"""Compare both completely reduced arms without filtering any cell."""
import json
from pathlib import Path
import sys
import reduce
import run


def verdict(a, b):
    admitted = a["all_participants_admitted"] and b["all_participants_admitted"]
    old = a["participants"]["whitefoot-hash-map"]
    new = b["participants"]["whitefoot-hash-map"]
    gain = all(new["cohort_max_ns_per_remove"][i] < old["cohort_min_ns_per_remove"][i]
               for i in (0, 1))
    loss = all(old["cohort_max_ns_per_remove"][i] < new["cohort_min_ns_per_remove"][i]
               for i in (0, 1))
    return {"both_arms_admitted": admitted, "qualified_gain": admitted and gain,
            "qualified_loss": admitted and loss,
            "qualified_candidate_peer_target": admitted and b["qualified_wf_advantage"]}


def main(home):
    chronology = json.loads((home / "order.json").read_text())
    assert chronology["completed"] and chronology["registered_order"] == [list(x) for x in run.ORDER]
    assert [(p["arm"], p["cohort"]) for p in chronology["processes"]] == run.ORDER
    arms = {arm: reduce.reduce_campaign(home / arm) for arm in ("A", "B")}
    for arm, result in arms.items():
        (home / arm / "reduction.json").write_text(json.dumps(result, indent=2) + "\n")
        status = json.loads((home / arm / "status.json").read_text())
        assert [dict(arm=arm, **p) for p in status["processes"]] == [
            p for p in chronology["processes"] if p["arm"] == arm]
    keys = ("element_bytes", "series", "entry_floor", "outcome")
    cells = []
    for a, b in zip(arms["A"]["cells"], arms["B"]["cells"]):
        assert all(a[k] == b[k] for k in keys)
        cells.append({**{k: a[k] for k in keys}, **verdict(a, b), "A": a, "B": b})
    assert len(cells) == 16
    summary = {name: sum(c[name] for c in cells) for name in (
        "both_arms_admitted", "qualified_gain", "qualified_loss", "qualified_candidate_peer_target")}
    result = {"order": run.ORDER, "summary": summary, "cells": cells,
              "scope": "Single-callsite O3 attribution only; no production policy adoption"}
    (home / "comparison.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(summary))


if __name__ == "__main__":
    if sys.argv[1:] == ["--self-test"]:
        def cell(low, high, admitted=True):
            return {"all_participants_admitted": admitted, "qualified_wf_advantage": True,
                    "participants": {"whitefoot-hash-map": {
                        "cohort_min_ns_per_remove": [low, low],
                        "cohort_max_ns_per_remove": [high, high]}}}
        assert verdict(cell(12, 13), cell(10, 11))["qualified_gain"]
        assert not verdict(cell(12, 13), cell(10, 12))["qualified_gain"]
        assert not verdict(cell(12, 13, False), cell(10, 11))["qualified_candidate_peer_target"]
        assert verdict(cell(10, 11), cell(12, 13))["qualified_loss"]
        print("Tie, invalid baseline, and loss direction discriminate")
    else:
        main(Path(sys.argv[1]).resolve())
