"""Build only the single-call-site account counterfactual after lane release."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

here = Path(__file__).resolve().parent
base = here.parent / "public-remove-api"
native = here.parent / "public-remove-inline-floor"
build = here / "build"
build.mkdir(exist_ok=True)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


control = base / "build/wf.account.ll"
candidate = here / "candidate.account.ll"
old = ("  call void @wf_map.hash_map_remove$instance$28da32efc51c2b65"
       "(ptr %wf.slot.1, ptr %v26, ptr %v25, ptr %v27)\n")
new = old.rstrip("\n") + " alwaysinline\n"
assert candidate.read_text().replace(new, old) == control.read_text()
assert control.read_text().count(old) == 1
assert sha(native / "candidate.ll") == "25315faf049fcbc9506d2b515ad36b7ef3eb890d74b0d51e3a1d6247b6f42c2c"
assert sha(native / "candidate-image") == "b79e4fcf400e67555527fa30a8aefc19e4435a63e5705e55a952ce1a99cc5e4f"

source = json.loads((base / "build/prepare-statuses.json").read_text())
by_stage = {record["stage"]: record for record in source}
compile_argv = by_stage["wf-account-object"]["argv"].copy()
compile_argv[compile_argv.index(str(control))] = str(candidate)
compile_argv[compile_argv.index(str(base / "build/wf-account.o"))] = str(build / "candidate-account.o")
link_argv = by_stage["link-account"]["argv"].copy()
link_argv[link_argv.index(str(base / "build/wf-account.o"))] = str(build / "candidate-account.o")
link_argv[link_argv.index(str(base / "build/remove-account"))] = str(build / "candidate-account")
statuses = []


def run(stage, argv):
    start = time.monotonic()
    with (build / (stage + ".stdout")).open("wb") as stdout, (build / (stage + ".stderr")).open("wb") as stderr:
        result = subprocess.run(argv, cwd=here, stdout=stdout, stderr=stderr, check=False)
    statuses.append({"stage": stage, "argv": argv, "exit": result.returncode,
                     "wall_s": time.monotonic() - start})
    (build / "statuses.json").write_text(json.dumps(statuses, indent=2) + "\n")
    print(stage, result.returncode, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)


run("candidate-account-object", compile_argv)
run("candidate-account-link", link_argv)
(build / "pins.json").write_text(json.dumps({
    "baseline_account_ir": sha(control), "candidate_account_ir": sha(candidate),
    "candidate_account_object": sha(build / "candidate-account.o"),
    "candidate_account_image": sha(build / "candidate-account"),
    "baseline_timed_image": sha(native / "control-image"),
    "candidate_timed_image": sha(native / "candidate-image")}, indent=2) + "\n")
print("account counterfactual prepared; no timing", flush=True)
