"""One fixed A0 B0 B1 A1 experiment; retire with this attribution trial."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
IMAGES = {arm: HERE.parent / "public-remove-inline-floor" / name
          for arm, name in (("A", "control-image"), ("B", "candidate-image"))}
ORDER = [("A", 0), ("B", 0), ("B", 1), ("A", 1)]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pins():
    frozen = json.loads((HERE / "frozen.json").read_text())
    observed = {}
    for key, expected in {**frozen["inputs"], **frozen["external_dependencies"]}.items():
        actual = sha(HERE / key)
        if actual != expected:
            raise ValueError("frozen input changed: " + key)
        observed[key] = actual
    observed["frozen.json"] = sha(HERE / "frozen.json")
    return observed


def main(output):
    if not os.environ.get("WHITEFOOT_CHECK_OWNER"):
        raise SystemExit("run through .github/run-check.pl")
    output.mkdir(parents=True, exist_ok=False)
    before = pins()
    statuses = {}
    for arm in IMAGES:
        (output / arm).mkdir()
        statuses[arm] = {"before": before, "order": [0, 1], "processes": [],
                         "no_retry": True, "completed": False}
    chronology = {"registered_order": ORDER, "processes": [], "completed": False}
    for arm, cohort in ORDER:
        home = output / arm
        out = home / f"cohort-{cohort}.csv"
        err = home / f"cohort-{cohort}.stderr"
        argv = [str(IMAGES[arm]), "remove-measure", str(cohort)]
        print("START", arm, cohort, flush=True)
        started = time.monotonic()
        with out.open("wb") as stdout, err.open("wb") as stderr:
            process = subprocess.run(argv, cwd=HERE, stdout=stdout, stderr=stderr, check=False)
        record = {"cohort": cohort, "argv": argv, "exit": process.returncode,
                  "wall_s": time.monotonic() - started,
                  "stdout_sha256": sha(out), "stderr_sha256": sha(err),
                  "stdout_bytes": out.stat().st_size, "stderr_bytes": err.stat().st_size}
        statuses[arm]["processes"].append(record)
        (home / "status.json").write_text(json.dumps(statuses[arm], indent=2) + "\n")
        chronology["processes"].append({"arm": arm, **record})
        (output / "order.json").write_text(json.dumps(chronology, indent=2) + "\n")
        print("END", arm, cohort, "exit", process.returncode, flush=True)
    after = pins()
    for arm, status in statuses.items():
        status.update(after=after, inputs_unchanged=before == after, completed=True)
        (output / arm / "status.json").write_text(json.dumps(status, indent=2) + "\n")
    chronology["completed"] = True
    (output / "order.json").write_text(json.dumps(chronology, indent=2) + "\n")
    if before != after or any(p["exit"] != 0 for p in chronology["processes"]):
        raise SystemExit(1)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: run.py NEW_OUTPUT_DIRECTORY")
    main(Path(sys.argv[1]).resolve())
