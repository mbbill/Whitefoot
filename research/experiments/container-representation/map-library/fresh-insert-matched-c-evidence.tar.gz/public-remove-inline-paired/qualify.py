"""Direct positive and independent negative outcomes; no timed measurement."""
from pathlib import Path
import json
import subprocess

here = Path(__file__).resolve().parent
out = here / "checks"
out.mkdir(exist_ok=True)
statuses = []


def run(mode, name, args, expected_exit, expected_stderr):
    argv = [str(here / "build" / ("remove-" + mode)), *args]
    with (out / (name + ".stdout")).open("w") as stdout, (out / (name + ".stderr")).open("w") as stderr:
        process = subprocess.run(argv, cwd=here, stdout=stdout, stderr=stderr,
                                 check=False)
    observed = (out / (name + ".stderr")).read_text().strip()
    expected_text = "" if expected_stderr == "" else "map ecosystem: " + expected_stderr
    passed = process.returncode == expected_exit and observed == expected_text
    record = {"name": name, "argv": argv, "exit": process.returncode,
              "expected_exit": expected_exit, "expected_stderr": expected_stderr,
              "observed_stderr": observed, "pass": passed}
    statuses.append(record)
    (out / "statuses.json").write_text(json.dumps(statuses, indent=2) + "\n")
    print(name, process.returncode, "pass" if passed else "FAIL", flush=True)
    if not passed:
        raise SystemExit(1)


for mode in ("timed", "account"):
    run(mode, mode + "-check", ["remove-check"], 0, "")
run("account", "account-account", ["remove-account"], 0, "")

faults = {
    "returned-key": "remove independent returned-owner/absent oracle",
    "returned-value": "remove independent returned-owner/absent oracle",
    "absent-some": "remove independent returned-owner/absent oracle",
    "capacity": "remove unchanged reported buckets",
    "cleanup": "remove independent retained-owner oracle",
    "allocation": "remove exact operation allocation ledger",
    "release": "remove exact operation allocation ledger",
}
for mode in ("timed", "account"):
    for variant in range(12):
        for fault, expected in faults.items():
            if mode == "timed" and fault in ("allocation", "release"):
                continue
            if fault == "capacity" and variant % 3 == 1:
                expected = "remove Rust usable capacity upper bound"
            name = f"{mode}-{variant}-{fault}"
            run(mode, name, ["remove-negative", fault, str(variant)], 1, expected)

print("public remove qualification terminal; no timing", flush=True)
