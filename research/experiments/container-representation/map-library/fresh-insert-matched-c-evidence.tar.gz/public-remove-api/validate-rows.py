"""Check that reported sample capacity ranges cover every retained batch."""
import csv
import io
import sys
from collections import defaultdict


GROUP = ("cohort", "element_bytes", "series", "variant", "outcome",
         "entry_floor", "sample", "control")


def validate(rows):
    groups = defaultdict(lambda: {"sample": [], "batch": []})
    for row in rows:
        key = tuple(row[name] for name in GROUP)
        groups[key][row["row_kind"]].append(row)
    assert groups, "no public remove rows"
    for key, group in groups.items():
        assert len(group["sample"]) == 1, (key, "sample count")
        sample = group["sample"][0]
        batches = group["batch"]
        assert len(batches) == int(sample["batches"]), (key, "batch count")
        assert {int(r["batch_or_batches"]) for r in batches} == set(range(len(batches))), (
            key, "batch identity")
        minimum = min(int(row["post_reported_min"]) for row in batches)
        maximum = max(int(row["post_reported_max"]) for row in batches)
        assert int(sample["post_reported_min"]) == minimum, (key, "sample minimum")
        assert int(sample["post_reported_max"]) == maximum, (key, "sample maximum")
    return len(groups)


def self_test():
    text = "cohort,element_bytes,series,variant,outcome,entry_floor,sample,control,row_kind,batches,batch_or_batches,post_reported_min,post_reported_max\n"
    text += "0,8,aligned-hash,rust-hash-map,present,64,0,0,batch,2,0,100,100\n"
    text += "0,8,aligned-hash,rust-hash-map,present,64,0,0,batch,2,1,90,110\n"
    text += "0,8,aligned-hash,rust-hash-map,present,64,0,0,sample,2,2,90,110\n"
    rows = list(csv.DictReader(io.StringIO(text)))
    assert validate(rows) == 1
    rows[-1]["post_reported_min"] = "100"
    try:
        validate(rows)
    except AssertionError as error:
        assert "sample minimum" in str(error)
    else:
        raise AssertionError("first-batch-only sample range was admitted")
    rows[-1]["post_reported_min"] = "90"
    rows[-1]["post_reported_max"] = "100"
    try:
        validate(rows)
    except AssertionError as error:
        assert "sample maximum" in str(error)
    else:
        raise AssertionError("first-batch-only sample maximum was admitted")
    print("later-batch capacity-range fault rejected")


if __name__ == "__main__":
    if sys.argv[1:] == ["--self-test"]:
        self_test()
    else:
        assert len(sys.argv) == 2, "usage: validate-rows.py cohort.csv"
        with open(sys.argv[1], newline="") as source:
            print("validated sample capacity ranges", validate(csv.DictReader(source)))
