#!/usr/bin/env python3
"""Reduce the fixed public-remove campaign; never exclude a timed observation."""
import csv
import hashlib
import json
from pathlib import Path
import re
import statistics
import sys
import run

HERE = Path(__file__).resolve().parent
WIDTHS = (8, 256)
SERIES = ("native-default", "aligned-hash")
FLOORS = (64, 4096)
OUTCOMES = ("present", "absent")
PEERS = ("whitefoot-hash-map", "rust-hash-map", "cpp-unordered-map")
HEADER = ("contract,cohort,element_bytes,series,variant,outcome,entry_floor,"
          "initial_count,window,sample,control,row_kind,batch_or_batches,batches,"
          "contexts,calls,elapsed_ns,receipt,cleanup_checksum,"
          "initial_reported_capacity,post_reported_min,post_reported_max,"
          "instrument_valid").split(",")
NUMERIC = set(HEADER) - {"contract", "series", "variant", "outcome", "row_kind"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def clock_record(stderr):
    lines = stderr.splitlines()
    mins = re.findall(r"^reserve clock: minimum_nonzero_ns=(\d+) fault=0$", stderr, re.M)
    maxs = re.findall(r"^reserve clock: maximum_empty_ns=(\d+)$", stderr, re.M)
    require(len(mins) == len(maxs) == 1, "clock calibration header")
    marker = "reserve clock-only: index,elapsed_ns"
    require(lines.count(marker) == 1, "clock empty-interval marker")
    start = lines.index(marker) + 1
    empty = []
    for line in lines[start:start + 1024]:
        fields = line.split(",")
        require(len(fields) == 2 and all(field.isdigit() for field in fields),
                "clock empty interval syntax")
        empty.append((int(fields[0]), int(fields[1])))
    require([index for index, _ in empty] == list(range(1024)), "clock empty interval order")
    require(max(value for _, value in empty) == int(maxs[0]), "clock maximum mismatch")
    require(int(mins[0]) <= 100, "clock quantum over 100 ns")
    return {"minimum_nonzero_ns": int(mins[0]), "maximum_empty_ns": int(maxs[0]),
            "empty_intervals": 1024}


def parse_rows(path, cohort):
    groups = {}
    count = 0
    with path.open(newline="") as source:
        reader = csv.DictReader(source)
        require(reader.fieldnames == HEADER, "CSV header")
        for raw in reader:
            require(None not in raw and all(value is not None for value in raw.values()),
                    "CSV column count")
            row = {name: (int(value) if name in NUMERIC else value)
                   for name, value in raw.items()}
            width, series, floor, outcome, peer = (row["element_bytes"], row["series"],
                row["entry_floor"], row["outcome"], row["variant"])
            require(row["contract"] == "public-remove" and row["cohort"] == cohort,
                    "CSV contract/cohort")
            require(width in WIDTHS and series in SERIES and floor in FLOORS and
                    outcome in OUTCOMES and peer in PEERS, "CSV panel membership")
            require(row["initial_count"] == floor // 2 and row["window"] == floor // 8,
                    "CSV population/work")
            require(0 <= row["sample"] < 12 and row["control"] in (0, 1),
                    "CSV sample/control")
            batches, contexts = (128, 1024) if floor == 64 else (64, 32)
            require(row["batches"] == batches and row["contexts"] == contexts,
                    "CSV batch shape")
            kind, batch = row["row_kind"], row["batch_or_batches"]
            require((kind == "batch" and 0 <= batch < batches) or
                    (kind == "sample" and batch == batches), "CSV batch index")
            require(row["calls"] == (contexts * floor // 8 if kind == "batch" else 1048576),
                    "CSV timed operation count")
            require(row["elapsed_ns"] >= 0 and row["instrument_valid"] in (0, 1),
                    "CSV time/flag")
            cap, low, high = (row["initial_reported_capacity"],
                              row["post_reported_min"], row["post_reported_max"])
            require(0 < cap < 1 << 32 and floor <= low <= high <= cap,
                    "CSV reported capacity range")
            if peer != "rust-hash-map":
                require(low == high == cap, "WF/C++ unchanged reported bucket count")
            if peer == "whitefoot-hash-map":
                require(cap == 4 * (floor - 1) // 3 + 1, "WF physical slot count")
            key = (width, series, floor, outcome, peer, row["sample"])
            slot = (kind, batch, row["control"])
            group = groups.setdefault(key, {})
            require(slot not in group, "duplicate CSV row")
            group[slot] = row
            count += 1
    require(count == 111744 and len(groups) == 16 * 3 * 12,
            "complete raw CSV panel")
    return groups, count


def summarize_group(key, rows, clock_max):
    _, _, floor, _, _, _ = key
    batches, contexts = (128, 1024) if floor == 64 else (64, 32)
    require(len(rows) == 2 * (batches + 1), "complete sample/control batches")
    real_sum = control_sum = control_receipt = real_receipt = cleanup = 0
    initial_capacity = None
    post_min, post_max = 1 << 64, 0
    all_clock = True
    for batch in range(batches):
        real = rows[("batch", batch, 0)]
        control = rows[("batch", batch, 1)]
        cap = real["initial_reported_capacity"]
        require(cap == control["initial_reported_capacity"] and
                (initial_capacity is None or cap == initial_capacity),
                "initial capacity across batch/control")
        initial_capacity = cap
        for field in ("post_reported_min", "post_reported_max", "cleanup_checksum"):
            require(real[field] == control[field], "batch control " + field)
        post_min = min(post_min, real["post_reported_min"])
        post_max = max(post_max, real["post_reported_max"])
        ok = real["elapsed_ns"] // 100 >= clock_max
        require(real["instrument_valid"] == control["instrument_valid"] == int(ok),
                "per-batch clock admission")
        all_clock &= ok
        real_sum += real["elapsed_ns"]
        control_sum += control["elapsed_ns"]
        real_receipt ^= real["receipt"]
        control_receipt += control["receipt"]
        cleanup ^= real["cleanup_checksum"]
    real = rows[("sample", batches, 0)]
    control = rows[("sample", batches, 1)]
    for row in (real, control):
        require(row["initial_reported_capacity"] == initial_capacity and
                row["post_reported_min"] == post_min and
                row["post_reported_max"] == post_max,
                "sample full-batch capacity extrema")
        require(row["cleanup_checksum"] == cleanup, "sample cleanup XOR")
    require(real["elapsed_ns"] == real_sum and control["elapsed_ns"] == control_sum,
            "sample elapsed sum")
    require(real["receipt"] == real_receipt and
            control["receipt"] == control_receipt, "sample receipt fold")
    admitted = all_clock and real_sum >= 1000000
    require(real["instrument_valid"] == control["instrument_valid"] == int(admitted),
            "sample instrument admission")
    return {"elapsed_ns": real_sum, "control_elapsed_ns": control_sum,
            "valid": admitted, "initial_reported_capacity": initial_capacity,
            "post_reported_min": post_min, "post_reported_max": post_max,
            "calls": 1048576}


def drift(a, b):
    return (max(a, b) - min(a, b)) / min(a, b)


def strict_below(a, b):
    return max(a) < min(b)


def account_rows():
    path = HERE / "checks/account-account.stdout"
    result = {}
    with path.open(newline="") as source:
        reader = csv.DictReader(source)
        require(len(reader.fieldnames) == 22, "account CSV header width")
        for raw in reader:
            row = {name: (value if name in ("contract", "series", "variant", "outcome")
                          else int(value)) for name, value in raw.items()}
            key = (row["element_bytes"], row["series"], row["entry_floor"],
                   row["outcome"], row["variant"])
            require(row["contract"] == "remove" and key not in result,
                    "account contract/unique cell")
            require(key[0] in WIDTHS and key[1] in SERIES and key[2] in FLOORS and
                    key[3] in OUTCOMES and key[4] in PEERS, "account panel membership")
            require(row["initial_count"] == key[2] // 2 and
                    row["window"] == key[2] // 8, "account operation count")
            require(row["initial_physical_slots_or_buckets"] >= key[2] and
                    row["initial_usable_entries"] >= key[2] and
                    row["post_usable_entries"] >= key[2], "account headroom")
            require(row["remove_requests"] == 0 and row["final_live"] == 0,
                    "account no removal allocation/final zero live")
            releases = key[2] // 8 if key[4] == PEERS[2] and key[3] == "present" else 0
            require(row["remove_releases"] == releases, "account removal releases")
            result[key] = row
    require(len(result) == 16 * 3, "complete account panel")
    return result


def reduce_campaign(home):
    status = json.loads((home / "status.json").read_text())
    checks = json.loads((HERE / "checks/statuses.json").read_text())
    require(len(checks) == 147 and all(row["pass"] for row in checks),
            "direct qualification statuses")
    frozen = json.loads((HERE / "frozen.json").read_text())
    require(status["completed"] is True and status["inputs_unchanged"] is True and
            status["before"] == status["after"] and
            status["before"]["frozen.json"] == sha(HERE / "frozen.json"),
            "frozen campaign inputs")
    require(status["order"] == [0, 1] and len(status["processes"]) == 2,
            "registered two-cohort order")
    require(set(frozen["inputs"]) | set(frozen["external_dependencies"]) ==
            set(status["before"]) - {"frozen.json"},
            "frozen input inventory")
    require(status["before"] == run.pins(), "retained status vs frozen bytes")
    require(status["no_retry"] is True, "single fixed campaign")
    samples, raw_rows, clocks, exits = {}, {}, {}, {}
    for cohort in (0, 1):
        process = status["processes"][cohort]
        require(process["cohort"] == cohort and process["exit"] in (0, 1),
                "direct cohort status")
        require(process["argv"] == [str(HERE / "build/remove-timed"),
                                    "remove-measure", str(cohort)],
                "actual public-remove command")
        csv_path = home / f"cohort-{cohort}.csv"
        stderr_path = home / f"cohort-{cohort}.stderr"
        for path, stem in ((csv_path, "stdout"), (stderr_path, "stderr")):
            require(path.stat().st_size == process[stem + "_bytes"] and
                    sha(path) == process[stem + "_sha256"], "raw process output pin")
        stderr = stderr_path.read_text()
        clock = clock_record(stderr)
        clocks[str(cohort)] = clock
        groups, raw_rows[str(cohort)] = parse_rows(csv_path, cohort)
        cohort_samples = {key: summarize_group(key, rows, clock["maximum_empty_ns"])
                          for key, rows in groups.items()}
        admitted = all(sample["valid"] for sample in cohort_samples.values())
        require((process["exit"] == 0) == admitted,
                "direct exit vs every sample instrument admission")
        if process["exit"] == 1:
            require(stderr.strip().splitlines()[-1] ==
                    "map ecosystem: public remove instrument admission",
                    "instrument failure diagnostic")
        samples[cohort] = cohort_samples
        exits[str(cohort)] = process["exit"]
    accounts = account_rows()
    cells = []
    for width in WIDTHS:
        for series in SERIES:
            for floor in FLOORS:
                for outcome in OUTCOMES:
                    participants = {}
                    for peer in PEERS:
                        vectors = [[samples[cohort][(width, series, floor, outcome, peer, n)]
                                    for n in range(12)] for cohort in (0, 1)]
                        times = [[row["elapsed_ns"] for row in vector] for vector in vectors]
                        medians = [statistics.median(v) for v in times]
                        participants[peer] = {
                            "account_initial_physical_slots_or_buckets": accounts[
                                (width, series, floor, outcome, peer)][
                                    "initial_physical_slots_or_buckets"],
                            "account_initial_usable_entries": accounts[
                                (width, series, floor, outcome, peer)]["initial_usable_entries"],
                            "account_prepare_bytes": accounts[
                                (width, series, floor, outcome, peer)]["prepare_bytes"],
                            "context_scaled_prepare_bytes": accounts[
                                (width, series, floor, outcome, peer)]["prepare_bytes"] *
                                (1024 if floor == 64 else 32),
                            "account_prepare_requests": accounts[
                                (width, series, floor, outcome, peer)]["prepare_requests"],
                            "account_remove_releases": accounts[
                                (width, series, floor, outcome, peer)]["remove_releases"],
                            "cohort_median_ns_per_remove": [m / 1048576 for m in medians],
                            "cohort_min_ns_per_remove": [min(v) / 1048576 for v in times],
                            "cohort_max_ns_per_remove": [max(v) / 1048576 for v in times],
                            "cohort_invalid_samples": [sum(not row["valid"] for row in v)
                                                       for v in vectors],
                            "cohort_initial_reported_capacity": [sorted(set(
                                row["initial_reported_capacity"] for row in v)) for v in vectors],
                            "cohort_post_reported_min": [min(row["post_reported_min"] for row in v)
                                                         for v in vectors],
                            "cohort_post_reported_max": [max(row["post_reported_max"] for row in v)
                                                         for v in vectors],
                            "cohort_drift_fraction": drift(*medians),
                            "all_samples_admitted": all(row["valid"] for v in vectors for row in v),
                        }
                    cohorts = []
                    for cohort in (0, 1):
                        def values(peer):
                            return [samples[cohort][(width, series, floor, outcome, peer, n)]
                                    ["elapsed_ns"] for n in range(12)]
                        wf, rust, cpp = [values(peer) for peer in PEERS]
                        slower = PEERS[1] if statistics.median(rust) >= statistics.median(cpp) else PEERS[2]
                        peer_values = rust if slower == PEERS[1] else cpp
                        cohorts.append({"cohort": cohort, "slower_peer": slower,
                                        "strict_wf_below_slower_peer_range": strict_below(wf, peer_values),
                                        "wf_vs_slower_peer_median_delta_percent": 100 * (
                                            statistics.median(wf) - statistics.median(peer_values)) /
                                            statistics.median(peer_values)})
                    admitted = all(p["all_samples_admitted"] and
                                   p["cohort_drift_fraction"] <= .10
                                   for p in participants.values())
                    cell = {"element_bytes": width, "series": series, "entry_floor": floor,
                            "outcome": outcome, "participants": participants,
                            "cohorts": cohorts, "all_participants_admitted": admitted,
                            "qualified_wf_advantage": admitted and all(
                                c["strict_wf_below_slower_peer_range"] for c in cohorts)}
                    cells.append(cell)
    return {"criterion": "criterion.txt (fixed before timing)",
            "check_status_sha256": sha(HERE / "checks/statuses.json"),
            "qualified_check_outcomes": len(checks), "raw_rows": raw_rows,
            "process_exits": exits, "clocks": clocks,
            "geometry_controls_unsubtracted": True, "cells": cells,
            "qualified_cells": sum(cell["qualified_wf_advantage"] for cell in cells),
            "global_qualified_advantage": all(cell["qualified_wf_advantage"] for cell in cells)}


def self_test():
    require(drift(10, 11) == .10, "10 percent drift inclusive")
    require(strict_below((10, 11), (12, 13)), "strict range positive")
    require(not strict_below((10, 12), (12, 13)), "strict range tie rejected")
    key = (8, "native-default", 64, "present", PEERS[0], 0)
    rows = {}
    for batch in range(128):
        for control in (0, 1):
            rows[("batch", batch, control)] = {
                "initial_reported_capacity": 85, "post_reported_min": 85,
                "post_reported_max": 85, "cleanup_checksum": batch,
                "elapsed_ns": 10000 if not control else 1000,
                "receipt": batch if not control else 85, "instrument_valid": 1}
    for control in (0, 1):
        rows[("sample", 128, control)] = {
            "initial_reported_capacity": 85, "post_reported_min": 85,
            "post_reported_max": 85, "cleanup_checksum": 0,
            "elapsed_ns": 1280000 if not control else 128000,
            "receipt": 0 if not control else 128 * 85, "instrument_valid": 1}
    require(summarize_group(key, rows, 100)["valid"], "synthetic admitted sample")
    rows[("sample", 128, 0)]["post_reported_max"] = 84
    try:
        summarize_group(key, rows, 100)
    except ValueError as error:
        require("capacity extrema" in str(error), "sample maximum fault diagnostic")
    else:
        raise AssertionError("sample maximum fault admitted")
    rows[("sample", 128, 0)]["post_reported_max"] = 85
    rows[("batch", 127, 0)]["instrument_valid"] = 0
    try:
        summarize_group(key, rows, 100)
    except ValueError as error:
        require("clock admission" in str(error), "batch flag fault diagnostic")
    else:
        raise AssertionError("batch clock fault admitted")
    print("strict range, sample extrema, and batch clock faults rejected")


if __name__ == "__main__":
    if sys.argv[1:] == ["--self-test"]:
        self_test()
    else:
        require(len(sys.argv) == 2, "usage: reduce.py CAMPAIGN_DIRECTORY")
        destination = Path(sys.argv[1]).resolve()
        result = reduce_campaign(destination)
        (destination / "reduction.json").write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps({"raw_rows": result["raw_rows"],
                          "qualified_cells": result["qualified_cells"],
                          "global_qualified_advantage": result["global_qualified_advantage"]}))
