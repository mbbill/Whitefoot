#!/usr/bin/env python3
"""Reduce the preregistered paired fresh-insertion panel without exclusions."""
import csv
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import re
import statistics
import sys

MASK = (1 << 64) - 1
HERE = Path(__file__).resolve().parent
ORDER = [('control', 0), ('candidate', 0), ('candidate', 1), ('control', 1)]
HEADER = ('contract,cohort,element_bytes,series,variant,entry_floor,initial_count,'
          'window,sample,control,row_kind,batch_or_batches,batches,contexts,calls,'
          'elapsed_ns,receipt,cleanup_checksum,capacity,instrument_valid').split(',')
WIDTHS = (8, 256)
SERIES = ('native-default', 'aligned-hash')
FLOORS = (64, 4096)
PEERS = ('whitefoot-hash-map', 'rust-hash-map', 'cpp-unordered-map', 'matched-c-sparse')
NUMERIC = {'cohort','element_bytes','entry_floor','initial_count','window','sample',
           'control','batch_or_batches','batches','contexts','calls','elapsed_ns',
           'receipt','cleanup_checksum','capacity','instrument_valid'}

def require(ok, message):
    if not ok:
        raise ValueError(message)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def mix(value):
    value = ((value ^ (value >> 30)) * 0xbf58476d1ce4e5b9) & MASK
    value = ((value ^ (value >> 27)) * 0x94d049bb133111eb) & MASK
    return value ^ (value >> 31)

@lru_cache(None)
def owner_oracle(wide, count, seed):
    ordered = seed & MASK
    total = parity = 0
    for index in range(count):
        key = 2 * index + 1
        value_seed = (seed + index) & MASK
        for word in range(32 if wide else 1):
            key = (key * 131 + value_seed + word) & MASK
        total = (total + key) & MASK
        parity ^= mix(key)
    return (mix(ordered) ^ mix(total) ^ parity ^
            ((count * 0x9e3779b97f4a7c15) & MASK)) & MASK

def expected_cleanup(width, floor, sample, batch, contexts):
    count = floor // 2 + floor // 8
    seed = 101 + sample + batch * contexts
    result = 0
    for index in range(contexts):
        result ^= owner_oracle(width == 256, count, seed + index)
    return result

def clock_record(stderr):
    lines = stderr.splitlines()
    mins = re.findall(r'^reserve clock: minimum_nonzero_ns=(\d+) fault=0$',stderr,re.M)
    maxs = re.findall(r'^reserve clock: maximum_empty_ns=(\d+)$',stderr,re.M)
    require(len(mins)==len(maxs)==1,'clock calibration header')
    marker = 'reserve clock-only: index,elapsed_ns'
    require(lines.count(marker)==1,'clock empty-interval marker')
    start = lines.index(marker)+1
    empty = []
    for line in lines[start:start+1024]:
        fields = line.split(',')
        require(len(fields)==2 and fields[0].isdigit() and fields[1].isdigit(),
                'clock empty interval syntax')
        empty.append((int(fields[0]),int(fields[1])))
    require([i for i,_ in empty]==list(range(1024)),'clock empty interval order/count')
    require(max(t for _,t in empty)==int(maxs[0]),'clock maximum mismatch')
    require(int(mins[0])<=100,'clock quantum over 100 ns')
    return {'minimum_nonzero_ns':int(mins[0]),'maximum_empty_ns':int(maxs[0]),
            'empty_intervals':1024}

def parse_rows(path, arm, cohort):
    groups = {}
    with path.open(newline='') as stream:
        reader = csv.DictReader(stream)
        require(reader.fieldnames==HEADER,'CSV header: '+str(path))
        count = 0
        for source in reader:
            require(None not in source,'CSV column count')
            row = {k:(int(v) if k in NUMERIC else v) for k,v in source.items()}
            require(row['contract']=='fresh-insert' and row['cohort']==cohort,'CSV contract/cohort')
            width, series, floor, peer = (row['element_bytes'],row['series'],
                                           row['entry_floor'],row['variant'])
            require(width in WIDTHS and series in SERIES and floor in FLOORS and peer in PEERS,
                    'CSV cell/peer membership')
            require(row['initial_count']==floor//2 and row['window']==floor//8,
                    'CSV shape')
            sample, control = row['sample'],row['control']
            require(0<=sample<12 and control in (0,1),'CSV sample/control')
            batches = 128 if floor==64 else 64
            contexts = 256 if floor==64 else 8
            require(row['batches']==batches and row['contexts']==contexts,'CSV batch shape')
            require(row['row_kind'] in ('batch','sample'),'CSV row kind')
            batch = row['batch_or_batches']
            require((row['row_kind']=='batch' and 0<=batch<batches) or
                    (row['row_kind']=='sample' and batch==batches),'CSV batch index')
            require(row['calls']==(contexts*floor//8 if row['row_kind']=='batch' else 262144),
                    'CSV insertion-work normalization')
            require(row['capacity']>0 and row['capacity']<(1<<32),'CSV capacity range')
            require(row['instrument_valid'] in (0,1),'CSV instrument flag')
            key=(width,series,floor,peer,sample)
            slot=(row['row_kind'],batch,control)
            group=groups.setdefault(key,{})
            require(slot not in group,'duplicate CSV row')
            group[slot]=row
            count+=1
    require(count==74496 and len(groups)==8*4*12,'complete CSV panel rows/groups')
    return groups,count

def summarize_group(key, rows, clock_max):
    width,series,floor,peer,sample=key
    batches=128 if floor==64 else 64
    contexts=256 if floor==64 else 8
    expected_size=2*(batches+1)
    require(len(rows)==expected_size,'incomplete sample batch/control rows')
    real_elapsed=control_elapsed=real_receipt=control_receipt=cleanup=0
    capacity=None
    all_clock=True
    for batch in range(batches):
        real=rows[('batch',batch,0)]
        control=rows[('batch',batch,1)]
        require(real['capacity']==control['capacity'],'batch geometry control capacity')
        cap=real['capacity']
        if capacity is None: capacity=cap
        require(cap==capacity,'capacity changes across batches')
        if peer in ('whitefoot-hash-map','matched-c-sparse'):
            require(cap==4*(floor-1)//3+1,'WF/C exact physical slots')
        elif peer=='rust-hash-map':
            require(cap>=floor,'Rust application headroom')
        else:
            require(cap>=floor,'C++ bucket floor with ordinary max_load_factor 1')
        require(real['receipt']==contexts*floor//8,'fresh batch receipt')
        final_len=floor//2+floor//8
        expected_control=contexts*((cap<<32)|final_len)
        require(control['receipt']==expected_control,'geometry control receipt')
        expected=expected_cleanup(width,floor,sample,batch,contexts)
        require(real['cleanup_checksum']==control['cleanup_checksum']==expected,
                'independent complete-owner batch oracle')
        ok=real['elapsed_ns']//100>=clock_max
        require(real['instrument_valid']==control['instrument_valid']==int(ok),
                'per-batch clock flag')
        all_clock &= ok
        real_elapsed+=real['elapsed_ns'];control_elapsed+=control['elapsed_ns']
        real_receipt+=real['receipt'];control_receipt+=control['receipt']
        cleanup ^= expected
    real=rows[('sample',batches,0)]; control=rows[('sample',batches,1)]
    require(real['capacity']==control['capacity']==capacity,'sample capacity')
    require(real['elapsed_ns']==real_elapsed and control['elapsed_ns']==control_elapsed,
            'sample elapsed sum')
    require(real['receipt']==real_receipt==262144 and
            control['receipt']==control_receipt,'sample receipt sum')
    require(real['cleanup_checksum']==control['cleanup_checksum']==cleanup,
            'sample cleanup XOR')
    valid=all_clock and real_elapsed>=1000000
    require(real['instrument_valid']==control['instrument_valid']==int(valid),
            'sample instrument flag')
    return {'elapsed_ns':real_elapsed,'control_elapsed_ns':control_elapsed,
            'capacity':capacity,'valid':bool(valid),'cleanup_checksum':cleanup,
            'insertion_work_calls':262144,
            'actual_control_geometry_calls':batches*contexts}

def median(values):
    return statistics.median(values)

def drift(a,b):
    return (max(a,b)-min(a,b))/min(a,b)

def main():
    require(len(sys.argv)==2,'usage: reduce.py CAMPAIGN_DIRECTORY')
    home=Path(sys.argv[1]).resolve()
    status=json.loads((home/'status.json').read_text())
    check_paths=[HERE/'checks-original/statuses.json',
                 HERE/'checks-c-final/statuses.json',
                 HERE/'checks-contract/statuses.json']
    checks=[json.loads(path.read_text()) for path in check_paths]
    require([len(rows) for rows in checks]==[92,72,52] and
            all(row['pass'] for rows in checks for row in rows),
            'original, C and direct Put correctness/fault qualification')
    require(status['completed'] is True and status['inputs_unchanged'] is True,
            'complete unchanged campaign inputs')
    require(status['before']==status['after'],'campaign before/after input pins')
    require([tuple(x) for x in status['order']]==ORDER,'registered process order')
    require(len(status['processes'])==4,'four direct process statuses')
    samples={}; clocks={}; raw_rows={}; exits={}
    for index,(arm,cohort) in enumerate(ORDER):
        process=status['processes'][index]
        require((process['arm'],process['cohort'])==(arm,cohort),'process order/status')
        require(process['exit'] in (0,1),'unexpected process exit')
        exits[f'{arm}{cohort}']=process['exit']
        csv_path=home/f'{arm}-cohort-{cohort}.csv'
        stderr_path=home/f'{arm}-cohort-{cohort}.stderr'
        require(csv_path.stat().st_size==process['stdout_bytes'] and
                sha(csv_path)==process['stdout_sha256'],'raw CSV pin')
        require(stderr_path.stat().st_size==process['stderr_bytes'] and
                sha(stderr_path)==process['stderr_sha256'],'stderr pin')
        stderr=stderr_path.read_text()
        clock=clock_record(stderr)
        clocks[f'{arm}{cohort}']=clock
        groups,nrows=parse_rows(csv_path,arm,cohort)
        raw_rows[f'{arm}{cohort}']=nrows
        rows={}
        for key,group in groups.items():
            rows[key]=summarize_group(key,group,clock['maximum_empty_ns'])
        all_valid=all(x['valid'] for x in rows.values())
        require((process['exit']==0)==all_valid,'direct exit vs complete instrument flags')
        if process['exit']==1:
            require(stderr.strip().splitlines()[-1]==
                    'map ecosystem: fresh fixed-panel instrument qualification',
                    'expected complete-panel instrument exit')
        samples[(arm,cohort)]=rows
    cells=[]
    for width in WIDTHS:
        for series in SERIES:
            for floor in FLOORS:
                cell={'element_bytes':width,'series':series,'entry_floor':floor,'cohorts':[],
                      'participants':{},'qualified_candidate_gain':False}
                for arm in ('control','candidate'):
                    for peer in PEERS:
                        values=[]; admitted=True
                        for cohort in (0,1):
                            group=[samples[(arm,cohort)][(width,series,floor,peer,s)]
                                   for s in range(12)]
                            values.append([x['elapsed_ns'] for x in group])
                            admitted &= all(x['valid'] for x in group)
                        medians=[median(v) for v in values]
                        cell['participants'][f'{arm}:{peer}']={
                            'cohort_median_ns_per_insertion':[m/262144 for m in medians],
                            'cohort_min_ns_per_insertion':[min(v)/262144 for v in values],
                            'cohort_max_ns_per_insertion':[max(v)/262144 for v in values],
                            'cohort_drift_fraction':drift(*medians),
                            'reported_capacity':[samples[(arm,c)][(width,series,floor,peer,0)]['capacity']
                                                 for c in (0,1)],
                            'all_samples_instrument_valid':bool(admitted),
                            'cohort_invalid_sample_counts':[
                                sum(not samples[(arm,c)][(width,series,floor,peer,s)]['valid']
                                    for s in range(12)) for c in (0,1)]}
                for cohort in (0,1):
                    def vector(arm,peer):
                        return [samples[(arm,cohort)][(width,series,floor,peer,s)]['elapsed_ns']
                                for s in range(12)]
                    control=vector('control',PEERS[0]); candidate=vector('candidate',PEERS[0])
                    rust=vector('candidate',PEERS[1]); cpp=vector('candidate',PEERS[2])
                    matched_c=vector('candidate',PEERS[3])
                    slower=PEERS[1] if median(rust)>=median(cpp) else PEERS[2]
                    peer_values=rust if slower==PEERS[1] else cpp
                    cell['cohorts'].append({
                        'cohort':cohort,'slower_candidate_panel_peer':slower,
                        'strict_candidate_below_control_range':max(candidate)<min(control),
                        'strict_candidate_below_slower_peer_range':max(candidate)<min(peer_values),
                        'strict_matched_c_below_control_wf_range':max(vector('control',PEERS[3]))<min(control),
                        'strict_matched_c_below_candidate_wf_range':max(matched_c)<min(candidate),
                        'strict_matched_c_above_control_wf_range':min(vector('control',PEERS[3]))>max(control),
                        'strict_matched_c_above_candidate_wf_range':min(matched_c)>max(candidate),
                        'control_median_ns_per_insertion':median(control)/262144,
                        'candidate_median_ns_per_insertion':median(candidate)/262144,
                        'candidate_vs_control_median_delta_percent':
                            100*(median(candidate)-median(control))/median(control),
                        'candidate_vs_slower_peer_median_delta_percent':
                            100*(median(candidate)-median(peer_values))/median(peer_values)})
                cell['peer_interarm_median_shift_fraction_diagnostic'] = {
                    peer: [
                        abs(cell['participants'][f'candidate:{peer}']['cohort_median_ns_per_insertion'][c]
                            - cell['participants'][f'control:{peer}']['cohort_median_ns_per_insertion'][c])
                        / min(cell['participants'][f'candidate:{peer}']['cohort_median_ns_per_insertion'][c],
                              cell['participants'][f'control:{peer}']['cohort_median_ns_per_insertion'][c])
                        for c in (0,1)]
                    for peer in PEERS[1:]
                }
                all_admitted=all(x['all_samples_instrument_valid'] and
                                 x['cohort_drift_fraction']<=0.10
                                 for x in cell['participants'].values())
                cell['all_participants_admitted']=all_admitted
                cell['qualified_candidate_gain']=all_admitted and all(
                    c['strict_candidate_below_control_range'] and
                    c['strict_candidate_below_slower_peer_range'] for c in cell['cohorts'])
                cells.append(cell)
    result={'criterion':'criterion.txt (fixed before campaign)',
            'check_status_sha256':{str(p.relative_to(HERE)):sha(p) for p in check_paths},
            'qualified_check_outcomes':sum(map(len,checks)),
            'process_exits':exits,'raw_rows':raw_rows,'clocks':clocks,
            'control_calls_field':'insertion-work normalizer, not actual geometry call count',
            'actual_control_calls_per_sample':{'S64':32768,'S4096':512},
            'control_intervals_unsubtracted':True,
            'cells':cells,'qualified_cells':sum(c['qualified_candidate_gain'] for c in cells),
            'global_qualified_benefit':all(c['qualified_candidate_gain'] for c in cells)}
    (home/'reduction.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'raw_rows':raw_rows,'qualified_cells':result['qualified_cells'],
                      'global_qualified_benefit':result['global_qualified_benefit']}))

if __name__=='__main__':
    main()
