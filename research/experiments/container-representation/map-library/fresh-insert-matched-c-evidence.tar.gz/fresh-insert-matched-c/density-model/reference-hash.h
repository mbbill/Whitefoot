/* Exact source excerpt, only HELPER decoration removed. */
typedef struct { uint64_t salt; bool collide; } HashEnv;
static uint64_t mix(uint64_t value) {
    value ^= value >> 30;
    value *= UINT64_C(0xbf58476d1ce4e5b9);
    value ^= value >> 27;
    value *= UINT64_C(0x94d049bb133111eb);
    return value ^ (value >> 31);
}

static uint64_t key_hash(const HashEnv *env, const uint64_t *key) {
    return env->collide ? 0 : mix(*key ^ env->salt);
}

static bool key_equal(const HashEnv *env, const uint64_t *left, const uint64_t *right) {
    (void)env;
    return *left == *right;
}

static uint64_t key_at(uint64_t index) { return index * 2 + 1; }
static uint64_t successor(uint64_t index, uint64_t capacity) {
    return index + 1 == capacity ? 0 : index + 1;
}
