from pathlib import Path
import subprocess,json,hashlib,time
p=Path(__file__).resolve().parent
files=['criterion.txt','source-pins.json','reference-hash.h','model.c','run.py']
pins={f:hashlib.sha256((p/f).read_bytes()).hexdigest() for f in files}
(p/'pre-run-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
statuses=[]
def run(name,args,expected=0):
    start=time.monotonic()
    with (p/(name+'.stdout')).open('w') as out,(p/(name+'.stderr')).open('w') as err:
        r=subprocess.run(args,cwd=p,stdout=out,stderr=err)
    statuses.append(dict(stage=name,command=args,exit=r.returncode,expected=expected,seconds=time.monotonic()-start))
    (p/'statuses.json').write_text(json.dumps(statuses,indent=2)+'\n')
    if r.returncode!=expected: raise SystemExit('unexpected stage status: '+name)
run('build',['/usr/bin/clang','-O2','-std=c11','-Wall','-Wextra','-Werror','model.c','-o','model'])
run('check',['./model','check'])
for fault in range(1,4):run('fault-'+str(fault),['./model','fault',str(fault)],1)
run('model',['./model'])
assert pins=={f:hashlib.sha256((p/f).read_bytes()).hexdigest() for f in files}
(p/'post-run-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
print(json.dumps(statuses,indent=2))
