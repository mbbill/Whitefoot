#!/usr/bin/env python3
"""Separate preregistered C attribution from the inherited combined target."""

import hashlib
import json
import sys
from pathlib import Path


def main() -> None:
    campaign = Path(sys.argv[1])
    source = campaign / "reduction.json"
    raw = source.read_bytes()
    reduction = json.loads(raw)
    cells = []
    for cell in reduction["cells"]:
        cohorts = cell["cohorts"]
        participants = cell["participants"]
        flags = {
            "c_strictly_below_wf_a_both_cohorts": all(
                c["strict_matched_c_below_control_wf_range"] for c in cohorts
            ),
            "c_strictly_above_wf_a_both_cohorts": all(
                c["strict_matched_c_above_control_wf_range"] for c in cohorts
            ),
            "c_strictly_below_wf_b_both_cohorts": all(
                c["strict_matched_c_below_candidate_wf_range"] for c in cohorts
            ),
            "c_strictly_above_wf_b_both_cohorts": all(
                c["strict_matched_c_above_candidate_wf_range"] for c in cohorts
            ),
            "wf_b_strictly_below_wf_a_both_cohorts": all(
                c["strict_candidate_below_control_range"] for c in cohorts
            ),
            "wf_b_below_slower_original_peer_both_cohorts": all(
                c["strict_candidate_below_slower_peer_range"] for c in cohorts
            ),
        }
        cells.append(
            {
                "element_bytes": cell["element_bytes"],
                "series": cell["series"],
                "entry_floor": cell["entry_floor"],
                "admitted": cell["all_participants_admitted"],
                "flags": flags,
                "cohort_median_ns_per_insertion": {
                    name: participants[name]["cohort_median_ns_per_insertion"]
                    for name in (
                        "control:whitefoot-hash-map",
                        "candidate:whitefoot-hash-map",
                        "candidate:matched-c-sparse",
                        "candidate:rust-hash-map",
                        "candidate:cpp-unordered-map",
                    )
                },
                "inherited_qualified_candidate_gain_is_combined_wf_and_peer_target": cell[
                    "qualified_candidate_gain"
                ],
            }
        )
    result = {
        "source": str(source),
        "source_sha256": hashlib.sha256(raw).hexdigest(),
        "rule": "criterion.txt: strict max(C 12 real ns/op) < min(WF 12) in both cohorts; separate A and B",
        "cells": cells,
        "counts": {
            name: sum(cell["flags"][name] for cell in cells)
            for name in cells[0]["flags"]
        },
        "admitted_counts": {
            name: sum(cell["admitted"] and cell["flags"][name] for cell in cells)
            for name in cells[0]["flags"]
        },
        "four_scalar_c_below_wf_b": all(
            c["flags"]["c_strictly_below_wf_b_both_cohorts"]
            for c in cells
            if c["element_bytes"] == 8
        ),
    }
    (campaign / "supplemental-attribution.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps(result["counts"], sort_keys=True))


if __name__ == "__main__":
    main()
