/* Untimed, sequential observer for probe-order.wf. Expected callback traces
 * follow the fixture's explicit key lists, not either library implementation.
 * This instrumentation is not an implementation of a read-only WF callback.
 * Keep with the two-span experiment; retire with its scratch/replay evidence. */
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern int wf_fixture_main(int argc, char **argv);
enum { MAX_EVENTS = 8192, MAX_ALLOCATIONS = 64 };
typedef struct {
    uint64_t capacity, phase, kind, left, right;
} Event;
typedef struct {
    void *pointer;
    uint64_t bytes;
    bool released;
} Allocation;
static Event expected[MAX_EVENTS];
static size_t expected_count, observed_count;
static Allocation allocations[MAX_ALLOCATIONS];
static uint64_t sizes[MAX_ALLOCATIONS];
static size_t release_order[MAX_ALLOCATIONS];
static size_t expected_allocations, expected_releases, allocated, released;
static uint64_t live_bytes, total_bytes, peak_bytes;

static void require(bool condition, const char *message) {
    if (!condition) {
        fprintf(stderr, "two-span observer: %s\n", message);
        exit(1);
    }
}

static void append(uint64_t capacity, uint64_t phase, uint64_t kind,
                   uint64_t left, uint64_t right) {
    require(expected_count < MAX_EVENTS, "expected trace capacity");
    expected[expected_count++] = (Event){capacity, phase, kind, left, right};
}

static void hash_event(uint64_t capacity, uint64_t phase, uint64_t query) {
    append(capacity, phase, 0, query, 0);
}

static void equal_event(uint64_t capacity, uint64_t phase,
                        uint64_t stored, uint64_t query) {
    append(capacity, phase, 1, stored, query);
}

static uint64_t final_key(uint64_t ordinal) {
    return ordinal == 0 ? 900 : ordinal == 1 ? 101 :
           ordinal == 2 ? 901 : 100 + ordinal;
}

static void original_scan(uint64_t capacity, uint64_t phase, uint64_t query,
                          uint64_t entries) {
    hash_event(capacity, phase, query);
    for (uint64_t index = 0; index < entries; ++index)
        equal_event(capacity, phase, 100 + index, query);
}

static void final_scan(uint64_t capacity, uint64_t phase, uint64_t query) {
    hash_event(capacity, phase, query);
    for (uint64_t index = 0; index < capacity; ++index)
        equal_event(capacity, phase, final_key(index), query);
}

static void build_expected(void) {
    for (uint64_t capacity = 0; capacity <= 17; ++capacity) {
        sizes[expected_allocations++] = 16 + 24 * capacity;
        if (capacity != 0)
            sizes[expected_allocations++] = 16 + 24 * capacity;
        /* Rehash releases the original backing; final cleanup releases the
         * new one. For C=0 only construction and final cleanup allocate/free. */
        while (expected_releases < expected_allocations) {
            release_order[expected_releases] = expected_releases;
            ++expected_releases;
        }
        for (uint64_t index = 0; index < capacity; ++index)
            original_scan(capacity, 0, 100 + index, index);
        original_scan(capacity, 1, 9999, capacity);
        original_scan(capacity, 2, 100, capacity < 2 ? capacity : 2);
        original_scan(capacity, 3, 9999, capacity == 0 ? 0 : 1);
        original_scan(capacity, 4, 9999, capacity == 0 ? 0 : 1);
        original_scan(capacity, 5, 9999, capacity);
        if (capacity != 0) original_scan(capacity, 6, 9999, 1);
        if (capacity > 1) {
            hash_event(capacity, 7, 101);
            equal_event(capacity, 7, 101, 101);
        }
        if (capacity > 2) {
            hash_event(capacity, 8, 102);
            equal_event(capacity, 8, 101, 102);
            equal_event(capacity, 8, 102, 102);
        }
        hash_event(capacity, 9, 900);
        if (capacity > 1) equal_event(capacity, 9, 101, 900);
        for (uint64_t index = 3; index < capacity; ++index)
            equal_event(capacity, 9, 100 + index, 900);
        hash_event(capacity, 10, 9999);
        if (capacity != 0) equal_event(capacity, 10, 900, 9999);
        if (capacity > 2) {
            hash_event(capacity, 11, 901);
            equal_event(capacity, 11, 900, 901);
            equal_event(capacity, 11, 101, 901);
            for (uint64_t index = 3; index < capacity; ++index)
                equal_event(capacity, 11, 100 + index, 901);
        }
        final_scan(capacity, 12, 100);
        final_scan(capacity, 13, 100);
        final_scan(capacity, 14, 9999);
        /* Physical slots descend during migration. With home=C-1, that
         * sequence is first inserted key, then the remaining keys reversed.
         * Migration must never call equality, even under mode 3. */
        if (capacity != 0) hash_event(capacity, 15, 900);
        for (uint64_t index = capacity; index > 1; --index)
            hash_event(capacity, 15, final_key(index - 1));
        hash_event(capacity, 16, 9999);
        if (capacity != 0) equal_event(capacity, 16, 900, 9999);
        for (uint64_t index = capacity; index > 1; --index)
            equal_event(capacity, 16, final_key(index - 1), 9999);
    }
    require(expected_allocations == 35 && expected_releases == 35,
            "independent allocation cardinality");
}

static void observe(uint64_t capacity, uint64_t phase, uint64_t kind,
                    uint64_t left, uint64_t right) {
    require(observed_count < expected_count, "unexpected callback count");
    Event want = expected[observed_count++];
    if (want.capacity != capacity || want.phase != phase || want.kind != kind ||
        want.left != left || want.right != right) {
        fprintf(stderr, "two-span observer: callback at %zu expected "
                "C=%" PRIu64 " phase=%" PRIu64 " kind=%" PRIu64
                " left=%" PRIu64 " right=%" PRIu64 " observed "
                "C=%" PRIu64 " phase=%" PRIu64 " kind=%" PRIu64
                " left=%" PRIu64 " right=%" PRIu64 "\n",
                observed_count - 1, want.capacity, want.phase, want.kind,
                want.left, want.right, capacity, phase, kind, left, right);
        exit(1);
    }
}

void wf_span_hash_observe(const uint64_t *env, const uint64_t *key) {
    observe(env[0], env[3], 0, *key, 0);
}

void wf_span_equal_observe(const uint64_t *env, const uint64_t *left,
                          const uint64_t *right) {
    observe(env[0], env[3], 1, *left, *right);
}

void *wf_observe_allocate(uint64_t bytes) {
    require(allocated < expected_allocations, "unexpected allocation count");
    require(bytes == sizes[allocated], "exact allocation extent");
    void *pointer = malloc(bytes == 0 ? 1 : (size_t)bytes);
    require(pointer != NULL, "host allocation failed");
    memset(pointer, 0xcc, bytes == 0 ? 1 : (size_t)bytes);
    allocations[allocated++] = (Allocation){pointer, bytes, false};
    total_bytes += bytes;
    live_bytes += bytes;
    if (live_bytes > peak_bytes) peak_bytes = live_bytes;
    return pointer;
}

void wf_observe_release(void *pointer) {
    require(released < expected_releases, "unexpected release count");
    size_t identity = release_order[released];
    require(identity < allocated, "release before allocation");
    Allocation *allocation = &allocations[identity];
    require(pointer == allocation->pointer, "exact release identity/order");
    require(!allocation->released, "duplicate release");
    require(live_bytes >= allocation->bytes, "release byte balance");
    live_bytes -= allocation->bytes;
    allocation->released = true;
    memset(pointer, 0xa5, (size_t)allocation->bytes);
    ++released;
    /* Delay host free solely to prevent pointer reuse in this identity oracle.
     * Peak above is requested live bytes, not observer-process RSS. */
}

static void corrupt_expected(const char *fault) {
    if (strcmp(fault, "wrong-allocation-size") == 0) {
        ++sizes[0];
        return;
    }
    if (strcmp(fault, "wrong-release-order") == 0) {
        release_order[1] = 2;
        release_order[2] = 1;
        return;
    }
    for (size_t index = 0; index + 1 < expected_count; ++index) {
        Event *event = &expected[index];
        if (strcmp(fault, "wrong-hash-count") == 0 &&
            event->capacity == 0 && event->phase == 1) {
            require(expected_count + 1 < MAX_EVENTS, "fault trace capacity");
            memmove(event + 1, event, (expected_count - index) * sizeof *event);
            ++expected_count;
            return;
        }
        if (event->capacity != 3 || event->phase != 1 || event->kind != 1)
            continue;
        if (strcmp(fault, "wrong-order") == 0) {
            Event temporary = *event;
            *event = expected[index + 1];
            expected[index + 1] = temporary;
            return;
        }
        if (strcmp(fault, "wrong-count") == 0) {
            memmove(event, event + 1, (expected_count - index - 1) * sizeof *event);
            --expected_count;
            return;
        }
    }
    require(false, "unknown observer fault");
}

int main(int argc, char **argv) {
    build_expected();
    if (argc == 2) corrupt_expected(argv[1]);
    else require(argc == 1, "observer arguments");
    require(wf_fixture_main(0, NULL) == 0, "source semantic witness");
    require(observed_count == expected_count, "missing callback count");
    require(allocated == 35 && released == 35 && total_bytes == 7904 &&
            live_bytes == 0 && peak_bytes == 848, "exact final allocation ledger");
    for (size_t index = 0; index < allocated; ++index) {
        require(allocations[index].released, "missing allocation release");
        free(allocations[index].pointer);
    }
    printf("two-span observer: %zu exact callback events; 35 allocations, "
           "7904 requested bytes, 848 peak bytes, zero live bytes\n", observed_count);
    return 0;
}
