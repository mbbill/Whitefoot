"""Compiler-independent finite and maximal-boundary oracle for two-span order.
Uses mathematical integers for the reference modulo, never a native wrapping
sum. This is not WF admission or runtime evidence. Run only in an authorized
guarded stage; preserve outcomes with the source-factor experiment.
"""
import itertools
import sys

fault = sys.argv[1] if len(sys.argv) == 2 else "none"
assert fault in {"none", "omit-suffix-end", "omit-prefix-zero", "reverse-prefix"}
cases = 0
for capacity in range(66):
    for home in range(capacity):
        first = range(home, capacity - (fault == "omit-suffix-end"))
        second = range(1 if fault == "omit-prefix-zero" else 0, home)
        if fault == "reverse-prefix":
            second = reversed(second)
        actual = list(itertools.chain(first, second))
        expected = [(home + step) % capacity for step in range(capacity)]
        assert actual == expected, (fault, capacity, home, actual, expected)
        assert len(actual) == capacity and len(set(actual)) == capacity
        cases += 1

maximum = (1 << 64) - 1
boundaries = [1, 2, 3, 7, 8, 9, 15, 16, 17, maximum // 2,
              maximum // 2 + 1, maximum - 1, maximum]
checked = 0
for capacity in boundaries:
    homes = {0, capacity - 1, capacity // 2}
    if capacity > 1:
        homes.add(1)
        homes.add(capacity - 2)
    for home in homes:
        first_length = capacity - home
        assert 0 <= home < capacity <= maximum
        assert 0 <= first_length <= maximum
        assert first_length + home == capacity
        steps = {0, capacity - 1, first_length - 1}
        if first_length < capacity:
            steps.add(first_length)
        for step in steps:
            if step < first_length:
                index = home + step
                assert index < capacity
            else:
                index = step - first_length
                assert index < home
            assert 0 <= index < capacity <= maximum
            assert index == (home + step) % capacity
            checked += 1
print(f"two-span arithmetic: {cases} complete small sequences and {checked} maximal-boundary positions")
