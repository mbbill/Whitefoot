"""One-shot untimed observation adapter for the two-span semantic witness.
Adds entry observers to the two named witness callbacks and interposes heap
accounting; never transform the practical timing/native-gate module with it.
Delete with this scratch trial or preserve with its eventual replay evidence.
"""
from pathlib import Path
import hashlib
import json
import re
import sys

source, destination = map(Path, sys.argv[1:])
assert not destination.exists(), destination
text = source.read_text()
original = text
assert text.count("define i32 @main(") == 1
assert "@malloc(" in text and "@free(" in text
for name, result, count in [("span_hash", "i64", 2), ("span_equal", "i1", 3)]:
    pattern = re.compile(
        rf"(^define {result} @wf_{name}\(([^\n]*)\)[^\n]*\{{\nentry:\n)", re.M
    )
    matches = list(pattern.finditer(text))
    assert len(matches) == 1, (name, len(matches))
    match = matches[0]
    args = re.findall(r"ptr[^,]* (%v\d+)(?:,|$)", match.group(2))
    assert len(args) == count, (name, args, match.group(2))
    call = "  call void @wf_" + name + "_observe(" + ", ".join("ptr " + arg for arg in args) + ")\n"
    text = text[:match.end()] + call + text[match.end():]
text = text.replace("@malloc(", "@wf_observe_allocate(")
text = text.replace("@free(", "@wf_observe_release(")
text = text.replace("@main(", "@wf_fixture_main(")
text += "\ndeclare void @wf_span_hash_observe(ptr, ptr)\n"
text += "declare void @wf_span_equal_observe(ptr, ptr, ptr)\n"
destination.write_text(text)
record = {
    "source": str(source),
    "source_sha256": hashlib.sha256(original.encode()).hexdigest(),
    "observed": str(destination),
    "observed_sha256": hashlib.sha256(text.encode()).hexdigest(),
    "qualification": "Untimed sequential instrumentation only: exact callback entry order and heap identity/extents. It is neither ordinary source callback mutation nor timed allocation/callback work.",
}
manifest = destination.with_suffix(destination.suffix + ".json")
assert not manifest.exists(), manifest
manifest.write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record))
