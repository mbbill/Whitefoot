"""One-shot guarded admission/native construction for the two-span experiment.

No generated program runs here. Preserve every attempt and its input bytes;
delete with this scratch experiment or retain with its final replay evidence.
"""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
worktree = Path('/private/tmp/whitefoot-container-library-complete')
reference = Path('/private/tmp/whitefoot-map-group-control-7abd6bb')
frozen = Path('/private/tmp/whitefoot-map-occupancy-7abd6bb')
cli = frozen / 'whitefootc'
mode, attempt = sys.argv[1:]
assert mode in {'admission', 'native'}
stage = root / attempt
stage.mkdir(exist_ok=False)
commands = []


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(name, value):
    path = stage / name
    assert not path.exists(), path
    path.write_text(json.dumps(value, indent=2) + '\n')


def run(label, command, expected=0):
    log = stage / (label + '.log')
    assert not log.exists(), log
    started = time.monotonic()
    with log.open('wb') as output:
        process = subprocess.run(command, cwd=worktree, stdout=output,
                                 stderr=subprocess.STDOUT, timeout=60)
    record = {'label': label, 'command': [str(x) for x in command],
              'direct_exit': process.returncode, 'expected_exit': expected,
              'wall_seconds': time.monotonic() - started,
              'log': str(log), 'log_sha256': digest(log)}
    commands.append(record)
    print(json.dumps(record), flush=True)
    if process.returncode != expected:
        print(log.read_text()[-12000:], flush=True)
        raise SystemExit(1)


def source_inputs():
    result = []
    for carrier in ['baseline', 'candidate']:
        result.extend((root / carrier).rglob('*'))
        for fixture in ['probe-order', 'owning', 'indexed', 'group-owning']:
            result.extend((root / (carrier + '-' + fixture)).glob('*'))
    result.extend(root.glob('*.py'))
    result.extend(root.glob('*.c'))
    result.extend(root.glob('*.wf'))
    result.extend(root.glob('*.txt'))
    result.extend(root.glob('*.patch'))
    result.append(root / 'preparation.json')
    return sorted(set(path for path in result if path.is_file()))


inputs = source_inputs()
before = {str(path): digest(path) for path in inputs}
snapshot = stage / 'inputs'
for path in inputs:
    target = snapshot / path.relative_to(root)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, target)
identities = {
    'observed_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'],
                                              cwd=worktree, text=True).strip(),
    'source_pin': '7abd6bb34746b7b983b83103c68ee429b24859bb',
    'compiler': {'path': str(cli), 'sha256': digest(cli)},
    'sources': before,
    'stage': mode,
    'guard_owner': os.environ.get('WHITEFOOT_CHECK_OWNER'),
    'qualification': 'No generated program execution or timing in this stage.',
}
assert identities['compiler']['sha256'] == '5753999f224f89a9a99e0399b76bfd7b92cd53d5f22b0d204df4f2ec3ffbc20b'
if mode == 'native':
    clang = Path('/usr/bin/clang').resolve()
    identities['clang'] = {'path': str(clang), 'sha256': digest(clang),
                          'version': subprocess.check_output(
                              [str(clang), '--version'], text=True)}
    identities['references'] = {
        str(path): digest(path) for path in [
            frozen / 'build/ecosystem/map.raw.ll',
            reference / 'native/original.s',
            reference / 'qualify-carrier.py',
        ]
    }
write_json('identities-before.json', identities)
outcome = 'incomplete'
try:
    if mode == 'admission':
        for carrier in ['baseline', 'candidate']:
            graphs = [carrier] + [carrier + '-' + fixture for fixture in
                                  ['probe-order', 'owning', 'indexed', 'group-owning']]
            for graph in graphs:
                run(graph, [str(cli), '--check', '--graph',
                            str(root / graph / 'modules.wfg'), '--entry', 'main'])
        run('arithmetic', ['python3', str(root / 'probe-arithmetic.py')])
        for fault in ['omit-suffix-end', 'omit-prefix-zero', 'reverse-prefix']:
            run('arithmetic-' + fault,
                ['python3', str(root / 'probe-arithmetic.py'), fault], expected=1)
    else:
        native = stage / 'native'
        native.mkdir()
        for carrier in ['baseline', 'candidate']:
            raw = native / (carrier + '.raw.ll')
            run(carrier + '-emit', [str(cli), '--emit-llvm', '--graph',
                str(root / carrier / 'modules.wfg'), '--entry', 'main', '-o', str(raw)])
        run('baseline-raw-qualification', ['python3', str(reference / 'qualify-carrier.py'),
            str(frozen / 'build/ecosystem/map.raw.ll'), str(native / 'baseline.raw.ll'),
            str(native / 'baseline-raw-qualification.json')])
        shutil.copyfile(reference / 'native/original.s', native / 'original.s')
        for carrier in ['baseline', 'candidate']:
            raw = native / (carrier + '.raw.ll')
            source = raw.read_text()
            assert source.count('define i32 @main(') == 1
            timed = native / (carrier + '-timed.ll')
            timed.write_text(source.replace('@main(', '@wf_fixture_main('))
            run(carrier + '-native', ['/usr/bin/clang', '-O3', '-Wno-override-module',
                                     '-S', str(timed), '-o', str(native / (carrier + '.s'))])
        run('baseline-native-qualification', ['python3', str(root / 'qualify-native.py'),
                                              str(native)])
        write_json('generated-artifacts.json', {
            str(path): digest(path) for path in sorted(native.glob('*')) if path.is_file()
        })
    outcome = 'pass'
finally:
    after = {str(path): digest(path) for path in inputs}
    write_json('identities-after.json', after)
    unchanged = before == after and digest(cli) == identities['compiler']['sha256']
    if mode == 'native':
        unchanged = unchanged and digest(clang) == identities['clang']['sha256']
        unchanged = unchanged and all(digest(Path(path)) == value for path, value in
                                      identities['references'].items())
    write_json('report.json', {'outcome': outcome, 'commands': commands,
                              'inputs_unchanged': unchanged,
                              'generated_programs_executed': False})
    assert unchanged, 'frozen input changed during stage'
