from pathlib import Path
import hashlib,json,subprocess,time
root=Path(__file__).resolve().parent
output=root/'run-1'
output.mkdir(exist_ok=False)
cli=Path('/private/tmp/whitefoot-map-occupancy-7abd6bb/whitefootc')
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(cli)=='5753999f224f89a9a99e0399b76bfd7b92cd53d5f22b0d204df4f2ec3ffbc20b'
records=[]
for name in ['zero','positive','zero-no-header']:
    files=sorted((root/name).glob('*'))
    before={str(p):digest(p) for p in files}
    argv=[str(cli),'--check','--graph',str(root/name/'modules.wfg'),'--entry','main']
    started=time.monotonic()
    result=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=10)
    log=output/(name+'.log');log.write_bytes(result.stdout)
    after={str(p):digest(p) for p in files}
    assert before==after
    record={'name':name,'argv':argv,'direct_exit':result.returncode,'wall_seconds':time.monotonic()-started,'input_hashes':before,'output_sha256':digest(log),'output':result.stdout.decode()}
    records.append(record)
    print(json.dumps(record),flush=True)
(output/'report.json').write_text(json.dumps({'compiler_sha256':digest(cli),'commands':records,'generated_programs_executed':False},indent=2)+'\n')
assert all(r['direct_exit']==0 for r in records if r['name']!='zero')
