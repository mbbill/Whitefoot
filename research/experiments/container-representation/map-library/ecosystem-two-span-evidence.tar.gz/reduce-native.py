"""Correct the unused zero fields and return omission in the private reduction.

This one-shot compiler-independent reading serves the rejected two-span source
factor. It is frozen with its evidence; it is not a compiler or timing harness.
Original reductions and all compiler output remain available byte for byte.
"""
from pathlib import Path
import copy
import hashlib
import json
import re

root = Path(__file__).resolve().parent
native = root / 'native-1/native'
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
original = root / 'original-reductions'
inventory = json.loads((original / 'candidate-native-inventory.json').read_text())
screen = json.loads((original / 'native-screen.json').read_text())
pattern = re.compile(r'^[^\n]*; -- Begin function (\S+)\n.*?^\s*; -- End function[^\n]*\n', re.M | re.S)
parsed = {}
for variant in ['baseline', 'candidate']:
    parsed[variant] = {}
    for match in pattern.finditer((native / (variant + '.s')).read_text()):
        instructions = []
        for line in match.group().splitlines():
            line = line.split(';', 1)[0].strip()
            if line and re.fullmatch(r'[a-z][a-z0-9.]*', line.split()[0]):
                instructions.append(line)
        parsed[variant][match.group(1)] = instructions

totals = {'baseline': 0, 'candidate': 0}
returns = {'baseline': 0, 'candidate': 0}
by_name = {}
for row in inventory['functions']:
    by_name[row['name']] = row
    for variant in ['baseline', 'candidate']:
        if variant not in row:
            assert row['name'] not in parsed[variant]
            continue
        metrics = row[variant]
        instructions = parsed[variant][row['name']]
        return_count = sum(line == 'ret' for line in instructions)
        assert metrics['instructions'] + return_count == len(instructions)
        assert metrics.pop('loads') == 0
        assert metrics.pop('stores') == 0
        metrics['instructions'] = len(instructions)
        metrics['instruction_bytes'] = 4 * len(instructions)
        totals[variant] += len(instructions)
        returns[variant] += return_count
    if row['status'] == 'removed':
        assert row['name'] == 'wf_hash_map.hash_map_probe'

assert [len(parsed[x]) for x in totals] == [110, 109]
assert totals == {'baseline': 8480, 'candidate': 8524}
assert returns == {'baseline': 137, 'candidate': 141}
correction = {
    'original_inventory_sha256': digest(original / 'candidate-native-inventory.json'),
    'original_screen_sha256': digest(original / 'native-screen.json'),
    'reducer_sha256': digest(Path(__file__)),
    'limitation': 'The original private reduction omitted operand-free ret instructions and emitted invalid unused zero load/store fields. Corrected counts include every ret; invalid fields are removed, not treated as zero traffic. Raw compiler output and all call/body-equality/frame conclusions are unchanged.',
    'return_instructions': returns,
}
inventory['publication_correction'] = correction
inventory['qualification'] = 'All emitted native functions inventoried. Instruction bytes include ret and exclude alignment/constant pools; they are not linked image size. max_cfa_offset records CFI only and is not necessarily a complete physical frame. No load/store totals or timing attribution are claimed.'
(native / 'candidate-native-inventory.json').write_text(json.dumps(inventory, indent=2) + '\n')

for row in screen['changed_function_details']:
    corrected = by_name[row['name']]
    for variant in ['baseline', 'candidate']:
        if variant in row:
            frames = {key: value for key, value in row[variant].items() if key.startswith('prologue_')}
            row[variant] = copy.deepcopy(corrected[variant])
            row[variant].update(frames)
screen['instruction_text'].update({
    'baseline_instructions': totals['baseline'],
    'candidate_instructions': totals['candidate'],
    'baseline_unpadded_instruction_bytes': 4 * totals['baseline'],
    'candidate_unpadded_instruction_bytes': 4 * totals['candidate'],
})
screen['publication_correction'] = correction
screen['complete_native_inventory']['sha256'] = digest(native / 'candidate-native-inventory.json')
screen['invariant_rejection'] = {
    'status': 'Unresolved frozen-compiler diagnosis, localized to a zero-ceiling Map instantiation; no compiler-defect or language-verdict claim.',
    'run3': {'path': str(root / 'invariant-isolation/run-3/report.json'), 'sha256': digest(root / 'invariant-isolation/run-3/report.json')},
    'observations': 'The standalone Map caller with ceiling 0 rejects home >= 0_u64 at its migration backedge. Otherwise identical ceilings 8 and 17 admit, as do original ordered-invariant forms at 8 and 17 and the nested Slots loop. Run1 tiny loops all admit. Run2 main-only caller selection retained all definitions and did not discriminate their cause.',
    'rules_to_classify': ['ENT-2', 'INV-1'],
    'generated_programs_executed': False,
}
(root / 'native-screen.json').write_text(json.dumps(screen, indent=2) + '\n')
print(json.dumps({'instruction_totals': totals, 'return_totals': returns, 'inventory_sha256': digest(native / 'candidate-native-inventory.json'), 'screen_sha256': digest(root / 'native-screen.json')}))
