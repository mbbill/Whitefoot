	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function wf_resource_record_abort
l_wf_resource_record_abort:             ; @wf_resource_record_abort
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
Lloh0:
	adrp	x19, l_.wf_resource.heap@PAGE
Lloh1:
	add	x19, x19, l_.wf_resource.heap@PAGEOFF
	mov	w20, #20                        ; =0x14
	mov	w0, #2                          ; =0x2
	mov	x1, x19
	mov	x2, x20
	bl	_write
	tbz	x0, #63, LBB0_3
LBB0_1:                                 ; %error.i
                                        ; =>This Inner Loop Header: Depth=1
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #4
	b.ne	LBB0_6
; %bb.2:                                ; %write.i
                                        ;   in Loop: Header=BB0_1 Depth=1
	mov	w0, #2                          ; =0x2
	mov	x1, x19
	mov	x2, x20
	bl	_write
	tbnz	x0, #63, LBB0_1
LBB0_3:                                 ; %wf_resource_write.exit
                                        ; =>This Inner Loop Header: Depth=1
	subs	x20, x20, x0
	b.eq	LBB0_6
; %bb.4:                                ; %wf_resource_write.exit
                                        ;   in Loop: Header=BB0_3 Depth=1
	cbz	x0, LBB0_6
; %bb.5:                                ; %write.more
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x19, x19, x0
	mov	w0, #2                          ; =0x2
	mov	x1, x19
	mov	x2, x20
	bl	_write
	tbnz	x0, #63, LBB0_1
	b	LBB0_3
LBB0_6:                                 ; %abort
	bl	_abort
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_resource_abort
l_wf_resource_abort:                    ; @wf_resource_abort
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	l_wf_resource_record_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_carrier_main                ; -- Begin function wf_carrier_main
	.p2align	2
_wf_carrier_main:                       ; @wf_carrier_main
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w0, #3                          ; =0x3
	mov	w1, #2                          ; =0x2
	mov	w2, #2                          ; =0x2
	mov	w3, #17                         ; =0x11
	mov	x5, #0                          ; =0x0
	mov	w4, #7                          ; =0x7
	bl	_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd
	mov	w0, #3                          ; =0x3
	mov	w1, #2                          ; =0x2
	mov	w2, #2                          ; =0x2
	mov	w3, #17                         ; =0x11
	mov	w4, #3                          ; =0x3
	mov	w5, #1                          ; =0x1
	bl	_wf_map_cost_library_trace$instance$4250cb78d3f44027
	mov	x0, x19
	mov	w1, #0                          ; =0x0
	bl	_wf_std.process.exit_status
	mov	w0, #3                          ; =0x3
	mov	w1, #2                          ; =0x2
	mov	w2, #17                         ; =0x11
	bl	_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd
	mov	w0, #3                          ; =0x3
	mov	w1, #2                          ; =0x2
	mov	w2, #17                         ; =0x11
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_wf_map_cost_library_geometry$instance$4250cb78d3f44027
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_map_cost_mix                ; -- Begin function wf_map_cost_mix
	.p2align	2
_wf_map_cost_mix:                       ; @wf_map_cost_mix
; %bb.0:                                ; %entry
	eor	x8, x0, x0, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x0, x8, x8, lsr #31
	ret
                                        ; -- End function
	.globl	_wf_map_cost_hash               ; -- Begin function wf_map_cost_hash
	.p2align	2
_wf_map_cost_hash:                      ; @wf_map_cost_hash
; %bb.0:                                ; %entry
	ldrb	w8, [x0, #8]
	tbz	w8, #0, LBB4_2
; %bb.1:
	mov	x0, #0                          ; =0x0
	ret
LBB4_2:                                 ; %bb3
	ldr	x8, [x1]
	ldr	x9, [x0]
	eor	x8, x9, x8
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x0, x8, x8, lsr #31
	ret
                                        ; -- End function
	.globl	_wf_map_cost_equal              ; -- Begin function wf_map_cost_equal
	.p2align	2
_wf_map_cost_equal:                     ; @wf_map_cost_equal
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x2]
	cmp	x8, x9
	cset	w0, eq
	ret
                                        ; -- End function
	.globl	_wf_map_cost_key                ; -- Begin function wf_map_cost_key
	.p2align	2
_wf_map_cost_key:                       ; @wf_map_cost_key
; %bb.0:                                ; %entry
	mov	w8, #1                          ; =0x1
	orr	x0, x8, x0, lsl #1
	ret
                                        ; -- End function
	.globl	_wf_map_cost_ordered            ; -- Begin function wf_map_cost_ordered
	.p2align	2
_wf_map_cost_ordered:                   ; @wf_map_cost_ordered
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	mov	w9, #131                        ; =0x83
	madd	x8, x8, x9, x1
	str	x8, [x0]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_map_cost_final              ; -- Begin function wf_map_cost_final
	.p2align	2
_wf_map_cost_final:                     ; @wf_map_cost_final
; %bb.0:                                ; %entry
	ldp	x8, x9, [x0, #8]
	add	x8, x8, x1
	eor	x10, x1, x1, lsr #30
	mov	x11, #58809                     ; =0xe5b9
	movk	x11, #7396, lsl #16
	movk	x11, #18285, lsl #32
	movk	x11, #48984, lsl #48
	mul	x10, x10, x11
	eor	x10, x10, x10, lsr #27
	mov	x11, #4587                      ; =0x11eb
	movk	x11, #4913, lsl #16
	movk	x11, #18875, lsl #32
	movk	x11, #38096, lsl #48
	mul	x10, x10, x11
	eor	x9, x9, x10, lsr #31
	eor	x9, x9, x10
	stp	x8, x9, [x0, #8]
	ldr	x8, [x0, #24]
	add	x8, x8, #1
	str	x8, [x0, #24]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_map_cost_finish             ; -- Begin function wf_map_cost_finish
	.p2align	2
_wf_map_cost_finish:                    ; @wf_map_cost_finish
; %bb.0:                                ; %entry
	ldp	x8, x9, [x0]
	ldp	x10, x11, [x0, #16]
	eor	x8, x8, x8, lsr #30
	mov	x12, #58809                     ; =0xe5b9
	movk	x12, #7396, lsl #16
	movk	x12, #18285, lsl #32
	movk	x12, #48984, lsl #48
	mul	x8, x8, x12
	eor	x8, x8, x8, lsr #27
	mov	x13, #4587                      ; =0x11eb
	movk	x13, #4913, lsl #16
	movk	x13, #18875, lsl #32
	movk	x13, #38096, lsl #48
	mul	x8, x8, x13
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x12
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x13
	eor	x12, x9, x8
	mov	x13, #31765                     ; =0x7c15
	movk	x13, #32586, lsl #16
	movk	x13, #31161, lsl #32
	movk	x13, #40503, lsl #48
	mul	x11, x11, x13
	eor	x10, x10, x11
	eor	x10, x10, x12, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	ret
                                        ; -- End function
	.globl	_wf_map_cost_word_make          ; -- Begin function wf_map_cost_word_make
	.p2align	2
_wf_map_cost_word_make:                 ; @wf_map_cost_word_make
; %bb.0:                                ; %entry
	ret
                                        ; -- End function
	.globl	_wf_map_cost_word_content       ; -- Begin function wf_map_cost_word_content
	.p2align	2
_wf_map_cost_word_content:              ; @wf_map_cost_word_content
; %bb.0:                                ; %entry
	mov	w8, #131                        ; =0x83
	madd	x0, x0, x8, x1
	ret
                                        ; -- End function
	.globl	_wf_map_cost_word_observe       ; -- Begin function wf_map_cost_word_observe
	.p2align	2
_wf_map_cost_word_observe:              ; @wf_map_cost_word_observe
; %bb.0:                                ; %entry
	ldr	x0, [x2]
	ret
                                        ; -- End function
	.globl	_wf_map_cost_word_edit          ; -- Begin function wf_map_cost_word_edit
	.p2align	2
_wf_map_cost_word_edit:                 ; @wf_map_cost_word_edit
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	add	x0, x8, #1
	str	x0, [x2]
	ret
                                        ; -- End function
	.globl	_wf_map_cost_word_consume       ; -- Begin function wf_map_cost_word_consume
	.p2align	2
_wf_map_cost_word_consume:              ; @wf_map_cost_word_consume
; %bb.0:                                ; %entry
	mov	w8, #131                        ; =0x83
	madd	x8, x1, x8, x2
	ldp	x9, x10, [x0, #8]
	add	x9, x9, x8
	eor	x8, x8, x8, lsr #30
	mov	x11, #58809                     ; =0xe5b9
	movk	x11, #7396, lsl #16
	movk	x11, #18285, lsl #32
	movk	x11, #48984, lsl #48
	mul	x8, x8, x11
	eor	x8, x8, x8, lsr #27
	mov	x11, #4587                      ; =0x11eb
	movk	x11, #4913, lsl #16
	movk	x11, #18875, lsl #32
	movk	x11, #38096, lsl #48
	mul	x8, x8, x11
	eor	x10, x10, x8, lsr #31
	eor	x8, x10, x8
	stp	x9, x8, [x0, #8]
	ldr	x8, [x0, #24]
	add	x8, x8, #1
	str	x8, [x0, #24]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_map_cost_record_make
lCPI15_0:
	.quad	1                               ; 0x1
	.quad	2                               ; 0x2
lCPI15_1:
	.quad	3                               ; 0x3
	.quad	4                               ; 0x4
lCPI15_2:
	.quad	5                               ; 0x5
	.quad	6                               ; 0x6
lCPI15_3:
	.quad	7                               ; 0x7
	.quad	8                               ; 0x8
lCPI15_4:
	.quad	9                               ; 0x9
	.quad	10                              ; 0xa
lCPI15_5:
	.quad	11                              ; 0xb
	.quad	12                              ; 0xc
lCPI15_6:
	.quad	13                              ; 0xd
	.quad	14                              ; 0xe
lCPI15_7:
	.quad	15                              ; 0xf
	.quad	16                              ; 0x10
lCPI15_8:
	.quad	17                              ; 0x11
	.quad	18                              ; 0x12
lCPI15_9:
	.quad	19                              ; 0x13
	.quad	20                              ; 0x14
lCPI15_10:
	.quad	21                              ; 0x15
	.quad	22                              ; 0x16
lCPI15_11:
	.quad	23                              ; 0x17
	.quad	24                              ; 0x18
lCPI15_12:
	.quad	25                              ; 0x19
	.quad	26                              ; 0x1a
lCPI15_13:
	.quad	27                              ; 0x1b
	.quad	28                              ; 0x1c
lCPI15_14:
	.quad	29                              ; 0x1d
	.quad	30                              ; 0x1e
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_map_cost_record_make
	.p2align	2
_wf_map_cost_record_make:               ; @wf_map_cost_record_make
; %bb.0:                                ; %entry
	dup.2d	v0, x1
Lloh2:
	adrp	x8, lCPI15_0@PAGE
Lloh3:
	ldr	q1, [x8, lCPI15_0@PAGEOFF]
Lloh4:
	adrp	x8, lCPI15_1@PAGE
Lloh5:
	ldr	q2, [x8, lCPI15_1@PAGEOFF]
	add.2d	v1, v0, v1
Lloh6:
	adrp	x8, lCPI15_2@PAGE
Lloh7:
	ldr	q3, [x8, lCPI15_2@PAGEOFF]
	add.2d	v2, v0, v2
Lloh8:
	adrp	x8, lCPI15_3@PAGE
Lloh9:
	ldr	q4, [x8, lCPI15_3@PAGEOFF]
	add.2d	v3, v0, v3
Lloh10:
	adrp	x8, lCPI15_4@PAGE
Lloh11:
	ldr	q5, [x8, lCPI15_4@PAGEOFF]
	add.2d	v4, v0, v4
Lloh12:
	adrp	x8, lCPI15_5@PAGE
Lloh13:
	ldr	q6, [x8, lCPI15_5@PAGEOFF]
	add.2d	v5, v0, v5
Lloh14:
	adrp	x8, lCPI15_6@PAGE
Lloh15:
	ldr	q7, [x8, lCPI15_6@PAGEOFF]
	add.2d	v6, v0, v6
Lloh16:
	adrp	x8, lCPI15_7@PAGE
Lloh17:
	ldr	q16, [x8, lCPI15_7@PAGEOFF]
	add.2d	v7, v0, v7
Lloh18:
	adrp	x8, lCPI15_8@PAGE
Lloh19:
	ldr	q17, [x8, lCPI15_8@PAGEOFF]
	add.2d	v16, v0, v16
Lloh20:
	adrp	x8, lCPI15_9@PAGE
Lloh21:
	ldr	q18, [x8, lCPI15_9@PAGEOFF]
	add.2d	v17, v0, v17
Lloh22:
	adrp	x8, lCPI15_10@PAGE
Lloh23:
	ldr	q19, [x8, lCPI15_10@PAGEOFF]
	add.2d	v18, v0, v18
Lloh24:
	adrp	x8, lCPI15_11@PAGE
Lloh25:
	ldr	q20, [x8, lCPI15_11@PAGEOFF]
	add.2d	v19, v0, v19
Lloh26:
	adrp	x8, lCPI15_12@PAGE
Lloh27:
	ldr	q21, [x8, lCPI15_12@PAGEOFF]
	add.2d	v20, v0, v20
Lloh28:
	adrp	x8, lCPI15_13@PAGE
Lloh29:
	ldr	q22, [x8, lCPI15_13@PAGEOFF]
	add.2d	v21, v0, v21
Lloh30:
	adrp	x8, lCPI15_14@PAGE
Lloh31:
	ldr	q23, [x8, lCPI15_14@PAGEOFF]
	add.2d	v22, v0, v22
	add.2d	v0, v0, v23
	str	x1, [x0]
	add	x8, x1, #31
	stur	q1, [x0, #8]
	stur	q2, [x0, #24]
	stur	q3, [x0, #40]
	stur	q4, [x0, #56]
	stur	q5, [x0, #72]
	stur	q6, [x0, #88]
	stur	q7, [x0, #104]
	stur	q16, [x0, #120]
	stur	q17, [x0, #136]
	stur	q18, [x0, #152]
	stur	q19, [x0, #168]
	stur	q20, [x0, #184]
	stur	q21, [x0, #200]
	stur	q22, [x0, #216]
	stur	q0, [x0, #232]
	str	x8, [x0, #248]
	ret
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdrp	Lloh28, Lloh30
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
                                        ; -- End function
	.globl	_wf_map_cost_record_content     ; -- Begin function wf_map_cost_record_content
	.p2align	2
_wf_map_cost_record_content:            ; @wf_map_cost_record_content
; %bb.0:                                ; %entry
	ldp	x9, x10, [x1]
	mov	w8, #131                        ; =0x83
	madd	x9, x0, x8, x9
	madd	x9, x9, x8, x10
	ldp	x10, x11, [x1, #16]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #32]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #48]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #64]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #80]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #96]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #112]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #128]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #144]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #160]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #176]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #192]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #208]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #224]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #240]
	madd	x9, x9, x8, x10
	madd	x0, x9, x8, x11
	ret
                                        ; -- End function
	.globl	_wf_map_cost_record_observe     ; -- Begin function wf_map_cost_record_observe
	.p2align	2
_wf_map_cost_record_observe:            ; @wf_map_cost_record_observe
; %bb.0:                                ; %entry
	ldr	x0, [x2]
	ret
                                        ; -- End function
	.globl	_wf_map_cost_record_edit        ; -- Begin function wf_map_cost_record_edit
	.p2align	2
_wf_map_cost_record_edit:               ; @wf_map_cost_record_edit
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	add	x0, x8, #1
	str	x0, [x2]
	ret
                                        ; -- End function
	.globl	_wf_map_cost_record_consume     ; -- Begin function wf_map_cost_record_consume
	.p2align	2
_wf_map_cost_record_consume:            ; @wf_map_cost_record_consume
; %bb.0:                                ; %entry
	ldp	x9, x10, [x2]
	mov	w8, #131                        ; =0x83
	madd	x9, x1, x8, x9
	madd	x9, x9, x8, x10
	ldp	x10, x11, [x2, #16]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #32]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #48]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #64]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #80]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #96]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #112]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #128]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #144]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #160]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #176]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #192]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #208]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #224]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #240]
	madd	x9, x9, x8, x10
	madd	x8, x9, x8, x11
	ldp	x9, x10, [x0, #8]
	add	x9, x8, x9
	eor	x8, x8, x8, lsr #30
	mov	x11, #58809                     ; =0xe5b9
	movk	x11, #7396, lsl #16
	movk	x11, #18285, lsl #32
	movk	x11, #48984, lsl #48
	mul	x8, x8, x11
	eor	x8, x8, x8, lsr #27
	mov	x11, #4587                      ; =0x11eb
	movk	x11, #4913, lsl #16
	movk	x11, #18875, lsl #32
	movk	x11, #38096, lsl #48
	mul	x8, x8, x11
	eor	x10, x10, x8, lsr #31
	eor	x8, x10, x8
	stp	x9, x8, [x0, #8]
	ldr	x8, [x0, #24]
	add	x8, x8, #1
	str	x8, [x0, #24]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_map_cost_lookup_result      ; -- Begin function wf_map_cost_lookup_result
	.p2align	2
_wf_map_cost_lookup_result:             ; @wf_map_cost_lookup_result
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cbz	w8, LBB20_3
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB20_4
; %bb.2:                                ; %bb3
	ldr	x8, [x1]
	mov	w9, #131                        ; =0x83
	mul	x8, x8, x9
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
LBB20_3:                                ; %bb2
	ldr	x8, [x0, #8]
	ldr	x9, [x1]
	mov	w10, #17161                     ; =0x4309
	madd	x8, x9, x10, x8
	add	x8, x8, #131
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
LBB20_4:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_map_cost_rebuild_result     ; -- Begin function wf_map_cost_rebuild_result
	.p2align	2
_wf_map_cost_rebuild_result:            ; @wf_map_cost_rebuild_result
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cbz	w8, LBB21_3
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB21_4
; %bb.2:                                ; %bb3
	ldr	x8, [x1]
	mov	w9, #131                        ; =0x83
	mul	x8, x8, x9
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
LBB21_3:                                ; %bb2
	ldr	x8, [x1]
	mov	w9, #131                        ; =0x83
	mov	x10, #1                         ; =0x1
	madd	x8, x8, x9, x10
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
LBB21_4:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_map_cost_library_word_trace ; -- Begin function wf_map_cost_library_word_trace
	.p2align	2
_wf_map_cost_library_word_trace:        ; @wf_map_cost_library_word_trace
	.cfi_startproc
; %bb.0:                                ; %entry
	cmp	x4, #8
	b.ne	LBB22_2
; %bb.1:                                ; %bb2
	mov	x0, x3
	mov	x1, x5
	b	_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd
LBB22_2:                                ; %bb3
	b	_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_map_cost_library_record_trace ; -- Begin function wf_map_cost_library_record_trace
	.p2align	2
_wf_map_cost_library_record_trace:      ; @wf_map_cost_library_record_trace
	.cfi_startproc
; %bb.0:                                ; %entry
	cmp	x4, #8
	b.ne	LBB23_2
; %bb.1:                                ; %bb2
	mov	x0, x3
	mov	x1, x5
	b	_wf_map_cost_library_policy$instance$4250cb78d3f44027
LBB23_2:                                ; %bb3
	b	_wf_map_cost_library_trace$instance$4250cb78d3f44027
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_map_cost_library_word_geometry ; -- Begin function wf_map_cost_library_word_geometry
	.p2align	2
_wf_map_cost_library_word_geometry:     ; @wf_map_cost_library_word_geometry
	.cfi_startproc
; %bb.0:                                ; %entry
	b	_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_map_cost_library_record_geometry ; -- Begin function wf_map_cost_library_record_geometry
	.p2align	2
_wf_map_cost_library_record_geometry:   ; @wf_map_cost_library_record_geometry
	.cfi_startproc
; %bb.0:                                ; %entry
	b	_wf_map_cost_library_geometry$instance$4250cb78d3f44027
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_main                        ; -- Begin function wf_main
	.p2align	2
_wf_main:                               ; @wf_main
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w0, #3                          ; =0x3
	mov	w1, #2                          ; =0x2
	mov	w2, #2                          ; =0x2
	mov	w3, #17                         ; =0x11
	mov	x5, #0                          ; =0x0
	mov	w4, #7                          ; =0x7
	bl	_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd
	mov	w0, #3                          ; =0x3
	mov	w1, #2                          ; =0x2
	mov	w2, #2                          ; =0x2
	mov	w3, #17                         ; =0x11
	mov	w4, #3                          ; =0x3
	mov	w5, #1                          ; =0x1
	bl	_wf_map_cost_library_trace$instance$4250cb78d3f44027
	mov	x0, x19
	mov	w1, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_wf_std.process.exit_status
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_array_filled$instance$581665c886d1d2c8 ; -- Begin function wf_array_filled$instance$581665c886d1d2c8
	.p2align	2
_wf_array_filled$instance$581665c886d1d2c8: ; @"wf_array_filled$instance$581665c886d1d2c8"
; %bb.0:                                ; %entry
	dup.2d	v0, x1
	stp	q0, q0, [x0]
	stp	q0, q0, [x0, #32]
	stp	q0, q0, [x0, #64]
	stp	q0, q0, [x0, #96]
	stp	q0, q0, [x0, #128]
	stp	q0, q0, [x0, #160]
	stp	q0, q0, [x0, #192]
	stp	q0, q0, [x0, #224]
	ret
                                        ; -- End function
	.globl	_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd ; -- Begin function wf_map_cost_library_policy$instance$c7c8cd11e7f079bd
	.p2align	2
_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd: ; @"wf_map_cost_library_policy$instance$c7c8cd11e7f079bd"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #176
	stp	x24, x23, [sp, #112]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 176
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x0
	mov	x20, #31765                     ; =0x7c15
	movk	x20, #32586, lsl #16
	movk	x20, #31161, lsl #32
	movk	x20, #40503, lsl #48
	eor	x8, x0, x20
	cmp	x1, #0
	cset	w9, ne
	str	x8, [sp, #24]
	strb	w9, [sp, #32]
	mov	w0, #88                         ; =0x58
	bl	_malloc
	cbz	x0, LBB28_31
; %bb.1:                                ; %bb1.i.i.i
	str	wzr, [x0, #16]
	stp	xzr, xzr, [x0, #72]
	stp	xzr, xzr, [x0, #24]
	str	wzr, [x0, #40]
	stp	xzr, xzr, [x0, #48]
	str	wzr, [x0, #64]
	mov	w8, #3                          ; =0x3
	dup.2d	v0, x8
	str	q0, [x0]
	stp	x0, xzr, [sp, #8]
	add	x0, sp, #88
	add	x1, sp, #8
	add	x4, sp, #24
	mov	w2, #1                          ; =0x1
	mov	x3, x19
	bl	_wf_hash_map.hash_map_put$instance$c7b22b9ef52855b6
	ldr	w8, [sp, #88]
	cbz	w8, LBB28_4
; %bb.2:                                ; %bb1.i.i.i
	cmp	w8, #1
	b.ne	LBB28_30
; %bb.3:                                ; %bb3.i
	ldp	x9, x8, [sp, #96]
	ldrb	w10, [sp, #92]
	mov	w11, #131                       ; =0x83
	tst	w10, #0x1
	mov	w10, #1                         ; =0x1
	cinc	x10, x10, ne
	madd	x9, x19, x11, x9
	add	x9, x9, x10
	madd	x21, x9, x11, x8
	b	LBB28_5
LBB28_4:                                ; %bb2.i
	mov	w8, #131                        ; =0x83
	mul	x21, x19, x8
LBB28_5:                                ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit"
	add	x0, sp, #88
	add	x1, sp, #8
	add	x3, x19, #1
	add	x4, sp, #24
	mov	w2, #3                          ; =0x3
	bl	_wf_hash_map.hash_map_put$instance$c7b22b9ef52855b6
	ldr	w8, [sp, #88]
	cbz	w8, LBB28_8
; %bb.6:                                ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit"
	cmp	w8, #1
	b.ne	LBB28_30
; %bb.7:                                ; %bb3.i.1
	ldp	x9, x8, [sp, #96]
	ldrb	w10, [sp, #92]
	mov	w11, #131                       ; =0x83
	tst	w10, #0x1
	mov	w10, #1                         ; =0x1
	cinc	x10, x10, ne
	madd	x9, x21, x11, x9
	add	x9, x9, x10
	madd	x21, x9, x11, x8
	b	LBB28_9
LBB28_8:                                ; %bb2.i.1
	mov	w8, #131                        ; =0x83
	mul	x21, x21, x8
LBB28_9:                                ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit.1"
	add	x0, sp, #88
	add	x1, sp, #8
	add	x3, x19, #2
	add	x4, sp, #24
	mov	w2, #5                          ; =0x5
	bl	_wf_hash_map.hash_map_put$instance$c7b22b9ef52855b6
	ldr	w8, [sp, #88]
	cbz	w8, LBB28_12
; %bb.10:                               ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit.1"
	cmp	w8, #1
	b.ne	LBB28_30
; %bb.11:                               ; %bb3.i.2
	ldp	x9, x8, [sp, #96]
	ldrb	w10, [sp, #92]
	mov	w11, #131                       ; =0x83
	tst	w10, #0x1
	mov	w10, #1                         ; =0x1
	cinc	x10, x10, ne
	madd	x9, x21, x11, x9
	add	x9, x9, x10
	madd	x21, x9, x11, x8
	b	LBB28_13
LBB28_12:                               ; %bb2.i.2
	mov	w8, #131                        ; =0x83
	mul	x21, x21, x8
LBB28_13:                               ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit.2"
	add	x0, sp, #64
	add	x1, sp, #8
	add	x3, x19, #10
	add	x4, sp, #24
	mov	w2, #1                          ; =0x1
	bl	_wf_hash_map.hash_map_put$instance$c7b22b9ef52855b6
	ldr	w8, [sp, #64]
	cbz	w8, LBB28_16
; %bb.14:                               ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit.2"
	cmp	w8, #1
	b.ne	LBB28_30
; %bb.15:                               ; %bb3.i5
	ldp	x9, x8, [sp, #72]
	ldrb	w10, [sp, #68]
	mov	w11, #131                       ; =0x83
	tst	w10, #0x1
	mov	w10, #1                         ; =0x1
	cinc	x10, x10, ne
	madd	x9, x21, x11, x9
	add	x9, x9, x10
	madd	x21, x9, x11, x8
	b	LBB28_17
LBB28_16:                               ; %bb2.i19
	mov	w8, #131                        ; =0x83
	mul	x21, x21, x8
LBB28_17:                               ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit23"
	add	x0, sp, #40
	add	x1, sp, #8
	add	x3, x19, #20
	add	x4, sp, #24
	mov	w2, #7                          ; =0x7
	bl	_wf_hash_map.hash_map_put$instance$c7b22b9ef52855b6
	ldr	w8, [sp, #40]
	cbz	w8, LBB28_20
; %bb.18:                               ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit23"
	cmp	w8, #1
	b.ne	LBB28_30
; %bb.19:                               ; %bb3.i25
	ldp	x9, x8, [sp, #48]
	ldrb	w10, [sp, #44]
	mov	w11, #131                       ; =0x83
	tst	w10, #0x1
	mov	w10, #1                         ; =0x1
	cinc	x10, x10, ne
	madd	x9, x21, x11, x9
	add	x9, x9, x10
	madd	x19, x9, x11, x8
	b	LBB28_21
LBB28_20:                               ; %bb2.i39
	mov	w8, #131                        ; =0x83
	mul	x19, x21, x8
LBB28_21:                               ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit43"
	mov	x22, #58809                     ; =0xe5b9
	movk	x22, #7396, lsl #16
	movk	x22, #18285, lsl #32
	movk	x22, #48984, lsl #48
	mov	x21, #4587                      ; =0x11eb
	movk	x21, #4913, lsl #16
	movk	x21, #18875, lsl #32
	movk	x21, #38096, lsl #48
	ldr	x0, [sp, #8]
	ldr	x11, [x0]
	cbz	x11, LBB28_28
; %bb.22:                               ; %bb5.i.preheader
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	x23, #0                         ; =0x0
	sub	x10, x11, #1
	mov	w12, #24                        ; =0x18
	madd	x11, x11, x12, x0
	mov	w12, #131                       ; =0x83
	b	LBB28_24
LBB28_23:                               ; %bb6.i
                                        ;   in Loop: Header=BB28_24 Depth=1
	sub	x10, x10, #1
	sub	x11, x11, #24
	cmn	x10, #1
	b.eq	LBB28_27
LBB28_24:                               ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	str	x10, [x0]
	ldur	w13, [x11, #-8]
	cmp	w13, #2
	b.lo	LBB28_23
; %bb.25:                               ; %bb5.i
                                        ;   in Loop: Header=BB28_24 Depth=1
	b.ne	LBB28_30
; %bb.26:                               ; %bb7.i
                                        ;   in Loop: Header=BB28_24 Depth=1
	ldp	x14, x13, [x11]
	madd	x13, x14, x12, x13
	add	x23, x13, x23
	eor	x13, x13, x13, lsr #30
	mul	x13, x13, x22
	eor	x13, x13, x13, lsr #27
	mul	x13, x13, x21
	eor	x9, x9, x13, lsr #31
	eor	x9, x9, x13
	add	x8, x8, #1
	b	LBB28_23
LBB28_27:                               ; %"wf_hash_map.hash_map_free$instance$5c6f40d0925a4760.exit.loopexit"
	mul	x8, x8, x20
	eor	x20, x8, x9
	b	LBB28_29
LBB28_28:
	mov	x23, #0                         ; =0x0
	mov	x20, #0                         ; =0x0
LBB28_29:                               ; %"wf_hash_map.hash_map_free$instance$5c6f40d0925a4760.exit"
	bl	_free
	eor	x8, x19, x19, lsr #30
	mul	x8, x8, x22
	eor	x8, x8, x8, lsr #27
	mul	x8, x8, x21
	eor	x9, x23, x23, lsr #30
	mul	x9, x9, x22
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x21
	eor	x10, x9, x8
	eor	x10, x20, x10, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #144]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
LBB28_30:                               ; %invalid.tag.b0.i
	bl	_abort
LBB28_31:                               ; %window.block.oom.v1.i.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd ; -- Begin function wf_map_cost_library_trace$instance$c7c8cd11e7f079bd
	.p2align	2
_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd: ; @"wf_map_cost_library_trace$instance$c7c8cd11e7f079bd"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #576
	.cfi_def_cfa_offset 672
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x23, x4
	str	x2, [sp, #48]                   ; 8-byte Folded Spill
	mov	x21, x1
	mov	x24, x0
	mov	x8, #31765                      ; =0x7c15
	movk	x8, #32586, lsl #16
	movk	x8, #31161, lsl #32
	movk	x8, #40503, lsl #48
	str	x3, [sp, #32]                   ; 8-byte Folded Spill
	eor	x8, x3, x8
	cmp	x5, #0
	cset	w9, ne
	str	x8, [sp, #488]
	strb	w9, [sp, #496]
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB29_300
; %bb.1:                                ; %bb1.i.i.i
	add	x3, sp, #64
	stp	xzr, x24, [x0]
	cbz	x24, LBB29_5
; %bb.2:                                ; %bb5.i.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
LBB29_3:                                ; %bb5.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x9], #24
	cmp	x24, x8
	b.ne	LBB29_3
; %bb.4:                                ; %bb4.bb7_crit_edge.i.i.i
	str	x24, [x0]
LBB29_5:                                ; %"wf_hash_map.hash_map_new$instance$820b2044b97e0fbd.exit"
	add	x8, x3, #440
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	stp	x0, xzr, [sp, #504]
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	str	x8, [sp, #520]
	str	xzr, [sp, #528]
	str	xzr, [sp, #544]
	str	xzr, [sp, #536]
	cbz	x21, LBB29_11
; %bb.6:                                ; %bb2.lr.ph
	add	x19, sp, #64
	mov	w20, #1                         ; =0x1
	mov	w22, #131                       ; =0x83
	mov	w25, #1                         ; =0x1
	mov	x27, x21
	ldr	x26, [sp, #32]                  ; 8-byte Folded Reload
	b	LBB29_8
LBB29_7:                                ; %bb6
                                        ;   in Loop: Header=BB29_8 Depth=1
	ldr	x8, [sp, #520]
	mul	x8, x8, x22
	add	x3, sp, #64
	str	x8, [sp, #520]
	add	x26, x26, #1
	add	x25, x25, #2
	subs	x27, x27, #1
	b.eq	LBB29_11
LBB29_8:                                ; %bb2
                                        ; =>This Inner Loop Header: Depth=1
	add	x0, sp, #64
	add	x4, x3, #424
	ldr	x1, [sp, #56]                   ; 8-byte Folded Reload
	mov	x2, x25
	mov	x3, x26
	bl	_wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad
	ldr	w8, [sp, #64]
	cbz	w8, LBB29_7
; %bb.9:                                ; %bb2
                                        ;   in Loop: Header=BB29_8 Depth=1
	cmp	w8, #1
	b.ne	LBB29_299
; %bb.10:                               ; %bb7
                                        ;   in Loop: Header=BB29_8 Depth=1
	ldrb	w8, [sp, #68]
	ldur	q0, [x19, #8]
	add	x3, sp, #64
	stur	q0, [x3, #24]
	ldr	x9, [sp, #520]
	cmp	w8, #0
	cinc	x8, x20, ne
	madd	x8, x9, x22, x8
	ldp	x9, x10, [sp, #88]
	add	x8, x9, x8
	madd	x8, x8, x22, x10
	str	x8, [sp, #520]
	add	x26, x26, #1
	add	x25, x25, #2
	subs	x27, x27, #1
	b.ne	LBB29_8
LBB29_11:                               ; %bb12.preheader
	mov	x5, #58809                      ; =0xe5b9
	movk	x5, #7396, lsl #16
	movk	x5, #18285, lsl #32
	movk	x5, #48984, lsl #48
	mov	x4, #4587                       ; =0x11eb
	movk	x4, #4913, lsl #16
	movk	x4, #18875, lsl #32
	movk	x4, #38096, lsl #48
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	cbz	x9, LBB29_119
; %bb.12:                               ; %bb13.lr.ph
	lsl	x9, x24, #1
	cmp	x24, #0
	csinc	x19, x9, xzr, ne
	cmp	x23, #1
	csel	x24, x21, xzr, eq
	add	x20, sp, #64
	cmp	x23, #5
	b.ne	LBB29_126
; %bb.13:                               ; %bb13.us.preheader
	mov	x23, #0                         ; =0x0
	sub	x8, x21, x21, lsr #1
	cmp	x8, #1
	csinc	x22, x8, xzr, hi
	mov	w25, #131                       ; =0x83
	mov	w27, #1                         ; =0x1
	mov	w26, #24                        ; =0x18
	mov	w19, #17161                     ; =0x4309
	b	LBB29_15
LBB29_14:                               ;   in Loop: Header=BB29_15 Depth=1
	ldp	x23, x8, [sp, #40]              ; 16-byte Folded Reload
	mov	w19, #17161                     ; =0x4309
	cmp	x23, x8
	b.eq	LBB29_119
LBB29_15:                               ; %bb13.us
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB29_19 Depth 2
                                        ;       Child Loop BB29_25 Depth 3
                                        ;       Child Loop BB29_31 Depth 3
                                        ;       Child Loop BB29_42 Depth 3
                                        ;       Child Loop BB29_48 Depth 3
                                        ;     Child Loop BB29_62 Depth 2
                                        ;       Child Loop BB29_67 Depth 3
                                        ;       Child Loop BB29_73 Depth 3
                                        ;     Child Loop BB29_82 Depth 2
                                        ;       Child Loop BB29_87 Depth 3
                                        ;       Child Loop BB29_96 Depth 3
	cbz	x21, LBB29_53
; %bb.16:                               ; %bb20.lr.ph.us
                                        ;   in Loop: Header=BB29_15 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	x9, [sp, #512]
	b	LBB29_19
LBB29_17:                               ; %bb12.i.i.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	cbnz	w17, LBB29_299
LBB29_18:                               ; %bb3.i79.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	str	w27, [sp, #144]
	str	xzr, [sp, #152]
	mul	x10, x10, x25
	strb	wzr, [sp, #160]
	str	x10, [sp, #520]
	add	x8, x8, #1
	cmp	x8, x22
	b.eq	LBB29_54
LBB29_19:                               ; %bb20.us
                                        ;   Parent Loop BB29_15 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB29_25 Depth 3
                                        ;       Child Loop BB29_31 Depth 3
                                        ;       Child Loop BB29_42 Depth 3
                                        ;       Child Loop BB29_48 Depth 3
	orr	x10, x27, x8, lsl #2
	str	x10, [sp, #552]
	cbz	x9, LBB29_38
; %bb.20:                               ; %bb3.i.i.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	ldrb	w11, [sp, #496]
	tbz	w11, #0, LBB29_22
; %bb.21:                               ;   in Loop: Header=BB29_19 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	x11, [sp, #504]
	ldr	x14, [x11]
	cbnz	x14, LBB29_23
	b	LBB29_38
LBB29_22:                               ; %bb3.i.i.i574.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	ldr	x11, [sp, #488]
	eor	x11, x11, x10
	eor	x11, x11, x11, lsr #30
	mul	x11, x11, x5
	eor	x11, x11, x11, lsr #27
	mul	x11, x11, x4
	eor	x12, x11, x11, lsr #31
	ldr	x11, [sp, #504]
	ldr	x14, [x11]
	cbz	x14, LBB29_38
LBB29_23:                               ; %bb12.preheader.i.i589.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	udiv	x13, x12, x14
	msub	x13, x13, x14, x12
	mov	x12, x13
	b	LBB29_25
LBB29_24:                               ; %bb20.i.i593.us
                                        ;   in Loop: Header=BB29_25 Depth=3
	add	x12, x12, #1
	cmp	x12, x14
	b.eq	LBB29_28
LBB29_25:                               ; %bb12.i.i590.us
                                        ;   Parent Loop BB29_15 Depth=1
                                        ;     Parent Loop BB29_19 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	madd	x15, x12, x26, x11
	ldr	w16, [x15, #16]!
	cmp	w16, #1
	b.eq	LBB29_24
; %bb.26:                               ; %bb12.i.i590.us
                                        ;   in Loop: Header=BB29_25 Depth=3
	cmp	w16, #2
	b.ne	LBB29_36
; %bb.27:                               ; %bb3.i9.i.i.us
                                        ;   in Loop: Header=BB29_25 Depth=3
	ldr	x15, [x15, #8]
	cmp	x15, x10
	b.ne	LBB29_24
	b	LBB29_34
LBB29_28:                               ; %bb21.i.i.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	cbz	x13, LBB29_38
; %bb.29:                               ; %bb12.1.i.i595.us.preheader
                                        ;   in Loop: Header=BB29_19 Depth=2
	mov	x12, #0                         ; =0x0
	add	x14, x11, #24
	b	LBB29_31
LBB29_30:                               ; %bb20.1.i.i.us
                                        ;   in Loop: Header=BB29_31 Depth=3
	add	x12, x12, #1
	add	x14, x14, #24
	cmp	x13, x12
	b.eq	LBB29_38
LBB29_31:                               ; %bb12.1.i.i595.us
                                        ;   Parent Loop BB29_15 Depth=1
                                        ;     Parent Loop BB29_19 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldur	w15, [x14, #-8]
	cmp	w15, #1
	b.eq	LBB29_30
; %bb.32:                               ; %bb12.1.i.i595.us
                                        ;   in Loop: Header=BB29_31 Depth=3
	cmp	w15, #2
	b.ne	LBB29_37
; %bb.33:                               ; %bb3.i9.1.i.i.us
                                        ;   in Loop: Header=BB29_31 Depth=3
	ldr	x15, [x14]
	cmp	x15, x10
	b.ne	LBB29_30
LBB29_34:                               ; %bb24.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	madd	x11, x12, x26, x11
	ldr	x12, [x11, #32]
	str	w27, [x11, #16]
	stp	xzr, xzr, [x11, #24]
	sub	x9, x9, #1
	str	x9, [sp, #512]
	str	w27, [sp, #104]
	stp	x10, x12, [sp, #112]
	ldur	q0, [x20, #48]
	stur	q0, [x3, #64]
	ldr	x10, [sp, #520]
	ldp	x11, x12, [sp, #128]
	madd	x10, x10, x25, x11
	madd	x10, x10, x25, x12
	add	x10, x10, #131
	str	x10, [sp, #520]
	ldrb	w11, [sp, #496]
	tbnz	w11, #0, LBB29_39
LBB29_35:                               ; %bb3.i.i.i.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	ldr	x11, [sp, #488]
	ldr	x12, [sp, #552]
	eor	x11, x12, x11
	eor	x11, x11, x11, lsr #30
	mul	x11, x11, x5
	eor	x11, x11, x11, lsr #27
	mul	x11, x11, x4
	eor	x12, x11, x11, lsr #31
	ldr	x11, [sp, #504]
	ldr	x15, [x11]
	cbnz	x15, LBB29_40
	b	LBB29_18
LBB29_36:                               ; %bb12.i.i590.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	cbz	w16, LBB29_38
	b	LBB29_299
LBB29_37:                               ; %bb12.1.i.i595.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	cbnz	w15, LBB29_299
LBB29_38:                               ; %bb25.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	str	wzr, [sp, #104]
	stp	xzr, xzr, [x20, #48]
	ldr	x10, [sp, #520]
	mul	x10, x10, x25
	str	x10, [sp, #520]
	ldrb	w11, [sp, #496]
	tbz	w11, #0, LBB29_35
LBB29_39:                               ;   in Loop: Header=BB29_19 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	x11, [sp, #504]
	ldr	x15, [x11]
	cbz	x15, LBB29_18
LBB29_40:                               ; %bb12.preheader.i.i.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	udiv	x13, x12, x15
	msub	x13, x13, x15, x12
	ldr	x14, [sp, #552]
	mov	x12, x13
	b	LBB29_42
LBB29_41:                               ; %bb22.i.i.us
                                        ;   in Loop: Header=BB29_42 Depth=3
	add	x12, x12, #1
	cmp	x12, x15
	b.eq	LBB29_45
LBB29_42:                               ; %bb12.i.i.us
                                        ;   Parent Loop BB29_15 Depth=1
                                        ;     Parent Loop BB29_19 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	madd	x16, x12, x26, x11
	ldr	w17, [x16, #16]!
	cmp	w17, #1
	b.eq	LBB29_41
; %bb.43:                               ; %bb12.i.i.us
                                        ;   in Loop: Header=BB29_42 Depth=3
	cmp	w17, #2
	b.ne	LBB29_17
; %bb.44:                               ; %bb16.i.i.us
                                        ;   in Loop: Header=BB29_42 Depth=3
	ldr	x16, [x16, #8]
	cmp	x16, x14
	b.ne	LBB29_41
	b	LBB29_51
LBB29_45:                               ; %bb23.i.i.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	cbz	x13, LBB29_18
; %bb.46:                               ; %bb12.1.i.i.us.preheader
                                        ;   in Loop: Header=BB29_19 Depth=2
	mov	x12, #0                         ; =0x0
	add	x15, x11, #24
	b	LBB29_48
LBB29_47:                               ; %bb22.1.i.i.us
                                        ;   in Loop: Header=BB29_48 Depth=3
	add	x12, x12, #1
	add	x15, x15, #24
	cmp	x13, x12
	b.eq	LBB29_18
LBB29_48:                               ; %bb12.1.i.i.us
                                        ;   Parent Loop BB29_15 Depth=1
                                        ;     Parent Loop BB29_19 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldur	w16, [x15, #-8]
	cmp	w16, #1
	b.eq	LBB29_47
; %bb.49:                               ; %bb12.1.i.i.us
                                        ;   in Loop: Header=BB29_48 Depth=3
	cmp	w16, #2
	b.ne	LBB29_52
; %bb.50:                               ; %bb16.1.i.i.us
                                        ;   in Loop: Header=BB29_48 Depth=3
	ldr	x16, [x15]
	cmp	x16, x14
	b.ne	LBB29_47
LBB29_51:                               ; %bb2.i81.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	madd	x12, x12, x26, x11
	ldr	x12, [x12, #32]
	str	wzr, [sp, #144]
	str	x12, [sp, #152]
	strb	wzr, [sp, #160]
	madd	x10, x10, x19, x12
	add	x10, x10, #131
	str	x10, [sp, #520]
	add	x8, x8, #1
	cmp	x8, x22
	b.ne	LBB29_19
	b	LBB29_54
LBB29_52:                               ; %bb12.1.i.i.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	cbz	w16, LBB29_18
	b	LBB29_299
LBB29_53:                               ; %bb13.us.bb22.us_crit_edge
                                        ;   in Loop: Header=BB29_15 Depth=1
	ldr	x11, [sp, #504]
LBB29_54:                               ; %bb22.us
                                        ;   in Loop: Header=BB29_15 Depth=1
	ldr	x1, [x11]
	add	x2, x3, #424
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	bl	_wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	str	w0, [sp, #168]
	strb	w1, [sp, #172]
	strb	w2, [sp, #173]
	cbz	w0, LBB29_57
; %bb.55:                               ; %bb22.us
                                        ;   in Loop: Header=BB29_15 Depth=1
	cmp	w0, #1
	b.ne	LBB29_299
; %bb.56:                               ; %bb3.i.us
                                        ;   in Loop: Header=BB29_15 Depth=1
	ldr	x8, [sp, #520]
	mul	x8, x8, x25
	b	LBB29_58
LBB29_57:                               ; %bb2.i.us
                                        ;   in Loop: Header=BB29_15 Depth=1
	ldr	x8, [sp, #520]
	mov	x9, #1                          ; =0x1
	madd	x8, x8, x25, x9
LBB29_58:                               ; %wf_map_cost_rebuild_result.exit.us
                                        ;   in Loop: Header=BB29_15 Depth=1
	add	x3, sp, #64
	mov	x4, #4587                       ; =0x11eb
	movk	x4, #4913, lsl #16
	movk	x4, #18875, lsl #32
	movk	x4, #38096, lsl #48
	mov	x5, #58809                      ; =0xe5b9
	movk	x5, #7396, lsl #16
	movk	x5, #18285, lsl #32
	movk	x5, #48984, lsl #48
	str	x8, [sp, #520]
	cbz	x21, LBB29_118
; %bb.59:                               ; %bb28.lr.ph.us
                                        ;   in Loop: Header=BB29_15 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	x10, [sp, #488]
	ldrb	w11, [sp, #496]
	ldr	x12, [sp, #504]
	add	x13, x12, #24
	b	LBB29_62
LBB29_60:                               ; %bb12.i.i118.us
                                        ;   in Loop: Header=BB29_62 Depth=2
	cbnz	w1, LBB29_299
LBB29_61:                               ; %bb3.i157.us
                                        ;   in Loop: Header=BB29_62 Depth=2
	str	w27, [sp, #176]
	str	xzr, [sp, #184]
	mul	x8, x8, x25
	strb	wzr, [sp, #192]
	str	x8, [sp, #520]
	add	x9, x9, #1
	cmp	x9, x21
	b.eq	LBB29_78
LBB29_62:                               ; %bb28.us
                                        ;   Parent Loop BB29_15 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB29_67 Depth 3
                                        ;       Child Loop BB29_73 Depth 3
	orr	x14, x27, x9, lsl #1
	str	x14, [sp, #560]
	tbz	w11, #0, LBB29_64
; %bb.63:                               ;   in Loop: Header=BB29_62 Depth=2
	mov	x15, #0                         ; =0x0
	ldr	x17, [x12]
	cbnz	x17, LBB29_65
	b	LBB29_61
LBB29_64:                               ; %bb3.i.i.i100.us
                                        ;   in Loop: Header=BB29_62 Depth=2
	eor	x15, x10, x14
	eor	x15, x15, x15, lsr #30
	mul	x15, x15, x5
	eor	x15, x15, x15, lsr #27
	mul	x15, x15, x4
	eor	x15, x15, x15, lsr #31
	ldr	x17, [x12]
	cbz	x17, LBB29_61
LBB29_65:                               ; %bb12.preheader.i.i116.us
                                        ;   in Loop: Header=BB29_62 Depth=2
	udiv	x16, x15, x17
	msub	x16, x16, x17, x15
	mov	x15, x16
	b	LBB29_67
LBB29_66:                               ; %bb22.i.i123.us
                                        ;   in Loop: Header=BB29_67 Depth=3
	add	x15, x15, #1
	cmp	x15, x17
	b.eq	LBB29_70
LBB29_67:                               ; %bb12.i.i118.us
                                        ;   Parent Loop BB29_15 Depth=1
                                        ;     Parent Loop BB29_62 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	madd	x0, x15, x26, x12
	ldr	w1, [x0, #16]!
	cmp	w1, #1
	b.eq	LBB29_66
; %bb.68:                               ; %bb12.i.i118.us
                                        ;   in Loop: Header=BB29_67 Depth=3
	cmp	w1, #2
	b.ne	LBB29_60
; %bb.69:                               ; %bb16.i.i150.us
                                        ;   in Loop: Header=BB29_67 Depth=3
	ldr	x0, [x0, #8]
	cmp	x0, x14
	b.ne	LBB29_66
	b	LBB29_76
LBB29_70:                               ; %bb23.i.i126.us
                                        ;   in Loop: Header=BB29_62 Depth=2
	cbz	x16, LBB29_61
; %bb.71:                               ; %bb12.1.i.i128.us.preheader
                                        ;   in Loop: Header=BB29_62 Depth=2
	mov	x15, #0                         ; =0x0
	mov	x17, x13
	b	LBB29_73
LBB29_72:                               ; %bb22.1.i.i133.us
                                        ;   in Loop: Header=BB29_73 Depth=3
	add	x15, x15, #1
	add	x17, x17, #24
	cmp	x16, x15
	b.eq	LBB29_61
LBB29_73:                               ; %bb12.1.i.i128.us
                                        ;   Parent Loop BB29_15 Depth=1
                                        ;     Parent Loop BB29_62 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldur	w0, [x17, #-8]
	cmp	w0, #1
	b.eq	LBB29_72
; %bb.74:                               ; %bb12.1.i.i128.us
                                        ;   in Loop: Header=BB29_73 Depth=3
	cmp	w0, #2
	b.ne	LBB29_77
; %bb.75:                               ; %bb16.1.i.i141.us
                                        ;   in Loop: Header=BB29_73 Depth=3
	ldr	x0, [x17]
	cmp	x0, x14
	b.ne	LBB29_72
LBB29_76:                               ; %bb2.i161.us
                                        ;   in Loop: Header=BB29_62 Depth=2
	madd	x14, x15, x26, x12
	ldr	x14, [x14, #32]
	str	wzr, [sp, #176]
	str	x14, [sp, #184]
	strb	wzr, [sp, #192]
	madd	x8, x8, x19, x14
	add	x8, x8, #131
	str	x8, [sp, #520]
	add	x9, x9, #1
	cmp	x9, x21
	b.ne	LBB29_62
	b	LBB29_78
LBB29_77:                               ; %bb12.1.i.i128.us
                                        ;   in Loop: Header=BB29_62 Depth=2
	cbz	w0, LBB29_61
	b	LBB29_299
LBB29_78:                               ; %bb33.lr.ph.us
                                        ;   in Loop: Header=BB29_15 Depth=1
	mov	x19, #0                         ; =0x0
	add	x23, x23, #1
	ldr	x28, [sp, #32]                  ; 8-byte Folded Reload
	str	x23, [sp, #40]                  ; 8-byte Folded Spill
	madd	x28, x23, x21, x28
	b	LBB29_82
LBB29_79:                               ; %bb38.us.thread
                                        ;   in Loop: Header=BB29_82 Depth=2
	stp	x27, x23, [sp, #200]
	strb	w27, [sp, #204]
	str	x24, [sp, #216]
	ldur	q0, [x20, #144]
	stur	q0, [x3, #160]
LBB29_80:                               ; %bb41.us
                                        ;   in Loop: Header=BB29_82 Depth=2
	mov	w8, #2                          ; =0x2
LBB29_81:                               ; %bb39.us
                                        ;   in Loop: Header=BB29_82 Depth=2
	ldr	x9, [sp, #520]
	madd	x8, x9, x25, x8
	ldp	x9, x10, [sp, #224]
	add	x8, x9, x8
	madd	x8, x8, x25, x10
	str	x8, [sp, #520]
	add	x19, x19, #1
	cmp	x19, x22
	b.eq	LBB29_14
LBB29_82:                               ; %bb33.us
                                        ;   Parent Loop BB29_15 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB29_87 Depth 3
                                        ;       Child Loop BB29_96 Depth 3
	orr	x23, x27, x19, lsl #2
	ldrb	w8, [sp, #496]
	tbz	w8, #0, LBB29_90
; %bb.83:                               ;   in Loop: Header=BB29_82 Depth=2
	mov	x10, #0                         ; =0x0
	add	x24, x28, x19, lsl #1
	ldr	x9, [sp, #504]
	ldr	x8, [x9]
	cbz	x8, LBB29_91
LBB29_84:                               ; %bb12.preheader.i.us
                                        ;   in Loop: Header=BB29_82 Depth=2
	udiv	x11, x10, x8
	msub	x12, x11, x8, x10
	mov	x11, x12
	mov	x10, x8
	b	LBB29_87
LBB29_85:                               ; %bb18.i618.us
                                        ;   in Loop: Header=BB29_87 Depth=3
	cmp	x10, x8
	csel	x10, x11, x10, eq
LBB29_86:                               ; %bb26.i.us
                                        ;   in Loop: Header=BB29_87 Depth=3
	add	x11, x11, #1
	cmp	x11, x8
	b.eq	LBB29_92
LBB29_87:                               ; %bb12.i.us
                                        ;   Parent Loop BB29_15 Depth=1
                                        ;     Parent Loop BB29_82 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	madd	x13, x11, x26, x9
	ldr	w14, [x13, #16]!
	cmp	w14, #1
	b.eq	LBB29_85
; %bb.88:                               ; %bb12.i.us
                                        ;   in Loop: Header=BB29_87 Depth=3
	cmp	w14, #2
	b.ne	LBB29_100
; %bb.89:                               ; %bb3.i20.i.us
                                        ;   in Loop: Header=BB29_87 Depth=3
	ldr	x14, [x13, #8]
	cmp	x14, x23
	b.ne	LBB29_86
	b	LBB29_99
LBB29_90:                               ; %bb3.i.i605.us
                                        ;   in Loop: Header=BB29_82 Depth=2
	ldr	x8, [sp, #488]
	eor	x8, x8, x23
	eor	x8, x8, x8, lsr #30
	mul	x8, x8, x5
	eor	x8, x8, x8, lsr #27
	mul	x8, x8, x4
	eor	x10, x8, x8, lsr #31
	add	x24, x28, x19, lsl #1
	ldr	x9, [sp, #504]
	ldr	x8, [x9]
	cbnz	x8, LBB29_84
LBB29_91:                               ;   in Loop: Header=BB29_82 Depth=2
	mov	x10, #0                         ; =0x0
	b	LBB29_102
LBB29_92:                               ; %bb27.i.us
                                        ;   in Loop: Header=BB29_82 Depth=2
	cbz	x12, LBB29_102
; %bb.93:                               ; %bb12.1.i.us.preheader
                                        ;   in Loop: Header=BB29_82 Depth=2
	mov	x11, #0                         ; =0x0
	add	x13, x9, #16
	b	LBB29_96
LBB29_94:                               ; %bb18.1.i.us
                                        ;   in Loop: Header=BB29_96 Depth=3
	cmp	x10, x8
	csel	x10, x11, x10, eq
LBB29_95:                               ; %bb26.1.i.us
                                        ;   in Loop: Header=BB29_96 Depth=3
	add	x11, x11, #1
	add	x13, x13, #24
	cmp	x12, x11
	b.eq	LBB29_102
LBB29_96:                               ; %bb12.1.i.us
                                        ;   Parent Loop BB29_15 Depth=1
                                        ;     Parent Loop BB29_82 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w14, [x13]
	cmp	w14, #1
	b.eq	LBB29_94
; %bb.97:                               ; %bb12.1.i.us
                                        ;   in Loop: Header=BB29_96 Depth=3
	cmp	w14, #2
	b.ne	LBB29_100
; %bb.98:                               ; %bb3.i20.1.i.us
                                        ;   in Loop: Header=BB29_96 Depth=3
	ldr	x14, [x13, #8]
	cmp	x14, x23
	b.ne	LBB29_95
LBB29_99:                               ; %"wf_hash_map.hash_map_exchange$instance$0ed342445dd803f3.exit.i.us"
                                        ;   in Loop: Header=BB29_82 Depth=2
	ldr	x8, [x13, #16]
	mov	w9, #2                          ; =0x2
	str	w9, [x13]
	stp	x23, x24, [x13, #8]
	b	LBB29_116
LBB29_100:                              ; %bb12.1.i.us
                                        ;   in Loop: Header=BB29_82 Depth=2
	cbnz	w14, LBB29_299
; %bb.101:                              ; %bb17.i617.us
                                        ;   in Loop: Header=BB29_82 Depth=2
	cmp	x10, x8
	csel	x10, x11, x10, eq
LBB29_102:                              ; %bb1.i615.us
                                        ;   in Loop: Header=BB29_82 Depth=2
	cmp	x10, x8
	b.hs	LBB29_106
; %bb.103:                              ; %bb29.i.us
                                        ;   in Loop: Header=BB29_82 Depth=2
	ldr	x11, [sp, #512]
	cmp	x11, #4, lsl #12                ; =16384
	b.hs	LBB29_106
; %bb.104:                              ; %bb32.i.us
                                        ;   in Loop: Header=BB29_82 Depth=2
	add	x8, x11, #1
	str	x8, [sp, #512]
	madd	x10, x10, x26, x9
	ldr	w11, [x10, #16]
	ldp	x9, x8, [x10, #24]
	mov	w12, #2                         ; =0x2
	str	w12, [x10, #16]
	stp	x23, x24, [x10, #24]
	cmp	w11, #2
	b.hs	LBB29_114
; %bb.105:                              ; %"wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit.thread.us"
                                        ;   in Loop: Header=BB29_82 Depth=2
	stp	xzr, xzr, [x3, #136]
	stur	xzr, [x3, #152]
	b	LBB29_113
LBB29_106:                              ; %bb4.i.us
                                        ;   in Loop: Header=BB29_82 Depth=2
	lsr	x9, x8, #14
	cbnz	x9, LBB29_79
; %bb.107:                              ; %bb7.i173.us
                                        ;   in Loop: Header=BB29_82 Depth=2
	cmp	x8, #2, lsl #12                 ; =8192
	mov	w9, #8192                       ; =0x2000
	csel	x9, x8, x9, lo
	lsl	x9, x9, #1
	cmp	x8, #0
	csinc	x1, x9, xzr, ne
	cmp	x1, x8
	b.ls	LBB29_110
; %bb.108:                              ; %"wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit.i.us"
                                        ;   in Loop: Header=BB29_82 Depth=2
	add	x2, x3, #424
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	bl	_wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	add	x3, sp, #64
	cmp	w0, #1
	mov	x4, #4587                       ; =0x11eb
	movk	x4, #4913, lsl #16
	movk	x4, #18875, lsl #32
	movk	x4, #38096, lsl #48
	mov	x5, #58809                      ; =0xe5b9
	movk	x5, #7396, lsl #16
	movk	x5, #18285, lsl #32
	movk	x5, #48984, lsl #48
	b.eq	LBB29_79
; %bb.109:                              ; %"wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit.i.us"
                                        ;   in Loop: Header=BB29_82 Depth=2
	cbnz	w0, LBB29_299
LBB29_110:                              ; %"wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit.us"
                                        ;   in Loop: Header=BB29_82 Depth=2
	add	x0, x3, #136
	add	x4, x3, #424
	ldr	x1, [sp, #56]                   ; 8-byte Folded Reload
	mov	x2, x23
	mov	x3, x24
	bl	_wf_hash_map.hash_map_try_put$instance$fde7c6722a8b0dad
	add	x3, sp, #64
	ldr	w8, [sp, #200]
	mov	x4, #4587                       ; =0x11eb
	movk	x4, #4913, lsl #16
	movk	x4, #18875, lsl #32
	movk	x4, #38096, lsl #48
	mov	x5, #58809                      ; =0xe5b9
	movk	x5, #7396, lsl #16
	movk	x5, #18285, lsl #32
	movk	x5, #48984, lsl #48
	cbz	w8, LBB29_113
; %bb.111:                              ; %"wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit.us"
                                        ;   in Loop: Header=BB29_82 Depth=2
	cmp	w8, #1
	b.ne	LBB29_299
; %bb.112:                              ; %bb38.us
                                        ;   in Loop: Header=BB29_82 Depth=2
	ldrb	w8, [sp, #204]
	ldur	q0, [x20, #144]
	stur	q0, [x3, #160]
	cmp	w8, #1
	b.eq	LBB29_80
	b	LBB29_117
LBB29_113:                              ; %bb37.us
                                        ;   in Loop: Header=BB29_82 Depth=2
	ldr	x8, [sp, #520]
	mul	x8, x8, x25
	str	x8, [sp, #520]
	add	x19, x19, #1
	cmp	x19, x22
	b.ne	LBB29_82
	b	LBB29_14
LBB29_114:                              ; %bb32.i.us
                                        ;   in Loop: Header=BB29_82 Depth=2
	b.ne	LBB29_299
; %bb.115:                              ;   in Loop: Header=BB29_82 Depth=2
	mov	x23, x9
LBB29_116:                              ; %"wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit.thread957.us"
                                        ;   in Loop: Header=BB29_82 Depth=2
	stp	x27, x23, [sp, #200]
	str	x8, [sp, #216]
	ldrb	w8, [sp, #204]
	ldur	q0, [x20, #144]
	stur	q0, [x3, #160]
	cmp	w8, #1
	b.eq	LBB29_80
LBB29_117:                              ;   in Loop: Header=BB29_82 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB29_81
LBB29_118:                              ; %bb32.preheader.us.bb93.loopexit.us_crit_edge
                                        ;   in Loop: Header=BB29_15 Depth=1
	add	x23, x23, #1
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	cmp	x23, x8
	b.ne	LBB29_15
LBB29_119:                              ; %bb15
	add	x8, sp, #64
	add	x9, x8, #376
	ldr	x10, [sp, #56]                  ; 8-byte Folded Reload
	ldr	q0, [x10]
	str	q0, [x9]
	ldr	x0, [sp, #440]
	ldr	x13, [x0]
	cbz	x13, LBB29_125
; %bb.120:                              ; %bb5.lr.ph.i
	ldr	x9, [sp, #528]
	ldr	x10, [sp, #536]
	ldr	x11, [sp, #544]
	sub	x12, x13, #1
	mov	w14, #24                        ; =0x18
	madd	x13, x13, x14, x0
	mov	w14, #131                       ; =0x83
	b	LBB29_122
LBB29_121:                              ; %bb6.i
                                        ;   in Loop: Header=BB29_122 Depth=1
	sub	x12, x12, #1
	sub	x13, x13, #24
	cmn	x12, #1
	b.eq	LBB29_125
LBB29_122:                              ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	str	x12, [x0]
	ldur	w15, [x13, #-8]
	cmp	w15, #2
	b.lo	LBB29_121
; %bb.123:                              ; %bb5.i
                                        ;   in Loop: Header=BB29_122 Depth=1
	b.ne	LBB29_299
; %bb.124:                              ; %bb7.i
                                        ;   in Loop: Header=BB29_122 Depth=1
	ldp	x16, x15, [x13]
	madd	x15, x16, x14, x15
	add	x9, x15, x9
	eor	x15, x15, x15, lsr #30
	mul	x15, x15, x5
	eor	x15, x15, x15, lsr #27
	mul	x15, x15, x4
	eor	x10, x10, x15, lsr #31
	eor	x10, x10, x15
	str	x9, [sp, #528]
	str	x10, [sp, #536]
	add	x11, x11, #1
	str	x11, [sp, #544]
	b	LBB29_121
LBB29_125:                              ; %"wf_hash_map.hash_map_free$instance$001ff12ace7d7c19.exit"
	add	x19, x3, #456
	add	x20, x8, #392
	mov	x21, x4
	mov	x22, x5
	bl	_free
	ldp	q0, q1, [x19]
	stp	q0, q1, [x20]
	ldp	x8, x9, [sp, #456]
	ldp	x10, x11, [sp, #472]
	eor	x8, x8, x8, lsr #30
	mul	x8, x8, x22
	eor	x8, x8, x8, lsr #27
	mul	x8, x8, x21
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x22
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x21
	eor	x12, x9, x8
	mov	x13, #31765                     ; =0x7c15
	movk	x13, #32586, lsl #16
	movk	x13, #31161, lsl #32
	movk	x13, #40503, lsl #48
	mul	x11, x11, x13
	eor	x10, x10, x11
	eor	x10, x10, x12, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	add	sp, sp, #576
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB29_126:                              ; %bb13.preheader
	mov	x25, #0                         ; =0x0
	sub	x17, x23, #9
	mov	w6, #131                        ; =0x83
	mov	w22, #1                         ; =0x1
	mov	w27, #24                        ; =0x18
	mov	w7, #17161                      ; =0x4309
	stp	x19, x17, [sp, #16]             ; 16-byte Folded Spill
	b	LBB29_129
LBB29_127:                              ;   in Loop: Header=BB29_129 Depth=1
	mov	x28, x25
LBB29_128:                              ; %bb93.loopexit1105
                                        ;   in Loop: Header=BB29_129 Depth=1
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	mov	x25, x28
	cmp	x28, x9
	ldr	x19, [sp, #16]                  ; 8-byte Folded Reload
	b.eq	LBB29_119
LBB29_129:                              ; %bb13
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB29_148 Depth 2
                                        ;       Child Loop BB29_188 Depth 3
                                        ;       Child Loop BB29_208 Depth 3
                                        ;       Child Loop BB29_194 Depth 3
                                        ;       Child Loop BB29_231 Depth 3
                                        ;       Child Loop BB29_249 Depth 3
                                        ;       Child Loop BB29_255 Depth 3
                                        ;       Child Loop BB29_266 Depth 3
                                        ;       Child Loop BB29_274 Depth 3
                                        ;       Child Loop BB29_178 Depth 3
                                        ;       Child Loop BB29_201 Depth 3
                                        ;       Child Loop BB29_163 Depth 3
                                        ;       Child Loop BB29_169 Depth 3
	cmp	x23, #4
	b.eq	LBB29_133
; %bb.130:                              ; %bb13
                                        ;   in Loop: Header=BB29_129 Depth=1
	cmp	x23, #9
	b.eq	LBB29_133
; %bb.131:                              ; %bb13
                                        ;   in Loop: Header=BB29_129 Depth=1
	cmp	x23, #10
	b.ne	LBB29_142
; %bb.132:                              ; %bb49.thread
                                        ;   in Loop: Header=BB29_129 Depth=1
	mov	x9, #1                          ; =0x1
	madd	x8, x8, x6, x9
	str	x8, [sp, #520]
	b	LBB29_141
LBB29_133:                              ; %bb51
                                        ;   in Loop: Header=BB29_129 Depth=1
	cmp	x19, #4, lsl #12                ; =16384
	b.ls	LBB29_137
; %bb.134:                              ;   in Loop: Header=BB29_129 Depth=1
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	str	w0, [sp, #240]
	strb	w1, [sp, #244]
	strb	w2, [sp, #245]
	cbz	w0, LBB29_140
LBB29_135:                              ; %"wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit"
                                        ;   in Loop: Header=BB29_129 Depth=1
	cmp	w0, #1
	b.ne	LBB29_299
; %bb.136:                              ; %bb3.i202
                                        ;   in Loop: Header=BB29_129 Depth=1
	ldr	x8, [sp, #520]
	mul	x8, x8, x6
	str	x8, [sp, #520]
	cmp	x17, #2
	b.lo	LBB29_141
	b	LBB29_142
LBB29_137:                              ; %bb3.i.i193
                                        ;   in Loop: Header=BB29_129 Depth=1
	ldr	x8, [sp, #504]
	ldr	x8, [x8]
	cmp	x19, x8
	b.ls	LBB29_139
; %bb.138:                              ; %bb6.i.i200
                                        ;   in Loop: Header=BB29_129 Depth=1
	add	x2, x3, #424
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	mov	x1, x19
	bl	_wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	mov	w7, #17161                      ; =0x4309
	mov	w6, #131                        ; =0x83
	ldr	x17, [sp, #24]                  ; 8-byte Folded Reload
	mov	x5, #58809                      ; =0xe5b9
	movk	x5, #7396, lsl #16
	movk	x5, #18285, lsl #32
	movk	x5, #48984, lsl #48
	mov	x4, #4587                       ; =0x11eb
	movk	x4, #4913, lsl #16
	movk	x4, #18875, lsl #32
	movk	x4, #38096, lsl #48
	add	x3, sp, #64
	str	w0, [sp, #240]
	strb	w1, [sp, #244]
	strb	w2, [sp, #245]
	cbnz	w0, LBB29_135
	b	LBB29_140
LBB29_139:                              ;   in Loop: Header=BB29_129 Depth=1
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #240]
	strb	w1, [sp, #244]
	strb	w2, [sp, #245]
	cbnz	w0, LBB29_135
LBB29_140:                              ; %bb2.i207
                                        ;   in Loop: Header=BB29_129 Depth=1
	ldr	x8, [sp, #520]
	mov	x9, #1                          ; =0x1
	madd	x8, x8, x6, x9
	str	x8, [sp, #520]
	cmp	x17, #2
	b.hs	LBB29_142
LBB29_141:                              ; %bb53
                                        ;   in Loop: Header=BB29_129 Depth=1
	ldr	x9, [sp, #504]
	ldr	x9, [x9]
	cmp	x9, x19
	mul	x8, x8, x6
	cinc	x8, x8, hs
	str	x8, [sp, #520]
LBB29_142:                              ; %bb43
                                        ;   in Loop: Header=BB29_129 Depth=1
	add	x25, x25, #1
	cbz	x21, LBB29_127
; %bb.143:                              ; %bb59.lr.ph
                                        ;   in Loop: Header=BB29_129 Depth=1
	mov	x19, #0                         ; =0x0
	ldr	x9, [sp, #32]                   ; 8-byte Folded Reload
	mov	x28, x25
	madd	x0, x25, x21, x9
	str	x0, [sp, #40]                   ; 8-byte Folded Spill
	b	LBB29_148
LBB29_144:                              ; %bb12.i.i241
                                        ;   in Loop: Header=BB29_148 Depth=2
	cbnz	w14, LBB29_299
LBB29_145:                              ; %bb3.i280
                                        ;   in Loop: Header=BB29_148 Depth=2
	str	w22, [sp, #248]
	str	xzr, [sp, #256]
	mul	x8, x8, x6
	strb	wzr, [sp, #264]
LBB29_146:                              ; %bb92.sink.split
                                        ;   in Loop: Header=BB29_148 Depth=2
	str	x8, [sp, #520]
LBB29_147:                              ; %bb92
                                        ;   in Loop: Header=BB29_148 Depth=2
	add	x19, x19, #1
	cmp	x19, x21
	b.eq	LBB29_128
LBB29_148:                              ; %bb59
                                        ;   Parent Loop BB29_129 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB29_188 Depth 3
                                        ;       Child Loop BB29_208 Depth 3
                                        ;       Child Loop BB29_194 Depth 3
                                        ;       Child Loop BB29_231 Depth 3
                                        ;       Child Loop BB29_249 Depth 3
                                        ;       Child Loop BB29_255 Depth 3
                                        ;       Child Loop BB29_266 Depth 3
                                        ;       Child Loop BB29_274 Depth 3
                                        ;       Child Loop BB29_178 Depth 3
                                        ;       Child Loop BB29_201 Depth 3
                                        ;       Child Loop BB29_163 Depth 3
                                        ;       Child Loop BB29_169 Depth 3
	add	x9, x19, x24
	orr	x25, x22, x9, lsl #1
	str	x25, [sp, #568]
	cmp	x23, #3
	b.gt	LBB29_155
; %bb.149:                              ; %bb59
                                        ;   in Loop: Header=BB29_148 Depth=2
	cmp	x23, #2
	b.lo	LBB29_158
; %bb.150:                              ; %bb59
                                        ;   in Loop: Header=BB29_148 Depth=2
	b.eq	LBB29_173
; %bb.151:                              ; %bb59
                                        ;   in Loop: Header=BB29_148 Depth=2
	cmp	x23, #3
	b.ne	LBB29_147
; %bb.152:                              ; %bb78
                                        ;   in Loop: Header=BB29_148 Depth=2
	ldr	x8, [sp, #512]
	cbz	x8, LBB29_245
; %bb.153:                              ; %bb3.i.i345
                                        ;   in Loop: Header=BB29_148 Depth=2
	ldrb	w9, [sp, #496]
	tbz	w9, #0, LBB29_191
; %bb.154:                              ;   in Loop: Header=BB29_148 Depth=2
	mov	x10, #0                         ; =0x0
	ldr	x9, [sp, #504]
	ldr	x12, [x9]
	cbnz	x12, LBB29_192
	b	LBB29_245
LBB29_155:                              ; %bb59
                                        ;   in Loop: Header=BB29_148 Depth=2
	cmp	x17, #2
	b.lo	LBB29_158
; %bb.156:                              ; %bb59
                                        ;   in Loop: Header=BB29_148 Depth=2
	cmp	x23, #7
	b.eq	LBB29_181
; %bb.157:                              ; %bb59
                                        ;   in Loop: Header=BB29_148 Depth=2
	cmp	x23, #4
	b.ne	LBB29_147
LBB29_158:                              ; %bb66
                                        ;   in Loop: Header=BB29_148 Depth=2
	ldrb	w9, [sp, #496]
	tbz	w9, #0, LBB29_160
; %bb.159:                              ;   in Loop: Header=BB29_148 Depth=2
	mov	x10, #0                         ; =0x0
	ldr	x9, [sp, #504]
	ldr	x12, [x9]
	cbnz	x12, LBB29_161
	b	LBB29_145
LBB29_160:                              ; %bb3.i.i.i223
                                        ;   in Loop: Header=BB29_148 Depth=2
	ldr	x9, [sp, #488]
	eor	x9, x9, x25
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x5
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x4
	eor	x10, x9, x9, lsr #31
	ldr	x9, [sp, #504]
	ldr	x12, [x9]
	cbz	x12, LBB29_145
LBB29_161:                              ; %bb12.preheader.i.i239
                                        ;   in Loop: Header=BB29_148 Depth=2
	udiv	x11, x10, x12
	msub	x11, x11, x12, x10
	mov	x10, x11
	b	LBB29_163
LBB29_162:                              ; %bb22.i.i246
                                        ;   in Loop: Header=BB29_163 Depth=3
	add	x10, x10, #1
	cmp	x10, x12
	b.eq	LBB29_166
LBB29_163:                              ; %bb12.i.i241
                                        ;   Parent Loop BB29_129 Depth=1
                                        ;     Parent Loop BB29_148 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	madd	x13, x10, x27, x9
	ldr	w14, [x13, #16]!
	cmp	w14, #1
	b.eq	LBB29_162
; %bb.164:                              ; %bb12.i.i241
                                        ;   in Loop: Header=BB29_163 Depth=3
	cmp	w14, #2
	b.ne	LBB29_144
; %bb.165:                              ; %bb16.i.i273
                                        ;   in Loop: Header=BB29_163 Depth=3
	ldr	x13, [x13, #8]
	cmp	x13, x25
	b.ne	LBB29_162
	b	LBB29_172
LBB29_166:                              ; %bb23.i.i249
                                        ;   in Loop: Header=BB29_148 Depth=2
	cbz	x11, LBB29_145
; %bb.167:                              ; %bb12.1.i.i251.preheader
                                        ;   in Loop: Header=BB29_148 Depth=2
	mov	x10, #0                         ; =0x0
	add	x12, x9, #24
	b	LBB29_169
LBB29_168:                              ; %bb22.1.i.i256
                                        ;   in Loop: Header=BB29_169 Depth=3
	add	x10, x10, #1
	add	x12, x12, #24
	cmp	x11, x10
	b.eq	LBB29_145
LBB29_169:                              ; %bb12.1.i.i251
                                        ;   Parent Loop BB29_129 Depth=1
                                        ;     Parent Loop BB29_148 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldur	w13, [x12, #-8]
	cmp	w13, #1
	b.eq	LBB29_168
; %bb.170:                              ; %bb12.1.i.i251
                                        ;   in Loop: Header=BB29_169 Depth=3
	cmp	w13, #2
	b.ne	LBB29_212
; %bb.171:                              ; %bb16.1.i.i264
                                        ;   in Loop: Header=BB29_169 Depth=3
	ldr	x13, [x12]
	cmp	x13, x25
	b.ne	LBB29_168
LBB29_172:                              ; %bb2.i285
                                        ;   in Loop: Header=BB29_148 Depth=2
	madd	x9, x10, x27, x9
	ldr	x9, [x9, #32]
	str	wzr, [sp, #248]
	str	x9, [sp, #256]
	strb	wzr, [sp, #264]
	madd	x8, x8, x7, x9
	add	x8, x8, #131
	b	LBB29_146
LBB29_173:                              ; %bb69
                                        ;   in Loop: Header=BB29_148 Depth=2
	ldrb	w8, [sp, #496]
	tbz	w8, #0, LBB29_183
; %bb.174:                              ;   in Loop: Header=BB29_148 Depth=2
	mov	x10, #0                         ; =0x0
	add	x26, x0, x19
	ldr	x9, [sp, #504]
	ldr	x8, [x9]
	cbz	x8, LBB29_184
LBB29_175:                              ; %bb12.preheader.i636
                                        ;   in Loop: Header=BB29_148 Depth=2
	udiv	x11, x10, x8
	msub	x12, x11, x8, x10
	mov	x11, x12
	mov	x10, x8
	b	LBB29_178
LBB29_176:                              ; %bb18.i710
                                        ;   in Loop: Header=BB29_178 Depth=3
	cmp	x10, x8
	csel	x10, x11, x10, eq
LBB29_177:                              ; %bb26.i648
                                        ;   in Loop: Header=BB29_178 Depth=3
	add	x11, x11, #1
	cmp	x11, x8
	b.eq	LBB29_197
LBB29_178:                              ; %bb12.i638
                                        ;   Parent Loop BB29_129 Depth=1
                                        ;     Parent Loop BB29_148 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	madd	x13, x11, x27, x9
	ldr	w14, [x13, #16]!
	cmp	w14, #1
	b.eq	LBB29_176
; %bb.179:                              ; %bb12.i638
                                        ;   in Loop: Header=BB29_178 Depth=3
	cmp	w14, #2
	b.ne	LBB29_213
; %bb.180:                              ; %bb3.i20.i644
                                        ;   in Loop: Header=BB29_178 Depth=3
	ldr	x14, [x13, #8]
	cmp	x14, x25
	b.ne	LBB29_177
	b	LBB29_204
LBB29_181:                              ; %bb90
                                        ;   in Loop: Header=BB29_148 Depth=2
	ldrb	w9, [sp, #496]
	tbz	w9, #0, LBB29_185
; %bb.182:                              ;   in Loop: Header=BB29_148 Depth=2
	mov	x10, #0                         ; =0x0
	ldr	x9, [sp, #504]
	ldr	x12, [x9]
	cbnz	x12, LBB29_186
	b	LBB29_243
LBB29_183:                              ; %bb3.i.i620
                                        ;   in Loop: Header=BB29_148 Depth=2
	ldr	x8, [sp, #488]
	eor	x8, x8, x25
	eor	x8, x8, x8, lsr #30
	mul	x8, x8, x5
	eor	x8, x8, x8, lsr #27
	mul	x8, x8, x4
	eor	x10, x8, x8, lsr #31
	add	x26, x0, x19
	ldr	x9, [sp, #504]
	ldr	x8, [x9]
	cbnz	x8, LBB29_175
LBB29_184:                              ;   in Loop: Header=BB29_148 Depth=2
	mov	x10, #0                         ; =0x0
	b	LBB29_215
LBB29_185:                              ; %bb3.i.i.i503
                                        ;   in Loop: Header=BB29_148 Depth=2
	ldr	x9, [sp, #488]
	eor	x9, x9, x25
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x5
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x4
	eor	x10, x9, x9, lsr #31
	ldr	x9, [sp, #504]
	ldr	x12, [x9]
	cbz	x12, LBB29_243
LBB29_186:                              ; %bb12.preheader.i.i519
                                        ;   in Loop: Header=BB29_148 Depth=2
	udiv	x11, x10, x12
	msub	x11, x11, x12, x10
	mov	x10, x11
	b	LBB29_188
LBB29_187:                              ; %bb22.i.i526
                                        ;   in Loop: Header=BB29_188 Depth=3
	add	x10, x10, #1
	cmp	x10, x12
	b.eq	LBB29_205
LBB29_188:                              ; %bb12.i.i521
                                        ;   Parent Loop BB29_129 Depth=1
                                        ;     Parent Loop BB29_148 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	madd	x13, x10, x27, x9
	ldr	w14, [x13, #16]!
	cmp	w14, #1
	b.eq	LBB29_187
; %bb.189:                              ; %bb12.i.i521
                                        ;   in Loop: Header=BB29_188 Depth=3
	cmp	w14, #2
	b.ne	LBB29_236
; %bb.190:                              ; %bb16.i.i553
                                        ;   in Loop: Header=BB29_188 Depth=3
	ldr	x13, [x13, #8]
	cmp	x13, x25
	b.ne	LBB29_187
	b	LBB29_211
LBB29_191:                              ; %bb3.i.i.i716
                                        ;   in Loop: Header=BB29_148 Depth=2
	ldr	x9, [sp, #488]
	eor	x9, x9, x25
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x5
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x4
	eor	x10, x9, x9, lsr #31
	ldr	x9, [sp, #504]
	ldr	x12, [x9]
	cbz	x12, LBB29_245
LBB29_192:                              ; %bb12.preheader.i.i732
                                        ;   in Loop: Header=BB29_148 Depth=2
	udiv	x11, x10, x12
	msub	x11, x11, x12, x10
	mov	x10, x11
	b	LBB29_194
LBB29_193:                              ; %bb20.i.i744
                                        ;   in Loop: Header=BB29_194 Depth=3
	add	x10, x10, #1
	cmp	x10, x12
	b.eq	LBB29_228
LBB29_194:                              ; %bb12.i.i734
                                        ;   Parent Loop BB29_129 Depth=1
                                        ;     Parent Loop BB29_148 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	madd	x13, x10, x27, x9
	ldr	w14, [x13, #16]!
	cmp	w14, #1
	b.eq	LBB29_193
; %bb.195:                              ; %bb12.i.i734
                                        ;   in Loop: Header=BB29_194 Depth=3
	cmp	w14, #2
	b.ne	LBB29_237
; %bb.196:                              ; %bb3.i9.i.i739
                                        ;   in Loop: Header=BB29_194 Depth=3
	ldr	x13, [x13, #8]
	cmp	x13, x25
	b.ne	LBB29_193
	b	LBB29_234
LBB29_197:                              ; %bb27.i652
                                        ;   in Loop: Header=BB29_148 Depth=2
	cbz	x12, LBB29_215
; %bb.198:                              ; %bb12.1.i654.preheader
                                        ;   in Loop: Header=BB29_148 Depth=2
	mov	x11, #0                         ; =0x0
	add	x13, x9, #16
	b	LBB29_201
LBB29_199:                              ; %bb18.1.i701
                                        ;   in Loop: Header=BB29_201 Depth=3
	cmp	x10, x8
	csel	x10, x11, x10, eq
LBB29_200:                              ; %bb26.1.i664
                                        ;   in Loop: Header=BB29_201 Depth=3
	add	x11, x11, #1
	add	x13, x13, #24
	cmp	x12, x11
	b.eq	LBB29_215
LBB29_201:                              ; %bb12.1.i654
                                        ;   Parent Loop BB29_129 Depth=1
                                        ;     Parent Loop BB29_148 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w14, [x13]
	cmp	w14, #1
	b.eq	LBB29_199
; %bb.202:                              ; %bb12.1.i654
                                        ;   in Loop: Header=BB29_201 Depth=3
	cmp	w14, #2
	b.ne	LBB29_213
; %bb.203:                              ; %bb3.i20.1.i660
                                        ;   in Loop: Header=BB29_201 Depth=3
	ldr	x14, [x13, #8]
	cmp	x14, x25
	b.ne	LBB29_200
LBB29_204:                              ; %"wf_hash_map.hash_map_exchange$instance$0ed342445dd803f3.exit.i694"
                                        ;   in Loop: Header=BB29_148 Depth=2
	ldr	x8, [x13, #16]
	mov	w9, #2                          ; =0x2
	str	w9, [x13]
	stp	x25, x26, [x13, #8]
	stp	x22, x25, [sp, #272]
	str	x8, [sp, #288]
	ldrb	w8, [sp, #276]
	ldur	q0, [x20, #216]
	stur	q0, [x3, #232]
	tbnz	w8, #0, LBB29_227
	b	LBB29_240
LBB29_205:                              ; %bb23.i.i529
                                        ;   in Loop: Header=BB29_148 Depth=2
	cbz	x11, LBB29_243
; %bb.206:                              ; %bb12.1.i.i531.preheader
                                        ;   in Loop: Header=BB29_148 Depth=2
	mov	x10, #0                         ; =0x0
	add	x12, x9, #24
	b	LBB29_208
LBB29_207:                              ; %bb22.1.i.i536
                                        ;   in Loop: Header=BB29_208 Depth=3
	add	x10, x10, #1
	add	x12, x12, #24
	cmp	x11, x10
	b.eq	LBB29_243
LBB29_208:                              ; %bb12.1.i.i531
                                        ;   Parent Loop BB29_129 Depth=1
                                        ;     Parent Loop BB29_148 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldur	w13, [x12, #-8]
	cmp	w13, #1
	b.eq	LBB29_207
; %bb.209:                              ; %bb12.1.i.i531
                                        ;   in Loop: Header=BB29_208 Depth=3
	cmp	w13, #2
	b.ne	LBB29_242
; %bb.210:                              ; %bb16.1.i.i544
                                        ;   in Loop: Header=BB29_208 Depth=3
	ldr	x13, [x12]
	cmp	x13, x25
	b.ne	LBB29_207
LBB29_211:                              ; %bb2.i564
                                        ;   in Loop: Header=BB29_148 Depth=2
	madd	x8, x10, x27, x9
	ldr	x9, [x8, #32]
	add	x10, x9, #1
	str	x10, [x8, #32]
	str	wzr, [sp, #416]
	str	x10, [sp, #424]
	strb	wzr, [sp, #432]
	ldr	x8, [sp, #520]
	madd	x8, x8, x7, x9
	add	x8, x8, #132
	b	LBB29_146
LBB29_212:                              ; %bb12.1.i.i251
                                        ;   in Loop: Header=BB29_148 Depth=2
	cbz	w13, LBB29_145
	b	LBB29_299
LBB29_213:                              ; %bb12.1.i654
                                        ;   in Loop: Header=BB29_148 Depth=2
	cbnz	w14, LBB29_299
; %bb.214:                              ; %bb17.i704
                                        ;   in Loop: Header=BB29_148 Depth=2
	cmp	x10, x8
	csel	x10, x11, x10, eq
LBB29_215:                              ; %bb1.i668
                                        ;   in Loop: Header=BB29_148 Depth=2
	cmp	x10, x8
	b.hs	LBB29_219
; %bb.216:                              ; %bb29.i675
                                        ;   in Loop: Header=BB29_148 Depth=2
	ldr	x11, [sp, #512]
	lsr	x12, x11, #14
	cbnz	x12, LBB29_219
; %bb.217:                              ; %bb32.i679
                                        ;   in Loop: Header=BB29_148 Depth=2
	add	x8, x11, #1
	str	x8, [sp, #512]
	madd	x10, x10, x27, x9
	ldr	w11, [x10, #16]
	ldp	x9, x8, [x10, #24]
	mov	w12, #2                         ; =0x2
	str	w12, [x10, #16]
	stp	x25, x26, [x10, #24]
	cmp	w11, #2
	b.hs	LBB29_238
; %bb.218:                              ; %"wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit327.thread"
                                        ;   in Loop: Header=BB29_148 Depth=2
	stp	xzr, xzr, [x3, #208]
	stur	xzr, [x3, #224]
	b	LBB29_293
LBB29_219:                              ; %bb4.i302
                                        ;   in Loop: Header=BB29_148 Depth=2
	lsr	x9, x8, #14
	cbz	x9, LBB29_221
LBB29_220:                              ; %bb73.thread
                                        ;   in Loop: Header=BB29_148 Depth=2
	stp	x22, x25, [sp, #272]
	strb	w22, [sp, #276]
	str	x26, [sp, #288]
	ldur	q0, [x20, #216]
	stur	q0, [x3, #232]
	b	LBB29_227
LBB29_221:                              ; %bb7.i306
                                        ;   in Loop: Header=BB29_148 Depth=2
	cmp	x8, #2, lsl #12                 ; =8192
	mov	w9, #8192                       ; =0x2000
	csel	x9, x8, x9, lo
	lsl	x9, x9, #1
	cmp	x8, #0
	csinc	x1, x9, xzr, ne
	cmp	x1, x8
	b.ls	LBB29_224
; %bb.222:                              ; %"wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit.i315"
                                        ;   in Loop: Header=BB29_148 Depth=2
	add	x2, x3, #424
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	bl	_wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	add	x3, sp, #64
	cbz	w0, LBB29_224
; %bb.223:                              ; %"wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit.i315"
                                        ;   in Loop: Header=BB29_148 Depth=2
	cmp	w0, #1
	mov	x4, #4587                       ; =0x11eb
	movk	x4, #4913, lsl #16
	movk	x4, #18875, lsl #32
	movk	x4, #38096, lsl #48
	mov	x5, #58809                      ; =0xe5b9
	movk	x5, #7396, lsl #16
	movk	x5, #18285, lsl #32
	movk	x5, #48984, lsl #48
	ldr	x17, [sp, #24]                  ; 8-byte Folded Reload
	mov	w6, #131                        ; =0x83
	mov	w7, #17161                      ; =0x4309
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	b.eq	LBB29_220
	b	LBB29_299
LBB29_224:                              ; %"wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit327"
                                        ;   in Loop: Header=BB29_148 Depth=2
	add	x0, x3, #208
	add	x4, x3, #424
	ldr	x1, [sp, #56]                   ; 8-byte Folded Reload
	mov	x2, x25
	mov	x3, x26
	bl	_wf_hash_map.hash_map_try_put$instance$fde7c6722a8b0dad
	add	x3, sp, #64
	ldr	w8, [sp, #272]
	mov	x4, #4587                       ; =0x11eb
	movk	x4, #4913, lsl #16
	movk	x4, #18875, lsl #32
	movk	x4, #38096, lsl #48
	mov	x5, #58809                      ; =0xe5b9
	movk	x5, #7396, lsl #16
	movk	x5, #18285, lsl #32
	movk	x5, #48984, lsl #48
	ldr	x17, [sp, #24]                  ; 8-byte Folded Reload
	mov	w6, #131                        ; =0x83
	mov	w7, #17161                      ; =0x4309
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	cbz	w8, LBB29_293
; %bb.225:                              ; %"wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit327"
                                        ;   in Loop: Header=BB29_148 Depth=2
	cmp	w8, #1
	b.ne	LBB29_299
; %bb.226:                              ; %bb73
                                        ;   in Loop: Header=BB29_148 Depth=2
	ldrb	w8, [sp, #276]
	ldur	q0, [x20, #216]
	stur	q0, [x3, #232]
	tbz	w8, #0, LBB29_240
LBB29_227:                              ; %bb76
                                        ;   in Loop: Header=BB29_148 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB29_241
LBB29_228:                              ; %bb21.i.i747
                                        ;   in Loop: Header=BB29_148 Depth=2
	cbz	x11, LBB29_245
; %bb.229:                              ; %bb12.1.i.i749.preheader
                                        ;   in Loop: Header=BB29_148 Depth=2
	mov	x10, #0                         ; =0x0
	add	x12, x9, #24
	b	LBB29_231
LBB29_230:                              ; %bb20.1.i.i759
                                        ;   in Loop: Header=BB29_231 Depth=3
	add	x10, x10, #1
	add	x12, x12, #24
	cmp	x11, x10
	b.eq	LBB29_245
LBB29_231:                              ; %bb12.1.i.i749
                                        ;   Parent Loop BB29_129 Depth=1
                                        ;     Parent Loop BB29_148 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldur	w13, [x12, #-8]
	cmp	w13, #1
	b.eq	LBB29_230
; %bb.232:                              ; %bb12.1.i.i749
                                        ;   in Loop: Header=BB29_231 Depth=3
	cmp	w13, #2
	b.ne	LBB29_244
; %bb.233:                              ; %bb3.i9.1.i.i754
                                        ;   in Loop: Header=BB29_231 Depth=3
	ldr	x13, [x12]
	cmp	x13, x25
	b.ne	LBB29_230
LBB29_234:                              ; %bb81
                                        ;   in Loop: Header=BB29_148 Depth=2
	madd	x9, x10, x27, x9
	ldr	x10, [x9, #32]
	str	w22, [x9, #16]
	stp	xzr, xzr, [x9, #24]
	sub	x8, x8, #1
	str	x8, [sp, #512]
	str	w22, [sp, #312]
	stp	x25, x10, [sp, #320]
	ldr	q0, [x20, #256]
	str	q0, [x3, #272]
	ldr	x8, [sp, #520]
	ldp	x9, x10, [sp, #336]
	madd	x8, x8, x6, x9
	madd	x8, x8, x6, x10
	add	x11, x8, #131
	str	x11, [sp, #520]
	ldr	x10, [sp, #488]
	ldrb	w9, [sp, #496]
	ldr	x25, [sp, #568]
	tbnz	w9, #0, LBB29_246
LBB29_235:                              ; %bb3.i.i.i371
                                        ;   in Loop: Header=BB29_148 Depth=2
	eor	x8, x25, x10
	eor	x8, x8, x8, lsr #30
	mul	x8, x8, x5
	eor	x8, x8, x8, lsr #27
	mul	x8, x8, x4
	eor	x12, x8, x8, lsr #31
	ldr	x8, [sp, #504]
	ldr	x14, [x8]
	cbnz	x14, LBB29_247
	b	LBB29_261
LBB29_236:                              ; %bb12.i.i521
                                        ;   in Loop: Header=BB29_148 Depth=2
	cbz	w14, LBB29_243
	b	LBB29_299
LBB29_237:                              ; %bb12.i.i734
                                        ;   in Loop: Header=BB29_148 Depth=2
	cbz	w14, LBB29_245
	b	LBB29_299
LBB29_238:                              ; %bb32.i679
                                        ;   in Loop: Header=BB29_148 Depth=2
	b.ne	LBB29_299
; %bb.239:                              ;   in Loop: Header=BB29_148 Depth=2
	stp	x22, x9, [sp, #272]
	str	x8, [sp, #288]
	ldrb	w8, [sp, #276]
	ldur	q0, [x20, #216]
	stur	q0, [x3, #232]
	tbnz	w8, #0, LBB29_227
LBB29_240:                              ;   in Loop: Header=BB29_148 Depth=2
	mov	w8, #1                          ; =0x1
LBB29_241:                              ; %bb74
                                        ;   in Loop: Header=BB29_148 Depth=2
	ldr	x9, [sp, #520]
	madd	x8, x9, x6, x8
	ldp	x9, x10, [sp, #296]
	b	LBB29_298
LBB29_242:                              ; %bb12.1.i.i531
                                        ;   in Loop: Header=BB29_148 Depth=2
	cbnz	w13, LBB29_299
LBB29_243:                              ; %bb3.i559
                                        ;   in Loop: Header=BB29_148 Depth=2
	str	w22, [sp, #416]
	str	xzr, [sp, #424]
	mul	x8, x8, x6
	strb	wzr, [sp, #432]
	b	LBB29_146
LBB29_244:                              ; %bb12.1.i.i749
                                        ;   in Loop: Header=BB29_148 Depth=2
	cbnz	w13, LBB29_299
LBB29_245:                              ; %bb82
                                        ;   in Loop: Header=BB29_148 Depth=2
	str	wzr, [sp, #312]
	stp	xzr, xzr, [x20, #256]
	ldr	x8, [sp, #520]
	mul	x11, x8, x6
	str	x11, [sp, #520]
	ldr	x10, [sp, #488]
	ldrb	w9, [sp, #496]
	ldr	x25, [sp, #568]
	tbz	w9, #0, LBB29_235
LBB29_246:                              ;   in Loop: Header=BB29_148 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	x8, [sp, #504]
	ldr	x14, [x8]
	cbz	x14, LBB29_261
LBB29_247:                              ; %bb12.preheader.i.i387
                                        ;   in Loop: Header=BB29_148 Depth=2
	udiv	x13, x12, x14
	msub	x13, x13, x14, x12
	mov	x12, x13
	b	LBB29_249
LBB29_248:                              ; %bb22.i.i394
                                        ;   in Loop: Header=BB29_249 Depth=3
	add	x12, x12, #1
	cmp	x12, x14
	b.eq	LBB29_252
LBB29_249:                              ; %bb12.i.i389
                                        ;   Parent Loop BB29_129 Depth=1
                                        ;     Parent Loop BB29_148 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	madd	x15, x12, x27, x8
	ldr	w16, [x15, #16]!
	cmp	w16, #1
	b.eq	LBB29_248
; %bb.250:                              ; %bb12.i.i389
                                        ;   in Loop: Header=BB29_249 Depth=3
	cmp	w16, #2
	b.ne	LBB29_259
; %bb.251:                              ; %bb16.i.i421
                                        ;   in Loop: Header=BB29_249 Depth=3
	ldr	x15, [x15, #8]
	cmp	x15, x25
	b.ne	LBB29_248
	b	LBB29_258
LBB29_252:                              ; %bb23.i.i397
                                        ;   in Loop: Header=BB29_148 Depth=2
	cbz	x13, LBB29_261
; %bb.253:                              ; %bb12.1.i.i399.preheader
                                        ;   in Loop: Header=BB29_148 Depth=2
	mov	x12, #0                         ; =0x0
	add	x14, x8, #24
	b	LBB29_255
LBB29_254:                              ; %bb22.1.i.i404
                                        ;   in Loop: Header=BB29_255 Depth=3
	add	x12, x12, #1
	add	x14, x14, #24
	cmp	x13, x12
	b.eq	LBB29_261
LBB29_255:                              ; %bb12.1.i.i399
                                        ;   Parent Loop BB29_129 Depth=1
                                        ;     Parent Loop BB29_148 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldur	w15, [x14, #-8]
	cmp	w15, #1
	b.eq	LBB29_254
; %bb.256:                              ; %bb12.1.i.i399
                                        ;   in Loop: Header=BB29_255 Depth=3
	cmp	w15, #2
	b.ne	LBB29_260
; %bb.257:                              ; %bb16.1.i.i412
                                        ;   in Loop: Header=BB29_255 Depth=3
	ldr	x15, [x14]
	cmp	x15, x25
	b.ne	LBB29_254
LBB29_258:                              ; %bb2.i433
                                        ;   in Loop: Header=BB29_148 Depth=2
	madd	x12, x12, x27, x8
	ldr	x12, [x12, #32]
	str	wzr, [sp, #352]
	str	x12, [sp, #360]
	strb	wzr, [sp, #368]
	madd	x11, x11, x7, x12
	add	x11, x11, #131
	b	LBB29_262
LBB29_259:                              ; %bb12.i.i389
                                        ;   in Loop: Header=BB29_148 Depth=2
	cbz	w16, LBB29_261
	b	LBB29_299
LBB29_260:                              ; %bb12.1.i.i399
                                        ;   in Loop: Header=BB29_148 Depth=2
	cbnz	w15, LBB29_299
LBB29_261:                              ; %bb3.i428
                                        ;   in Loop: Header=BB29_148 Depth=2
	str	w22, [sp, #352]
	str	xzr, [sp, #360]
	mul	x11, x11, x6
	strb	wzr, [sp, #368]
LBB29_262:                              ; %wf_map_cost_lookup_result.exit440
                                        ;   in Loop: Header=BB29_148 Depth=2
	str	x11, [sp, #520]
	add	x26, x0, x19
	eor	x10, x25, x10
	eor	x10, x10, x10, lsr #30
	mul	x10, x10, x5
	eor	x10, x10, x10, lsr #27
	mul	x10, x10, x4
	eor	x10, x10, x10, lsr #31
	tst	w9, #0x1
	csel	x10, xzr, x10, ne
	ldr	x9, [x8]
	cbz	x9, LBB29_269
; %bb.263:                              ; %bb12.preheader.i786
                                        ;   in Loop: Header=BB29_148 Depth=2
	udiv	x11, x10, x9
	msub	x12, x11, x9, x10
	mov	x11, x12
	mov	x10, x9
	b	LBB29_266
LBB29_264:                              ; %bb18.i860
                                        ;   in Loop: Header=BB29_266 Depth=3
	cmp	x10, x9
	csel	x10, x11, x10, eq
LBB29_265:                              ; %bb26.i798
                                        ;   in Loop: Header=BB29_266 Depth=3
	add	x11, x11, #1
	cmp	x11, x9
	b.eq	LBB29_270
LBB29_266:                              ; %bb12.i788
                                        ;   Parent Loop BB29_129 Depth=1
                                        ;     Parent Loop BB29_148 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	madd	x13, x11, x27, x8
	ldr	w14, [x13, #16]!
	cmp	w14, #1
	b.eq	LBB29_264
; %bb.267:                              ; %bb12.i788
                                        ;   in Loop: Header=BB29_266 Depth=3
	cmp	w14, #2
	b.ne	LBB29_278
; %bb.268:                              ; %bb3.i20.i794
                                        ;   in Loop: Header=BB29_266 Depth=3
	ldr	x14, [x13, #8]
	cmp	x14, x25
	b.ne	LBB29_265
	b	LBB29_277
LBB29_269:                              ;   in Loop: Header=BB29_148 Depth=2
	mov	x10, #0                         ; =0x0
	b	LBB29_280
LBB29_270:                              ; %bb27.i802
                                        ;   in Loop: Header=BB29_148 Depth=2
	cbz	x12, LBB29_280
; %bb.271:                              ; %bb12.1.i804.preheader
                                        ;   in Loop: Header=BB29_148 Depth=2
	mov	x11, #0                         ; =0x0
	add	x13, x8, #16
	b	LBB29_274
LBB29_272:                              ; %bb18.1.i851
                                        ;   in Loop: Header=BB29_274 Depth=3
	cmp	x10, x9
	csel	x10, x11, x10, eq
LBB29_273:                              ; %bb26.1.i814
                                        ;   in Loop: Header=BB29_274 Depth=3
	add	x11, x11, #1
	add	x13, x13, #24
	cmp	x12, x11
	b.eq	LBB29_280
LBB29_274:                              ; %bb12.1.i804
                                        ;   Parent Loop BB29_129 Depth=1
                                        ;     Parent Loop BB29_148 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w14, [x13]
	cmp	w14, #1
	b.eq	LBB29_272
; %bb.275:                              ; %bb12.1.i804
                                        ;   in Loop: Header=BB29_274 Depth=3
	cmp	w14, #2
	b.ne	LBB29_278
; %bb.276:                              ; %bb3.i20.1.i810
                                        ;   in Loop: Header=BB29_274 Depth=3
	ldr	x14, [x13, #8]
	cmp	x14, x25
	b.ne	LBB29_273
LBB29_277:                              ; %"wf_hash_map.hash_map_exchange$instance$0ed342445dd803f3.exit.i844"
                                        ;   in Loop: Header=BB29_148 Depth=2
	ldr	x8, [x13, #16]
	mov	w9, #2                          ; =0x2
	str	w9, [x13]
	stp	x25, x26, [x13, #8]
	stp	x22, x25, [sp, #376]
	str	x8, [sp, #392]
	ldrb	w8, [x3, #316]
	ldr	q0, [x20, #320]
	str	q0, [x3, #336]
	tbnz	w8, #0, LBB29_292
	b	LBB29_296
LBB29_278:                              ; %bb12.1.i804
                                        ;   in Loop: Header=BB29_148 Depth=2
	cbnz	w14, LBB29_299
; %bb.279:                              ; %bb17.i854
                                        ;   in Loop: Header=BB29_148 Depth=2
	cmp	x10, x9
	csel	x10, x11, x10, eq
LBB29_280:                              ; %bb1.i818
                                        ;   in Loop: Header=BB29_148 Depth=2
	cmp	x10, x9
	b.hs	LBB29_284
; %bb.281:                              ; %bb29.i825
                                        ;   in Loop: Header=BB29_148 Depth=2
	ldr	x11, [sp, #512]
	lsr	x12, x11, #14
	cbnz	x12, LBB29_284
; %bb.282:                              ; %bb32.i829
                                        ;   in Loop: Header=BB29_148 Depth=2
	add	x9, x11, #1
	str	x9, [sp, #512]
	madd	x10, x10, x27, x8
	ldr	w11, [x10, #16]
	ldp	x9, x8, [x10, #24]
	mov	w12, #2                         ; =0x2
	str	w12, [x10, #16]
	stp	x25, x26, [x10, #24]
	cmp	w11, #2
	b.hs	LBB29_294
; %bb.283:                              ; %"wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit475.thread"
                                        ;   in Loop: Header=BB29_148 Depth=2
	stp	xzr, xzr, [x3, #312]
	str	xzr, [x3, #328]
	b	LBB29_293
LBB29_284:                              ; %bb4.i450
                                        ;   in Loop: Header=BB29_148 Depth=2
	lsr	x8, x9, #14
	cbz	x8, LBB29_286
LBB29_285:                              ; %bb85.thread
                                        ;   in Loop: Header=BB29_148 Depth=2
	stp	x22, x25, [sp, #376]
	strb	w22, [x3, #316]
	str	x26, [sp, #392]
	ldr	q0, [x20, #320]
	str	q0, [x3, #336]
	b	LBB29_292
LBB29_286:                              ; %bb7.i454
                                        ;   in Loop: Header=BB29_148 Depth=2
	cmp	x9, #2, lsl #12                 ; =8192
	mov	w8, #8192                       ; =0x2000
	csel	x8, x9, x8, lo
	lsl	x8, x8, #1
	cmp	x9, #0
	csinc	x1, x8, xzr, ne
	cmp	x1, x9
	b.ls	LBB29_289
; %bb.287:                              ; %"wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit.i463"
                                        ;   in Loop: Header=BB29_148 Depth=2
	add	x2, x3, #424
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	bl	_wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	add	x3, sp, #64
	cbz	w0, LBB29_289
; %bb.288:                              ; %"wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit.i463"
                                        ;   in Loop: Header=BB29_148 Depth=2
	cmp	w0, #1
	mov	x4, #4587                       ; =0x11eb
	movk	x4, #4913, lsl #16
	movk	x4, #18875, lsl #32
	movk	x4, #38096, lsl #48
	mov	x5, #58809                      ; =0xe5b9
	movk	x5, #7396, lsl #16
	movk	x5, #18285, lsl #32
	movk	x5, #48984, lsl #48
	ldr	x17, [sp, #24]                  ; 8-byte Folded Reload
	mov	w6, #131                        ; =0x83
	mov	w7, #17161                      ; =0x4309
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	b.eq	LBB29_285
	b	LBB29_299
LBB29_289:                              ; %"wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit475"
                                        ;   in Loop: Header=BB29_148 Depth=2
	add	x0, x3, #312
	add	x4, x3, #424
	ldr	x1, [sp, #56]                   ; 8-byte Folded Reload
	mov	x2, x25
	mov	x3, x26
	bl	_wf_hash_map.hash_map_try_put$instance$fde7c6722a8b0dad
	add	x3, sp, #64
	ldr	w8, [sp, #376]
	mov	x4, #4587                       ; =0x11eb
	movk	x4, #4913, lsl #16
	movk	x4, #18875, lsl #32
	movk	x4, #38096, lsl #48
	mov	x5, #58809                      ; =0xe5b9
	movk	x5, #7396, lsl #16
	movk	x5, #18285, lsl #32
	movk	x5, #48984, lsl #48
	ldr	x17, [sp, #24]                  ; 8-byte Folded Reload
	mov	w6, #131                        ; =0x83
	mov	w7, #17161                      ; =0x4309
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	cbz	w8, LBB29_293
; %bb.290:                              ; %"wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit475"
                                        ;   in Loop: Header=BB29_148 Depth=2
	cmp	w8, #1
	b.ne	LBB29_299
; %bb.291:                              ; %bb85
                                        ;   in Loop: Header=BB29_148 Depth=2
	ldrb	w8, [x3, #316]
	ldr	q0, [x20, #320]
	str	q0, [x3, #336]
	tbz	w8, #0, LBB29_296
LBB29_292:                              ; %bb88
                                        ;   in Loop: Header=BB29_148 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB29_297
LBB29_293:                              ; %bb72
                                        ;   in Loop: Header=BB29_148 Depth=2
	ldr	x8, [sp, #520]
	mul	x8, x8, x6
	b	LBB29_146
LBB29_294:                              ; %bb32.i829
                                        ;   in Loop: Header=BB29_148 Depth=2
	b.ne	LBB29_299
; %bb.295:                              ;   in Loop: Header=BB29_148 Depth=2
	stp	x22, x9, [sp, #376]
	str	x8, [sp, #392]
	ldrb	w8, [x3, #316]
	ldr	q0, [x20, #320]
	str	q0, [x3, #336]
	tbnz	w8, #0, LBB29_292
LBB29_296:                              ;   in Loop: Header=BB29_148 Depth=2
	mov	w8, #1                          ; =0x1
LBB29_297:                              ; %bb86
                                        ;   in Loop: Header=BB29_148 Depth=2
	ldr	x9, [sp, #520]
	madd	x8, x9, x6, x8
	ldp	x9, x10, [sp, #400]
LBB29_298:                              ; %bb92.sink.split
                                        ;   in Loop: Header=BB29_148 Depth=2
	add	x8, x9, x8
	madd	x8, x8, x6, x10
	b	LBB29_146
LBB29_299:                              ; %invalid.tag.b2
	bl	_abort
LBB29_300:                              ; %window.block.oom.v1.i.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_map_cost_library_policy$instance$4250cb78d3f44027
lCPI30_0:
	.quad	42                              ; 0x2a
	.quad	43                              ; 0x2b
lCPI30_1:
	.quad	44                              ; 0x2c
	.quad	45                              ; 0x2d
lCPI30_2:
	.quad	46                              ; 0x2e
	.quad	47                              ; 0x2f
lCPI30_3:
	.quad	48                              ; 0x30
	.quad	49                              ; 0x31
lCPI30_4:
	.quad	50                              ; 0x32
	.quad	51                              ; 0x33
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_map_cost_library_policy$instance$4250cb78d3f44027
	.p2align	2
_wf_map_cost_library_policy$instance$4250cb78d3f44027: ; @"wf_map_cost_library_policy$instance$4250cb78d3f44027"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #1904
	.cfi_def_cfa_offset 2000
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
	mov	x8, #31765                      ; =0x7c15
	movk	x8, #32586, lsl #16
	movk	x8, #31161, lsl #32
	movk	x8, #40503, lsl #48
	eor	x8, x0, x8
	cmp	x1, #0
	cset	w9, ne
	str	x8, [sp, #304]
	strb	w9, [sp, #312]
	mov	w0, #832                        ; =0x340
	bl	_malloc
	cbz	x0, LBB30_2
; %bb.1:                                ; %bb1.i.i.i
	str	wzr, [x0, #16]
	add	x8, x0, #296
	add	x9, x0, #568
	str	xzr, [x0, #824]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9]
	stp	q0, q0, [x9, #32]
	stp	q0, q0, [x9, #64]
	stp	q0, q0, [x9, #96]
	stp	q0, q0, [x9, #128]
	stp	q0, q0, [x9, #160]
	stp	q0, q0, [x9, #192]
	stp	q0, q0, [x9, #224]
	stur	q0, [x0, #248]
	stur	q0, [x0, #232]
	stur	q0, [x0, #216]
	stur	q0, [x0, #200]
	stur	q0, [x0, #184]
	stur	q0, [x0, #168]
	stur	q0, [x0, #152]
	stur	q0, [x0, #136]
	stur	q0, [x0, #120]
	stur	q0, [x0, #104]
	stur	q0, [x0, #88]
	stur	q0, [x0, #72]
	stur	q0, [x0, #56]
	stur	q0, [x0, #40]
	mov	x9, x0
	str	q0, [x9, #24]!
	stur	q0, [x9, #252]
	str	q0, [x9, #240]
	stur	q0, [x8, #252]
	stp	q0, q0, [x8, #224]
	stp	q0, q0, [x8, #192]
	stp	q0, q0, [x8, #160]
	stp	q0, q0, [x8, #128]
	stp	q0, q0, [x8, #96]
	stp	q0, q0, [x8, #64]
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8]
	mov	w8, #3                          ; =0x3
	dup.2d	v0, x8
	str	q0, [x0]
	stp	x0, xzr, [sp, #288]
	add	x8, x19, #1
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	add	x24, x19, #2
	add	x25, x19, #3
	stp	x25, x24, [sp, #128]            ; 16-byte Folded Spill
	add	x26, x19, #4
	add	x27, x19, #5
	stp	x27, x26, [sp, #112]            ; 16-byte Folded Spill
	add	x28, x19, #6
	add	x30, x19, #7
	stp	x30, x28, [sp, #96]             ; 16-byte Folded Spill
	add	x9, x19, #8
	add	x8, x19, #9
	stp	x8, x9, [sp, #8]                ; 16-byte Folded Spill
	add	x21, x19, #10
	add	x22, x19, #11
	add	x23, x19, #12
	stp	x23, x22, [sp, #232]            ; 16-byte Folded Spill
	add	x20, x19, #13
	add	x7, x19, #14
	add	x6, x19, #15
	add	x5, x19, #16
	stp	x6, x5, [sp, #184]              ; 16-byte Folded Spill
	add	x4, x19, #17
	add	x3, x19, #18
	add	x2, x19, #19
	add	x8, x19, #20
	str	x8, [sp, #248]                  ; 8-byte Folded Spill
	add	x9, x19, #21
	add	x10, x19, #22
	stp	x10, x9, [sp, #48]              ; 16-byte Folded Spill
	add	x11, x19, #23
	add	x12, x19, #24
	stp	x12, x11, [sp, #32]             ; 16-byte Folded Spill
	add	x13, x19, #25
	str	x13, [sp, #24]                  ; 8-byte Folded Spill
	add	x14, x19, #26
	add	x15, x19, #27
	stp	x15, x14, [sp, #216]            ; 16-byte Folded Spill
	add	x16, x19, #28
	add	x17, x19, #29
	stp	x17, x16, [sp, #200]            ; 16-byte Folded Spill
	add	x0, x19, #30
	add	x1, x19, #31
	stp	x1, x0, [sp, #152]              ; 16-byte Folded Spill
	stp	x19, xzr, [sp, #256]
	stp	xzr, xzr, [sp, #272]
	str	x19, [sp, #1648]
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	x8, [sp, #1656]
	str	x24, [sp, #1664]
	str	x25, [sp, #1672]
	str	x26, [sp, #1680]
	str	x27, [sp, #1688]
	str	x28, [sp, #1696]
	str	x30, [sp, #1704]
	ldp	x25, x24, [sp, #8]              ; 16-byte Folded Reload
	str	x24, [sp, #1712]
	str	x25, [sp, #1720]
	str	x21, [sp, #1728]
	mov	x28, x21
	stp	x21, x20, [sp, #72]             ; 16-byte Folded Spill
	str	x22, [sp, #1736]
	str	x23, [sp, #1744]
	str	x20, [sp, #1752]
	mov	x27, x20
	str	x7, [sp, #1760]
	mov	x26, x7
	str	x7, [sp, #88]                   ; 8-byte Folded Spill
	str	x6, [sp, #1768]
	str	x5, [sp, #1776]
	str	x4, [sp, #1784]
	mov	x23, x4
	str	x4, [sp, #144]                  ; 8-byte Folded Spill
	str	x3, [sp, #1792]
	mov	x22, x3
	stp	x3, x2, [sp, #168]              ; 16-byte Folded Spill
	str	x2, [sp, #1800]
	mov	x21, x2
	ldr	x20, [sp, #248]                 ; 8-byte Folded Reload
	str	x20, [sp, #1808]
	str	x9, [sp, #1816]
	str	x10, [sp, #1824]
	str	x11, [sp, #1832]
	str	x12, [sp, #1840]
	str	x13, [sp, #1848]
	str	x14, [sp, #1856]
	str	x15, [sp, #1864]
	str	x16, [sp, #1872]
	str	x17, [sp, #1880]
	str	x0, [sp, #1888]
	str	x1, [sp, #1896]
	add	x0, sp, #1376
	add	x1, sp, #288
	add	x3, sp, #1648
	add	x4, sp, #304
	mov	w2, #1                          ; =0x1
	bl	_wf_hash_map.hash_map_put$instance$8d5197e2f00c3b07
	add	x0, sp, #1376
	add	x1, sp, #256
	bl	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	x8, [sp, #1648]
	add	x8, x19, #32
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	ldp	x9, x10, [sp, #128]             ; 16-byte Folded Reload
	str	x10, [sp, #1656]
	str	x9, [sp, #1664]
	ldp	x9, x10, [sp, #112]             ; 16-byte Folded Reload
	str	x10, [sp, #1672]
	str	x9, [sp, #1680]
	ldp	x9, x10, [sp, #96]              ; 16-byte Folded Reload
	str	x10, [sp, #1688]
	str	x9, [sp, #1696]
	str	x24, [sp, #1704]
	str	x25, [sp, #1712]
	str	x28, [sp, #1720]
	ldp	x9, x10, [sp, #232]             ; 16-byte Folded Reload
	str	x10, [sp, #1728]
	str	x9, [sp, #1736]
	str	x27, [sp, #1744]
	str	x26, [sp, #1752]
	ldp	x10, x9, [sp, #184]             ; 16-byte Folded Reload
	str	x10, [sp, #1760]
	str	x9, [sp, #1768]
	str	x23, [sp, #1776]
	str	x22, [sp, #1784]
	str	x21, [sp, #1792]
	str	x20, [sp, #1800]
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	str	x21, [sp, #1808]
	str	x22, [sp, #1816]
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	str	x23, [sp, #1824]
	str	x24, [sp, #1832]
	ldr	x25, [sp, #24]                  ; 8-byte Folded Reload
	str	x25, [sp, #1840]
	ldp	x27, x26, [sp, #216]            ; 16-byte Folded Reload
	str	x26, [sp, #1848]
	str	x27, [sp, #1856]
	ldp	x20, x28, [sp, #200]            ; 16-byte Folded Reload
	str	x28, [sp, #1864]
	str	x20, [sp, #1872]
	ldp	x9, x10, [sp, #152]             ; 16-byte Folded Reload
	str	x10, [sp, #1880]
	str	x9, [sp, #1888]
	str	x8, [sp, #1896]
	add	x0, sp, #1376
	add	x1, sp, #288
	add	x3, sp, #1648
	add	x4, sp, #304
	mov	w2, #3                          ; =0x3
	bl	_wf_hash_map.hash_map_put$instance$8d5197e2f00c3b07
	add	x0, sp, #1376
	add	x1, sp, #256
	bl	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
	ldp	x8, x9, [sp, #128]              ; 16-byte Folded Reload
	str	x9, [sp, #1648]
	str	x8, [sp, #1656]
	ldp	x8, x9, [sp, #112]              ; 16-byte Folded Reload
	str	x9, [sp, #1664]
	str	x8, [sp, #1672]
	ldp	x8, x9, [sp, #96]               ; 16-byte Folded Reload
	str	x9, [sp, #1680]
	str	x8, [sp, #1688]
	ldp	x8, x9, [sp, #8]                ; 16-byte Folded Reload
	str	x9, [sp, #1696]
	str	x8, [sp, #1704]
	add	x9, x19, #33
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	str	x8, [sp, #1712]
	ldp	x8, x10, [sp, #232]             ; 16-byte Folded Reload
	str	x10, [sp, #1720]
	str	x8, [sp, #1728]
	ldp	x10, x8, [sp, #80]              ; 16-byte Folded Reload
	str	x10, [sp, #1736]
	str	x8, [sp, #1744]
	ldp	x10, x8, [sp, #184]             ; 16-byte Folded Reload
	str	x10, [sp, #1752]
	str	x8, [sp, #1760]
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	str	x8, [sp, #1768]
	ldp	x10, x8, [sp, #168]             ; 16-byte Folded Reload
	str	x10, [sp, #1776]
	str	x8, [sp, #1784]
	ldr	x8, [sp, #248]                  ; 8-byte Folded Reload
	str	x8, [sp, #1792]
	str	x21, [sp, #1800]
	str	x22, [sp, #1808]
	str	x23, [sp, #1816]
	str	x24, [sp, #1824]
	str	x25, [sp, #1832]
	str	x26, [sp, #1840]
	str	x27, [sp, #1848]
	str	x28, [sp, #1856]
	str	x20, [sp, #1864]
	ldp	x21, x20, [sp, #152]            ; 16-byte Folded Reload
	str	x20, [sp, #1872]
	str	x21, [sp, #1880]
	ldr	x23, [sp, #64]                  ; 8-byte Folded Reload
	str	x23, [sp, #1888]
	str	x9, [sp, #1896]
	mov	x22, x9
	add	x0, sp, #1376
	add	x1, sp, #288
	add	x3, sp, #1648
	add	x4, sp, #304
	mov	w2, #5                          ; =0x5
	bl	_wf_hash_map.hash_map_put$instance$8d5197e2f00c3b07
	add	x0, sp, #1376
	add	x1, sp, #256
	bl	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	str	x8, [sp, #1120]
	ldp	x8, x9, [sp, #232]              ; 16-byte Folded Reload
	str	x9, [sp, #1128]
	str	x8, [sp, #1136]
	add	x9, x19, #34
	ldp	x11, x8, [sp, #80]              ; 16-byte Folded Reload
	str	x11, [sp, #1144]
	add	x10, x19, #35
	stp	x10, x9, [sp, #232]             ; 16-byte Folded Spill
	str	x8, [sp, #1152]
	add	x11, x19, #36
	ldr	x8, [sp, #184]                  ; 8-byte Folded Reload
	str	x8, [sp, #1160]
	add	x12, x19, #37
	ldr	x8, [sp, #192]                  ; 8-byte Folded Reload
	str	x8, [sp, #1168]
	add	x13, x19, #38
	stp	x12, x13, [sp, #184]            ; 16-byte Folded Spill
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	str	x8, [sp, #1176]
	add	x14, x19, #39
	stp	x11, x14, [sp, #136]            ; 16-byte Folded Spill
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	str	x8, [sp, #1184]
	add	x15, x19, #40
	ldr	x8, [sp, #176]                  ; 8-byte Folded Reload
	str	x8, [sp, #1192]
	add	x16, x19, #41
	stp	x15, x16, [sp, #168]            ; 16-byte Folded Spill
	ldr	x8, [sp, #248]                  ; 8-byte Folded Reload
	str	x8, [sp, #1200]
	ldp	x25, x24, [sp, #48]             ; 16-byte Folded Reload
	str	x24, [sp, #1208]
	str	x25, [sp, #1216]
	ldp	x27, x26, [sp, #32]             ; 16-byte Folded Reload
	str	x26, [sp, #1224]
	str	x27, [sp, #1232]
	ldr	x28, [sp, #24]                  ; 8-byte Folded Reload
	str	x28, [sp, #1240]
	ldr	x8, [sp, #224]                  ; 8-byte Folded Reload
	str	x8, [sp, #1248]
	ldr	x8, [sp, #216]                  ; 8-byte Folded Reload
	str	x8, [sp, #1256]
	ldr	x8, [sp, #208]                  ; 8-byte Folded Reload
	str	x8, [sp, #1264]
	ldr	x8, [sp, #200]                  ; 8-byte Folded Reload
	str	x8, [sp, #1272]
	str	x20, [sp, #1280]
	str	x21, [sp, #1288]
	str	x23, [sp, #1296]
	str	x22, [sp, #1304]
	str	x9, [sp, #1312]
	str	x10, [sp, #1320]
	str	x11, [sp, #1328]
	str	x12, [sp, #1336]
	str	x13, [sp, #1344]
	str	x14, [sp, #1352]
	str	x15, [sp, #1360]
	str	x16, [sp, #1368]
	add	x0, sp, #848
	add	x1, sp, #288
	add	x3, sp, #1120
	add	x4, sp, #304
	mov	w2, #1                          ; =0x1
	bl	_wf_hash_map.hash_map_put$instance$8d5197e2f00c3b07
	add	x0, sp, #848
	add	x1, sp, #256
	bl	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
	dup.2d	v0, x19
Lloh32:
	adrp	x8, lCPI30_0@PAGE
Lloh33:
	ldr	q1, [x8, lCPI30_0@PAGEOFF]
	add.2d	v1, v0, v1
Lloh34:
	adrp	x8, lCPI30_1@PAGE
Lloh35:
	ldr	q2, [x8, lCPI30_1@PAGEOFF]
	add.2d	v2, v0, v2
Lloh36:
	adrp	x8, lCPI30_2@PAGE
Lloh37:
	ldr	q3, [x8, lCPI30_2@PAGEOFF]
	add.2d	v3, v0, v3
Lloh38:
	adrp	x8, lCPI30_3@PAGE
Lloh39:
	ldr	q4, [x8, lCPI30_3@PAGEOFF]
	add.2d	v4, v0, v4
Lloh40:
	adrp	x8, lCPI30_4@PAGE
Lloh41:
	ldr	q5, [x8, lCPI30_4@PAGEOFF]
	add.2d	v0, v0, v5
	ldr	x8, [sp, #248]                  ; 8-byte Folded Reload
	str	x8, [sp, #592]
	str	x24, [sp, #600]
	str	x25, [sp, #608]
	str	x26, [sp, #616]
	str	x27, [sp, #624]
	str	x28, [sp, #632]
	ldp	x8, x9, [sp, #216]              ; 16-byte Folded Reload
	str	x9, [sp, #640]
	str	x8, [sp, #648]
	ldp	x8, x9, [sp, #200]              ; 16-byte Folded Reload
	str	x9, [sp, #656]
	str	x8, [sp, #664]
	str	x20, [sp, #672]
	str	x21, [sp, #680]
	str	x23, [sp, #688]
	str	x22, [sp, #696]
	ldp	x8, x9, [sp, #232]              ; 16-byte Folded Reload
	str	x9, [sp, #704]
	str	x8, [sp, #712]
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	str	x8, [sp, #720]
	ldp	x9, x8, [sp, #184]              ; 16-byte Folded Reload
	str	x9, [sp, #728]
	str	x8, [sp, #736]
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	str	x8, [sp, #744]
	ldp	x9, x8, [sp, #168]              ; 16-byte Folded Reload
	str	x9, [sp, #752]
	str	x8, [sp, #760]
	stp	q1, q2, [sp, #768]
	stp	q3, q4, [sp, #800]
	str	q0, [sp, #832]
	add	x0, sp, #320
	add	x1, sp, #288
	add	x3, sp, #592
	add	x4, sp, #304
	mov	w2, #7                          ; =0x7
	bl	_wf_hash_map.hash_map_put$instance$8d5197e2f00c3b07
	add	x0, sp, #320
	add	x1, sp, #256
	bl	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
	add	x0, sp, #288
	add	x1, sp, #256
	bl	_wf_hash_map.hash_map_free$instance$72d84b2e6d0b7146
	ldp	x8, x9, [sp, #256]
	ldp	x10, x11, [sp, #272]
	eor	x8, x8, x8, lsr #30
	mov	x12, #58809                     ; =0xe5b9
	movk	x12, #7396, lsl #16
	movk	x12, #18285, lsl #32
	movk	x12, #48984, lsl #48
	mul	x8, x8, x12
	eor	x8, x8, x8, lsr #27
	mov	x13, #4587                      ; =0x11eb
	movk	x13, #4913, lsl #16
	movk	x13, #18875, lsl #32
	movk	x13, #38096, lsl #48
	mul	x8, x8, x13
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x12
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x13
	eor	x12, x9, x8
	mov	x13, #31765                     ; =0x7c15
	movk	x13, #32586, lsl #16
	movk	x13, #31161, lsl #32
	movk	x13, #40503, lsl #48
	mul	x11, x11, x13
	eor	x10, x10, x11
	eor	x10, x10, x12, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	add	sp, sp, #1904
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB30_2:                                ; %window.block.oom.v1.i.i.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpAdrp	Lloh38, Lloh40
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpAdrp	Lloh36, Lloh38
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpAdrp	Lloh34, Lloh36
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpAdrp	Lloh32, Lloh34
	.loh AdrpLdr	Lloh32, Lloh33
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_map_cost_library_trace$instance$4250cb78d3f44027
lCPI31_0:
	.quad	1                               ; 0x1
	.quad	2                               ; 0x2
lCPI31_1:
	.quad	3                               ; 0x3
	.quad	4                               ; 0x4
lCPI31_2:
	.quad	5                               ; 0x5
	.quad	6                               ; 0x6
lCPI31_3:
	.quad	7                               ; 0x7
	.quad	8                               ; 0x8
lCPI31_4:
	.quad	9                               ; 0x9
	.quad	10                              ; 0xa
lCPI31_5:
	.quad	11                              ; 0xb
	.quad	12                              ; 0xc
lCPI31_6:
	.quad	13                              ; 0xd
	.quad	14                              ; 0xe
lCPI31_7:
	.quad	15                              ; 0xf
	.quad	16                              ; 0x10
lCPI31_8:
	.quad	17                              ; 0x11
	.quad	18                              ; 0x12
lCPI31_9:
	.quad	19                              ; 0x13
	.quad	20                              ; 0x14
lCPI31_10:
	.quad	21                              ; 0x15
	.quad	22                              ; 0x16
lCPI31_11:
	.quad	23                              ; 0x17
	.quad	24                              ; 0x18
lCPI31_12:
	.quad	25                              ; 0x19
	.quad	26                              ; 0x1a
lCPI31_13:
	.quad	27                              ; 0x1b
	.quad	28                              ; 0x1c
lCPI31_14:
	.quad	29                              ; 0x1d
	.quad	30                              ; 0x1e
lCPI31_15:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI31_16:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI31_17:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI31_18:
	.quad	8                               ; 0x8
	.quad	9                               ; 0x9
lCPI31_19:
	.quad	10                              ; 0xa
	.quad	11                              ; 0xb
lCPI31_20:
	.quad	12                              ; 0xc
	.quad	13                              ; 0xd
lCPI31_21:
	.quad	14                              ; 0xe
	.quad	15                              ; 0xf
lCPI31_22:
	.quad	16                              ; 0x10
	.quad	17                              ; 0x11
lCPI31_23:
	.quad	18                              ; 0x12
	.quad	19                              ; 0x13
lCPI31_24:
	.quad	20                              ; 0x14
	.quad	21                              ; 0x15
lCPI31_25:
	.quad	22                              ; 0x16
	.quad	23                              ; 0x17
lCPI31_26:
	.quad	24                              ; 0x18
	.quad	25                              ; 0x19
lCPI31_27:
	.quad	26                              ; 0x1a
	.quad	27                              ; 0x1b
lCPI31_28:
	.quad	28                              ; 0x1c
	.quad	29                              ; 0x1d
lCPI31_29:
	.quad	30                              ; 0x1e
	.quad	31                              ; 0x1f
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_map_cost_library_trace$instance$4250cb78d3f44027
	.p2align	2
_wf_map_cost_library_trace$instance$4250cb78d3f44027: ; @"wf_map_cost_library_trace$instance$4250cb78d3f44027"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	mov	w9, #7808                       ; =0x1e80
Lloh42:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh43:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #3712
	.cfi_def_cfa_offset 7904
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x23, x4
	mov	x22, x3
	str	x2, [sp, #104]                  ; 8-byte Folded Spill
	mov	x20, x1
	mov	x21, x0
	add	x10, sp, #704
	mov	x8, #31765                      ; =0x7c15
	movk	x8, #32586, lsl #16
	movk	x8, #31161, lsl #32
	movk	x8, #40503, lsl #48
	eor	x8, x3, x8
	cmp	x5, #0
	cset	w9, ne
	mov	w11, #5968                      ; =0x1750
	str	x8, [sp, #6664]
	add	x19, sp, #704
	strb	w9, [x10, x11]
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB31_201
; %bb.1:                                ; %bb1.i.i.i
	stp	xzr, x21, [x0]
	cbz	x21, LBB31_5
; %bb.2:                                ; %bb5.i.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
	movi.2d	v0, #0000000000000000
LBB31_3:                                ; %bb5.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	q0, q0, [x9]
	stp	q0, q0, [x9, #32]
	stp	q0, q0, [x9, #64]
	stp	q0, q0, [x9, #96]
	stp	q0, q0, [x9, #128]
	stp	q0, q0, [x9, #160]
	stp	q0, q0, [x9, #192]
	stp	q0, q0, [x9, #224]
	str	xzr, [x9, #256]
	add	x9, x9, #272
	cmp	x21, x8
	b.ne	LBB31_3
; %bb.4:                                ; %bb4.bb7_crit_edge.i.i.i
	str	x21, [x0]
LBB31_5:                                ; %"wf_hash_map.hash_map_new$instance$0e108827ecbbe374.exit"
	str	x0, [sp, #6680]
	str	xzr, [sp, #6688]
	str	x22, [sp, #8]                   ; 8-byte Folded Spill
	str	x22, [sp, #6696]
	str	xzr, [sp, #6704]
	str	xzr, [sp, #6720]
	str	xzr, [sp, #6712]
	str	x20, [sp, #696]                 ; 8-byte Folded Spill
	cbz	x20, LBB31_11
; %bb.6:                                ; %bb2.lr.ph
Lloh44:
	adrp	x8, lCPI31_0@PAGE
Lloh45:
	ldr	q0, [x8, lCPI31_0@PAGEOFF]
	str	q0, [sp, #672]                  ; 16-byte Folded Spill
	add	x19, x19, #792
Lloh46:
	adrp	x8, lCPI31_1@PAGE
Lloh47:
	ldr	q0, [x8, lCPI31_1@PAGEOFF]
	str	q0, [sp, #656]                  ; 16-byte Folded Spill
	add	x20, sp, #704
Lloh48:
	adrp	x8, lCPI31_2@PAGE
Lloh49:
	ldr	q0, [x8, lCPI31_2@PAGEOFF]
	str	q0, [sp, #640]                  ; 16-byte Folded Spill
	mov	w22, #1                         ; =0x1
Lloh50:
	adrp	x8, lCPI31_3@PAGE
Lloh51:
	ldr	q0, [x8, lCPI31_3@PAGEOFF]
	str	q0, [sp, #624]                  ; 16-byte Folded Spill
Lloh52:
	adrp	x8, lCPI31_4@PAGE
Lloh53:
	ldr	q0, [x8, lCPI31_4@PAGEOFF]
	str	q0, [sp, #608]                  ; 16-byte Folded Spill
Lloh54:
	adrp	x8, lCPI31_5@PAGE
Lloh55:
	ldr	q0, [x8, lCPI31_5@PAGEOFF]
	str	q0, [sp, #592]                  ; 16-byte Folded Spill
Lloh56:
	adrp	x8, lCPI31_6@PAGE
Lloh57:
	ldr	q0, [x8, lCPI31_6@PAGEOFF]
	str	q0, [sp, #576]                  ; 16-byte Folded Spill
Lloh58:
	adrp	x8, lCPI31_7@PAGE
Lloh59:
	ldr	q0, [x8, lCPI31_7@PAGEOFF]
	str	q0, [sp, #560]                  ; 16-byte Folded Spill
Lloh60:
	adrp	x8, lCPI31_8@PAGE
Lloh61:
	ldr	q0, [x8, lCPI31_8@PAGEOFF]
	str	q0, [sp, #544]                  ; 16-byte Folded Spill
Lloh62:
	adrp	x8, lCPI31_9@PAGE
Lloh63:
	ldr	q0, [x8, lCPI31_9@PAGEOFF]
	str	q0, [sp, #528]                  ; 16-byte Folded Spill
Lloh64:
	adrp	x8, lCPI31_10@PAGE
Lloh65:
	ldr	q0, [x8, lCPI31_10@PAGEOFF]
	str	q0, [sp, #512]                  ; 16-byte Folded Spill
Lloh66:
	adrp	x8, lCPI31_11@PAGE
Lloh67:
	ldr	q0, [x8, lCPI31_11@PAGEOFF]
	str	q0, [sp, #496]                  ; 16-byte Folded Spill
	mov	w25, #131                       ; =0x83
Lloh68:
	adrp	x8, lCPI31_12@PAGE
Lloh69:
	ldr	q0, [x8, lCPI31_12@PAGEOFF]
	str	q0, [sp, #480]                  ; 16-byte Folded Spill
	mov	w24, #1                         ; =0x1
Lloh70:
	adrp	x8, lCPI31_13@PAGE
Lloh71:
	ldr	q0, [x8, lCPI31_13@PAGEOFF]
	str	q0, [sp, #464]                  ; 16-byte Folded Spill
	ldr	x26, [sp, #696]                 ; 8-byte Folded Reload
Lloh72:
	adrp	x8, lCPI31_14@PAGE
Lloh73:
	ldr	q0, [x8, lCPI31_14@PAGEOFF]
	str	q0, [sp, #448]                  ; 16-byte Folded Spill
	ldr	x27, [sp, #8]                   ; 8-byte Folded Reload
	b	LBB31_8
LBB31_7:                                ; %bb6
                                        ;   in Loop: Header=BB31_8 Depth=1
	ldr	x8, [sp, #6696]
	mul	x8, x8, x25
	str	x8, [sp, #6696]
	add	x27, x27, #1
	add	x24, x24, #2
	subs	x26, x26, #1
	b.eq	LBB31_11
LBB31_8:                                ; %bb2
                                        ; =>This Inner Loop Header: Depth=1
	add	x8, x27, #31
	str	x27, [sp, #704]
	dup.2d	v0, x27
	ldr	q1, [sp, #672]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #457
	stur	q1, [x9, #255]
	ldr	q1, [sp, #656]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #473
	stur	q1, [x9, #255]
	ldr	q1, [sp, #640]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #489
	stur	q1, [x9, #255]
	ldr	q1, [sp, #624]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #505
	stur	q1, [x9, #255]
	ldr	q1, [sp, #608]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #521
	stur	q1, [x9, #255]
	ldr	q1, [sp, #592]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #537
	stur	q1, [x9, #255]
	ldr	q1, [sp, #576]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #553
	stur	q1, [x9, #255]
	ldr	q1, [sp, #560]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #569
	stur	q1, [x9, #255]
	ldr	q1, [sp, #544]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #704
	stur	q1, [x9, #136]
	ldr	q1, [sp, #528]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x9, #152]
	ldr	q1, [sp, #512]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x9, #168]
	ldr	q1, [sp, #496]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x9, #184]
	ldr	q1, [sp, #480]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x9, #200]
	ldr	q1, [sp, #464]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x9, #216]
	ldr	q1, [sp, #448]                  ; 16-byte Folded Reload
	add.2d	v0, v0, v1
	stur	q0, [x9, #232]
	str	x8, [sp, #952]
	add	x0, x9, #256
	mov	w8, #5976                       ; =0x1758
	add	x1, x9, x8
	add	x3, sp, #704
	mov	w8, #5960                       ; =0x1748
	add	x4, x9, x8
	mov	x2, x24
	bl	_wf_hash_map.hash_map_put$instance$28da32efc51c2b65
	ldr	w8, [sp, #960]
	cbz	w8, LBB31_7
; %bb.9:                                ; %bb2
                                        ;   in Loop: Header=BB31_8 Depth=1
	cmp	w8, #1
	b.ne	LBB31_82
; %bb.10:                               ; %bb7
                                        ;   in Loop: Header=BB31_8 Depth=1
	add	x8, sp, #704
	ldrb	w28, [x8, #260]
	add	x0, x8, #528
	add	x1, x20, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	ldr	x8, [sp, #6696]
	cmp	w28, #0
	cinc	x9, x22, ne
	madd	x8, x8, x25, x9
	str	x8, [sp, #6696]
	ldr	x9, [sp, #1232]
	ldp	q1, q0, [x20, #368]
	stp	q1, q0, [x19, #96]
	ldp	q1, q0, [x20, #336]
	stp	q1, q0, [x19, #64]
	ldp	q1, q0, [x20, #432]
	stp	q1, q0, [x19, #160]
	ldp	q1, q0, [x20, #400]
	stp	q1, q0, [x19, #128]
	ldp	q1, q0, [x20, #496]
	stp	q1, q0, [x19, #224]
	ldp	q1, q0, [x20, #464]
	stp	q1, q0, [x19, #192]
	ldp	q1, q0, [x20, #304]
	stp	q1, q0, [x19, #32]
	ldp	q0, q1, [x20, #272]
	stp	q0, q1, [x19]
	ldr	x10, [sp, #1496]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1504]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1512]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1520]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1528]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1536]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1544]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1552]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1560]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1568]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1576]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1584]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1592]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1600]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1608]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1616]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1624]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1632]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1640]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1648]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1656]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1664]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1672]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1680]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1688]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1696]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1704]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1712]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1720]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1728]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1736]
	add	x8, x8, x10
	madd	x8, x9, x25, x8
	ldr	x9, [sp, #1744]
	madd	x8, x8, x25, x9
	str	x8, [sp, #6696]
	add	x27, x27, #1
	add	x24, x24, #2
	subs	x26, x26, #1
	b.ne	LBB31_8
LBB31_11:                               ; %bb12.preheader
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	ldr	x24, [sp, #696]                 ; 8-byte Folded Reload
	cbz	x8, LBB31_200
; %bb.12:                               ; %bb13.lr.ph
	lsl	x8, x21, #1
	cmp	x21, #0
	csinc	x27, x8, xzr, ne
	cmp	x23, #1
	csel	x20, x24, xzr, eq
	add	x16, sp, #704
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2656
	add	x9, x8, #800
	add	x8, x8, #536
	stp	x8, x9, [sp, #368]              ; 16-byte Folded Spill
	cmp	x23, #5
	b.ne	LBB31_83
; %bb.13:                               ; %bb13.us.preheader
	mov	x26, #0                         ; =0x0
	add	x9, sp, #704
	add	x8, x9, #1584
	str	x8, [sp, #416]                  ; 8-byte Folded Spill
	add	x28, x9, #1896
	add	x23, x9, #2152
Lloh74:
	adrp	x8, lCPI31_0@PAGE
Lloh75:
	ldr	q0, [x8, lCPI31_0@PAGEOFF]
	str	q0, [sp, #656]                  ; 16-byte Folded Spill
	add	x8, x9, #2688
	str	x8, [sp, #400]                  ; 8-byte Folded Spill
	sub	x8, x24, x24, lsr #1
Lloh76:
	adrp	x9, lCPI31_1@PAGE
Lloh77:
	ldr	q0, [x9, lCPI31_1@PAGEOFF]
	str	q0, [sp, #640]                  ; 16-byte Folded Spill
Lloh78:
	adrp	x9, lCPI31_2@PAGE
Lloh79:
	ldr	q0, [x9, lCPI31_2@PAGEOFF]
	str	q0, [sp, #624]                  ; 16-byte Folded Spill
	cmp	x8, #1
	csinc	x8, x8, xzr, hi
	str	x8, [sp, #672]                  ; 8-byte Folded Spill
Lloh80:
	adrp	x8, lCPI31_3@PAGE
Lloh81:
	ldr	q0, [x8, lCPI31_3@PAGEOFF]
	str	q0, [sp, #608]                  ; 16-byte Folded Spill
Lloh82:
	adrp	x8, lCPI31_4@PAGE
Lloh83:
	ldr	q0, [x8, lCPI31_4@PAGEOFF]
	str	q0, [sp, #592]                  ; 16-byte Folded Spill
Lloh84:
	adrp	x8, lCPI31_5@PAGE
Lloh85:
	ldr	q0, [x8, lCPI31_5@PAGEOFF]
	str	q0, [sp, #576]                  ; 16-byte Folded Spill
Lloh86:
	adrp	x8, lCPI31_6@PAGE
Lloh87:
	ldr	q0, [x8, lCPI31_6@PAGEOFF]
	str	q0, [sp, #560]                  ; 16-byte Folded Spill
	add	x25, x16, #1064
Lloh88:
	adrp	x8, lCPI31_7@PAGE
Lloh89:
	ldr	q0, [x8, lCPI31_7@PAGEOFF]
	str	q0, [sp, #544]                  ; 16-byte Folded Spill
	add	x8, x16, #2168
	str	x8, [sp, #384]                  ; 8-byte Folded Spill
Lloh90:
	adrp	x8, lCPI31_8@PAGE
Lloh91:
	ldr	q0, [x8, lCPI31_8@PAGEOFF]
	str	q0, [sp, #528]                  ; 16-byte Folded Spill
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	add	x19, x8, x24
Lloh92:
	adrp	x8, lCPI31_9@PAGE
Lloh93:
	ldr	q0, [x8, lCPI31_9@PAGEOFF]
	str	q0, [sp, #512]                  ; 16-byte Folded Spill
	mov	w20, #131                       ; =0x83
Lloh94:
	adrp	x8, lCPI31_10@PAGE
Lloh95:
	ldr	q0, [x8, lCPI31_10@PAGEOFF]
	str	q0, [sp, #496]                  ; 16-byte Folded Spill
Lloh96:
	adrp	x8, lCPI31_11@PAGE
Lloh97:
	ldr	q0, [x8, lCPI31_11@PAGEOFF]
	str	q0, [sp, #480]                  ; 16-byte Folded Spill
Lloh98:
	adrp	x8, lCPI31_12@PAGE
Lloh99:
	ldr	q0, [x8, lCPI31_12@PAGEOFF]
	str	q0, [sp, #464]                  ; 16-byte Folded Spill
Lloh100:
	adrp	x8, lCPI31_13@PAGE
Lloh101:
	ldr	q0, [x8, lCPI31_13@PAGEOFF]
	str	q0, [sp, #448]                  ; 16-byte Folded Spill
Lloh102:
	adrp	x8, lCPI31_14@PAGE
Lloh103:
	ldr	q0, [x8, lCPI31_14@PAGEOFF]
	str	q0, [sp, #432]                  ; 16-byte Folded Spill
	mov	w27, #272                       ; =0x110
	b	LBB31_15
LBB31_14:                               ;   in Loop: Header=BB31_15 Depth=1
	ldr	x24, [sp, #696]                 ; 8-byte Folded Reload
	ldr	x26, [sp, #336]                 ; 8-byte Folded Reload
	ldr	x19, [sp, #352]                 ; 8-byte Folded Reload
	add	x19, x19, x24
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	cmp	x26, x8
	b.eq	LBB31_200
LBB31_15:                               ; %bb13.us
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB31_19 Depth 2
                                        ;       Child Loop BB31_27 Depth 3
                                        ;       Child Loop BB31_33 Depth 3
                                        ;     Child Loop BB31_48 Depth 2
                                        ;       Child Loop BB31_53 Depth 3
                                        ;       Child Loop BB31_59 Depth 3
                                        ;     Child Loop BB31_67 Depth 2
	str	x19, [sp, #352]                 ; 8-byte Folded Spill
	cbz	x24, LBB31_39
; %bb.16:                               ; %bb20.us.preheader
                                        ;   in Loop: Header=BB31_15 Depth=1
	mov	x19, #0                         ; =0x0
	add	x21, sp, #704
	mov	w22, #5968                      ; =0x1750
	b	LBB31_19
LBB31_17:                               ; %bb12.i.i.us
                                        ;   in Loop: Header=BB31_19 Depth=2
	cbnz	w15, LBB31_82
LBB31_18:                               ; %bb3.i64.us
                                        ;   in Loop: Header=BB31_19 Depth=2
	mov	w10, #1                         ; =0x1
	str	w10, [sp, #2544]
	str	xzr, [sp, #2552]
	mul	x8, x8, x20
	strb	wzr, [sp, #2560]
	str	x8, [sp, #6696]
	add	x19, x19, #1
	ldr	x8, [sp, #672]                  ; 8-byte Folded Reload
	cmp	x19, x8
	b.eq	LBB31_38
LBB31_19:                               ; %bb20.us
                                        ;   Parent Loop BB31_15 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB31_27 Depth 3
                                        ;       Child Loop BB31_33 Depth 3
	mov	w8, #1                          ; =0x1
	orr	x8, x8, x19, lsl #2
	str	x8, [sp, #6728]
	add	x0, x21, #1048
	mov	w8, #5976                       ; =0x1758
	add	x1, x21, x8
	mov	w8, #6024                       ; =0x1788
	add	x2, x21, x8
	mov	w8, #5960                       ; =0x1748
	add	x3, x21, x8
	bl	_wf_hash_map.hash_map_remove$instance$28da32efc51c2b65
	ldr	w8, [sp, #1752]
	cmp	w8, #1
	b.eq	LBB31_23
; %bb.20:                               ; %bb20.us
                                        ;   in Loop: Header=BB31_19 Depth=2
	cbnz	w8, LBB31_82
; %bb.21:                               ; %bb25.us
                                        ;   in Loop: Header=BB31_19 Depth=2
	ldr	x8, [sp, #6696]
	mul	x8, x8, x20
	str	x8, [sp, #6696]
	ldrb	w9, [x21, x22]
	tbnz	w9, #0, LBB31_24
LBB31_22:                               ; %bb3.i.i.i.us
                                        ;   in Loop: Header=BB31_19 Depth=2
	ldr	x9, [sp, #6664]
	ldr	x10, [sp, #6728]
	eor	x9, x10, x9
	eor	x9, x9, x9, lsr #30
	mov	x10, #58809                     ; =0xe5b9
	movk	x10, #7396, lsl #16
	movk	x10, #18285, lsl #32
	movk	x10, #48984, lsl #48
	mul	x9, x9, x10
	eor	x9, x9, x9, lsr #27
	mov	x10, #4587                      ; =0x11eb
	movk	x10, #4913, lsl #16
	movk	x10, #18875, lsl #32
	movk	x10, #38096, lsl #48
	mul	x9, x9, x10
	eor	x10, x9, x9, lsr #31
	ldr	x9, [sp, #6680]
	ldr	x13, [x9]
	cbnz	x13, LBB31_25
	b	LBB31_18
LBB31_23:                               ; %bb24.us
                                        ;   in Loop: Header=BB31_19 Depth=2
	add	x0, x21, #1320
	add	x8, sp, #704
	add	x1, x8, #1056
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	ldr	x8, [sp, #6696]
	ldr	x9, [sp, #2024]
	ldp	q1, q0, [x25, #32]
	ldr	x10, [sp, #416]                 ; 8-byte Folded Reload
	stp	q1, q0, [x10, #32]
	ldp	q1, q0, [x25, #96]
	stp	q1, q0, [x10, #96]
	ldp	q1, q0, [x25, #64]
	stp	q1, q0, [x10, #64]
	ldp	q1, q0, [x25, #160]
	stp	q1, q0, [x10, #160]
	ldp	q1, q0, [x25, #128]
	stp	q1, q0, [x10, #128]
	ldp	q1, q0, [x25, #224]
	stp	q1, q0, [x10, #224]
	ldp	q1, q0, [x25, #192]
	stp	q1, q0, [x10, #192]
	ldp	q1, q0, [x25]
	stp	q1, q0, [x10]
	ldr	x10, [sp, #2528]
	madd	x8, x8, x20, x10
	ldr	x10, [sp, #2288]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2296]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2304]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2312]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2320]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2328]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2336]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2344]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2352]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2360]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2368]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2376]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2384]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2392]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2400]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2408]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2416]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2424]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2432]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2440]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2448]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2456]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2464]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2472]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2480]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2488]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2496]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2504]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2512]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #2520]
	madd	x9, x9, x20, x10
	madd	x8, x9, x20, x8
	ldr	x9, [sp, #2536]
	madd	x8, x8, x20, x9
	add	x8, x8, #131
	str	x8, [sp, #6696]
	ldrb	w9, [x21, x22]
	tbz	w9, #0, LBB31_22
LBB31_24:                               ;   in Loop: Header=BB31_19 Depth=2
	mov	x10, #0                         ; =0x0
	ldr	x9, [sp, #6680]
	ldr	x13, [x9]
	cbz	x13, LBB31_18
LBB31_25:                               ; %bb12.preheader.i.i.us
                                        ;   in Loop: Header=BB31_19 Depth=2
	udiv	x11, x10, x13
	msub	x11, x11, x13, x10
	ldr	x12, [sp, #6728]
	mov	x10, x11
	b	LBB31_27
LBB31_26:                               ; %bb22.i.i.us
                                        ;   in Loop: Header=BB31_27 Depth=3
	add	x10, x10, #1
	cmp	x10, x13
	b.eq	LBB31_30
LBB31_27:                               ; %bb12.i.i.us
                                        ;   Parent Loop BB31_15 Depth=1
                                        ;     Parent Loop BB31_19 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	madd	x14, x10, x27, x9
	ldr	w15, [x14, #16]!
	cmp	w15, #1
	b.eq	LBB31_26
; %bb.28:                               ; %bb12.i.i.us
                                        ;   in Loop: Header=BB31_27 Depth=3
	cmp	w15, #2
	b.ne	LBB31_17
; %bb.29:                               ; %bb16.i.i.us
                                        ;   in Loop: Header=BB31_27 Depth=3
	ldr	x14, [x14, #8]
	cmp	x14, x12
	b.ne	LBB31_26
	b	LBB31_36
LBB31_30:                               ; %bb23.i.i.us
                                        ;   in Loop: Header=BB31_19 Depth=2
	cbz	x11, LBB31_18
; %bb.31:                               ; %bb12.1.i.i.us.preheader
                                        ;   in Loop: Header=BB31_19 Depth=2
	mov	x10, #0                         ; =0x0
	add	x13, x9, #24
	b	LBB31_33
LBB31_32:                               ; %bb22.1.i.i.us
                                        ;   in Loop: Header=BB31_33 Depth=3
	add	x10, x10, #1
	add	x13, x13, #272
	cmp	x11, x10
	b.eq	LBB31_18
LBB31_33:                               ; %bb12.1.i.i.us
                                        ;   Parent Loop BB31_15 Depth=1
                                        ;     Parent Loop BB31_19 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldur	w14, [x13, #-8]
	cmp	w14, #1
	b.eq	LBB31_32
; %bb.34:                               ; %bb12.1.i.i.us
                                        ;   in Loop: Header=BB31_33 Depth=3
	cmp	w14, #2
	b.ne	LBB31_37
; %bb.35:                               ; %bb16.1.i.i.us
                                        ;   in Loop: Header=BB31_33 Depth=3
	ldr	x14, [x13]
	cmp	x14, x12
	b.ne	LBB31_32
LBB31_36:                               ; %bb2.i66.us
                                        ;   in Loop: Header=BB31_19 Depth=2
	madd	x10, x10, x27, x9
	ldr	x10, [x10, #32]
	str	wzr, [sp, #2544]
	str	x10, [sp, #2552]
	strb	wzr, [sp, #2560]
	mov	w11, #17161                     ; =0x4309
	mul	x8, x8, x11
	add	x8, x10, x8
	add	x8, x8, #131
	str	x8, [sp, #6696]
	add	x19, x19, #1
	ldr	x8, [sp, #672]                  ; 8-byte Folded Reload
	cmp	x19, x8
	b.ne	LBB31_19
	b	LBB31_38
LBB31_37:                               ; %bb12.1.i.i.us
                                        ;   in Loop: Header=BB31_19 Depth=2
	cbz	w14, LBB31_18
	b	LBB31_82
LBB31_38:                               ;   in Loop: Header=BB31_15 Depth=1
	ldr	x19, [sp, #352]                 ; 8-byte Folded Reload
	b	LBB31_40
LBB31_39:                               ; %bb13.us.bb22.us_crit_edge
                                        ;   in Loop: Header=BB31_15 Depth=1
	ldr	x9, [sp, #6680]
	add	x21, sp, #704
	mov	w22, #5968                      ; =0x1750
LBB31_40:                               ; %bb22.us
                                        ;   in Loop: Header=BB31_15 Depth=1
	ldr	x1, [x9]
	mov	w8, #5976                       ; =0x1758
	add	x0, x21, x8
	mov	w8, #5960                       ; =0x1748
	add	x2, x21, x8
	bl	_wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	str	w0, [sp, #2568]
	strb	w1, [sp, #2572]
	strb	w2, [sp, #2573]
	cbz	w0, LBB31_44
; %bb.41:                               ; %bb22.us
                                        ;   in Loop: Header=BB31_15 Depth=1
	cmp	w0, #1
	b.ne	LBB31_82
; %bb.42:                               ; %bb3.i.us
                                        ;   in Loop: Header=BB31_15 Depth=1
	ldr	x8, [sp, #6696]
	mul	x8, x8, x20
	str	x8, [sp, #6696]
	cbnz	x24, LBB31_45
LBB31_43:                               ; %bb32.preheader.us.bb93.loopexit.us_crit_edge
                                        ;   in Loop: Header=BB31_15 Depth=1
	add	x26, x26, #1
	add	x19, x19, x24
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	cmp	x26, x8
	b.ne	LBB31_15
	b	LBB31_200
LBB31_44:                               ; %bb2.i.us
                                        ;   in Loop: Header=BB31_15 Depth=1
	ldr	x8, [sp, #6696]
	mov	x9, #1                          ; =0x1
	madd	x8, x8, x20, x9
	str	x8, [sp, #6696]
	cbz	x24, LBB31_43
LBB31_45:                               ; %bb28.lr.ph.us
                                        ;   in Loop: Header=BB31_15 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	x10, [sp, #6664]
	ldrb	w11, [x21, x22]
	ldr	x12, [sp, #6680]
	add	x13, x12, #24
	b	LBB31_48
LBB31_46:                               ; %bb12.i.i228.us
                                        ;   in Loop: Header=BB31_48 Depth=2
	cbnz	w1, LBB31_82
LBB31_47:                               ; %bb3.i267.us
                                        ;   in Loop: Header=BB31_48 Depth=2
	mov	w14, #1                         ; =0x1
	str	w14, [sp, #2576]
	str	xzr, [sp, #2584]
	mul	x8, x8, x20
	strb	wzr, [sp, #2592]
	str	x8, [sp, #6696]
	add	x9, x9, #1
	cmp	x9, x24
	b.eq	LBB31_64
LBB31_48:                               ; %bb28.us
                                        ;   Parent Loop BB31_15 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB31_53 Depth 3
                                        ;       Child Loop BB31_59 Depth 3
	mov	w14, #1                         ; =0x1
	orr	x14, x14, x9, lsl #1
	str	x14, [sp, #6736]
	tbz	w11, #0, LBB31_50
; %bb.49:                               ;   in Loop: Header=BB31_48 Depth=2
	mov	x15, #0                         ; =0x0
	ldr	x17, [x12]
	cbnz	x17, LBB31_51
	b	LBB31_47
LBB31_50:                               ; %bb3.i.i.i210.us
                                        ;   in Loop: Header=BB31_48 Depth=2
	eor	x15, x10, x14
	eor	x15, x15, x15, lsr #30
	mov	x16, #58809                     ; =0xe5b9
	movk	x16, #7396, lsl #16
	movk	x16, #18285, lsl #32
	movk	x16, #48984, lsl #48
	mul	x15, x15, x16
	eor	x15, x15, x15, lsr #27
	mov	x16, #4587                      ; =0x11eb
	movk	x16, #4913, lsl #16
	movk	x16, #18875, lsl #32
	movk	x16, #38096, lsl #48
	mul	x15, x15, x16
	eor	x15, x15, x15, lsr #31
	ldr	x17, [x12]
	cbz	x17, LBB31_47
LBB31_51:                               ; %bb12.preheader.i.i226.us
                                        ;   in Loop: Header=BB31_48 Depth=2
	udiv	x16, x15, x17
	msub	x16, x16, x17, x15
	mov	x15, x16
	b	LBB31_53
LBB31_52:                               ; %bb22.i.i233.us
                                        ;   in Loop: Header=BB31_53 Depth=3
	add	x15, x15, #1
	cmp	x15, x17
	b.eq	LBB31_56
LBB31_53:                               ; %bb12.i.i228.us
                                        ;   Parent Loop BB31_15 Depth=1
                                        ;     Parent Loop BB31_48 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	madd	x0, x15, x27, x12
	ldr	w1, [x0, #16]!
	cmp	w1, #1
	b.eq	LBB31_52
; %bb.54:                               ; %bb12.i.i228.us
                                        ;   in Loop: Header=BB31_53 Depth=3
	cmp	w1, #2
	b.ne	LBB31_46
; %bb.55:                               ; %bb16.i.i260.us
                                        ;   in Loop: Header=BB31_53 Depth=3
	ldr	x0, [x0, #8]
	cmp	x0, x14
	b.ne	LBB31_52
	b	LBB31_62
LBB31_56:                               ; %bb23.i.i236.us
                                        ;   in Loop: Header=BB31_48 Depth=2
	cbz	x16, LBB31_47
; %bb.57:                               ; %bb12.1.i.i238.us.preheader
                                        ;   in Loop: Header=BB31_48 Depth=2
	mov	x15, #0                         ; =0x0
	mov	x17, x13
	b	LBB31_59
LBB31_58:                               ; %bb22.1.i.i243.us
                                        ;   in Loop: Header=BB31_59 Depth=3
	add	x15, x15, #1
	add	x17, x17, #272
	cmp	x16, x15
	b.eq	LBB31_47
LBB31_59:                               ; %bb12.1.i.i238.us
                                        ;   Parent Loop BB31_15 Depth=1
                                        ;     Parent Loop BB31_48 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldur	w0, [x17, #-8]
	cmp	w0, #1
	b.eq	LBB31_58
; %bb.60:                               ; %bb12.1.i.i238.us
                                        ;   in Loop: Header=BB31_59 Depth=3
	cmp	w0, #2
	b.ne	LBB31_63
; %bb.61:                               ; %bb16.1.i.i251.us
                                        ;   in Loop: Header=BB31_59 Depth=3
	ldr	x0, [x17]
	cmp	x0, x14
	b.ne	LBB31_58
LBB31_62:                               ; %bb2.i271.us
                                        ;   in Loop: Header=BB31_48 Depth=2
	madd	x14, x15, x27, x12
	ldr	x14, [x14, #32]
	str	wzr, [sp, #2576]
	str	x14, [sp, #2584]
	strb	wzr, [sp, #2592]
	mov	w15, #17161                     ; =0x4309
	madd	x8, x8, x15, x14
	add	x8, x8, #131
	str	x8, [sp, #6696]
	add	x9, x9, #1
	cmp	x9, x24
	b.ne	LBB31_48
	b	LBB31_64
LBB31_63:                               ; %bb12.1.i.i238.us
                                        ;   in Loop: Header=BB31_48 Depth=2
	cbz	w0, LBB31_47
	b	LBB31_82
LBB31_64:                               ; %bb33.lr.ph.us
                                        ;   in Loop: Header=BB31_15 Depth=1
	add	x26, x26, #1
	str	x26, [sp, #336]                 ; 8-byte Folded Spill
	mov	x24, x19
	mov	w22, #1                         ; =0x1
	ldr	x19, [sp, #672]                 ; 8-byte Folded Reload
	b	LBB31_67
LBB31_65:                               ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit.thread1369.us"
                                        ;   in Loop: Header=BB31_67 Depth=2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x23, #240]
	stp	q0, q0, [x23, #208]
	stp	q0, q0, [x23, #176]
	stp	q0, q0, [x23, #144]
	stp	q0, q0, [x23, #112]
	stp	q0, q0, [x23, #80]
	stp	q0, q0, [x23, #48]
	stp	q0, q0, [x23, #16]
	str	q0, [x23]
LBB31_66:                               ; %bb37.us
                                        ;   in Loop: Header=BB31_67 Depth=2
	ldr	x8, [sp, #6696]
	mul	x8, x8, x20
	str	x8, [sp, #6696]
	add	x22, x22, #4
	add	x24, x24, #2
	subs	x19, x19, #1
	b.eq	LBB31_14
LBB31_67:                               ; %bb33.us
                                        ;   Parent Loop BB31_15 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x8, x24, #31
	str	x24, [sp, #2600]
	dup.2d	v0, x24
	ldr	q1, [sp, #656]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2608]
	ldr	q1, [sp, #640]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2624]
	ldr	q1, [sp, #624]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2640]
	ldr	q1, [sp, #608]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2656]
	ldr	q1, [sp, #592]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2672]
	ldr	q1, [sp, #576]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2688]
	ldr	q1, [sp, #560]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2704]
	ldr	q1, [sp, #544]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2720]
	ldr	q1, [sp, #528]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2736]
	ldr	q1, [sp, #512]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2752]
	ldr	q1, [sp, #496]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2768]
	ldr	q1, [sp, #480]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2784]
	ldr	q1, [sp, #464]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2800]
	ldr	q1, [sp, #448]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2816]
	ldr	q1, [sp, #432]                  ; 16-byte Folded Reload
	add.2d	v0, v0, v1
	str	q0, [sp, #2832]
	str	x8, [sp, #2848]
	ldp	q0, q1, [x28, #192]
	str	q0, [sp, #6944]
	str	q1, [sp, #6960]
	ldp	q0, q1, [x28, #224]
	str	q0, [sp, #6976]
	str	q1, [sp, #6992]
	ldp	q0, q1, [x28, #128]
	str	q0, [sp, #6880]
	str	q1, [sp, #6896]
	ldp	q0, q1, [x28, #160]
	str	q0, [sp, #6912]
	str	q1, [sp, #6928]
	ldp	q0, q1, [x28, #64]
	str	q0, [sp, #6816]
	str	q1, [sp, #6832]
	ldp	q0, q1, [x28, #96]
	str	q0, [sp, #6848]
	str	q1, [sp, #6864]
	ldp	q0, q1, [x28]
	str	q0, [sp, #6752]
	str	q1, [sp, #6768]
	ldp	q0, q1, [x28, #32]
	str	q0, [sp, #6784]
	str	q1, [sp, #6800]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2656
	add	x0, x8, #256
	mov	w8, #5976                       ; =0x1758
	add	x1, x21, x8
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #2656
	mov	w8, #5960                       ; =0x1748
	add	x4, x21, x8
	mov	x2, x22
	bl	_wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65
	ldr	w8, [sp, #7008]
	cbz	w8, LBB31_65
; %bb.68:                               ; %bb33.us
                                        ;   in Loop: Header=BB31_67 Depth=2
	cmp	w8, #1
	b.ne	LBB31_82
; %bb.69:                               ; %bb2.i343.us
                                        ;   in Loop: Header=BB31_67 Depth=2
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2656
	ldrb	w21, [x8, #260]
	add	x0, x8, #528
	add	x1, x8, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	tbz	w21, #0, LBB31_72
; %bb.70:                               ; %bb4.i.us
                                        ;   in Loop: Header=BB31_67 Depth=2
	ldr	x8, [sp, #6680]
	ldr	x8, [x8]
	lsr	x9, x8, #14
	cbz	x9, LBB31_75
; %bb.71:                               ; %bb6.i.us
                                        ;   in Loop: Header=BB31_67 Depth=2
	mov	w9, #1                          ; =0x1
	str	x9, [sp, #2856]
	add	x8, sp, #704
	strb	w9, [x8, #2156]
	b	LBB31_73
LBB31_72:                               ; %bb3.i344.us
                                        ;   in Loop: Header=BB31_67 Depth=2
	mov	w8, #1                          ; =0x1
	str	x8, [sp, #2856]
LBB31_73:                               ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit.thread.us"
                                        ;   in Loop: Header=BB31_67 Depth=2
	add	x26, sp, #704
	add	x0, x26, #2160
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2656
	add	x1, x8, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
LBB31_74:                               ; %bb38.us
                                        ;   in Loop: Header=BB31_67 Depth=2
	add	x8, sp, #704
	ldrb	w21, [x8, #2156]
	add	x0, x8, #2424
	add	x1, x26, #2160
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	ldr	x8, [sp, #6696]
	cmp	w21, #0
	add	x21, sp, #704
	mov	w9, #1                          ; =0x1
	cinc	x9, x9, ne
	madd	x8, x8, x20, x9
	ldr	x9, [sp, #3128]
	ldr	x11, [sp, #384]                 ; 8-byte Folded Reload
	ldp	q1, q0, [x11, #96]
	ldr	x10, [sp, #400]                 ; 8-byte Folded Reload
	stp	q1, q0, [x10, #96]
	ldp	q1, q0, [x11, #64]
	stp	q1, q0, [x10, #64]
	ldp	q1, q0, [x11, #160]
	stp	q1, q0, [x10, #160]
	ldp	q1, q0, [x11, #128]
	stp	q1, q0, [x10, #128]
	ldp	q1, q0, [x11, #224]
	stp	q1, q0, [x10, #224]
	ldp	q1, q0, [x11, #192]
	stp	q1, q0, [x10, #192]
	ldp	q1, q0, [x11, #32]
	stp	q1, q0, [x10, #32]
	ldp	q0, q1, [x11]
	stp	q0, q1, [x10]
	ldr	x10, [sp, #3392]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3400]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3408]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3416]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3424]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3432]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3440]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3448]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3456]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3464]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3472]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3480]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3488]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3496]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3504]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3512]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3520]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3528]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3536]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3544]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3552]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3560]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3568]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3576]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3584]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3592]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3600]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3608]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3616]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3624]
	madd	x9, x9, x20, x10
	ldr	x10, [sp, #3632]
	add	x8, x8, x10
	madd	x8, x9, x20, x8
	ldr	x9, [sp, #3640]
	madd	x8, x8, x20, x9
	str	x8, [sp, #6696]
	add	x22, x22, #4
	add	x24, x24, #2
	subs	x19, x19, #1
	b.ne	LBB31_67
	b	LBB31_14
LBB31_75:                               ; %bb7.i.us
                                        ;   in Loop: Header=BB31_67 Depth=2
	cmp	x8, #2, lsl #12                 ; =8192
	mov	w9, #8192                       ; =0x2000
	csel	x9, x8, x9, lo
	lsl	x9, x9, #1
	cmp	x8, #0
	csinc	x1, x9, xzr, ne
	cmp	x1, x8
	add	x21, sp, #704
	b.ls	LBB31_79
; %bb.76:                               ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.i.us"
                                        ;   in Loop: Header=BB31_67 Depth=2
	mov	w8, #5976                       ; =0x1758
	add	x0, x21, x8
	mov	w8, #5960                       ; =0x1748
	add	x2, x21, x8
	bl	_wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	str	w0, [sp, #7544]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2656
	strb	w1, [x8, #796]
	strb	w2, [x8, #797]
	cbz	w0, LBB31_80
; %bb.77:                               ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.i.us"
                                        ;   in Loop: Header=BB31_67 Depth=2
	cmp	w0, #1
	b.ne	LBB31_82
; %bb.78:                               ; %bb18.i.us
                                        ;   in Loop: Header=BB31_67 Depth=2
	mov	w8, #1                          ; =0x1
	str	x8, [sp, #2856]
	strb	w8, [x21, #2156]
	b	LBB31_73
LBB31_79:                               ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.thread.i.us"
                                        ;   in Loop: Header=BB31_67 Depth=2
	str	wzr, [sp, #7544]
	strh	wzr, [sp, #7548]
LBB31_80:                               ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit.us"
                                        ;   in Loop: Header=BB31_67 Depth=2
	ldr	x2, [sp, #7280]
	ldp	x8, x3, [sp, #368]              ; 16-byte Folded Reload
	ldp	q0, q1, [x8, #192]
	stp	q0, q1, [x3, #192]
	ldp	q0, q1, [x8, #224]
	stp	q0, q1, [x3, #224]
	ldp	q0, q1, [x8, #128]
	stp	q0, q1, [x3, #128]
	ldp	q0, q1, [x8, #160]
	stp	q0, q1, [x3, #160]
	ldp	q0, q1, [x8, #64]
	stp	q0, q1, [x3, #64]
	ldp	q0, q1, [x8, #96]
	stp	q0, q1, [x3, #96]
	ldp	q0, q1, [x8]
	stp	q0, q1, [x3]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x3, #32]
	mov	w8, #5976                       ; =0x1758
	add	x1, x21, x8
	mov	w8, #5960                       ; =0x1748
	add	x4, x21, x8
	mov	x0, x23
	bl	_wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65
	ldr	w8, [sp, #2856]
	cbz	w8, LBB31_66
; %bb.81:                               ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit.us"
                                        ;   in Loop: Header=BB31_67 Depth=2
	cmp	w8, #1
	add	x26, sp, #704
	b.eq	LBB31_74
LBB31_82:                               ; %invalid.tag.b2
	bl	_abort
LBB31_83:                               ; %bb13.preheader
	str	x27, [sp, #16]                  ; 8-byte Folded Spill
	str	xzr, [sp, #624]                 ; 8-byte Folded Spill
	mov	w8, #4832                       ; =0x12e0
Lloh104:
	adrp	x9, lCPI31_15@PAGE
Lloh105:
	ldr	q0, [x9, lCPI31_15@PAGEOFF]
	str	q0, [sp, #592]                  ; 16-byte Folded Spill
Lloh106:
	adrp	x9, lCPI31_16@PAGE
Lloh107:
	ldr	q0, [x9, lCPI31_16@PAGEOFF]
	str	q0, [sp, #576]                  ; 16-byte Folded Spill
	mov	w9, #4296                       ; =0x10c8
Lloh108:
	adrp	x10, lCPI31_17@PAGE
Lloh109:
	ldr	q0, [x10, lCPI31_17@PAGEOFF]
	str	q0, [sp, #560]                  ; 16-byte Folded Spill
	mov	w10, #4560                      ; =0x11d0
Lloh110:
	adrp	x11, lCPI31_18@PAGE
Lloh111:
	ldr	q0, [x11, lCPI31_18@PAGEOFF]
	str	q0, [sp, #544]                  ; 16-byte Folded Spill
	mov	w11, #4840                      ; =0x12e8
Lloh112:
	adrp	x12, lCPI31_19@PAGE
Lloh113:
	ldr	q0, [x12, lCPI31_19@PAGEOFF]
	str	q0, [sp, #528]                  ; 16-byte Folded Spill
	mov	w12, #5096                      ; =0x13e8
Lloh114:
	adrp	x13, lCPI31_20@PAGE
Lloh115:
	ldr	q0, [x13, lCPI31_20@PAGEOFF]
	str	q0, [sp, #512]                  ; 16-byte Folded Spill
	mov	w13, #5368                      ; =0x14f8
Lloh116:
	adrp	x14, lCPI31_21@PAGE
Lloh117:
	ldr	q0, [x14, lCPI31_21@PAGEOFF]
	str	q0, [sp, #496]                  ; 16-byte Folded Spill
	mov	w14, #5632                      ; =0x1600
Lloh118:
	adrp	x15, lCPI31_22@PAGE
Lloh119:
	ldr	q0, [x15, lCPI31_22@PAGEOFF]
	str	q0, [sp, #480]                  ; 16-byte Folded Spill
	add	x15, sp, #704
	add	x8, x15, x8
	str	x8, [sp, #672]                  ; 8-byte Folded Spill
Lloh120:
	adrp	x8, lCPI31_23@PAGE
Lloh121:
	ldr	q0, [x8, lCPI31_23@PAGEOFF]
	str	q0, [sp, #464]                  ; 16-byte Folded Spill
	add	x8, x15, x9
	str	x8, [sp, #80]                   ; 8-byte Folded Spill
Lloh122:
	adrp	x8, lCPI31_24@PAGE
Lloh123:
	ldr	q0, [x8, lCPI31_24@PAGEOFF]
	str	q0, [sp, #448]                  ; 16-byte Folded Spill
	add	x8, x15, x10
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
Lloh124:
	adrp	x8, lCPI31_25@PAGE
Lloh125:
	ldr	q0, [x8, lCPI31_25@PAGEOFF]
	str	q0, [sp, #432]                  ; 16-byte Folded Spill
	add	x19, x15, x11
Lloh126:
	adrp	x8, lCPI31_26@PAGE
Lloh127:
	ldr	q0, [x8, lCPI31_26@PAGEOFF]
	str	q0, [sp, #416]                  ; 16-byte Folded Spill
	add	x8, x15, x12
	str	x8, [sp, #88]                   ; 8-byte Folded Spill
Lloh128:
	adrp	x8, lCPI31_27@PAGE
Lloh129:
	ldr	q0, [x8, lCPI31_27@PAGEOFF]
	str	q0, [sp, #400]                  ; 16-byte Folded Spill
	add	x8, x15, x13
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
Lloh130:
	adrp	x8, lCPI31_28@PAGE
Lloh131:
	ldr	q0, [x8, lCPI31_28@PAGEOFF]
	str	q0, [sp, #384]                  ; 16-byte Folded Spill
	add	x8, x15, x14
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
Lloh132:
	adrp	x8, lCPI31_29@PAGE
Lloh133:
	ldr	q0, [x8, lCPI31_29@PAGEOFF]
	str	q0, [sp, #352]                  ; 16-byte Folded Spill
Lloh134:
	adrp	x8, lCPI31_0@PAGE
Lloh135:
	ldr	q0, [x8, lCPI31_0@PAGEOFF]
	str	q0, [sp, #336]                  ; 16-byte Folded Spill
	add	x22, x15, #2976
Lloh136:
	adrp	x8, lCPI31_1@PAGE
Lloh137:
	ldr	q0, [x8, lCPI31_1@PAGEOFF]
	str	q0, [sp, #320]                  ; 16-byte Folded Spill
	add	x8, x15, #3232
	str	x8, [sp, #96]                   ; 8-byte Folded Spill
Lloh138:
	adrp	x8, lCPI31_2@PAGE
Lloh139:
	ldr	q0, [x8, lCPI31_2@PAGEOFF]
	str	q0, [sp, #304]                  ; 16-byte Folded Spill
	add	x8, x15, #3768
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
Lloh140:
	adrp	x8, lCPI31_3@PAGE
Lloh141:
	ldr	q0, [x8, lCPI31_3@PAGEOFF]
	str	q0, [sp, #288]                  ; 16-byte Folded Spill
	sub	x14, x23, #9
Lloh142:
	adrp	x8, lCPI31_4@PAGE
Lloh143:
	ldr	q0, [x8, lCPI31_4@PAGEOFF]
	str	q0, [sp, #272]                  ; 16-byte Folded Spill
Lloh144:
	adrp	x8, lCPI31_5@PAGE
Lloh145:
	ldr	q0, [x8, lCPI31_5@PAGEOFF]
	str	q0, [sp, #256]                  ; 16-byte Folded Spill
	add	x8, x16, #4040
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
Lloh146:
	adrp	x8, lCPI31_6@PAGE
Lloh147:
	ldr	q0, [x8, lCPI31_6@PAGEOFF]
	str	q0, [sp, #240]                  ; 16-byte Folded Spill
	mov	w8, #5112                       ; =0x13f8
	add	x8, x16, x8
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	add	x8, x16, #3248
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
Lloh148:
	adrp	x8, lCPI31_7@PAGE
Lloh149:
	ldr	q0, [x8, lCPI31_7@PAGEOFF]
	str	q0, [sp, #224]                  ; 16-byte Folded Spill
	mov	w26, #131                       ; =0x83
Lloh150:
	adrp	x8, lCPI31_8@PAGE
Lloh151:
	ldr	q0, [x8, lCPI31_8@PAGEOFF]
	str	q0, [sp, #208]                  ; 16-byte Folded Spill
Lloh152:
	adrp	x8, lCPI31_9@PAGE
Lloh153:
	ldr	q0, [x8, lCPI31_9@PAGEOFF]
	str	q0, [sp, #192]                  ; 16-byte Folded Spill
	mov	w15, #1                         ; =0x1
Lloh154:
	adrp	x8, lCPI31_10@PAGE
Lloh155:
	ldr	q0, [x8, lCPI31_10@PAGEOFF]
	str	q0, [sp, #176]                  ; 16-byte Folded Spill
Lloh156:
	adrp	x8, lCPI31_11@PAGE
Lloh157:
	ldr	q0, [x8, lCPI31_11@PAGEOFF]
	str	q0, [sp, #160]                  ; 16-byte Folded Spill
Lloh158:
	adrp	x8, lCPI31_12@PAGE
Lloh159:
	ldr	q0, [x8, lCPI31_12@PAGEOFF]
	str	q0, [sp, #144]                  ; 16-byte Folded Spill
Lloh160:
	adrp	x8, lCPI31_13@PAGE
Lloh161:
	ldr	q0, [x8, lCPI31_13@PAGEOFF]
	str	q0, [sp, #128]                  ; 16-byte Folded Spill
Lloh162:
	adrp	x8, lCPI31_14@PAGE
Lloh163:
	ldr	q0, [x8, lCPI31_14@PAGEOFF]
	str	q0, [sp, #112]                  ; 16-byte Folded Spill
	mov	w28, #272                       ; =0x110
	str	x20, [sp, #608]                 ; 8-byte Folded Spill
	str	x14, [sp, #640]                 ; 8-byte Folded Spill
	b	LBB31_85
LBB31_84:                               ; %bb93.loopexit1431
                                        ;   in Loop: Header=BB31_85 Depth=1
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #624]                  ; 8-byte Folded Reload
	cmp	x9, x8
	ldr	x24, [sp, #696]                 ; 8-byte Folded Reload
	b.eq	LBB31_200
LBB31_85:                               ; %bb13
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB31_105 Depth 2
                                        ;       Child Loop BB31_141 Depth 3
                                        ;       Child Loop BB31_156 Depth 3
                                        ;       Child Loop BB31_148 Depth 3
                                        ;       Child Loop BB31_163 Depth 3
                                        ;       Child Loop BB31_121 Depth 3
                                        ;       Child Loop BB31_127 Depth 3
	cmp	x23, #4
	b.eq	LBB31_89
; %bb.86:                               ; %bb13
                                        ;   in Loop: Header=BB31_85 Depth=1
	cmp	x23, #9
	b.eq	LBB31_89
; %bb.87:                               ; %bb13
                                        ;   in Loop: Header=BB31_85 Depth=1
	cmp	x23, #10
	add	x21, sp, #704
	add	x25, sp, #704
	b.ne	LBB31_98
; %bb.88:                               ; %bb49.thread
                                        ;   in Loop: Header=BB31_85 Depth=1
	ldr	x8, [sp, #6696]
	mov	x9, #1                          ; =0x1
	madd	x8, x8, x26, x9
	str	x8, [sp, #6696]
	b	LBB31_97
LBB31_89:                               ; %bb51
                                        ;   in Loop: Header=BB31_85 Depth=1
	ldr	x1, [sp, #16]                   ; 8-byte Folded Reload
	cmp	x1, #4, lsl #12                 ; =16384
	add	x25, sp, #704
	b.ls	LBB31_91
; %bb.90:                               ;   in Loop: Header=BB31_85 Depth=1
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	add	x21, sp, #704
	str	w0, [sp, #3648]
	strb	w1, [sp, #3652]
	strb	w2, [sp, #3653]
	cbnz	w0, LBB31_93
	b	LBB31_96
LBB31_91:                               ; %bb3.i.i
                                        ;   in Loop: Header=BB31_85 Depth=1
	ldr	x8, [sp, #6680]
	ldr	x8, [x8]
	cmp	x1, x8
	add	x21, sp, #704
	b.ls	LBB31_95
; %bb.92:                               ; %bb6.i.i
                                        ;   in Loop: Header=BB31_85 Depth=1
	mov	w8, #5976                       ; =0x1758
	add	x0, x21, x8
	mov	w8, #5960                       ; =0x1748
	add	x2, x21, x8
	bl	_wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	ldr	x14, [sp, #640]                 ; 8-byte Folded Reload
	str	w0, [sp, #3648]
	strb	w1, [sp, #3652]
	strb	w2, [sp, #3653]
	cbz	w0, LBB31_96
LBB31_93:                               ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit"
                                        ;   in Loop: Header=BB31_85 Depth=1
	cmp	w0, #1
	mov	w15, #1                         ; =0x1
	b.ne	LBB31_82
; %bb.94:                               ; %bb3.i495
                                        ;   in Loop: Header=BB31_85 Depth=1
	ldr	x8, [sp, #6696]
	mul	x8, x8, x26
	str	x8, [sp, #6696]
	cmp	x14, #2
	b.lo	LBB31_97
	b	LBB31_98
LBB31_95:                               ;   in Loop: Header=BB31_85 Depth=1
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #3648]
	strb	w1, [sp, #3652]
	strb	w2, [sp, #3653]
	cbnz	w0, LBB31_93
LBB31_96:                               ; %bb2.i500
                                        ;   in Loop: Header=BB31_85 Depth=1
	ldr	x8, [sp, #6696]
	mov	x9, #1                          ; =0x1
	madd	x8, x8, x26, x9
	mov	w15, #1                         ; =0x1
	str	x8, [sp, #6696]
	cmp	x14, #2
	b.hs	LBB31_98
LBB31_97:                               ; %bb53
                                        ;   in Loop: Header=BB31_85 Depth=1
	ldr	x9, [sp, #6680]
	ldr	x9, [x9]
	ldr	x10, [sp, #16]                  ; 8-byte Folded Reload
	cmp	x9, x10
	mul	x8, x8, x26
	cinc	x8, x8, hs
	str	x8, [sp, #6696]
LBB31_98:                               ; %bb43
                                        ;   in Loop: Header=BB31_85 Depth=1
	ldr	x8, [sp, #624]                  ; 8-byte Folded Reload
	add	x8, x8, #1
	str	x8, [sp, #624]                  ; 8-byte Folded Spill
	cbz	x24, LBB31_84
; %bb.99:                               ; %bb59.lr.ph
                                        ;   in Loop: Header=BB31_85 Depth=1
	mov	x24, #0                         ; =0x0
	ldr	x8, [sp, #696]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x10, [sp, #624]                 ; 8-byte Folded Reload
	madd	x8, x10, x8, x9
	str	x8, [sp, #656]                  ; 8-byte Folded Spill
	b	LBB31_105
LBB31_100:                              ; %bb12.i.i534
                                        ;   in Loop: Header=BB31_105 Depth=2
	cbnz	w13, LBB31_82
LBB31_101:                              ; %bb3.i573
                                        ;   in Loop: Header=BB31_105 Depth=2
	str	w15, [sp, #3656]
	str	xzr, [sp, #3664]
	strb	wzr, [sp, #3672]
LBB31_102:                              ; %bb92.sink.split
                                        ;   in Loop: Header=BB31_105 Depth=2
	ldr	x8, [sp, #6696]
	mul	x8, x8, x26
LBB31_103:                              ; %bb92.sink.split
                                        ;   in Loop: Header=BB31_105 Depth=2
	str	x8, [sp, #6696]
LBB31_104:                              ; %bb92
                                        ;   in Loop: Header=BB31_105 Depth=2
	add	x24, x24, #1
	ldr	x8, [sp, #696]                  ; 8-byte Folded Reload
	cmp	x24, x8
	b.eq	LBB31_84
LBB31_105:                              ; %bb59
                                        ;   Parent Loop BB31_85 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB31_141 Depth 3
                                        ;       Child Loop BB31_156 Depth 3
                                        ;       Child Loop BB31_148 Depth 3
                                        ;       Child Loop BB31_163 Depth 3
                                        ;       Child Loop BB31_121 Depth 3
                                        ;       Child Loop BB31_127 Depth 3
	add	x8, x24, x20
	orr	x2, x15, x8, lsl #1
	str	x2, [sp, #6744]
	cmp	x23, #3
	b.gt	LBB31_113
; %bb.106:                              ; %bb59
                                        ;   in Loop: Header=BB31_105 Depth=2
	cmp	x23, #2
	b.lo	LBB31_116
; %bb.107:                              ; %bb59
                                        ;   in Loop: Header=BB31_105 Depth=2
	b.eq	LBB31_131
; %bb.108:                              ; %bb59
                                        ;   in Loop: Header=BB31_105 Depth=2
	cmp	x23, #3
	b.ne	LBB31_104
; %bb.109:                              ; %bb78
                                        ;   in Loop: Header=BB31_105 Depth=2
	add	x0, x21, #4024
	mov	w8, #5976                       ; =0x1758
	add	x1, x21, x8
	mov	w8, #6040                       ; =0x1798
	add	x2, x21, x8
	mov	w8, #5960                       ; =0x1748
	add	x3, x21, x8
	bl	_wf_hash_map.hash_map_remove$instance$28da32efc51c2b65
	ldr	w8, [sp, #4728]
	cbz	w8, LBB31_144
; %bb.110:                              ; %bb78
                                        ;   in Loop: Header=BB31_105 Depth=2
	cmp	w8, #1
	b.ne	LBB31_82
; %bb.111:                              ; %bb81
                                        ;   in Loop: Header=BB31_105 Depth=2
	add	x1, x25, #4032
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	ldr	x8, [sp, #6696]
	ldr	x9, [sp, #5000]
	ldp	x11, x10, [sp, #64]             ; 16-byte Folded Reload
	ldp	q1, q0, [x11, #32]
	stp	q1, q0, [x10, #32]
	ldp	q1, q0, [x11, #96]
	stp	q1, q0, [x10, #96]
	ldp	q1, q0, [x11, #64]
	stp	q1, q0, [x10, #64]
	ldp	q1, q0, [x11, #160]
	stp	q1, q0, [x10, #160]
	ldp	q1, q0, [x11, #128]
	stp	q1, q0, [x10, #128]
	ldp	q1, q0, [x11, #224]
	stp	q1, q0, [x10, #224]
	ldp	q1, q0, [x11, #192]
	stp	q1, q0, [x10, #192]
	ldp	q1, q0, [x11]
	stp	q1, q0, [x10]
	ldr	x10, [sp, #5504]
	madd	x8, x8, x26, x10
	ldr	x10, [sp, #5264]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5272]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5280]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5288]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5296]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5304]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5312]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5320]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5328]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5336]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5344]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5352]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5360]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5368]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5376]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5384]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5392]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5400]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5408]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5416]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5424]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5432]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5440]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5448]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5456]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5464]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5472]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5480]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5488]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #5496]
	madd	x9, x9, x26, x10
	madd	x8, x9, x26, x8
	ldr	x9, [sp, #5512]
	madd	x8, x8, x26, x9
	add	x8, x8, #131
	str	x8, [sp, #6696]
	mov	w9, #5968                       ; =0x1750
	ldrb	w9, [x21, x9]
	ldr	x2, [sp, #6744]
	mov	w15, #1                         ; =0x1
	tbnz	w9, #0, LBB31_145
LBB31_112:                              ; %bb3.i.i.i833
                                        ;   in Loop: Header=BB31_105 Depth=2
	ldr	x9, [sp, #6664]
	eor	x9, x2, x9
	eor	x9, x9, x9, lsr #30
	mov	x10, #58809                     ; =0xe5b9
	movk	x10, #7396, lsl #16
	movk	x10, #18285, lsl #32
	movk	x10, #48984, lsl #48
	mul	x9, x9, x10
	eor	x9, x9, x9, lsr #27
	mov	x10, #4587                      ; =0x11eb
	movk	x10, #4913, lsl #16
	movk	x10, #18875, lsl #32
	movk	x10, #38096, lsl #48
	mul	x9, x9, x10
	eor	x10, x9, x9, lsr #31
	ldr	x9, [sp, #6680]
	ldr	x12, [x9]
	cbnz	x12, LBB31_146
	b	LBB31_182
LBB31_113:                              ; %bb59
                                        ;   in Loop: Header=BB31_105 Depth=2
	cmp	x14, #2
	b.lo	LBB31_116
; %bb.114:                              ; %bb59
                                        ;   in Loop: Header=BB31_105 Depth=2
	cmp	x23, #7
	b.eq	LBB31_136
; %bb.115:                              ; %bb59
                                        ;   in Loop: Header=BB31_105 Depth=2
	cmp	x23, #4
	b.ne	LBB31_104
LBB31_116:                              ; %bb66
                                        ;   in Loop: Header=BB31_105 Depth=2
	mov	w8, #5968                       ; =0x1750
	ldrb	w8, [x21, x8]
	tbz	w8, #0, LBB31_118
; %bb.117:                              ;   in Loop: Header=BB31_105 Depth=2
	mov	x9, #0                          ; =0x0
	ldr	x8, [sp, #6680]
	ldr	x11, [x8]
	cbnz	x11, LBB31_119
	b	LBB31_101
LBB31_118:                              ; %bb3.i.i.i516
                                        ;   in Loop: Header=BB31_105 Depth=2
	ldr	x8, [sp, #6664]
	eor	x8, x8, x2
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x9, x8, x8, lsr #31
	ldr	x8, [sp, #6680]
	ldr	x11, [x8]
	cbz	x11, LBB31_101
LBB31_119:                              ; %bb12.preheader.i.i532
                                        ;   in Loop: Header=BB31_105 Depth=2
	udiv	x10, x9, x11
	msub	x10, x10, x11, x9
	mov	x9, x10
	b	LBB31_121
LBB31_120:                              ; %bb22.i.i539
                                        ;   in Loop: Header=BB31_121 Depth=3
	add	x9, x9, #1
	cmp	x9, x11
	b.eq	LBB31_124
LBB31_121:                              ; %bb12.i.i534
                                        ;   Parent Loop BB31_85 Depth=1
                                        ;     Parent Loop BB31_105 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	madd	x12, x9, x28, x8
	ldr	w13, [x12, #16]!
	cmp	w13, #1
	b.eq	LBB31_120
; %bb.122:                              ; %bb12.i.i534
                                        ;   in Loop: Header=BB31_121 Depth=3
	cmp	w13, #2
	b.ne	LBB31_100
; %bb.123:                              ; %bb16.i.i566
                                        ;   in Loop: Header=BB31_121 Depth=3
	ldr	x12, [x12, #8]
	cmp	x12, x2
	b.ne	LBB31_120
	b	LBB31_130
LBB31_124:                              ; %bb23.i.i542
                                        ;   in Loop: Header=BB31_105 Depth=2
	cbz	x10, LBB31_101
; %bb.125:                              ; %bb12.1.i.i544.preheader
                                        ;   in Loop: Header=BB31_105 Depth=2
	mov	x9, #0                          ; =0x0
	add	x11, x8, #24
	b	LBB31_127
LBB31_126:                              ; %bb22.1.i.i549
                                        ;   in Loop: Header=BB31_127 Depth=3
	add	x9, x9, #1
	add	x11, x11, #272
	cmp	x10, x9
	b.eq	LBB31_101
LBB31_127:                              ; %bb12.1.i.i544
                                        ;   Parent Loop BB31_85 Depth=1
                                        ;     Parent Loop BB31_105 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldur	w12, [x11, #-8]
	cmp	w12, #1
	b.eq	LBB31_126
; %bb.128:                              ; %bb12.1.i.i544
                                        ;   in Loop: Header=BB31_127 Depth=3
	cmp	w12, #2
	b.ne	LBB31_170
; %bb.129:                              ; %bb16.1.i.i557
                                        ;   in Loop: Header=BB31_127 Depth=3
	ldr	x12, [x11]
	cmp	x12, x2
	b.ne	LBB31_126
LBB31_130:                              ; %bb2.i578
                                        ;   in Loop: Header=BB31_105 Depth=2
	madd	x8, x9, x28, x8
	ldr	x8, [x8, #32]
	str	wzr, [sp, #3656]
	str	x8, [sp, #3664]
	strb	wzr, [sp, #3672]
	ldr	x9, [sp, #6696]
	mov	w10, #17161                     ; =0x4309
	madd	x8, x9, x10, x8
	add	x8, x8, #131
	b	LBB31_103
LBB31_131:                              ; %bb69
                                        ;   in Loop: Header=BB31_105 Depth=2
	mov	w27, #1                         ; =0x1
	ldr	x8, [sp, #656]                  ; 8-byte Folded Reload
	add	x8, x8, x24
	str	x8, [sp, #3680]
	add	x9, x8, #1
	str	x9, [sp, #3688]
	dup.2d	v0, x8
	ldr	q1, [sp, #592]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3696]
	ldr	q1, [sp, #576]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3712]
	ldr	q1, [sp, #560]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3728]
	ldr	q1, [sp, #544]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3744]
	ldr	q1, [sp, #528]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3760]
	ldr	q1, [sp, #512]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3776]
	ldr	q1, [sp, #496]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3792]
	ldr	q1, [sp, #480]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3808]
	ldr	q1, [sp, #464]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3824]
	ldr	q1, [sp, #448]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3840]
	ldr	q1, [sp, #432]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3856]
	ldr	q1, [sp, #416]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3872]
	ldr	q1, [sp, #400]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3888]
	ldr	q1, [sp, #384]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3904]
	ldr	q1, [sp, #352]                  ; 16-byte Folded Reload
	add.2d	v0, v0, v1
	str	q0, [sp, #3920]
	ldp	q0, q1, [x22, #192]
	str	q0, [sp, #6944]
	str	q1, [sp, #6960]
	ldp	q0, q1, [x22, #224]
	str	q0, [sp, #6976]
	str	q1, [sp, #6992]
	ldp	q0, q1, [x22, #128]
	str	q0, [sp, #6880]
	str	q1, [sp, #6896]
	ldp	q0, q1, [x22, #160]
	str	q0, [sp, #6912]
	str	q1, [sp, #6928]
	ldp	q0, q1, [x22, #64]
	str	q0, [sp, #6816]
	str	q1, [sp, #6832]
	ldp	q0, q1, [x22, #96]
	str	q0, [sp, #6848]
	str	q1, [sp, #6864]
	ldp	q0, q1, [x22]
	str	q0, [sp, #6752]
	str	q1, [sp, #6768]
	ldp	q0, q1, [x22, #32]
	str	q0, [sp, #6784]
	str	q1, [sp, #6800]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2656
	add	x0, x8, #256
	mov	w8, #5976                       ; =0x1758
	add	x1, x21, x8
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #2656
	mov	w8, #5960                       ; =0x1748
	add	x4, x21, x8
	bl	_wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65
	ldr	w8, [sp, #7008]
	cbz	w8, LBB31_151
; %bb.132:                              ; %bb69
                                        ;   in Loop: Header=BB31_105 Depth=2
	cmp	w8, #1
	b.ne	LBB31_82
; %bb.133:                              ; %bb2.i654
                                        ;   in Loop: Header=BB31_105 Depth=2
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2656
	ldrb	w20, [x8, #260]
	add	x0, x8, #528
	add	x1, x8, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	tbz	w20, #0, LBB31_167
; %bb.134:                              ; %bb4.i660
                                        ;   in Loop: Header=BB31_105 Depth=2
	ldr	x8, [sp, #6680]
	ldr	x8, [x8]
	cmp	x8, #4, lsl #12                 ; =16384
	b.lo	LBB31_173
LBB31_135:                              ; %bb18.i682
                                        ;   in Loop: Header=BB31_105 Depth=2
	mov	w8, #1                          ; =0x1
	str	x8, [sp, #3936]
	strb	w8, [x21, #3236]
	b	LBB31_168
LBB31_136:                              ; %bb90
                                        ;   in Loop: Header=BB31_105 Depth=2
	mov	w8, #5968                       ; =0x1750
	ldrb	w8, [x21, x8]
	tbz	w8, #0, LBB31_138
; %bb.137:                              ;   in Loop: Header=BB31_105 Depth=2
	mov	x9, #0                          ; =0x0
	ldr	x8, [sp, #6680]
	ldr	x11, [x8]
	cbnz	x11, LBB31_139
	b	LBB31_180
LBB31_138:                              ; %bb3.i.i.i1286
                                        ;   in Loop: Header=BB31_105 Depth=2
	ldr	x8, [sp, #6664]
	eor	x8, x8, x2
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x9, x8, x8, lsr #31
	ldr	x8, [sp, #6680]
	ldr	x11, [x8]
	cbz	x11, LBB31_180
LBB31_139:                              ; %bb12.preheader.i.i1302
                                        ;   in Loop: Header=BB31_105 Depth=2
	udiv	x10, x9, x11
	msub	x10, x10, x11, x9
	mov	x9, x10
	b	LBB31_141
LBB31_140:                              ; %bb22.i.i1309
                                        ;   in Loop: Header=BB31_141 Depth=3
	add	x9, x9, #1
	cmp	x9, x11
	b.eq	LBB31_153
LBB31_141:                              ; %bb12.i.i1304
                                        ;   Parent Loop BB31_85 Depth=1
                                        ;     Parent Loop BB31_105 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	madd	x12, x9, x28, x8
	ldr	w13, [x12, #16]!
	cmp	w13, #1
	b.eq	LBB31_140
; %bb.142:                              ; %bb12.i.i1304
                                        ;   in Loop: Header=BB31_141 Depth=3
	cmp	w13, #2
	b.ne	LBB31_171
; %bb.143:                              ; %bb16.i.i1335
                                        ;   in Loop: Header=BB31_141 Depth=3
	ldr	x12, [x12, #8]
	cmp	x12, x2
	b.ne	LBB31_140
	b	LBB31_159
LBB31_144:                              ; %bb82
                                        ;   in Loop: Header=BB31_105 Depth=2
	ldr	x8, [sp, #6696]
	mul	x8, x8, x26
	str	x8, [sp, #6696]
	mov	w9, #5968                       ; =0x1750
	ldrb	w9, [x21, x9]
	ldr	x2, [sp, #6744]
	mov	w15, #1                         ; =0x1
	tbz	w9, #0, LBB31_112
LBB31_145:                              ;   in Loop: Header=BB31_105 Depth=2
	mov	x10, #0                         ; =0x0
	ldr	x9, [sp, #6680]
	ldr	x12, [x9]
	cbz	x12, LBB31_182
LBB31_146:                              ; %bb12.preheader.i.i849
                                        ;   in Loop: Header=BB31_105 Depth=2
	udiv	x11, x10, x12
	msub	x11, x11, x12, x10
	mov	x10, x11
	b	LBB31_148
LBB31_147:                              ; %bb22.i.i856
                                        ;   in Loop: Header=BB31_148 Depth=3
	add	x10, x10, #1
	cmp	x10, x12
	b.eq	LBB31_160
LBB31_148:                              ; %bb12.i.i851
                                        ;   Parent Loop BB31_85 Depth=1
                                        ;     Parent Loop BB31_105 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	madd	x13, x10, x28, x9
	ldr	w14, [x13, #16]!
	cmp	w14, #1
	b.eq	LBB31_147
; %bb.149:                              ; %bb12.i.i851
                                        ;   in Loop: Header=BB31_148 Depth=3
	cmp	w14, #2
	b.ne	LBB31_172
; %bb.150:                              ; %bb16.i.i883
                                        ;   in Loop: Header=BB31_148 Depth=3
	ldr	x13, [x13, #8]
	cmp	x13, x2
	b.ne	LBB31_147
	b	LBB31_166
LBB31_151:                              ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit691.thread1379"
                                        ;   in Loop: Header=BB31_105 Depth=2
	ldr	x8, [sp, #96]                   ; 8-byte Folded Reload
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #240]
	stp	q0, q0, [x8, #208]
	stp	q0, q0, [x8, #176]
	stp	q0, q0, [x8, #144]
	stp	q0, q0, [x8, #112]
	stp	q0, q0, [x8, #80]
	stp	q0, q0, [x8, #48]
	stp	q0, q0, [x8, #16]
	str	q0, [x8]
LBB31_152:                              ; %bb72
                                        ;   in Loop: Header=BB31_105 Depth=2
	ldr	x8, [sp, #6696]
	mul	x8, x8, x26
	ldr	x14, [sp, #640]                 ; 8-byte Folded Reload
	mov	w15, #1                         ; =0x1
	b	LBB31_103
LBB31_153:                              ; %bb23.i.i1312
                                        ;   in Loop: Header=BB31_105 Depth=2
	cbz	x10, LBB31_180
; %bb.154:                              ; %bb12.1.i.i1314.preheader
                                        ;   in Loop: Header=BB31_105 Depth=2
	mov	x9, #0                          ; =0x0
	add	x11, x8, #24
	b	LBB31_156
LBB31_155:                              ; %bb22.1.i.i1319
                                        ;   in Loop: Header=BB31_156 Depth=3
	add	x9, x9, #1
	add	x11, x11, #272
	cmp	x10, x9
	b.eq	LBB31_180
LBB31_156:                              ; %bb12.1.i.i1314
                                        ;   Parent Loop BB31_85 Depth=1
                                        ;     Parent Loop BB31_105 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldur	w12, [x11, #-8]
	cmp	w12, #1
	b.eq	LBB31_155
; %bb.157:                              ; %bb12.1.i.i1314
                                        ;   in Loop: Header=BB31_156 Depth=3
	cmp	w12, #2
	b.ne	LBB31_179
; %bb.158:                              ; %bb16.1.i.i1327
                                        ;   in Loop: Header=BB31_156 Depth=3
	ldr	x12, [x11]
	cmp	x12, x2
	b.ne	LBB31_155
LBB31_159:                              ; %bb2.i1346
                                        ;   in Loop: Header=BB31_105 Depth=2
	madd	x8, x9, x28, x8
	ldr	x9, [x8, #32]
	add	x10, x9, #1
	str	x10, [x8, #32]
	str	wzr, [sp, #6592]
	str	x10, [sp, #6600]
	ldr	x8, [sp, #672]                  ; 8-byte Folded Reload
	strb	wzr, [x8, #1072]
	ldr	x8, [sp, #6696]
	mov	w10, #17161                     ; =0x4309
	madd	x8, x8, x10, x9
	add	x8, x8, #132
	b	LBB31_103
LBB31_160:                              ; %bb23.i.i859
                                        ;   in Loop: Header=BB31_105 Depth=2
	cbz	x11, LBB31_182
; %bb.161:                              ; %bb12.1.i.i861.preheader
                                        ;   in Loop: Header=BB31_105 Depth=2
	mov	x10, #0                         ; =0x0
	add	x12, x9, #24
	b	LBB31_163
LBB31_162:                              ; %bb22.1.i.i866
                                        ;   in Loop: Header=BB31_163 Depth=3
	add	x10, x10, #1
	add	x12, x12, #272
	cmp	x11, x10
	b.eq	LBB31_182
LBB31_163:                              ; %bb12.1.i.i861
                                        ;   Parent Loop BB31_85 Depth=1
                                        ;     Parent Loop BB31_105 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldur	w13, [x12, #-8]
	cmp	w13, #1
	b.eq	LBB31_162
; %bb.164:                              ; %bb12.1.i.i861
                                        ;   in Loop: Header=BB31_163 Depth=3
	cmp	w13, #2
	b.ne	LBB31_181
; %bb.165:                              ; %bb16.1.i.i874
                                        ;   in Loop: Header=BB31_163 Depth=3
	ldr	x13, [x12]
	cmp	x13, x2
	b.ne	LBB31_162
LBB31_166:                              ; %bb2.i895
                                        ;   in Loop: Header=BB31_105 Depth=2
	mov	w27, #1                         ; =0x1
	madd	x9, x10, x28, x9
	ldr	x9, [x9, #32]
	str	wzr, [sp, #5520]
	str	x9, [sp, #5528]
	ldr	x10, [sp, #672]                 ; 8-byte Folded Reload
	strb	wzr, [x10]
	mov	w10, #17161                     ; =0x4309
	madd	x8, x8, x10, x9
	add	x8, x8, #131
	b	LBB31_183
LBB31_167:                              ; %bb3.i658
                                        ;   in Loop: Header=BB31_105 Depth=2
	str	x27, [sp, #3936]
LBB31_168:                              ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit691.thread"
                                        ;   in Loop: Header=BB31_105 Depth=2
	add	x0, x25, #3240
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2656
	add	x1, x8, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
LBB31_169:                              ; %bb73
                                        ;   in Loop: Header=BB31_105 Depth=2
	ldrb	w20, [x21, #3236]
	add	x0, x21, #3504
	add	x1, x25, #3240
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	ldr	x8, [sp, #6696]
	cmp	w20, #0
	mov	w15, #1                         ; =0x1
	cinc	x9, x15, ne
	madd	x8, x8, x26, x9
	ldr	x9, [sp, #4208]
	ldp	x11, x10, [sp, #48]             ; 16-byte Folded Reload
	ldp	q1, q0, [x11, #96]
	stp	q1, q0, [x10, #96]
	ldp	q1, q0, [x11, #64]
	stp	q1, q0, [x10, #64]
	ldp	q1, q0, [x11, #160]
	stp	q1, q0, [x10, #160]
	ldp	q1, q0, [x11, #128]
	stp	q1, q0, [x10, #128]
	ldp	q1, q0, [x11, #224]
	stp	q1, q0, [x10, #224]
	ldp	q1, q0, [x11, #192]
	stp	q1, q0, [x10, #192]
	ldp	q1, q0, [x11, #32]
	stp	q1, q0, [x10, #32]
	ldp	q0, q1, [x11]
	stp	q0, q1, [x10]
	ldr	x10, [sp, #4472]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4480]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4488]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4496]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4504]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4512]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4520]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4528]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4536]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4544]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4552]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4560]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4568]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4576]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4584]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4592]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4600]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4608]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4616]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4624]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4632]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4640]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4648]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4656]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4664]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4672]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4680]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4688]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4696]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4704]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #4712]
	add	x8, x8, x10
	madd	x8, x9, x26, x8
	ldr	x9, [sp, #4720]
	b	LBB31_193
LBB31_170:                              ; %bb12.1.i.i544
                                        ;   in Loop: Header=BB31_105 Depth=2
	cbz	w12, LBB31_101
	b	LBB31_82
LBB31_171:                              ; %bb12.i.i1304
                                        ;   in Loop: Header=BB31_105 Depth=2
	cbz	w13, LBB31_180
	b	LBB31_82
LBB31_172:                              ; %bb12.i.i851
                                        ;   in Loop: Header=BB31_105 Depth=2
	cbz	w14, LBB31_182
	b	LBB31_82
LBB31_173:                              ; %bb7.i664
                                        ;   in Loop: Header=BB31_105 Depth=2
	cmp	x8, #2, lsl #12                 ; =8192
	mov	w9, #8192                       ; =0x2000
	csel	x9, x8, x9, lo
	lsl	x9, x9, #1
	cmp	x8, #0
	csinc	x1, x9, xzr, ne
	cmp	x1, x8
	b.ls	LBB31_176
; %bb.174:                              ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.i675"
                                        ;   in Loop: Header=BB31_105 Depth=2
	mov	w8, #5976                       ; =0x1758
	add	x0, x21, x8
	mov	w8, #5960                       ; =0x1748
	add	x2, x21, x8
	bl	_wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	str	w0, [sp, #7544]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2656
	strb	w1, [x8, #796]
	strb	w2, [x8, #797]
	ldr	x20, [sp, #608]                 ; 8-byte Folded Reload
	cbz	w0, LBB31_177
; %bb.175:                              ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.i675"
                                        ;   in Loop: Header=BB31_105 Depth=2
	cmp	w0, #1
	b.eq	LBB31_135
	b	LBB31_82
LBB31_176:                              ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.thread.i669"
                                        ;   in Loop: Header=BB31_105 Depth=2
	str	wzr, [sp, #7544]
	strh	wzr, [sp, #7548]
	ldr	x20, [sp, #608]                 ; 8-byte Folded Reload
LBB31_177:                              ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit691"
                                        ;   in Loop: Header=BB31_105 Depth=2
	ldr	x2, [sp, #7280]
	ldp	x8, x3, [sp, #368]              ; 16-byte Folded Reload
	ldp	q0, q1, [x8, #192]
	stp	q0, q1, [x3, #192]
	ldp	q0, q1, [x8, #224]
	stp	q0, q1, [x3, #224]
	ldp	q0, q1, [x8, #128]
	stp	q0, q1, [x3, #128]
	ldp	q0, q1, [x8, #160]
	stp	q0, q1, [x3, #160]
	ldp	q0, q1, [x8, #64]
	stp	q0, q1, [x3, #64]
	ldp	q0, q1, [x8, #96]
	stp	q0, q1, [x3, #96]
	ldp	q0, q1, [x8]
	stp	q0, q1, [x3]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x3, #32]
	mov	w8, #5976                       ; =0x1758
	add	x1, x21, x8
	mov	w8, #5960                       ; =0x1748
	add	x4, x21, x8
	ldr	x0, [sp, #96]                   ; 8-byte Folded Reload
	bl	_wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65
	ldr	w8, [sp, #3936]
	cbz	w8, LBB31_152
; %bb.178:                              ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit691"
                                        ;   in Loop: Header=BB31_105 Depth=2
	cmp	w8, #1
	b.eq	LBB31_169
	b	LBB31_82
LBB31_179:                              ; %bb12.1.i.i1314
                                        ;   in Loop: Header=BB31_105 Depth=2
	cbnz	w12, LBB31_82
LBB31_180:                              ; %bb3.i1341
                                        ;   in Loop: Header=BB31_105 Depth=2
	str	w15, [sp, #6592]
	str	xzr, [sp, #6600]
	ldr	x8, [sp, #672]                  ; 8-byte Folded Reload
	strb	wzr, [x8, #1072]
	b	LBB31_102
LBB31_181:                              ; %bb12.1.i.i861
                                        ;   in Loop: Header=BB31_105 Depth=2
	cbnz	w13, LBB31_82
LBB31_182:                              ; %bb3.i890
                                        ;   in Loop: Header=BB31_105 Depth=2
	mov	w27, #1                         ; =0x1
	str	w15, [sp, #5520]
	str	xzr, [sp, #5528]
	mul	x8, x8, x26
	ldr	x9, [sp, #672]                  ; 8-byte Folded Reload
	strb	wzr, [x9]
LBB31_183:                              ; %wf_map_cost_lookup_result.exit902
                                        ;   in Loop: Header=BB31_105 Depth=2
	str	x8, [sp, #6696]
	ldr	x8, [sp, #656]                  ; 8-byte Folded Reload
	add	x8, x8, x24
	add	x9, x8, #31
	str	x8, [sp, #5544]
	dup.2d	v0, x8
	ldr	q1, [sp, #336]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5552]
	ldr	q1, [sp, #320]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5568]
	ldr	q1, [sp, #304]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5584]
	ldr	q1, [sp, #288]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5600]
	ldr	q1, [sp, #272]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5616]
	ldr	q1, [sp, #256]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5632]
	ldr	q1, [sp, #240]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5648]
	ldr	q1, [sp, #224]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5664]
	ldr	q1, [sp, #208]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5680]
	ldr	q1, [sp, #192]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5696]
	ldr	q1, [sp, #176]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5712]
	ldr	q1, [sp, #160]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5728]
	ldr	q1, [sp, #144]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5744]
	ldr	q1, [sp, #128]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5760]
	ldr	q1, [sp, #112]                  ; 16-byte Folded Reload
	add.2d	v0, v0, v1
	str	q0, [sp, #5776]
	str	x9, [sp, #5792]
	ldp	q0, q1, [x19, #192]
	str	q0, [sp, #6944]
	str	q1, [sp, #6960]
	ldp	q0, q1, [x19, #224]
	str	q0, [sp, #6976]
	str	q1, [sp, #6992]
	ldp	q0, q1, [x19, #128]
	str	q0, [sp, #6880]
	str	q1, [sp, #6896]
	ldp	q0, q1, [x19, #160]
	str	q0, [sp, #6912]
	str	q1, [sp, #6928]
	ldp	q0, q1, [x19, #64]
	str	q0, [sp, #6816]
	str	q1, [sp, #6832]
	ldp	q0, q1, [x19, #96]
	str	q0, [sp, #6848]
	str	q1, [sp, #6864]
	ldp	q0, q1, [x19]
	str	q0, [sp, #6752]
	str	q1, [sp, #6768]
	ldp	q0, q1, [x19, #32]
	str	q0, [sp, #6784]
	str	q1, [sp, #6800]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2656
	add	x0, x8, #256
	mov	w8, #5976                       ; =0x1758
	add	x1, x21, x8
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #2656
	mov	w8, #5960                       ; =0x1748
	add	x4, x21, x8
	bl	_wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65
	ldr	w8, [sp, #7008]
	cbz	w8, LBB31_188
; %bb.184:                              ; %wf_map_cost_lookup_result.exit902
                                        ;   in Loop: Header=BB31_105 Depth=2
	cmp	w8, #1
	b.ne	LBB31_82
; %bb.185:                              ; %bb2.i971
                                        ;   in Loop: Header=BB31_105 Depth=2
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2656
	ldrb	w20, [x8, #260]
	add	x0, x8, #528
	add	x1, x8, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	tbz	w20, #0, LBB31_190
; %bb.186:                              ; %bb4.i977
                                        ;   in Loop: Header=BB31_105 Depth=2
	ldr	x8, [sp, #6680]
	ldr	x8, [x8]
	cmp	x8, #4, lsl #12                 ; =16384
	b.lo	LBB31_194
LBB31_187:                              ; %bb18.i999
                                        ;   in Loop: Header=BB31_105 Depth=2
	mov	w9, #1                          ; =0x1
	str	x9, [sp, #5800]
	ldr	x8, [sp, #672]                  ; 8-byte Folded Reload
	strb	w9, [x8, #268]
	b	LBB31_191
LBB31_188:                              ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit1008.thread1389"
                                        ;   in Loop: Header=BB31_105 Depth=2
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #240]
	stp	q0, q0, [x8, #208]
	stp	q0, q0, [x8, #176]
	stp	q0, q0, [x8, #144]
	stp	q0, q0, [x8, #112]
	stp	q0, q0, [x8, #80]
	stp	q0, q0, [x8, #48]
	stp	q0, q0, [x8, #16]
	str	q0, [x8]
	ldr	x14, [sp, #640]                 ; 8-byte Folded Reload
LBB31_189:                              ; %bb84
                                        ;   in Loop: Header=BB31_105 Depth=2
	ldr	x8, [sp, #6696]
	mul	x8, x8, x26
	mov	w15, #1                         ; =0x1
	b	LBB31_103
LBB31_190:                              ; %bb3.i975
                                        ;   in Loop: Header=BB31_105 Depth=2
	str	x27, [sp, #5800]
LBB31_191:                              ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit1008.thread"
                                        ;   in Loop: Header=BB31_105 Depth=2
	mov	w8, #5104                       ; =0x13f0
	add	x0, x25, x8
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2656
	add	x1, x8, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	mov	w9, #5104                       ; =0x13f0
LBB31_192:                              ; %bb85
                                        ;   in Loop: Header=BB31_105 Depth=2
	ldr	x8, [sp, #672]                  ; 8-byte Folded Reload
	ldrb	w20, [x8, #268]
	add	x1, x25, x9
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	ldr	x8, [sp, #6696]
	cmp	w20, #0
	mov	w15, #1                         ; =0x1
	cinc	x9, x15, ne
	madd	x8, x8, x26, x9
	ldr	x9, [sp, #6072]
	ldp	x11, x10, [sp, #24]             ; 16-byte Folded Reload
	ldp	q1, q0, [x11, #96]
	stp	q1, q0, [x10, #96]
	ldp	q1, q0, [x11, #64]
	stp	q1, q0, [x10, #64]
	ldp	q1, q0, [x11, #160]
	stp	q1, q0, [x10, #160]
	ldp	q1, q0, [x11, #128]
	stp	q1, q0, [x10, #128]
	ldp	q1, q0, [x11, #224]
	stp	q1, q0, [x10, #224]
	ldp	q1, q0, [x11, #192]
	stp	q1, q0, [x10, #192]
	ldp	q1, q0, [x11, #32]
	stp	q1, q0, [x10, #32]
	ldp	q0, q1, [x11]
	stp	q0, q1, [x10]
	ldr	x10, [sp, #6336]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6344]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6352]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6360]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6368]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6376]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6384]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6392]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6400]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6408]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6416]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6424]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6432]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6440]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6448]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6456]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6464]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6472]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6480]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6488]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6496]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6504]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6512]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6520]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6528]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6536]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6544]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6552]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6560]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6568]
	madd	x9, x9, x26, x10
	ldr	x10, [sp, #6576]
	add	x8, x8, x10
	madd	x8, x9, x26, x8
	ldr	x9, [sp, #6584]
LBB31_193:                              ; %bb92.sink.split
                                        ;   in Loop: Header=BB31_105 Depth=2
	madd	x8, x8, x26, x9
	ldr	x20, [sp, #608]                 ; 8-byte Folded Reload
	ldr	x14, [sp, #640]                 ; 8-byte Folded Reload
	b	LBB31_103
LBB31_194:                              ; %bb7.i981
                                        ;   in Loop: Header=BB31_105 Depth=2
	cmp	x8, #2, lsl #12                 ; =8192
	mov	w9, #8192                       ; =0x2000
	csel	x9, x8, x9, lo
	lsl	x9, x9, #1
	cmp	x8, #0
	csinc	x1, x9, xzr, ne
	cmp	x1, x8
	b.ls	LBB31_197
; %bb.195:                              ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.i992"
                                        ;   in Loop: Header=BB31_105 Depth=2
	mov	w8, #5976                       ; =0x1758
	add	x0, x21, x8
	mov	w8, #5960                       ; =0x1748
	add	x2, x21, x8
	bl	_wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	str	w0, [sp, #7544]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2656
	strb	w1, [x8, #796]
	strb	w2, [x8, #797]
	ldr	x20, [sp, #608]                 ; 8-byte Folded Reload
	cbz	w0, LBB31_198
; %bb.196:                              ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.i992"
                                        ;   in Loop: Header=BB31_105 Depth=2
	cmp	w0, #1
	b.eq	LBB31_187
	b	LBB31_82
LBB31_197:                              ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.thread.i986"
                                        ;   in Loop: Header=BB31_105 Depth=2
	str	wzr, [sp, #7544]
	strh	wzr, [sp, #7548]
	ldr	x20, [sp, #608]                 ; 8-byte Folded Reload
LBB31_198:                              ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit1008"
                                        ;   in Loop: Header=BB31_105 Depth=2
	ldr	x2, [sp, #7280]
	ldp	x8, x3, [sp, #368]              ; 16-byte Folded Reload
	ldp	q0, q1, [x8, #192]
	stp	q0, q1, [x3, #192]
	ldp	q0, q1, [x8, #224]
	stp	q0, q1, [x3, #224]
	ldp	q0, q1, [x8, #128]
	stp	q0, q1, [x3, #128]
	ldp	q0, q1, [x8, #160]
	stp	q0, q1, [x3, #160]
	ldp	q0, q1, [x8, #64]
	stp	q0, q1, [x3, #64]
	ldp	q0, q1, [x8, #96]
	stp	q0, q1, [x3, #96]
	ldp	q0, q1, [x8]
	stp	q0, q1, [x3]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x3, #32]
	mov	w8, #5976                       ; =0x1758
	add	x1, x21, x8
	mov	w8, #5960                       ; =0x1748
	add	x4, x21, x8
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	bl	_wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65
	ldr	w8, [sp, #5800]
	ldr	x14, [sp, #640]                 ; 8-byte Folded Reload
	cbz	w8, LBB31_189
; %bb.199:                              ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit1008"
                                        ;   in Loop: Header=BB31_105 Depth=2
	cmp	w8, #1
	mov	w9, #5104                       ; =0x13f0
	b.eq	LBB31_192
	b	LBB31_82
LBB31_200:                              ; %bb15
	mov	w8, #5992                       ; =0x1768
	add	x10, sp, #704
	add	x19, x10, x8
	mov	w8, #5928                       ; =0x1728
	add	x9, sp, #704
	add	x20, x9, x8
	mov	w8, #5912                       ; =0x1718
	mov	w11, #5976                      ; =0x1758
	ldr	q0, [x10, x11]
	str	q0, [x9, x8]
	add	x0, x9, x8
	mov	x1, x19
	bl	_wf_hash_map.hash_map_free$instance$d5f8785ab7665d71
	ldp	q0, q1, [x19]
	stp	q0, q1, [x20]
	ldr	x8, [sp, #6632]
	ldr	x9, [sp, #6640]
	ldr	x10, [sp, #6648]
	ldr	x11, [sp, #6656]
	eor	x8, x8, x8, lsr #30
	mov	x13, #58809                     ; =0xe5b9
	movk	x13, #7396, lsl #16
	movk	x13, #18285, lsl #32
	movk	x13, #48984, lsl #48
	mul	x8, x8, x13
	eor	x8, x8, x8, lsr #27
	mov	x12, #4587                      ; =0x11eb
	movk	x12, #4913, lsl #16
	movk	x12, #18875, lsl #32
	movk	x12, #38096, lsl #48
	mul	x8, x8, x12
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x13
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x12
	eor	x12, x9, x8
	mov	x13, #31765                     ; =0x7c15
	movk	x13, #32586, lsl #16
	movk	x13, #31161, lsl #32
	movk	x13, #40503, lsl #48
	mul	x11, x11, x13
	eor	x10, x10, x11
	eor	x10, x10, x12, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #3712
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB31_201:                              ; %window.block.oom.v1.i.i.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh72, Lloh73
	.loh AdrpAdrp	Lloh70, Lloh72
	.loh AdrpLdr	Lloh70, Lloh71
	.loh AdrpAdrp	Lloh68, Lloh70
	.loh AdrpLdr	Lloh68, Lloh69
	.loh AdrpAdrp	Lloh66, Lloh68
	.loh AdrpLdr	Lloh66, Lloh67
	.loh AdrpAdrp	Lloh64, Lloh66
	.loh AdrpLdr	Lloh64, Lloh65
	.loh AdrpAdrp	Lloh62, Lloh64
	.loh AdrpLdr	Lloh62, Lloh63
	.loh AdrpAdrp	Lloh60, Lloh62
	.loh AdrpLdr	Lloh60, Lloh61
	.loh AdrpAdrp	Lloh58, Lloh60
	.loh AdrpLdr	Lloh58, Lloh59
	.loh AdrpAdrp	Lloh56, Lloh58
	.loh AdrpLdr	Lloh56, Lloh57
	.loh AdrpAdrp	Lloh54, Lloh56
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpAdrp	Lloh52, Lloh54
	.loh AdrpLdr	Lloh52, Lloh53
	.loh AdrpAdrp	Lloh50, Lloh52
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpAdrp	Lloh48, Lloh50
	.loh AdrpLdr	Lloh48, Lloh49
	.loh AdrpAdrp	Lloh46, Lloh48
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpAdrp	Lloh44, Lloh46
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpLdr	Lloh102, Lloh103
	.loh AdrpAdrp	Lloh100, Lloh102
	.loh AdrpLdr	Lloh100, Lloh101
	.loh AdrpAdrp	Lloh98, Lloh100
	.loh AdrpLdr	Lloh98, Lloh99
	.loh AdrpAdrp	Lloh96, Lloh98
	.loh AdrpLdr	Lloh96, Lloh97
	.loh AdrpAdrp	Lloh94, Lloh96
	.loh AdrpLdr	Lloh94, Lloh95
	.loh AdrpAdrp	Lloh92, Lloh94
	.loh AdrpLdr	Lloh92, Lloh93
	.loh AdrpLdr	Lloh90, Lloh91
	.loh AdrpLdr	Lloh88, Lloh89
	.loh AdrpAdrp	Lloh86, Lloh88
	.loh AdrpLdr	Lloh86, Lloh87
	.loh AdrpAdrp	Lloh84, Lloh86
	.loh AdrpLdr	Lloh84, Lloh85
	.loh AdrpAdrp	Lloh82, Lloh84
	.loh AdrpLdr	Lloh82, Lloh83
	.loh AdrpAdrp	Lloh80, Lloh82
	.loh AdrpLdr	Lloh80, Lloh81
	.loh AdrpLdr	Lloh78, Lloh79
	.loh AdrpAdrp	Lloh76, Lloh78
	.loh AdrpLdr	Lloh76, Lloh77
	.loh AdrpLdr	Lloh74, Lloh75
	.loh AdrpLdr	Lloh162, Lloh163
	.loh AdrpAdrp	Lloh160, Lloh162
	.loh AdrpLdr	Lloh160, Lloh161
	.loh AdrpAdrp	Lloh158, Lloh160
	.loh AdrpLdr	Lloh158, Lloh159
	.loh AdrpAdrp	Lloh156, Lloh158
	.loh AdrpLdr	Lloh156, Lloh157
	.loh AdrpAdrp	Lloh154, Lloh156
	.loh AdrpLdr	Lloh154, Lloh155
	.loh AdrpAdrp	Lloh152, Lloh154
	.loh AdrpLdr	Lloh152, Lloh153
	.loh AdrpAdrp	Lloh150, Lloh152
	.loh AdrpLdr	Lloh150, Lloh151
	.loh AdrpAdrp	Lloh148, Lloh150
	.loh AdrpLdr	Lloh148, Lloh149
	.loh AdrpLdr	Lloh146, Lloh147
	.loh AdrpLdr	Lloh144, Lloh145
	.loh AdrpAdrp	Lloh142, Lloh144
	.loh AdrpLdr	Lloh142, Lloh143
	.loh AdrpAdrp	Lloh140, Lloh142
	.loh AdrpLdr	Lloh140, Lloh141
	.loh AdrpLdr	Lloh138, Lloh139
	.loh AdrpLdr	Lloh136, Lloh137
	.loh AdrpAdrp	Lloh134, Lloh136
	.loh AdrpLdr	Lloh134, Lloh135
	.loh AdrpAdrp	Lloh132, Lloh134
	.loh AdrpLdr	Lloh132, Lloh133
	.loh AdrpLdr	Lloh130, Lloh131
	.loh AdrpLdr	Lloh128, Lloh129
	.loh AdrpLdr	Lloh126, Lloh127
	.loh AdrpAdrp	Lloh124, Lloh126
	.loh AdrpLdr	Lloh124, Lloh125
	.loh AdrpLdr	Lloh122, Lloh123
	.loh AdrpLdr	Lloh120, Lloh121
	.loh AdrpLdr	Lloh118, Lloh119
	.loh AdrpLdr	Lloh116, Lloh117
	.loh AdrpLdr	Lloh114, Lloh115
	.loh AdrpLdr	Lloh112, Lloh113
	.loh AdrpLdr	Lloh110, Lloh111
	.loh AdrpLdr	Lloh108, Lloh109
	.loh AdrpLdr	Lloh106, Lloh107
	.loh AdrpAdrp	Lloh104, Lloh106
	.loh AdrpLdr	Lloh104, Lloh105
	.loh AdrpLdrGot	Lloh42, Lloh43
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd ; -- Begin function wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd
	.p2align	2
_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd: ; @"wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #144
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 144
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x2
	mov	x21, x1
	mov	x20, x0
	mov	x22, #31765                     ; =0x7c15
	movk	x22, #32586, lsl #16
	movk	x22, #31161, lsl #32
	movk	x22, #40503, lsl #48
	eor	x8, x2, x22
	str	x8, [sp, #24]
	strb	wzr, [sp, #32]
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB32_23
; %bb.1:                                ; %bb1.i.i.i
	stp	xzr, x20, [x0]
	cbz	x20, LBB32_5
; %bb.2:                                ; %bb5.i.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
LBB32_3:                                ; %bb5.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x9], #24
	cmp	x20, x8
	b.ne	LBB32_3
; %bb.4:                                ; %bb4.bb7_crit_edge.i.i.i
	str	x20, [x0]
LBB32_5:                                ; %"wf_hash_map.hash_map_new$instance$820b2044b97e0fbd.exit"
	stp	x0, xzr, [sp, #8]
	cbz	x21, LBB32_12
; %bb.6:                                ; %bb2.lr.ph
	mov	w23, #1                         ; =0x1
	mov	w25, #131                       ; =0x83
	mov	w20, #1                         ; =0x1
	mov	x24, x19
	b	LBB32_8
LBB32_7:                                ; %bb2.i
                                        ;   in Loop: Header=BB32_8 Depth=1
	mul	x24, x24, x25
	add	x19, x19, #1
	add	x20, x20, #2
	subs	x21, x21, #1
	b.eq	LBB32_11
LBB32_8:                                ; %bb2
                                        ; =>This Inner Loop Header: Depth=1
	add	x0, sp, #40
	add	x1, sp, #8
	add	x4, sp, #24
	mov	x2, x20
	mov	x3, x19
	bl	_wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad
	ldr	w8, [sp, #40]
	cbz	w8, LBB32_7
; %bb.9:                                ; %bb2
                                        ;   in Loop: Header=BB32_8 Depth=1
	cmp	w8, #1
	b.ne	LBB32_19
; %bb.10:                               ; %bb3.i
                                        ;   in Loop: Header=BB32_8 Depth=1
	ldp	x9, x8, [sp, #48]
	ldrb	w10, [sp, #44]
	tst	w10, #0x1
	cinc	x10, x23, ne
	madd	x9, x24, x25, x9
	add	x9, x9, x10
	madd	x24, x9, x25, x8
	add	x19, x19, #1
	add	x20, x20, #2
	subs	x21, x21, #1
	b.ne	LBB32_8
LBB32_11:                               ; %bb4.loopexit
	ldp	x0, x8, [sp, #8]
	ldr	x20, [x0]
	mov	x19, x24
	b	LBB32_13
LBB32_12:
	mov	x8, #0                          ; =0x0
LBB32_13:                               ; %bb4
	mov	x23, #58809                     ; =0xe5b9
	movk	x23, #7396, lsl #16
	movk	x23, #18285, lsl #32
	movk	x23, #48984, lsl #48
	mov	x21, #4587                      ; =0x11eb
	movk	x21, #4913, lsl #16
	movk	x21, #18875, lsl #32
	movk	x21, #38096, lsl #48
	cbz	x20, LBB32_21
; %bb.14:                               ; %bb5.i.preheader
	mov	x9, #0                          ; =0x0
	mov	x24, #0                         ; =0x0
	mov	x25, #0                         ; =0x0
	sub	x10, x20, #1
	mov	w11, #24                        ; =0x18
	madd	x11, x20, x11, x0
	mov	w12, #131                       ; =0x83
	b	LBB32_17
LBB32_15:                               ; %bb7.i
                                        ;   in Loop: Header=BB32_17 Depth=1
	ldp	x14, x13, [x11]
	madd	x13, x14, x12, x13
	add	x25, x13, x25
	eor	x13, x13, x13, lsr #30
	mul	x13, x13, x23
	eor	x13, x13, x13, lsr #27
	mul	x13, x13, x21
	eor	x14, x24, x13, lsr #31
	eor	x24, x14, x13
	add	x9, x9, #1
LBB32_16:                               ; %bb6.i
                                        ;   in Loop: Header=BB32_17 Depth=1
	sub	x10, x10, #1
	sub	x11, x11, #24
	cmn	x10, #1
	b.eq	LBB32_20
LBB32_17:                               ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	str	x10, [x0]
	ldur	w13, [x11, #-8]
	cmp	w13, #2
	b.lo	LBB32_16
; %bb.18:                               ; %bb5.i
                                        ;   in Loop: Header=BB32_17 Depth=1
	b.eq	LBB32_15
LBB32_19:                               ; %invalid.tag.b0.i
	bl	_abort
LBB32_20:                               ; %"wf_hash_map.hash_map_free$instance$001ff12ace7d7c19.exit.loopexit"
	mul	x22, x9, x22
	b	LBB32_22
LBB32_21:
	mov	x22, #0                         ; =0x0
	mov	x24, #0                         ; =0x0
	mov	x25, #0                         ; =0x0
LBB32_22:                               ; %"wf_hash_map.hash_map_free$instance$001ff12ace7d7c19.exit"
	add	x20, x8, x20, lsl #32
	bl	_free
	eor	x8, x19, x19, lsr #30
	mul	x8, x8, x23
	eor	x8, x8, x8, lsr #27
	mul	x8, x8, x21
	eor	x9, x25, x25, lsr #30
	mul	x9, x9, x23
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x21
	eor	x10, x9, x8
	eor	x11, x20, x24
	eor	x11, x11, x22
	eor	x10, x11, x10, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
LBB32_23:                               ; %window.block.oom.v1.i.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_map_cost_library_geometry$instance$4250cb78d3f44027
lCPI33_0:
	.quad	1                               ; 0x1
	.quad	2                               ; 0x2
lCPI33_1:
	.quad	3                               ; 0x3
	.quad	4                               ; 0x4
lCPI33_2:
	.quad	5                               ; 0x5
	.quad	6                               ; 0x6
lCPI33_3:
	.quad	7                               ; 0x7
	.quad	8                               ; 0x8
lCPI33_4:
	.quad	9                               ; 0x9
	.quad	10                              ; 0xa
lCPI33_5:
	.quad	11                              ; 0xb
	.quad	12                              ; 0xc
lCPI33_6:
	.quad	13                              ; 0xd
	.quad	14                              ; 0xe
lCPI33_7:
	.quad	15                              ; 0xf
	.quad	16                              ; 0x10
lCPI33_8:
	.quad	17                              ; 0x11
	.quad	18                              ; 0x12
lCPI33_9:
	.quad	19                              ; 0x13
	.quad	20                              ; 0x14
lCPI33_10:
	.quad	21                              ; 0x15
	.quad	22                              ; 0x16
lCPI33_11:
	.quad	23                              ; 0x17
	.quad	24                              ; 0x18
lCPI33_12:
	.quad	25                              ; 0x19
	.quad	26                              ; 0x1a
lCPI33_13:
	.quad	27                              ; 0x1b
	.quad	28                              ; 0x1c
lCPI33_14:
	.quad	29                              ; 0x1d
	.quad	30                              ; 0x1e
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_map_cost_library_geometry$instance$4250cb78d3f44027
	.p2align	2
_wf_map_cost_library_geometry$instance$4250cb78d3f44027: ; @"wf_map_cost_library_geometry$instance$4250cb78d3f44027"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	sub	sp, sp, #832
	.cfi_def_cfa_offset 896
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
	mov	x22, #31765                     ; =0x7c15
	movk	x22, #32586, lsl #16
	movk	x22, #31161, lsl #32
	movk	x22, #40503, lsl #48
	eor	x8, x2, x22
	str	x8, [sp, #288]
	strb	wzr, [sp, #296]
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB33_11
; %bb.1:                                ; %bb1.i.i.i
	stp	xzr, x21, [x0]
	cbz	x21, LBB33_5
; %bb.2:                                ; %bb5.i.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
	movi.2d	v0, #0000000000000000
LBB33_3:                                ; %bb5.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	q0, q0, [x9]
	stp	q0, q0, [x9, #32]
	stp	q0, q0, [x9, #64]
	stp	q0, q0, [x9, #96]
	stp	q0, q0, [x9, #128]
	stp	q0, q0, [x9, #160]
	stp	q0, q0, [x9, #192]
	stp	q0, q0, [x9, #224]
	str	xzr, [x9, #256]
	add	x9, x9, #272
	cmp	x21, x8
	b.ne	LBB33_3
; %bb.4:                                ; %bb4.bb7_crit_edge.i.i.i
	str	x21, [x0]
LBB33_5:                                ; %"wf_hash_map.hash_map_new$instance$0e108827ecbbe374.exit"
	stp	x0, xzr, [sp, #272]
	stp	x19, xzr, [sp, #240]
	stp	xzr, xzr, [sp, #256]
	cbz	x20, LBB33_9
; %bb.6:                                ; %bb2.lr.ph
Lloh164:
	adrp	x8, lCPI33_0@PAGE
Lloh165:
	ldr	q0, [x8, lCPI33_0@PAGEOFF]
	str	q0, [sp, #224]                  ; 16-byte Folded Spill
	add	x23, sp, #576
Lloh166:
	adrp	x8, lCPI33_1@PAGE
Lloh167:
	ldr	q0, [x8, lCPI33_1@PAGEOFF]
	str	q0, [sp, #208]                  ; 16-byte Folded Spill
	mov	w21, #1                         ; =0x1
Lloh168:
	adrp	x8, lCPI33_2@PAGE
Lloh169:
	ldr	q0, [x8, lCPI33_2@PAGEOFF]
	str	q0, [sp, #192]                  ; 16-byte Folded Spill
Lloh170:
	adrp	x8, lCPI33_3@PAGE
Lloh171:
	ldr	q0, [x8, lCPI33_3@PAGEOFF]
	str	q0, [sp, #176]                  ; 16-byte Folded Spill
Lloh172:
	adrp	x8, lCPI33_4@PAGE
Lloh173:
	ldr	q0, [x8, lCPI33_4@PAGEOFF]
	str	q0, [sp, #160]                  ; 16-byte Folded Spill
Lloh174:
	adrp	x8, lCPI33_5@PAGE
Lloh175:
	ldr	q0, [x8, lCPI33_5@PAGEOFF]
	str	q0, [sp, #144]                  ; 16-byte Folded Spill
Lloh176:
	adrp	x8, lCPI33_6@PAGE
Lloh177:
	ldr	q0, [x8, lCPI33_6@PAGEOFF]
	str	q0, [sp, #128]                  ; 16-byte Folded Spill
Lloh178:
	adrp	x8, lCPI33_7@PAGE
Lloh179:
	ldr	q0, [x8, lCPI33_7@PAGEOFF]
	str	q0, [sp, #112]                  ; 16-byte Folded Spill
Lloh180:
	adrp	x8, lCPI33_8@PAGE
Lloh181:
	ldr	q0, [x8, lCPI33_8@PAGEOFF]
	str	q0, [sp, #96]                   ; 16-byte Folded Spill
Lloh182:
	adrp	x8, lCPI33_9@PAGE
Lloh183:
	ldr	q0, [x8, lCPI33_9@PAGEOFF]
	str	q0, [sp, #80]                   ; 16-byte Folded Spill
Lloh184:
	adrp	x8, lCPI33_10@PAGE
Lloh185:
	ldr	q0, [x8, lCPI33_10@PAGEOFF]
	str	q0, [sp, #64]                   ; 16-byte Folded Spill
Lloh186:
	adrp	x8, lCPI33_11@PAGE
Lloh187:
	ldr	q0, [x8, lCPI33_11@PAGEOFF]
	str	q0, [sp, #48]                   ; 16-byte Folded Spill
Lloh188:
	adrp	x8, lCPI33_12@PAGE
Lloh189:
	ldr	q0, [x8, lCPI33_12@PAGEOFF]
	str	q0, [sp, #32]                   ; 16-byte Folded Spill
Lloh190:
	adrp	x8, lCPI33_13@PAGE
Lloh191:
	ldr	q0, [x8, lCPI33_13@PAGEOFF]
	str	q0, [sp, #16]                   ; 16-byte Folded Spill
Lloh192:
	adrp	x8, lCPI33_14@PAGE
Lloh193:
	ldr	q0, [x8, lCPI33_14@PAGEOFF]
	str	q0, [sp]                        ; 16-byte Folded Spill
LBB33_7:                                ; %bb2
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v0, x19
	add	x8, x19, #31
	ldr	q1, [sp, #224]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #8]
	ldr	q1, [sp, #208]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #24]
	ldr	q1, [sp, #192]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #40]
	ldr	q1, [sp, #176]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #56]
	ldr	q1, [sp, #160]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #72]
	ldr	q1, [sp, #144]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #88]
	ldr	q1, [sp, #128]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #104]
	ldr	q1, [sp, #112]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #120]
	ldr	q1, [sp, #96]                   ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #136]
	ldr	q1, [sp, #80]                   ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #152]
	ldr	q1, [sp, #64]                   ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #168]
	ldr	q1, [sp, #48]                   ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #184]
	ldr	q1, [sp, #32]                   ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #200]
	ldr	q1, [sp, #16]                   ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #216]
	ldr	q1, [sp]                        ; 16-byte Folded Reload
	add.2d	v0, v0, v1
	stur	q0, [x23, #232]
	str	x19, [sp, #576]
	str	x8, [sp, #824]
	add	x0, sp, #304
	add	x1, sp, #272
	add	x3, sp, #576
	add	x4, sp, #288
	mov	x2, x21
	bl	_wf_hash_map.hash_map_put$instance$28da32efc51c2b65
	add	x0, sp, #304
	add	x1, sp, #240
	bl	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
	add	x19, x19, #1
	add	x21, x21, #2
	subs	x20, x20, #1
	b.ne	LBB33_7
; %bb.8:                                ; %bb4.loopexit
	ldp	x9, x8, [sp, #272]
	ldr	x21, [x9]
	b	LBB33_10
LBB33_9:
	mov	x8, #0                          ; =0x0
LBB33_10:                               ; %bb4
	add	x19, x8, x21, lsl #32
	add	x0, sp, #272
	add	x1, sp, #240
	bl	_wf_hash_map.hash_map_free$instance$d5f8785ab7665d71
	ldp	x8, x9, [sp, #240]
	ldp	x10, x11, [sp, #256]
	eor	x8, x8, x8, lsr #30
	mov	x12, #58809                     ; =0xe5b9
	movk	x12, #7396, lsl #16
	movk	x12, #18285, lsl #32
	movk	x12, #48984, lsl #48
	mul	x8, x8, x12
	eor	x8, x8, x8, lsr #27
	mov	x13, #4587                      ; =0x11eb
	movk	x13, #4913, lsl #16
	movk	x13, #18875, lsl #32
	movk	x13, #38096, lsl #48
	mul	x8, x8, x13
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x12
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x13
	eor	x12, x9, x8
	mul	x11, x11, x22
	eor	x10, x19, x10
	eor	x10, x10, x11
	eor	x10, x10, x12, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	add	sp, sp, #832
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB33_11:                               ; %window.block.oom.v1.i.i.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh192, Lloh193
	.loh AdrpAdrp	Lloh190, Lloh192
	.loh AdrpLdr	Lloh190, Lloh191
	.loh AdrpAdrp	Lloh188, Lloh190
	.loh AdrpLdr	Lloh188, Lloh189
	.loh AdrpAdrp	Lloh186, Lloh188
	.loh AdrpLdr	Lloh186, Lloh187
	.loh AdrpAdrp	Lloh184, Lloh186
	.loh AdrpLdr	Lloh184, Lloh185
	.loh AdrpAdrp	Lloh182, Lloh184
	.loh AdrpLdr	Lloh182, Lloh183
	.loh AdrpAdrp	Lloh180, Lloh182
	.loh AdrpLdr	Lloh180, Lloh181
	.loh AdrpAdrp	Lloh178, Lloh180
	.loh AdrpLdr	Lloh178, Lloh179
	.loh AdrpAdrp	Lloh176, Lloh178
	.loh AdrpLdr	Lloh176, Lloh177
	.loh AdrpAdrp	Lloh174, Lloh176
	.loh AdrpLdr	Lloh174, Lloh175
	.loh AdrpAdrp	Lloh172, Lloh174
	.loh AdrpLdr	Lloh172, Lloh173
	.loh AdrpAdrp	Lloh170, Lloh172
	.loh AdrpLdr	Lloh170, Lloh171
	.loh AdrpAdrp	Lloh168, Lloh170
	.loh AdrpLdr	Lloh168, Lloh169
	.loh AdrpAdrp	Lloh166, Lloh168
	.loh AdrpLdr	Lloh166, Lloh167
	.loh AdrpAdrp	Lloh164, Lloh166
	.loh AdrpLdr	Lloh164, Lloh165
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_new$instance$a62a753cf2b0b5ca ; -- Begin function wf_hash_map.hash_map_new$instance$a62a753cf2b0b5ca
	.p2align	2
_wf_hash_map.hash_map_new$instance$a62a753cf2b0b5ca: ; @"wf_hash_map.hash_map_new$instance$a62a753cf2b0b5ca"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB34_6
; %bb.1:                                ; %bb1.i.i
	stp	xzr, x19, [x0]
	cbz	x19, LBB34_5
; %bb.2:                                ; %bb5.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
LBB34_3:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x9], #24
	cmp	x19, x8
	b.ne	LBB34_3
; %bb.4:                                ; %bb4.bb7_crit_edge.i.i
	str	x19, [x0]
LBB34_5:                                ; %"wf_hash_map.hash_map_new$instance$a62a753cf2b0b5ca.body.exit"
	mov	x1, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB34_6:                                ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_put$instance$c7b22b9ef52855b6 ; -- Begin function wf_hash_map.hash_map_put$instance$c7b22b9ef52855b6
	.p2align	2
_wf_hash_map.hash_map_put$instance$c7b22b9ef52855b6: ; @"wf_hash_map.hash_map_put$instance$c7b22b9ef52855b6"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #112
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 112
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x4
	mov	x21, x1
	mov	x19, x0
	mov	x23, sp
	mov	x0, sp
	bl	_wf_hash_map.hash_map_try_put$instance$c7b22b9ef52855b6
	ldr	w8, [sp]
	cbz	w8, LBB35_5
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB35_11
; %bb.2:                                ; %bb2
	mov	x22, sp
	ldrb	w8, [sp, #4]
	ldur	q0, [sp, #8]
	stur	q0, [x23, #24]
	tbz	w8, #0, LBB35_6
; %bb.3:                                ; %bb4
	ldr	x8, [x21]
	ldr	x8, [x8]
	cmp	x8, #3
	b.lo	LBB35_8
LBB35_4:                                ; %bb6
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	strb	w8, [x19, #4]
	b	LBB35_7
LBB35_5:                                ; %bb1
	stp	xzr, xzr, [x19]
	str	xzr, [x19, #16]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB35_6:                                ; %bb3
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
LBB35_7:                                ; %common.ret
	ldur	q0, [x22, #8]
	stur	q0, [x19, #8]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB35_8:                                ; %bb7
	mov	w9, #1                          ; =0x1
	mov	w10, #3                         ; =0x3
	lsl	x11, x8, #1
	cmp	x8, #2
	csel	x10, x10, x11, eq
	cmp	x8, #0
	csel	x1, x9, x10, eq
	cmp	x1, x8
	b.ls	LBB35_12
; %bb.9:                                ; %"wf_hash_map.hash_map_reserve$instance$c7b22b9ef52855b6.exit"
	mov	x0, x21
	mov	x2, x20
	bl	_wf_hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6
	cbz	w0, LBB35_12
; %bb.10:                               ; %"wf_hash_map.hash_map_reserve$instance$c7b22b9ef52855b6.exit"
	cmp	w0, #1
	b.eq	LBB35_4
LBB35_11:                               ; %invalid.tag.b0
	bl	_abort
LBB35_12:                               ; %bb17
	ldp	x2, x3, [sp, #24]
	mov	x0, x19
	mov	x1, x21
	mov	x4, x20
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
	b	_wf_hash_map.hash_map_try_put$instance$c7b22b9ef52855b6
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd ; -- Begin function wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd
	.p2align	2
_wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd: ; @"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd"
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cbz	w8, LBB36_3
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB36_4
; %bb.2:                                ; %bb3
	ldp	x9, x8, [x0, #8]
	ldrb	w10, [x0, #4]
	ldr	x11, [x1]
	mov	w12, #131                       ; =0x83
	tst	w10, #0x1
	mov	w10, #1                         ; =0x1
	cinc	x10, x10, ne
	madd	x10, x11, x12, x10
	add	x9, x10, x9
	madd	x8, x9, x12, x8
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
LBB36_3:                                ; %bb2
	ldr	x8, [x1]
	mov	w9, #131                        ; =0x83
	mul	x8, x8, x9
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
LBB36_4:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_free$instance$5c6f40d0925a4760 ; -- Begin function wf_hash_map.hash_map_free$instance$5c6f40d0925a4760
	.p2align	2
_wf_hash_map.hash_map_free$instance$5c6f40d0925a4760: ; @"wf_hash_map.hash_map_free$instance$5c6f40d0925a4760"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0]
	ldr	x12, [x0]
	cbz	x12, LBB37_6
; %bb.1:                                ; %bb5.lr.ph
	ldp	x8, x9, [x1, #8]
	ldr	x10, [x1, #24]
	sub	x11, x12, #1
	mov	w13, #24                        ; =0x18
	madd	x12, x12, x13, x0
	mov	w13, #131                       ; =0x83
	mov	x14, #58809                     ; =0xe5b9
	movk	x14, #7396, lsl #16
	movk	x14, #18285, lsl #32
	movk	x14, #48984, lsl #48
	mov	x15, #4587                      ; =0x11eb
	movk	x15, #4913, lsl #16
	movk	x15, #18875, lsl #32
	movk	x15, #38096, lsl #48
	b	LBB37_3
LBB37_2:                                ; %bb6
                                        ;   in Loop: Header=BB37_3 Depth=1
	sub	x11, x11, #1
	sub	x12, x12, #24
	cmn	x11, #1
	b.eq	LBB37_6
LBB37_3:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	str	x11, [x0]
	ldur	w16, [x12, #-8]
	cmp	w16, #2
	b.lo	LBB37_2
; %bb.4:                                ; %bb5
                                        ;   in Loop: Header=BB37_3 Depth=1
	b.ne	LBB37_7
; %bb.5:                                ; %bb7
                                        ;   in Loop: Header=BB37_3 Depth=1
	ldp	x17, x16, [x12]
	madd	x16, x17, x13, x16
	add	x8, x16, x8
	eor	x16, x16, x16, lsr #30
	mul	x16, x16, x14
	eor	x16, x16, x16, lsr #27
	mul	x16, x16, x15
	eor	x9, x9, x16, lsr #31
	eor	x9, x9, x16
	stp	x8, x9, [x1, #8]
	add	x10, x10, #1
	str	x10, [x1, #24]
	b	LBB37_2
LBB37_6:                                ; %bb4
	bl	_free
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB37_7:                                ; %invalid.tag.b3
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_new$instance$820b2044b97e0fbd ; -- Begin function wf_hash_map.hash_map_new$instance$820b2044b97e0fbd
	.p2align	2
_wf_hash_map.hash_map_new$instance$820b2044b97e0fbd: ; @"wf_hash_map.hash_map_new$instance$820b2044b97e0fbd"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB38_6
; %bb.1:                                ; %bb1.i.i
	stp	xzr, x19, [x0]
	cbz	x19, LBB38_5
; %bb.2:                                ; %bb5.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
LBB38_3:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x9], #24
	cmp	x19, x8
	b.ne	LBB38_3
; %bb.4:                                ; %bb4.bb7_crit_edge.i.i
	str	x19, [x0]
LBB38_5:                                ; %"wf_hash_map.hash_map_new$instance$820b2044b97e0fbd.body.exit"
	mov	x1, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB38_6:                                ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad ; -- Begin function wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad
	.p2align	2
_wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad: ; @"wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #112
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 112
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x4
	mov	x21, x1
	mov	x19, x0
	mov	x23, sp
	mov	x0, sp
	bl	_wf_hash_map.hash_map_try_put$instance$fde7c6722a8b0dad
	ldr	w8, [sp]
	cbz	w8, LBB39_5
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB39_11
; %bb.2:                                ; %bb2
	mov	x22, sp
	ldrb	w8, [sp, #4]
	ldur	q0, [sp, #8]
	stur	q0, [x23, #24]
	tbz	w8, #0, LBB39_6
; %bb.3:                                ; %bb4
	ldr	x8, [x21]
	ldr	x8, [x8]
	cmp	x8, #4, lsl #12                 ; =16384
	b.lo	LBB39_8
LBB39_4:                                ; %bb6
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	strb	w8, [x19, #4]
	b	LBB39_7
LBB39_5:                                ; %bb1
	stp	xzr, xzr, [x19]
	str	xzr, [x19, #16]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB39_6:                                ; %bb3
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
LBB39_7:                                ; %common.ret
	ldur	q0, [x22, #8]
	stur	q0, [x19, #8]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB39_8:                                ; %bb7
	mov	w9, #8192                       ; =0x2000
	cmp	x8, #2, lsl #12                 ; =8192
	csel	x9, x8, x9, lo
	lsl	x9, x9, #1
	cmp	x8, #0
	csinc	x1, x9, xzr, ne
	cmp	x1, x8
	b.ls	LBB39_12
; %bb.9:                                ; %"wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit"
	mov	x0, x21
	mov	x2, x20
	bl	_wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	cbz	w0, LBB39_12
; %bb.10:                               ; %"wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit"
	cmp	w0, #1
	b.eq	LBB39_4
LBB39_11:                               ; %invalid.tag.b0
	bl	_abort
LBB39_12:                               ; %bb17
	ldp	x2, x3, [sp, #24]
	mov	x0, x19
	mov	x1, x21
	mov	x4, x20
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
	b	_wf_hash_map.hash_map_try_put$instance$fde7c6722a8b0dad
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_remove$instance$fde7c6722a8b0dad ; -- Begin function wf_hash_map.hash_map_remove$instance$fde7c6722a8b0dad
	.p2align	2
_wf_hash_map.hash_map_remove$instance$fde7c6722a8b0dad: ; @"wf_hash_map.hash_map_remove$instance$fde7c6722a8b0dad"
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	ldr	x20, [x0, #8]
	cbz	x20, LBB40_4
; %bb.1:                                ; %bb3.i
	mov	x19, x0
	bl	_wf_hash_map.hash_map_find$instance$fde7c6722a8b0dad
	cmp	w0, #1
	b.eq	LBB40_4
; %bb.2:                                ; %bb3.i
	cbnz	w0, LBB40_7
; %bb.3:                                ; %bb4.i
	ldr	x8, [x19]
	mov	w9, #24                         ; =0x18
	madd	x8, x1, x9, x8
	ldr	w9, [x8, #16]
	ldp	x1, x2, [x8, #24]
	mov	w10, #1                         ; =0x1
	str	w10, [x8, #16]
	stp	xzr, xzr, [x8, #24]
	cmp	w9, #2
	b.hs	LBB40_5
LBB40_4:
	mov	w0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB40_5:                                ; %bb4.i
	b.ne	LBB40_7
; %bb.6:                                ; %bb6.i
	sub	x8, x20, #1
	str	x8, [x19, #8]
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB40_7:                                ; %invalid.tag.b1.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50 ; -- Begin function wf_hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50
	.p2align	2
_wf_hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50: ; @"wf_hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50"
; %bb.0:                                ; %entry
	ldrb	w8, [x2, #8]
	tbz	w8, #0, LBB41_2
; %bb.1:
	mov	x10, #0                         ; =0x0
	ldr	x9, [x0]
	ldr	x8, [x9]
	cbnz	x8, LBB41_3
	b	LBB41_17
LBB41_2:                                ; %bb3.i.i
	ldr	x8, [x2]
	ldr	x9, [x1]
	eor	x8, x9, x8
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x10, x8, x8, lsr #31
	ldr	x9, [x0]
	ldr	x8, [x9]
	cbz	x8, LBB41_17
LBB41_3:                                ; %bb12.preheader.i
	udiv	x11, x10, x8
	msub	x11, x11, x8, x10
	mov	w12, #24                        ; =0x18
	mov	x10, x11
	b	LBB41_5
LBB41_4:                                ; %bb22.i
                                        ;   in Loop: Header=BB41_5 Depth=1
	add	x10, x10, #1
	cmp	x10, x8
	b.eq	LBB41_8
LBB41_5:                                ; %bb12.i
                                        ; =>This Inner Loop Header: Depth=1
	madd	x13, x10, x12, x9
	ldr	w14, [x13, #16]!
	cmp	w14, #1
	b.eq	LBB41_4
; %bb.6:                                ; %bb12.i
                                        ;   in Loop: Header=BB41_5 Depth=1
	cmp	w14, #2
	b.ne	LBB41_15
; %bb.7:                                ; %bb16.i
                                        ;   in Loop: Header=BB41_5 Depth=1
	ldr	x13, [x13, #8]
	ldr	x14, [x1]
	cmp	x13, x14
	b.ne	LBB41_4
	b	LBB41_14
LBB41_8:                                ; %bb23.i
	cbz	x11, LBB41_16
; %bb.9:                                ; %bb12.1.i.preheader
	mov	x10, #0                         ; =0x0
	add	x12, x9, #24
	b	LBB41_11
LBB41_10:                               ; %bb22.1.i
                                        ;   in Loop: Header=BB41_11 Depth=1
	add	x10, x10, #1
	add	x12, x12, #24
	cmp	x11, x10
	b.eq	LBB41_16
LBB41_11:                               ; %bb12.1.i
                                        ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x12, #-8]
	cmp	w8, #1
	b.eq	LBB41_10
; %bb.12:                               ; %bb12.1.i
                                        ;   in Loop: Header=BB41_11 Depth=1
	cmp	w8, #2
	b.ne	LBB41_18
; %bb.13:                               ; %bb16.1.i
                                        ;   in Loop: Header=BB41_11 Depth=1
	ldr	x8, [x12]
	ldr	x13, [x1]
	cmp	x8, x13
	b.ne	LBB41_10
LBB41_14:                               ; %bb20.i
	mov	w0, #0                          ; =0x0
	mov	w8, #24                         ; =0x18
	madd	x8, x10, x8, x9
	ldr	x8, [x8, #32]
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ret
LBB41_15:                               ; %bb12.i
	cbnz	w14, LBB41_19
LBB41_16:                               ; %"wf_hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50.body.exit.loopexit55"
	mov	x8, #0                          ; =0x0
LBB41_17:                               ; %"wf_hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50.body.exit"
	mov	w0, #1                          ; =0x1
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ret
LBB41_18:                               ; %bb12.1.i
	cbz	w8, LBB41_17
LBB41_19:                               ; %invalid.tag.b12.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_rehash$instance$fde7c6722a8b0dad ; -- Begin function wf_hash_map.hash_map_rehash$instance$fde7c6722a8b0dad
	.p2align	2
_wf_hash_map.hash_map_rehash$instance$fde7c6722a8b0dad: ; @"wf_hash_map.hash_map_rehash$instance$fde7c6722a8b0dad"
	.cfi_startproc
; %bb.0:                                ; %entry
	mov	x2, x1
	ldr	x8, [x0]
	ldr	x1, [x8]
	b	_wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad ; -- Begin function wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad
	.p2align	2
_wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad: ; @"wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad"
	.cfi_startproc
; %bb.0:                                ; %entry
	cmp	x1, #4, lsl #12                 ; =16384
	b.ls	LBB43_2
; %bb.1:
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	ret
LBB43_2:                                ; %bb3.i
	ldr	x8, [x0]
	ldr	x8, [x8]
	cmp	x1, x8
	b.ls	LBB43_4
; %bb.3:                                ; %bb6.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB43_4:
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_capacity$instance$820b2044b97e0fbd ; -- Begin function wf_hash_map.hash_map_capacity$instance$820b2044b97e0fbd
	.p2align	2
_wf_hash_map.hash_map_capacity$instance$820b2044b97e0fbd: ; @"wf_hash_map.hash_map_capacity$instance$820b2044b97e0fbd"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x0, [x8]
	ret
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_edit$instance$25497bb333d90567 ; -- Begin function wf_hash_map.hash_map_edit$instance$25497bb333d90567
	.p2align	2
_wf_hash_map.hash_map_edit$instance$25497bb333d90567: ; @"wf_hash_map.hash_map_edit$instance$25497bb333d90567"
; %bb.0:                                ; %entry
	ldrb	w8, [x2, #8]
	tbz	w8, #0, LBB45_2
; %bb.1:
	mov	x10, #0                         ; =0x0
	ldr	x9, [x0]
	ldr	x8, [x9]
	cbnz	x8, LBB45_3
	b	LBB45_17
LBB45_2:                                ; %bb3.i.i
	ldr	x8, [x2]
	ldr	x9, [x1]
	eor	x8, x9, x8
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x10, x8, x8, lsr #31
	ldr	x9, [x0]
	ldr	x8, [x9]
	cbz	x8, LBB45_17
LBB45_3:                                ; %bb12.preheader.i
	udiv	x11, x10, x8
	msub	x11, x11, x8, x10
	mov	w12, #24                        ; =0x18
	mov	x10, x11
	b	LBB45_5
LBB45_4:                                ; %bb22.i
                                        ;   in Loop: Header=BB45_5 Depth=1
	add	x10, x10, #1
	cmp	x10, x8
	b.eq	LBB45_8
LBB45_5:                                ; %bb12.i
                                        ; =>This Inner Loop Header: Depth=1
	madd	x13, x10, x12, x9
	ldr	w14, [x13, #16]!
	cmp	w14, #1
	b.eq	LBB45_4
; %bb.6:                                ; %bb12.i
                                        ;   in Loop: Header=BB45_5 Depth=1
	cmp	w14, #2
	b.ne	LBB45_15
; %bb.7:                                ; %bb16.i
                                        ;   in Loop: Header=BB45_5 Depth=1
	ldr	x13, [x13, #8]
	ldr	x14, [x1]
	cmp	x13, x14
	b.ne	LBB45_4
	b	LBB45_14
LBB45_8:                                ; %bb23.i
	cbz	x11, LBB45_16
; %bb.9:                                ; %bb12.1.i.preheader
	mov	x10, #0                         ; =0x0
	add	x12, x9, #24
	b	LBB45_11
LBB45_10:                               ; %bb22.1.i
                                        ;   in Loop: Header=BB45_11 Depth=1
	add	x10, x10, #1
	add	x12, x12, #24
	cmp	x11, x10
	b.eq	LBB45_16
LBB45_11:                               ; %bb12.1.i
                                        ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x12, #-8]
	cmp	w8, #1
	b.eq	LBB45_10
; %bb.12:                               ; %bb12.1.i
                                        ;   in Loop: Header=BB45_11 Depth=1
	cmp	w8, #2
	b.ne	LBB45_18
; %bb.13:                               ; %bb16.1.i
                                        ;   in Loop: Header=BB45_11 Depth=1
	ldr	x8, [x12]
	ldr	x13, [x1]
	cmp	x8, x13
	b.ne	LBB45_10
LBB45_14:                               ; %bb20.i
	mov	w0, #0                          ; =0x0
	mov	w8, #24                         ; =0x18
	madd	x9, x10, x8, x9
	ldr	x8, [x9, #32]
	add	x8, x8, #1
	str	x8, [x9, #32]
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ret
LBB45_15:                               ; %bb12.i
	cbnz	w14, LBB45_19
LBB45_16:                               ; %"wf_hash_map.hash_map_edit$instance$25497bb333d90567.body.exit.loopexit55"
	mov	x8, #0                          ; =0x0
LBB45_17:                               ; %"wf_hash_map.hash_map_edit$instance$25497bb333d90567.body.exit"
	mov	w0, #1                          ; =0x1
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ret
LBB45_18:                               ; %bb12.1.i
	cbz	w8, LBB45_17
LBB45_19:                               ; %invalid.tag.b12.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_free$instance$001ff12ace7d7c19 ; -- Begin function wf_hash_map.hash_map_free$instance$001ff12ace7d7c19
	.p2align	2
_wf_hash_map.hash_map_free$instance$001ff12ace7d7c19: ; @"wf_hash_map.hash_map_free$instance$001ff12ace7d7c19"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0]
	ldr	x12, [x0]
	cbz	x12, LBB46_6
; %bb.1:                                ; %bb5.lr.ph
	ldp	x8, x9, [x1, #8]
	ldr	x10, [x1, #24]
	sub	x11, x12, #1
	mov	w13, #24                        ; =0x18
	madd	x12, x12, x13, x0
	mov	w13, #131                       ; =0x83
	mov	x14, #58809                     ; =0xe5b9
	movk	x14, #7396, lsl #16
	movk	x14, #18285, lsl #32
	movk	x14, #48984, lsl #48
	mov	x15, #4587                      ; =0x11eb
	movk	x15, #4913, lsl #16
	movk	x15, #18875, lsl #32
	movk	x15, #38096, lsl #48
	b	LBB46_3
LBB46_2:                                ; %bb6
                                        ;   in Loop: Header=BB46_3 Depth=1
	sub	x11, x11, #1
	sub	x12, x12, #24
	cmn	x11, #1
	b.eq	LBB46_6
LBB46_3:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	str	x11, [x0]
	ldur	w16, [x12, #-8]
	cmp	w16, #2
	b.lo	LBB46_2
; %bb.4:                                ; %bb5
                                        ;   in Loop: Header=BB46_3 Depth=1
	b.ne	LBB46_7
; %bb.5:                                ; %bb7
                                        ;   in Loop: Header=BB46_3 Depth=1
	ldp	x17, x16, [x12]
	madd	x16, x17, x13, x16
	add	x8, x16, x8
	eor	x16, x16, x16, lsr #30
	mul	x16, x16, x14
	eor	x16, x16, x16, lsr #27
	mul	x16, x16, x15
	eor	x9, x9, x16, lsr #31
	eor	x9, x9, x16
	stp	x8, x9, [x1, #8]
	add	x10, x10, #1
	str	x10, [x1, #24]
	b	LBB46_2
LBB46_6:                                ; %bb4
	bl	_free
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB46_7:                                ; %invalid.tag.b3
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_new$instance$96033bf6ddb80743 ; -- Begin function wf_hash_map.hash_map_new$instance$96033bf6ddb80743
	.p2align	2
_wf_hash_map.hash_map_new$instance$96033bf6ddb80743: ; @"wf_hash_map.hash_map_new$instance$96033bf6ddb80743"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB47_6
; %bb.1:                                ; %bb1.i.i
	stp	xzr, x19, [x0]
	cbz	x19, LBB47_5
; %bb.2:                                ; %bb5.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
	movi.2d	v0, #0000000000000000
LBB47_3:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	q0, q0, [x9]
	stp	q0, q0, [x9, #32]
	stp	q0, q0, [x9, #64]
	stp	q0, q0, [x9, #96]
	stp	q0, q0, [x9, #128]
	stp	q0, q0, [x9, #160]
	stp	q0, q0, [x9, #192]
	stp	q0, q0, [x9, #224]
	str	xzr, [x9, #256]
	add	x9, x9, #272
	cmp	x19, x8
	b.ne	LBB47_3
; %bb.4:                                ; %bb4.bb7_crit_edge.i.i
	str	x19, [x0]
LBB47_5:                                ; %"wf_hash_map.hash_map_new$instance$96033bf6ddb80743.body.exit"
	mov	x1, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB47_6:                                ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_put$instance$8d5197e2f00c3b07 ; -- Begin function wf_hash_map.hash_map_put$instance$8d5197e2f00c3b07
	.p2align	2
_wf_hash_map.hash_map_put$instance$8d5197e2f00c3b07: ; @"wf_hash_map.hash_map_put$instance$8d5197e2f00c3b07"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #1056
	.cfi_def_cfa_offset 1136
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	mov	x20, x4
	mov	x21, x1
	mov	x19, x0
	ldp	q0, q1, [x3, #192]
	mov	x22, sp
	stp	q0, q1, [sp, #192]
	ldp	q0, q1, [x3, #224]
	stp	q0, q1, [sp, #224]
	ldp	q0, q1, [x3, #128]
	stp	q0, q1, [sp, #128]
	ldp	q0, q1, [x3, #160]
	stp	q0, q1, [sp, #160]
	ldp	q0, q1, [x3, #64]
	stp	q0, q1, [sp, #64]
	ldp	q0, q1, [x3, #96]
	stp	q0, q1, [sp, #96]
	ldp	q0, q1, [x3]
	stp	q0, q1, [sp]
	ldp	q0, q1, [x3, #32]
	stp	q0, q1, [sp, #32]
	add	x0, x22, #256
	mov	x3, sp
	bl	_wf_hash_map.hash_map_try_put$instance$8d5197e2f00c3b07
	ldr	w8, [sp, #256]
	cbz	w8, LBB48_5
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB48_15
; %bb.2:                                ; %bb2
	mov	x23, sp
	ldrb	w24, [sp, #260]
	add	x0, x22, #528
	add	x1, x23, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	tbz	w24, #0, LBB48_6
; %bb.3:                                ; %bb4
	ldr	x8, [x21]
	ldr	x8, [x8]
	cmp	x8, #3
	b.lo	LBB48_9
LBB48_4:                                ; %bb6
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	strb	w8, [x19, #4]
	add	x0, x19, #8
	add	x1, x23, #264
	b	LBB48_7
LBB48_5:                                ; %bb1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #240]
	stp	q0, q0, [x19, #208]
	stp	q0, q0, [x19, #176]
	stp	q0, q0, [x19, #144]
	stp	q0, q0, [x19, #112]
	stp	q0, q0, [x19, #80]
	stp	q0, q0, [x19, #48]
	stp	q0, q0, [x19, #16]
	str	q0, [x19]
	b	LBB48_8
LBB48_6:                                ; %bb3
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19], #8
	add	x1, x23, #264
	mov	x0, x19
LBB48_7:                                ; %common.ret
	mov	w2, #264                        ; =0x108
	bl	_memcpy
LBB48_8:                                ; %common.ret
	add	sp, sp, #1056
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
LBB48_9:                                ; %bb7
	cbz	x8, LBB48_12
; %bb.10:                               ; %bb7
	cmp	x8, #2
	b.ne	LBB48_16
; %bb.11:                               ; %bb3.i.i.fold.split
	mov	w1, #3                          ; =0x3
	cmp	x1, x8
	b.hi	LBB48_13
	b	LBB48_17
LBB48_12:
	mov	w1, #1                          ; =0x1
	cmp	x1, x8
	b.ls	LBB48_17
LBB48_13:                               ; %"wf_hash_map.hash_map_reserve$instance$8d5197e2f00c3b07.exit"
	mov	x0, x21
	mov	x2, x20
	bl	_wf_hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07
	str	w0, [sp, #792]
	strb	w1, [sp, #796]
	strb	w2, [sp, #797]
	cbz	w0, LBB48_18
; %bb.14:                               ; %"wf_hash_map.hash_map_reserve$instance$8d5197e2f00c3b07.exit"
	cmp	w0, #1
	b.eq	LBB48_4
LBB48_15:                               ; %invalid.tag.b0
	bl	_abort
LBB48_16:                               ; %bb8
	lsl	x1, x8, #1
	cmp	x1, x8
	b.hi	LBB48_13
LBB48_17:                               ; %"wf_hash_map.hash_map_reserve$instance$8d5197e2f00c3b07.exit.thread"
	str	wzr, [sp, #792]
	strh	wzr, [sp, #796]
LBB48_18:                               ; %bb17
	add	x3, x22, #800
	ldr	x2, [sp, #528]
	mov	x8, sp
	add	x8, x8, #536
	ldp	q0, q1, [x8, #192]
	stp	q0, q1, [x3, #192]
	ldp	q0, q1, [x8, #224]
	stp	q0, q1, [x3, #224]
	ldp	q0, q1, [x8, #128]
	stp	q0, q1, [x3, #128]
	ldp	q0, q1, [x8, #160]
	stp	q0, q1, [x3, #160]
	ldp	q0, q1, [x8, #64]
	stp	q0, q1, [x3, #64]
	ldp	q0, q1, [x8, #96]
	stp	q0, q1, [x3, #96]
	ldp	q0, q1, [x8]
	stp	q0, q1, [x3]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x3, #32]
	mov	x0, x19
	mov	x1, x21
	mov	x4, x20
	bl	_wf_hash_map.hash_map_try_put$instance$8d5197e2f00c3b07
	b	LBB48_8
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027 ; -- Begin function wf_map_cost_library_policy_result$instance$4250cb78d3f44027
	.p2align	2
_wf_map_cost_library_policy_result$instance$4250cb78d3f44027: ; @"wf_map_cost_library_policy_result$instance$4250cb78d3f44027"
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cbz	w8, LBB49_3
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB49_4
; %bb.2:                                ; %bb3
	ldrb	w9, [x0, #4]
	ldr	x10, [x1]
	mov	w8, #131                        ; =0x83
	tst	w9, #0x1
	mov	w9, #1                          ; =0x1
	cinc	x9, x9, ne
	madd	x9, x10, x8, x9
	ldp	x11, x10, [x0, #8]
	madd	x10, x11, x8, x10
	ldr	x11, [x0, #24]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #32]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #40]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #48]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #56]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #64]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #72]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #80]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #88]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #96]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #104]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #112]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #120]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #128]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #136]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #144]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #152]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #160]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #168]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #176]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #184]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #192]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #200]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #208]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #216]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #224]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #232]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #240]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #248]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #256]
	madd	x10, x10, x8, x11
	add	x9, x10, x9
	ldr	x10, [x0, #264]
	madd	x8, x9, x8, x10
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
LBB49_3:                                ; %bb2
	ldr	x8, [x1]
	mov	w9, #131                        ; =0x83
	mul	x8, x8, x9
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
LBB49_4:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_free$instance$72d84b2e6d0b7146 ; -- Begin function wf_hash_map.hash_map_free$instance$72d84b2e6d0b7146
	.p2align	2
_wf_hash_map.hash_map_free$instance$72d84b2e6d0b7146: ; @"wf_hash_map.hash_map_free$instance$72d84b2e6d0b7146"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0]
	ldr	x11, [x0]
	cbz	x11, LBB50_6
; %bb.1:                                ; %bb5.lr.ph
	ldp	x8, x9, [x1, #8]
	sub	x10, x11, #1
	mov	w12, #272                       ; =0x110
	madd	x12, x11, x12, x0
	ldr	x11, [x1, #24]
	sub	x12, x12, #120
	mov	w13, #131                       ; =0x83
	mov	x14, #58809                     ; =0xe5b9
	movk	x14, #7396, lsl #16
	movk	x14, #18285, lsl #32
	movk	x14, #48984, lsl #48
	mov	x15, #4587                      ; =0x11eb
	movk	x15, #4913, lsl #16
	movk	x15, #18875, lsl #32
	movk	x15, #38096, lsl #48
	b	LBB50_3
LBB50_2:                                ; %bb6
                                        ;   in Loop: Header=BB50_3 Depth=1
	sub	x10, x10, #1
	sub	x12, x12, #272
	cmn	x10, #1
	b.eq	LBB50_6
LBB50_3:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	str	x10, [x0]
	ldur	w16, [x12, #-136]
	cmp	w16, #2
	b.lo	LBB50_2
; %bb.4:                                ; %bb5
                                        ;   in Loop: Header=BB50_3 Depth=1
	b.ne	LBB50_7
; %bb.5:                                ; %bb7
                                        ;   in Loop: Header=BB50_3 Depth=1
	ldp	x17, x16, [x12, #-128]
	madd	x16, x17, x13, x16
	ldur	x17, [x12, #-112]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-104]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-96]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-88]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-80]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-72]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-64]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-56]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-48]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-40]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-32]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-24]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-16]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-8]
	madd	x16, x16, x13, x17
	ldr	x17, [x12]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #8]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #16]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #24]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #32]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #40]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #48]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #56]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #64]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #72]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #80]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #88]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #96]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #104]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #112]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #120]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #128]
	madd	x16, x16, x13, x17
	add	x8, x16, x8
	eor	x16, x16, x16, lsr #30
	mul	x16, x16, x14
	eor	x16, x16, x16, lsr #27
	mul	x16, x16, x15
	eor	x9, x9, x16, lsr #31
	eor	x9, x9, x16
	stp	x8, x9, [x1, #8]
	add	x11, x11, #1
	str	x11, [x1, #24]
	b	LBB50_2
LBB50_6:                                ; %bb4
	bl	_free
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB50_7:                                ; %invalid.tag.b3
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_new$instance$0e108827ecbbe374 ; -- Begin function wf_hash_map.hash_map_new$instance$0e108827ecbbe374
	.p2align	2
_wf_hash_map.hash_map_new$instance$0e108827ecbbe374: ; @"wf_hash_map.hash_map_new$instance$0e108827ecbbe374"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB51_6
; %bb.1:                                ; %bb1.i.i
	stp	xzr, x19, [x0]
	cbz	x19, LBB51_5
; %bb.2:                                ; %bb5.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
	movi.2d	v0, #0000000000000000
LBB51_3:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	q0, q0, [x9]
	stp	q0, q0, [x9, #32]
	stp	q0, q0, [x9, #64]
	stp	q0, q0, [x9, #96]
	stp	q0, q0, [x9, #128]
	stp	q0, q0, [x9, #160]
	stp	q0, q0, [x9, #192]
	stp	q0, q0, [x9, #224]
	str	xzr, [x9, #256]
	add	x9, x9, #272
	cmp	x19, x8
	b.ne	LBB51_3
; %bb.4:                                ; %bb4.bb7_crit_edge.i.i
	str	x19, [x0]
LBB51_5:                                ; %"wf_hash_map.hash_map_new$instance$0e108827ecbbe374.body.exit"
	mov	x1, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB51_6:                                ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_put$instance$28da32efc51c2b65 ; -- Begin function wf_hash_map.hash_map_put$instance$28da32efc51c2b65
	.p2align	2
_wf_hash_map.hash_map_put$instance$28da32efc51c2b65: ; @"wf_hash_map.hash_map_put$instance$28da32efc51c2b65"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #1056
	.cfi_def_cfa_offset 1136
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	mov	x20, x4
	mov	x21, x1
	mov	x19, x0
	ldp	q0, q1, [x3, #192]
	mov	x22, sp
	stp	q0, q1, [sp, #192]
	ldp	q0, q1, [x3, #224]
	stp	q0, q1, [sp, #224]
	ldp	q0, q1, [x3, #128]
	stp	q0, q1, [sp, #128]
	ldp	q0, q1, [x3, #160]
	stp	q0, q1, [sp, #160]
	ldp	q0, q1, [x3, #64]
	stp	q0, q1, [sp, #64]
	ldp	q0, q1, [x3, #96]
	stp	q0, q1, [sp, #96]
	ldp	q0, q1, [x3]
	stp	q0, q1, [sp]
	ldp	q0, q1, [x3, #32]
	stp	q0, q1, [sp, #32]
	add	x0, x22, #256
	mov	x3, sp
	bl	_wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65
	ldr	w8, [sp, #256]
	cbz	w8, LBB52_5
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB52_12
; %bb.2:                                ; %bb2
	mov	x23, sp
	ldrb	w24, [sp, #260]
	add	x0, x22, #528
	add	x1, x23, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	tbz	w24, #0, LBB52_6
; %bb.3:                                ; %bb4
	ldr	x8, [x21]
	ldr	x8, [x8]
	cmp	x8, #4, lsl #12                 ; =16384
	b.lo	LBB52_9
LBB52_4:                                ; %bb6
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	strb	w8, [x19, #4]
	add	x0, x19, #8
	add	x1, x23, #264
	b	LBB52_7
LBB52_5:                                ; %bb1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #240]
	stp	q0, q0, [x19, #208]
	stp	q0, q0, [x19, #176]
	stp	q0, q0, [x19, #144]
	stp	q0, q0, [x19, #112]
	stp	q0, q0, [x19, #80]
	stp	q0, q0, [x19, #48]
	stp	q0, q0, [x19, #16]
	str	q0, [x19]
	b	LBB52_8
LBB52_6:                                ; %bb3
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19], #8
	add	x1, x23, #264
	mov	x0, x19
LBB52_7:                                ; %common.ret
	mov	w2, #264                        ; =0x108
	bl	_memcpy
LBB52_8:                                ; %common.ret
	add	sp, sp, #1056
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
LBB52_9:                                ; %bb7
	mov	w9, #8192                       ; =0x2000
	cmp	x8, #2, lsl #12                 ; =8192
	csel	x9, x8, x9, lo
	lsl	x9, x9, #1
	cmp	x8, #0
	csinc	x1, x9, xzr, ne
	cmp	x1, x8
	b.ls	LBB52_13
; %bb.10:                               ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit"
	mov	x0, x21
	mov	x2, x20
	bl	_wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	str	w0, [sp, #792]
	strb	w1, [sp, #796]
	strb	w2, [sp, #797]
	cbz	w0, LBB52_14
; %bb.11:                               ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit"
	cmp	w0, #1
	b.eq	LBB52_4
LBB52_12:                               ; %invalid.tag.b0
	bl	_abort
LBB52_13:                               ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.thread"
	str	wzr, [sp, #792]
	strh	wzr, [sp, #796]
LBB52_14:                               ; %bb17
	add	x3, x22, #800
	ldr	x2, [sp, #528]
	mov	x8, sp
	add	x8, x8, #536
	ldp	q0, q1, [x8, #192]
	stp	q0, q1, [x3, #192]
	ldp	q0, q1, [x8, #224]
	stp	q0, q1, [x3, #224]
	ldp	q0, q1, [x8, #128]
	stp	q0, q1, [x3, #128]
	ldp	q0, q1, [x8, #160]
	stp	q0, q1, [x3, #160]
	ldp	q0, q1, [x8, #64]
	stp	q0, q1, [x3, #64]
	ldp	q0, q1, [x8, #96]
	stp	q0, q1, [x3, #96]
	ldp	q0, q1, [x8]
	stp	q0, q1, [x3]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x3, #32]
	mov	x0, x19
	mov	x1, x21
	mov	x4, x20
	bl	_wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65
	b	LBB52_8
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_remove$instance$28da32efc51c2b65 ; -- Begin function wf_hash_map.hash_map_remove$instance$28da32efc51c2b65
	.p2align	2
_wf_hash_map.hash_map_remove$instance$28da32efc51c2b65: ; @"wf_hash_map.hash_map_remove$instance$28da32efc51c2b65"
; %bb.0:                                ; %entry
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	mov	x19, x0
	ldr	x21, [x1, #8]
	cbz	x21, LBB53_7
; %bb.1:                                ; %bb3
	mov	x20, x1
	mov	x0, x1
	mov	x1, x2
	mov	x2, x3
	bl	_wf_hash_map.hash_map_find$instance$28da32efc51c2b65
	cmp	w0, #1
	b.eq	LBB53_7
; %bb.2:                                ; %bb3
	cbnz	w0, LBB53_9
; %bb.3:                                ; %bb4
	ldr	x8, [x20]
	mov	w9, #272                        ; =0x110
	madd	x10, x1, x9, x8
	ldr	w9, [x10, #16]!
	ldur	q0, [x10, #8]
	ldur	q1, [x10, #24]
	ldur	q2, [x10, #40]
	ldur	q3, [x10, #56]
	ldur	q4, [x10, #72]
	ldur	q5, [x10, #88]
	ldur	q6, [x10, #104]
	ldur	q7, [x10, #120]
	ldur	q16, [x10, #136]
	ldur	q17, [x10, #152]
	ldur	q18, [x10, #168]
	ldur	q19, [x10, #184]
	ldur	q20, [x10, #200]
	ldur	q21, [x10, #216]
	ldur	q22, [x10, #232]
	ldur	q23, [x10, #248]
	ldr	x8, [x10, #264]
	mov	w11, #1                         ; =0x1
	str	w11, [x10]
	movi.2d	v24, #0000000000000000
	stur	q24, [x10, #8]
	stur	q24, [x10, #24]
	stur	q24, [x10, #40]
	stur	q24, [x10, #56]
	stur	q24, [x10, #72]
	stur	q24, [x10, #88]
	stur	q24, [x10, #104]
	stur	q24, [x10, #120]
	stur	q24, [x10, #136]
	stur	q24, [x10, #152]
	stur	q24, [x10, #168]
	stur	q24, [x10, #184]
	stur	q24, [x10, #200]
	stur	q24, [x10, #216]
	stur	q24, [x10, #232]
	stur	q24, [x10, #248]
	str	xzr, [x10, #264]
	cbz	w9, LBB53_8
; %bb.4:                                ; %bb4
	cmp	w9, #1
	b.eq	LBB53_7
; %bb.5:                                ; %bb4
	cmp	w9, #2
	b.ne	LBB53_9
; %bb.6:                                ; %bb6
	sub	x9, x21, #1
	str	x9, [x20, #8]
	str	xzr, [x19]
	mov	w9, #1                          ; =0x1
	str	w9, [x19]
	stur	q0, [x19, #8]
	stur	q1, [x19, #24]
	stur	q2, [x19, #40]
	stur	q3, [x19, #56]
	stur	q4, [x19, #72]
	stur	q5, [x19, #88]
	stur	q6, [x19, #104]
	stur	q7, [x19, #120]
	stur	q16, [x19, #136]
	stur	q17, [x19, #152]
	stur	q18, [x19, #168]
	stur	q19, [x19, #184]
	stur	q20, [x19, #200]
	stur	q21, [x19, #216]
	stur	q22, [x19, #232]
	stur	q23, [x19, #248]
	str	x8, [x19, #264]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB53_7:                                ; %bb2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #240]
	stp	q0, q0, [x19, #208]
	stp	q0, q0, [x19, #176]
	stp	q0, q0, [x19, #144]
	stp	q0, q0, [x19, #112]
	stp	q0, q0, [x19, #80]
	stp	q0, q0, [x19, #48]
	stp	q0, q0, [x19, #16]
	str	q0, [x19]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB53_8:                                ; %bb7
	stp	q24, q24, [x19, #240]
	stp	q24, q24, [x19, #208]
	stp	q24, q24, [x19, #176]
	stp	q24, q24, [x19, #144]
	stp	q24, q24, [x19, #112]
	stp	q24, q24, [x19, #80]
	stp	q24, q24, [x19, #48]
	stp	q24, q24, [x19, #16]
	str	q24, [x19]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB53_9:                                ; %invalid.tag.b1
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_lookup$instance$000400fb603e42fe ; -- Begin function wf_hash_map.hash_map_lookup$instance$000400fb603e42fe
	.p2align	2
_wf_hash_map.hash_map_lookup$instance$000400fb603e42fe: ; @"wf_hash_map.hash_map_lookup$instance$000400fb603e42fe"
; %bb.0:                                ; %entry
	ldrb	w8, [x2, #8]
	tbz	w8, #0, LBB54_2
; %bb.1:
	mov	x10, #0                         ; =0x0
	ldr	x9, [x0]
	ldr	x8, [x9]
	cbnz	x8, LBB54_3
	b	LBB54_17
LBB54_2:                                ; %bb3.i.i
	ldr	x8, [x2]
	ldr	x9, [x1]
	eor	x8, x9, x8
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x10, x8, x8, lsr #31
	ldr	x9, [x0]
	ldr	x8, [x9]
	cbz	x8, LBB54_17
LBB54_3:                                ; %bb12.preheader.i
	udiv	x11, x10, x8
	msub	x11, x11, x8, x10
	mov	w12, #272                       ; =0x110
	mov	x10, x11
	b	LBB54_5
LBB54_4:                                ; %bb22.i
                                        ;   in Loop: Header=BB54_5 Depth=1
	add	x10, x10, #1
	cmp	x10, x8
	b.eq	LBB54_8
LBB54_5:                                ; %bb12.i
                                        ; =>This Inner Loop Header: Depth=1
	madd	x13, x10, x12, x9
	ldr	w14, [x13, #16]!
	cmp	w14, #1
	b.eq	LBB54_4
; %bb.6:                                ; %bb12.i
                                        ;   in Loop: Header=BB54_5 Depth=1
	cmp	w14, #2
	b.ne	LBB54_15
; %bb.7:                                ; %bb16.i
                                        ;   in Loop: Header=BB54_5 Depth=1
	ldr	x13, [x13, #8]
	ldr	x14, [x1]
	cmp	x13, x14
	b.ne	LBB54_4
	b	LBB54_14
LBB54_8:                                ; %bb23.i
	cbz	x11, LBB54_16
; %bb.9:                                ; %bb12.1.i.preheader
	mov	x10, #0                         ; =0x0
	add	x12, x9, #24
	b	LBB54_11
LBB54_10:                               ; %bb22.1.i
                                        ;   in Loop: Header=BB54_11 Depth=1
	add	x10, x10, #1
	add	x12, x12, #272
	cmp	x11, x10
	b.eq	LBB54_16
LBB54_11:                               ; %bb12.1.i
                                        ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x12, #-8]
	cmp	w8, #1
	b.eq	LBB54_10
; %bb.12:                               ; %bb12.1.i
                                        ;   in Loop: Header=BB54_11 Depth=1
	cmp	w8, #2
	b.ne	LBB54_18
; %bb.13:                               ; %bb16.1.i
                                        ;   in Loop: Header=BB54_11 Depth=1
	ldr	x8, [x12]
	ldr	x13, [x1]
	cmp	x8, x13
	b.ne	LBB54_10
LBB54_14:                               ; %bb20.i
	mov	w0, #0                          ; =0x0
	mov	w8, #272                        ; =0x110
	madd	x8, x10, x8, x9
	ldr	x8, [x8, #32]
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ret
LBB54_15:                               ; %bb12.i
	cbnz	w14, LBB54_19
LBB54_16:                               ; %"wf_hash_map.hash_map_lookup$instance$000400fb603e42fe.body.exit.loopexit55"
	mov	x8, #0                          ; =0x0
LBB54_17:                               ; %"wf_hash_map.hash_map_lookup$instance$000400fb603e42fe.body.exit"
	mov	w0, #1                          ; =0x1
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ret
LBB54_18:                               ; %bb12.1.i
	cbz	w8, LBB54_17
LBB54_19:                               ; %invalid.tag.b12.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_rehash$instance$28da32efc51c2b65 ; -- Begin function wf_hash_map.hash_map_rehash$instance$28da32efc51c2b65
	.p2align	2
_wf_hash_map.hash_map_rehash$instance$28da32efc51c2b65: ; @"wf_hash_map.hash_map_rehash$instance$28da32efc51c2b65"
	.cfi_startproc
; %bb.0:                                ; %entry
	mov	x2, x1
	ldr	x8, [x0]
	ldr	x1, [x8]
	b	_wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65 ; -- Begin function wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65
	.p2align	2
_wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65: ; @"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65"
	.cfi_startproc
; %bb.0:                                ; %entry
	cmp	x1, #4, lsl #12                 ; =16384
	b.ls	LBB56_2
; %bb.1:
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	ret
LBB56_2:                                ; %bb3.i
	ldr	x8, [x0]
	ldr	x8, [x8]
	cmp	x1, x8
	b.ls	LBB56_4
; %bb.3:                                ; %bb6.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB56_4:
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_capacity$instance$0e108827ecbbe374 ; -- Begin function wf_hash_map.hash_map_capacity$instance$0e108827ecbbe374
	.p2align	2
_wf_hash_map.hash_map_capacity$instance$0e108827ecbbe374: ; @"wf_hash_map.hash_map_capacity$instance$0e108827ecbbe374"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x0, [x8]
	ret
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_edit$instance$ec3fd08e444cbe49 ; -- Begin function wf_hash_map.hash_map_edit$instance$ec3fd08e444cbe49
	.p2align	2
_wf_hash_map.hash_map_edit$instance$ec3fd08e444cbe49: ; @"wf_hash_map.hash_map_edit$instance$ec3fd08e444cbe49"
; %bb.0:                                ; %entry
	ldrb	w8, [x2, #8]
	tbz	w8, #0, LBB58_2
; %bb.1:
	mov	x10, #0                         ; =0x0
	ldr	x9, [x0]
	ldr	x8, [x9]
	cbnz	x8, LBB58_3
	b	LBB58_17
LBB58_2:                                ; %bb3.i.i
	ldr	x8, [x2]
	ldr	x9, [x1]
	eor	x8, x9, x8
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x10, x8, x8, lsr #31
	ldr	x9, [x0]
	ldr	x8, [x9]
	cbz	x8, LBB58_17
LBB58_3:                                ; %bb12.preheader.i
	udiv	x11, x10, x8
	msub	x11, x11, x8, x10
	mov	w12, #272                       ; =0x110
	mov	x10, x11
	b	LBB58_5
LBB58_4:                                ; %bb22.i
                                        ;   in Loop: Header=BB58_5 Depth=1
	add	x10, x10, #1
	cmp	x10, x8
	b.eq	LBB58_8
LBB58_5:                                ; %bb12.i
                                        ; =>This Inner Loop Header: Depth=1
	madd	x13, x10, x12, x9
	ldr	w14, [x13, #16]!
	cmp	w14, #1
	b.eq	LBB58_4
; %bb.6:                                ; %bb12.i
                                        ;   in Loop: Header=BB58_5 Depth=1
	cmp	w14, #2
	b.ne	LBB58_15
; %bb.7:                                ; %bb16.i
                                        ;   in Loop: Header=BB58_5 Depth=1
	ldr	x13, [x13, #8]
	ldr	x14, [x1]
	cmp	x13, x14
	b.ne	LBB58_4
	b	LBB58_14
LBB58_8:                                ; %bb23.i
	cbz	x11, LBB58_16
; %bb.9:                                ; %bb12.1.i.preheader
	mov	x10, #0                         ; =0x0
	add	x12, x9, #24
	b	LBB58_11
LBB58_10:                               ; %bb22.1.i
                                        ;   in Loop: Header=BB58_11 Depth=1
	add	x10, x10, #1
	add	x12, x12, #272
	cmp	x11, x10
	b.eq	LBB58_16
LBB58_11:                               ; %bb12.1.i
                                        ; =>This Inner Loop Header: Depth=1
	ldur	w8, [x12, #-8]
	cmp	w8, #1
	b.eq	LBB58_10
; %bb.12:                               ; %bb12.1.i
                                        ;   in Loop: Header=BB58_11 Depth=1
	cmp	w8, #2
	b.ne	LBB58_18
; %bb.13:                               ; %bb16.1.i
                                        ;   in Loop: Header=BB58_11 Depth=1
	ldr	x8, [x12]
	ldr	x13, [x1]
	cmp	x8, x13
	b.ne	LBB58_10
LBB58_14:                               ; %bb20.i
	mov	w0, #0                          ; =0x0
	mov	w8, #272                        ; =0x110
	madd	x9, x10, x8, x9
	ldr	x8, [x9, #32]
	add	x8, x8, #1
	str	x8, [x9, #32]
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ret
LBB58_15:                               ; %bb12.i
	cbnz	w14, LBB58_19
LBB58_16:                               ; %"wf_hash_map.hash_map_edit$instance$ec3fd08e444cbe49.body.exit.loopexit55"
	mov	x8, #0                          ; =0x0
LBB58_17:                               ; %"wf_hash_map.hash_map_edit$instance$ec3fd08e444cbe49.body.exit"
	mov	w0, #1                          ; =0x1
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ret
LBB58_18:                               ; %bb12.1.i
	cbz	w8, LBB58_17
LBB58_19:                               ; %invalid.tag.b12.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_free$instance$d5f8785ab7665d71 ; -- Begin function wf_hash_map.hash_map_free$instance$d5f8785ab7665d71
	.p2align	2
_wf_hash_map.hash_map_free$instance$d5f8785ab7665d71: ; @"wf_hash_map.hash_map_free$instance$d5f8785ab7665d71"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0]
	ldr	x11, [x0]
	cbz	x11, LBB59_6
; %bb.1:                                ; %bb5.lr.ph
	ldp	x8, x9, [x1, #8]
	sub	x10, x11, #1
	mov	w12, #272                       ; =0x110
	madd	x12, x11, x12, x0
	ldr	x11, [x1, #24]
	sub	x12, x12, #120
	mov	w13, #131                       ; =0x83
	mov	x14, #58809                     ; =0xe5b9
	movk	x14, #7396, lsl #16
	movk	x14, #18285, lsl #32
	movk	x14, #48984, lsl #48
	mov	x15, #4587                      ; =0x11eb
	movk	x15, #4913, lsl #16
	movk	x15, #18875, lsl #32
	movk	x15, #38096, lsl #48
	b	LBB59_3
LBB59_2:                                ; %bb6
                                        ;   in Loop: Header=BB59_3 Depth=1
	sub	x10, x10, #1
	sub	x12, x12, #272
	cmn	x10, #1
	b.eq	LBB59_6
LBB59_3:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	str	x10, [x0]
	ldur	w16, [x12, #-136]
	cmp	w16, #2
	b.lo	LBB59_2
; %bb.4:                                ; %bb5
                                        ;   in Loop: Header=BB59_3 Depth=1
	b.ne	LBB59_7
; %bb.5:                                ; %bb7
                                        ;   in Loop: Header=BB59_3 Depth=1
	ldp	x17, x16, [x12, #-128]
	madd	x16, x17, x13, x16
	ldur	x17, [x12, #-112]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-104]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-96]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-88]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-80]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-72]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-64]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-56]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-48]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-40]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-32]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-24]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-16]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-8]
	madd	x16, x16, x13, x17
	ldr	x17, [x12]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #8]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #16]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #24]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #32]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #40]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #48]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #56]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #64]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #72]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #80]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #88]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #96]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #104]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #112]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #120]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #128]
	madd	x16, x16, x13, x17
	add	x8, x16, x8
	eor	x16, x16, x16, lsr #30
	mul	x16, x16, x14
	eor	x16, x16, x16, lsr #27
	mul	x16, x16, x15
	eor	x9, x9, x16, lsr #31
	eor	x9, x9, x16
	stp	x8, x9, [x1, #8]
	add	x11, x11, #1
	str	x11, [x1, #24]
	b	LBB59_2
LBB59_6:                                ; %bb4
	bl	_free
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB59_7:                                ; %invalid.tag.b3
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_len$instance$820b2044b97e0fbd ; -- Begin function wf_hash_map.hash_map_len$instance$820b2044b97e0fbd
	.p2align	2
_wf_hash_map.hash_map_len$instance$820b2044b97e0fbd: ; @"wf_hash_map.hash_map_len$instance$820b2044b97e0fbd"
; %bb.0:                                ; %entry
	ldr	x0, [x0, #8]
	ret
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_len$instance$0e108827ecbbe374 ; -- Begin function wf_hash_map.hash_map_len$instance$0e108827ecbbe374
	.p2align	2
_wf_hash_map.hash_map_len$instance$0e108827ecbbe374: ; @"wf_hash_map.hash_map_len$instance$0e108827ecbbe374"
; %bb.0:                                ; %entry
	ldr	x0, [x0, #8]
	ret
                                        ; -- End function
	.globl	_wf_box_slots_new$instance$087f541e70b769ea ; -- Begin function wf_box_slots_new$instance$087f541e70b769ea
	.p2align	2
_wf_box_slots_new$instance$087f541e70b769ea: ; @"wf_box_slots_new$instance$087f541e70b769ea"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB62_2
; %bb.1:                                ; %window.block.ready.v1
	stp	xzr, x19, [x0]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB62_2:                                ; %window.block.oom.v1
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_extend$instance$a62a753cf2b0b5ca ; -- Begin function wf_hash_map.hash_map_extend$instance$a62a753cf2b0b5ca
	.p2align	2
_wf_hash_map.hash_map_extend$instance$a62a753cf2b0b5ca: ; @"wf_hash_map.hash_map_extend$instance$a62a753cf2b0b5ca"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x1
	ldr	x20, [x0]
	ldr	x8, [x20, #8]
	cmp	x8, x1
	b.hs	LBB63_4
; %bb.1:                                ; %bb2
	mov	x21, x0
	ldr	x23, [x20]
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	madd	x0, x19, x8, x9
	bl	_malloc
	cbz	x0, LBB63_8
; %bb.2:                                ; %"wf_grow$instance$087f541e70b769ea.exit"
	mov	x22, x0
	stp	x23, x19, [x0], #16
	add	x8, x23, x23, lsl #1
	lsl	x2, x8, #3
	add	x1, x20, #16
	bl	_memmove
	mov	x0, x20
	bl	_free
	str	x22, [x21]
	mov	x20, x22
	cmp	x23, x19
	b.lo	LBB63_5
LBB63_3:                                ; %bb7
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB63_4:                                ; %entry.bb1_crit_edge
	ldr	x23, [x20]
	cmp	x23, x19
	b.hs	LBB63_3
LBB63_5:                                ; %bb5.preheader
	mov	w8, #24                         ; =0x18
	madd	x8, x23, x8, x20
	add	x8, x8, #24
LBB63_6:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x8, #-8]
	add	x23, x23, #1
	stp	xzr, xzr, [x8], #24
	cmp	x19, x23
	b.ne	LBB63_6
; %bb.7:                                ; %bb4.bb7_crit_edge
	str	x23, [x20]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB63_8:                                ; %window.block.oom.v2.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_try_put$instance$c7b22b9ef52855b6 ; -- Begin function wf_hash_map.hash_map_try_put$instance$c7b22b9ef52855b6
	.p2align	2
_wf_hash_map.hash_map_try_put$instance$c7b22b9ef52855b6: ; @"wf_hash_map.hash_map_try_put$instance$c7b22b9ef52855b6"
; %bb.0:                                ; %entry
	ldrb	w8, [x4, #8]
	tbz	w8, #0, LBB64_8
; %bb.1:
	mov	x10, #0                         ; =0x0
	ldr	x8, [x1]
	ldr	x9, [x8]
	cbz	x9, LBB64_9
LBB64_2:                                ; %bb12.preheader
	udiv	x11, x10, x9
	msub	x12, x11, x9, x10
	mov	w14, #24                        ; =0x18
	mov	x11, x12
	mov	x10, x9
	b	LBB64_5
LBB64_3:                                ; %bb18
                                        ;   in Loop: Header=BB64_5 Depth=1
	cmp	x10, x9
	csel	x10, x11, x10, eq
LBB64_4:                                ; %bb26
                                        ;   in Loop: Header=BB64_5 Depth=1
	add	x11, x11, #1
	cmp	x11, x9
	b.eq	LBB64_10
LBB64_5:                                ; %bb12
                                        ; =>This Inner Loop Header: Depth=1
	madd	x13, x11, x14, x8
	ldr	w15, [x13, #16]!
	cmp	w15, #1
	b.eq	LBB64_3
; %bb.6:                                ; %bb12
                                        ;   in Loop: Header=BB64_5 Depth=1
	cmp	w15, #2
	b.ne	LBB64_18
; %bb.7:                                ; %bb3.i20
                                        ;   in Loop: Header=BB64_5 Depth=1
	ldr	x15, [x13, #8]
	cmp	x15, x2
	b.ne	LBB64_4
	b	LBB64_17
LBB64_8:                                ; %bb3.i
	ldr	x8, [x4]
	eor	x8, x8, x2
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x10, x8, x8, lsr #31
	ldr	x8, [x1]
	ldr	x9, [x8]
	cbnz	x9, LBB64_2
LBB64_9:
	mov	x10, #0                         ; =0x0
	b	LBB64_21
LBB64_10:                               ; %bb27
	cbz	x12, LBB64_21
; %bb.11:                               ; %bb12.1.preheader
	mov	x11, #0                         ; =0x0
	add	x13, x8, #16
	b	LBB64_14
LBB64_12:                               ; %bb18.1
                                        ;   in Loop: Header=BB64_14 Depth=1
	cmp	x10, x9
	csel	x10, x11, x10, eq
LBB64_13:                               ; %bb26.1
                                        ;   in Loop: Header=BB64_14 Depth=1
	add	x11, x11, #1
	add	x13, x13, #24
	cmp	x12, x11
	b.eq	LBB64_21
LBB64_14:                               ; %bb12.1
                                        ; =>This Inner Loop Header: Depth=1
	ldr	w14, [x13]
	cmp	w14, #1
	b.eq	LBB64_12
; %bb.15:                               ; %bb12.1
                                        ;   in Loop: Header=BB64_14 Depth=1
	cmp	w14, #2
	b.ne	LBB64_19
; %bb.16:                               ; %bb3.i20.1
                                        ;   in Loop: Header=BB64_14 Depth=1
	ldr	x14, [x13, #8]
	cmp	x14, x2
	b.ne	LBB64_13
LBB64_17:                               ; %"wf_hash_map.hash_map_exchange$instance$0ed342445dd803f3.exit"
	ldr	x8, [x13, #16]
	mov	w9, #2                          ; =0x2
	str	w9, [x13]
	stp	x2, x3, [x13, #8]
	mov	w9, #1                          ; =0x1
	stp	x9, x2, [x0]
	str	x8, [x0, #16]
	ret
LBB64_18:                               ; %bb12
	cbz	w15, LBB64_20
	b	LBB64_29
LBB64_19:                               ; %bb12.1
	cbnz	w14, LBB64_29
LBB64_20:                               ; %bb17
	cmp	x10, x9
	csel	x10, x11, x10, eq
LBB64_21:                               ; %bb1
	cmp	x10, x9
	b.hs	LBB64_27
; %bb.22:                               ; %bb29
	ldr	x9, [x1, #8]
	cmp	x9, #2
	b.hi	LBB64_27
; %bb.23:                               ; %bb32
	add	x9, x9, #1
	str	x9, [x1, #8]
	mov	w9, #24                         ; =0x18
	madd	x9, x10, x9, x8
	ldr	w8, [x9, #16]
	ldur	q0, [x9, #24]
	mov	w10, #2                         ; =0x2
	str	w10, [x9, #16]
	stp	x2, x3, [x9, #24]
	cbz	w8, LBB64_28
; %bb.24:                               ; %bb32
	cmp	w8, #1
	b.eq	LBB64_28
; %bb.25:                               ; %bb32
	cmp	w8, #2
	b.ne	LBB64_29
; %bb.26:                               ; %bb3.i35
	mov	w8, #1                          ; =0x1
	str	x8, [x0]
	stur	q0, [x0, #8]
	ret
LBB64_27:                               ; %bb28
	stp	xzr, x2, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	strb	w8, [x0, #4]
	str	x3, [x0, #16]
	ret
LBB64_28:                               ; %bb2.i38
	stp	xzr, xzr, [x0]
	str	xzr, [x0, #16]
	ret
LBB64_29:                               ; %invalid.tag.b0.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_reserve$instance$c7b22b9ef52855b6 ; -- Begin function wf_hash_map.hash_map_reserve$instance$c7b22b9ef52855b6
	.p2align	2
_wf_hash_map.hash_map_reserve$instance$c7b22b9ef52855b6: ; @"wf_hash_map.hash_map_reserve$instance$c7b22b9ef52855b6"
	.cfi_startproc
; %bb.0:                                ; %entry
	cmp	x1, #3
	b.ls	LBB65_2
; %bb.1:
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	ret
LBB65_2:                                ; %bb3.i
	ldr	x8, [x0]
	ldr	x8, [x8]
	cmp	x1, x8
	b.ls	LBB65_4
; %bb.3:                                ; %bb6.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_wf_hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB65_4:
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_extend$instance$820b2044b97e0fbd ; -- Begin function wf_hash_map.hash_map_extend$instance$820b2044b97e0fbd
	.p2align	2
_wf_hash_map.hash_map_extend$instance$820b2044b97e0fbd: ; @"wf_hash_map.hash_map_extend$instance$820b2044b97e0fbd"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x1
	ldr	x20, [x0]
	ldr	x8, [x20, #8]
	cmp	x8, x1
	b.hs	LBB66_4
; %bb.1:                                ; %bb2
	mov	x21, x0
	ldr	x23, [x20]
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	madd	x0, x19, x8, x9
	bl	_malloc
	cbz	x0, LBB66_8
; %bb.2:                                ; %"wf_grow$instance$087f541e70b769ea.exit"
	mov	x22, x0
	stp	x23, x19, [x0], #16
	add	x8, x23, x23, lsl #1
	lsl	x2, x8, #3
	add	x1, x20, #16
	bl	_memmove
	mov	x0, x20
	bl	_free
	str	x22, [x21]
	mov	x20, x22
	cmp	x23, x19
	b.lo	LBB66_5
LBB66_3:                                ; %bb7
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB66_4:                                ; %entry.bb1_crit_edge
	ldr	x23, [x20]
	cmp	x23, x19
	b.hs	LBB66_3
LBB66_5:                                ; %bb5.preheader
	mov	w8, #24                         ; =0x18
	madd	x8, x23, x8, x20
	add	x8, x8, #24
LBB66_6:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x8, #-8]
	add	x23, x23, #1
	stp	xzr, xzr, [x8], #24
	cmp	x19, x23
	b.ne	LBB66_6
; %bb.7:                                ; %bb4.bb7_crit_edge
	str	x23, [x20]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB66_8:                                ; %window.block.oom.v2.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_try_put$instance$fde7c6722a8b0dad ; -- Begin function wf_hash_map.hash_map_try_put$instance$fde7c6722a8b0dad
	.p2align	2
_wf_hash_map.hash_map_try_put$instance$fde7c6722a8b0dad: ; @"wf_hash_map.hash_map_try_put$instance$fde7c6722a8b0dad"
; %bb.0:                                ; %entry
	ldrb	w8, [x4, #8]
	tbz	w8, #0, LBB67_8
; %bb.1:
	mov	x10, #0                         ; =0x0
	ldr	x8, [x1]
	ldr	x9, [x8]
	cbz	x9, LBB67_9
LBB67_2:                                ; %bb12.preheader
	udiv	x11, x10, x9
	msub	x12, x11, x9, x10
	mov	w14, #24                        ; =0x18
	mov	x11, x12
	mov	x10, x9
	b	LBB67_5
LBB67_3:                                ; %bb18
                                        ;   in Loop: Header=BB67_5 Depth=1
	cmp	x10, x9
	csel	x10, x11, x10, eq
LBB67_4:                                ; %bb26
                                        ;   in Loop: Header=BB67_5 Depth=1
	add	x11, x11, #1
	cmp	x11, x9
	b.eq	LBB67_10
LBB67_5:                                ; %bb12
                                        ; =>This Inner Loop Header: Depth=1
	madd	x13, x11, x14, x8
	ldr	w15, [x13, #16]!
	cmp	w15, #1
	b.eq	LBB67_3
; %bb.6:                                ; %bb12
                                        ;   in Loop: Header=BB67_5 Depth=1
	cmp	w15, #2
	b.ne	LBB67_18
; %bb.7:                                ; %bb3.i20
                                        ;   in Loop: Header=BB67_5 Depth=1
	ldr	x15, [x13, #8]
	cmp	x15, x2
	b.ne	LBB67_4
	b	LBB67_17
LBB67_8:                                ; %bb3.i
	ldr	x8, [x4]
	eor	x8, x8, x2
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x10, x8, x8, lsr #31
	ldr	x8, [x1]
	ldr	x9, [x8]
	cbnz	x9, LBB67_2
LBB67_9:
	mov	x10, #0                         ; =0x0
	b	LBB67_21
LBB67_10:                               ; %bb27
	cbz	x12, LBB67_21
; %bb.11:                               ; %bb12.1.preheader
	mov	x11, #0                         ; =0x0
	add	x13, x8, #16
	b	LBB67_14
LBB67_12:                               ; %bb18.1
                                        ;   in Loop: Header=BB67_14 Depth=1
	cmp	x10, x9
	csel	x10, x11, x10, eq
LBB67_13:                               ; %bb26.1
                                        ;   in Loop: Header=BB67_14 Depth=1
	add	x11, x11, #1
	add	x13, x13, #24
	cmp	x12, x11
	b.eq	LBB67_21
LBB67_14:                               ; %bb12.1
                                        ; =>This Inner Loop Header: Depth=1
	ldr	w14, [x13]
	cmp	w14, #1
	b.eq	LBB67_12
; %bb.15:                               ; %bb12.1
                                        ;   in Loop: Header=BB67_14 Depth=1
	cmp	w14, #2
	b.ne	LBB67_19
; %bb.16:                               ; %bb3.i20.1
                                        ;   in Loop: Header=BB67_14 Depth=1
	ldr	x14, [x13, #8]
	cmp	x14, x2
	b.ne	LBB67_13
LBB67_17:                               ; %"wf_hash_map.hash_map_exchange$instance$0ed342445dd803f3.exit"
	ldr	x8, [x13, #16]
	mov	w9, #2                          ; =0x2
	str	w9, [x13]
	stp	x2, x3, [x13, #8]
	mov	w9, #1                          ; =0x1
	stp	x9, x2, [x0]
	str	x8, [x0, #16]
	ret
LBB67_18:                               ; %bb12
	cbz	w15, LBB67_20
	b	LBB67_29
LBB67_19:                               ; %bb12.1
	cbnz	w14, LBB67_29
LBB67_20:                               ; %bb17
	cmp	x10, x9
	csel	x10, x11, x10, eq
LBB67_21:                               ; %bb1
	cmp	x10, x9
	b.hs	LBB67_27
; %bb.22:                               ; %bb29
	ldr	x9, [x1, #8]
	lsr	x11, x9, #14
	cbnz	x11, LBB67_27
; %bb.23:                               ; %bb32
	add	x9, x9, #1
	str	x9, [x1, #8]
	mov	w9, #24                         ; =0x18
	madd	x9, x10, x9, x8
	ldr	w8, [x9, #16]
	ldur	q0, [x9, #24]
	mov	w10, #2                         ; =0x2
	str	w10, [x9, #16]
	stp	x2, x3, [x9, #24]
	cbz	w8, LBB67_28
; %bb.24:                               ; %bb32
	cmp	w8, #1
	b.eq	LBB67_28
; %bb.25:                               ; %bb32
	cmp	w8, #2
	b.ne	LBB67_29
; %bb.26:                               ; %bb3.i35
	mov	w8, #1                          ; =0x1
	str	x8, [x0]
	stur	q0, [x0, #8]
	ret
LBB67_27:                               ; %bb28
	stp	xzr, x2, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	strb	w8, [x0, #4]
	str	x3, [x0, #16]
	ret
LBB67_28:                               ; %bb2.i38
	stp	xzr, xzr, [x0]
	str	xzr, [x0, #16]
	ret
LBB67_29:                               ; %invalid.tag.b0.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_find$instance$fde7c6722a8b0dad ; -- Begin function wf_hash_map.hash_map_find$instance$fde7c6722a8b0dad
	.p2align	2
_wf_hash_map.hash_map_find$instance$fde7c6722a8b0dad: ; @"wf_hash_map.hash_map_find$instance$fde7c6722a8b0dad"
; %bb.0:                                ; %entry
	mov	x8, x1
	ldrb	w9, [x2, #8]
	tbz	w9, #0, LBB68_2
; %bb.1:
	mov	x9, #0                          ; =0x0
	ldr	x10, [x0]
	ldr	x11, [x10]
	cbnz	x11, LBB68_3
	b	LBB68_17
LBB68_2:                                ; %bb3.i.i
	ldr	x9, [x2]
	ldr	x10, [x8]
	eor	x9, x10, x9
	eor	x9, x9, x9, lsr #30
	mov	x10, #58809                     ; =0xe5b9
	movk	x10, #7396, lsl #16
	movk	x10, #18285, lsl #32
	movk	x10, #48984, lsl #48
	mul	x9, x9, x10
	eor	x9, x9, x9, lsr #27
	mov	x10, #4587                      ; =0x11eb
	movk	x10, #4913, lsl #16
	movk	x10, #18875, lsl #32
	movk	x10, #38096, lsl #48
	mul	x9, x9, x10
	eor	x9, x9, x9, lsr #31
	ldr	x10, [x0]
	ldr	x11, [x10]
	cbz	x11, LBB68_17
LBB68_3:                                ; %bb12.preheader.i
	udiv	x12, x9, x11
	msub	x9, x12, x11, x9
	mov	w12, #24                        ; =0x18
	mov	x1, x9
	b	LBB68_5
LBB68_4:                                ; %bb20.i
                                        ;   in Loop: Header=BB68_5 Depth=1
	add	x1, x1, #1
	cmp	x1, x11
	b.eq	LBB68_9
LBB68_5:                                ; %bb12.i
                                        ; =>This Inner Loop Header: Depth=1
	madd	x13, x1, x12, x10
	ldr	w14, [x13, #16]!
	cmp	w14, #1
	b.eq	LBB68_4
; %bb.6:                                ; %bb12.i
                                        ;   in Loop: Header=BB68_5 Depth=1
	cmp	w14, #2
	b.ne	LBB68_16
; %bb.7:                                ; %bb3.i9.i
                                        ;   in Loop: Header=BB68_5 Depth=1
	ldr	x13, [x13, #8]
	ldr	x14, [x8]
	cmp	x13, x14
	b.ne	LBB68_4
; %bb.8:
	mov	w0, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ret
LBB68_9:                                ; %bb21.i
	cbz	x9, LBB68_17
; %bb.10:                               ; %bb12.1.i.preheader
	mov	x1, #0                          ; =0x0
	add	x10, x10, #24
	b	LBB68_12
LBB68_11:                               ; %bb20.1.i
                                        ;   in Loop: Header=BB68_12 Depth=1
	add	x1, x1, #1
	add	x10, x10, #24
	cmp	x9, x1
	b.eq	LBB68_17
LBB68_12:                               ; %bb12.1.i
                                        ; =>This Inner Loop Header: Depth=1
	ldur	w11, [x10, #-8]
	cmp	w11, #1
	b.eq	LBB68_11
; %bb.13:                               ; %bb12.1.i
                                        ;   in Loop: Header=BB68_12 Depth=1
	cmp	w11, #2
	b.ne	LBB68_18
; %bb.14:                               ; %bb3.i9.1.i
                                        ;   in Loop: Header=BB68_12 Depth=1
	ldr	x11, [x10]
	ldr	x12, [x8]
	cmp	x11, x12
	b.ne	LBB68_11
; %bb.15:
	mov	w0, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ret
LBB68_16:                               ; %bb12.i
	cbnz	w14, LBB68_20
LBB68_17:                               ; %"wf_hash_map.hash_map_find$instance$fde7c6722a8b0dad.body.exit.loopexit30split"
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	ret
LBB68_18:                               ; %bb12.1.i
	cbnz	w11, LBB68_20
; %bb.19:
	mov	w0, #1                          ; =0x1
	mov	x1, x11
	mov	w2, #0                          ; =0x0
	ret
LBB68_20:                               ; %invalid.tag.b0.i.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad ; -- Begin function wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	.p2align	2
_wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad: ; @"wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	cmp	x1, #4, lsl #12                 ; =16384
	b.hi	LBB69_2
; %bb.1:                                ; %bb3.i
	ldr	x19, [x0]
	ldr	x8, [x19]
	cmp	x1, x8
	b.hs	LBB69_3
LBB69_2:
	mov	w0, #1                          ; =0x1
	b	LBB69_39
LBB69_3:                                ; %bb6.i
	cbz	x1, LBB69_38
; %bb.4:                                ; %bb9.i
	mov	x22, x0
	ldr	x20, [x2]
	ldrb	w21, [x2, #8]
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	mov	x23, x1
	madd	x0, x1, x8, x9
	bl	_malloc
	cbz	x0, LBB69_41
; %bb.5:                                ; %bb1.i.i
	mov	x8, #0                          ; =0x0
	mov	x9, x23
	str	x23, [x0, #8]
	add	x10, x0, #24
LBB69_6:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x10, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x10], #24
	cmp	x9, x8
	b.ne	LBB69_6
; %bb.7:                                ; %bb4.bb7_crit_edge.i.i
	str	x9, [x0]
	str	x0, [x22]
	ldr	x13, [x19]
	cbz	x13, LBB69_37
; %bb.8:                                ; %bb14.lr.ph.i
	add	x8, x0, #16
	mov	w9, #24                         ; =0x18
	tbz	w21, #0, LBB69_21
; %bb.9:                                ; %bb14.us.i.preheader
	mov	w10, #2                         ; =0x2
	b	LBB69_13
LBB69_10:                               ; %bb35.us.us.i
                                        ;   in Loop: Header=BB69_13 Depth=1
	b.hs	LBB69_40
; %bb.11:                               ; %bb15.us.loopexit.i
                                        ;   in Loop: Header=BB69_13 Depth=1
	str	w10, [x14]
	stp	x12, x11, [x14, #8]
	ldr	x11, [x19]
LBB69_12:                               ; %bb15.us.i
                                        ;   in Loop: Header=BB69_13 Depth=1
	mov	x13, x11
	cbz	x11, LBB69_37
LBB69_13:                               ; %bb14.us.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB69_17 Depth 2
                                        ;       Child Loop BB69_18 Depth 3
	sub	x11, x13, #1
	str	x11, [x19]
	madd	x12, x13, x9, x19
	ldr	w13, [x12, #-8]!
	cmp	w13, #2
	b.lo	LBB69_12
; %bb.14:                               ; %bb14.us.i
                                        ;   in Loop: Header=BB69_13 Depth=1
	b.ne	LBB69_40
; %bb.15:                               ; %bb23.lr.ph.us.i
                                        ;   in Loop: Header=BB69_13 Depth=1
	ldr	x13, [x0]
	cbz	x13, LBB69_20
; %bb.16:                               ;   in Loop: Header=BB69_13 Depth=1
	ldp	x12, x11, [x12, #8]
LBB69_17:                               ; %bb35.us.us.i.preheader
                                        ;   Parent Loop BB69_13 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB69_18 Depth 3
	mov	x15, #0                         ; =0x0
	mov	x14, x8
LBB69_18:                               ; %bb35.us.us.i
                                        ;   Parent Loop BB69_13 Depth=1
                                        ;     Parent Loop BB69_17 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w16, [x14]
	cmp	w16, #2
	b.ne	LBB69_10
; %bb.19:                               ; %bb3.i31.us.us.i
                                        ;   in Loop: Header=BB69_18 Depth=3
	add	x15, x15, #1
	add	x14, x14, #24
	cmp	x13, x15
	b.ne	LBB69_18
	b	LBB69_17
LBB69_20:                               ; %bb23.us.us.i
                                        ; =>This Inner Loop Header: Depth=1
	b	LBB69_20
LBB69_21:                               ; %bb14.i.preheader
	mov	x10, #58809                     ; =0xe5b9
	movk	x10, #7396, lsl #16
	movk	x10, #18285, lsl #32
	movk	x10, #48984, lsl #48
	mov	x11, #4587                      ; =0x11eb
	movk	x11, #4913, lsl #16
	movk	x11, #18875, lsl #32
	movk	x11, #38096, lsl #48
	mov	w12, #2                         ; =0x2
	b	LBB69_25
LBB69_22:                               ; %bb35.1.i
                                        ;   in Loop: Header=BB69_25 Depth=1
	b.hs	LBB69_40
; %bb.23:                               ; %bb15.loopexit.i
                                        ;   in Loop: Header=BB69_25 Depth=1
	str	w12, [x15]
	stur	q0, [x15, #8]
	ldr	x14, [x19]
LBB69_24:                               ; %bb15.i
                                        ;   in Loop: Header=BB69_25 Depth=1
	mov	x13, x14
	cbz	x14, LBB69_37
LBB69_25:                               ; %bb14.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB69_29 Depth 2
                                        ;       Child Loop BB69_30 Depth 3
                                        ;       Child Loop BB69_34 Depth 3
	sub	x14, x13, #1
	str	x14, [x19]
	madd	x15, x13, x9, x19
	ldr	w13, [x15, #-8]!
	cmp	w13, #2
	b.lo	LBB69_24
; %bb.26:                               ; %bb14.i
                                        ;   in Loop: Header=BB69_25 Depth=1
	b.ne	LBB69_40
; %bb.27:                               ; %bb23.lr.ph.i
                                        ;   in Loop: Header=BB69_25 Depth=1
	ldr	x13, [x0]
	cbz	x13, LBB69_36
; %bb.28:                               ; %bb23.i.preheader
                                        ;   in Loop: Header=BB69_25 Depth=1
	ldur	q0, [x15, #8]
	ldr	x14, [x15, #8]
	eor	x14, x14, x20
	eor	x14, x14, x14, lsr #30
	mul	x14, x14, x10
	eor	x14, x14, x14, lsr #27
	mul	x14, x14, x11
	eor	x14, x14, x14, lsr #31
	udiv	x15, x14, x13
	msub	x14, x15, x13, x14
LBB69_29:                               ; %bb35.i
                                        ;   Parent Loop BB69_25 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB69_30 Depth 3
                                        ;       Child Loop BB69_34 Depth 3
	mov	x16, x14
LBB69_30:                               ; %bb35.i
                                        ;   Parent Loop BB69_25 Depth=1
                                        ;     Parent Loop BB69_29 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	madd	x15, x16, x9, x0
	ldr	w17, [x15, #16]!
	cmp	w17, #2
	b.ne	LBB69_22
; %bb.31:                               ; %bb3.i31.i
                                        ;   in Loop: Header=BB69_30 Depth=3
	add	x15, x16, #1
	cmp	x15, x13
	csinc	x16, x14, x16, eq
	b.ne	LBB69_30
; %bb.32:                               ; %bb3.i31.i
                                        ;   in Loop: Header=BB69_30 Depth=3
	cbz	x14, LBB69_30
; %bb.33:                               ; %bb35.1.i.preheader
                                        ;   in Loop: Header=BB69_29 Depth=2
	mov	x16, #0                         ; =0x0
	mov	x15, x8
LBB69_34:                               ; %bb35.1.i
                                        ;   Parent Loop BB69_25 Depth=1
                                        ;     Parent Loop BB69_29 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w17, [x15]
	cmp	w17, #2
	b.ne	LBB69_22
; %bb.35:                               ; %bb3.i31.1.i
                                        ;   in Loop: Header=BB69_34 Depth=3
	add	x16, x16, #1
	add	x15, x15, #24
	cmp	x14, x16
	b.ne	LBB69_34
	b	LBB69_29
LBB69_36:                               ; %bb23.us17.i
                                        ; =>This Inner Loop Header: Depth=1
	b	LBB69_36
LBB69_37:                               ; %bb13.i
	mov	x0, x19
	bl	_free
LBB69_38:                               ; %"wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad.body.exit"
	mov	w0, #0                          ; =0x0
LBB69_39:                               ; %"wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB69_40:                               ; %invalid.tag.b12.i
	bl	_abort
LBB69_41:                               ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_box_slots_new$instance$b1cfa6e689dc9e10 ; -- Begin function wf_box_slots_new$instance$b1cfa6e689dc9e10
	.p2align	2
_wf_box_slots_new$instance$b1cfa6e689dc9e10: ; @"wf_box_slots_new$instance$b1cfa6e689dc9e10"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB70_2
; %bb.1:                                ; %window.block.ready.v1
	stp	xzr, x19, [x0]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB70_2:                                ; %window.block.oom.v1
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_extend$instance$96033bf6ddb80743 ; -- Begin function wf_hash_map.hash_map_extend$instance$96033bf6ddb80743
	.p2align	2
_wf_hash_map.hash_map_extend$instance$96033bf6ddb80743: ; @"wf_hash_map.hash_map_extend$instance$96033bf6ddb80743"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x1
	ldr	x20, [x0]
	ldr	x8, [x20, #8]
	cmp	x8, x1
	b.hs	LBB71_4
; %bb.1:                                ; %bb2
	mov	x21, x0
	ldr	x23, [x20]
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	madd	x0, x19, x8, x9
	bl	_malloc
	cbz	x0, LBB71_8
; %bb.2:                                ; %"wf_grow$instance$b1cfa6e689dc9e10.exit"
	mov	x22, x0
	stp	x23, x19, [x0], #16
	add	x8, x23, x23, lsl #4
	lsl	x2, x8, #4
	add	x1, x20, #16
	bl	_memmove
	mov	x0, x20
	bl	_free
	str	x22, [x21]
	mov	x20, x22
	cmp	x23, x19
	b.lo	LBB71_5
LBB71_3:                                ; %bb7
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB71_4:                                ; %entry.bb1_crit_edge
	ldr	x23, [x20]
	cmp	x23, x19
	b.hs	LBB71_3
LBB71_5:                                ; %bb5.preheader
	mov	w8, #272                        ; =0x110
	madd	x8, x23, x8, x20
	add	x8, x8, #24
	movi.2d	v0, #0000000000000000
LBB71_6:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x8, #-8]
	add	x23, x23, #1
	stp	q0, q0, [x8]
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8, #64]
	stp	q0, q0, [x8, #96]
	stp	q0, q0, [x8, #128]
	stp	q0, q0, [x8, #160]
	stp	q0, q0, [x8, #192]
	stp	q0, q0, [x8, #224]
	str	xzr, [x8, #256]
	add	x8, x8, #272
	cmp	x19, x23
	b.ne	LBB71_6
; %bb.7:                                ; %bb4.bb7_crit_edge
	str	x23, [x20]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB71_8:                                ; %window.block.oom.v2.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_try_put$instance$8d5197e2f00c3b07 ; -- Begin function wf_hash_map.hash_map_try_put$instance$8d5197e2f00c3b07
	.p2align	2
_wf_hash_map.hash_map_try_put$instance$8d5197e2f00c3b07: ; @"wf_hash_map.hash_map_try_put$instance$8d5197e2f00c3b07"
; %bb.0:                                ; %entry
	sub	sp, sp, #288
	stp	x28, x27, [sp, #256]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #272]            ; 16-byte Folded Spill
	mov	x9, x2
	ldp	q0, q1, [x3, #192]
	stp	q0, q1, [sp, #192]
	ldp	q0, q1, [x3, #224]
	stp	q0, q1, [sp, #224]
	ldp	q0, q1, [x3, #128]
	stp	q0, q1, [sp, #128]
	ldp	q0, q1, [x3, #160]
	stp	q0, q1, [sp, #160]
	ldp	q0, q1, [x3, #64]
	stp	q0, q1, [sp, #64]
	ldp	q0, q1, [x3, #96]
	stp	q0, q1, [sp, #96]
	ldp	q0, q1, [x3]
	stp	q0, q1, [sp]
	ldp	q0, q1, [x3, #32]
	stp	q0, q1, [sp, #32]
	ldrb	w8, [x4, #8]
	tbz	w8, #0, LBB72_8
; %bb.1:
	mov	x8, #0                          ; =0x0
	ldr	x12, [x1]
	ldr	x10, [x12]
	cbz	x10, LBB72_9
LBB72_2:                                ; %bb12.preheader
	udiv	x11, x8, x10
	msub	x11, x11, x10, x8
	mov	w13, #272                       ; =0x110
	mov	x8, x11
	mov	x2, x10
	b	LBB72_5
LBB72_3:                                ; %bb18
                                        ;   in Loop: Header=BB72_5 Depth=1
	cmp	x2, x10
	csel	x2, x8, x2, eq
LBB72_4:                                ; %bb26
                                        ;   in Loop: Header=BB72_5 Depth=1
	add	x8, x8, #1
	cmp	x8, x10
	b.eq	LBB72_10
LBB72_5:                                ; %bb12
                                        ; =>This Inner Loop Header: Depth=1
	madd	x14, x8, x13, x12
	ldr	w15, [x14, #16]!
	cmp	w15, #1
	b.eq	LBB72_3
; %bb.6:                                ; %bb12
                                        ;   in Loop: Header=BB72_5 Depth=1
	cmp	w15, #2
	b.ne	LBB72_18
; %bb.7:                                ; %bb3.i20
                                        ;   in Loop: Header=BB72_5 Depth=1
	ldr	x14, [x14, #8]
	cmp	x14, x9
	b.ne	LBB72_4
	b	LBB72_17
LBB72_8:                                ; %bb3.i
	ldr	x8, [x4]
	eor	x8, x8, x9
	eor	x8, x8, x8, lsr #30
	mov	x10, #58809                     ; =0xe5b9
	movk	x10, #7396, lsl #16
	movk	x10, #18285, lsl #32
	movk	x10, #48984, lsl #48
	mul	x8, x8, x10
	eor	x8, x8, x8, lsr #27
	mov	x10, #4587                      ; =0x11eb
	movk	x10, #4913, lsl #16
	movk	x10, #18875, lsl #32
	movk	x10, #38096, lsl #48
	mul	x8, x8, x10
	eor	x8, x8, x8, lsr #31
	ldr	x12, [x1]
	ldr	x10, [x12]
	cbnz	x10, LBB72_2
LBB72_9:
	mov	x2, #0                          ; =0x0
	b	LBB72_20
LBB72_10:                               ; %bb27
	cbz	x11, LBB72_20
; %bb.11:                               ; %bb12.1.preheader
	mov	x8, #0                          ; =0x0
	add	x12, x12, #24
	b	LBB72_14
LBB72_12:                               ; %bb18.1
                                        ;   in Loop: Header=BB72_14 Depth=1
	cmp	x2, x10
	csel	x2, x8, x2, eq
LBB72_13:                               ; %bb26.1
                                        ;   in Loop: Header=BB72_14 Depth=1
	add	x8, x8, #1
	add	x12, x12, #272
	cmp	x11, x8
	b.eq	LBB72_20
LBB72_14:                               ; %bb12.1
                                        ; =>This Inner Loop Header: Depth=1
	ldur	w13, [x12, #-8]
	cmp	w13, #1
	b.eq	LBB72_12
; %bb.15:                               ; %bb12.1
                                        ;   in Loop: Header=BB72_14 Depth=1
	cmp	w13, #2
	b.ne	LBB72_24
; %bb.16:                               ; %bb3.i20.1
                                        ;   in Loop: Header=BB72_14 Depth=1
	ldr	x13, [x12]
	cmp	x13, x9
	b.ne	LBB72_13
LBB72_17:                               ; %bb16
	mov	x4, sp
	mov	x2, x8
	mov	x3, x9
	bl	_wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449
	ldp	x29, x30, [sp, #272]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #256]            ; 16-byte Folded Reload
	add	sp, sp, #288
	ret
LBB72_18:                               ; %bb12
	cbnz	w15, LBB72_25
LBB72_19:                               ; %bb17
	cmp	x2, x10
	csel	x2, x8, x2, eq
LBB72_20:                               ; %bb1
	cmp	x2, x10
	b.hs	LBB72_23
; %bb.21:                               ; %bb29
	ldr	x8, [x1, #8]
	cmp	x8, #2
	b.hi	LBB72_23
; %bb.22:                               ; %bb32
	add	x8, x8, #1
	str	x8, [x1, #8]
	mov	x4, sp
	mov	x3, x9
	bl	_wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449
	ldp	x29, x30, [sp, #272]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #256]            ; 16-byte Folded Reload
	add	sp, sp, #288
	ret
LBB72_23:                               ; %bb28
	stp	xzr, x9, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	strb	w8, [x0, #4]
	ldp	q0, q1, [sp]
	stp	q0, q1, [x0, #16]
	ldp	q0, q1, [sp, #32]
	stp	q0, q1, [x0, #48]
	ldp	q0, q1, [sp, #64]
	stp	q0, q1, [x0, #80]
	ldp	q0, q1, [sp, #96]
	stp	q0, q1, [x0, #112]
	ldp	q0, q1, [sp, #128]
	stp	q0, q1, [x0, #144]
	ldp	q0, q1, [sp, #160]
	stp	q0, q1, [x0, #176]
	ldp	q0, q1, [sp, #192]
	stp	q0, q1, [x0, #208]
	ldp	q0, q1, [sp, #224]
	stp	q0, q1, [x0, #240]
	ldp	x29, x30, [sp, #272]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #256]            ; 16-byte Folded Reload
	add	sp, sp, #288
	ret
LBB72_24:                               ; %bb12.1
	cbz	w13, LBB72_19
LBB72_25:                               ; %invalid.tag.b0.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_reserve$instance$8d5197e2f00c3b07 ; -- Begin function wf_hash_map.hash_map_reserve$instance$8d5197e2f00c3b07
	.p2align	2
_wf_hash_map.hash_map_reserve$instance$8d5197e2f00c3b07: ; @"wf_hash_map.hash_map_reserve$instance$8d5197e2f00c3b07"
	.cfi_startproc
; %bb.0:                                ; %entry
	cmp	x1, #3
	b.ls	LBB73_2
; %bb.1:
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	ret
LBB73_2:                                ; %bb3.i
	ldr	x8, [x0]
	ldr	x8, [x8]
	cmp	x1, x8
	b.ls	LBB73_4
; %bb.3:                                ; %bb6.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_wf_hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB73_4:
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_extend$instance$0e108827ecbbe374 ; -- Begin function wf_hash_map.hash_map_extend$instance$0e108827ecbbe374
	.p2align	2
_wf_hash_map.hash_map_extend$instance$0e108827ecbbe374: ; @"wf_hash_map.hash_map_extend$instance$0e108827ecbbe374"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x1
	ldr	x20, [x0]
	ldr	x8, [x20, #8]
	cmp	x8, x1
	b.hs	LBB74_4
; %bb.1:                                ; %bb2
	mov	x21, x0
	ldr	x23, [x20]
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	madd	x0, x19, x8, x9
	bl	_malloc
	cbz	x0, LBB74_8
; %bb.2:                                ; %"wf_grow$instance$b1cfa6e689dc9e10.exit"
	mov	x22, x0
	stp	x23, x19, [x0], #16
	add	x8, x23, x23, lsl #4
	lsl	x2, x8, #4
	add	x1, x20, #16
	bl	_memmove
	mov	x0, x20
	bl	_free
	str	x22, [x21]
	mov	x20, x22
	cmp	x23, x19
	b.lo	LBB74_5
LBB74_3:                                ; %bb7
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB74_4:                                ; %entry.bb1_crit_edge
	ldr	x23, [x20]
	cmp	x23, x19
	b.hs	LBB74_3
LBB74_5:                                ; %bb5.preheader
	mov	w8, #272                        ; =0x110
	madd	x8, x23, x8, x20
	add	x8, x8, #24
	movi.2d	v0, #0000000000000000
LBB74_6:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x8, #-8]
	add	x23, x23, #1
	stp	q0, q0, [x8]
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8, #64]
	stp	q0, q0, [x8, #96]
	stp	q0, q0, [x8, #128]
	stp	q0, q0, [x8, #160]
	stp	q0, q0, [x8, #192]
	stp	q0, q0, [x8, #224]
	str	xzr, [x8, #256]
	add	x8, x8, #272
	cmp	x19, x23
	b.ne	LBB74_6
; %bb.7:                                ; %bb4.bb7_crit_edge
	str	x23, [x20]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB74_8:                                ; %window.block.oom.v2.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65 ; -- Begin function wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65
	.p2align	2
_wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65: ; @"wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65"
; %bb.0:                                ; %entry
	sub	sp, sp, #288
	stp	x28, x27, [sp, #256]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #272]            ; 16-byte Folded Spill
	mov	x9, x2
	ldp	q0, q1, [x3, #192]
	stp	q0, q1, [sp, #192]
	ldp	q0, q1, [x3, #224]
	stp	q0, q1, [sp, #224]
	ldp	q0, q1, [x3, #128]
	stp	q0, q1, [sp, #128]
	ldp	q0, q1, [x3, #160]
	stp	q0, q1, [sp, #160]
	ldp	q0, q1, [x3, #64]
	stp	q0, q1, [sp, #64]
	ldp	q0, q1, [x3, #96]
	stp	q0, q1, [sp, #96]
	ldp	q0, q1, [x3]
	stp	q0, q1, [sp]
	ldp	q0, q1, [x3, #32]
	stp	q0, q1, [sp, #32]
	ldrb	w8, [x4, #8]
	tbz	w8, #0, LBB75_8
; %bb.1:
	mov	x8, #0                          ; =0x0
	ldr	x12, [x1]
	ldr	x10, [x12]
	cbz	x10, LBB75_9
LBB75_2:                                ; %bb12.preheader
	udiv	x11, x8, x10
	msub	x11, x11, x10, x8
	mov	w13, #272                       ; =0x110
	mov	x8, x11
	mov	x2, x10
	b	LBB75_5
LBB75_3:                                ; %bb18
                                        ;   in Loop: Header=BB75_5 Depth=1
	cmp	x2, x10
	csel	x2, x8, x2, eq
LBB75_4:                                ; %bb26
                                        ;   in Loop: Header=BB75_5 Depth=1
	add	x8, x8, #1
	cmp	x8, x10
	b.eq	LBB75_10
LBB75_5:                                ; %bb12
                                        ; =>This Inner Loop Header: Depth=1
	madd	x14, x8, x13, x12
	ldr	w15, [x14, #16]!
	cmp	w15, #1
	b.eq	LBB75_3
; %bb.6:                                ; %bb12
                                        ;   in Loop: Header=BB75_5 Depth=1
	cmp	w15, #2
	b.ne	LBB75_18
; %bb.7:                                ; %bb3.i20
                                        ;   in Loop: Header=BB75_5 Depth=1
	ldr	x14, [x14, #8]
	cmp	x14, x9
	b.ne	LBB75_4
	b	LBB75_17
LBB75_8:                                ; %bb3.i
	ldr	x8, [x4]
	eor	x8, x8, x9
	eor	x8, x8, x8, lsr #30
	mov	x10, #58809                     ; =0xe5b9
	movk	x10, #7396, lsl #16
	movk	x10, #18285, lsl #32
	movk	x10, #48984, lsl #48
	mul	x8, x8, x10
	eor	x8, x8, x8, lsr #27
	mov	x10, #4587                      ; =0x11eb
	movk	x10, #4913, lsl #16
	movk	x10, #18875, lsl #32
	movk	x10, #38096, lsl #48
	mul	x8, x8, x10
	eor	x8, x8, x8, lsr #31
	ldr	x12, [x1]
	ldr	x10, [x12]
	cbnz	x10, LBB75_2
LBB75_9:
	mov	x2, #0                          ; =0x0
	b	LBB75_20
LBB75_10:                               ; %bb27
	cbz	x11, LBB75_20
; %bb.11:                               ; %bb12.1.preheader
	mov	x8, #0                          ; =0x0
	add	x12, x12, #24
	b	LBB75_14
LBB75_12:                               ; %bb18.1
                                        ;   in Loop: Header=BB75_14 Depth=1
	cmp	x2, x10
	csel	x2, x8, x2, eq
LBB75_13:                               ; %bb26.1
                                        ;   in Loop: Header=BB75_14 Depth=1
	add	x8, x8, #1
	add	x12, x12, #272
	cmp	x11, x8
	b.eq	LBB75_20
LBB75_14:                               ; %bb12.1
                                        ; =>This Inner Loop Header: Depth=1
	ldur	w13, [x12, #-8]
	cmp	w13, #1
	b.eq	LBB75_12
; %bb.15:                               ; %bb12.1
                                        ;   in Loop: Header=BB75_14 Depth=1
	cmp	w13, #2
	b.ne	LBB75_24
; %bb.16:                               ; %bb3.i20.1
                                        ;   in Loop: Header=BB75_14 Depth=1
	ldr	x13, [x12]
	cmp	x13, x9
	b.ne	LBB75_13
LBB75_17:                               ; %bb16
	mov	x4, sp
	mov	x2, x8
	mov	x3, x9
	bl	_wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449
	ldp	x29, x30, [sp, #272]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #256]            ; 16-byte Folded Reload
	add	sp, sp, #288
	ret
LBB75_18:                               ; %bb12
	cbnz	w15, LBB75_25
LBB75_19:                               ; %bb17
	cmp	x2, x10
	csel	x2, x8, x2, eq
LBB75_20:                               ; %bb1
	cmp	x2, x10
	b.hs	LBB75_23
; %bb.21:                               ; %bb29
	ldr	x8, [x1, #8]
	lsr	x10, x8, #14
	cbnz	x10, LBB75_23
; %bb.22:                               ; %bb32
	add	x8, x8, #1
	str	x8, [x1, #8]
	mov	x4, sp
	mov	x3, x9
	bl	_wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449
	ldp	x29, x30, [sp, #272]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #256]            ; 16-byte Folded Reload
	add	sp, sp, #288
	ret
LBB75_23:                               ; %bb28
	stp	xzr, x9, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	strb	w8, [x0, #4]
	ldp	q0, q1, [sp]
	stp	q0, q1, [x0, #16]
	ldp	q0, q1, [sp, #32]
	stp	q0, q1, [x0, #48]
	ldp	q0, q1, [sp, #64]
	stp	q0, q1, [x0, #80]
	ldp	q0, q1, [sp, #96]
	stp	q0, q1, [x0, #112]
	ldp	q0, q1, [sp, #128]
	stp	q0, q1, [x0, #144]
	ldp	q0, q1, [sp, #160]
	stp	q0, q1, [x0, #176]
	ldp	q0, q1, [sp, #192]
	stp	q0, q1, [x0, #208]
	ldp	q0, q1, [sp, #224]
	stp	q0, q1, [x0, #240]
	ldp	x29, x30, [sp, #272]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #256]            ; 16-byte Folded Reload
	add	sp, sp, #288
	ret
LBB75_24:                               ; %bb12.1
	cbz	w13, LBB75_19
LBB75_25:                               ; %invalid.tag.b0.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_find$instance$28da32efc51c2b65 ; -- Begin function wf_hash_map.hash_map_find$instance$28da32efc51c2b65
	.p2align	2
_wf_hash_map.hash_map_find$instance$28da32efc51c2b65: ; @"wf_hash_map.hash_map_find$instance$28da32efc51c2b65"
; %bb.0:                                ; %entry
	mov	x8, x1
	ldrb	w9, [x2, #8]
	tbz	w9, #0, LBB76_2
; %bb.1:
	mov	x9, #0                          ; =0x0
	ldr	x10, [x0]
	ldr	x11, [x10]
	cbnz	x11, LBB76_3
	b	LBB76_17
LBB76_2:                                ; %bb3.i.i
	ldr	x9, [x2]
	ldr	x10, [x8]
	eor	x9, x10, x9
	eor	x9, x9, x9, lsr #30
	mov	x10, #58809                     ; =0xe5b9
	movk	x10, #7396, lsl #16
	movk	x10, #18285, lsl #32
	movk	x10, #48984, lsl #48
	mul	x9, x9, x10
	eor	x9, x9, x9, lsr #27
	mov	x10, #4587                      ; =0x11eb
	movk	x10, #4913, lsl #16
	movk	x10, #18875, lsl #32
	movk	x10, #38096, lsl #48
	mul	x9, x9, x10
	eor	x9, x9, x9, lsr #31
	ldr	x10, [x0]
	ldr	x11, [x10]
	cbz	x11, LBB76_17
LBB76_3:                                ; %bb12.preheader.i
	udiv	x12, x9, x11
	msub	x9, x12, x11, x9
	mov	w12, #272                       ; =0x110
	mov	x1, x9
	b	LBB76_5
LBB76_4:                                ; %bb20.i
                                        ;   in Loop: Header=BB76_5 Depth=1
	add	x1, x1, #1
	cmp	x1, x11
	b.eq	LBB76_9
LBB76_5:                                ; %bb12.i
                                        ; =>This Inner Loop Header: Depth=1
	madd	x13, x1, x12, x10
	ldr	w14, [x13, #16]!
	cmp	w14, #1
	b.eq	LBB76_4
; %bb.6:                                ; %bb12.i
                                        ;   in Loop: Header=BB76_5 Depth=1
	cmp	w14, #2
	b.ne	LBB76_16
; %bb.7:                                ; %bb3.i9.i
                                        ;   in Loop: Header=BB76_5 Depth=1
	ldr	x13, [x13, #8]
	ldr	x14, [x8]
	cmp	x13, x14
	b.ne	LBB76_4
; %bb.8:
	mov	w0, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ret
LBB76_9:                                ; %bb21.i
	cbz	x9, LBB76_17
; %bb.10:                               ; %bb12.1.i.preheader
	mov	x1, #0                          ; =0x0
	add	x10, x10, #24
	b	LBB76_12
LBB76_11:                               ; %bb20.1.i
                                        ;   in Loop: Header=BB76_12 Depth=1
	add	x1, x1, #1
	add	x10, x10, #272
	cmp	x9, x1
	b.eq	LBB76_17
LBB76_12:                               ; %bb12.1.i
                                        ; =>This Inner Loop Header: Depth=1
	ldur	w11, [x10, #-8]
	cmp	w11, #1
	b.eq	LBB76_11
; %bb.13:                               ; %bb12.1.i
                                        ;   in Loop: Header=BB76_12 Depth=1
	cmp	w11, #2
	b.ne	LBB76_18
; %bb.14:                               ; %bb3.i9.1.i
                                        ;   in Loop: Header=BB76_12 Depth=1
	ldr	x11, [x10]
	ldr	x12, [x8]
	cmp	x11, x12
	b.ne	LBB76_11
; %bb.15:
	mov	w0, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ret
LBB76_16:                               ; %bb12.i
	cbnz	w14, LBB76_20
LBB76_17:                               ; %"wf_hash_map.hash_map_find$instance$28da32efc51c2b65.body.exit.loopexit30split"
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	ret
LBB76_18:                               ; %bb12.1.i
	cbnz	w11, LBB76_20
; %bb.19:
	mov	w0, #1                          ; =0x1
	mov	x1, x11
	mov	w2, #0                          ; =0x0
	ret
LBB76_20:                               ; %invalid.tag.b0.i.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65 ; -- Begin function wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	.p2align	2
_wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65: ; @"wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #576
	.cfi_def_cfa_offset 672
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cmp	x1, #4, lsl #12                 ; =16384
	b.hi	LBB77_2
; %bb.1:                                ; %bb3.i
	mov	x19, x0
	ldr	x22, [x0]
	ldr	x8, [x22]
	cmp	x1, x8
	b.hs	LBB77_3
LBB77_2:
	mov	w0, #1                          ; =0x1
	b	LBB77_45
LBB77_3:                                ; %bb6.i
	cbz	x1, LBB77_44
; %bb.4:                                ; %bb9.i
	ldr	x23, [x2]
	ldrb	w8, [x2, #8]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	mov	x20, x1
	madd	x0, x1, x8, x9
	bl	_malloc
	cbz	x0, LBB77_47
; %bb.5:                                ; %bb1.i.i
	mov	x21, x0
	mov	x8, #0                          ; =0x0
	mov	x9, x20
	str	x20, [x0, #8]
	add	x10, x0, #24
	movi.2d	v0, #0000000000000000
LBB77_6:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x10, #-8]
	add	x8, x8, #1
	stp	q0, q0, [x10]
	stp	q0, q0, [x10, #32]
	stp	q0, q0, [x10, #64]
	stp	q0, q0, [x10, #96]
	stp	q0, q0, [x10, #128]
	stp	q0, q0, [x10, #160]
	stp	q0, q0, [x10, #192]
	stp	q0, q0, [x10, #224]
	str	xzr, [x10, #256]
	add	x10, x10, #272
	cmp	x9, x8
	b.ne	LBB77_6
; %bb.7:                                ; %bb4.bb7_crit_edge.i.i
	str	x9, [x21]
	str	x21, [x19]
	ldr	x8, [x22]
	cbz	x8, LBB77_43
; %bb.8:                                ; %bb14.lr.ph.i
	add	x27, x21, #16
	mov	w28, #272                       ; =0x110
	mov	w24, #264                       ; =0x108
	add	x25, sp, #32
	str	x22, [sp, #16]                  ; 8-byte Folded Spill
	b	LBB77_11
LBB77_9:                                ; %bb15thread-pre-split.i
                                        ;   in Loop: Header=BB77_11 Depth=1
	ldr	x22, [sp, #16]                  ; 8-byte Folded Reload
	ldr	x9, [x22]
LBB77_10:                               ; %bb15.i
                                        ;   in Loop: Header=BB77_11 Depth=1
	mov	x8, x9
	cbz	x9, LBB77_43
LBB77_11:                               ; %bb14.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB77_29 Depth 2
                                        ;     Child Loop BB77_31 Depth 2
                                        ;     Child Loop BB77_35 Depth 2
                                        ;     Child Loop BB77_18 Depth 2
                                        ;       Child Loop BB77_20 Depth 3
	sub	x9, x8, #1
	str	x9, [x22]
	madd	x8, x8, x28, x22
	ldr	w10, [x8, #-256]!
	cmp	w10, #2
	b.lo	LBB77_10
; %bb.12:                               ; %bb14.i
                                        ;   in Loop: Header=BB77_11 Depth=1
	b.ne	LBB77_46
; %bb.13:                               ; %bb23.preheader.i
                                        ;   in Loop: Header=BB77_11 Depth=1
	ldr	x9, [x8, #264]
	str	xzr, [sp, #32]
	ldur	q0, [x8, #8]
	stur	q0, [sp, #40]
	ldur	q0, [x8, #24]
	stur	q0, [sp, #56]
	ldur	q0, [x8, #40]
	stur	q0, [sp, #72]
	ldur	q0, [x8, #56]
	stur	q0, [sp, #88]
	ldur	q0, [x8, #72]
	stur	q0, [sp, #104]
	ldur	q0, [x8, #88]
	stur	q0, [sp, #120]
	ldur	q0, [x8, #104]
	stur	q0, [sp, #136]
	ldur	q0, [x8, #120]
	stur	q0, [sp, #152]
	ldur	q0, [x8, #136]
	add	x10, sp, #32
	stur	q0, [x10, #136]
	ldur	q0, [x8, #152]
	stur	q0, [x10, #152]
	ldur	q0, [x8, #168]
	stur	q0, [x10, #168]
	ldur	q0, [x8, #184]
	stur	q0, [x10, #184]
	ldur	q0, [x8, #200]
	stur	q0, [x10, #200]
	ldur	q0, [x8, #216]
	stur	q0, [x10, #216]
	ldur	q0, [x8, #232]
	stur	q0, [x10, #232]
	ldur	q0, [x8, #248]
	stur	q0, [x10, #248]
	str	x9, [sp, #296]
	ldr	x8, [x21]
	ldr	w9, [sp, #28]                   ; 4-byte Folded Reload
	tbz	w9, #0, LBB77_26
; %bb.14:                               ; %bb23.preheader.i.split.us.split
                                        ;   in Loop: Header=BB77_11 Depth=1
	cbz	x8, LBB77_41
; %bb.15:                               ; %bb23.i.us.preheader
                                        ;   in Loop: Header=BB77_11 Depth=1
	mov	w20, #1                         ; =0x1
	b	LBB77_18
LBB77_16:                               ; %bb24.i.us
                                        ;   in Loop: Header=BB77_18 Depth=2
	mov	x20, x26
	cbz	x26, LBB77_9
LBB77_17:                               ; %bb23.i.usthread-pre-split
                                        ;   in Loop: Header=BB77_18 Depth=2
	ldr	x8, [x21]
LBB77_18:                               ; %bb23.i.us
                                        ;   Parent Loop BB77_11 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB77_20 Depth 3
	cbz	x8, LBB77_17
; %bb.19:                               ; %bb35.i.us.preheader
                                        ;   in Loop: Header=BB77_18 Depth=2
	mov	x2, #0                          ; =0x0
	mov	x9, x27
LBB77_20:                               ; %bb35.i.us
                                        ;   Parent Loop BB77_11 Depth=1
                                        ;     Parent Loop BB77_18 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w10, [x9]
	cmp	w10, #2
	b.ne	LBB77_22
; %bb.21:                               ; %bb3.i30.i.us
                                        ;   in Loop: Header=BB77_20 Depth=3
	add	x9, x9, #272
	add	x2, x2, #1
	cmp	x8, x2
	b.ne	LBB77_20
	b	LBB77_17
LBB77_22:                               ; %bb35.i.us
                                        ;   in Loop: Header=BB77_18 Depth=2
	b.hs	LBB77_46
; %bb.23:                               ; %bb39.i.loopexit3.us
                                        ;   in Loop: Header=BB77_18 Depth=2
	sub	x26, x20, #1
	str	x26, [sp, #32]
	madd	x22, x20, x24, x25
	ldr	x3, [x22, #-256]!
	add	x0, sp, #304
	add	x4, x22, #8
	mov	x1, x19
	bl	_wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449
	ldr	w8, [sp, #304]
	cbz	w8, LBB77_16
; %bb.24:                               ; %bb39.i.loopexit3.us
                                        ;   in Loop: Header=BB77_18 Depth=2
	cmp	w8, #1
	b.ne	LBB77_46
; %bb.25:                               ; %bb43.i.us
                                        ;   in Loop: Header=BB77_18 Depth=2
	add	x8, sp, #304
	add	x1, x8, #8
	mov	x0, x22
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	str	x20, [sp, #32]
	b	LBB77_17
LBB77_26:                               ; %bb23.preheader.i.split
                                        ;   in Loop: Header=BB77_11 Depth=1
	cbz	x8, LBB77_42
; %bb.27:                               ; %bb23.i.preheader
                                        ;   in Loop: Header=BB77_11 Depth=1
	mov	w26, #1                         ; =0x1
	cbnz	x8, LBB77_30
	b	LBB77_29
LBB77_28:                               ; %bb24.i
                                        ;   in Loop: Header=BB77_11 Depth=1
	mov	x26, x20
	cbz	x20, LBB77_9
LBB77_29:                               ; %bb23.ithread-pre-split
                                        ;   Parent Loop BB77_11 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x21]
	cbz	x8, LBB77_29
LBB77_30:                               ; %bb35.preheader.i
                                        ;   in Loop: Header=BB77_11 Depth=1
	ldr	x9, [sp, #40]
	eor	x9, x9, x23
	eor	x9, x9, x9, lsr #30
	mov	x10, #58809                     ; =0xe5b9
	movk	x10, #7396, lsl #16
	movk	x10, #18285, lsl #32
	movk	x10, #48984, lsl #48
	mul	x9, x9, x10
	eor	x9, x9, x9, lsr #27
	mov	x10, #4587                      ; =0x11eb
	movk	x10, #4913, lsl #16
	movk	x10, #18875, lsl #32
	movk	x10, #38096, lsl #48
	mul	x9, x9, x10
	eor	x9, x9, x9, lsr #31
	udiv	x10, x9, x8
	msub	x9, x10, x8, x9
	mov	x2, x9
LBB77_31:                               ; %bb35.i
                                        ;   Parent Loop BB77_11 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	madd	x10, x2, x28, x21
	ldr	w10, [x10, #16]
	cmp	w10, #2
	b.ne	LBB77_37
; %bb.32:                               ; %bb3.i30.i
                                        ;   in Loop: Header=BB77_31 Depth=2
	add	x2, x2, #1
	cmp	x2, x8
	b.ne	LBB77_31
; %bb.33:                               ; %bb45.i
                                        ;   in Loop: Header=BB77_11 Depth=1
	cbz	x9, LBB77_29
; %bb.34:                               ; %bb35.1.i.preheader
                                        ;   in Loop: Header=BB77_11 Depth=1
	mov	x2, #0                          ; =0x0
	mov	x8, x27
LBB77_35:                               ; %bb35.1.i
                                        ;   Parent Loop BB77_11 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w10, [x8]
	cmp	w10, #2
	b.ne	LBB77_37
; %bb.36:                               ; %bb3.i30.1.i
                                        ;   in Loop: Header=BB77_35 Depth=2
	add	x8, x8, #272
	add	x2, x2, #1
	cmp	x9, x2
	b.ne	LBB77_35
	b	LBB77_29
LBB77_37:                               ; %bb35.i
                                        ;   in Loop: Header=BB77_11 Depth=1
	b.hs	LBB77_46
; %bb.38:                               ; %bb39.i
                                        ;   in Loop: Header=BB77_11 Depth=1
	sub	x20, x26, #1
	str	x20, [sp, #32]
	madd	x22, x26, x24, x25
	ldr	x3, [x22, #-256]!
	add	x0, sp, #304
	add	x4, x22, #8
	mov	x1, x19
	bl	_wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449
	ldr	w8, [sp, #304]
	cbz	w8, LBB77_28
; %bb.39:                               ; %bb39.i
                                        ;   in Loop: Header=BB77_11 Depth=1
	cmp	w8, #1
	b.ne	LBB77_46
; %bb.40:                               ; %bb43.i
                                        ;   in Loop: Header=BB77_11 Depth=1
	add	x8, sp, #304
	add	x1, x8, #8
	mov	x0, x22
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	str	x26, [sp, #32]
	b	LBB77_29
LBB77_41:                               ; %bb23.i.us.us
                                        ; =>This Inner Loop Header: Depth=1
	b	LBB77_41
LBB77_42:                               ; %bb23.i.us8
                                        ; =>This Inner Loop Header: Depth=1
	b	LBB77_42
LBB77_43:                               ; %bb13.i
	mov	x0, x22
	bl	_free
LBB77_44:                               ; %"wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65.body.exit"
	mov	w0, #0                          ; =0x0
LBB77_45:                               ; %"wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	add	sp, sp, #576
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB77_46:                               ; %invalid.tag.b12.i
	bl	_abort
LBB77_47:                               ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_action$instance$fc5e3cb62bdf3601 ; -- Begin function wf_hash_map.hash_map_action$instance$fc5e3cb62bdf3601
	.p2align	2
_wf_hash_map.hash_map_action$instance$fc5e3cb62bdf3601: ; @"wf_hash_map.hash_map_action$instance$fc5e3cb62bdf3601"
; %bb.0:                                ; %entry
	mov	x8, x0
	ldr	w0, [x0]
	cmp	w0, #2
	b.hs	LBB78_2
; %bb.1:                                ; %common.ret
	ret
LBB78_2:                                ; %entry
	b.ne	LBB78_4
; %bb.3:                                ; %bb3
	ldr	x8, [x8, #8]
	ldr	x9, [x1]
	cmp	x8, x9
	mov	w8, #2                          ; =0x2
	cinc	w0, w8, eq
	ret
LBB78_4:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_exchange$instance$0ed342445dd803f3 ; -- Begin function wf_hash_map.hash_map_exchange$instance$0ed342445dd803f3
	.p2align	2
_wf_hash_map.hash_map_exchange$instance$0ed342445dd803f3: ; @"wf_hash_map.hash_map_exchange$instance$0ed342445dd803f3"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	mov	w9, #24                         ; =0x18
	madd	x9, x2, x9, x8
	ldr	w8, [x9, #16]
	ldur	q0, [x9, #24]
	mov	w10, #2                         ; =0x2
	str	w10, [x9, #16]
	stp	x3, x4, [x9, #24]
	cbz	w8, LBB79_4
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.eq	LBB79_4
; %bb.2:                                ; %entry
	cmp	w8, #2
	b.ne	LBB79_5
; %bb.3:                                ; %bb3
	str	xzr, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	stur	q0, [x0, #8]
	ret
LBB79_4:                                ; %bb2
	stp	xzr, xzr, [x0]
	str	xzr, [x0, #16]
	ret
LBB79_5:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6 ; -- Begin function wf_hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6
	.p2align	2
_wf_hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6: ; @"wf_hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	cmp	x1, #3
	b.hi	LBB80_2
; %bb.1:                                ; %bb3.i
	ldr	x19, [x0]
	ldr	x8, [x19]
	cmp	x1, x8
	b.hs	LBB80_3
LBB80_2:
	mov	w0, #1                          ; =0x1
	b	LBB80_39
LBB80_3:                                ; %bb6.i
	cbz	x1, LBB80_38
; %bb.4:                                ; %bb9.i
	mov	x22, x0
	ldr	x20, [x2]
	ldrb	w21, [x2, #8]
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	mov	x23, x1
	madd	x0, x1, x8, x9
	bl	_malloc
	cbz	x0, LBB80_41
; %bb.5:                                ; %bb1.i.i
	mov	x8, #0                          ; =0x0
	mov	x9, x23
	str	x23, [x0, #8]
	add	x10, x0, #24
LBB80_6:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x10, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x10], #24
	cmp	x9, x8
	b.ne	LBB80_6
; %bb.7:                                ; %bb4.bb7_crit_edge.i.i
	str	x9, [x0]
	str	x0, [x22]
	ldr	x13, [x19]
	cbz	x13, LBB80_37
; %bb.8:                                ; %bb14.lr.ph.i
	add	x8, x0, #16
	mov	w9, #24                         ; =0x18
	tbz	w21, #0, LBB80_21
; %bb.9:                                ; %bb14.us.i.preheader
	mov	w10, #2                         ; =0x2
	b	LBB80_13
LBB80_10:                               ; %bb35.us.us.i
                                        ;   in Loop: Header=BB80_13 Depth=1
	b.hs	LBB80_40
; %bb.11:                               ; %bb15.us.loopexit.i
                                        ;   in Loop: Header=BB80_13 Depth=1
	str	w10, [x14]
	stp	x12, x11, [x14, #8]
	ldr	x11, [x19]
LBB80_12:                               ; %bb15.us.i
                                        ;   in Loop: Header=BB80_13 Depth=1
	mov	x13, x11
	cbz	x11, LBB80_37
LBB80_13:                               ; %bb14.us.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB80_17 Depth 2
                                        ;       Child Loop BB80_18 Depth 3
	sub	x11, x13, #1
	str	x11, [x19]
	madd	x12, x13, x9, x19
	ldr	w13, [x12, #-8]!
	cmp	w13, #2
	b.lo	LBB80_12
; %bb.14:                               ; %bb14.us.i
                                        ;   in Loop: Header=BB80_13 Depth=1
	b.ne	LBB80_40
; %bb.15:                               ; %bb23.lr.ph.us.i
                                        ;   in Loop: Header=BB80_13 Depth=1
	ldr	x13, [x0]
	cbz	x13, LBB80_20
; %bb.16:                               ;   in Loop: Header=BB80_13 Depth=1
	ldp	x12, x11, [x12, #8]
LBB80_17:                               ; %bb35.us.us.i.preheader
                                        ;   Parent Loop BB80_13 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB80_18 Depth 3
	mov	x15, #0                         ; =0x0
	mov	x14, x8
LBB80_18:                               ; %bb35.us.us.i
                                        ;   Parent Loop BB80_13 Depth=1
                                        ;     Parent Loop BB80_17 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w16, [x14]
	cmp	w16, #2
	b.ne	LBB80_10
; %bb.19:                               ; %bb3.i31.us.us.i
                                        ;   in Loop: Header=BB80_18 Depth=3
	add	x15, x15, #1
	add	x14, x14, #24
	cmp	x13, x15
	b.ne	LBB80_18
	b	LBB80_17
LBB80_20:                               ; %bb23.us.us.i
                                        ; =>This Inner Loop Header: Depth=1
	b	LBB80_20
LBB80_21:                               ; %bb14.i.preheader
	mov	x10, #58809                     ; =0xe5b9
	movk	x10, #7396, lsl #16
	movk	x10, #18285, lsl #32
	movk	x10, #48984, lsl #48
	mov	x11, #4587                      ; =0x11eb
	movk	x11, #4913, lsl #16
	movk	x11, #18875, lsl #32
	movk	x11, #38096, lsl #48
	mov	w12, #2                         ; =0x2
	b	LBB80_25
LBB80_22:                               ; %bb35.1.i
                                        ;   in Loop: Header=BB80_25 Depth=1
	b.hs	LBB80_40
; %bb.23:                               ; %bb15.loopexit.i
                                        ;   in Loop: Header=BB80_25 Depth=1
	str	w12, [x15]
	stur	q0, [x15, #8]
	ldr	x14, [x19]
LBB80_24:                               ; %bb15.i
                                        ;   in Loop: Header=BB80_25 Depth=1
	mov	x13, x14
	cbz	x14, LBB80_37
LBB80_25:                               ; %bb14.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB80_29 Depth 2
                                        ;       Child Loop BB80_30 Depth 3
                                        ;       Child Loop BB80_34 Depth 3
	sub	x14, x13, #1
	str	x14, [x19]
	madd	x15, x13, x9, x19
	ldr	w13, [x15, #-8]!
	cmp	w13, #2
	b.lo	LBB80_24
; %bb.26:                               ; %bb14.i
                                        ;   in Loop: Header=BB80_25 Depth=1
	b.ne	LBB80_40
; %bb.27:                               ; %bb23.lr.ph.i
                                        ;   in Loop: Header=BB80_25 Depth=1
	ldr	x13, [x0]
	cbz	x13, LBB80_36
; %bb.28:                               ; %bb23.i.preheader
                                        ;   in Loop: Header=BB80_25 Depth=1
	ldur	q0, [x15, #8]
	ldr	x14, [x15, #8]
	eor	x14, x14, x20
	eor	x14, x14, x14, lsr #30
	mul	x14, x14, x10
	eor	x14, x14, x14, lsr #27
	mul	x14, x14, x11
	eor	x14, x14, x14, lsr #31
	udiv	x15, x14, x13
	msub	x14, x15, x13, x14
LBB80_29:                               ; %bb35.i
                                        ;   Parent Loop BB80_25 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB80_30 Depth 3
                                        ;       Child Loop BB80_34 Depth 3
	mov	x16, x14
LBB80_30:                               ; %bb35.i
                                        ;   Parent Loop BB80_25 Depth=1
                                        ;     Parent Loop BB80_29 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	madd	x15, x16, x9, x0
	ldr	w17, [x15, #16]!
	cmp	w17, #2
	b.ne	LBB80_22
; %bb.31:                               ; %bb3.i31.i
                                        ;   in Loop: Header=BB80_30 Depth=3
	add	x15, x16, #1
	cmp	x15, x13
	csinc	x16, x14, x16, eq
	b.ne	LBB80_30
; %bb.32:                               ; %bb3.i31.i
                                        ;   in Loop: Header=BB80_30 Depth=3
	cbz	x14, LBB80_30
; %bb.33:                               ; %bb35.1.i.preheader
                                        ;   in Loop: Header=BB80_29 Depth=2
	mov	x16, #0                         ; =0x0
	mov	x15, x8
LBB80_34:                               ; %bb35.1.i
                                        ;   Parent Loop BB80_25 Depth=1
                                        ;     Parent Loop BB80_29 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w17, [x15]
	cmp	w17, #2
	b.ne	LBB80_22
; %bb.35:                               ; %bb3.i31.1.i
                                        ;   in Loop: Header=BB80_34 Depth=3
	add	x16, x16, #1
	add	x15, x15, #24
	cmp	x14, x16
	b.ne	LBB80_34
	b	LBB80_29
LBB80_36:                               ; %bb23.us17.i
                                        ; =>This Inner Loop Header: Depth=1
	b	LBB80_36
LBB80_37:                               ; %bb13.i
	mov	x0, x19
	bl	_free
LBB80_38:                               ; %"wf_hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6.body.exit"
	mov	w0, #0                          ; =0x0
LBB80_39:                               ; %"wf_hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB80_40:                               ; %invalid.tag.b12.i
	bl	_abort
LBB80_41:                               ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_slots_new$instance$f6f95306140971d3 ; -- Begin function wf_slots_new$instance$f6f95306140971d3
	.p2align	2
_wf_slots_new$instance$f6f95306140971d3: ; @"wf_slots_new$instance$f6f95306140971d3"
; %bb.0:                                ; %entry
	mov	x0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_is_available$instance$0ed342445dd803f3 ; -- Begin function wf_hash_map.hash_map_is_available$instance$0ed342445dd803f3
	.p2align	2
_wf_hash_map.hash_map_is_available$instance$0ed342445dd803f3: ; @"wf_hash_map.hash_map_is_available$instance$0ed342445dd803f3"
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cmp	w8, #3
	b.hs	LBB82_2
; %bb.1:                                ; %switch.lookup
	mov	w9, #3                          ; =0x3
	lsr	w8, w9, w8
	and	w0, w8, #0x1
	ret
LBB82_2:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_action$instance$c6df3d8464f8cde0 ; -- Begin function wf_hash_map.hash_map_action$instance$c6df3d8464f8cde0
	.p2align	2
_wf_hash_map.hash_map_action$instance$c6df3d8464f8cde0: ; @"wf_hash_map.hash_map_action$instance$c6df3d8464f8cde0"
; %bb.0:                                ; %entry
	mov	x8, x0
	ldr	w0, [x0]
	cmp	w0, #2
	b.hs	LBB83_2
; %bb.1:                                ; %common.ret
	ret
LBB83_2:                                ; %entry
	b.ne	LBB83_4
; %bb.3:                                ; %bb3
	ldr	x8, [x8, #8]
	ldr	x9, [x1]
	cmp	x8, x9
	mov	w8, #2                          ; =0x2
	cinc	w0, w8, eq
	ret
LBB83_4:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449 ; -- Begin function wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449
	.p2align	2
_wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449: ; @"wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449"
; %bb.0:                                ; %entry
	stp	d15, d14, [sp, #-64]!           ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	ldr	x8, [x1]
	mov	w9, #272                        ; =0x110
	madd	x10, x2, x9, x8
	ldr	w9, [x10, #16]!
	ldur	q0, [x10, #8]
	ldur	q1, [x10, #24]
	ldur	q2, [x10, #40]
	ldur	q3, [x10, #56]
	ldur	q4, [x10, #72]
	ldur	q5, [x10, #88]
	ldur	q6, [x10, #104]
	ldur	q7, [x10, #120]
	ldur	q16, [x10, #136]
	ldur	q17, [x10, #152]
	ldur	q18, [x10, #168]
	ldur	q19, [x10, #184]
	ldur	q20, [x10, #200]
	ldur	q21, [x10, #216]
	ldur	q22, [x10, #232]
	ldur	q23, [x10, #248]
	ldr	x8, [x10, #264]
	ldp	q24, q25, [x4]
	ldp	q26, q27, [x4, #32]
	ldp	q28, q29, [x4, #64]
	ldp	q30, q31, [x4, #96]
	ldp	q8, q9, [x4, #128]
	ldp	q10, q11, [x4, #160]
	ldp	q12, q13, [x4, #192]
	ldp	q14, q15, [x4, #224]
	mov	w11, #2                         ; =0x2
	str	w11, [x10]
	str	x3, [x10, #8]
	stp	q24, q25, [x10, #16]
	stp	q26, q27, [x10, #48]
	stp	q28, q29, [x10, #80]
	stp	q30, q31, [x10, #112]
	stp	q8, q9, [x10, #144]
	stp	q10, q11, [x10, #176]
	stp	q12, q13, [x10, #208]
	stp	q14, q15, [x10, #240]
	cbz	w9, LBB84_4
; %bb.1:                                ; %entry
	cmp	w9, #1
	b.eq	LBB84_4
; %bb.2:                                ; %entry
	cmp	w9, #2
	b.ne	LBB84_5
; %bb.3:                                ; %bb3
	str	xzr, [x0]
	mov	w9, #1                          ; =0x1
	str	w9, [x0]
	stur	q0, [x0, #8]
	stur	q1, [x0, #24]
	stur	q2, [x0, #40]
	stur	q3, [x0, #56]
	stur	q4, [x0, #72]
	stur	q5, [x0, #88]
	stur	q6, [x0, #104]
	stur	q7, [x0, #120]
	stur	q16, [x0, #136]
	stur	q17, [x0, #152]
	stur	q18, [x0, #168]
	stur	q19, [x0, #184]
	stur	q20, [x0, #200]
	stur	q21, [x0, #216]
	stur	q22, [x0, #232]
	stur	q23, [x0, #248]
	str	x8, [x0, #264]
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #64             ; 16-byte Folded Reload
	ret
LBB84_4:                                ; %bb2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0, #240]
	stp	q0, q0, [x0, #208]
	stp	q0, q0, [x0, #176]
	stp	q0, q0, [x0, #144]
	stp	q0, q0, [x0, #112]
	stp	q0, q0, [x0, #80]
	stp	q0, q0, [x0, #48]
	stp	q0, q0, [x0, #16]
	str	q0, [x0]
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #64             ; 16-byte Folded Reload
	ret
LBB84_5:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07 ; -- Begin function wf_hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07
	.p2align	2
_wf_hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07: ; @"wf_hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #576
	.cfi_def_cfa_offset 672
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cmp	x1, #3
	b.hi	LBB85_2
; %bb.1:                                ; %bb3.i
	mov	x19, x0
	ldr	x22, [x0]
	ldr	x8, [x22]
	cmp	x1, x8
	b.hs	LBB85_3
LBB85_2:
	mov	w0, #1                          ; =0x1
	b	LBB85_45
LBB85_3:                                ; %bb6.i
	cbz	x1, LBB85_44
; %bb.4:                                ; %bb9.i
	ldr	x23, [x2]
	ldrb	w8, [x2, #8]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	mov	x20, x1
	madd	x0, x1, x8, x9
	bl	_malloc
	cbz	x0, LBB85_47
; %bb.5:                                ; %bb1.i.i
	mov	x21, x0
	mov	x8, #0                          ; =0x0
	mov	x9, x20
	str	x20, [x0, #8]
	add	x10, x0, #24
	movi.2d	v0, #0000000000000000
LBB85_6:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x10, #-8]
	add	x8, x8, #1
	stp	q0, q0, [x10]
	stp	q0, q0, [x10, #32]
	stp	q0, q0, [x10, #64]
	stp	q0, q0, [x10, #96]
	stp	q0, q0, [x10, #128]
	stp	q0, q0, [x10, #160]
	stp	q0, q0, [x10, #192]
	stp	q0, q0, [x10, #224]
	str	xzr, [x10, #256]
	add	x10, x10, #272
	cmp	x9, x8
	b.ne	LBB85_6
; %bb.7:                                ; %bb4.bb7_crit_edge.i.i
	str	x9, [x21]
	str	x21, [x19]
	ldr	x8, [x22]
	cbz	x8, LBB85_43
; %bb.8:                                ; %bb14.lr.ph.i
	add	x27, x21, #16
	mov	w28, #272                       ; =0x110
	mov	w24, #264                       ; =0x108
	add	x25, sp, #32
	str	x22, [sp, #16]                  ; 8-byte Folded Spill
	b	LBB85_11
LBB85_9:                                ; %bb15thread-pre-split.i
                                        ;   in Loop: Header=BB85_11 Depth=1
	ldr	x22, [sp, #16]                  ; 8-byte Folded Reload
	ldr	x9, [x22]
LBB85_10:                               ; %bb15.i
                                        ;   in Loop: Header=BB85_11 Depth=1
	mov	x8, x9
	cbz	x9, LBB85_43
LBB85_11:                               ; %bb14.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB85_29 Depth 2
                                        ;     Child Loop BB85_31 Depth 2
                                        ;     Child Loop BB85_35 Depth 2
                                        ;     Child Loop BB85_18 Depth 2
                                        ;       Child Loop BB85_20 Depth 3
	sub	x9, x8, #1
	str	x9, [x22]
	madd	x8, x8, x28, x22
	ldr	w10, [x8, #-256]!
	cmp	w10, #2
	b.lo	LBB85_10
; %bb.12:                               ; %bb14.i
                                        ;   in Loop: Header=BB85_11 Depth=1
	b.ne	LBB85_46
; %bb.13:                               ; %bb23.preheader.i
                                        ;   in Loop: Header=BB85_11 Depth=1
	ldr	x9, [x8, #264]
	str	xzr, [sp, #32]
	ldur	q0, [x8, #8]
	stur	q0, [sp, #40]
	ldur	q0, [x8, #24]
	stur	q0, [sp, #56]
	ldur	q0, [x8, #40]
	stur	q0, [sp, #72]
	ldur	q0, [x8, #56]
	stur	q0, [sp, #88]
	ldur	q0, [x8, #72]
	stur	q0, [sp, #104]
	ldur	q0, [x8, #88]
	stur	q0, [sp, #120]
	ldur	q0, [x8, #104]
	stur	q0, [sp, #136]
	ldur	q0, [x8, #120]
	stur	q0, [sp, #152]
	ldur	q0, [x8, #136]
	add	x10, sp, #32
	stur	q0, [x10, #136]
	ldur	q0, [x8, #152]
	stur	q0, [x10, #152]
	ldur	q0, [x8, #168]
	stur	q0, [x10, #168]
	ldur	q0, [x8, #184]
	stur	q0, [x10, #184]
	ldur	q0, [x8, #200]
	stur	q0, [x10, #200]
	ldur	q0, [x8, #216]
	stur	q0, [x10, #216]
	ldur	q0, [x8, #232]
	stur	q0, [x10, #232]
	ldur	q0, [x8, #248]
	stur	q0, [x10, #248]
	str	x9, [sp, #296]
	ldr	x8, [x21]
	ldr	w9, [sp, #28]                   ; 4-byte Folded Reload
	tbz	w9, #0, LBB85_26
; %bb.14:                               ; %bb23.preheader.i.split.us.split
                                        ;   in Loop: Header=BB85_11 Depth=1
	cbz	x8, LBB85_41
; %bb.15:                               ; %bb23.i.us.preheader
                                        ;   in Loop: Header=BB85_11 Depth=1
	mov	w20, #1                         ; =0x1
	b	LBB85_18
LBB85_16:                               ; %bb24.i.us
                                        ;   in Loop: Header=BB85_18 Depth=2
	mov	x20, x26
	cbz	x26, LBB85_9
LBB85_17:                               ; %bb23.i.usthread-pre-split
                                        ;   in Loop: Header=BB85_18 Depth=2
	ldr	x8, [x21]
LBB85_18:                               ; %bb23.i.us
                                        ;   Parent Loop BB85_11 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB85_20 Depth 3
	cbz	x8, LBB85_17
; %bb.19:                               ; %bb35.i.us.preheader
                                        ;   in Loop: Header=BB85_18 Depth=2
	mov	x2, #0                          ; =0x0
	mov	x9, x27
LBB85_20:                               ; %bb35.i.us
                                        ;   Parent Loop BB85_11 Depth=1
                                        ;     Parent Loop BB85_18 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w10, [x9]
	cmp	w10, #2
	b.ne	LBB85_22
; %bb.21:                               ; %bb3.i30.i.us
                                        ;   in Loop: Header=BB85_20 Depth=3
	add	x9, x9, #272
	add	x2, x2, #1
	cmp	x8, x2
	b.ne	LBB85_20
	b	LBB85_17
LBB85_22:                               ; %bb35.i.us
                                        ;   in Loop: Header=BB85_18 Depth=2
	b.hs	LBB85_46
; %bb.23:                               ; %bb39.i.loopexit3.us
                                        ;   in Loop: Header=BB85_18 Depth=2
	sub	x26, x20, #1
	str	x26, [sp, #32]
	madd	x22, x20, x24, x25
	ldr	x3, [x22, #-256]!
	add	x0, sp, #304
	add	x4, x22, #8
	mov	x1, x19
	bl	_wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449
	ldr	w8, [sp, #304]
	cbz	w8, LBB85_16
; %bb.24:                               ; %bb39.i.loopexit3.us
                                        ;   in Loop: Header=BB85_18 Depth=2
	cmp	w8, #1
	b.ne	LBB85_46
; %bb.25:                               ; %bb43.i.us
                                        ;   in Loop: Header=BB85_18 Depth=2
	add	x8, sp, #304
	add	x1, x8, #8
	mov	x0, x22
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	str	x20, [sp, #32]
	b	LBB85_17
LBB85_26:                               ; %bb23.preheader.i.split
                                        ;   in Loop: Header=BB85_11 Depth=1
	cbz	x8, LBB85_42
; %bb.27:                               ; %bb23.i.preheader
                                        ;   in Loop: Header=BB85_11 Depth=1
	mov	w26, #1                         ; =0x1
	cbnz	x8, LBB85_30
	b	LBB85_29
LBB85_28:                               ; %bb24.i
                                        ;   in Loop: Header=BB85_11 Depth=1
	mov	x26, x20
	cbz	x20, LBB85_9
LBB85_29:                               ; %bb23.ithread-pre-split
                                        ;   Parent Loop BB85_11 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x8, [x21]
	cbz	x8, LBB85_29
LBB85_30:                               ; %bb35.preheader.i
                                        ;   in Loop: Header=BB85_11 Depth=1
	ldr	x9, [sp, #40]
	eor	x9, x9, x23
	eor	x9, x9, x9, lsr #30
	mov	x10, #58809                     ; =0xe5b9
	movk	x10, #7396, lsl #16
	movk	x10, #18285, lsl #32
	movk	x10, #48984, lsl #48
	mul	x9, x9, x10
	eor	x9, x9, x9, lsr #27
	mov	x10, #4587                      ; =0x11eb
	movk	x10, #4913, lsl #16
	movk	x10, #18875, lsl #32
	movk	x10, #38096, lsl #48
	mul	x9, x9, x10
	eor	x9, x9, x9, lsr #31
	udiv	x10, x9, x8
	msub	x9, x10, x8, x9
	mov	x2, x9
LBB85_31:                               ; %bb35.i
                                        ;   Parent Loop BB85_11 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	madd	x10, x2, x28, x21
	ldr	w10, [x10, #16]
	cmp	w10, #2
	b.ne	LBB85_37
; %bb.32:                               ; %bb3.i30.i
                                        ;   in Loop: Header=BB85_31 Depth=2
	add	x2, x2, #1
	cmp	x2, x8
	b.ne	LBB85_31
; %bb.33:                               ; %bb45.i
                                        ;   in Loop: Header=BB85_11 Depth=1
	cbz	x9, LBB85_29
; %bb.34:                               ; %bb35.1.i.preheader
                                        ;   in Loop: Header=BB85_11 Depth=1
	mov	x2, #0                          ; =0x0
	mov	x8, x27
LBB85_35:                               ; %bb35.1.i
                                        ;   Parent Loop BB85_11 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	w10, [x8]
	cmp	w10, #2
	b.ne	LBB85_37
; %bb.36:                               ; %bb3.i30.1.i
                                        ;   in Loop: Header=BB85_35 Depth=2
	add	x8, x8, #272
	add	x2, x2, #1
	cmp	x9, x2
	b.ne	LBB85_35
	b	LBB85_29
LBB85_37:                               ; %bb35.i
                                        ;   in Loop: Header=BB85_11 Depth=1
	b.hs	LBB85_46
; %bb.38:                               ; %bb39.i
                                        ;   in Loop: Header=BB85_11 Depth=1
	sub	x20, x26, #1
	str	x20, [sp, #32]
	madd	x22, x26, x24, x25
	ldr	x3, [x22, #-256]!
	add	x0, sp, #304
	add	x4, x22, #8
	mov	x1, x19
	bl	_wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449
	ldr	w8, [sp, #304]
	cbz	w8, LBB85_28
; %bb.39:                               ; %bb39.i
                                        ;   in Loop: Header=BB85_11 Depth=1
	cmp	w8, #1
	b.ne	LBB85_46
; %bb.40:                               ; %bb43.i
                                        ;   in Loop: Header=BB85_11 Depth=1
	add	x8, sp, #304
	add	x1, x8, #8
	mov	x0, x22
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	str	x26, [sp, #32]
	b	LBB85_29
LBB85_41:                               ; %bb23.i.us.us
                                        ; =>This Inner Loop Header: Depth=1
	b	LBB85_41
LBB85_42:                               ; %bb23.i.us8
                                        ; =>This Inner Loop Header: Depth=1
	b	LBB85_42
LBB85_43:                               ; %bb13.i
	mov	x0, x22
	bl	_free
LBB85_44:                               ; %"wf_hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07.body.exit"
	mov	w0, #0                          ; =0x0
LBB85_45:                               ; %"wf_hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	add	sp, sp, #576
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB85_46:                               ; %invalid.tag.b12.i
	bl	_abort
LBB85_47:                               ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_slots_new$instance$7445cefb96d3b406 ; -- Begin function wf_slots_new$instance$7445cefb96d3b406
	.p2align	2
_wf_slots_new$instance$7445cefb96d3b406: ; @"wf_slots_new$instance$7445cefb96d3b406"
; %bb.0:                                ; %entry
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0, #240]
	stp	q0, q0, [x0, #208]
	stp	q0, q0, [x0, #176]
	stp	q0, q0, [x0, #144]
	stp	q0, q0, [x0, #112]
	stp	q0, q0, [x0, #80]
	stp	q0, q0, [x0, #48]
	stp	q0, q0, [x0, #16]
	str	q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_is_available$instance$d7a1a90c27bba449 ; -- Begin function wf_hash_map.hash_map_is_available$instance$d7a1a90c27bba449
	.p2align	2
_wf_hash_map.hash_map_is_available$instance$d7a1a90c27bba449: ; @"wf_hash_map.hash_map_is_available$instance$d7a1a90c27bba449"
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cmp	w8, #3
	b.hs	LBB87_2
; %bb.1:                                ; %switch.lookup
	mov	w9, #3                          ; =0x3
	lsr	w8, w9, w8
	and	w0, w8, #0x1
	ret
LBB87_2:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_take_back$instance$20364da1adbcdc5f ; -- Begin function wf_take_back$instance$20364da1adbcdc5f
	.p2align	2
_wf_take_back$instance$20364da1adbcdc5f: ; @"wf_take_back$instance$20364da1adbcdc5f"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x9, [x8]
	sub	x10, x9, #1
	str	x10, [x8]
	mov	w10, #24                        ; =0x18
	madd	x8, x9, x10, x8
	ldur	w0, [x8, #-8]
	ldp	x1, x2, [x8]
	ret
                                        ; -- End function
	.globl	_wf_free_empty$instance$fd33b528f0517054 ; -- Begin function wf_free_empty$instance$fd33b528f0517054
	.p2align	2
_wf_free_empty$instance$fd33b528f0517054: ; @"wf_free_empty$instance$fd33b528f0517054"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	bl	_free
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_swap$instance$087f541e70b769ea ; -- Begin function wf_swap$instance$087f541e70b769ea
	.p2align	2
_wf_swap$instance$087f541e70b769ea:     ; @"wf_swap$instance$087f541e70b769ea"
; %bb.0:                                ; %entry
	ldr	q0, [x0]
	str	q0, [sp, #-32]!
	ldr	x8, [x0, #16]
	str	x8, [sp, #16]
	ldr	x9, [x1, #16]
	ldr	q1, [x1]
	str	q1, [x0]
	str	x9, [x0, #16]
	str	q0, [x1]
	str	x8, [x1, #16]
	mov	w0, #0                          ; =0x0
	add	sp, sp, #32
	ret
                                        ; -- End function
	.globl	_wf_take_back$instance$2af1311599ac146a ; -- Begin function wf_take_back$instance$2af1311599ac146a
	.p2align	2
_wf_take_back$instance$2af1311599ac146a: ; @"wf_take_back$instance$2af1311599ac146a"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x8]
	sub	x10, x9, #1
	mov	w11, #272                       ; =0x110
	madd	x9, x9, x11, x8
	sub	x1, x9, #256
	str	x10, [x8]
	mov	w2, #272                        ; =0x110
	b	_memmove
                                        ; -- End function
	.globl	_wf_free_empty$instance$1b41cffa653e924b ; -- Begin function wf_free_empty$instance$1b41cffa653e924b
	.p2align	2
_wf_free_empty$instance$1b41cffa653e924b: ; @"wf_free_empty$instance$1b41cffa653e924b"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	bl	_free
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_swap$instance$b1cfa6e689dc9e10 ; -- Begin function wf_swap$instance$b1cfa6e689dc9e10
	.p2align	2
_wf_swap$instance$b1cfa6e689dc9e10:     ; @"wf_swap$instance$b1cfa6e689dc9e10"
; %bb.0:                                ; %entry
	sub	sp, sp, #320
	stp	x28, x27, [sp, #272]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #288]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #304]            ; 16-byte Folded Spill
	mov	x19, x1
	mov	x20, x0
	mov	x0, sp
	mov	x1, x20
	mov	w2, #272                        ; =0x110
	bl	_memcpy
	mov	x0, x20
	mov	x1, x19
	mov	w2, #272                        ; =0x110
	bl	_memmove
	mov	x1, sp
	mov	x0, x19
	mov	w2, #272                        ; =0x110
	bl	_memcpy
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #304]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #288]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #272]            ; 16-byte Folded Reload
	add	sp, sp, #320
	ret
                                        ; -- End function
	.globl	_wf_grow$instance$087f541e70b769ea ; -- Begin function wf_grow$instance$087f541e70b769ea
	.p2align	2
_wf_grow$instance$087f541e70b769ea:     ; @"wf_grow$instance$087f541e70b769ea"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x22, x1
	mov	x19, x0
	ldr	x20, [x0]
	ldr	x23, [x20]
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	madd	x0, x1, x8, x9
	bl	_malloc
	cbz	x0, LBB94_2
; %bb.1:                                ; %window.block.ready.v2
	mov	x21, x0
	stp	x23, x22, [x0], #16
	add	x8, x23, x23, lsl #1
	lsl	x2, x8, #3
	add	x1, x20, #16
	bl	_memmove
	mov	x0, x20
	bl	_free
	str	x21, [x19]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB94_2:                                ; %window.block.oom.v2
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_place_back$instance$20364da1adbcdc5f ; -- Begin function wf_place_back$instance$20364da1adbcdc5f
	.p2align	2
_wf_place_back$instance$20364da1adbcdc5f: ; @"wf_place_back$instance$20364da1adbcdc5f"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x9, [x8]
	mov	w10, #24                        ; =0x18
	madd	x10, x9, x10, x8
	ldr	x11, [x1, #16]
	ldr	q0, [x1]
	str	q0, [x10, #16]
	str	x11, [x10, #32]
	add	x9, x9, #1
	str	x9, [x8]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_swap$instance$fd33b528f0517054 ; -- Begin function wf_swap$instance$fd33b528f0517054
	.p2align	2
_wf_swap$instance$fd33b528f0517054:     ; @"wf_swap$instance$fd33b528f0517054"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x9, [x1]
	str	x9, [x0]
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_place_back$instance$22267f8259e51fb5 ; -- Begin function wf_place_back$instance$22267f8259e51fb5
	.p2align	2
_wf_place_back$instance$22267f8259e51fb5: ; @"wf_place_back$instance$22267f8259e51fb5"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	add	x9, x0, x8, lsl #4
	ldr	q0, [x1]
	stur	q0, [x9, #8]
	add	x8, x8, #1
	str	x8, [x0]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_take_back$instance$22267f8259e51fb5 ; -- Begin function wf_take_back$instance$22267f8259e51fb5
	.p2align	2
_wf_take_back$instance$22267f8259e51fb5: ; @"wf_take_back$instance$22267f8259e51fb5"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	sub	x8, x8, #1
	add	x9, x0, x8, lsl #4
	str	x8, [x0]
	ldp	x0, x1, [x9, #8]
	ret
                                        ; -- End function
	.globl	_wf_free_empty$instance$b7fb76652ce23509 ; -- Begin function wf_free_empty$instance$b7fb76652ce23509
	.p2align	2
_wf_free_empty$instance$b7fb76652ce23509: ; @"wf_free_empty$instance$b7fb76652ce23509"
; %bb.0:                                ; %entry
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_grow$instance$b1cfa6e689dc9e10 ; -- Begin function wf_grow$instance$b1cfa6e689dc9e10
	.p2align	2
_wf_grow$instance$b1cfa6e689dc9e10:     ; @"wf_grow$instance$b1cfa6e689dc9e10"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x22, x1
	mov	x19, x0
	ldr	x20, [x0]
	ldr	x23, [x20]
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	madd	x0, x1, x8, x9
	bl	_malloc
	cbz	x0, LBB100_2
; %bb.1:                                ; %window.block.ready.v2
	mov	x21, x0
	stp	x23, x22, [x0], #16
	add	x8, x23, x23, lsl #4
	lsl	x2, x8, #4
	add	x1, x20, #16
	bl	_memmove
	mov	x0, x20
	bl	_free
	str	x21, [x19]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB100_2:                               ; %window.block.oom.v2
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_place_back$instance$2af1311599ac146a ; -- Begin function wf_place_back$instance$2af1311599ac146a
	.p2align	2
_wf_place_back$instance$2af1311599ac146a: ; @"wf_place_back$instance$2af1311599ac146a"
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	ldr	x19, [x0]
	ldr	x20, [x19]
	mov	w8, #272                        ; =0x110
	madd	x8, x20, x8, x19
	add	x0, x8, #16
	mov	w2, #272                        ; =0x110
	bl	_memmove
	add	x8, x20, #1
	str	x8, [x19]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_swap$instance$1b41cffa653e924b ; -- Begin function wf_swap$instance$1b41cffa653e924b
	.p2align	2
_wf_swap$instance$1b41cffa653e924b:     ; @"wf_swap$instance$1b41cffa653e924b"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x9, [x1]
	str	x9, [x0]
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_place_back$instance$48adfc37250fbcc6 ; -- Begin function wf_place_back$instance$48adfc37250fbcc6
	.p2align	2
_wf_place_back$instance$48adfc37250fbcc6: ; @"wf_place_back$instance$48adfc37250fbcc6"
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	mov	x19, x0
	ldr	x20, [x0]
	mov	w8, #264                        ; =0x108
	madd	x8, x20, x8, x0
	add	x0, x8, #8
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	x8, x20, #1
	str	x8, [x19]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_take_back$instance$48adfc37250fbcc6 ; -- Begin function wf_take_back$instance$48adfc37250fbcc6
	.p2align	2
_wf_take_back$instance$48adfc37250fbcc6: ; @"wf_take_back$instance$48adfc37250fbcc6"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	sub	x9, x8, #1
	mov	w10, #264                       ; =0x108
	madd	x8, x8, x10, x1
	sub	x8, x8, #256
	str	x9, [x1]
	mov	x1, x8
	mov	w2, #264                        ; =0x108
	b	_memcpy
                                        ; -- End function
	.globl	_wf_free_empty$instance$d97c759d7de32f56 ; -- Begin function wf_free_empty$instance$d97c759d7de32f56
	.p2align	2
_wf_free_empty$instance$d97c759d7de32f56: ; @"wf_free_empty$instance$d97c759d7de32f56"
; %bb.0:                                ; %entry
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf__floor_run                  ; -- Begin function wf__floor_run
	.weak_definition	_wf__floor_run
	.p2align	2
_wf__floor_run:                         ; @wf__floor_run
	.cfi_startproc
; %bb.0:                                ; %entry
	b	_wf__main_body
	.cfi_endproc
                                        ; -- End function
	.globl	_wf__main_body                  ; -- Begin function wf__main_body
	.p2align	2
_wf__main_body:                         ; @wf__main_body
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w0, #3                          ; =0x3
	mov	w1, #2                          ; =0x2
	mov	w2, #2                          ; =0x2
	mov	w3, #17                         ; =0x11
	mov	x5, #0                          ; =0x0
	mov	w4, #7                          ; =0x7
	bl	_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd
	mov	w0, #3                          ; =0x3
	mov	w1, #2                          ; =0x2
	mov	w2, #2                          ; =0x2
	mov	w3, #17                         ; =0x11
	mov	w4, #3                          ; =0x3
	mov	w5, #1                          ; =0x1
	bl	_wf_map_cost_library_trace$instance$4250cb78d3f44027
	mov	x0, sp
	mov	w1, #0                          ; =0x0
	bl	_wf_std.process.exit_status
	mov	w0, #3                          ; =0x3
	mov	w1, #2                          ; =0x2
	mov	w2, #17                         ; =0x11
	bl	_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd
	mov	w0, #3                          ; =0x3
	mov	w1, #2                          ; =0x2
	mov	w2, #17                         ; =0x11
	bl	_wf_map_cost_library_geometry$instance$4250cb78d3f44027
	mov	x0, sp
	bl	_wf__ordinary_exit_code
	and	w0, w0, #0xff
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_fixture_main                ; -- Begin function wf_fixture_main
	.p2align	2
_wf_fixture_main:                       ; @wf_fixture_main
	.cfi_startproc
; %bb.0:                                ; %entry
	b	_wf__floor_run
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__const
l_.wf_resource.heap:                    ; @.wf_resource.heap
	.ascii	"{\"resource\":\"heap\"}\n"

.subsections_via_symbols
