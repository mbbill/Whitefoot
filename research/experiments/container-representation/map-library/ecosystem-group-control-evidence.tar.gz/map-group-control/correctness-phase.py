"""One-shot Map trial construction/check caller. Owned by the existing Map
experiment; remove with this scratch trial. Every subprocess is sequential,
records its direct status and separate stdout/stderr, and never times a workload.
Invoke only through the repository heavy guard. Inputs are frozen separately.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shlex, subprocess, sys, time
S=Path('/private/tmp/whitefoot-map-group-control-7abd6bb')
R=Path('/private/tmp/whitefoot-container-library-complete')
F=Path('/private/tmp/whitefoot-map-occupancy-7abd6bb')
CLI=F/'whitefootc'; E=F/'build/ecosystem'
B=S/'correctness'; B.mkdir(exist_ok=True)
L=B/'commands'; L.mkdir(exist_ok=True)
N=['ordinary_values.o','sched/core.o','sched/entry.o','completion/runtime.o','completion/file_adapter.o','completion/bridge.o','wf_floor.o','sched/prim_host.o','completion/wait_host.o','completion/file_posix.o','completion/linux_io_uring.o','ordinary_values_ir.o']
RUNTIME=[F/'build/native'/p for p in N]
CONFIG=(E/'configuration.txt').read_text().splitlines()
ABSL=shlex.split(CONFIG[16]); RUST=shlex.split(CONFIG[12])
assert CONFIG[16].startswith('-L/private/tmp/whitefoot-abseil-20260817.0-install/lib ')
# Exact ordering from the maintained family's link target and runtime.mk.
def run(label,argv,expected=0,out=None,err=None):
    argv=list(map(str,argv)); stdout=L/(label+'.stdout'); stderr=L/(label+'.stderr')
    assert not stdout.exists() and not stderr.exists(), ('preserve prior outcome', label)
    start=datetime.now(timezone.utc).isoformat(); clock=time.monotonic()
    with stdout.open('wb') as o,stderr.open('wb') as e:
        result=subprocess.run(argv,cwd=R,stdout=o,stderr=e)
    record=dict(label=label,argv=argv,cwd=str(R),start_utc=start,wall_seconds=time.monotonic()-clock,direct_exit=result.returncode,expected_exit=expected,stdout=str(stdout),stderr=str(stderr))
    with (B/'commands.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
    print(json.dumps(record),flush=True)
    actual_out=stdout.read_text();actual_err=stderr.read_text()
    if result.returncode!=expected or (out is not None and actual_out!=out) or (err is not None and actual_err!=err):
        print(actual_out,actual_err,flush=True);raise SystemExit('Unexpected direct outcome: '+label)
    return stdout,stderr

def write_once(path,text):
    assert not path.exists(),str(path);path.write_text(text)

def build_ecosystem():
    run('candidate-account-driver', ['clang','-std=c11','-O3','-Wall','-Wextra','-Werror','-DECOSYSTEM','-DACCOUNT_ONLY','-DWF_GROUP_CONTROLS','-c',S/'account/map-ecosystem.c','-o',B/'candidate-driver-account.o'])
    for arm,raw in [('baseline','baseline-wrapper.raw.ll'),('candidate','candidate.raw.ll')]:
        llvm=(S/'native'/raw).read_text()
        assert llvm.count('define i32 @main(')==1
        write_once(B/(arm+'-account.ll'),llvm.replace('@malloc(','@wf_cost_allocate(').replace('@free(','@wf_cost_release(').replace('@main(','@wf_fixture_main('))
        run(arm+'-account-object',['clang','-O3','-Wno-override-module','-c',B/(arm+'-account.ll'),'-o',B/(arm+'-account.o')])
        for mode in ['timed','account']:
            driver=B/'candidate-driver-account.o' if arm=='candidate' and mode=='account' else E/('driver-'+mode+'.o')
            obj=S/'native'/(arm+'.o') if mode=='timed' else B/(arm+'-account.o')
            run(arm+'-'+mode+'-link',['clang++','-O3',driver,obj,E/('rust-'+mode+'.a'),E/('cpp-'+mode+'.o'),E/('control-'+mode+'.o'),*RUNTIME,*ABSL,*RUST,'-pthread','-lm','-o',B/(arm+'-'+mode)])

def check_ecosystem():
    geometry_reasons=dict(missing='one filled geometry snapshot',population='filled geometry population',identity='geometry implementation identity',capacity='exposed capacity geometry',allocation='filled geometry allocation snapshot',checksum='geometry independent setup oracle',diagnostic='diagnostic matches trace allocation')
    for arm in ['baseline','candidate']:
        for mode in ['timed','account']:
            exe=B/(arm+'-'+mode)
            run(arm+'-'+mode+'-check',[exe,'check'],out='map ecosystem: 18390 oracle-checked traces passed\n',err='')
            run(arm+'-'+mode+'-occupancy-check',[exe,'occupancy-check'],out='map occupancy: 1440 oracle-checked traces passed\n',err='')
        timed=B/(arm+'-timed'); account=B/(arm+'-account')
        run(arm+'-negative-checksum',[timed,'negative-checksum'],1,out='',err='map ecosystem: independent key-ID/content/outcome oracle\n')
        run(arm+'-negative-leak',[account,'negative-leak'],1,out='',err='map ecosystem: every allocation is reclaimed\n')
        for variant in [0,1,2,3,5,6,7,8]:
            run(arm+'-negative-reserve-'+str(variant),[timed,'negative-reserve',variant],1,out='',err='map ecosystem: reserve capacity floor\n')
        run(arm+'-geometry-check',[account,'geometry-check'],err='')
        for fault,reason in geometry_reasons.items():
            run(arm+'-negative-geometry-'+fault,[account,'negative-geometry',fault],1,out='',err='map ecosystem: '+reason+'\n')
        for mode,work in [('geometry',None),('geometry-identities',None),('account','262144'),('occupancy-account','1048576')]:
            output,_=run(arm+'-'+mode,[account,mode]+([work] if work else []),err='')
            destination=B/(arm+'-'+mode+('.csv' if mode!='geometry-identities' else '.txt'))
            assert not destination.exists(); destination.write_bytes(output.read_bytes())
    for fault in ['negative-metadata-bytes','negative-metadata-release']:
        run('candidate-'+fault,[B/'candidate-account',fault],1,out='',err='map ecosystem: group-control exact backing counts, bytes, peak and cleanup\n')

def build_owners():
    for arm in ['baseline','candidate']:
        for fixture in ['owning','indexed','group-owning']:
            for mode,flags in [('sequential',[]),('parallel',['--par'])]:
                name=arm+'-'+fixture+'-'+mode
                raw=B/(name+'.raw.ll')
                run(name+'-emit',[CLI,*flags,'--emit-llvm','--graph',S/(arm+'-'+fixture)/'modules.wfg','--entry','main','-o',raw])
                run(name+'-normal-link',['clang','-O2','-Wno-override-module',raw,*RUNTIME,'-pthread','-lm','-o',B/name])
                llvm=raw.read_text();assert llvm.count('define i32 @main(')==1 and '@malloc(' in llvm and '@free(' in llvm
                observed=B/(name+'.observed.ll')
                write_once(observed,llvm.replace('@malloc(','@wf_observe_allocate(').replace('@free(','@wf_observe_release(').replace('@main(','@wf_fixture_main('))
                observer=S/'group-owning-observer.c' if fixture=='group-owning' else B/'container-allocation-observer.c'
                defines=['-DGROUP_METADATA='+str(int(arm=='candidate')),'-DGROUP_EXACT_PEAK='+str(int(mode=='sequential'))] if fixture=='group-owning' else []
                run(name+'-observed-link',['clang','-std=c11','-O2','-Wall','-Wextra','-Werror','-Wno-override-module',*defines,'-I'+str(B/'include'),observed,observer,*RUNTIME,'-pthread','-lm','-o',B/(name+'-observed')])

def check_owners():
    for arm in ['baseline','candidate']:
        for fixture in ['owning','indexed','group-owning']:
            count={'owning':28,'indexed':129,'group-owning':77 if arm=='candidate' else 72}[fixture]
            for mode in ['sequential','parallel']:
                name=arm+'-'+fixture+'-'+mode
                run(name+'-normal-run',[B/name],out='',err='')
                expected='container allocation observer: '+str(count)+' allocations, each released exactly once\n'
                output,_=run(name+'-observed-run',[B/(name+'-observed')],out=None if fixture=='group-owning' else expected,err='')
                if fixture=='group-owning':
                    import re
                    lines=output.read_text().splitlines(keepends=True)
                    assert len(lines)==2 and lines[1]==expected
                    matched=re.fullmatch(r'group allocation ledger: requests=(\d+) releases=(\d+) bytes=(\d+) peak=(\d+) live=(\d+) exact_peak=(\d+)\n',lines[0]);assert matched
                    requests,releases,total,peak,live,exact=map(int,matched.groups())
                    assert (requests,releases,total,live,exact)==(count,count,3080 if arm=='candidate' else 2976,0,int(mode=='sequential'))
                    if exact:assert peak==(1456 if arm=='candidate' else 1408)
                    # Parallel peak is observed, not fixed by the source schedule.
                    assert 0 < peak <= total
        observed=B/(arm+'-group-owning-parallel-observed')
        run(arm+'-observer-concurrent',[observed,'concurrent'],out='container allocation observer: 32 allocations, each released exactly once\n',err='')
        observed=B/(arm+'-group-owning-sequential-observed')
        for fault,reason in [('double-release','allocation released twice'),('foreign-release','release did not return an allocated address'),('missing-release','every allocation is released exactly once'),('wrong-group-extent','group exact allocation extents'),('wrong-group-bytes','group exact count, bytes, peak and cleanup'),('wrong-group-peak','group exact count, bytes, peak and cleanup')]:
            run(arm+'-observer-'+fault,[observed,fault],1,out='',err='container allocation observer: '+reason+'\n')

if len(sys.argv)!=2:raise SystemExit('one phase required')
{'build-ecosystem':build_ecosystem,'check-ecosystem':check_ecosystem,'build-owners':build_owners,'check-owners':check_owners}[sys.argv[1]]()
