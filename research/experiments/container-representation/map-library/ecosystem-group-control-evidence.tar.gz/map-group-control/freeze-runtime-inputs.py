from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,subprocess,sys
S=Path('/private/tmp/whitefoot-map-group-control-7abd6bb');F=Path('/private/tmp/whitefoot-map-occupancy-7abd6bb');R=Path('/private/tmp/whitefoot-container-library-complete')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
mode=sys.argv[1];target=S/'correctness'/(mode+'-inputs.json')
assert not target.exists()
paths={F/'whitefootc',S/'correctness-phase.py'}
for d in ['baseline','candidate','baseline-owning','candidate-owning','baseline-indexed','candidate-indexed','baseline-group-owning','candidate-group-owning','account']:
 paths.update(p for p in (S/d).rglob('*') if p.is_file() and not p.name.endswith('.evidence'))
paths.update([S/'group-owning-observer.c',S/'correctness/container-allocation-observer.c',S/'correctness/include/sched/prim.h'])
paths.update(p for p in (S/'native').iterdir() if p.is_file())
old=json.loads((F/'pre-timing-freeze.json').read_text())
for e in old['artifacts']:
 p=Path(e['path']);assert digest(p)==e['sha256'],str(p);paths.add(p)
config=(F/'build/ecosystem/configuration.txt').read_text().splitlines()
for word in config[16].split():
 if word.startswith('-labsl_'):paths.add(Path('/private/tmp/whitefoot-abseil-20260817.0-install/lib')/('lib'+word[2:]+'.a'))
for path in ['/usr/bin/clang','/usr/bin/clang++','/Library/Developer/CommandLineTools/usr/bin/clang','/Library/Developer/CommandLineTools/usr/bin/ld']:
 paths.add(Path(path))
assert digest(F/'whitefootc')=='5753999f224f89a9a99e0399b76bfd7b92cd53d5f22b0d204df4f2ec3ffbc20b'
result={'utc':datetime.now(timezone.utc).isoformat(),'source_pin':'7abd6bb34746b7b983b83103c68ee429b24859bb','observed_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'frozen_native_original_manifest_sha256':digest(F/'pre-timing-freeze.json'),'qualification':'All old occupancy artifacts rehashed equal; fresh baseline/candidate source and already-qualified native objects are frozen here. No measurements.', 'files':[{'path':str(p),'sha256':digest(p),'bytes':p.stat().st_size} for p in sorted(paths)]}
target.write_text(json.dumps(result,indent=2)+'\n');print(str(target),len(paths),digest(target))
