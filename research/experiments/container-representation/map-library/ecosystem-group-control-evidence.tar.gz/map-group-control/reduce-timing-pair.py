"""Independent scalar-CSV reduction for the registered Map pair. Consumes all
rows; does not execute measured programs, select samples, or change criteria.
Owned by this one-shot experiment; remove after evidence is published/retired.
"""
from pathlib import Path
import collections,csv,hashlib,itertools,json,statistics,subprocess
S=Path('/private/tmp/whitefoot-map-group-control-7abd6bb');T=S/'timing';B=S/'correctness'
WF='whitefoot-hash-map';PEERS=['rust-hash-map','cpp-unordered-map','absl-flat-hash-map','c-sparse-direct']
FIELDS=['series','element_bytes','path','requested_capacity','count']
HEADER='contract,cohort,series,element_bytes,path,requested_capacity,count,hash,variant,sample,rounds,traces,elapsed_ns,checksum'
plan=json.loads((S/'timing-plan.json').read_text());allrows={};groups={};checksums={};identities=[]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write_csv(path,rows):
    assert rows and not path.exists(),str(path)
    with path.open('w') as out:
        writer=csv.DictWriter(out,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
def cell_key(r):return tuple(r[k] for k in FIELDS)
def values(protocol,arm,key,cohort,variant):return groups[(protocol,arm,key,cohort,variant)]
def stats(v):return {'minimum':min(v),'median':statistics.median(v),'maximum':max(v)}
def comparison(a,b):
    # a/b; each list contains one group in each cohort. Keep the cohorts.
    sa=[stats(x) for x in a];sb=[stats(x) for x in b]
    ratios=[sa[c]['median']/sb[c]['median'] for c in [0,1]]
    minimum=min(*(x['minimum'] for x in sa),*(x['minimum'] for x in sb))
    spread=max(ratios)/min(ratios)-1
    upper=[sa[c]['maximum']/sb[c]['minimum'] for c in [0,1]]
    lower=[sa[c]['minimum']/sb[c]['maximum'] for c in [0,1]]
    strict='gain' if all(x<1 for x in upper) else 'loss' if all(x>1 for x in lower) else 'overlap'
    reasons=[]
    if minimum<1000000:reasons.append('short')
    if spread>0.10:reasons.append('unstable')
    result={'ratio_0':ratios[0],'ratio_1':ratios[1],'lower_0':lower[0],'upper_0':upper[0],'lower_1':lower[1],'upper_1':upper[1],'minimum_sample_ns':minimum,'cohort_ratio_spread_pct':100*spread,'raw_range_status':strict,'qualification':';'.join(reasons) or 'qualified','status':strict if not reasons else 'inconclusive','median_direction':'lower' if all(x<1 for x in ratios) else 'higher' if all(x>1 for x in ratios) else 'mixed'}
    for c in [0,1]:
        for side,summary in [('numerator',sa[c]),('denominator',sb[c])]:
            for name,value in summary.items():result[f'{side}_{name}_{c}']=value
    return result

for protocol in ['measure','occupancy-measure']:
 for arm in ['baseline','candidate']:
  collected=[]
  for cohort in [0,1]:
   path=T/f'{protocol}-{cohort}-{arm}.csv';raw=path.read_text();assert raw.splitlines()[0]==HEADER
   rows=list(csv.DictReader(raw.splitlines()));assert len(rows)==(4620 if protocol=='measure' else 1760)
   seen=set();samples=collections.defaultdict(dict)
   for r in rows:
    assert r['cohort']==str(cohort)
    assert r['contract']==('normal' if protocol=='measure' else 'capacity-sweep')
    key=cell_key(r); sample=int(r['sample']);assert 0<=sample<=10
    full=(key,r['variant'],sample);assert full not in seen;seen.add(full)
    count=int(r['count']);repeats=max(1,1048576//count)
    rounds=0 if r['path']=='fill-free' else 1 if r['path']=='reserve-more-entries' else repeats
    traces=repeats if r['path'] in ['fill-free','reserve-more-entries'] else 1
    assert int(r['rounds'])==rounds and int(r['traces'])==traces
    semantic=(r['element_bytes'],r['path'],r['requested_capacity'],r['count'],sample)
    if semantic in checksums:assert checksums[semantic]==r['checksum']
    else:checksums[semantic]=r['checksum']
    samples[(key,r['variant'])][sample]=int(r['elapsed_ns'])
   for (key,variant),sample_values in samples.items():
    assert sorted(sample_values)==list(range(11));groups[(protocol,arm,key,cohort,variant)]=[sample_values[i] for i in range(11)]
   collected+=rows
  # Explicit driver matrix, independent of groups discovered above.
  caps_counts=[('3','2'),('64','56'),('4096','3584')] if protocol=='measure' else [(str(c),'3584') for c in [4096,5120,6144,8192]]
  paths=['hit','miss','replace-old-value','remove-churn','edit-first-word','fill-free','reserve-more-entries'] if protocol=='measure' else ['hit','miss','replace-old-value','edit-first-word']
  series=['native-default','aligned-hash'] if protocol=='measure' else ['aligned-hash']
  expected={(se,width,path,cap,count) for se,width,path,(cap,count) in itertools.product(series,['8','256'],paths,caps_counts)}
  actual={cell_key(r) for r in collected};assert actual==expected
  for key,cohort,variant in itertools.product(expected,[0,1],[WF,*PEERS]):assert (protocol,arm,key,cohort,variant) in groups
  allrows[(protocol,arm)]=collected
  combined=T/f'{protocol}-{arm}-samples.csv';write_csv(combined,collected)
  identities.append({'path':str(combined),'rows':len(collected),'sha256':digest(combined)})
# Occupancy account uses the same work and seed101 as timed sample0.
for arm in ['baseline','candidate']:
 for r in csv.DictReader((B/f'{arm}-occupancy-account.csv').open()):
  semantic=(r['element_bytes'],r['path'],r['requested_capacity'],r['count'],0)
  assert checksums[semantic]==r['checksum']

paired=[];native_drift=[];peer_comparisons=[];memory=[];sensitivity=[]
for protocol in ['measure','occupancy-measure']:
 keys=sorted({cell_key(r) for r in allrows[(protocol,'baseline')]})
 for key in keys:
  meta={'protocol':protocol,**dict(zip(FIELDS,key))}
  drifts=[]
  for peer in PEERS:
   c=comparison([values(protocol,'candidate',key,i,peer) for i in [0,1]],[values(protocol,'baseline',key,i,peer) for i in [0,1]])
   for cohort in [0,1]:drifts.append(max(c[f'ratio_{cohort}'],1/c[f'ratio_{cohort}'])-1)
   native_drift.append({**meta,'peer':peer,**c})
  c=comparison([values(protocol,'candidate',key,i,WF) for i in [0,1]],[values(protocol,'baseline',key,i,WF) for i in [0,1]])
  c['maximum_interimage_peer_drift_pct']=100*max(drifts)
  if max(drifts)>0.10:
   c['qualification']=('' if c['qualification']=='qualified' else c['qualification']+';')+'peer-drift'
   c['status']='inconclusive'
  paired.append({**meta,**c})
  for arm,peer in itertools.product(['baseline','candidate'],PEERS):
   c=comparison([values(protocol,arm,key,i,WF) for i in [0,1]],[values(protocol,arm,key,i,peer) for i in [0,1]])
   peer_comparisons.append({**meta,'arm':arm,'peer':peer,**c})

pairs=json.loads((B/'fresh-ledger-memory-summary.json').read_text())
for arm in ['baseline','candidate']:
 for pair in pairs[arm]['fresh_memory_pairs']:
  for path in ['hit','miss','replace-old-value','edit-first-word']:
   wfkey=('aligned-hash',str(pair['element_bytes']),path,str(pair['wf_request']),'3584')
   peerkey=('aligned-hash',str(pair['element_bytes']),path,str(pair['native_request']),'3584')
   c=comparison([values('occupancy-measure',arm,wfkey,i,WF) for i in [0,1]],[values('occupancy-measure',arm,peerkey,i,pair['peer']) for i in [0,1]])
   memory.append({'arm':arm,'path':path,**pair,**c})
 for width,path,capacity in itertools.product(['8','256'],['hit','miss','replace-old-value','edit-first-word'],['5120','6144','8192']):
  key=('aligned-hash',width,path,capacity,'3584');base=('aligned-hash',width,path,'4096','3584')
  c=comparison([values('occupancy-measure',arm,key,i,WF) for i in [0,1]],[values('occupancy-measure',arm,base,i,WF) for i in [0,1]])
  sensitivity.append({'arm':arm,'element_bytes':width,'path':path,'numerator_capacity':capacity,'denominator_capacity':'4096',**c})
for name,rows in [('paired',paired),('native-drift',native_drift),('peer-comparisons',peer_comparisons),('memory-comparisons',memory),('capacity-sensitivity',sensitivity)]:
 path=T/f'{name}.csv';write_csv(path,rows);identities.append({'path':str(path),'rows':len(rows),'sha256':digest(path)})
summary={'qualification':'Complete registered matrix, exactsampleIDs/work, cross-arm/peer/cohort checksum agreement, and all160 occupancy-account seed101 outcomes verified. No samples removed.','rows':sum(len(r) for r in allrows.values()),'artifacts':identities,'paired_status_counts':dict(collections.Counter(r['status'] for r in paired)),'paired_by_protocol':{p:dict(collections.Counter(r['status'] for r in paired if r['protocol']==p)) for p in ['measure','occupancy-measure']},'qualified_losses':[r for r in paired if r['status']=='loss'],'qualified_gains':[r for r in paired if r['status']=='gain'],'unqualified_raw_losses':[r for r in paired if r['raw_range_status']=='loss' and r['status']=='inconclusive'],'adverse_both_medians':[r for r in paired if r['median_direction']=='higher'],'minimum_sample_ns':min(int(r['elapsed_ns']) for rows in allrows.values() for r in rows),'timing_stages':[json.loads(line) for line in (T/'stages.jsonl').read_text().splitlines()]}
p=T/'summary.json';assert not p.exists();p.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['rows','paired_status_counts','paired_by_protocol','minimum_sample_ns']},indent=2));print('summary',digest(p))
