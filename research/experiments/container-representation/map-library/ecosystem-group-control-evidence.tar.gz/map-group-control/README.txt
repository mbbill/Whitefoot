Frozen evidence for the rejected ordinary group-control HashMap trial.
Owner: map-library/RESULTS.md, "Ordinary group-control comparison".
No production/compiler policy was selected. All eight raw timing files,
116 primary pair cells, 464 native-drift cells, 928 peer comparisons, 48 fresh
memory comparisons, 48 capacity-sensitivity rows and both 84-cell target
reports are retained. Each original row is kept; combined CSVs can be rebuilt
by the retained reducer without executing any measured program.

Source pin: 7abd6bb34746b7b983b83103c68ee429b24859bb.
Frozen CLI SHA256: 5753999f224f89a9a99e0399b76bfd7b92cd53d5f22b0d204df4f2ec3ffbc20b.
The exact commands/direct exits/wall costs are in stages.jsonl,
correctness/commands.jsonl and timing/stages.jsonl. Construction, correctness,
allocation accounting and timing are separate stages. runtime-observations
keeps independent oracle outcomes and fault diagnostics; the allocation
ledgers are instrumented observations, not timed allocation traffic.

The portable group-controls-replay-zero-context.patch applies to the two exact
pinned lib/std/collections/hash_map files with
`git apply --unidiff-zero --directory=lib/std/collections PATCH`. Its forward
application reproduced all three measured files byte for byte; reverse
application restored the exact two-file baseline. See
publication-zero-context-replay.json. The original measured group-controls.patch
and its SHA256 remain unchanged in this archive; publication-replay.json records
its earlier ordinary-context application. The portable rendering changes no
source hunk content and is separate from that measured patch identity. Baseline/candidate
carrier sources retain the exact four ABI bodies and a cold entry wrapper.
Raw and native qualification records include every original implementation
body under an explicit symbol/type bijection. No missing function was ignored.

Identity/command/prose metadata use portable transcription tokens:
${MAP_TRIAL}: this extracted experiment directory.
${OCCUPANCY_BASELINE}: the retained original pinned occupancy construction.
${WORKTREE}: the research/container-ecosystem-baselines checkout.
${ABSEIL_PREFIX}: the exact recovered 20260817.0 installation.
${USER_HOME}: the original machine's personal home prefix.
These tokens describe paths; they do not modify any measured input, row,
hash, command argument meaning or raw scratch evidence. The index records
raw and published hashes separately when path transcription changes bytes.
The retained one-shot source callers still use their original scratch paths;
map them explicitly if reconstructing elsewhere. They are evidence, not a
maintained new build interface. Native objects/images and full toolchain
binaries are identified by hash, not bundled. Reuse/reconstruction must
preserve the native controls and use the project's shared heavy guard.

Source/runtime arithmetic and correctness already passed. Reconstruction is
not an authorization to rerun timing, select cells, change the criterion or
adopt the representation. The pending amendment proposes refusal. Earlier
ceil/proof/graph-pruning/source-authoring failures remain in raw scratch;
the rejected ceil patch, source identities and original diagnostic logs are
included so successful admission is not portrayed as the first attempt.
