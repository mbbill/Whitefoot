"""One-shot exact raw-IR graph comparison for the ordinary module carrier.

The existing map experiment owns this qualification; remove this scratch
helper with preparation. It compares instruction text, attributes, types and
call targets, admitting only an explicit bijective nominal/symbol renaming.
The extra selected-entry wrapper is excluded only as cold harness plumbing;
the original fixture main must still match exactly. No LLVM is transformed
for compilation by this helper.
"""
from collections import deque
from pathlib import Path
import difflib
import hashlib
import json
import re
import sys

old_path, new_path, output_path = map(Path, sys.argv[1:])
old, new = old_path.read_text(), new_path.read_text()
symbol = re.compile(r"@[A-Za-z0-9_.$-]+")
type_token = re.compile(r"%wf\.t\.[0-9a-f]+")
function = re.compile(r"^define [^\n]+\{\n.*?^\}\n", re.M | re.S)
type_def = re.compile(r"^(%wf\.t\.[0-9a-f]+) = type (.*)$", re.M)


def definitions(text):
    return {symbol.search(body).group(): body for body in function.findall(text)}


def namespace(name):
    return name.replace("@wf_std.collections.hash_map.", "@wf_hash_map.")


def family(name):
    return re.sub(r"\$instance\$[0-9a-f]+", "$instance$ID", namespace(name))


before, after = definitions(old), definitions(new)
old_types, new_types = type_def.findall(old), type_def.findall(new)
assert len(old_types) == len(new_types), "type count changed"
types = dict(zip((name for name, _ in old_types), (name for name, _ in new_types)))
assert len(set(types.values())) == len(types), "type renaming is not bijective"
for (name, body), (_, other) in zip(old_types, new_types):
    assert type_token.sub(lambda m: types[m.group()], body) == other, (name, body, other)

# The C driver supplies main and never enters this renamed fixture plumbing.
# Original wf_main remains an ordinary exact-comparison root.
plumbing = {"@main", "@wf__floor_run", "@wf__main_body"}
extra = {"@wf_carrier_main"}
names, inverse, pending, visited = {}, {}, deque(), set()


def pair(left, right):
    assert family(left) == family(right), ("unrelated function rename", left, right)
    assert names.get(left, right) == right, ("inconsistent rename", left, right, names[left])
    assert inverse.get(right, left) == left, ("non-bijective rename", left, right, inverse[right])
    if left in names:
        return
    names[left], inverse[right] = right, left
    if left in before:
        assert right in after, ("missing definition", left, right)
        if left not in plumbing:
            pending.append((left, right))
    else:
        assert left == right, ("external symbol changed", left, right)


for name in before:
    if name in plumbing:
        continue
    matched = namespace(name)
    if matched in after:
        pair(name, matched)

while pending:
    left, right = pending.popleft()
    if left in visited:
        continue
    first = type_token.sub(lambda m: types[m.group()], before[left])
    second = after[right]
    first_shape, second_shape = symbol.sub("@SYMBOL", first), symbol.sub("@SYMBOL", second)
    if first_shape != second_shape:
        print("".join(difflib.unified_diff(first_shape.splitlines(True), second_shape.splitlines(True),
                                         fromfile=left, tofile=right)))
        raise SystemExit("IR instruction/attribute difference")
    for lhs, rhs in zip(symbol.findall(first), symbol.findall(second)):
        pair(lhs, rhs)
    visited.add(left)

assert visited == set(before) - plumbing, ("unqualified original definitions", sorted(set(before) - plumbing - visited))
assert set(after) - set(inverse) == plumbing | extra, ("unexpected carrier definitions", sorted(set(after) - set(inverse)))
for name in ("word_trace", "record_trace", "word_geometry", "record_geometry"):
    assert "@wf_map_cost_library_" + name in visited, name

def nonfunctions(text):
    # Definition order and nominal names are not semantic instruction changes.
    remaining = function.sub("", text)
    return sorted(line for line in remaining.splitlines() if line.strip())

renamed_old = symbol.sub(lambda m: names.get(m.group(), m.group()),
                        type_token.sub(lambda m: types[m.group()], old))
old_remainder, new_remainder = set(nonfunctions(renamed_old)), set(nonfunctions(new))
omitted_declarations = sorted(old_remainder - new_remainder)
assert not new_remainder - old_remainder, "unexpected module declarations/attributes/globals"
for declaration in omitted_declarations:
    assert declaration.startswith("declare "), ("missing non-declaration", declaration)
    name = symbol.search(declaration).group()
    assert symbol.findall(renamed_old).count(name) == 1, ("missing used declaration", name)
    assert name not in names.values(), ("missing call target", name)

assert not output_path.exists(), "refuse to overwrite qualification"
report = {
    "original": {"path": str(old_path), "sha256": hashlib.sha256(old_path.read_bytes()).hexdigest()},
    "carrier": {"path": str(new_path), "sha256": hashlib.sha256(new_path.read_bytes()).hexdigest()},
    "qualified_definitions": len(visited),
    "qualified_types": len(types),
    "omitted_unreferenced_external_declarations": omitted_declarations,
    "excluded_entry_plumbing": sorted(plumbing),
    "extra_cold_carrier_wrapper": sorted(extra),
    "type_renaming": types,
    "symbol_renaming": names,
    "qualification": "Exact raw instruction/type/attribute/call graph equality under this bijection; native O3 qualification remains separate."
}
output_path.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({k: report[k] for k in ("qualified_definitions", "qualified_types", "qualification")}))
