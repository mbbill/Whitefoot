"""One-shot caller for the preregistered Map group-control pair. No replay path.
Keep with the scratch experiment until results are retained or the trial ends.
Invoke only after root review, through the shared heavy guard.
"""
from pathlib import Path
from datetime import datetime, timezone
import collections,csv,hashlib,json,subprocess,time
S=Path('/private/tmp/whitefoot-map-group-control-7abd6bb');B=S/'correctness';T=S/'timing';R=Path('/private/tmp/whitefoot-container-library-complete')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(path,value):
    with path.open('x') as out:json.dump(value,out,indent=2);out.write('\n')
registration=json.loads((S/'timing/registration.json').read_text())
assert digest(S/'timing-plan.json')==registration['plan_sha256']
assert digest(Path(__file__))==registration['runner_sha256']
plan=json.loads((S/'timing-plan.json').read_text())
assert digest(B/'runtime-complete-report.json')==plan['runtime_report_sha256']
assert digest(B/'fresh-ledger-memory-summary.json')==plan['memory_pairs_manifest_sha256']
report=json.loads((B/'runtime-complete-report.json').read_text())
frozen=json.loads((B/'owner-before-inputs.json').read_text())
assert not (T/'stages.jsonl').exists()
for command in plan['commands']:
    assert not Path(command['stdout']).exists() and not Path(command['stderr']).exists()
def verify():
    members=frozen['files']+report['generated_artifacts']
    for entry in members:
        assert digest(Path(entry['path']))==entry['sha256'],entry['path']
    return {'utc':datetime.now(timezone.utc).isoformat(),'observed_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'verified_entries':len(members),'all_unchanged':True,'timing_plan_sha256':digest(S/'timing-plan.json'),'runner_sha256':digest(Path(__file__))}
save(T/'before.json',verify())
for command in plan['commands']:
    before=time.monotonic();started=datetime.now(timezone.utc).isoformat()
    with Path(command['stdout']).open('xb') as out,Path(command['stderr']).open('xb') as err:
        result=subprocess.run(command['argv'],cwd=R,stdout=out,stderr=err)
    record={**command,'started_utc':started,'ended_utc':datetime.now(timezone.utc).isoformat(),'wall_seconds':time.monotonic()-before,'direct_exit':result.returncode,'stdout_sha256':digest(Path(command['stdout'])),'stderr_sha256':digest(Path(command['stderr']))}
    with (T/'stages.jsonl').open('a') as out:out.write(json.dumps(record)+'\n')
    print(json.dumps({k:record[k] for k in ['label','wall_seconds','direct_exit','stdout_sha256']}),flush=True)
    assert result.returncode==command['expected_direct_exit']
    assert Path(command['stderr']).read_bytes()==b''
    rows=list(csv.DictReader(Path(command['stdout']).open()))
    assert len(rows)==command['expected_rows']
    groups=collections.defaultdict(list)
    for row in rows:
        assert int(row['elapsed_ns'])>0
        assert row['cohort']==command['argv'][2]
        key=tuple((k,v) for k,v in row.items() if k not in ['sample','elapsed_ns','checksum'])
        groups[key].append(int(row['sample']))
    assert all(sorted(samples)==list(range(11)) for samples in groups.values())
    print(command['label']+': complete eleven-sample groups verified',flush=True)
save(T/'after.json',verify())
print('All eight registered measurements finished once; frozen inputs/artifacts unchanged.',flush=True)
