/* Proposed scratch account-only extension, not yet compiled or executed.
 * Owned by the ordinary group-control experiment; delete with preparation.
 * This consumes only harness inputs and the independently stated storage
 * extents. It must never select baseline, C, Rust, C++ or Abseil variants.
 * Ledger field order: requests, releases, bytes, live, peak.
 */
static uint64_t candidate_metadata_bytes(uint64_t capacity) {
    return capacity > 8 ? 8 + 8 * (capacity / 8) : 0;
}

static uint64_t candidate_requests(uint64_t capacity) {
    return 1 + (capacity > 8);
}

static uint64_t candidate_backing_bytes(bool wide, uint64_t capacity) {
    /* Same scalar/wide enum-slot layout as frozen source C; the extra
     * Array contains complete u64 words and an eight-byte length header. */
    return 16 + capacity * (wide ? 272 : 24)
        + candidate_metadata_bytes(capacity);
}

static Ledger candidate_expected_trace(bool wide, uint64_t requested,
                                       uint64_t rounds, unsigned path) {
    uint64_t capacity = path == POLICY ? 3 : requested;
    uint64_t requests = candidate_requests(capacity);
    uint64_t bytes = candidate_backing_bytes(wide, capacity);
    Ledger expected = {requests, requests, bytes, 0, bytes};
    if ((path == GROW || path == RESERVE_CHECK) && rounds != 0) {
        /* The first round reserves T. Later rounds repeat the same input
         * floor, so only that first successful transition allocates. */
        uint64_t target = capacity ? 2 * capacity : 1;
        uint64_t next_requests = candidate_requests(target);
        uint64_t next_bytes = candidate_backing_bytes(wide, target);
        expected.requests += next_requests;
        expected.releases += next_requests;
        expected.bytes += next_bytes;
        expected.peak += next_bytes;
    } else if (path == REHASH && rounds != 0 && capacity != 0) {
        /* Every positive-capacity rebuild owns old+new until migration.
         * Zero-capacity rebuild is the unchanged allocation-free path. */
        expected.requests += rounds * requests;
        expected.releases += rounds * requests;
        expected.bytes += rounds * bytes;
        expected.peak += bytes;
    }
    return expected;
}

static Ledger candidate_expected_batch(bool wide, uint64_t capacity,
                                       uint64_t rounds, unsigned path,
                                       uint64_t traces) {
    Ledger expected = candidate_expected_trace(wide, capacity, rounds, path);
    expected.requests *= traces;
    expected.releases *= traces;
    expected.bytes *= traces;
    /* Consecutive complete traces do not overlap backing lifetimes. */
    return expected;
}

static void candidate_check_exact_ledger(Ledger actual, Ledger expected) {
    require(actual.requests == expected.requests
            && actual.releases == expected.releases
            && actual.bytes == expected.bytes
            && actual.live == expected.live
            && actual.peak == expected.peak,
            "group-control exact backing counts, bytes, peak and cleanup");
}

/* Proposed call sites under an explicit candidate representation mode:
 * - checked_trace, account, occupancy_account: WF variants only;
 * - read_geometry: candidate WF only, Q(C) replaces its one-request check,
 *   exact E(C) bytes/peak also checked; existing decoded slot/count witness
 *   and diagnostic/trace consistency remain unchanged;
 * - negative-metadata-bytes: on scalar C=9 trace, the second allocation's
 *   observer extent is deliberately eight bytes too large;
 * - negative-metadata-release: on the same trace, suppress only the second
 *   allocation's recorded release. Both must fail, preserving raw logs.
 * The latter are observer fault controls, not changes to the WF algorithm
 * or evidence of timed allocator traffic. Timed controls remain frozen.
 */
