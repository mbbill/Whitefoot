"""One-shot arithmetic/model witness for the admitted metadata representation.

The byte-list and modulo-order oracles do not invoke or validate WF code.
Retire this scratch helper with the experiment's preparation.
"""
import json

LIMIT = (1 << 64) - 1
EMPTY = 0x8080808080808080
BOUNDARIES = (0, 1, 7, 8, 9, 15, 16, 17)


def spans(capacity, home):
    cursor = home
    remaining = capacity
    while remaining:
        span = min(8 - cursor % 8, capacity - cursor, remaining)
        assert span > 0
        yield cursor, span
        remaining -= span
        cursor += span
        if cursor == capacity:
            cursor = 0


orders = 0
for capacity in range(66):
    for home in range(capacity):
        observed = [i for start, span in spans(capacity, home)
                    for i in range(start, start + span)]
        expected = [(home + step) % capacity for step in range(capacity)]
        assert observed == expected
        orders += 1

updates = 0
for capacity in BOUNDARIES:
    heap = [EMPTY] * (capacity // 8) if capacity > 8 else []
    tail = EMPTY
    expected = [128] * capacity
    for index in range(capacity):
        for code in range(256):
            group, lane = divmod(index, 8)
            keep = LIMIT ^ (255 << (lane * 8))
            if heap and group < len(heap):
                heap[group] = (heap[group] & keep) | (code << (lane * 8))
            else:
                assert (not heap and group == 0) or group == len(heap)
                tail = (tail & keep) | (code << (lane * 8))
            expected[index] = code
            decoded = []
            for selected in range(capacity):
                selected_group, selected_lane = divmod(selected, 8)
                word = heap[selected_group] if heap and selected_group < len(heap) else tail
                decoded.append((word >> (selected_lane * 8)) & 255)
            assert decoded == expected
            updates += 1

maxima = []
for capacity in (*BOUNDARIES, LIMIT - 8, LIMIT - 7, LIMIT - 1, LIMIT):
    groups, partial = divmod(capacity, 8)
    assert groups <= LIMIT // 8
    assert 8 * groups + partial == capacity and 0 <= partial < 8
    assert 8 * groups <= LIMIT
    # At large arithmetic boundaries, check mapping without allocating or
    # pretending to execute a capacity-sized probe sequence.
    indices = {0, 1, 7, 8, capacity // 2, max(0, capacity - 8), max(0, capacity - 1)}
    for index in sorted(i for i in indices if i < capacity):
        group, lane = divmod(index, 8)
        if capacity <= 8:
            assert group == 0 and lane < capacity
        else:
            assert group < groups or (group == groups and lane < partial)
    maxima.append({"capacity": capacity, "complete_words": groups,
                   "tail_lanes": partial, "heap_words": groups if capacity > 8 else 0})

assert (LIMIT + 7) // 8 == LIMIT // 8 + 1  # Retained ceil-array refusal.
assert [i for start, span in spans(9, 8) for i in range(start, start + span)] != list(range(9))
assert (9 // 8, 8 // 8, 8 % 8) == (1, 1, 0)  # Tail is a real distinct group.
print(json.dumps({"cyclic_orders": orders, "byte_list_updates": updates,
                  "arithmetic_boundaries": maxima}, indent=2))
