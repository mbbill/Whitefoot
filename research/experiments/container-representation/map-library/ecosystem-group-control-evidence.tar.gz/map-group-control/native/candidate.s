	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function wf_resource_record_abort
l_wf_resource_record_abort:             ; @wf_resource_record_abort
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
Lloh0:
	adrp	x19, l_.wf_resource.heap@PAGE
Lloh1:
	add	x19, x19, l_.wf_resource.heap@PAGEOFF
	mov	w20, #20                        ; =0x14
	mov	w0, #2                          ; =0x2
	mov	x1, x19
	mov	x2, x20
	bl	_write
	tbz	x0, #63, LBB0_3
LBB0_1:                                 ; %error.i
                                        ; =>This Inner Loop Header: Depth=1
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #4
	b.ne	LBB0_6
; %bb.2:                                ; %write.i
                                        ;   in Loop: Header=BB0_1 Depth=1
	mov	w0, #2                          ; =0x2
	mov	x1, x19
	mov	x2, x20
	bl	_write
	tbnz	x0, #63, LBB0_1
LBB0_3:                                 ; %wf_resource_write.exit
                                        ; =>This Inner Loop Header: Depth=1
	subs	x20, x20, x0
	b.eq	LBB0_6
; %bb.4:                                ; %wf_resource_write.exit
                                        ;   in Loop: Header=BB0_3 Depth=1
	cbz	x0, LBB0_6
; %bb.5:                                ; %write.more
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x19, x19, x0
	mov	w0, #2                          ; =0x2
	mov	x1, x19
	mov	x2, x20
	bl	_write
	tbnz	x0, #63, LBB0_1
	b	LBB0_3
LBB0_6:                                 ; %abort
	bl	_abort
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_resource_abort
l_wf_resource_abort:                    ; @wf_resource_abort
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	l_wf_resource_record_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_control_fingerprint ; -- Begin function wf_hash_map.hash_map_control_fingerprint
	.p2align	2
_wf_hash_map.hash_map_control_fingerprint: ; @wf_hash_map.hash_map_control_fingerprint
; %bb.0:                                ; %entry
	lsr	x0, x0, #57
	ret
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_control_word ; -- Begin function wf_hash_map.hash_map_control_word
	.p2align	2
_wf_hash_map.hash_map_control_word:     ; @wf_hash_map.hash_map_control_word
; %bb.0:                                ; %entry
	ldr	x8, [x0, #8]
	cbz	x8, LBB3_3
; %bb.1:                                ; %bb3
	ldr	x8, [x0, #16]
	ldr	x9, [x8]
	cmp	x1, x9
	b.hs	LBB3_4
; %bb.2:                                ; %bb8
	add	x8, x8, x1, lsl #3
	ldr	x0, [x8, #8]
	ret
LBB3_3:                                 ; %bb2
	ldr	x8, [x0]
	mov	x9, #-9187201950435737472       ; =0x8080808080808080
	cmp	x1, #0
	csel	x0, x8, x9, eq
	ret
LBB3_4:                                 ; %bb9
	ldr	x8, [x0]
	mov	x9, #-9187201950435737472       ; =0x8080808080808080
	csel	x0, x8, x9, eq
	ret
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_control_set ; -- Begin function wf_hash_map.hash_map_control_set
	.p2align	2
_wf_hash_map.hash_map_control_set:      ; @wf_hash_map.hash_map_control_set
; %bb.0:                                ; %entry
	ubfiz	x8, x1, #3, #3
	mov	w9, #255                        ; =0xff
	lsl	x9, x9, x8
	mvn	x9, x9
	lsl	x8, x2, x8
	ldr	x10, [x0, #8]
	cbz	x10, LBB4_3
; %bb.1:                                ; %bb3
	lsr	x10, x1, #3
	ldr	x11, [x0, #16]
	ldr	x12, [x11]
	cmp	x10, x12
	b.hs	LBB4_6
; %bb.2:                                ; %bb8
	add	x10, x11, x10, lsl #3
	ldr	x11, [x10, #8]
	and	x9, x11, x9
	orr	x8, x9, x8
	str	x8, [x10, #8]
	mov	w0, #0                          ; =0x0
	ret
LBB4_3:                                 ; %bb2
	cmp	x1, #8
	b.hs	LBB4_5
LBB4_4:                                 ; %bb11
	ldr	x10, [x0]
	and	x9, x10, x9
	orr	x8, x9, x8
	str	x8, [x0]
LBB4_5:                                 ; %common.ret
	mov	w0, #0                          ; =0x0
	ret
LBB4_6:                                 ; %bb9
	b.eq	LBB4_4
	b	LBB4_5
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_control_equal ; -- Begin function wf_hash_map.hash_map_control_equal
	.p2align	2
_wf_hash_map.hash_map_control_equal:    ; @wf_hash_map.hash_map_control_equal
; %bb.0:                                ; %entry
	mov	x8, #72340172838076673          ; =0x101010101010101
	mul	x8, x1, x8
	eor	x8, x8, x0
	and	x9, x8, #0x7f7f7f7f7f7f7f7f
	mov	x10, #9187201950435737471       ; =0x7f7f7f7f7f7f7f7f
	add	x9, x9, x10
	orr	x8, x9, x8
	mov	x9, #-9187201950435737472       ; =0x8080808080808080
	bic	x0, x9, x8
	ret
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_control_span ; -- Begin function wf_hash_map.hash_map_control_span
	.p2align	2
_wf_hash_map.hash_map_control_span:     ; @wf_hash_map.hash_map_control_span
; %bb.0:                                ; %entry
	mov	w8, #8                          ; =0x8
	sub	x8, x8, x0
	cmp	x8, x1
	csel	x8, x8, x1, lo
	cmp	x8, x2
	csel	x0, x8, x2, lo
	ret
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_control_active ; -- Begin function wf_hash_map.hash_map_control_active
	.p2align	2
_wf_hash_map.hash_map_control_active:   ; @wf_hash_map.hash_map_control_active
; %bb.0:                                ; %entry
	lsl	w8, w1, #3
	neg	w8, w8
	mov	x9, #-9187201950435737472       ; =0x8080808080808080
	lsr	x8, x9, x8
	lsl	w9, w0, #3
	lsl	x0, x8, x9
	ret
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_control_first ; -- Begin function wf_hash_map.hash_map_control_first
	.p2align	2
_wf_hash_map.hash_map_control_first:    ; @wf_hash_map.hash_map_control_first
; %bb.0:                                ; %entry
	rbit	x8, x0
	clz	x8, x8
	lsr	x0, x8, #3
	ret
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_control_stop ; -- Begin function wf_hash_map.hash_map_control_stop
	.p2align	2
_wf_hash_map.hash_map_control_stop:     ; @wf_hash_map.hash_map_control_stop
; %bb.0:                                ; %entry
	cbz	x0, LBB9_2
; %bb.1:                                ; %bb2
	rbit	x8, x0
	clz	x8, x8
	lsr	x8, x8, #3
	subs	x8, x8, x1
	b.hs	LBB9_3
LBB9_2:                                 ; %common.ret
	mov	x0, x2
	ret
LBB9_3:                                 ; %bb5
	cmp	x8, x2
	csel	x0, x8, x2, lo
	ret
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_probe     ; -- Begin function wf_hash_map.hash_map_probe
	.p2align	2
_wf_hash_map.hash_map_probe:            ; @wf_hash_map.hash_map_probe
; %bb.0:                                ; %entry
	sub	x8, x2, x0
	cmp	x1, x8
	csneg	x8, x0, x8, lo
	add	x0, x8, x1
	ret
                                        ; -- End function
	.globl	_wf_carrier_main                ; -- Begin function wf_carrier_main
	.p2align	2
_wf_carrier_main:                       ; @wf_carrier_main
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w0, #3                          ; =0x3
	mov	w1, #2                          ; =0x2
	mov	w2, #2                          ; =0x2
	mov	w3, #17                         ; =0x11
	mov	x5, #0                          ; =0x0
	mov	w4, #7                          ; =0x7
	bl	_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd
	mov	w0, #3                          ; =0x3
	mov	w1, #2                          ; =0x2
	mov	w2, #2                          ; =0x2
	mov	w3, #17                         ; =0x11
	mov	w4, #3                          ; =0x3
	mov	w5, #1                          ; =0x1
	bl	_wf_map_cost_library_trace$instance$4250cb78d3f44027
	mov	x0, x19
	mov	w1, #0                          ; =0x0
	bl	_wf_std.process.exit_status
	mov	w0, #3                          ; =0x3
	mov	w1, #2                          ; =0x2
	mov	w2, #17                         ; =0x11
	bl	_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd
	mov	w0, #3                          ; =0x3
	mov	w1, #2                          ; =0x2
	mov	w2, #17                         ; =0x11
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_wf_map_cost_library_geometry$instance$4250cb78d3f44027
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_map_cost_mix                ; -- Begin function wf_map_cost_mix
	.p2align	2
_wf_map_cost_mix:                       ; @wf_map_cost_mix
; %bb.0:                                ; %entry
	eor	x8, x0, x0, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x0, x8, x8, lsr #31
	ret
                                        ; -- End function
	.globl	_wf_map_cost_hash               ; -- Begin function wf_map_cost_hash
	.p2align	2
_wf_map_cost_hash:                      ; @wf_map_cost_hash
; %bb.0:                                ; %entry
	ldrb	w8, [x0, #8]
	tbz	w8, #0, LBB13_2
; %bb.1:
	mov	x0, #0                          ; =0x0
	ret
LBB13_2:                                ; %bb3
	ldr	x8, [x1]
	ldr	x9, [x0]
	eor	x8, x9, x8
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x0, x8, x8, lsr #31
	ret
                                        ; -- End function
	.globl	_wf_map_cost_equal              ; -- Begin function wf_map_cost_equal
	.p2align	2
_wf_map_cost_equal:                     ; @wf_map_cost_equal
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x2]
	cmp	x8, x9
	cset	w0, eq
	ret
                                        ; -- End function
	.globl	_wf_map_cost_key                ; -- Begin function wf_map_cost_key
	.p2align	2
_wf_map_cost_key:                       ; @wf_map_cost_key
; %bb.0:                                ; %entry
	mov	w8, #1                          ; =0x1
	orr	x0, x8, x0, lsl #1
	ret
                                        ; -- End function
	.globl	_wf_map_cost_ordered            ; -- Begin function wf_map_cost_ordered
	.p2align	2
_wf_map_cost_ordered:                   ; @wf_map_cost_ordered
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	mov	w9, #131                        ; =0x83
	madd	x8, x8, x9, x1
	str	x8, [x0]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_map_cost_final              ; -- Begin function wf_map_cost_final
	.p2align	2
_wf_map_cost_final:                     ; @wf_map_cost_final
; %bb.0:                                ; %entry
	ldp	x8, x9, [x0, #8]
	add	x8, x8, x1
	eor	x10, x1, x1, lsr #30
	mov	x11, #58809                     ; =0xe5b9
	movk	x11, #7396, lsl #16
	movk	x11, #18285, lsl #32
	movk	x11, #48984, lsl #48
	mul	x10, x10, x11
	eor	x10, x10, x10, lsr #27
	mov	x11, #4587                      ; =0x11eb
	movk	x11, #4913, lsl #16
	movk	x11, #18875, lsl #32
	movk	x11, #38096, lsl #48
	mul	x10, x10, x11
	eor	x9, x9, x10, lsr #31
	eor	x9, x9, x10
	stp	x8, x9, [x0, #8]
	ldr	x8, [x0, #24]
	add	x8, x8, #1
	str	x8, [x0, #24]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_map_cost_finish             ; -- Begin function wf_map_cost_finish
	.p2align	2
_wf_map_cost_finish:                    ; @wf_map_cost_finish
; %bb.0:                                ; %entry
	ldp	x8, x9, [x0]
	ldp	x10, x11, [x0, #16]
	eor	x8, x8, x8, lsr #30
	mov	x12, #58809                     ; =0xe5b9
	movk	x12, #7396, lsl #16
	movk	x12, #18285, lsl #32
	movk	x12, #48984, lsl #48
	mul	x8, x8, x12
	eor	x8, x8, x8, lsr #27
	mov	x13, #4587                      ; =0x11eb
	movk	x13, #4913, lsl #16
	movk	x13, #18875, lsl #32
	movk	x13, #38096, lsl #48
	mul	x8, x8, x13
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x12
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x13
	eor	x12, x9, x8
	mov	x13, #31765                     ; =0x7c15
	movk	x13, #32586, lsl #16
	movk	x13, #31161, lsl #32
	movk	x13, #40503, lsl #48
	mul	x11, x11, x13
	eor	x10, x10, x11
	eor	x10, x10, x12, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	ret
                                        ; -- End function
	.globl	_wf_map_cost_word_make          ; -- Begin function wf_map_cost_word_make
	.p2align	2
_wf_map_cost_word_make:                 ; @wf_map_cost_word_make
; %bb.0:                                ; %entry
	ret
                                        ; -- End function
	.globl	_wf_map_cost_word_content       ; -- Begin function wf_map_cost_word_content
	.p2align	2
_wf_map_cost_word_content:              ; @wf_map_cost_word_content
; %bb.0:                                ; %entry
	mov	w8, #131                        ; =0x83
	madd	x0, x0, x8, x1
	ret
                                        ; -- End function
	.globl	_wf_map_cost_word_observe       ; -- Begin function wf_map_cost_word_observe
	.p2align	2
_wf_map_cost_word_observe:              ; @wf_map_cost_word_observe
; %bb.0:                                ; %entry
	ldr	x0, [x2]
	ret
                                        ; -- End function
	.globl	_wf_map_cost_word_edit          ; -- Begin function wf_map_cost_word_edit
	.p2align	2
_wf_map_cost_word_edit:                 ; @wf_map_cost_word_edit
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	add	x0, x8, #1
	str	x0, [x2]
	ret
                                        ; -- End function
	.globl	_wf_map_cost_word_consume       ; -- Begin function wf_map_cost_word_consume
	.p2align	2
_wf_map_cost_word_consume:              ; @wf_map_cost_word_consume
; %bb.0:                                ; %entry
	mov	w8, #131                        ; =0x83
	madd	x8, x1, x8, x2
	ldp	x9, x10, [x0, #8]
	add	x9, x9, x8
	eor	x8, x8, x8, lsr #30
	mov	x11, #58809                     ; =0xe5b9
	movk	x11, #7396, lsl #16
	movk	x11, #18285, lsl #32
	movk	x11, #48984, lsl #48
	mul	x8, x8, x11
	eor	x8, x8, x8, lsr #27
	mov	x11, #4587                      ; =0x11eb
	movk	x11, #4913, lsl #16
	movk	x11, #18875, lsl #32
	movk	x11, #38096, lsl #48
	mul	x8, x8, x11
	eor	x10, x10, x8, lsr #31
	eor	x8, x10, x8
	stp	x9, x8, [x0, #8]
	ldr	x8, [x0, #24]
	add	x8, x8, #1
	str	x8, [x0, #24]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_map_cost_record_make
lCPI24_0:
	.quad	1                               ; 0x1
	.quad	2                               ; 0x2
lCPI24_1:
	.quad	3                               ; 0x3
	.quad	4                               ; 0x4
lCPI24_2:
	.quad	5                               ; 0x5
	.quad	6                               ; 0x6
lCPI24_3:
	.quad	7                               ; 0x7
	.quad	8                               ; 0x8
lCPI24_4:
	.quad	9                               ; 0x9
	.quad	10                              ; 0xa
lCPI24_5:
	.quad	11                              ; 0xb
	.quad	12                              ; 0xc
lCPI24_6:
	.quad	13                              ; 0xd
	.quad	14                              ; 0xe
lCPI24_7:
	.quad	15                              ; 0xf
	.quad	16                              ; 0x10
lCPI24_8:
	.quad	17                              ; 0x11
	.quad	18                              ; 0x12
lCPI24_9:
	.quad	19                              ; 0x13
	.quad	20                              ; 0x14
lCPI24_10:
	.quad	21                              ; 0x15
	.quad	22                              ; 0x16
lCPI24_11:
	.quad	23                              ; 0x17
	.quad	24                              ; 0x18
lCPI24_12:
	.quad	25                              ; 0x19
	.quad	26                              ; 0x1a
lCPI24_13:
	.quad	27                              ; 0x1b
	.quad	28                              ; 0x1c
lCPI24_14:
	.quad	29                              ; 0x1d
	.quad	30                              ; 0x1e
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_map_cost_record_make
	.p2align	2
_wf_map_cost_record_make:               ; @wf_map_cost_record_make
; %bb.0:                                ; %entry
	dup.2d	v0, x1
Lloh2:
	adrp	x8, lCPI24_0@PAGE
Lloh3:
	ldr	q1, [x8, lCPI24_0@PAGEOFF]
Lloh4:
	adrp	x8, lCPI24_1@PAGE
Lloh5:
	ldr	q2, [x8, lCPI24_1@PAGEOFF]
	add.2d	v1, v0, v1
Lloh6:
	adrp	x8, lCPI24_2@PAGE
Lloh7:
	ldr	q3, [x8, lCPI24_2@PAGEOFF]
	add.2d	v2, v0, v2
Lloh8:
	adrp	x8, lCPI24_3@PAGE
Lloh9:
	ldr	q4, [x8, lCPI24_3@PAGEOFF]
	add.2d	v3, v0, v3
Lloh10:
	adrp	x8, lCPI24_4@PAGE
Lloh11:
	ldr	q5, [x8, lCPI24_4@PAGEOFF]
	add.2d	v4, v0, v4
Lloh12:
	adrp	x8, lCPI24_5@PAGE
Lloh13:
	ldr	q6, [x8, lCPI24_5@PAGEOFF]
	add.2d	v5, v0, v5
Lloh14:
	adrp	x8, lCPI24_6@PAGE
Lloh15:
	ldr	q7, [x8, lCPI24_6@PAGEOFF]
	add.2d	v6, v0, v6
Lloh16:
	adrp	x8, lCPI24_7@PAGE
Lloh17:
	ldr	q16, [x8, lCPI24_7@PAGEOFF]
	add.2d	v7, v0, v7
Lloh18:
	adrp	x8, lCPI24_8@PAGE
Lloh19:
	ldr	q17, [x8, lCPI24_8@PAGEOFF]
	add.2d	v16, v0, v16
Lloh20:
	adrp	x8, lCPI24_9@PAGE
Lloh21:
	ldr	q18, [x8, lCPI24_9@PAGEOFF]
	add.2d	v17, v0, v17
Lloh22:
	adrp	x8, lCPI24_10@PAGE
Lloh23:
	ldr	q19, [x8, lCPI24_10@PAGEOFF]
	add.2d	v18, v0, v18
Lloh24:
	adrp	x8, lCPI24_11@PAGE
Lloh25:
	ldr	q20, [x8, lCPI24_11@PAGEOFF]
	add.2d	v19, v0, v19
Lloh26:
	adrp	x8, lCPI24_12@PAGE
Lloh27:
	ldr	q21, [x8, lCPI24_12@PAGEOFF]
	add.2d	v20, v0, v20
Lloh28:
	adrp	x8, lCPI24_13@PAGE
Lloh29:
	ldr	q22, [x8, lCPI24_13@PAGEOFF]
	add.2d	v21, v0, v21
Lloh30:
	adrp	x8, lCPI24_14@PAGE
Lloh31:
	ldr	q23, [x8, lCPI24_14@PAGEOFF]
	add.2d	v22, v0, v22
	add.2d	v0, v0, v23
	str	x1, [x0]
	add	x8, x1, #31
	stur	q1, [x0, #8]
	stur	q2, [x0, #24]
	stur	q3, [x0, #40]
	stur	q4, [x0, #56]
	stur	q5, [x0, #72]
	stur	q6, [x0, #88]
	stur	q7, [x0, #104]
	stur	q16, [x0, #120]
	stur	q17, [x0, #136]
	stur	q18, [x0, #152]
	stur	q19, [x0, #168]
	stur	q20, [x0, #184]
	stur	q21, [x0, #200]
	stur	q22, [x0, #216]
	stur	q0, [x0, #232]
	str	x8, [x0, #248]
	ret
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdrp	Lloh28, Lloh30
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
                                        ; -- End function
	.globl	_wf_map_cost_record_content     ; -- Begin function wf_map_cost_record_content
	.p2align	2
_wf_map_cost_record_content:            ; @wf_map_cost_record_content
; %bb.0:                                ; %entry
	ldp	x9, x10, [x1]
	mov	w8, #131                        ; =0x83
	madd	x9, x0, x8, x9
	madd	x9, x9, x8, x10
	ldp	x10, x11, [x1, #16]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #32]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #48]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #64]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #80]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #96]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #112]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #128]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #144]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #160]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #176]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #192]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #208]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #224]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #240]
	madd	x9, x9, x8, x10
	madd	x0, x9, x8, x11
	ret
                                        ; -- End function
	.globl	_wf_map_cost_record_observe     ; -- Begin function wf_map_cost_record_observe
	.p2align	2
_wf_map_cost_record_observe:            ; @wf_map_cost_record_observe
; %bb.0:                                ; %entry
	ldr	x0, [x2]
	ret
                                        ; -- End function
	.globl	_wf_map_cost_record_edit        ; -- Begin function wf_map_cost_record_edit
	.p2align	2
_wf_map_cost_record_edit:               ; @wf_map_cost_record_edit
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	add	x0, x8, #1
	str	x0, [x2]
	ret
                                        ; -- End function
	.globl	_wf_map_cost_record_consume     ; -- Begin function wf_map_cost_record_consume
	.p2align	2
_wf_map_cost_record_consume:            ; @wf_map_cost_record_consume
; %bb.0:                                ; %entry
	ldp	x9, x10, [x2]
	mov	w8, #131                        ; =0x83
	madd	x9, x1, x8, x9
	madd	x9, x9, x8, x10
	ldp	x10, x11, [x2, #16]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #32]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #48]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #64]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #80]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #96]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #112]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #128]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #144]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #160]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #176]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #192]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #208]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #224]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #240]
	madd	x9, x9, x8, x10
	madd	x8, x9, x8, x11
	ldp	x9, x10, [x0, #8]
	add	x9, x8, x9
	eor	x8, x8, x8, lsr #30
	mov	x11, #58809                     ; =0xe5b9
	movk	x11, #7396, lsl #16
	movk	x11, #18285, lsl #32
	movk	x11, #48984, lsl #48
	mul	x8, x8, x11
	eor	x8, x8, x8, lsr #27
	mov	x11, #4587                      ; =0x11eb
	movk	x11, #4913, lsl #16
	movk	x11, #18875, lsl #32
	movk	x11, #38096, lsl #48
	mul	x8, x8, x11
	eor	x10, x10, x8, lsr #31
	eor	x8, x10, x8
	stp	x9, x8, [x0, #8]
	ldr	x8, [x0, #24]
	add	x8, x8, #1
	str	x8, [x0, #24]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_map_cost_lookup_result      ; -- Begin function wf_map_cost_lookup_result
	.p2align	2
_wf_map_cost_lookup_result:             ; @wf_map_cost_lookup_result
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cbz	w8, LBB29_3
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB29_4
; %bb.2:                                ; %bb3
	ldr	x8, [x1]
	mov	w9, #131                        ; =0x83
	mul	x8, x8, x9
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
LBB29_3:                                ; %bb2
	ldr	x8, [x0, #8]
	ldr	x9, [x1]
	mov	w10, #17161                     ; =0x4309
	madd	x8, x9, x10, x8
	add	x8, x8, #131
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
LBB29_4:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_map_cost_rebuild_result     ; -- Begin function wf_map_cost_rebuild_result
	.p2align	2
_wf_map_cost_rebuild_result:            ; @wf_map_cost_rebuild_result
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cbz	w8, LBB30_3
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB30_4
; %bb.2:                                ; %bb3
	ldr	x8, [x1]
	mov	w9, #131                        ; =0x83
	mul	x8, x8, x9
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
LBB30_3:                                ; %bb2
	ldr	x8, [x1]
	mov	w9, #131                        ; =0x83
	mov	x10, #1                         ; =0x1
	madd	x8, x8, x9, x10
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
LBB30_4:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_map_cost_library_word_trace ; -- Begin function wf_map_cost_library_word_trace
	.p2align	2
_wf_map_cost_library_word_trace:        ; @wf_map_cost_library_word_trace
	.cfi_startproc
; %bb.0:                                ; %entry
	cmp	x4, #8
	b.ne	LBB31_2
; %bb.1:                                ; %bb2
	mov	x0, x3
	mov	x1, x5
	b	_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd
LBB31_2:                                ; %bb3
	b	_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_map_cost_library_record_trace ; -- Begin function wf_map_cost_library_record_trace
	.p2align	2
_wf_map_cost_library_record_trace:      ; @wf_map_cost_library_record_trace
	.cfi_startproc
; %bb.0:                                ; %entry
	cmp	x4, #8
	b.ne	LBB32_2
; %bb.1:                                ; %bb2
	mov	x0, x3
	mov	x1, x5
	b	_wf_map_cost_library_policy$instance$4250cb78d3f44027
LBB32_2:                                ; %bb3
	b	_wf_map_cost_library_trace$instance$4250cb78d3f44027
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_map_cost_library_word_geometry ; -- Begin function wf_map_cost_library_word_geometry
	.p2align	2
_wf_map_cost_library_word_geometry:     ; @wf_map_cost_library_word_geometry
	.cfi_startproc
; %bb.0:                                ; %entry
	b	_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_map_cost_library_record_geometry ; -- Begin function wf_map_cost_library_record_geometry
	.p2align	2
_wf_map_cost_library_record_geometry:   ; @wf_map_cost_library_record_geometry
	.cfi_startproc
; %bb.0:                                ; %entry
	b	_wf_map_cost_library_geometry$instance$4250cb78d3f44027
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_main                        ; -- Begin function wf_main
	.p2align	2
_wf_main:                               ; @wf_main
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w0, #3                          ; =0x3
	mov	w1, #2                          ; =0x2
	mov	w2, #2                          ; =0x2
	mov	w3, #17                         ; =0x11
	mov	x5, #0                          ; =0x0
	mov	w4, #7                          ; =0x7
	bl	_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd
	mov	w0, #3                          ; =0x3
	mov	w1, #2                          ; =0x2
	mov	w2, #2                          ; =0x2
	mov	w3, #17                         ; =0x11
	mov	w4, #3                          ; =0x3
	mov	w5, #1                          ; =0x1
	bl	_wf_map_cost_library_trace$instance$4250cb78d3f44027
	mov	x0, x19
	mov	w1, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_wf_std.process.exit_status
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_array_filled$instance$581665c886d1d2c8 ; -- Begin function wf_array_filled$instance$581665c886d1d2c8
	.p2align	2
_wf_array_filled$instance$581665c886d1d2c8: ; @"wf_array_filled$instance$581665c886d1d2c8"
; %bb.0:                                ; %entry
	dup.2d	v0, x1
	stp	q0, q0, [x0]
	stp	q0, q0, [x0, #32]
	stp	q0, q0, [x0, #64]
	stp	q0, q0, [x0, #96]
	stp	q0, q0, [x0, #128]
	stp	q0, q0, [x0, #160]
	stp	q0, q0, [x0, #192]
	stp	q0, q0, [x0, #224]
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_map_cost_library_policy$instance$c7c8cd11e7f079bd
lCPI37_0:
	.quad	0                               ; 0x0
	.quad	-9187201950435737472            ; 0x8080808080808080
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd
	.p2align	2
_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd: ; @"wf_map_cost_library_policy$instance$c7c8cd11e7f079bd"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #208
	stp	x22, x21, [sp, #160]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #176]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 208
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	mov	x20, #31765                     ; =0x7c15
	movk	x20, #32586, lsl #16
	movk	x20, #31161, lsl #32
	movk	x20, #40503, lsl #48
	eor	x8, x0, x20
	cmp	x1, #0
	cset	w9, ne
	str	x8, [sp, #72]
	strb	w9, [sp, #80]
	mov	w0, #88                         ; =0x58
	bl	_malloc
	cbz	x0, LBB37_23
; %bb.1:                                ; %bb1.i.i
	str	wzr, [x0, #16]
	stp	xzr, xzr, [x0, #72]
	stp	xzr, xzr, [x0, #24]
	str	wzr, [x0, #40]
	stp	xzr, xzr, [x0, #48]
	str	wzr, [x0, #64]
	mov	w8, #3                          ; =0x3
	dup.2d	v0, x8
	str	q0, [x0]
	stp	xzr, x0, [sp, #24]
Lloh32:
	adrp	x8, lCPI37_0@PAGE
Lloh33:
	ldr	q0, [x8, lCPI37_0@PAGEOFF]
	stur	q0, [sp, #40]
	stp	xzr, xzr, [sp, #56]
	stp	xzr, xzr, [sp, #8]
	add	x0, sp, #136
	add	x1, sp, #32
	add	x4, sp, #72
	mov	w2, #1                          ; =0x1
	mov	x3, x19
	bl	_wf_hash_map.hash_map_put$instance$c7b22b9ef52855b6
	ldr	w8, [sp, #136]
	cbz	w8, LBB37_4
; %bb.2:                                ; %bb1.i.i
	cmp	w8, #1
	b.ne	LBB37_22
; %bb.3:                                ; %bb3.i
	ldp	x9, x8, [sp, #144]
	ldrb	w10, [sp, #140]
	mov	w11, #131                       ; =0x83
	tst	w10, #0x1
	mov	w10, #1                         ; =0x1
	cinc	x10, x10, ne
	add	x9, x10, x9
	madd	x9, x19, x11, x9
	madd	x21, x9, x11, x8
	b	LBB37_5
LBB37_4:                                ; %bb2.i
	mov	w8, #131                        ; =0x83
	mul	x21, x19, x8
LBB37_5:                                ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit"
	add	x0, sp, #136
	add	x1, sp, #32
	add	x3, x19, #1
	add	x4, sp, #72
	mov	w2, #3                          ; =0x3
	bl	_wf_hash_map.hash_map_put$instance$c7b22b9ef52855b6
	ldr	w8, [sp, #136]
	cbz	w8, LBB37_8
; %bb.6:                                ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit"
	cmp	w8, #1
	b.ne	LBB37_22
; %bb.7:                                ; %bb3.i.1
	ldp	x9, x8, [sp, #144]
	ldrb	w10, [sp, #140]
	mov	w11, #131                       ; =0x83
	tst	w10, #0x1
	mov	w10, #1                         ; =0x1
	cinc	x10, x10, ne
	add	x9, x10, x9
	madd	x9, x21, x11, x9
	madd	x21, x9, x11, x8
	b	LBB37_9
LBB37_8:                                ; %bb2.i.1
	mov	w8, #131                        ; =0x83
	mul	x21, x21, x8
LBB37_9:                                ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit.1"
	add	x0, sp, #136
	add	x1, sp, #32
	add	x3, x19, #2
	add	x4, sp, #72
	mov	w2, #5                          ; =0x5
	bl	_wf_hash_map.hash_map_put$instance$c7b22b9ef52855b6
	ldr	w8, [sp, #136]
	cbz	w8, LBB37_12
; %bb.10:                               ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit.1"
	cmp	w8, #1
	b.ne	LBB37_22
; %bb.11:                               ; %bb3.i.2
	ldp	x9, x8, [sp, #144]
	ldrb	w10, [sp, #140]
	mov	w11, #131                       ; =0x83
	tst	w10, #0x1
	mov	w10, #1                         ; =0x1
	cinc	x10, x10, ne
	add	x9, x10, x9
	madd	x9, x21, x11, x9
	madd	x21, x9, x11, x8
	b	LBB37_13
LBB37_12:                               ; %bb2.i.2
	mov	w8, #131                        ; =0x83
	mul	x21, x21, x8
LBB37_13:                               ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit.2"
	add	x0, sp, #112
	add	x1, sp, #32
	add	x3, x19, #10
	add	x4, sp, #72
	mov	w2, #1                          ; =0x1
	bl	_wf_hash_map.hash_map_put$instance$c7b22b9ef52855b6
	ldr	w8, [sp, #112]
	cbz	w8, LBB37_16
; %bb.14:                               ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit.2"
	cmp	w8, #1
	b.ne	LBB37_22
; %bb.15:                               ; %bb3.i5
	ldp	x9, x8, [sp, #120]
	ldrb	w10, [sp, #116]
	mov	w11, #131                       ; =0x83
	tst	w10, #0x1
	mov	w10, #1                         ; =0x1
	cinc	x10, x10, ne
	add	x9, x10, x9
	madd	x9, x21, x11, x9
	madd	x21, x9, x11, x8
	b	LBB37_17
LBB37_16:                               ; %bb2.i19
	mov	w8, #131                        ; =0x83
	mul	x21, x21, x8
LBB37_17:                               ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit23"
	add	x0, sp, #88
	add	x1, sp, #32
	add	x3, x19, #20
	add	x4, sp, #72
	mov	w2, #7                          ; =0x7
	bl	_wf_hash_map.hash_map_put$instance$c7b22b9ef52855b6
	ldr	w8, [sp, #88]
	cbz	w8, LBB37_20
; %bb.18:                               ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit23"
	cmp	w8, #1
	b.ne	LBB37_22
; %bb.19:                               ; %bb3.i25
	ldp	x9, x8, [sp, #96]
	ldrb	w10, [sp, #92]
	mov	w11, #131                       ; =0x83
	tst	w10, #0x1
	mov	w10, #1                         ; =0x1
	cinc	x10, x10, ne
	madd	x9, x21, x11, x9
	add	x9, x9, x10
	madd	x8, x9, x11, x8
	b	LBB37_21
LBB37_20:                               ; %bb2.i39
	mov	w8, #131                        ; =0x83
	mul	x8, x21, x8
LBB37_21:                               ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit43"
	str	x8, [sp]
	add	x0, sp, #32
	mov	x1, sp
	bl	_wf_hash_map.hash_map_free$instance$5c6f40d0925a4760
	ldp	x8, x9, [sp]
	ldp	x10, x11, [sp, #16]
	eor	x8, x8, x8, lsr #30
	mov	x12, #58809                     ; =0xe5b9
	movk	x12, #7396, lsl #16
	movk	x12, #18285, lsl #32
	movk	x12, #48984, lsl #48
	mul	x8, x8, x12
	eor	x8, x8, x8, lsr #27
	mov	x13, #4587                      ; =0x11eb
	movk	x13, #4913, lsl #16
	movk	x13, #18875, lsl #32
	movk	x13, #38096, lsl #48
	mul	x8, x8, x13
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x12
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x13
	eor	x12, x9, x8
	mul	x11, x11, x20
	eor	x10, x10, x11
	eor	x10, x10, x12, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #176]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #160]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
LBB37_22:                               ; %invalid.tag.b0.i
	bl	_abort
LBB37_23:                               ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh32, Lloh33
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_map_cost_library_trace$instance$c7c8cd11e7f079bd
lCPI38_0:
	.quad	0                               ; 0x0
	.quad	-9187201950435737472            ; 0x8080808080808080
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd
	.p2align	2
_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd: ; @"wf_map_cost_library_trace$instance$c7c8cd11e7f079bd"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #688
	.cfi_def_cfa_offset 784
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x22, x4
	str	x2, [sp, #40]                   ; 8-byte Folded Spill
	str	x1, [sp, #64]                   ; 8-byte Folded Spill
	mov	x23, x0
	mov	x8, #31765                      ; =0x7c15
	movk	x8, #32586, lsl #16
	movk	x8, #31161, lsl #32
	movk	x8, #40503, lsl #48
	str	x3, [sp, #16]                   ; 8-byte Folded Spill
	eor	x8, x3, x8
	cmp	x5, #0
	cset	w9, ne
	str	x8, [sp, #528]
	strb	w9, [sp, #536]
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB38_460
; %bb.1:                                ; %bb1.i.i
	stp	xzr, x23, [x0]
	cbz	x23, LBB38_7
; %bb.2:                                ; %bb5.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
LBB38_3:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x9], #24
	cmp	x23, x8
	b.ne	LBB38_3
; %bb.4:                                ; %"wf_hash_map.hash_map_extend$instance$820b2044b97e0fbd.exit.i"
	str	x23, [x0]
	cmp	x23, #9
	b.lo	LBB38_7
; %bb.5:                                ; %bb2.i.i.i
	mov	x19, x0
	and	x25, x23, #0xfffffffffffffff8
	add	x0, x25, #8
	bl	_malloc
	cbz	x0, LBB38_460
; %bb.6:                                ; %buffer.fill.init.v2.i.i.i.i
	mov	x24, x0
	lsr	x8, x23, #3
	str	x8, [x0], #8
	mov	w1, #128                        ; =0x80
	mov	x2, x25
	bl	_memset
	mov	w8, #1                          ; =0x1
	mov	x0, x19
	b	LBB38_8
LBB38_7:
	mov	x24, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
LBB38_8:                                ; %"wf_hash_map.hash_map_new$instance$820b2044b97e0fbd.exit"
	ldr	x30, [sp, #64]                  ; 8-byte Folded Reload
Lloh34:
	adrp	x9, lCPI38_0@PAGE
Lloh35:
	ldr	q0, [x9, lCPI38_0@PAGEOFF]
	add	x27, sp, #80
	add	x9, x27, #316
	str	x9, [sp, #32]                   ; 8-byte Folded Spill
	stur	q0, [x9, #156]
	str	x0, [sp, #544]
	str	x8, [sp, #568]
	str	x24, [sp, #576]
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	str	x8, [sp, #584]
	str	xzr, [sp, #592]
	str	xzr, [sp, #608]
	str	xzr, [sp, #600]
	cbz	x30, LBB38_14
; %bb.9:                                ; %bb2.lr.ph
	add	x19, sp, #80
	mov	w20, #1                         ; =0x1
	mov	w21, #131                       ; =0x83
	mov	w24, #1                         ; =0x1
	mov	x26, x30
	ldr	x25, [sp, #16]                  ; 8-byte Folded Reload
	b	LBB38_11
LBB38_10:                               ; %bb6
                                        ;   in Loop: Header=BB38_11 Depth=1
	ldr	x8, [sp, #584]
	mul	x8, x8, x21
	ldr	x30, [sp, #64]                  ; 8-byte Folded Reload
	str	x8, [sp, #584]
	add	x25, x25, #1
	add	x24, x24, #2
	subs	x26, x26, #1
	b.eq	LBB38_14
LBB38_11:                               ; %bb2
                                        ; =>This Inner Loop Header: Depth=1
	add	x0, sp, #80
	add	x1, x27, #464
	add	x4, x27, #448
	mov	x2, x24
	mov	x3, x25
	bl	_wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad
	ldr	w8, [sp, #80]
	cbz	w8, LBB38_10
; %bb.12:                               ; %bb2
                                        ;   in Loop: Header=BB38_11 Depth=1
	cmp	w8, #1
	b.ne	LBB38_249
; %bb.13:                               ; %bb7
                                        ;   in Loop: Header=BB38_11 Depth=1
	ldrb	w8, [sp, #84]
	ldur	q0, [x19, #8]
	stur	q0, [x27, #24]
	ldr	x9, [sp, #584]
	cmp	w8, #0
	cinc	x8, x20, ne
	madd	x8, x9, x21, x8
	ldp	x9, x10, [sp, #104]
	add	x8, x9, x8
	madd	x8, x8, x21, x10
	ldr	x30, [sp, #64]                  ; 8-byte Folded Reload
	str	x8, [sp, #584]
	add	x25, x25, #1
	add	x24, x24, #2
	subs	x26, x26, #1
	b.ne	LBB38_11
LBB38_14:                               ; %bb12.preheader
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	cbz	x9, LBB38_459
; %bb.15:                               ; %bb13.lr.ph
	lsl	x9, x23, #1
	cmp	x23, #0
	csinc	x20, x9, xzr, ne
	cmp	x22, #1
	csel	x9, x30, xzr, eq
	cmp	x22, #5
	b.ne	LBB38_250
; %bb.16:                               ; %bb13.us.preheader
	mov	x22, #0                         ; =0x0
	sub	x8, x30, x30, lsr #1
	cmp	x8, #1
	csinc	x8, x8, xzr, hi
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	add	x8, x8, x30
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	mov	w23, #131                       ; =0x83
	mov	w24, #1                         ; =0x1
	mov	w26, #8                         ; =0x8
	mov	x25, #-9187201950435737472      ; =0x8080808080808080
	mov	x28, #9187201950435737471       ; =0x7f7f7f7f7f7f7f7f
	mov	w19, #24                        ; =0x18
	b	LBB38_18
LBB38_17:                               ;   in Loop: Header=BB38_18 Depth=1
	ldp	x8, x30, [sp, #56]              ; 16-byte Folded Reload
	add	x8, x8, x30
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	ldp	x8, x22, [sp, #40]              ; 16-byte Folded Reload
	cmp	x22, x8
	b.eq	LBB38_459
LBB38_18:                               ; %bb13.us
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB38_22 Depth 2
                                        ;       Child Loop BB38_27 Depth 3
                                        ;       Child Loop BB38_96 Depth 3
                                        ;     Child Loop BB38_168 Depth 2
                                        ;       Child Loop BB38_172 Depth 3
                                        ;     Child Loop BB38_233 Depth 2
	cbz	x30, LBB38_159
; %bb.19:                               ; %bb20.lr.ph.us
                                        ;   in Loop: Header=BB38_18 Depth=1
	str	x22, [sp, #48]                  ; 8-byte Folded Spill
	mov	x8, #0                          ; =0x0
	ldr	x9, [sp, #552]
	ldr	x10, [sp, #568]
	ldr	x11, [sp, #576]
	add	x30, sp, #80
	b	LBB38_22
LBB38_20:                               ; %bb22.i.i561.us
                                        ;   in Loop: Header=BB38_22 Depth=2
	cbnz	w22, LBB38_249
LBB38_21:                               ; %bb3.i67.us
                                        ;   in Loop: Header=BB38_22 Depth=2
	str	w24, [sp, #160]
	str	xzr, [sp, #168]
	mul	x12, x12, x23
	strb	wzr, [sp, #176]
	str	x12, [sp, #584]
	add	x8, x8, #1
	ldr	x12, [sp, #72]                  ; 8-byte Folded Reload
	cmp	x8, x12
	b.eq	LBB38_158
LBB38_22:                               ; %bb20.us
                                        ;   Parent Loop BB38_18 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB38_27 Depth 3
                                        ;       Child Loop BB38_96 Depth 3
	orr	x12, x24, x8, lsl #2
	str	x12, [sp, #616]
	cbz	x9, LBB38_86
; %bb.23:                               ; %bb3.i.i.us
                                        ;   in Loop: Header=BB38_22 Depth=2
	ldrb	w13, [sp, #536]
	tbz	w13, #0, LBB38_25
; %bb.24:                               ;   in Loop: Header=BB38_22 Depth=2
	mov	x15, #0                         ; =0x0
	ldr	x13, [sp, #544]
	ldr	x14, [x13]
	cbnz	x14, LBB38_26
	b	LBB38_86
LBB38_25:                               ; %bb3.i.i.i436.us
                                        ;   in Loop: Header=BB38_22 Depth=2
	ldr	x13, [sp, #528]
	eor	x13, x13, x12
	eor	x13, x13, x13, lsr #30
	mov	x14, #58809                     ; =0xe5b9
	movk	x14, #7396, lsl #16
	movk	x14, #18285, lsl #32
	movk	x14, #48984, lsl #48
	mul	x13, x13, x14
	eor	x13, x13, x13, lsr #27
	mov	x14, #4587                      ; =0x11eb
	movk	x14, #4913, lsl #16
	movk	x14, #18875, lsl #32
	movk	x14, #38096, lsl #48
	mul	x13, x13, x14
	eor	x15, x13, x13, lsr #31
	ldr	x13, [sp, #544]
	ldr	x14, [x13]
	cbz	x14, LBB38_86
LBB38_26:                               ; %bb3.i.i440.us
                                        ;   in Loop: Header=BB38_22 Depth=2
	lsr	x0, x15, #57
	udiv	x16, x15, x14
	msub	x16, x16, x14, x15
	ldr	x15, [sp, #568]
	ldr	x17, [sp, #560]
	mov	x1, #72340172838076673          ; =0x101010101010101
	mul	x0, x0, x1
	ldr	x1, [sp, #576]
	mov	w2, #1                          ; =0x1
	mov	x3, x14
LBB38_27:                               ; %bb10.i.i.us
                                        ;   Parent Loop BB38_18 Depth=1
                                        ;     Parent Loop BB38_22 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	x5, x16, #0x7
	sub	x4, x14, x16
	sub	x6, x26, x5
	cmp	x6, x4
	csel	x4, x6, x4, lo
	cmp	x4, x3
	csel	x4, x4, x3, lo
	cbz	x15, LBB38_30
; %bb.28:                               ; %bb3.i21.i.i.us
                                        ;   in Loop: Header=BB38_27 Depth=3
	lsr	x6, x16, #3
	ldr	x7, [x1]
	cmp	x6, x7
	b.hs	LBB38_31
; %bb.29:                               ; %bb8.i.i.i455.us
                                        ;   in Loop: Header=BB38_27 Depth=3
	add	x6, x1, x6, lsl #3
	ldr	x7, [x6, #8]
	b	LBB38_32
LBB38_30:                               ; %bb2.i.i.i456.us
                                        ;   in Loop: Header=BB38_27 Depth=3
	cmp	x16, #8
	csel	x7, x17, x25, lo
	b	LBB38_32
LBB38_31:                               ; %bb9.i.i.i444.us
                                        ;   in Loop: Header=BB38_27 Depth=3
	csel	x7, x17, x25, eq
LBB38_32:                               ; %wf_hash_map.hash_map_control_word.exit.i.i.us
                                        ;   in Loop: Header=BB38_27 Depth=3
	lsl	x6, x4, #3
	neg	x6, x6
	lsr	x6, x25, x6
	lsl	x20, x5, #3
	lsl	x20, x6, x20
	and	x6, x7, #0x7f7f7f7f7f7f7f7f
	sub	x6, x25, x6
	and	x6, x6, x7
	and	x6, x20, x6
	cmp	x6, #0
	rbit	x6, x6
	clz	x6, x6
	lsr	x21, x6, #3
	ccmp	x21, x5, #0, ne
	mov	x6, x4
	b.hs	LBB38_34
; %bb.33:                               ; %wf_hash_map.hash_map_control_stop.exit.i.i.us
                                        ;   in Loop: Header=BB38_27 Depth=3
	eor	x7, x7, x0
	and	x21, x7, #0x7f7f7f7f7f7f7f7f
	add	x21, x21, x28
	orr	x7, x21, x7
	bic	x20, x20, x7
	cbnz	x20, LBB38_35
	b	LBB38_82
LBB38_34:                               ; %bb5.i.i.i449.us
                                        ;   in Loop: Header=BB38_27 Depth=3
	sub	x6, x21, x5
	cmp	x6, x4
	csel	x6, x6, x4, lo
	eor	x7, x7, x0
	and	x21, x7, #0x7f7f7f7f7f7f7f7f
	add	x21, x21, x28
	orr	x7, x21, x7
	bic	x20, x20, x7
	cbz	x20, LBB38_82
LBB38_35:                               ; %bb17.i.i.us
                                        ;   in Loop: Header=BB38_27 Depth=3
	rbit	x7, x20
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB38_40
; %bb.36:                               ; %bb19.i.i.us
                                        ;   in Loop: Header=BB38_27 Depth=3
	cmp	x7, x6
	b.hs	LBB38_40
; %bb.37:                               ; %bb22.i.i.us
                                        ;   in Loop: Header=BB38_27 Depth=3
	add	x7, x7, x16
	madd	x21, x7, x19, x13
	ldr	w22, [x21, #16]!
	cmp	w22, #1
	b.eq	LBB38_40
; %bb.38:                               ; %bb22.i.i.us
                                        ;   in Loop: Header=BB38_27 Depth=3
	cmp	w22, #2
	b.ne	LBB38_85
; %bb.39:                               ; %bb25.i.i.us
                                        ;   in Loop: Header=BB38_27 Depth=3
	ldr	x22, [x21, #8]
	cmp	x22, x12
	b.eq	LBB38_88
LBB38_40:                               ; %bb31.i.i.us
                                        ;   in Loop: Header=BB38_27 Depth=3
	sub	x7, x20, #1
	and	x20, x7, x20
	cbz	x20, LBB38_82
; %bb.41:                               ; %bb17.i.i.us.1
                                        ;   in Loop: Header=BB38_27 Depth=3
	rbit	x7, x20
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB38_46
; %bb.42:                               ; %bb19.i.i.us.1
                                        ;   in Loop: Header=BB38_27 Depth=3
	cmp	x7, x6
	b.hs	LBB38_46
; %bb.43:                               ; %bb22.i.i.us.1
                                        ;   in Loop: Header=BB38_27 Depth=3
	add	x7, x7, x16
	madd	x21, x7, x19, x13
	ldr	w22, [x21, #16]!
	cmp	w22, #1
	b.eq	LBB38_46
; %bb.44:                               ; %bb22.i.i.us.1
                                        ;   in Loop: Header=BB38_27 Depth=3
	cmp	w22, #2
	b.ne	LBB38_85
; %bb.45:                               ; %bb25.i.i.us.1
                                        ;   in Loop: Header=BB38_27 Depth=3
	ldr	x22, [x21, #8]
	cmp	x22, x12
	b.eq	LBB38_88
LBB38_46:                               ; %bb31.i.i.us.1
                                        ;   in Loop: Header=BB38_27 Depth=3
	sub	x7, x20, #1
	and	x20, x7, x20
	cbz	x20, LBB38_82
; %bb.47:                               ; %bb17.i.i.us.2
                                        ;   in Loop: Header=BB38_27 Depth=3
	rbit	x7, x20
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB38_52
; %bb.48:                               ; %bb19.i.i.us.2
                                        ;   in Loop: Header=BB38_27 Depth=3
	cmp	x7, x6
	b.hs	LBB38_52
; %bb.49:                               ; %bb22.i.i.us.2
                                        ;   in Loop: Header=BB38_27 Depth=3
	add	x7, x7, x16
	madd	x21, x7, x19, x13
	ldr	w22, [x21, #16]!
	cmp	w22, #1
	b.eq	LBB38_52
; %bb.50:                               ; %bb22.i.i.us.2
                                        ;   in Loop: Header=BB38_27 Depth=3
	cmp	w22, #2
	b.ne	LBB38_85
; %bb.51:                               ; %bb25.i.i.us.2
                                        ;   in Loop: Header=BB38_27 Depth=3
	ldr	x22, [x21, #8]
	cmp	x22, x12
	b.eq	LBB38_88
LBB38_52:                               ; %bb31.i.i.us.2
                                        ;   in Loop: Header=BB38_27 Depth=3
	sub	x7, x20, #1
	and	x20, x7, x20
	cbz	x20, LBB38_82
; %bb.53:                               ; %bb17.i.i.us.3
                                        ;   in Loop: Header=BB38_27 Depth=3
	rbit	x7, x20
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB38_58
; %bb.54:                               ; %bb19.i.i.us.3
                                        ;   in Loop: Header=BB38_27 Depth=3
	cmp	x7, x6
	b.hs	LBB38_58
; %bb.55:                               ; %bb22.i.i.us.3
                                        ;   in Loop: Header=BB38_27 Depth=3
	add	x7, x7, x16
	madd	x21, x7, x19, x13
	ldr	w22, [x21, #16]!
	cmp	w22, #1
	b.eq	LBB38_58
; %bb.56:                               ; %bb22.i.i.us.3
                                        ;   in Loop: Header=BB38_27 Depth=3
	cmp	w22, #2
	b.ne	LBB38_85
; %bb.57:                               ; %bb25.i.i.us.3
                                        ;   in Loop: Header=BB38_27 Depth=3
	ldr	x22, [x21, #8]
	cmp	x22, x12
	b.eq	LBB38_88
LBB38_58:                               ; %bb31.i.i.us.3
                                        ;   in Loop: Header=BB38_27 Depth=3
	sub	x7, x20, #1
	and	x20, x7, x20
	cbz	x20, LBB38_82
; %bb.59:                               ; %bb17.i.i.us.4
                                        ;   in Loop: Header=BB38_27 Depth=3
	rbit	x7, x20
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB38_64
; %bb.60:                               ; %bb19.i.i.us.4
                                        ;   in Loop: Header=BB38_27 Depth=3
	cmp	x7, x6
	b.hs	LBB38_64
; %bb.61:                               ; %bb22.i.i.us.4
                                        ;   in Loop: Header=BB38_27 Depth=3
	add	x7, x7, x16
	madd	x21, x7, x19, x13
	ldr	w22, [x21, #16]!
	cmp	w22, #1
	b.eq	LBB38_64
; %bb.62:                               ; %bb22.i.i.us.4
                                        ;   in Loop: Header=BB38_27 Depth=3
	cmp	w22, #2
	b.ne	LBB38_85
; %bb.63:                               ; %bb25.i.i.us.4
                                        ;   in Loop: Header=BB38_27 Depth=3
	ldr	x22, [x21, #8]
	cmp	x22, x12
	b.eq	LBB38_88
LBB38_64:                               ; %bb31.i.i.us.4
                                        ;   in Loop: Header=BB38_27 Depth=3
	sub	x7, x20, #1
	and	x20, x7, x20
	cbz	x20, LBB38_82
; %bb.65:                               ; %bb17.i.i.us.5
                                        ;   in Loop: Header=BB38_27 Depth=3
	rbit	x7, x20
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB38_70
; %bb.66:                               ; %bb19.i.i.us.5
                                        ;   in Loop: Header=BB38_27 Depth=3
	cmp	x7, x6
	b.hs	LBB38_70
; %bb.67:                               ; %bb22.i.i.us.5
                                        ;   in Loop: Header=BB38_27 Depth=3
	add	x7, x7, x16
	madd	x21, x7, x19, x13
	ldr	w22, [x21, #16]!
	cmp	w22, #1
	b.eq	LBB38_70
; %bb.68:                               ; %bb22.i.i.us.5
                                        ;   in Loop: Header=BB38_27 Depth=3
	cmp	w22, #2
	b.ne	LBB38_85
; %bb.69:                               ; %bb25.i.i.us.5
                                        ;   in Loop: Header=BB38_27 Depth=3
	ldr	x22, [x21, #8]
	cmp	x22, x12
	b.eq	LBB38_88
LBB38_70:                               ; %bb31.i.i.us.5
                                        ;   in Loop: Header=BB38_27 Depth=3
	sub	x7, x20, #1
	and	x20, x7, x20
	cbz	x20, LBB38_82
; %bb.71:                               ; %bb17.i.i.us.6
                                        ;   in Loop: Header=BB38_27 Depth=3
	rbit	x7, x20
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB38_76
; %bb.72:                               ; %bb19.i.i.us.6
                                        ;   in Loop: Header=BB38_27 Depth=3
	cmp	x7, x6
	b.hs	LBB38_76
; %bb.73:                               ; %bb22.i.i.us.6
                                        ;   in Loop: Header=BB38_27 Depth=3
	add	x7, x7, x16
	madd	x21, x7, x19, x13
	ldr	w22, [x21, #16]!
	cmp	w22, #1
	b.eq	LBB38_76
; %bb.74:                               ; %bb22.i.i.us.6
                                        ;   in Loop: Header=BB38_27 Depth=3
	cmp	w22, #2
	b.ne	LBB38_85
; %bb.75:                               ; %bb25.i.i.us.6
                                        ;   in Loop: Header=BB38_27 Depth=3
	ldr	x22, [x21, #8]
	cmp	x22, x12
	b.eq	LBB38_88
LBB38_76:                               ; %bb31.i.i.us.6
                                        ;   in Loop: Header=BB38_27 Depth=3
	sub	x7, x20, #1
	and	x7, x7, x20
	cbz	x7, LBB38_82
; %bb.77:                               ; %bb17.i.i.us.7
                                        ;   in Loop: Header=BB38_27 Depth=3
	rbit	x7, x7
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x5, x7, x5
	b.lo	LBB38_82
; %bb.78:                               ; %bb19.i.i.us.7
                                        ;   in Loop: Header=BB38_27 Depth=3
	cmp	x5, x6
	b.hs	LBB38_82
; %bb.79:                               ; %bb22.i.i.us.7
                                        ;   in Loop: Header=BB38_27 Depth=3
	add	x7, x5, x16
	madd	x21, x7, x19, x13
	ldr	w5, [x21, #16]!
	cmp	w5, #1
	b.eq	LBB38_82
; %bb.80:                               ; %bb22.i.i.us.7
                                        ;   in Loop: Header=BB38_27 Depth=3
	cmp	w5, #2
	b.ne	LBB38_157
; %bb.81:                               ; %bb25.i.i.us.7
                                        ;   in Loop: Header=BB38_27 Depth=3
	ldr	x5, [x21, #8]
	cmp	x5, x12
	b.eq	LBB38_88
LBB38_82:                               ; %bb14.i.i.us
                                        ;   in Loop: Header=BB38_27 Depth=3
	cmp	x6, x4
	b.lo	LBB38_86
; %bb.83:                               ; %bb34.i.i.us
                                        ;   in Loop: Header=BB38_27 Depth=3
	add	x16, x4, x16
	cmp	x16, x14
	csel	x16, x16, xzr, lo
	cmp	x2, x14
	b.hs	LBB38_86
; %bb.84:                               ; %bb34.i.i.us
                                        ;   in Loop: Header=BB38_27 Depth=3
	add	x2, x2, #1
	sub	x3, x3, x4
	cbnz	x3, LBB38_27
	b	LBB38_86
LBB38_85:                               ; %bb22.i.i.us
                                        ;   in Loop: Header=BB38_22 Depth=2
	cbnz	w22, LBB38_249
LBB38_86:                               ; %bb25.us
                                        ;   in Loop: Header=BB38_22 Depth=2
	str	wzr, [sp, #120]
	stp	xzr, xzr, [x30, #48]
	ldr	x12, [sp, #584]
	mul	x12, x12, x23
	str	x12, [sp, #584]
	ldrb	w13, [sp, #536]
	tbz	w13, #0, LBB38_94
LBB38_87:                               ;   in Loop: Header=BB38_22 Depth=2
	mov	x15, #0                         ; =0x0
	ldr	x13, [sp, #544]
	ldr	x14, [x13]
	cbnz	x14, LBB38_95
	b	LBB38_21
LBB38_88:                               ; %bb4.i.i.us
                                        ;   in Loop: Header=BB38_22 Depth=2
	ldr	x13, [x21, #16]
	str	w24, [x21]
	ubfiz	x14, x7, #3, #3
	mov	w15, #255                       ; =0xff
	lsl	x15, x15, x14
	mvn	x15, x15
	mov	w16, #254                       ; =0xfe
	lsl	x14, x16, x14
	stp	xzr, xzr, [x21, #8]
	cbz	x10, LBB38_91
; %bb.89:                               ; %bb3.i.i.i.us
                                        ;   in Loop: Header=BB38_22 Depth=2
	mov	x0, x11
	lsr	x16, x7, #3
	ldr	x17, [x11]
	cmp	x16, x17
	b.hs	LBB38_155
; %bb.90:                               ; %bb8.i.i.i.us
                                        ;   in Loop: Header=BB38_22 Depth=2
	add	x16, x0, x16, lsl #3
	ldr	x17, [x16, #8]
	and	x15, x17, x15
	orr	x14, x15, x14
	str	x14, [x16, #8]
	b	LBB38_93
LBB38_91:                               ; %bb2.i.i.i56.us
                                        ;   in Loop: Header=BB38_22 Depth=2
	cmp	x7, #7
	b.hi	LBB38_93
LBB38_92:                               ; %bb5.i.i.i.us
                                        ;   in Loop: Header=BB38_22 Depth=2
	ldr	x16, [sp, #560]
	and	x15, x16, x15
	orr	x14, x15, x14
	str	x14, [sp, #560]
LBB38_93:                               ; %bb24.us
                                        ;   in Loop: Header=BB38_22 Depth=2
	sub	x9, x9, #1
	str	x9, [sp, #552]
	str	w24, [sp, #120]
	stp	x12, x13, [sp, #128]
	ldur	q0, [x30, #48]
	stur	q0, [x27, #64]
	ldr	x12, [sp, #584]
	ldp	x13, x14, [sp, #144]
	madd	x12, x12, x23, x13
	madd	x12, x12, x23, x14
	add	x12, x12, #131
	str	x12, [sp, #584]
	ldrb	w13, [sp, #536]
	tbnz	w13, #0, LBB38_87
LBB38_94:                               ; %bb3.i.i.i459.us
                                        ;   in Loop: Header=BB38_22 Depth=2
	ldr	x13, [sp, #528]
	ldr	x14, [sp, #616]
	eor	x13, x14, x13
	eor	x13, x13, x13, lsr #30
	mov	x14, #58809                     ; =0xe5b9
	movk	x14, #7396, lsl #16
	movk	x14, #18285, lsl #32
	movk	x14, #48984, lsl #48
	mul	x13, x13, x14
	eor	x13, x13, x13, lsr #27
	mov	x14, #4587                      ; =0x11eb
	movk	x14, #4913, lsl #16
	movk	x14, #18875, lsl #32
	movk	x14, #38096, lsl #48
	mul	x13, x13, x14
	eor	x15, x13, x13, lsr #31
	ldr	x13, [sp, #544]
	ldr	x14, [x13]
	cbz	x14, LBB38_21
LBB38_95:                               ; %bb3.i.i475.us
                                        ;   in Loop: Header=BB38_22 Depth=2
	lsr	x0, x15, #57
	udiv	x16, x15, x14
	msub	x16, x16, x14, x15
	ldr	x15, [sp, #568]
	ldr	x17, [sp, #560]
	mov	x1, #72340172838076673          ; =0x101010101010101
	mul	x0, x0, x1
	ldr	x1, [sp, #576]
	ldr	x2, [sp, #616]
	mov	w3, #1                          ; =0x1
	mov	x4, x14
LBB38_96:                               ; %bb10.i.i485.us
                                        ;   Parent Loop BB38_18 Depth=1
                                        ;     Parent Loop BB38_22 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	x6, x16, #0x7
	sub	x5, x14, x16
	sub	x7, x26, x6
	cmp	x7, x5
	csel	x5, x7, x5, lo
	cmp	x5, x4
	csel	x5, x5, x4, lo
	cbz	x15, LBB38_99
; %bb.97:                               ; %bb3.i21.i.i495.us
                                        ;   in Loop: Header=BB38_96 Depth=3
	lsr	x7, x16, #3
	ldr	x20, [x1]
	cmp	x7, x20
	b.hs	LBB38_100
; %bb.98:                               ; %bb8.i.i.i572.us
                                        ;   in Loop: Header=BB38_96 Depth=3
	add	x7, x1, x7, lsl #3
	ldr	x20, [x7, #8]
	b	LBB38_101
LBB38_99:                               ; %bb2.i.i.i575.us
                                        ;   in Loop: Header=BB38_96 Depth=3
	cmp	x16, #8
	csel	x20, x17, x25, lo
	b	LBB38_101
LBB38_100:                              ; %bb9.i.i.i499.us
                                        ;   in Loop: Header=BB38_96 Depth=3
	csel	x20, x17, x25, eq
LBB38_101:                              ; %wf_hash_map.hash_map_control_word.exit.i.i502.us
                                        ;   in Loop: Header=BB38_96 Depth=3
	lsl	x7, x5, #3
	neg	x7, x7
	lsr	x7, x25, x7
	lsl	x21, x6, #3
	lsl	x21, x7, x21
	and	x7, x20, #0x7f7f7f7f7f7f7f7f
	sub	x7, x25, x7
	and	x7, x7, x20
	and	x7, x21, x7
	cmp	x7, #0
	rbit	x7, x7
	clz	x7, x7
	lsr	x22, x7, #3
	ccmp	x22, x6, #0, ne
	mov	x7, x5
	b.hs	LBB38_103
; %bb.102:                              ; %wf_hash_map.hash_map_control_stop.exit.i.i526.us
                                        ;   in Loop: Header=BB38_96 Depth=3
	eor	x20, x20, x0
	and	x22, x20, #0x7f7f7f7f7f7f7f7f
	add	x22, x22, x28
	orr	x20, x22, x20
	bic	x21, x21, x20
	cbnz	x21, LBB38_104
	b	LBB38_151
LBB38_103:                              ; %bb5.i.i.i523.us
                                        ;   in Loop: Header=BB38_96 Depth=3
	sub	x7, x22, x6
	cmp	x7, x5
	csel	x7, x7, x5, lo
	eor	x20, x20, x0
	and	x22, x20, #0x7f7f7f7f7f7f7f7f
	add	x22, x22, x28
	orr	x20, x22, x20
	bic	x21, x21, x20
	cbz	x21, LBB38_151
LBB38_104:                              ; %bb17.i.i529.us
                                        ;   in Loop: Header=BB38_96 Depth=3
	rbit	x20, x21
	clz	x20, x20
	lsr	x20, x20, #3
	subs	x20, x20, x6
	b.lo	LBB38_109
; %bb.105:                              ; %bb19.i.i537.us
                                        ;   in Loop: Header=BB38_96 Depth=3
	cmp	x20, x7
	b.hs	LBB38_109
; %bb.106:                              ; %bb22.i.i561.us
                                        ;   in Loop: Header=BB38_96 Depth=3
	add	x20, x20, x16
	madd	x20, x20, x19, x13
	ldr	w22, [x20, #16]!
	cmp	w22, #1
	b.eq	LBB38_109
; %bb.107:                              ; %bb22.i.i561.us
                                        ;   in Loop: Header=BB38_96 Depth=3
	cmp	w22, #2
	b.ne	LBB38_20
; %bb.108:                              ; %bb25.i.i566.us
                                        ;   in Loop: Header=BB38_96 Depth=3
	ldr	x22, [x20, #8]
	cmp	x22, x2
	b.eq	LBB38_154
LBB38_109:                              ; %bb31.i.i540.us
                                        ;   in Loop: Header=BB38_96 Depth=3
	sub	x20, x21, #1
	and	x21, x20, x21
	cbz	x21, LBB38_151
; %bb.110:                              ; %bb17.i.i529.us.1
                                        ;   in Loop: Header=BB38_96 Depth=3
	rbit	x20, x21
	clz	x20, x20
	lsr	x20, x20, #3
	subs	x20, x20, x6
	b.lo	LBB38_115
; %bb.111:                              ; %bb19.i.i537.us.1
                                        ;   in Loop: Header=BB38_96 Depth=3
	cmp	x20, x7
	b.hs	LBB38_115
; %bb.112:                              ; %bb22.i.i561.us.1
                                        ;   in Loop: Header=BB38_96 Depth=3
	add	x20, x20, x16
	madd	x20, x20, x19, x13
	ldr	w22, [x20, #16]!
	cmp	w22, #1
	b.eq	LBB38_115
; %bb.113:                              ; %bb22.i.i561.us.1
                                        ;   in Loop: Header=BB38_96 Depth=3
	cmp	w22, #2
	b.ne	LBB38_20
; %bb.114:                              ; %bb25.i.i566.us.1
                                        ;   in Loop: Header=BB38_96 Depth=3
	ldr	x22, [x20, #8]
	cmp	x22, x2
	b.eq	LBB38_154
LBB38_115:                              ; %bb31.i.i540.us.1
                                        ;   in Loop: Header=BB38_96 Depth=3
	sub	x20, x21, #1
	and	x21, x20, x21
	cbz	x21, LBB38_151
; %bb.116:                              ; %bb17.i.i529.us.2
                                        ;   in Loop: Header=BB38_96 Depth=3
	rbit	x20, x21
	clz	x20, x20
	lsr	x20, x20, #3
	subs	x20, x20, x6
	b.lo	LBB38_121
; %bb.117:                              ; %bb19.i.i537.us.2
                                        ;   in Loop: Header=BB38_96 Depth=3
	cmp	x20, x7
	b.hs	LBB38_121
; %bb.118:                              ; %bb22.i.i561.us.2
                                        ;   in Loop: Header=BB38_96 Depth=3
	add	x20, x20, x16
	madd	x20, x20, x19, x13
	ldr	w22, [x20, #16]!
	cmp	w22, #1
	b.eq	LBB38_121
; %bb.119:                              ; %bb22.i.i561.us.2
                                        ;   in Loop: Header=BB38_96 Depth=3
	cmp	w22, #2
	b.ne	LBB38_20
; %bb.120:                              ; %bb25.i.i566.us.2
                                        ;   in Loop: Header=BB38_96 Depth=3
	ldr	x22, [x20, #8]
	cmp	x22, x2
	b.eq	LBB38_154
LBB38_121:                              ; %bb31.i.i540.us.2
                                        ;   in Loop: Header=BB38_96 Depth=3
	sub	x20, x21, #1
	and	x21, x20, x21
	cbz	x21, LBB38_151
; %bb.122:                              ; %bb17.i.i529.us.3
                                        ;   in Loop: Header=BB38_96 Depth=3
	rbit	x20, x21
	clz	x20, x20
	lsr	x20, x20, #3
	subs	x20, x20, x6
	b.lo	LBB38_127
; %bb.123:                              ; %bb19.i.i537.us.3
                                        ;   in Loop: Header=BB38_96 Depth=3
	cmp	x20, x7
	b.hs	LBB38_127
; %bb.124:                              ; %bb22.i.i561.us.3
                                        ;   in Loop: Header=BB38_96 Depth=3
	add	x20, x20, x16
	madd	x20, x20, x19, x13
	ldr	w22, [x20, #16]!
	cmp	w22, #1
	b.eq	LBB38_127
; %bb.125:                              ; %bb22.i.i561.us.3
                                        ;   in Loop: Header=BB38_96 Depth=3
	cmp	w22, #2
	b.ne	LBB38_20
; %bb.126:                              ; %bb25.i.i566.us.3
                                        ;   in Loop: Header=BB38_96 Depth=3
	ldr	x22, [x20, #8]
	cmp	x22, x2
	b.eq	LBB38_154
LBB38_127:                              ; %bb31.i.i540.us.3
                                        ;   in Loop: Header=BB38_96 Depth=3
	sub	x20, x21, #1
	and	x21, x20, x21
	cbz	x21, LBB38_151
; %bb.128:                              ; %bb17.i.i529.us.4
                                        ;   in Loop: Header=BB38_96 Depth=3
	rbit	x20, x21
	clz	x20, x20
	lsr	x20, x20, #3
	subs	x20, x20, x6
	b.lo	LBB38_133
; %bb.129:                              ; %bb19.i.i537.us.4
                                        ;   in Loop: Header=BB38_96 Depth=3
	cmp	x20, x7
	b.hs	LBB38_133
; %bb.130:                              ; %bb22.i.i561.us.4
                                        ;   in Loop: Header=BB38_96 Depth=3
	add	x20, x20, x16
	madd	x20, x20, x19, x13
	ldr	w22, [x20, #16]!
	cmp	w22, #1
	b.eq	LBB38_133
; %bb.131:                              ; %bb22.i.i561.us.4
                                        ;   in Loop: Header=BB38_96 Depth=3
	cmp	w22, #2
	b.ne	LBB38_20
; %bb.132:                              ; %bb25.i.i566.us.4
                                        ;   in Loop: Header=BB38_96 Depth=3
	ldr	x22, [x20, #8]
	cmp	x22, x2
	b.eq	LBB38_154
LBB38_133:                              ; %bb31.i.i540.us.4
                                        ;   in Loop: Header=BB38_96 Depth=3
	sub	x20, x21, #1
	and	x21, x20, x21
	cbz	x21, LBB38_151
; %bb.134:                              ; %bb17.i.i529.us.5
                                        ;   in Loop: Header=BB38_96 Depth=3
	rbit	x20, x21
	clz	x20, x20
	lsr	x20, x20, #3
	subs	x20, x20, x6
	b.lo	LBB38_139
; %bb.135:                              ; %bb19.i.i537.us.5
                                        ;   in Loop: Header=BB38_96 Depth=3
	cmp	x20, x7
	b.hs	LBB38_139
; %bb.136:                              ; %bb22.i.i561.us.5
                                        ;   in Loop: Header=BB38_96 Depth=3
	add	x20, x20, x16
	madd	x20, x20, x19, x13
	ldr	w22, [x20, #16]!
	cmp	w22, #1
	b.eq	LBB38_139
; %bb.137:                              ; %bb22.i.i561.us.5
                                        ;   in Loop: Header=BB38_96 Depth=3
	cmp	w22, #2
	b.ne	LBB38_20
; %bb.138:                              ; %bb25.i.i566.us.5
                                        ;   in Loop: Header=BB38_96 Depth=3
	ldr	x22, [x20, #8]
	cmp	x22, x2
	b.eq	LBB38_154
LBB38_139:                              ; %bb31.i.i540.us.5
                                        ;   in Loop: Header=BB38_96 Depth=3
	sub	x20, x21, #1
	and	x21, x20, x21
	cbz	x21, LBB38_151
; %bb.140:                              ; %bb17.i.i529.us.6
                                        ;   in Loop: Header=BB38_96 Depth=3
	rbit	x20, x21
	clz	x20, x20
	lsr	x20, x20, #3
	subs	x20, x20, x6
	b.lo	LBB38_145
; %bb.141:                              ; %bb19.i.i537.us.6
                                        ;   in Loop: Header=BB38_96 Depth=3
	cmp	x20, x7
	b.hs	LBB38_145
; %bb.142:                              ; %bb22.i.i561.us.6
                                        ;   in Loop: Header=BB38_96 Depth=3
	add	x20, x20, x16
	madd	x20, x20, x19, x13
	ldr	w22, [x20, #16]!
	cmp	w22, #1
	b.eq	LBB38_145
; %bb.143:                              ; %bb22.i.i561.us.6
                                        ;   in Loop: Header=BB38_96 Depth=3
	cmp	w22, #2
	b.ne	LBB38_20
; %bb.144:                              ; %bb25.i.i566.us.6
                                        ;   in Loop: Header=BB38_96 Depth=3
	ldr	x22, [x20, #8]
	cmp	x22, x2
	b.eq	LBB38_154
LBB38_145:                              ; %bb31.i.i540.us.6
                                        ;   in Loop: Header=BB38_96 Depth=3
	sub	x20, x21, #1
	and	x20, x20, x21
	cbz	x20, LBB38_151
; %bb.146:                              ; %bb17.i.i529.us.7
                                        ;   in Loop: Header=BB38_96 Depth=3
	rbit	x20, x20
	clz	x20, x20
	lsr	x20, x20, #3
	subs	x6, x20, x6
	b.lo	LBB38_151
; %bb.147:                              ; %bb19.i.i537.us.7
                                        ;   in Loop: Header=BB38_96 Depth=3
	cmp	x6, x7
	b.hs	LBB38_151
; %bb.148:                              ; %bb22.i.i561.us.7
                                        ;   in Loop: Header=BB38_96 Depth=3
	add	x6, x6, x16
	madd	x20, x6, x19, x13
	ldr	w6, [x20, #16]!
	cmp	w6, #1
	b.eq	LBB38_151
; %bb.149:                              ; %bb22.i.i561.us.7
                                        ;   in Loop: Header=BB38_96 Depth=3
	cmp	w6, #2
	b.ne	LBB38_156
; %bb.150:                              ; %bb25.i.i566.us.7
                                        ;   in Loop: Header=BB38_96 Depth=3
	ldr	x6, [x20, #8]
	cmp	x6, x2
	b.eq	LBB38_154
LBB38_151:                              ; %bb14.i.i545.us
                                        ;   in Loop: Header=BB38_96 Depth=3
	cmp	x7, x5
	b.lo	LBB38_21
; %bb.152:                              ; %bb34.i.i547.us
                                        ;   in Loop: Header=BB38_96 Depth=3
	add	x16, x5, x16
	cmp	x16, x14
	csel	x16, x16, xzr, lo
	cmp	x3, x14
	b.hs	LBB38_21
; %bb.153:                              ; %bb34.i.i547.us
                                        ;   in Loop: Header=BB38_96 Depth=3
	add	x3, x3, #1
	sub	x4, x4, x5
	cbnz	x4, LBB38_96
	b	LBB38_21
LBB38_154:                              ; %bb2.i69.us
                                        ;   in Loop: Header=BB38_22 Depth=2
	ldr	x14, [x20, #16]
	str	wzr, [sp, #160]
	str	x14, [sp, #168]
	strb	wzr, [sp, #176]
	mov	w15, #17161                     ; =0x4309
	madd	x12, x12, x15, x14
	add	x12, x12, #131
	str	x12, [sp, #584]
	add	x8, x8, #1
	ldr	x12, [sp, #72]                  ; 8-byte Folded Reload
	cmp	x8, x12
	b.ne	LBB38_22
	b	LBB38_158
LBB38_155:                              ; %bb9.i.i.i.us
                                        ;   in Loop: Header=BB38_22 Depth=2
	b.eq	LBB38_92
	b	LBB38_93
LBB38_156:                              ; %bb22.i.i561.us.7
                                        ;   in Loop: Header=BB38_22 Depth=2
	cbz	w6, LBB38_21
	b	LBB38_249
LBB38_157:                              ; %bb22.i.i.us.7
                                        ;   in Loop: Header=BB38_22 Depth=2
	cbz	w5, LBB38_86
	b	LBB38_249
LBB38_158:                              ;   in Loop: Header=BB38_18 Depth=1
	ldr	x22, [sp, #48]                  ; 8-byte Folded Reload
	b	LBB38_160
LBB38_159:                              ; %bb13.us.bb22.us_crit_edge
                                        ;   in Loop: Header=BB38_18 Depth=1
	ldr	x13, [sp, #544]
LBB38_160:                              ; %bb22.us
                                        ;   in Loop: Header=BB38_18 Depth=1
	ldr	x1, [x13]
	add	x0, x27, #464
	add	x2, x27, #448
	bl	_wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	str	w0, [sp, #184]
	strb	w1, [sp, #188]
	strb	w2, [sp, #189]
	cbz	w0, LBB38_164
; %bb.161:                              ; %bb22.us
                                        ;   in Loop: Header=BB38_18 Depth=1
	cmp	w0, #1
	ldr	x30, [sp, #64]                  ; 8-byte Folded Reload
	b.ne	LBB38_249
; %bb.162:                              ; %bb3.i.us
                                        ;   in Loop: Header=BB38_18 Depth=1
	ldr	x8, [sp, #584]
	mul	x8, x8, x23
	str	x8, [sp, #584]
	cbnz	x30, LBB38_165
LBB38_163:                              ; %bb32.preheader.us.bb93.loopexit.us_crit_edge
                                        ;   in Loop: Header=BB38_18 Depth=1
	add	x22, x22, #1
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	add	x8, x8, x30
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	cmp	x22, x8
	b.ne	LBB38_18
	b	LBB38_459
LBB38_164:                              ; %bb2.i.us
                                        ;   in Loop: Header=BB38_18 Depth=1
	ldr	x8, [sp, #584]
	mov	x9, #1                          ; =0x1
	madd	x8, x8, x23, x9
	ldr	x30, [sp, #64]                  ; 8-byte Folded Reload
	str	x8, [sp, #584]
	cbz	x30, LBB38_163
LBB38_165:                              ; %bb28.lr.ph.us
                                        ;   in Loop: Header=BB38_18 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	x10, [sp, #528]
	ldrb	w11, [sp, #536]
	ldr	x12, [sp, #544]
	ldr	x13, [sp, #560]
	ldr	x14, [sp, #568]
	ldr	x15, [sp, #576]
	b	LBB38_168
LBB38_166:                              ; %bb22.i.i683.us
                                        ;   in Loop: Header=BB38_168 Depth=2
	cbnz	w21, LBB38_249
LBB38_167:                              ; %bb3.i106.us
                                        ;   in Loop: Header=BB38_168 Depth=2
	str	w24, [sp, #192]
	str	xzr, [sp, #200]
	mul	x8, x8, x23
	strb	wzr, [sp, #208]
	str	x8, [sp, #584]
	add	x9, x9, #1
	cmp	x9, x30
	b.eq	LBB38_232
LBB38_168:                              ; %bb28.us
                                        ;   Parent Loop BB38_18 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB38_172 Depth 3
	orr	x16, x24, x9, lsl #1
	str	x16, [sp, #624]
	tbz	w11, #0, LBB38_170
; %bb.169:                              ;   in Loop: Header=BB38_168 Depth=2
	mov	x0, #0                          ; =0x0
	ldr	x17, [x12]
	cbnz	x17, LBB38_171
	b	LBB38_167
LBB38_170:                              ; %bb3.i.i.i581.us
                                        ;   in Loop: Header=BB38_168 Depth=2
	eor	x17, x10, x16
	eor	x17, x17, x17, lsr #30
	mov	x0, #58809                      ; =0xe5b9
	movk	x0, #7396, lsl #16
	movk	x0, #18285, lsl #32
	movk	x0, #48984, lsl #48
	mul	x17, x17, x0
	eor	x17, x17, x17, lsr #27
	mov	x0, #4587                       ; =0x11eb
	movk	x0, #4913, lsl #16
	movk	x0, #18875, lsl #32
	movk	x0, #38096, lsl #48
	mul	x17, x17, x0
	eor	x0, x17, x17, lsr #31
	ldr	x17, [x12]
	cbz	x17, LBB38_167
LBB38_171:                              ; %bb3.i.i597.us
                                        ;   in Loop: Header=BB38_168 Depth=2
	lsr	x2, x0, #57
	udiv	x1, x0, x17
	msub	x1, x1, x17, x0
	mov	x0, #72340172838076673          ; =0x101010101010101
	mul	x0, x2, x0
	mov	w2, #1                          ; =0x1
	mov	x3, x17
LBB38_172:                              ; %bb10.i.i607.us
                                        ;   Parent Loop BB38_18 Depth=1
                                        ;     Parent Loop BB38_168 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	x5, x1, #0x7
	sub	x4, x17, x1
	sub	x6, x26, x5
	cmp	x6, x4
	csel	x4, x6, x4, lo
	cmp	x4, x3
	csel	x4, x4, x3, lo
	cbz	x14, LBB38_175
; %bb.173:                              ; %bb3.i21.i.i617.us
                                        ;   in Loop: Header=BB38_172 Depth=3
	lsr	x6, x1, #3
	ldr	x7, [x15]
	cmp	x6, x7
	b.hs	LBB38_176
; %bb.174:                              ; %bb8.i.i.i694.us
                                        ;   in Loop: Header=BB38_172 Depth=3
	add	x6, x15, x6, lsl #3
	ldr	x7, [x6, #8]
	b	LBB38_177
LBB38_175:                              ; %bb2.i.i.i697.us
                                        ;   in Loop: Header=BB38_172 Depth=3
	cmp	x1, #8
	csel	x7, x13, x25, lo
	b	LBB38_177
LBB38_176:                              ; %bb9.i.i.i621.us
                                        ;   in Loop: Header=BB38_172 Depth=3
	csel	x7, x13, x25, eq
LBB38_177:                              ; %wf_hash_map.hash_map_control_word.exit.i.i624.us
                                        ;   in Loop: Header=BB38_172 Depth=3
	lsl	x6, x4, #3
	neg	x6, x6
	lsr	x6, x25, x6
	lsl	x20, x5, #3
	lsl	x20, x6, x20
	and	x6, x7, #0x7f7f7f7f7f7f7f7f
	sub	x6, x25, x6
	and	x6, x6, x7
	and	x6, x20, x6
	cmp	x6, #0
	rbit	x6, x6
	clz	x6, x6
	lsr	x21, x6, #3
	ccmp	x21, x5, #0, ne
	mov	x6, x4
	b.hs	LBB38_179
; %bb.178:                              ; %wf_hash_map.hash_map_control_stop.exit.i.i648.us
                                        ;   in Loop: Header=BB38_172 Depth=3
	eor	x7, x7, x0
	and	x21, x7, #0x7f7f7f7f7f7f7f7f
	add	x21, x21, x28
	orr	x7, x21, x7
	bic	x20, x20, x7
	cbnz	x20, LBB38_180
	b	LBB38_227
LBB38_179:                              ; %bb5.i.i.i645.us
                                        ;   in Loop: Header=BB38_172 Depth=3
	sub	x6, x21, x5
	cmp	x6, x4
	csel	x6, x6, x4, lo
	eor	x7, x7, x0
	and	x21, x7, #0x7f7f7f7f7f7f7f7f
	add	x21, x21, x28
	orr	x7, x21, x7
	bic	x20, x20, x7
	cbz	x20, LBB38_227
LBB38_180:                              ; %bb17.i.i651.us
                                        ;   in Loop: Header=BB38_172 Depth=3
	rbit	x7, x20
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB38_185
; %bb.181:                              ; %bb19.i.i659.us
                                        ;   in Loop: Header=BB38_172 Depth=3
	cmp	x7, x6
	b.hs	LBB38_185
; %bb.182:                              ; %bb22.i.i683.us
                                        ;   in Loop: Header=BB38_172 Depth=3
	add	x7, x7, x1
	madd	x7, x7, x19, x12
	ldr	w21, [x7, #16]!
	cmp	w21, #1
	b.eq	LBB38_185
; %bb.183:                              ; %bb22.i.i683.us
                                        ;   in Loop: Header=BB38_172 Depth=3
	cmp	w21, #2
	b.ne	LBB38_166
; %bb.184:                              ; %bb25.i.i688.us
                                        ;   in Loop: Header=BB38_172 Depth=3
	ldr	x21, [x7, #8]
	cmp	x21, x16
	b.eq	LBB38_230
LBB38_185:                              ; %bb31.i.i662.us
                                        ;   in Loop: Header=BB38_172 Depth=3
	sub	x7, x20, #1
	and	x20, x7, x20
	cbz	x20, LBB38_227
; %bb.186:                              ; %bb17.i.i651.us.1
                                        ;   in Loop: Header=BB38_172 Depth=3
	rbit	x7, x20
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB38_191
; %bb.187:                              ; %bb19.i.i659.us.1
                                        ;   in Loop: Header=BB38_172 Depth=3
	cmp	x7, x6
	b.hs	LBB38_191
; %bb.188:                              ; %bb22.i.i683.us.1
                                        ;   in Loop: Header=BB38_172 Depth=3
	add	x7, x7, x1
	madd	x7, x7, x19, x12
	ldr	w21, [x7, #16]!
	cmp	w21, #1
	b.eq	LBB38_191
; %bb.189:                              ; %bb22.i.i683.us.1
                                        ;   in Loop: Header=BB38_172 Depth=3
	cmp	w21, #2
	b.ne	LBB38_166
; %bb.190:                              ; %bb25.i.i688.us.1
                                        ;   in Loop: Header=BB38_172 Depth=3
	ldr	x21, [x7, #8]
	cmp	x21, x16
	b.eq	LBB38_230
LBB38_191:                              ; %bb31.i.i662.us.1
                                        ;   in Loop: Header=BB38_172 Depth=3
	sub	x7, x20, #1
	and	x20, x7, x20
	cbz	x20, LBB38_227
; %bb.192:                              ; %bb17.i.i651.us.2
                                        ;   in Loop: Header=BB38_172 Depth=3
	rbit	x7, x20
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB38_197
; %bb.193:                              ; %bb19.i.i659.us.2
                                        ;   in Loop: Header=BB38_172 Depth=3
	cmp	x7, x6
	b.hs	LBB38_197
; %bb.194:                              ; %bb22.i.i683.us.2
                                        ;   in Loop: Header=BB38_172 Depth=3
	add	x7, x7, x1
	madd	x7, x7, x19, x12
	ldr	w21, [x7, #16]!
	cmp	w21, #1
	b.eq	LBB38_197
; %bb.195:                              ; %bb22.i.i683.us.2
                                        ;   in Loop: Header=BB38_172 Depth=3
	cmp	w21, #2
	b.ne	LBB38_166
; %bb.196:                              ; %bb25.i.i688.us.2
                                        ;   in Loop: Header=BB38_172 Depth=3
	ldr	x21, [x7, #8]
	cmp	x21, x16
	b.eq	LBB38_230
LBB38_197:                              ; %bb31.i.i662.us.2
                                        ;   in Loop: Header=BB38_172 Depth=3
	sub	x7, x20, #1
	and	x20, x7, x20
	cbz	x20, LBB38_227
; %bb.198:                              ; %bb17.i.i651.us.3
                                        ;   in Loop: Header=BB38_172 Depth=3
	rbit	x7, x20
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB38_203
; %bb.199:                              ; %bb19.i.i659.us.3
                                        ;   in Loop: Header=BB38_172 Depth=3
	cmp	x7, x6
	b.hs	LBB38_203
; %bb.200:                              ; %bb22.i.i683.us.3
                                        ;   in Loop: Header=BB38_172 Depth=3
	add	x7, x7, x1
	madd	x7, x7, x19, x12
	ldr	w21, [x7, #16]!
	cmp	w21, #1
	b.eq	LBB38_203
; %bb.201:                              ; %bb22.i.i683.us.3
                                        ;   in Loop: Header=BB38_172 Depth=3
	cmp	w21, #2
	b.ne	LBB38_166
; %bb.202:                              ; %bb25.i.i688.us.3
                                        ;   in Loop: Header=BB38_172 Depth=3
	ldr	x21, [x7, #8]
	cmp	x21, x16
	b.eq	LBB38_230
LBB38_203:                              ; %bb31.i.i662.us.3
                                        ;   in Loop: Header=BB38_172 Depth=3
	sub	x7, x20, #1
	and	x20, x7, x20
	cbz	x20, LBB38_227
; %bb.204:                              ; %bb17.i.i651.us.4
                                        ;   in Loop: Header=BB38_172 Depth=3
	rbit	x7, x20
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB38_209
; %bb.205:                              ; %bb19.i.i659.us.4
                                        ;   in Loop: Header=BB38_172 Depth=3
	cmp	x7, x6
	b.hs	LBB38_209
; %bb.206:                              ; %bb22.i.i683.us.4
                                        ;   in Loop: Header=BB38_172 Depth=3
	add	x7, x7, x1
	madd	x7, x7, x19, x12
	ldr	w21, [x7, #16]!
	cmp	w21, #1
	b.eq	LBB38_209
; %bb.207:                              ; %bb22.i.i683.us.4
                                        ;   in Loop: Header=BB38_172 Depth=3
	cmp	w21, #2
	b.ne	LBB38_166
; %bb.208:                              ; %bb25.i.i688.us.4
                                        ;   in Loop: Header=BB38_172 Depth=3
	ldr	x21, [x7, #8]
	cmp	x21, x16
	b.eq	LBB38_230
LBB38_209:                              ; %bb31.i.i662.us.4
                                        ;   in Loop: Header=BB38_172 Depth=3
	sub	x7, x20, #1
	and	x20, x7, x20
	cbz	x20, LBB38_227
; %bb.210:                              ; %bb17.i.i651.us.5
                                        ;   in Loop: Header=BB38_172 Depth=3
	rbit	x7, x20
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB38_215
; %bb.211:                              ; %bb19.i.i659.us.5
                                        ;   in Loop: Header=BB38_172 Depth=3
	cmp	x7, x6
	b.hs	LBB38_215
; %bb.212:                              ; %bb22.i.i683.us.5
                                        ;   in Loop: Header=BB38_172 Depth=3
	add	x7, x7, x1
	madd	x7, x7, x19, x12
	ldr	w21, [x7, #16]!
	cmp	w21, #1
	b.eq	LBB38_215
; %bb.213:                              ; %bb22.i.i683.us.5
                                        ;   in Loop: Header=BB38_172 Depth=3
	cmp	w21, #2
	b.ne	LBB38_166
; %bb.214:                              ; %bb25.i.i688.us.5
                                        ;   in Loop: Header=BB38_172 Depth=3
	ldr	x21, [x7, #8]
	cmp	x21, x16
	b.eq	LBB38_230
LBB38_215:                              ; %bb31.i.i662.us.5
                                        ;   in Loop: Header=BB38_172 Depth=3
	sub	x7, x20, #1
	and	x20, x7, x20
	cbz	x20, LBB38_227
; %bb.216:                              ; %bb17.i.i651.us.6
                                        ;   in Loop: Header=BB38_172 Depth=3
	rbit	x7, x20
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB38_221
; %bb.217:                              ; %bb19.i.i659.us.6
                                        ;   in Loop: Header=BB38_172 Depth=3
	cmp	x7, x6
	b.hs	LBB38_221
; %bb.218:                              ; %bb22.i.i683.us.6
                                        ;   in Loop: Header=BB38_172 Depth=3
	add	x7, x7, x1
	madd	x7, x7, x19, x12
	ldr	w21, [x7, #16]!
	cmp	w21, #1
	b.eq	LBB38_221
; %bb.219:                              ; %bb22.i.i683.us.6
                                        ;   in Loop: Header=BB38_172 Depth=3
	cmp	w21, #2
	b.ne	LBB38_166
; %bb.220:                              ; %bb25.i.i688.us.6
                                        ;   in Loop: Header=BB38_172 Depth=3
	ldr	x21, [x7, #8]
	cmp	x21, x16
	b.eq	LBB38_230
LBB38_221:                              ; %bb31.i.i662.us.6
                                        ;   in Loop: Header=BB38_172 Depth=3
	sub	x7, x20, #1
	and	x7, x7, x20
	cbz	x7, LBB38_227
; %bb.222:                              ; %bb17.i.i651.us.7
                                        ;   in Loop: Header=BB38_172 Depth=3
	rbit	x7, x7
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x5, x7, x5
	b.lo	LBB38_227
; %bb.223:                              ; %bb19.i.i659.us.7
                                        ;   in Loop: Header=BB38_172 Depth=3
	cmp	x5, x6
	b.hs	LBB38_227
; %bb.224:                              ; %bb22.i.i683.us.7
                                        ;   in Loop: Header=BB38_172 Depth=3
	add	x5, x5, x1
	madd	x7, x5, x19, x12
	ldr	w5, [x7, #16]!
	cmp	w5, #1
	b.eq	LBB38_227
; %bb.225:                              ; %bb22.i.i683.us.7
                                        ;   in Loop: Header=BB38_172 Depth=3
	cmp	w5, #2
	b.ne	LBB38_231
; %bb.226:                              ; %bb25.i.i688.us.7
                                        ;   in Loop: Header=BB38_172 Depth=3
	ldr	x5, [x7, #8]
	cmp	x5, x16
	b.eq	LBB38_230
LBB38_227:                              ; %bb14.i.i667.us
                                        ;   in Loop: Header=BB38_172 Depth=3
	cmp	x6, x4
	b.lo	LBB38_167
; %bb.228:                              ; %bb34.i.i669.us
                                        ;   in Loop: Header=BB38_172 Depth=3
	add	x1, x4, x1
	cmp	x1, x17
	csel	x1, x1, xzr, lo
	cmp	x2, x17
	b.hs	LBB38_167
; %bb.229:                              ; %bb34.i.i669.us
                                        ;   in Loop: Header=BB38_172 Depth=3
	add	x2, x2, #1
	sub	x3, x3, x4
	cbnz	x3, LBB38_172
	b	LBB38_167
LBB38_230:                              ; %bb2.i110.us
                                        ;   in Loop: Header=BB38_168 Depth=2
	ldr	x16, [x7, #16]
	str	wzr, [sp, #192]
	str	x16, [sp, #200]
	strb	wzr, [sp, #208]
	mov	w17, #17161                     ; =0x4309
	madd	x8, x8, x17, x16
	add	x8, x8, #131
	str	x8, [sp, #584]
	add	x9, x9, #1
	cmp	x9, x30
	b.ne	LBB38_168
	b	LBB38_232
LBB38_231:                              ; %bb22.i.i683.us.7
                                        ;   in Loop: Header=BB38_168 Depth=2
	cbz	w5, LBB38_167
	b	LBB38_249
LBB38_232:                              ; %bb33.lr.ph.us
                                        ;   in Loop: Header=BB38_18 Depth=1
	add	x22, x22, #1
	str	x22, [sp, #48]                  ; 8-byte Folded Spill
	mov	w21, #1                         ; =0x1
	ldr	x20, [sp, #72]                  ; 8-byte Folded Reload
	ldr	x22, [sp, #56]                  ; 8-byte Folded Reload
LBB38_233:                              ; %bb33.us
                                        ;   Parent Loop BB38_18 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x0, sp, #640
	add	x1, x27, #464
	add	x4, x27, #448
	mov	x2, x21
	mov	x3, x22
	bl	_wf_hash_map.hash_map_try_put$instance$fde7c6722a8b0dad
	ldr	w8, [sp, #640]
	cbz	w8, LBB38_238
; %bb.234:                              ; %bb33.us
                                        ;   in Loop: Header=BB38_233 Depth=2
	cmp	w8, #1
	b.ne	LBB38_249
; %bb.235:                              ; %bb2.i120.us
                                        ;   in Loop: Header=BB38_233 Depth=2
	ldrb	w8, [sp, #644]
	add	x9, sp, #640
	ldur	q0, [x9, #8]
	add	x27, sp, #640
	stur	q0, [x9, #24]
	add	x10, sp, #80
	tbz	w8, #0, LBB38_240
; %bb.236:                              ; %bb4.i.us
                                        ;   in Loop: Header=BB38_233 Depth=2
	ldr	x8, [sp, #544]
	ldr	x8, [x8]
	lsr	x9, x8, #14
	cbz	x9, LBB38_243
; %bb.237:                              ; %bb6.i.us
                                        ;   in Loop: Header=BB38_233 Depth=2
	str	x24, [sp, #216]
	strb	w24, [sp, #220]
	b	LBB38_241
LBB38_238:                              ; %"wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit.thread983.us"
                                        ;   in Loop: Header=BB38_233 Depth=2
	stp	xzr, xzr, [x27, #136]
	stur	xzr, [x27, #152]
LBB38_239:                              ; %bb37.us
                                        ;   in Loop: Header=BB38_233 Depth=2
	ldr	x8, [sp, #584]
	mul	x8, x8, x23
	str	x8, [sp, #584]
	add	x22, x22, #2
	add	x21, x21, #4
	subs	x20, x20, #1
	b.ne	LBB38_233
	b	LBB38_17
LBB38_240:                              ; %bb3.i121.us
                                        ;   in Loop: Header=BB38_233 Depth=2
	str	x24, [sp, #216]
LBB38_241:                              ; %"wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit.thread.us"
                                        ;   in Loop: Header=BB38_233 Depth=2
	ldur	q0, [x27, #8]
	stur	q0, [x10, #144]
	add	x27, sp, #80
LBB38_242:                              ; %bb38.us
                                        ;   in Loop: Header=BB38_233 Depth=2
	ldrb	w8, [sp, #220]
	ldur	q0, [x10, #144]
	stur	q0, [x27, #160]
	ldr	x9, [sp, #584]
	cmp	w8, #0
	cinc	x8, x24, ne
	madd	x8, x9, x23, x8
	ldp	x9, x10, [sp, #240]
	add	x8, x9, x8
	madd	x8, x8, x23, x10
	str	x8, [sp, #584]
	add	x22, x22, #2
	add	x21, x21, #4
	subs	x20, x20, #1
	b.ne	LBB38_233
	b	LBB38_17
LBB38_243:                              ; %bb7.i.us
                                        ;   in Loop: Header=BB38_233 Depth=2
	cmp	x8, #2, lsl #12                 ; =8192
	mov	w9, #8192                       ; =0x2000
	csel	x9, x8, x9, lo
	lsl	x9, x9, #1
	cmp	x8, #0
	csinc	x1, x9, xzr, ne
	cmp	x1, x8
	b.ls	LBB38_247
; %bb.244:                              ; %"wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit.i.us"
                                        ;   in Loop: Header=BB38_233 Depth=2
	add	x8, sp, #80
	add	x0, x8, #464
	add	x2, x8, #448
	bl	_wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	cbz	w0, LBB38_247
; %bb.245:                              ; %"wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit.i.us"
                                        ;   in Loop: Header=BB38_233 Depth=2
	cmp	w0, #1
	b.ne	LBB38_249
; %bb.246:                              ; %bb18.i.us
                                        ;   in Loop: Header=BB38_233 Depth=2
	str	x24, [sp, #216]
	strb	w24, [sp, #220]
	add	x10, sp, #80
	b	LBB38_241
LBB38_247:                              ; %"wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit.us"
                                        ;   in Loop: Header=BB38_233 Depth=2
	ldr	x2, [sp, #664]
	ldr	x3, [sp, #672]
	add	x27, sp, #80
	add	x0, x27, #136
	add	x1, x27, #464
	add	x4, x27, #448
	bl	_wf_hash_map.hash_map_try_put$instance$fde7c6722a8b0dad
	ldr	w8, [sp, #216]
	cbz	w8, LBB38_239
; %bb.248:                              ; %"wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit.us"
                                        ;   in Loop: Header=BB38_233 Depth=2
	cmp	w8, #1
	add	x10, sp, #80
	b.eq	LBB38_242
LBB38_249:                              ; %invalid.tag.b2
	bl	_abort
LBB38_250:                              ; %bb13.preheader
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	mov	x28, #0                         ; =0x0
	sub	x9, x22, #9
	str	x9, [sp, #72]                   ; 8-byte Folded Spill
	mov	w24, #131                       ; =0x83
	mov	w21, #1                         ; =0x1
	mov	w19, #8                         ; =0x8
	mov	x25, #-9187201950435737472      ; =0x8080808080808080
	mov	x23, #9187201950435737471       ; =0x7f7f7f7f7f7f7f7f
	mov	w26, #24                        ; =0x18
	str	x20, [sp, #24]                  ; 8-byte Folded Spill
	b	LBB38_252
LBB38_251:                              ; %bb93.loopexit1053
                                        ;   in Loop: Header=BB38_252 Depth=1
	mov	w24, #131                       ; =0x83
	ldp	x9, x28, [sp, #40]              ; 16-byte Folded Reload
	cmp	x28, x9
	ldr	x20, [sp, #24]                  ; 8-byte Folded Reload
	b.eq	LBB38_459
LBB38_252:                              ; %bb13
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB38_271 Depth 2
                                        ;       Child Loop BB38_376 Depth 3
                                        ;       Child Loop BB38_288 Depth 3
	cmp	x22, #4
	b.eq	LBB38_256
; %bb.253:                              ; %bb13
                                        ;   in Loop: Header=BB38_252 Depth=1
	cmp	x22, #9
	b.eq	LBB38_256
; %bb.254:                              ; %bb13
                                        ;   in Loop: Header=BB38_252 Depth=1
	cmp	x22, #10
	b.ne	LBB38_265
; %bb.255:                              ; %bb49.thread
                                        ;   in Loop: Header=BB38_252 Depth=1
	mov	x9, #1                          ; =0x1
	madd	x8, x8, x24, x9
	str	x8, [sp, #584]
	b	LBB38_264
LBB38_256:                              ; %bb51
                                        ;   in Loop: Header=BB38_252 Depth=1
	cmp	x20, #4, lsl #12                ; =16384
	b.ls	LBB38_260
; %bb.257:                              ;   in Loop: Header=BB38_252 Depth=1
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	str	w0, [sp, #256]
	strb	w1, [sp, #260]
	strb	w2, [sp, #261]
	cbz	w0, LBB38_263
LBB38_258:                              ; %"wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit"
                                        ;   in Loop: Header=BB38_252 Depth=1
	cmp	w0, #1
	b.ne	LBB38_249
; %bb.259:                              ; %bb3.i150
                                        ;   in Loop: Header=BB38_252 Depth=1
	ldr	x8, [sp, #584]
	mul	x8, x8, x24
	str	x8, [sp, #584]
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	cmp	x9, #2
	b.lo	LBB38_264
	b	LBB38_265
LBB38_260:                              ; %bb3.i.i141
                                        ;   in Loop: Header=BB38_252 Depth=1
	ldr	x8, [sp, #544]
	ldr	x8, [x8]
	cmp	x20, x8
	b.ls	LBB38_262
; %bb.261:                              ; %bb6.i.i148
                                        ;   in Loop: Header=BB38_252 Depth=1
	add	x0, x27, #464
	add	x2, x27, #448
	mov	x1, x20
	bl	_wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	ldr	x30, [sp, #64]                  ; 8-byte Folded Reload
	str	w0, [sp, #256]
	strb	w1, [sp, #260]
	strb	w2, [sp, #261]
	cbnz	w0, LBB38_258
	b	LBB38_263
LBB38_262:                              ;   in Loop: Header=BB38_252 Depth=1
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #256]
	strb	w1, [sp, #260]
	strb	w2, [sp, #261]
	cbnz	w0, LBB38_258
LBB38_263:                              ; %bb2.i155
                                        ;   in Loop: Header=BB38_252 Depth=1
	ldr	x8, [sp, #584]
	mov	x9, #1                          ; =0x1
	madd	x8, x8, x24, x9
	str	x8, [sp, #584]
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	cmp	x9, #2
	b.hs	LBB38_265
LBB38_264:                              ; %bb53
                                        ;   in Loop: Header=BB38_252 Depth=1
	ldr	x9, [sp, #544]
	ldr	x9, [x9]
	cmp	x9, x20
	mul	x8, x8, x24
	cinc	x8, x8, hs
	str	x8, [sp, #584]
LBB38_265:                              ; %bb43
                                        ;   in Loop: Header=BB38_252 Depth=1
	add	x10, x28, #1
	str	x10, [sp, #48]                  ; 8-byte Folded Spill
	cbz	x30, LBB38_251
; %bb.266:                              ; %bb59.lr.ph
                                        ;   in Loop: Header=BB38_252 Depth=1
	mov	x28, #0                         ; =0x0
	ldp	x24, x9, [sp, #8]               ; 16-byte Folded Reload
	madd	x9, x10, x30, x9
	str	x9, [sp, #56]                   ; 8-byte Folded Spill
	mov	w20, #131                       ; =0x83
	b	LBB38_271
LBB38_267:                              ; %bb22.i.i805
                                        ;   in Loop: Header=BB38_271 Depth=2
	cbnz	w6, LBB38_249
LBB38_268:                              ; %bb3.i189
                                        ;   in Loop: Header=BB38_271 Depth=2
	str	w21, [sp, #264]
	str	xzr, [sp, #272]
	mul	x8, x8, x20
	strb	wzr, [sp, #280]
LBB38_269:                              ; %bb92.sink.split
                                        ;   in Loop: Header=BB38_271 Depth=2
	str	x8, [sp, #584]
LBB38_270:                              ; %bb92
                                        ;   in Loop: Header=BB38_271 Depth=2
	add	x28, x28, #1
	cmp	x28, x30
	b.eq	LBB38_251
LBB38_271:                              ; %bb59
                                        ;   Parent Loop BB38_252 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB38_376 Depth 3
                                        ;       Child Loop BB38_288 Depth 3
	add	x9, x28, x24
	orr	x2, x21, x9, lsl #1
	str	x2, [sp, #632]
	cmp	x22, #3
	b.gt	LBB38_281
; %bb.272:                              ; %bb59
                                        ;   in Loop: Header=BB38_271 Depth=2
	cmp	x22, #2
	b.lo	LBB38_284
; %bb.273:                              ; %bb59
                                        ;   in Loop: Header=BB38_271 Depth=2
	b.eq	LBB38_346
; %bb.274:                              ; %bb59
                                        ;   in Loop: Header=BB38_271 Depth=2
	cmp	x22, #3
	b.ne	LBB38_270
; %bb.275:                              ; %bb78
                                        ;   in Loop: Header=BB38_271 Depth=2
	ldr	x20, [sp, #552]
	cbz	x20, LBB38_370
; %bb.276:                              ; %bb3.i.i255
                                        ;   in Loop: Header=BB38_271 Depth=2
	add	x0, x27, #464
	add	x1, x27, #552
	add	x2, x27, #448
	bl	_wf_hash_map.hash_map_find$instance$fde7c6722a8b0dad
	cmp	w0, #1
	b.eq	LBB38_370
; %bb.277:                              ; %bb3.i.i255
                                        ;   in Loop: Header=BB38_271 Depth=2
	cbnz	w0, LBB38_249
; %bb.278:                              ; %bb4.i.i264
                                        ;   in Loop: Header=BB38_271 Depth=2
	ldr	x8, [sp, #544]
	madd	x11, x1, x26, x8
	ldr	w8, [x11, #16]
	ldur	q0, [x11, #24]
	str	w21, [x11, #16]
	ubfiz	x9, x1, #3, #3
	mov	w10, #255                       ; =0xff
	lsl	x10, x10, x9
	mvn	x10, x10
	mov	w12, #254                       ; =0xfe
	lsl	x9, x12, x9
	stp	xzr, xzr, [x11, #24]
	ldr	x11, [sp, #568]
	cbz	x11, LBB38_367
; %bb.279:                              ; %bb3.i.i.i282
                                        ;   in Loop: Header=BB38_271 Depth=2
	lsr	x11, x1, #3
	ldr	x12, [sp, #576]
	ldr	x13, [x12]
	cmp	x11, x13
	b.hs	LBB38_434
; %bb.280:                              ; %bb8.i.i.i297
                                        ;   in Loop: Header=BB38_271 Depth=2
	add	x11, x12, x11, lsl #3
	ldr	x12, [x11, #8]
	and	x10, x12, x10
	orr	x9, x10, x9
	str	x9, [x11, #8]
	b	LBB38_369
LBB38_281:                              ; %bb59
                                        ;   in Loop: Header=BB38_271 Depth=2
	ldr	x9, [sp, #72]                   ; 8-byte Folded Reload
	cmp	x9, #2
	b.lo	LBB38_284
; %bb.282:                              ; %bb59
                                        ;   in Loop: Header=BB38_271 Depth=2
	cmp	x22, #7
	b.eq	LBB38_351
; %bb.283:                              ; %bb59
                                        ;   in Loop: Header=BB38_271 Depth=2
	cmp	x22, #4
	b.ne	LBB38_270
LBB38_284:                              ; %bb66
                                        ;   in Loop: Header=BB38_271 Depth=2
	ldrb	w9, [sp, #536]
	tbz	w9, #0, LBB38_286
; %bb.285:                              ;   in Loop: Header=BB38_271 Depth=2
	mov	x11, #0                         ; =0x0
	ldr	x9, [sp, #544]
	ldr	x10, [x9]
	cbnz	x10, LBB38_287
	b	LBB38_268
LBB38_286:                              ; %bb3.i.i.i703
                                        ;   in Loop: Header=BB38_271 Depth=2
	ldr	x9, [sp, #528]
	eor	x9, x9, x2
	eor	x9, x9, x9, lsr #30
	mov	x10, #58809                     ; =0xe5b9
	movk	x10, #7396, lsl #16
	movk	x10, #18285, lsl #32
	movk	x10, #48984, lsl #48
	mul	x9, x9, x10
	eor	x9, x9, x9, lsr #27
	mov	x10, #4587                      ; =0x11eb
	movk	x10, #4913, lsl #16
	movk	x10, #18875, lsl #32
	movk	x10, #38096, lsl #48
	mul	x9, x9, x10
	eor	x11, x9, x9, lsr #31
	ldr	x9, [sp, #544]
	ldr	x10, [x9]
	cbz	x10, LBB38_268
LBB38_287:                              ; %bb3.i.i719
                                        ;   in Loop: Header=BB38_271 Depth=2
	lsr	x14, x11, #57
	udiv	x12, x11, x10
	msub	x12, x12, x10, x11
	ldr	x11, [sp, #568]
	ldr	x13, [sp, #560]
	mov	x15, #72340172838076673         ; =0x101010101010101
	mul	x14, x14, x15
	ldr	x15, [sp, #576]
	mov	w16, #1                         ; =0x1
	mov	x17, x10
LBB38_288:                              ; %bb10.i.i729
                                        ;   Parent Loop BB38_252 Depth=1
                                        ;     Parent Loop BB38_271 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	x1, x12, #0x7
	sub	x0, x10, x12
	sub	x3, x19, x1
	cmp	x3, x0
	csel	x0, x3, x0, lo
	cmp	x0, x17
	csel	x0, x0, x17, lo
	cbz	x11, LBB38_291
; %bb.289:                              ; %bb3.i21.i.i739
                                        ;   in Loop: Header=BB38_288 Depth=3
	lsr	x3, x12, #3
	ldr	x4, [x15]
	cmp	x3, x4
	b.hs	LBB38_292
; %bb.290:                              ; %bb8.i.i.i816
                                        ;   in Loop: Header=BB38_288 Depth=3
	add	x3, x15, x3, lsl #3
	ldr	x4, [x3, #8]
	b	LBB38_293
LBB38_291:                              ; %bb2.i.i.i819
                                        ;   in Loop: Header=BB38_288 Depth=3
	cmp	x12, #8
	csel	x4, x13, x25, lo
	b	LBB38_293
LBB38_292:                              ; %bb9.i.i.i743
                                        ;   in Loop: Header=BB38_288 Depth=3
	csel	x4, x13, x25, eq
LBB38_293:                              ; %wf_hash_map.hash_map_control_word.exit.i.i746
                                        ;   in Loop: Header=BB38_288 Depth=3
	lsl	x3, x0, #3
	neg	x3, x3
	lsr	x3, x25, x3
	lsl	x5, x1, #3
	lsl	x5, x3, x5
	and	x3, x4, #0x7f7f7f7f7f7f7f7f
	sub	x3, x25, x3
	and	x3, x3, x4
	and	x3, x5, x3
	cmp	x3, #0
	rbit	x3, x3
	clz	x3, x3
	lsr	x6, x3, #3
	ccmp	x6, x1, #0, ne
	mov	x3, x0
	b.hs	LBB38_295
; %bb.294:                              ; %wf_hash_map.hash_map_control_stop.exit.i.i770
                                        ;   in Loop: Header=BB38_288 Depth=3
	eor	x4, x4, x14
	and	x6, x4, #0x7f7f7f7f7f7f7f7f
	add	x6, x6, x23
	orr	x4, x6, x4
	bic	x5, x5, x4
	cbnz	x5, LBB38_296
	b	LBB38_343
LBB38_295:                              ; %bb5.i.i.i767
                                        ;   in Loop: Header=BB38_288 Depth=3
	sub	x3, x6, x1
	cmp	x3, x0
	csel	x3, x3, x0, lo
	eor	x4, x4, x14
	and	x6, x4, #0x7f7f7f7f7f7f7f7f
	add	x6, x6, x23
	orr	x4, x6, x4
	bic	x5, x5, x4
	cbz	x5, LBB38_343
LBB38_296:                              ; %bb17.i.i773
                                        ;   in Loop: Header=BB38_288 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x1
	b.lo	LBB38_301
; %bb.297:                              ; %bb19.i.i781
                                        ;   in Loop: Header=BB38_288 Depth=3
	cmp	x4, x3
	b.hs	LBB38_301
; %bb.298:                              ; %bb22.i.i805
                                        ;   in Loop: Header=BB38_288 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x26, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB38_301
; %bb.299:                              ; %bb22.i.i805
                                        ;   in Loop: Header=BB38_288 Depth=3
	cmp	w6, #2
	b.ne	LBB38_267
; %bb.300:                              ; %bb25.i.i810
                                        ;   in Loop: Header=BB38_288 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x2
	b.eq	LBB38_357
LBB38_301:                              ; %bb31.i.i784
                                        ;   in Loop: Header=BB38_288 Depth=3
	sub	x4, x5, #1
	and	x5, x4, x5
	cbz	x5, LBB38_343
; %bb.302:                              ; %bb17.i.i773.1
                                        ;   in Loop: Header=BB38_288 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x1
	b.lo	LBB38_307
; %bb.303:                              ; %bb19.i.i781.1
                                        ;   in Loop: Header=BB38_288 Depth=3
	cmp	x4, x3
	b.hs	LBB38_307
; %bb.304:                              ; %bb22.i.i805.1
                                        ;   in Loop: Header=BB38_288 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x26, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB38_307
; %bb.305:                              ; %bb22.i.i805.1
                                        ;   in Loop: Header=BB38_288 Depth=3
	cmp	w6, #2
	b.ne	LBB38_267
; %bb.306:                              ; %bb25.i.i810.1
                                        ;   in Loop: Header=BB38_288 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x2
	b.eq	LBB38_357
LBB38_307:                              ; %bb31.i.i784.1
                                        ;   in Loop: Header=BB38_288 Depth=3
	sub	x4, x5, #1
	and	x5, x4, x5
	cbz	x5, LBB38_343
; %bb.308:                              ; %bb17.i.i773.2
                                        ;   in Loop: Header=BB38_288 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x1
	b.lo	LBB38_313
; %bb.309:                              ; %bb19.i.i781.2
                                        ;   in Loop: Header=BB38_288 Depth=3
	cmp	x4, x3
	b.hs	LBB38_313
; %bb.310:                              ; %bb22.i.i805.2
                                        ;   in Loop: Header=BB38_288 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x26, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB38_313
; %bb.311:                              ; %bb22.i.i805.2
                                        ;   in Loop: Header=BB38_288 Depth=3
	cmp	w6, #2
	b.ne	LBB38_267
; %bb.312:                              ; %bb25.i.i810.2
                                        ;   in Loop: Header=BB38_288 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x2
	b.eq	LBB38_357
LBB38_313:                              ; %bb31.i.i784.2
                                        ;   in Loop: Header=BB38_288 Depth=3
	sub	x4, x5, #1
	and	x5, x4, x5
	cbz	x5, LBB38_343
; %bb.314:                              ; %bb17.i.i773.3
                                        ;   in Loop: Header=BB38_288 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x1
	b.lo	LBB38_319
; %bb.315:                              ; %bb19.i.i781.3
                                        ;   in Loop: Header=BB38_288 Depth=3
	cmp	x4, x3
	b.hs	LBB38_319
; %bb.316:                              ; %bb22.i.i805.3
                                        ;   in Loop: Header=BB38_288 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x26, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB38_319
; %bb.317:                              ; %bb22.i.i805.3
                                        ;   in Loop: Header=BB38_288 Depth=3
	cmp	w6, #2
	b.ne	LBB38_267
; %bb.318:                              ; %bb25.i.i810.3
                                        ;   in Loop: Header=BB38_288 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x2
	b.eq	LBB38_357
LBB38_319:                              ; %bb31.i.i784.3
                                        ;   in Loop: Header=BB38_288 Depth=3
	sub	x4, x5, #1
	and	x5, x4, x5
	cbz	x5, LBB38_343
; %bb.320:                              ; %bb17.i.i773.4
                                        ;   in Loop: Header=BB38_288 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x1
	b.lo	LBB38_325
; %bb.321:                              ; %bb19.i.i781.4
                                        ;   in Loop: Header=BB38_288 Depth=3
	cmp	x4, x3
	b.hs	LBB38_325
; %bb.322:                              ; %bb22.i.i805.4
                                        ;   in Loop: Header=BB38_288 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x26, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB38_325
; %bb.323:                              ; %bb22.i.i805.4
                                        ;   in Loop: Header=BB38_288 Depth=3
	cmp	w6, #2
	b.ne	LBB38_267
; %bb.324:                              ; %bb25.i.i810.4
                                        ;   in Loop: Header=BB38_288 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x2
	b.eq	LBB38_357
LBB38_325:                              ; %bb31.i.i784.4
                                        ;   in Loop: Header=BB38_288 Depth=3
	sub	x4, x5, #1
	and	x5, x4, x5
	cbz	x5, LBB38_343
; %bb.326:                              ; %bb17.i.i773.5
                                        ;   in Loop: Header=BB38_288 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x1
	b.lo	LBB38_331
; %bb.327:                              ; %bb19.i.i781.5
                                        ;   in Loop: Header=BB38_288 Depth=3
	cmp	x4, x3
	b.hs	LBB38_331
; %bb.328:                              ; %bb22.i.i805.5
                                        ;   in Loop: Header=BB38_288 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x26, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB38_331
; %bb.329:                              ; %bb22.i.i805.5
                                        ;   in Loop: Header=BB38_288 Depth=3
	cmp	w6, #2
	b.ne	LBB38_267
; %bb.330:                              ; %bb25.i.i810.5
                                        ;   in Loop: Header=BB38_288 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x2
	b.eq	LBB38_357
LBB38_331:                              ; %bb31.i.i784.5
                                        ;   in Loop: Header=BB38_288 Depth=3
	sub	x4, x5, #1
	and	x5, x4, x5
	cbz	x5, LBB38_343
; %bb.332:                              ; %bb17.i.i773.6
                                        ;   in Loop: Header=BB38_288 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x1
	b.lo	LBB38_337
; %bb.333:                              ; %bb19.i.i781.6
                                        ;   in Loop: Header=BB38_288 Depth=3
	cmp	x4, x3
	b.hs	LBB38_337
; %bb.334:                              ; %bb22.i.i805.6
                                        ;   in Loop: Header=BB38_288 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x26, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB38_337
; %bb.335:                              ; %bb22.i.i805.6
                                        ;   in Loop: Header=BB38_288 Depth=3
	cmp	w6, #2
	b.ne	LBB38_267
; %bb.336:                              ; %bb25.i.i810.6
                                        ;   in Loop: Header=BB38_288 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x2
	b.eq	LBB38_357
LBB38_337:                              ; %bb31.i.i784.6
                                        ;   in Loop: Header=BB38_288 Depth=3
	sub	x4, x5, #1
	and	x4, x4, x5
	cbz	x4, LBB38_343
; %bb.338:                              ; %bb17.i.i773.7
                                        ;   in Loop: Header=BB38_288 Depth=3
	rbit	x4, x4
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x1, x4, x1
	b.lo	LBB38_343
; %bb.339:                              ; %bb19.i.i781.7
                                        ;   in Loop: Header=BB38_288 Depth=3
	cmp	x1, x3
	b.hs	LBB38_343
; %bb.340:                              ; %bb22.i.i805.7
                                        ;   in Loop: Header=BB38_288 Depth=3
	add	x1, x1, x12
	madd	x4, x1, x26, x9
	ldr	w1, [x4, #16]!
	cmp	w1, #1
	b.eq	LBB38_343
; %bb.341:                              ; %bb22.i.i805.7
                                        ;   in Loop: Header=BB38_288 Depth=3
	cmp	w1, #2
	b.ne	LBB38_457
; %bb.342:                              ; %bb25.i.i810.7
                                        ;   in Loop: Header=BB38_288 Depth=3
	ldr	x1, [x4, #8]
	cmp	x1, x2
	b.eq	LBB38_357
LBB38_343:                              ; %bb14.i.i789
                                        ;   in Loop: Header=BB38_288 Depth=3
	cmp	x3, x0
	b.lo	LBB38_268
; %bb.344:                              ; %bb34.i.i791
                                        ;   in Loop: Header=BB38_288 Depth=3
	add	x12, x0, x12
	cmp	x12, x10
	csel	x12, x12, xzr, lo
	cmp	x16, x10
	b.hs	LBB38_268
; %bb.345:                              ; %bb34.i.i791
                                        ;   in Loop: Header=BB38_288 Depth=3
	add	x16, x16, #1
	sub	x17, x17, x0
	cbnz	x17, LBB38_288
	b	LBB38_268
LBB38_346:                              ; %bb69
                                        ;   in Loop: Header=BB38_271 Depth=2
	add	x0, sp, #640
	add	x1, x27, #464
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	add	x3, x8, x28
	add	x4, x27, #448
	bl	_wf_hash_map.hash_map_try_put$instance$fde7c6722a8b0dad
	ldr	w8, [sp, #640]
	cbz	w8, LBB38_353
; %bb.347:                              ; %bb69
                                        ;   in Loop: Header=BB38_271 Depth=2
	cmp	w8, #1
	b.ne	LBB38_249
; %bb.348:                              ; %bb2.i205
                                        ;   in Loop: Header=BB38_271 Depth=2
	ldrb	w8, [sp, #644]
	add	x9, sp, #640
	ldur	q0, [x9, #8]
	add	x20, sp, #640
	stur	q0, [x9, #24]
	ldr	x30, [sp, #64]                  ; 8-byte Folded Reload
	tbz	w8, #0, LBB38_358
; %bb.349:                              ; %bb4.i211
                                        ;   in Loop: Header=BB38_271 Depth=2
	ldr	x8, [sp, #544]
	ldr	x8, [x8]
	cmp	x8, #4, lsl #12                 ; =16384
	b.lo	LBB38_363
; %bb.350:                              ; %bb6.i231
                                        ;   in Loop: Header=BB38_271 Depth=2
	str	x21, [sp, #288]
	strb	w21, [sp, #292]
	b	LBB38_359
LBB38_351:                              ; %bb90
                                        ;   in Loop: Header=BB38_271 Depth=2
	add	x0, x27, #464
	add	x1, x27, #552
	add	x2, x27, #448
	bl	_wf_hash_map.hash_map_find$instance$fde7c6722a8b0dad
	cbz	w0, LBB38_355
; %bb.352:                              ; %bb90
                                        ;   in Loop: Header=BB38_271 Depth=2
	cmp	w0, #1
	ldr	x30, [sp, #64]                  ; 8-byte Folded Reload
	b.eq	LBB38_356
	b	LBB38_249
LBB38_353:                              ; %"wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit236.thread998"
                                        ;   in Loop: Header=BB38_271 Depth=2
	stp	xzr, xzr, [x27, #208]
	stur	xzr, [x27, #224]
LBB38_354:                              ; %bb72
                                        ;   in Loop: Header=BB38_271 Depth=2
	ldr	x8, [sp, #584]
	mul	x8, x8, x20
	ldr	x30, [sp, #64]                  ; 8-byte Folded Reload
	b	LBB38_269
LBB38_355:                              ; %bb1.i.i410
                                        ;   in Loop: Header=BB38_271 Depth=2
	ldr	x8, [sp, #544]
	madd	x8, x1, x26, x8
	ldr	w9, [x8, #16]!
	cmp	w9, #2
	ldr	x30, [sp, #64]                  ; 8-byte Folded Reload
	b.hs	LBB38_361
LBB38_356:                              ; %bb3.i423
                                        ;   in Loop: Header=BB38_271 Depth=2
	str	w21, [sp, #432]
	str	xzr, [sp, #440]
	strb	wzr, [sp, #448]
	b	LBB38_445
LBB38_357:                              ; %bb2.i194
                                        ;   in Loop: Header=BB38_271 Depth=2
	ldr	x9, [x4, #16]
	str	wzr, [sp, #264]
	str	x9, [sp, #272]
	strb	wzr, [sp, #280]
	mov	w10, #17161                     ; =0x4309
	madd	x8, x8, x10, x9
	add	x8, x8, #131
	b	LBB38_269
LBB38_358:                              ; %bb3.i209
                                        ;   in Loop: Header=BB38_271 Depth=2
	str	x21, [sp, #288]
LBB38_359:                              ; %"wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit236.thread"
                                        ;   in Loop: Header=BB38_271 Depth=2
	ldur	q0, [x20, #8]
	add	x9, sp, #80
	stur	q0, [x9, #216]
	mov	w20, #131                       ; =0x83
LBB38_360:                              ; %bb73
                                        ;   in Loop: Header=BB38_271 Depth=2
	ldrb	w8, [sp, #292]
	ldur	q0, [x9, #216]
	stur	q0, [x27, #232]
	ldr	x9, [sp, #584]
	cmp	w8, #0
	cinc	x8, x21, ne
	madd	x8, x9, x20, x8
	ldp	x9, x10, [sp, #312]
	b	LBB38_449
LBB38_361:                              ; %bb1.i.i410
                                        ;   in Loop: Header=BB38_271 Depth=2
	b.ne	LBB38_249
; %bb.362:                              ; %bb2.i428
                                        ;   in Loop: Header=BB38_271 Depth=2
	ldr	x9, [x8, #16]
	add	x10, x9, #1
	str	x10, [x8, #16]
	str	wzr, [sp, #432]
	str	x10, [sp, #440]
	strb	wzr, [sp, #448]
	ldr	x8, [sp, #584]
	mov	w10, #17161                     ; =0x4309
	madd	x8, x8, x10, x9
	add	x8, x8, #132
	b	LBB38_269
LBB38_363:                              ; %bb7.i215
                                        ;   in Loop: Header=BB38_271 Depth=2
	cmp	x8, #2, lsl #12                 ; =8192
	mov	w9, #8192                       ; =0x2000
	csel	x9, x8, x9, lo
	lsl	x9, x9, #1
	cmp	x8, #0
	csinc	x1, x9, xzr, ne
	cmp	x1, x8
	b.ls	LBB38_435
; %bb.364:                              ; %"wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit.i224"
                                        ;   in Loop: Header=BB38_271 Depth=2
	add	x0, x27, #464
	add	x2, x27, #448
	bl	_wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	cbz	w0, LBB38_435
; %bb.365:                              ; %"wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit.i224"
                                        ;   in Loop: Header=BB38_271 Depth=2
	cmp	w0, #1
	b.ne	LBB38_249
; %bb.366:                              ; %bb18.i227
                                        ;   in Loop: Header=BB38_271 Depth=2
	str	x21, [sp, #288]
	strb	w21, [sp, #292]
	ldr	x30, [sp, #64]                  ; 8-byte Folded Reload
	b	LBB38_359
LBB38_367:                              ; %bb2.i.i.i302
                                        ;   in Loop: Header=BB38_271 Depth=2
	cmp	x1, #8
	b.hs	LBB38_369
LBB38_368:                              ; %bb11.i.i.i293
                                        ;   in Loop: Header=BB38_271 Depth=2
	ldr	x11, [sp, #560]
	and	x10, x11, x10
	orr	x9, x10, x9
	str	x9, [sp, #560]
LBB38_369:                              ; %wf_hash_map.hash_map_control_set.exit.i.i289
                                        ;   in Loop: Header=BB38_271 Depth=2
	cmp	w8, #2
	b.hs	LBB38_372
LBB38_370:                              ; %bb82
                                        ;   in Loop: Header=BB38_271 Depth=2
	str	wzr, [sp, #328]
	add	x8, sp, #80
	stp	xzr, xzr, [x8, #256]
	ldr	x8, [sp, #584]
	mov	w20, #131                       ; =0x83
	mul	x8, x8, x20
	str	x8, [sp, #584]
	ldrb	w9, [sp, #536]
	ldr	x2, [sp, #632]
	tbz	w9, #0, LBB38_374
LBB38_371:                              ;   in Loop: Header=BB38_271 Depth=2
	mov	x11, #0                         ; =0x0
	ldr	x9, [sp, #544]
	ldr	x10, [x9]
	cbnz	x10, LBB38_375
	b	LBB38_438
LBB38_372:                              ; %wf_hash_map.hash_map_control_set.exit.i.i289
                                        ;   in Loop: Header=BB38_271 Depth=2
	b.ne	LBB38_249
; %bb.373:                              ; %bb81
                                        ;   in Loop: Header=BB38_271 Depth=2
	sub	x8, x20, #1
	str	x8, [sp, #552]
	str	w21, [sp, #328]
	str	q0, [sp, #336]
	add	x8, sp, #80
	ldr	q0, [x8, #256]
	str	q0, [x27, #272]
	ldr	x8, [sp, #584]
	ldp	x9, x10, [sp, #352]
	mov	w20, #131                       ; =0x83
	madd	x8, x8, x20, x9
	madd	x8, x8, x20, x10
	add	x8, x8, #131
	str	x8, [sp, #584]
	ldrb	w9, [sp, #536]
	ldr	x2, [sp, #632]
	tbnz	w9, #0, LBB38_371
LBB38_374:                              ; %bb3.i.i.i825
                                        ;   in Loop: Header=BB38_271 Depth=2
	ldr	x9, [sp, #528]
	eor	x9, x2, x9
	eor	x9, x9, x9, lsr #30
	mov	x10, #58809                     ; =0xe5b9
	movk	x10, #7396, lsl #16
	movk	x10, #18285, lsl #32
	movk	x10, #48984, lsl #48
	mul	x9, x9, x10
	eor	x9, x9, x9, lsr #27
	mov	x10, #4587                      ; =0x11eb
	movk	x10, #4913, lsl #16
	movk	x10, #18875, lsl #32
	movk	x10, #38096, lsl #48
	mul	x9, x9, x10
	eor	x11, x9, x9, lsr #31
	ldr	x9, [sp, #544]
	ldr	x10, [x9]
	cbz	x10, LBB38_438
LBB38_375:                              ; %bb3.i.i841
                                        ;   in Loop: Header=BB38_271 Depth=2
	lsr	x14, x11, #57
	udiv	x12, x11, x10
	msub	x12, x12, x10, x11
	ldr	x11, [sp, #568]
	ldr	x13, [sp, #560]
	mov	x15, #72340172838076673         ; =0x101010101010101
	mul	x14, x14, x15
	ldr	x15, [sp, #576]
	mov	w16, #1                         ; =0x1
	mov	x17, x10
LBB38_376:                              ; %bb10.i.i851
                                        ;   Parent Loop BB38_252 Depth=1
                                        ;     Parent Loop BB38_271 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	x1, x12, #0x7
	sub	x0, x10, x12
	sub	x3, x19, x1
	cmp	x3, x0
	csel	x0, x3, x0, lo
	cmp	x0, x17
	csel	x0, x0, x17, lo
	cbz	x11, LBB38_379
; %bb.377:                              ; %bb3.i21.i.i861
                                        ;   in Loop: Header=BB38_376 Depth=3
	lsr	x3, x12, #3
	ldr	x4, [x15]
	cmp	x3, x4
	b.hs	LBB38_380
; %bb.378:                              ; %bb8.i.i.i938
                                        ;   in Loop: Header=BB38_376 Depth=3
	add	x3, x15, x3, lsl #3
	ldr	x4, [x3, #8]
	b	LBB38_381
LBB38_379:                              ; %bb2.i.i.i941
                                        ;   in Loop: Header=BB38_376 Depth=3
	cmp	x12, #8
	csel	x4, x13, x25, lo
	b	LBB38_381
LBB38_380:                              ; %bb9.i.i.i865
                                        ;   in Loop: Header=BB38_376 Depth=3
	csel	x4, x13, x25, eq
LBB38_381:                              ; %wf_hash_map.hash_map_control_word.exit.i.i868
                                        ;   in Loop: Header=BB38_376 Depth=3
	lsl	x3, x0, #3
	neg	x3, x3
	lsr	x3, x25, x3
	lsl	x5, x1, #3
	lsl	x5, x3, x5
	and	x3, x4, #0x7f7f7f7f7f7f7f7f
	sub	x3, x25, x3
	and	x3, x3, x4
	and	x3, x5, x3
	cmp	x3, #0
	rbit	x3, x3
	clz	x3, x3
	lsr	x6, x3, #3
	ccmp	x6, x1, #0, ne
	mov	x3, x0
	b.hs	LBB38_383
; %bb.382:                              ; %wf_hash_map.hash_map_control_stop.exit.i.i892
                                        ;   in Loop: Header=BB38_376 Depth=3
	eor	x4, x4, x14
	and	x6, x4, #0x7f7f7f7f7f7f7f7f
	add	x6, x6, x23
	orr	x4, x6, x4
	bic	x5, x5, x4
	cbnz	x5, LBB38_384
	b	LBB38_431
LBB38_383:                              ; %bb5.i.i.i889
                                        ;   in Loop: Header=BB38_376 Depth=3
	sub	x3, x6, x1
	cmp	x3, x0
	csel	x3, x3, x0, lo
	eor	x4, x4, x14
	and	x6, x4, #0x7f7f7f7f7f7f7f7f
	add	x6, x6, x23
	orr	x4, x6, x4
	bic	x5, x5, x4
	cbz	x5, LBB38_431
LBB38_384:                              ; %bb17.i.i895
                                        ;   in Loop: Header=BB38_376 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x1
	b.lo	LBB38_389
; %bb.385:                              ; %bb19.i.i903
                                        ;   in Loop: Header=BB38_376 Depth=3
	cmp	x4, x3
	b.hs	LBB38_389
; %bb.386:                              ; %bb22.i.i927
                                        ;   in Loop: Header=BB38_376 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x26, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB38_389
; %bb.387:                              ; %bb22.i.i927
                                        ;   in Loop: Header=BB38_376 Depth=3
	cmp	w6, #2
	b.ne	LBB38_437
; %bb.388:                              ; %bb25.i.i932
                                        ;   in Loop: Header=BB38_376 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x2
	b.eq	LBB38_456
LBB38_389:                              ; %bb31.i.i906
                                        ;   in Loop: Header=BB38_376 Depth=3
	sub	x4, x5, #1
	and	x5, x4, x5
	cbz	x5, LBB38_431
; %bb.390:                              ; %bb17.i.i895.1
                                        ;   in Loop: Header=BB38_376 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x1
	b.lo	LBB38_395
; %bb.391:                              ; %bb19.i.i903.1
                                        ;   in Loop: Header=BB38_376 Depth=3
	cmp	x4, x3
	b.hs	LBB38_395
; %bb.392:                              ; %bb22.i.i927.1
                                        ;   in Loop: Header=BB38_376 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x26, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB38_395
; %bb.393:                              ; %bb22.i.i927.1
                                        ;   in Loop: Header=BB38_376 Depth=3
	cmp	w6, #2
	b.ne	LBB38_437
; %bb.394:                              ; %bb25.i.i932.1
                                        ;   in Loop: Header=BB38_376 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x2
	b.eq	LBB38_456
LBB38_395:                              ; %bb31.i.i906.1
                                        ;   in Loop: Header=BB38_376 Depth=3
	sub	x4, x5, #1
	and	x5, x4, x5
	cbz	x5, LBB38_431
; %bb.396:                              ; %bb17.i.i895.2
                                        ;   in Loop: Header=BB38_376 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x1
	b.lo	LBB38_401
; %bb.397:                              ; %bb19.i.i903.2
                                        ;   in Loop: Header=BB38_376 Depth=3
	cmp	x4, x3
	b.hs	LBB38_401
; %bb.398:                              ; %bb22.i.i927.2
                                        ;   in Loop: Header=BB38_376 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x26, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB38_401
; %bb.399:                              ; %bb22.i.i927.2
                                        ;   in Loop: Header=BB38_376 Depth=3
	cmp	w6, #2
	b.ne	LBB38_437
; %bb.400:                              ; %bb25.i.i932.2
                                        ;   in Loop: Header=BB38_376 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x2
	b.eq	LBB38_456
LBB38_401:                              ; %bb31.i.i906.2
                                        ;   in Loop: Header=BB38_376 Depth=3
	sub	x4, x5, #1
	and	x5, x4, x5
	cbz	x5, LBB38_431
; %bb.402:                              ; %bb17.i.i895.3
                                        ;   in Loop: Header=BB38_376 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x1
	b.lo	LBB38_407
; %bb.403:                              ; %bb19.i.i903.3
                                        ;   in Loop: Header=BB38_376 Depth=3
	cmp	x4, x3
	b.hs	LBB38_407
; %bb.404:                              ; %bb22.i.i927.3
                                        ;   in Loop: Header=BB38_376 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x26, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB38_407
; %bb.405:                              ; %bb22.i.i927.3
                                        ;   in Loop: Header=BB38_376 Depth=3
	cmp	w6, #2
	b.ne	LBB38_437
; %bb.406:                              ; %bb25.i.i932.3
                                        ;   in Loop: Header=BB38_376 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x2
	b.eq	LBB38_456
LBB38_407:                              ; %bb31.i.i906.3
                                        ;   in Loop: Header=BB38_376 Depth=3
	sub	x4, x5, #1
	and	x5, x4, x5
	cbz	x5, LBB38_431
; %bb.408:                              ; %bb17.i.i895.4
                                        ;   in Loop: Header=BB38_376 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x1
	b.lo	LBB38_413
; %bb.409:                              ; %bb19.i.i903.4
                                        ;   in Loop: Header=BB38_376 Depth=3
	cmp	x4, x3
	b.hs	LBB38_413
; %bb.410:                              ; %bb22.i.i927.4
                                        ;   in Loop: Header=BB38_376 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x26, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB38_413
; %bb.411:                              ; %bb22.i.i927.4
                                        ;   in Loop: Header=BB38_376 Depth=3
	cmp	w6, #2
	b.ne	LBB38_437
; %bb.412:                              ; %bb25.i.i932.4
                                        ;   in Loop: Header=BB38_376 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x2
	b.eq	LBB38_456
LBB38_413:                              ; %bb31.i.i906.4
                                        ;   in Loop: Header=BB38_376 Depth=3
	sub	x4, x5, #1
	and	x5, x4, x5
	cbz	x5, LBB38_431
; %bb.414:                              ; %bb17.i.i895.5
                                        ;   in Loop: Header=BB38_376 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x1
	b.lo	LBB38_419
; %bb.415:                              ; %bb19.i.i903.5
                                        ;   in Loop: Header=BB38_376 Depth=3
	cmp	x4, x3
	b.hs	LBB38_419
; %bb.416:                              ; %bb22.i.i927.5
                                        ;   in Loop: Header=BB38_376 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x26, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB38_419
; %bb.417:                              ; %bb22.i.i927.5
                                        ;   in Loop: Header=BB38_376 Depth=3
	cmp	w6, #2
	b.ne	LBB38_437
; %bb.418:                              ; %bb25.i.i932.5
                                        ;   in Loop: Header=BB38_376 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x2
	b.eq	LBB38_456
LBB38_419:                              ; %bb31.i.i906.5
                                        ;   in Loop: Header=BB38_376 Depth=3
	sub	x4, x5, #1
	and	x5, x4, x5
	cbz	x5, LBB38_431
; %bb.420:                              ; %bb17.i.i895.6
                                        ;   in Loop: Header=BB38_376 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x1
	b.lo	LBB38_425
; %bb.421:                              ; %bb19.i.i903.6
                                        ;   in Loop: Header=BB38_376 Depth=3
	cmp	x4, x3
	b.hs	LBB38_425
; %bb.422:                              ; %bb22.i.i927.6
                                        ;   in Loop: Header=BB38_376 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x26, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB38_425
; %bb.423:                              ; %bb22.i.i927.6
                                        ;   in Loop: Header=BB38_376 Depth=3
	cmp	w6, #2
	b.ne	LBB38_437
; %bb.424:                              ; %bb25.i.i932.6
                                        ;   in Loop: Header=BB38_376 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x2
	b.eq	LBB38_456
LBB38_425:                              ; %bb31.i.i906.6
                                        ;   in Loop: Header=BB38_376 Depth=3
	sub	x4, x5, #1
	and	x4, x4, x5
	cbz	x4, LBB38_431
; %bb.426:                              ; %bb17.i.i895.7
                                        ;   in Loop: Header=BB38_376 Depth=3
	rbit	x4, x4
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x1, x4, x1
	b.lo	LBB38_431
; %bb.427:                              ; %bb19.i.i903.7
                                        ;   in Loop: Header=BB38_376 Depth=3
	cmp	x1, x3
	b.hs	LBB38_431
; %bb.428:                              ; %bb22.i.i927.7
                                        ;   in Loop: Header=BB38_376 Depth=3
	add	x1, x1, x12
	madd	x4, x1, x26, x9
	ldr	w1, [x4, #16]!
	cmp	w1, #1
	b.eq	LBB38_431
; %bb.429:                              ; %bb22.i.i927.7
                                        ;   in Loop: Header=BB38_376 Depth=3
	cmp	w1, #2
	b.ne	LBB38_458
; %bb.430:                              ; %bb25.i.i932.7
                                        ;   in Loop: Header=BB38_376 Depth=3
	ldr	x1, [x4, #8]
	cmp	x1, x2
	b.eq	LBB38_456
LBB38_431:                              ; %bb14.i.i911
                                        ;   in Loop: Header=BB38_376 Depth=3
	cmp	x3, x0
	b.lo	LBB38_438
; %bb.432:                              ; %bb34.i.i913
                                        ;   in Loop: Header=BB38_376 Depth=3
	add	x12, x0, x12
	cmp	x12, x10
	csel	x12, x12, xzr, lo
	cmp	x16, x10
	b.hs	LBB38_438
; %bb.433:                              ; %bb34.i.i913
                                        ;   in Loop: Header=BB38_376 Depth=3
	add	x16, x16, #1
	sub	x17, x17, x0
	cbnz	x17, LBB38_376
	b	LBB38_438
LBB38_434:                              ; %bb9.i.i.i287
                                        ;   in Loop: Header=BB38_271 Depth=2
	b.eq	LBB38_368
	b	LBB38_369
LBB38_435:                              ; %"wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit236"
                                        ;   in Loop: Header=BB38_271 Depth=2
	ldr	x2, [sp, #664]
	ldr	x3, [sp, #672]
	add	x0, x27, #208
	add	x1, x27, #464
	add	x4, x27, #448
	bl	_wf_hash_map.hash_map_try_put$instance$fde7c6722a8b0dad
	ldr	w8, [sp, #288]
	mov	w20, #131                       ; =0x83
	cbz	w8, LBB38_354
; %bb.436:                              ; %"wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit236"
                                        ;   in Loop: Header=BB38_271 Depth=2
	cmp	w8, #1
	ldr	x30, [sp, #64]                  ; 8-byte Folded Reload
	add	x9, sp, #80
	b.eq	LBB38_360
	b	LBB38_249
LBB38_437:                              ; %bb22.i.i927
                                        ;   in Loop: Header=BB38_271 Depth=2
	cbnz	w6, LBB38_249
LBB38_438:                              ; %bb3.i330
                                        ;   in Loop: Header=BB38_271 Depth=2
	str	w21, [sp, #368]
	str	xzr, [sp, #376]
	mul	x8, x8, x20
	strb	wzr, [sp, #384]
LBB38_439:                              ; %wf_map_cost_lookup_result.exit342
                                        ;   in Loop: Header=BB38_271 Depth=2
	str	x8, [sp, #584]
	add	x0, sp, #640
	add	x1, x27, #464
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	add	x3, x8, x28
	add	x4, x27, #448
	bl	_wf_hash_map.hash_map_try_put$instance$fde7c6722a8b0dad
	ldr	w8, [sp, #640]
	cbz	w8, LBB38_444
; %bb.440:                              ; %wf_map_cost_lookup_result.exit342
                                        ;   in Loop: Header=BB38_271 Depth=2
	cmp	w8, #1
	ldr	x30, [sp, #64]                  ; 8-byte Folded Reload
	b.ne	LBB38_249
; %bb.441:                              ; %bb2.i346
                                        ;   in Loop: Header=BB38_271 Depth=2
	ldrb	w8, [sp, #644]
	add	x9, sp, #640
	ldur	q0, [x9, #8]
	add	x20, sp, #640
	stur	q0, [x9, #24]
	tbz	w8, #0, LBB38_446
; %bb.442:                              ; %bb4.i352
                                        ;   in Loop: Header=BB38_271 Depth=2
	ldr	x8, [sp, #544]
	ldr	x8, [x8]
	cmp	x8, #4, lsl #12                 ; =16384
	b.lo	LBB38_450
; %bb.443:                              ; %bb6.i372
                                        ;   in Loop: Header=BB38_271 Depth=2
	str	x21, [sp, #392]
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	strb	w21, [x8]
	b	LBB38_447
LBB38_444:                              ; %"wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit377.thread1021"
                                        ;   in Loop: Header=BB38_271 Depth=2
	stp	xzr, xzr, [x27, #312]
	str	xzr, [x27, #328]
	ldr	x30, [sp, #64]                  ; 8-byte Folded Reload
LBB38_445:                              ; %bb92.sink.split
                                        ;   in Loop: Header=BB38_271 Depth=2
	ldr	x8, [sp, #584]
	mul	x8, x8, x20
	b	LBB38_269
LBB38_446:                              ; %bb3.i350
                                        ;   in Loop: Header=BB38_271 Depth=2
	str	x21, [sp, #392]
LBB38_447:                              ; %"wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit377.thread"
                                        ;   in Loop: Header=BB38_271 Depth=2
	ldur	q0, [x20, #8]
	add	x9, sp, #80
	str	q0, [x9, #320]
	mov	w20, #131                       ; =0x83
LBB38_448:                              ; %bb85
                                        ;   in Loop: Header=BB38_271 Depth=2
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	ldrb	w8, [x8]
	ldr	q0, [x9, #320]
	str	q0, [x27, #336]
	ldr	x9, [sp, #584]
	cmp	w8, #0
	cinc	x8, x21, ne
	madd	x8, x9, x20, x8
	ldp	x9, x10, [sp, #416]
LBB38_449:                              ; %bb92.sink.split
                                        ;   in Loop: Header=BB38_271 Depth=2
	add	x8, x9, x8
	madd	x8, x8, x20, x10
	b	LBB38_269
LBB38_450:                              ; %bb7.i356
                                        ;   in Loop: Header=BB38_271 Depth=2
	cmp	x8, #2, lsl #12                 ; =8192
	mov	w9, #8192                       ; =0x2000
	csel	x9, x8, x9, lo
	lsl	x9, x9, #1
	cmp	x8, #0
	csinc	x1, x9, xzr, ne
	cmp	x1, x8
	b.ls	LBB38_454
; %bb.451:                              ; %"wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit.i365"
                                        ;   in Loop: Header=BB38_271 Depth=2
	add	x0, x27, #464
	add	x2, x27, #448
	bl	_wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	cbz	w0, LBB38_454
; %bb.452:                              ; %"wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit.i365"
                                        ;   in Loop: Header=BB38_271 Depth=2
	cmp	w0, #1
	b.ne	LBB38_249
; %bb.453:                              ; %bb18.i368
                                        ;   in Loop: Header=BB38_271 Depth=2
	str	x21, [sp, #392]
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	strb	w21, [x8]
	ldr	x30, [sp, #64]                  ; 8-byte Folded Reload
	b	LBB38_447
LBB38_454:                              ; %"wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit377"
                                        ;   in Loop: Header=BB38_271 Depth=2
	ldr	x2, [sp, #664]
	ldr	x3, [sp, #672]
	add	x0, x27, #312
	add	x1, x27, #464
	add	x4, x27, #448
	bl	_wf_hash_map.hash_map_try_put$instance$fde7c6722a8b0dad
	ldr	w8, [sp, #392]
	ldr	x30, [sp, #64]                  ; 8-byte Folded Reload
	mov	w20, #131                       ; =0x83
	cbz	w8, LBB38_445
; %bb.455:                              ; %"wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit377"
                                        ;   in Loop: Header=BB38_271 Depth=2
	cmp	w8, #1
	add	x9, sp, #80
	b.eq	LBB38_448
	b	LBB38_249
LBB38_456:                              ; %bb2.i335
                                        ;   in Loop: Header=BB38_271 Depth=2
	ldr	x9, [x4, #16]
	str	wzr, [sp, #368]
	str	x9, [sp, #376]
	strb	wzr, [sp, #384]
	mov	w10, #17161                     ; =0x4309
	madd	x8, x8, x10, x9
	add	x8, x8, #131
	b	LBB38_439
LBB38_457:                              ; %bb22.i.i805.7
                                        ;   in Loop: Header=BB38_271 Depth=2
	cbz	w1, LBB38_268
	b	LBB38_249
LBB38_458:                              ; %bb22.i.i927.7
                                        ;   in Loop: Header=BB38_271 Depth=2
	cbz	w1, LBB38_438
	b	LBB38_249
LBB38_459:                              ; %bb15
	add	x19, x27, #504
	add	x8, sp, #80
	add	x0, x8, #376
	ldp	q0, q1, [x27, #464]
	stp	q0, q1, [x0]
	ldr	x8, [x27, #496]
	str	x8, [sp, #488]
	mov	x1, x19
	bl	_wf_hash_map.hash_map_free$instance$001ff12ace7d7c19
	ldp	q0, q1, [x19]
	stp	q0, q1, [sp, #496]
	ldp	x8, x9, [sp, #496]
	ldr	x10, [sp, #512]
	ldr	x11, [sp, #520]
	eor	x8, x8, x8, lsr #30
	mov	x13, #58809                     ; =0xe5b9
	movk	x13, #7396, lsl #16
	movk	x13, #18285, lsl #32
	movk	x13, #48984, lsl #48
	mul	x8, x8, x13
	eor	x8, x8, x8, lsr #27
	mov	x12, #4587                      ; =0x11eb
	movk	x12, #4913, lsl #16
	movk	x12, #18875, lsl #32
	movk	x12, #38096, lsl #48
	mul	x8, x8, x12
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x13
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x12
	eor	x12, x9, x8
	mov	x13, #31765                     ; =0x7c15
	movk	x13, #32586, lsl #16
	movk	x13, #31161, lsl #32
	movk	x13, #40503, lsl #48
	mul	x11, x11, x13
	eor	x10, x10, x11
	eor	x10, x10, x12, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	add	sp, sp, #688
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB38_460:                              ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh34, Lloh35
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_map_cost_library_policy$instance$4250cb78d3f44027
lCPI39_0:
	.quad	0                               ; 0x0
	.quad	-9187201950435737472            ; 0x8080808080808080
lCPI39_1:
	.quad	42                              ; 0x2a
	.quad	43                              ; 0x2b
lCPI39_2:
	.quad	44                              ; 0x2c
	.quad	45                              ; 0x2d
lCPI39_3:
	.quad	46                              ; 0x2e
	.quad	47                              ; 0x2f
lCPI39_4:
	.quad	48                              ; 0x30
	.quad	49                              ; 0x31
lCPI39_5:
	.quad	50                              ; 0x32
	.quad	51                              ; 0x33
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_map_cost_library_policy$instance$4250cb78d3f44027
	.p2align	2
_wf_map_cost_library_policy$instance$4250cb78d3f44027: ; @"wf_map_cost_library_policy$instance$4250cb78d3f44027"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #1936
	.cfi_def_cfa_offset 2032
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
	mov	x8, #31765                      ; =0x7c15
	movk	x8, #32586, lsl #16
	movk	x8, #31161, lsl #32
	movk	x8, #40503, lsl #48
	eor	x8, x0, x8
	cmp	x1, #0
	cset	w9, ne
	str	x8, [sp, #336]
	strb	w9, [sp, #344]
	mov	w0, #832                        ; =0x340
	bl	_malloc
	cbz	x0, LBB39_2
; %bb.1:                                ; %bb1.i.i
	str	wzr, [x0, #16]
	add	x8, x0, #296
	add	x9, x0, #568
	str	xzr, [x0, #824]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9]
	stp	q0, q0, [x9, #32]
	stp	q0, q0, [x9, #64]
	stp	q0, q0, [x9, #96]
	stp	q0, q0, [x9, #128]
	stp	q0, q0, [x9, #160]
	stp	q0, q0, [x9, #192]
	stp	q0, q0, [x9, #224]
	stur	q0, [x0, #248]
	stur	q0, [x0, #232]
	stur	q0, [x0, #216]
	stur	q0, [x0, #200]
	stur	q0, [x0, #184]
	stur	q0, [x0, #168]
	stur	q0, [x0, #152]
	stur	q0, [x0, #136]
	stur	q0, [x0, #120]
	stur	q0, [x0, #104]
	stur	q0, [x0, #88]
	stur	q0, [x0, #72]
	stur	q0, [x0, #56]
	stur	q0, [x0, #40]
	mov	x9, x0
	str	q0, [x9, #24]!
	stur	q0, [x9, #252]
	str	q0, [x9, #240]
	stur	q0, [x8, #252]
	stp	q0, q0, [x8, #224]
	stp	q0, q0, [x8, #192]
	stp	q0, q0, [x8, #160]
	stp	q0, q0, [x8, #128]
	stp	q0, q0, [x8, #96]
	stp	q0, q0, [x8, #64]
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8]
	mov	w8, #3                          ; =0x3
	dup.2d	v0, x8
	str	q0, [x0]
	str	x0, [sp, #296]
Lloh36:
	adrp	x8, lCPI39_0@PAGE
Lloh37:
	ldr	q0, [x8, lCPI39_0@PAGEOFF]
	add	x8, sp, #49
	stur	q0, [x8, #255]
	stp	xzr, xzr, [sp, #320]
	add	x8, x19, #1
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	add	x24, x19, #2
	add	x25, x19, #3
	stp	x25, x24, [sp, #144]            ; 16-byte Folded Spill
	add	x26, x19, #4
	add	x27, x19, #5
	stp	x27, x26, [sp, #128]            ; 16-byte Folded Spill
	add	x28, x19, #6
	add	x30, x19, #7
	stp	x30, x28, [sp, #112]            ; 16-byte Folded Spill
	add	x9, x19, #8
	add	x8, x19, #9
	stp	x8, x9, [sp, #16]               ; 16-byte Folded Spill
	add	x21, x19, #10
	add	x22, x19, #11
	add	x23, x19, #12
	stp	x23, x22, [sp, #240]            ; 16-byte Folded Spill
	add	x20, x19, #13
	add	x7, x19, #14
	add	x6, x19, #15
	add	x5, x19, #16
	stp	x6, x5, [sp, #192]              ; 16-byte Folded Spill
	add	x4, x19, #17
	add	x3, x19, #18
	add	x2, x19, #19
	add	x8, x19, #20
	str	x8, [sp, #256]                  ; 8-byte Folded Spill
	add	x9, x19, #21
	add	x10, x19, #22
	stp	x10, x9, [sp, #56]              ; 16-byte Folded Spill
	add	x11, x19, #23
	add	x12, x19, #24
	stp	x12, x11, [sp, #40]             ; 16-byte Folded Spill
	add	x13, x19, #25
	str	x13, [sp, #32]                  ; 8-byte Folded Spill
	add	x14, x19, #26
	add	x15, x19, #27
	stp	x15, x14, [sp, #224]            ; 16-byte Folded Spill
	add	x16, x19, #28
	add	x17, x19, #29
	stp	x17, x16, [sp, #208]            ; 16-byte Folded Spill
	add	x0, x19, #30
	add	x1, x19, #31
	stp	x1, x0, [sp, #168]              ; 16-byte Folded Spill
	stp	x19, xzr, [sp, #264]
	stp	xzr, xzr, [sp, #280]
	str	x19, [sp, #1680]
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	str	x8, [sp, #1688]
	str	x24, [sp, #1696]
	str	x25, [sp, #1704]
	str	x26, [sp, #1712]
	str	x27, [sp, #1720]
	str	x28, [sp, #1728]
	str	x30, [sp, #1736]
	ldp	x25, x24, [sp, #16]             ; 16-byte Folded Reload
	str	x24, [sp, #1744]
	str	x25, [sp, #1752]
	str	x21, [sp, #1760]
	mov	x28, x21
	stp	x21, x20, [sp, #80]             ; 16-byte Folded Spill
	str	x22, [sp, #1768]
	str	x23, [sp, #1776]
	str	x20, [sp, #1784]
	mov	x27, x20
	str	x7, [sp, #1792]
	mov	x26, x7
	stp	x7, x4, [sp, #96]               ; 16-byte Folded Spill
	str	x6, [sp, #1800]
	str	x5, [sp, #1808]
	str	x4, [sp, #1816]
	mov	x23, x4
	str	x3, [sp, #1824]
	mov	x22, x3
	str	x3, [sp, #160]                  ; 8-byte Folded Spill
	str	x2, [sp, #1832]
	mov	x21, x2
	str	x2, [sp, #184]                  ; 8-byte Folded Spill
	ldr	x20, [sp, #256]                 ; 8-byte Folded Reload
	str	x20, [sp, #1840]
	str	x9, [sp, #1848]
	str	x10, [sp, #1856]
	str	x11, [sp, #1864]
	str	x12, [sp, #1872]
	str	x13, [sp, #1880]
	str	x14, [sp, #1888]
	str	x15, [sp, #1896]
	str	x16, [sp, #1904]
	str	x17, [sp, #1912]
	str	x0, [sp, #1920]
	str	x1, [sp, #1928]
	add	x0, sp, #1408
	add	x1, sp, #296
	add	x3, sp, #1680
	add	x4, sp, #336
	mov	w2, #1                          ; =0x1
	bl	_wf_hash_map.hash_map_put$instance$8d5197e2f00c3b07
	add	x0, sp, #1408
	add	x1, sp, #264
	bl	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	str	x8, [sp, #1680]
	add	x8, x19, #32
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	ldp	x9, x10, [sp, #144]             ; 16-byte Folded Reload
	str	x10, [sp, #1688]
	str	x9, [sp, #1696]
	ldp	x9, x10, [sp, #128]             ; 16-byte Folded Reload
	str	x10, [sp, #1704]
	str	x9, [sp, #1712]
	ldp	x9, x10, [sp, #112]             ; 16-byte Folded Reload
	str	x10, [sp, #1720]
	str	x9, [sp, #1728]
	str	x24, [sp, #1736]
	str	x25, [sp, #1744]
	str	x28, [sp, #1752]
	ldp	x9, x10, [sp, #240]             ; 16-byte Folded Reload
	str	x10, [sp, #1760]
	str	x9, [sp, #1768]
	str	x27, [sp, #1776]
	str	x26, [sp, #1784]
	ldp	x10, x9, [sp, #192]             ; 16-byte Folded Reload
	str	x10, [sp, #1792]
	str	x9, [sp, #1800]
	str	x23, [sp, #1808]
	str	x22, [sp, #1816]
	str	x21, [sp, #1824]
	str	x20, [sp, #1832]
	ldp	x22, x21, [sp, #56]             ; 16-byte Folded Reload
	str	x21, [sp, #1840]
	str	x22, [sp, #1848]
	ldp	x24, x23, [sp, #40]             ; 16-byte Folded Reload
	str	x23, [sp, #1856]
	str	x24, [sp, #1864]
	ldr	x25, [sp, #32]                  ; 8-byte Folded Reload
	str	x25, [sp, #1872]
	ldp	x27, x26, [sp, #224]            ; 16-byte Folded Reload
	str	x26, [sp, #1880]
	str	x27, [sp, #1888]
	ldp	x20, x28, [sp, #208]            ; 16-byte Folded Reload
	str	x28, [sp, #1896]
	str	x20, [sp, #1904]
	ldp	x9, x10, [sp, #168]             ; 16-byte Folded Reload
	str	x10, [sp, #1912]
	str	x9, [sp, #1920]
	str	x8, [sp, #1928]
	add	x0, sp, #1408
	add	x1, sp, #296
	add	x3, sp, #1680
	add	x4, sp, #336
	mov	w2, #3                          ; =0x3
	bl	_wf_hash_map.hash_map_put$instance$8d5197e2f00c3b07
	add	x0, sp, #1408
	add	x1, sp, #264
	bl	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
	ldp	x8, x9, [sp, #144]              ; 16-byte Folded Reload
	str	x9, [sp, #1680]
	str	x8, [sp, #1688]
	ldp	x8, x9, [sp, #128]              ; 16-byte Folded Reload
	str	x9, [sp, #1696]
	str	x8, [sp, #1704]
	ldp	x8, x9, [sp, #112]              ; 16-byte Folded Reload
	str	x9, [sp, #1712]
	str	x8, [sp, #1720]
	ldp	x8, x9, [sp, #16]               ; 16-byte Folded Reload
	str	x9, [sp, #1728]
	str	x8, [sp, #1736]
	add	x9, x19, #33
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	str	x8, [sp, #1744]
	ldp	x8, x10, [sp, #240]             ; 16-byte Folded Reload
	str	x10, [sp, #1752]
	str	x8, [sp, #1760]
	ldp	x10, x8, [sp, #88]              ; 16-byte Folded Reload
	str	x10, [sp, #1768]
	str	x8, [sp, #1776]
	ldp	x10, x8, [sp, #192]             ; 16-byte Folded Reload
	str	x10, [sp, #1784]
	str	x8, [sp, #1792]
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	str	x8, [sp, #1800]
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	str	x8, [sp, #1808]
	ldr	x8, [sp, #184]                  ; 8-byte Folded Reload
	str	x8, [sp, #1816]
	ldr	x8, [sp, #256]                  ; 8-byte Folded Reload
	str	x8, [sp, #1824]
	str	x21, [sp, #1832]
	str	x22, [sp, #1840]
	str	x23, [sp, #1848]
	str	x24, [sp, #1856]
	str	x25, [sp, #1864]
	str	x26, [sp, #1872]
	str	x27, [sp, #1880]
	str	x28, [sp, #1888]
	str	x20, [sp, #1896]
	ldp	x21, x20, [sp, #168]            ; 16-byte Folded Reload
	str	x20, [sp, #1904]
	str	x21, [sp, #1912]
	ldr	x23, [sp, #72]                  ; 8-byte Folded Reload
	str	x23, [sp, #1920]
	str	x9, [sp, #1928]
	mov	x22, x9
	add	x0, sp, #1408
	add	x1, sp, #296
	add	x3, sp, #1680
	add	x4, sp, #336
	mov	w2, #5                          ; =0x5
	bl	_wf_hash_map.hash_map_put$instance$8d5197e2f00c3b07
	add	x0, sp, #1408
	add	x1, sp, #264
	bl	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	str	x8, [sp, #1152]
	ldp	x8, x9, [sp, #240]              ; 16-byte Folded Reload
	str	x9, [sp, #1160]
	str	x8, [sp, #1168]
	add	x9, x19, #34
	ldp	x11, x8, [sp, #88]              ; 16-byte Folded Reload
	str	x11, [sp, #1176]
	add	x10, x19, #35
	stp	x10, x9, [sp, #240]             ; 16-byte Folded Spill
	str	x8, [sp, #1184]
	add	x11, x19, #36
	ldr	x8, [sp, #192]                  ; 8-byte Folded Reload
	str	x8, [sp, #1192]
	add	x12, x19, #37
	ldr	x8, [sp, #200]                  ; 8-byte Folded Reload
	str	x8, [sp, #1200]
	add	x13, x19, #38
	stp	x12, x13, [sp, #192]            ; 16-byte Folded Spill
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	str	x8, [sp, #1208]
	add	x14, x19, #39
	stp	x14, x11, [sp, #144]            ; 16-byte Folded Spill
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	str	x8, [sp, #1216]
	add	x15, x19, #40
	str	x15, [sp, #160]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #184]                  ; 8-byte Folded Reload
	str	x8, [sp, #1224]
	add	x16, x19, #41
	str	x16, [sp, #184]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #256]                  ; 8-byte Folded Reload
	str	x8, [sp, #1232]
	ldp	x25, x24, [sp, #56]             ; 16-byte Folded Reload
	str	x24, [sp, #1240]
	str	x25, [sp, #1248]
	ldp	x27, x26, [sp, #40]             ; 16-byte Folded Reload
	str	x26, [sp, #1256]
	str	x27, [sp, #1264]
	ldr	x28, [sp, #32]                  ; 8-byte Folded Reload
	str	x28, [sp, #1272]
	ldr	x8, [sp, #232]                  ; 8-byte Folded Reload
	str	x8, [sp, #1280]
	ldr	x8, [sp, #224]                  ; 8-byte Folded Reload
	str	x8, [sp, #1288]
	ldr	x8, [sp, #216]                  ; 8-byte Folded Reload
	str	x8, [sp, #1296]
	ldr	x8, [sp, #208]                  ; 8-byte Folded Reload
	str	x8, [sp, #1304]
	str	x20, [sp, #1312]
	str	x21, [sp, #1320]
	str	x23, [sp, #1328]
	str	x22, [sp, #1336]
	str	x9, [sp, #1344]
	str	x10, [sp, #1352]
	str	x11, [sp, #1360]
	str	x12, [sp, #1368]
	str	x13, [sp, #1376]
	str	x14, [sp, #1384]
	str	x15, [sp, #1392]
	str	x16, [sp, #1400]
	add	x0, sp, #880
	add	x1, sp, #296
	add	x3, sp, #1152
	add	x4, sp, #336
	mov	w2, #1                          ; =0x1
	bl	_wf_hash_map.hash_map_put$instance$8d5197e2f00c3b07
	add	x0, sp, #880
	add	x1, sp, #264
	bl	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
	dup.2d	v0, x19
Lloh38:
	adrp	x8, lCPI39_1@PAGE
Lloh39:
	ldr	q1, [x8, lCPI39_1@PAGEOFF]
	add.2d	v1, v0, v1
Lloh40:
	adrp	x8, lCPI39_2@PAGE
Lloh41:
	ldr	q2, [x8, lCPI39_2@PAGEOFF]
	add.2d	v2, v0, v2
Lloh42:
	adrp	x8, lCPI39_3@PAGE
Lloh43:
	ldr	q3, [x8, lCPI39_3@PAGEOFF]
	add.2d	v3, v0, v3
Lloh44:
	adrp	x8, lCPI39_4@PAGE
Lloh45:
	ldr	q4, [x8, lCPI39_4@PAGEOFF]
	add.2d	v4, v0, v4
Lloh46:
	adrp	x8, lCPI39_5@PAGE
Lloh47:
	ldr	q5, [x8, lCPI39_5@PAGEOFF]
	add.2d	v0, v0, v5
	ldr	x8, [sp, #256]                  ; 8-byte Folded Reload
	str	x8, [sp, #624]
	str	x24, [sp, #632]
	str	x25, [sp, #640]
	str	x26, [sp, #648]
	str	x27, [sp, #656]
	str	x28, [sp, #664]
	ldp	x8, x9, [sp, #224]              ; 16-byte Folded Reload
	str	x9, [sp, #672]
	str	x8, [sp, #680]
	ldp	x8, x9, [sp, #208]              ; 16-byte Folded Reload
	str	x9, [sp, #688]
	str	x8, [sp, #696]
	str	x20, [sp, #704]
	str	x21, [sp, #712]
	str	x23, [sp, #720]
	str	x22, [sp, #728]
	ldp	x8, x9, [sp, #240]              ; 16-byte Folded Reload
	str	x9, [sp, #736]
	str	x8, [sp, #744]
	ldr	x8, [sp, #152]                  ; 8-byte Folded Reload
	str	x8, [sp, #752]
	ldp	x9, x8, [sp, #192]              ; 16-byte Folded Reload
	str	x9, [sp, #760]
	str	x8, [sp, #768]
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	str	x8, [sp, #776]
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	str	x8, [sp, #784]
	ldr	x8, [sp, #184]                  ; 8-byte Folded Reload
	str	x8, [sp, #792]
	add	x8, sp, #624
	stp	q1, q2, [x8, #176]
	stp	q3, q4, [x8, #208]
	str	q0, [x8, #240]
	add	x0, sp, #352
	add	x1, sp, #296
	add	x3, sp, #624
	add	x4, sp, #336
	mov	w2, #7                          ; =0x7
	bl	_wf_hash_map.hash_map_put$instance$8d5197e2f00c3b07
	add	x0, sp, #352
	add	x1, sp, #264
	bl	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
	add	x0, sp, #296
	add	x1, sp, #264
	bl	_wf_hash_map.hash_map_free$instance$72d84b2e6d0b7146
	ldp	x8, x9, [sp, #264]
	ldp	x10, x11, [sp, #280]
	eor	x8, x8, x8, lsr #30
	mov	x12, #58809                     ; =0xe5b9
	movk	x12, #7396, lsl #16
	movk	x12, #18285, lsl #32
	movk	x12, #48984, lsl #48
	mul	x8, x8, x12
	eor	x8, x8, x8, lsr #27
	mov	x13, #4587                      ; =0x11eb
	movk	x13, #4913, lsl #16
	movk	x13, #18875, lsl #32
	movk	x13, #38096, lsl #48
	mul	x8, x8, x13
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x12
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x13
	eor	x12, x9, x8
	mov	x13, #31765                     ; =0x7c15
	movk	x13, #32586, lsl #16
	movk	x13, #31161, lsl #32
	movk	x13, #40503, lsl #48
	mul	x11, x11, x13
	eor	x10, x10, x11
	eor	x10, x10, x12, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	add	sp, sp, #1936
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB39_2:                                ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpAdrp	Lloh44, Lloh46
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpAdrp	Lloh42, Lloh44
	.loh AdrpLdr	Lloh42, Lloh43
	.loh AdrpAdrp	Lloh40, Lloh42
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpAdrp	Lloh38, Lloh40
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpLdr	Lloh36, Lloh37
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_map_cost_library_trace$instance$4250cb78d3f44027
lCPI40_0:
	.quad	0                               ; 0x0
	.quad	-9187201950435737472            ; 0x8080808080808080
lCPI40_1:
	.quad	1                               ; 0x1
	.quad	2                               ; 0x2
lCPI40_2:
	.quad	3                               ; 0x3
	.quad	4                               ; 0x4
lCPI40_3:
	.quad	5                               ; 0x5
	.quad	6                               ; 0x6
lCPI40_4:
	.quad	7                               ; 0x7
	.quad	8                               ; 0x8
lCPI40_5:
	.quad	9                               ; 0x9
	.quad	10                              ; 0xa
lCPI40_6:
	.quad	11                              ; 0xb
	.quad	12                              ; 0xc
lCPI40_7:
	.quad	13                              ; 0xd
	.quad	14                              ; 0xe
lCPI40_8:
	.quad	15                              ; 0xf
	.quad	16                              ; 0x10
lCPI40_9:
	.quad	17                              ; 0x11
	.quad	18                              ; 0x12
lCPI40_10:
	.quad	19                              ; 0x13
	.quad	20                              ; 0x14
lCPI40_11:
	.quad	21                              ; 0x15
	.quad	22                              ; 0x16
lCPI40_12:
	.quad	23                              ; 0x17
	.quad	24                              ; 0x18
lCPI40_13:
	.quad	25                              ; 0x19
	.quad	26                              ; 0x1a
lCPI40_14:
	.quad	27                              ; 0x1b
	.quad	28                              ; 0x1c
lCPI40_15:
	.quad	29                              ; 0x1d
	.quad	30                              ; 0x1e
lCPI40_16:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI40_17:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI40_18:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI40_19:
	.quad	8                               ; 0x8
	.quad	9                               ; 0x9
lCPI40_20:
	.quad	10                              ; 0xa
	.quad	11                              ; 0xb
lCPI40_21:
	.quad	12                              ; 0xc
	.quad	13                              ; 0xd
lCPI40_22:
	.quad	14                              ; 0xe
	.quad	15                              ; 0xf
lCPI40_23:
	.quad	16                              ; 0x10
	.quad	17                              ; 0x11
lCPI40_24:
	.quad	18                              ; 0x12
	.quad	19                              ; 0x13
lCPI40_25:
	.quad	20                              ; 0x14
	.quad	21                              ; 0x15
lCPI40_26:
	.quad	22                              ; 0x16
	.quad	23                              ; 0x17
lCPI40_27:
	.quad	24                              ; 0x18
	.quad	25                              ; 0x19
lCPI40_28:
	.quad	26                              ; 0x1a
	.quad	27                              ; 0x1b
lCPI40_29:
	.quad	28                              ; 0x1c
	.quad	29                              ; 0x1d
lCPI40_30:
	.quad	30                              ; 0x1e
	.quad	31                              ; 0x1f
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_map_cost_library_trace$instance$4250cb78d3f44027
	.p2align	2
_wf_map_cost_library_trace$instance$4250cb78d3f44027: ; @"wf_map_cost_library_trace$instance$4250cb78d3f44027"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	mov	w9, #7856                       ; =0x1eb0
Lloh48:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh49:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #3760
	.cfi_def_cfa_offset 7952
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x24, x4
	str	x2, [sp, #104]                  ; 8-byte Folded Spill
	mov	x25, x1
	mov	x22, x0
	add	x20, sp, #704
	mov	x8, #31765                      ; =0x7c15
	movk	x8, #32586, lsl #16
	movk	x8, #31161, lsl #32
	movk	x8, #40503, lsl #48
	str	x3, [sp, #8]                    ; 8-byte Folded Spill
	eor	x8, x3, x8
	cmp	x5, #0
	cset	w9, ne
	mov	w10, #5992                      ; =0x1768
	str	x8, [sp, #6688]
	strb	w9, [x20, x10]
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB40_385
; %bb.1:                                ; %bb1.i.i
	stp	xzr, x22, [x0]
	cbz	x22, LBB40_7
; %bb.2:                                ; %bb5.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
	movi.2d	v0, #0000000000000000
LBB40_3:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	q0, q0, [x9]
	stp	q0, q0, [x9, #32]
	stp	q0, q0, [x9, #64]
	stp	q0, q0, [x9, #96]
	stp	q0, q0, [x9, #128]
	stp	q0, q0, [x9, #160]
	stp	q0, q0, [x9, #192]
	stp	q0, q0, [x9, #224]
	str	xzr, [x9, #256]
	add	x9, x9, #272
	cmp	x22, x8
	b.ne	LBB40_3
; %bb.4:                                ; %"wf_hash_map.hash_map_extend$instance$0e108827ecbbe374.exit.i"
	str	x22, [x0]
	cmp	x22, #9
	b.lo	LBB40_7
; %bb.5:                                ; %bb2.i.i.i
	mov	x19, x0
	and	x21, x22, #0xfffffffffffffff8
	add	x0, x21, #8
	bl	_malloc
	cbz	x0, LBB40_385
; %bb.6:                                ; %buffer.fill.init.v2.i.i.i.i
	mov	x23, x0
	lsr	x8, x22, #3
	str	x8, [x0], #8
	mov	w1, #128                        ; =0x80
	mov	x2, x21
	bl	_memset
	mov	w8, #1                          ; =0x1
	mov	x0, x19
	b	LBB40_8
LBB40_7:
	mov	x23, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
LBB40_8:                                ; %"wf_hash_map.hash_map_new$instance$0e108827ecbbe374.exit"
	mov	w9, #4832                       ; =0x12e0
	add	x10, x20, x9
	str	x0, [sp, #6704]
Lloh50:
	adrp	x9, lCPI40_0@PAGE
Lloh51:
	ldr	q0, [x9, lCPI40_0@PAGEOFF]
	str	x10, [sp, #656]                 ; 8-byte Folded Spill
	add	x9, x10, #1176
	str	q0, [x9]
	mov	w9, #6000                       ; =0x1770
	add	x9, x20, x9
	str	x9, [sp, #696]                  ; 8-byte Folded Spill
	str	x8, [sp, #6728]
	str	x23, [sp, #6736]
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x8, [sp, #6744]
	str	xzr, [sp, #6752]
	str	xzr, [sp, #6768]
	str	xzr, [sp, #6760]
	str	x25, [sp, #688]                 ; 8-byte Folded Spill
	cbz	x25, LBB40_14
; %bb.9:                                ; %bb2.lr.ph
Lloh52:
	adrp	x8, lCPI40_1@PAGE
Lloh53:
	ldr	q0, [x8, lCPI40_1@PAGEOFF]
	str	q0, [sp, #672]                  ; 16-byte Folded Spill
	add	x8, sp, #704
	add	x19, x8, #792
Lloh54:
	adrp	x8, lCPI40_2@PAGE
Lloh55:
	ldr	q0, [x8, lCPI40_2@PAGEOFF]
	str	q0, [sp, #640]                  ; 16-byte Folded Spill
	add	x20, sp, #704
Lloh56:
	adrp	x8, lCPI40_3@PAGE
Lloh57:
	ldr	q0, [x8, lCPI40_3@PAGEOFF]
	str	q0, [sp, #624]                  ; 16-byte Folded Spill
	mov	w21, #1                         ; =0x1
Lloh58:
	adrp	x8, lCPI40_4@PAGE
Lloh59:
	ldr	q0, [x8, lCPI40_4@PAGEOFF]
	str	q0, [sp, #608]                  ; 16-byte Folded Spill
Lloh60:
	adrp	x8, lCPI40_5@PAGE
Lloh61:
	ldr	q0, [x8, lCPI40_5@PAGEOFF]
	str	q0, [sp, #592]                  ; 16-byte Folded Spill
Lloh62:
	adrp	x8, lCPI40_6@PAGE
Lloh63:
	ldr	q0, [x8, lCPI40_6@PAGEOFF]
	str	q0, [sp, #576]                  ; 16-byte Folded Spill
Lloh64:
	adrp	x8, lCPI40_7@PAGE
Lloh65:
	ldr	q0, [x8, lCPI40_7@PAGEOFF]
	str	q0, [sp, #560]                  ; 16-byte Folded Spill
Lloh66:
	adrp	x8, lCPI40_8@PAGE
Lloh67:
	ldr	q0, [x8, lCPI40_8@PAGEOFF]
	str	q0, [sp, #544]                  ; 16-byte Folded Spill
Lloh68:
	adrp	x8, lCPI40_9@PAGE
Lloh69:
	ldr	q0, [x8, lCPI40_9@PAGEOFF]
	str	q0, [sp, #528]                  ; 16-byte Folded Spill
Lloh70:
	adrp	x8, lCPI40_10@PAGE
Lloh71:
	ldr	q0, [x8, lCPI40_10@PAGEOFF]
	str	q0, [sp, #512]                  ; 16-byte Folded Spill
Lloh72:
	adrp	x8, lCPI40_11@PAGE
Lloh73:
	ldr	q0, [x8, lCPI40_11@PAGEOFF]
	str	q0, [sp, #496]                  ; 16-byte Folded Spill
Lloh74:
	adrp	x8, lCPI40_12@PAGE
Lloh75:
	ldr	q0, [x8, lCPI40_12@PAGEOFF]
	str	q0, [sp, #480]                  ; 16-byte Folded Spill
	mov	w25, #131                       ; =0x83
Lloh76:
	adrp	x8, lCPI40_13@PAGE
Lloh77:
	ldr	q0, [x8, lCPI40_13@PAGEOFF]
	str	q0, [sp, #464]                  ; 16-byte Folded Spill
	mov	w23, #1                         ; =0x1
Lloh78:
	adrp	x8, lCPI40_14@PAGE
Lloh79:
	ldr	q0, [x8, lCPI40_14@PAGEOFF]
	str	q0, [sp, #448]                  ; 16-byte Folded Spill
	ldr	x26, [sp, #688]                 ; 8-byte Folded Reload
Lloh80:
	adrp	x8, lCPI40_15@PAGE
Lloh81:
	ldr	q0, [x8, lCPI40_15@PAGEOFF]
	str	q0, [sp, #432]                  ; 16-byte Folded Spill
	ldr	x27, [sp, #8]                   ; 8-byte Folded Reload
	b	LBB40_11
LBB40_10:                               ; %bb6
                                        ;   in Loop: Header=BB40_11 Depth=1
	ldr	x8, [sp, #6744]
	mul	x8, x8, x25
	str	x8, [sp, #6744]
	add	x27, x27, #1
	add	x23, x23, #2
	subs	x26, x26, #1
	b.eq	LBB40_14
LBB40_11:                               ; %bb2
                                        ; =>This Inner Loop Header: Depth=1
	add	x8, x27, #31
	str	x27, [sp, #704]
	dup.2d	v0, x27
	ldr	q1, [sp, #672]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #457
	stur	q1, [x9, #255]
	ldr	q1, [sp, #640]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #473
	stur	q1, [x9, #255]
	ldr	q1, [sp, #624]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #489
	stur	q1, [x9, #255]
	ldr	q1, [sp, #608]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #505
	stur	q1, [x9, #255]
	ldr	q1, [sp, #592]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #521
	stur	q1, [x9, #255]
	ldr	q1, [sp, #576]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #537
	stur	q1, [x9, #255]
	ldr	q1, [sp, #560]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #553
	stur	q1, [x9, #255]
	ldr	q1, [sp, #544]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #569
	stur	q1, [x9, #255]
	ldr	q1, [sp, #528]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #704
	stur	q1, [x9, #136]
	ldr	q1, [sp, #512]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x9, #152]
	ldr	q1, [sp, #496]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x9, #168]
	ldr	q1, [sp, #480]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x9, #184]
	ldr	q1, [sp, #464]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x9, #200]
	ldr	q1, [sp, #448]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x9, #216]
	ldr	q1, [sp, #432]                  ; 16-byte Folded Reload
	add.2d	v0, v0, v1
	stur	q0, [x9, #232]
	str	x8, [sp, #952]
	add	x0, x9, #256
	add	x3, sp, #704
	mov	w8, #5984                       ; =0x1760
	add	x4, x9, x8
	ldr	x1, [sp, #696]                  ; 8-byte Folded Reload
	mov	x2, x23
	bl	_wf_hash_map.hash_map_put$instance$28da32efc51c2b65
	ldr	w8, [sp, #960]
	cbz	w8, LBB40_10
; %bb.12:                               ; %bb2
                                        ;   in Loop: Header=BB40_11 Depth=1
	cmp	w8, #1
	b.ne	LBB40_179
; %bb.13:                               ; %bb7
                                        ;   in Loop: Header=BB40_11 Depth=1
	add	x8, sp, #704
	ldrb	w28, [x8, #260]
	add	x0, x8, #528
	add	x1, x20, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	ldr	x8, [sp, #6744]
	cmp	w28, #0
	cinc	x9, x21, ne
	madd	x8, x8, x25, x9
	str	x8, [sp, #6744]
	ldr	x9, [sp, #1232]
	ldp	q1, q0, [x20, #368]
	stp	q1, q0, [x19, #96]
	ldp	q1, q0, [x20, #336]
	stp	q1, q0, [x19, #64]
	ldp	q1, q0, [x20, #432]
	stp	q1, q0, [x19, #160]
	ldp	q1, q0, [x20, #400]
	stp	q1, q0, [x19, #128]
	ldp	q1, q0, [x20, #496]
	stp	q1, q0, [x19, #224]
	ldp	q1, q0, [x20, #464]
	stp	q1, q0, [x19, #192]
	ldp	q1, q0, [x20, #304]
	stp	q1, q0, [x19, #32]
	ldp	q0, q1, [x20, #272]
	stp	q0, q1, [x19]
	ldr	x10, [sp, #1496]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1504]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1512]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1520]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1528]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1536]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1544]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1552]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1560]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1568]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1576]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1584]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1592]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1600]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1608]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1616]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1624]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1632]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1640]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1648]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1656]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1664]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1672]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1680]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1688]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1696]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1704]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1712]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1720]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1728]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1736]
	add	x8, x8, x10
	madd	x8, x9, x25, x8
	ldr	x9, [sp, #1744]
	madd	x8, x8, x25, x9
	str	x8, [sp, #6744]
	add	x27, x27, #1
	add	x23, x23, #2
	subs	x26, x26, #1
	b.ne	LBB40_11
LBB40_14:                               ; %bb12.preheader
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	cbz	x8, LBB40_384
; %bb.15:                               ; %bb13.lr.ph
	lsl	x8, x22, #1
	cmp	x22, #0
	csinc	x19, x8, xzr, ne
	cmp	x24, #1
	ldr	x9, [sp, #688]                  ; 8-byte Folded Reload
	csel	x8, x9, xzr, eq
	str	x8, [sp, #624]                  ; 8-byte Folded Spill
	add	x11, sp, #704
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2704
	add	x10, x8, #800
	add	x8, x8, #536
	stp	x8, x10, [sp, #304]             ; 16-byte Folded Spill
	cmp	x24, #5
	b.ne	LBB40_180
; %bb.16:                               ; %bb13.us.preheader
	mov	x10, #0                         ; =0x0
	add	x8, sp, #704
	add	x12, x8, #1584
	str	x12, [sp, #400]                 ; 8-byte Folded Spill
	add	x25, x8, #1896
	add	x12, x8, #2152
	str	x12, [sp, #416]                 ; 8-byte Folded Spill
	add	x8, x8, #2688
	str	x8, [sp, #368]                  ; 8-byte Folded Spill
	mov	w23, #6072                      ; =0x17b8
	sub	x8, x9, x9, lsr #1
	cmp	x8, #1
	csinc	x8, x8, xzr, hi
	str	x8, [sp, #672]                  ; 8-byte Folded Spill
Lloh82:
	adrp	x8, lCPI40_1@PAGE
Lloh83:
	ldr	q0, [x8, lCPI40_1@PAGEOFF]
	str	q0, [sp, #656]                  ; 16-byte Folded Spill
	add	x8, x11, #1064
	str	x8, [sp, #384]                  ; 8-byte Folded Spill
	add	x8, x11, #2168
	str	x8, [sp, #352]                  ; 8-byte Folded Spill
Lloh84:
	adrp	x8, lCPI40_2@PAGE
Lloh85:
	ldr	q0, [x8, lCPI40_2@PAGEOFF]
	str	q0, [sp, #640]                  ; 16-byte Folded Spill
Lloh86:
	adrp	x8, lCPI40_3@PAGE
Lloh87:
	ldr	q0, [x8, lCPI40_3@PAGEOFF]
	str	q0, [sp, #624]                  ; 16-byte Folded Spill
Lloh88:
	adrp	x8, lCPI40_4@PAGE
Lloh89:
	ldr	q0, [x8, lCPI40_4@PAGEOFF]
	str	q0, [sp, #608]                  ; 16-byte Folded Spill
Lloh90:
	adrp	x8, lCPI40_5@PAGE
Lloh91:
	ldr	q0, [x8, lCPI40_5@PAGEOFF]
	str	q0, [sp, #592]                  ; 16-byte Folded Spill
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	add	x8, x8, x9
	str	x8, [sp, #320]                  ; 8-byte Folded Spill
Lloh92:
	adrp	x8, lCPI40_6@PAGE
Lloh93:
	ldr	q0, [x8, lCPI40_6@PAGEOFF]
	str	q0, [sp, #576]                  ; 16-byte Folded Spill
	mov	w28, #131                       ; =0x83
Lloh94:
	adrp	x8, lCPI40_7@PAGE
Lloh95:
	ldr	q0, [x8, lCPI40_7@PAGEOFF]
	str	q0, [sp, #560]                  ; 16-byte Folded Spill
Lloh96:
	adrp	x8, lCPI40_8@PAGE
Lloh97:
	ldr	q0, [x8, lCPI40_8@PAGEOFF]
	str	q0, [sp, #544]                  ; 16-byte Folded Spill
Lloh98:
	adrp	x8, lCPI40_9@PAGE
Lloh99:
	ldr	q0, [x8, lCPI40_9@PAGEOFF]
	str	q0, [sp, #528]                  ; 16-byte Folded Spill
Lloh100:
	adrp	x8, lCPI40_10@PAGE
Lloh101:
	ldr	q0, [x8, lCPI40_10@PAGEOFF]
	str	q0, [sp, #512]                  ; 16-byte Folded Spill
Lloh102:
	adrp	x8, lCPI40_11@PAGE
Lloh103:
	ldr	q0, [x8, lCPI40_11@PAGEOFF]
	str	q0, [sp, #496]                  ; 16-byte Folded Spill
Lloh104:
	adrp	x8, lCPI40_12@PAGE
Lloh105:
	ldr	q0, [x8, lCPI40_12@PAGEOFF]
	str	q0, [sp, #480]                  ; 16-byte Folded Spill
Lloh106:
	adrp	x8, lCPI40_13@PAGE
Lloh107:
	ldr	q0, [x8, lCPI40_13@PAGEOFF]
	str	q0, [sp, #464]                  ; 16-byte Folded Spill
Lloh108:
	adrp	x8, lCPI40_14@PAGE
Lloh109:
	ldr	q0, [x8, lCPI40_14@PAGEOFF]
	str	q0, [sp, #448]                  ; 16-byte Folded Spill
Lloh110:
	adrp	x8, lCPI40_15@PAGE
Lloh111:
	ldr	q0, [x8, lCPI40_15@PAGEOFF]
	str	q0, [sp, #432]                  ; 16-byte Folded Spill
	mov	w19, #8                         ; =0x8
	mov	x21, #-9187201950435737472      ; =0x8080808080808080
	mov	x26, #9187201950435737471       ; =0x7f7f7f7f7f7f7f7f
	b	LBB40_18
LBB40_17:                               ;   in Loop: Header=BB40_18 Depth=1
	ldr	x27, [sp, #688]                 ; 8-byte Folded Reload
	ldr	x10, [sp, #336]                 ; 8-byte Folded Reload
	ldr	x8, [sp, #320]                  ; 8-byte Folded Reload
	add	x8, x8, x27
	str	x8, [sp, #320]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	cmp	x10, x8
	b.eq	LBB40_384
LBB40_18:                               ; %bb13.us
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB40_22 Depth 2
                                        ;       Child Loop BB40_29 Depth 3
                                        ;     Child Loop BB40_98 Depth 2
                                        ;       Child Loop BB40_102 Depth 3
                                        ;     Child Loop BB40_163 Depth 2
	str	x10, [sp, #336]                 ; 8-byte Folded Spill
	ldr	x27, [sp, #688]                 ; 8-byte Folded Reload
	cbz	x27, LBB40_89
; %bb.19:                               ; %bb20.us.preheader
                                        ;   in Loop: Header=BB40_18 Depth=1
	mov	x24, #0                         ; =0x0
	add	x20, sp, #704
	b	LBB40_22
LBB40_20:                               ; %bb22.i.i.us
                                        ;   in Loop: Header=BB40_22 Depth=2
	cbnz	w6, LBB40_179
LBB40_21:                               ; %bb3.i64.us
                                        ;   in Loop: Header=BB40_22 Depth=2
	mov	w10, #1                         ; =0x1
	str	w10, [sp, #2544]
	str	xzr, [sp, #2552]
	mul	x8, x8, x28
	strb	wzr, [sp, #2560]
	str	x8, [sp, #6744]
	add	x24, x24, #1
	ldr	x8, [sp, #672]                  ; 8-byte Folded Reload
	cmp	x24, x8
	b.eq	LBB40_90
LBB40_22:                               ; %bb20.us
                                        ;   Parent Loop BB40_18 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB40_29 Depth 3
	mov	w8, #1                          ; =0x1
	orr	x8, x8, x24, lsl #2
	str	x8, [sp, #6776]
	add	x0, x20, #1048
	add	x2, x20, x23
	mov	w8, #5984                       ; =0x1760
	add	x3, x20, x8
	ldr	x1, [sp, #696]                  ; 8-byte Folded Reload
	bl	_wf_hash_map.hash_map_remove$instance$28da32efc51c2b65
	ldr	w8, [sp, #1752]
	cmp	w8, #1
	b.eq	LBB40_26
; %bb.23:                               ; %bb20.us
                                        ;   in Loop: Header=BB40_22 Depth=2
	cbnz	w8, LBB40_179
; %bb.24:                               ; %bb25.us
                                        ;   in Loop: Header=BB40_22 Depth=2
	ldr	x8, [sp, #6744]
	mul	x8, x8, x28
	mov	w7, #272                        ; =0x110
	str	x8, [sp, #6744]
	mov	w9, #5992                       ; =0x1768
	ldrb	w9, [x20, x9]
	tbnz	w9, #0, LBB40_27
LBB40_25:                               ; %bb3.i.i.i.us
                                        ;   in Loop: Header=BB40_22 Depth=2
	ldr	x9, [sp, #6688]
	ldr	x10, [sp, #6776]
	eor	x9, x10, x9
	eor	x9, x9, x9, lsr #30
	mov	x10, #58809                     ; =0xe5b9
	movk	x10, #7396, lsl #16
	movk	x10, #18285, lsl #32
	movk	x10, #48984, lsl #48
	mul	x9, x9, x10
	eor	x9, x9, x9, lsr #27
	mov	x10, #4587                      ; =0x11eb
	movk	x10, #4913, lsl #16
	movk	x10, #18875, lsl #32
	movk	x10, #38096, lsl #48
	mul	x9, x9, x10
	eor	x11, x9, x9, lsr #31
	ldr	x9, [sp, #6704]
	ldr	x10, [x9]
	cbnz	x10, LBB40_28
	b	LBB40_21
LBB40_26:                               ; %bb24.us
                                        ;   in Loop: Header=BB40_22 Depth=2
	add	x0, x20, #1320
	add	x8, sp, #704
	add	x1, x8, #1056
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	ldr	x8, [sp, #6744]
	ldr	x9, [sp, #2024]
	ldr	x11, [sp, #384]                 ; 8-byte Folded Reload
	ldp	q1, q0, [x11, #32]
	ldr	x10, [sp, #400]                 ; 8-byte Folded Reload
	stp	q1, q0, [x10, #32]
	ldp	q1, q0, [x11, #96]
	stp	q1, q0, [x10, #96]
	ldp	q1, q0, [x11, #64]
	stp	q1, q0, [x10, #64]
	ldp	q1, q0, [x11, #160]
	stp	q1, q0, [x10, #160]
	ldp	q1, q0, [x11, #128]
	stp	q1, q0, [x10, #128]
	ldp	q1, q0, [x11, #224]
	stp	q1, q0, [x10, #224]
	ldp	q1, q0, [x11, #192]
	stp	q1, q0, [x10, #192]
	ldp	q1, q0, [x11]
	stp	q1, q0, [x10]
	ldr	x10, [sp, #2528]
	madd	x8, x8, x28, x10
	ldr	x10, [sp, #2288]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2296]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2304]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2312]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2320]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2328]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2336]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2344]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2352]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2360]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2368]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2376]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2384]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2392]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2400]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2408]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2416]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2424]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2432]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2440]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2448]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2456]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2464]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2472]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2480]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2488]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2496]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2504]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2512]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #2520]
	madd	x9, x9, x28, x10
	madd	x8, x9, x28, x8
	ldr	x9, [sp, #2536]
	madd	x8, x8, x28, x9
	add	x8, x8, #131
	mov	w7, #272                        ; =0x110
	str	x8, [sp, #6744]
	mov	w9, #5992                       ; =0x1768
	ldrb	w9, [x20, x9]
	tbz	w9, #0, LBB40_25
LBB40_27:                               ;   in Loop: Header=BB40_22 Depth=2
	mov	x11, #0                         ; =0x0
	ldr	x9, [sp, #6704]
	ldr	x10, [x9]
	cbz	x10, LBB40_21
LBB40_28:                               ; %bb3.i.i1203.us
                                        ;   in Loop: Header=BB40_22 Depth=2
	lsr	x14, x11, #57
	udiv	x12, x11, x10
	msub	x12, x12, x10, x11
	ldr	x11, [sp, #6728]
	ldr	x13, [sp, #6720]
	mov	x15, #72340172838076673         ; =0x101010101010101
	mul	x14, x14, x15
	ldr	x15, [sp, #6736]
	ldr	x16, [sp, #6776]
	mov	w17, #1                         ; =0x1
	mov	x0, x10
LBB40_29:                               ; %bb10.i.i.us
                                        ;   Parent Loop BB40_18 Depth=1
                                        ;     Parent Loop BB40_22 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	x2, x12, #0x7
	sub	x1, x10, x12
	sub	x3, x19, x2
	cmp	x3, x1
	csel	x1, x3, x1, lo
	cmp	x1, x0
	csel	x1, x1, x0, lo
	cbz	x11, LBB40_32
; %bb.30:                               ; %bb3.i21.i.i.us
                                        ;   in Loop: Header=BB40_29 Depth=3
	lsr	x3, x12, #3
	ldr	x4, [x15]
	cmp	x3, x4
	b.hs	LBB40_33
; %bb.31:                               ; %bb8.i.i.i.us
                                        ;   in Loop: Header=BB40_29 Depth=3
	add	x3, x15, x3, lsl #3
	ldr	x4, [x3, #8]
	b	LBB40_34
LBB40_32:                               ; %bb2.i.i.i1214.us
                                        ;   in Loop: Header=BB40_29 Depth=3
	cmp	x12, #8
	csel	x4, x13, x21, lo
	b	LBB40_34
LBB40_33:                               ; %bb9.i.i.i.us
                                        ;   in Loop: Header=BB40_29 Depth=3
	csel	x4, x13, x21, eq
LBB40_34:                               ; %wf_hash_map.hash_map_control_word.exit.i.i.us
                                        ;   in Loop: Header=BB40_29 Depth=3
	lsl	x3, x1, #3
	neg	x3, x3
	lsr	x3, x21, x3
	lsl	x5, x2, #3
	lsl	x5, x3, x5
	and	x3, x4, #0x7f7f7f7f7f7f7f7f
	sub	x3, x21, x3
	and	x3, x3, x4
	and	x3, x5, x3
	cmp	x3, #0
	rbit	x3, x3
	clz	x3, x3
	lsr	x6, x3, #3
	ccmp	x6, x2, #0, ne
	mov	x3, x1
	b.hs	LBB40_36
; %bb.35:                               ; %wf_hash_map.hash_map_control_stop.exit.i.i.us
                                        ;   in Loop: Header=BB40_29 Depth=3
	eor	x4, x4, x14
	and	x6, x4, #0x7f7f7f7f7f7f7f7f
	add	x6, x6, x26
	orr	x4, x6, x4
	bic	x5, x5, x4
	cbnz	x5, LBB40_37
	b	LBB40_84
LBB40_36:                               ; %bb5.i.i.i.us
                                        ;   in Loop: Header=BB40_29 Depth=3
	sub	x3, x6, x2
	cmp	x3, x1
	csel	x3, x3, x1, lo
	eor	x4, x4, x14
	and	x6, x4, #0x7f7f7f7f7f7f7f7f
	add	x6, x6, x26
	orr	x4, x6, x4
	bic	x5, x5, x4
	cbz	x5, LBB40_84
LBB40_37:                               ; %bb17.i.i.us
                                        ;   in Loop: Header=BB40_29 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x2
	b.lo	LBB40_42
; %bb.38:                               ; %bb19.i.i.us
                                        ;   in Loop: Header=BB40_29 Depth=3
	cmp	x4, x3
	b.hs	LBB40_42
; %bb.39:                               ; %bb22.i.i.us
                                        ;   in Loop: Header=BB40_29 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x7, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB40_42
; %bb.40:                               ; %bb22.i.i.us
                                        ;   in Loop: Header=BB40_29 Depth=3
	cmp	w6, #2
	b.ne	LBB40_20
; %bb.41:                               ; %bb25.i.i.us
                                        ;   in Loop: Header=BB40_29 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x16
	b.eq	LBB40_87
LBB40_42:                               ; %bb31.i.i.us
                                        ;   in Loop: Header=BB40_29 Depth=3
	sub	x4, x5, #1
	and	x5, x4, x5
	cbz	x5, LBB40_84
; %bb.43:                               ; %bb17.i.i.us.1
                                        ;   in Loop: Header=BB40_29 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x2
	b.lo	LBB40_48
; %bb.44:                               ; %bb19.i.i.us.1
                                        ;   in Loop: Header=BB40_29 Depth=3
	cmp	x4, x3
	b.hs	LBB40_48
; %bb.45:                               ; %bb22.i.i.us.1
                                        ;   in Loop: Header=BB40_29 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x7, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB40_48
; %bb.46:                               ; %bb22.i.i.us.1
                                        ;   in Loop: Header=BB40_29 Depth=3
	cmp	w6, #2
	b.ne	LBB40_20
; %bb.47:                               ; %bb25.i.i.us.1
                                        ;   in Loop: Header=BB40_29 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x16
	b.eq	LBB40_87
LBB40_48:                               ; %bb31.i.i.us.1
                                        ;   in Loop: Header=BB40_29 Depth=3
	sub	x4, x5, #1
	and	x5, x4, x5
	cbz	x5, LBB40_84
; %bb.49:                               ; %bb17.i.i.us.2
                                        ;   in Loop: Header=BB40_29 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x2
	b.lo	LBB40_54
; %bb.50:                               ; %bb19.i.i.us.2
                                        ;   in Loop: Header=BB40_29 Depth=3
	cmp	x4, x3
	b.hs	LBB40_54
; %bb.51:                               ; %bb22.i.i.us.2
                                        ;   in Loop: Header=BB40_29 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x7, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB40_54
; %bb.52:                               ; %bb22.i.i.us.2
                                        ;   in Loop: Header=BB40_29 Depth=3
	cmp	w6, #2
	b.ne	LBB40_20
; %bb.53:                               ; %bb25.i.i.us.2
                                        ;   in Loop: Header=BB40_29 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x16
	b.eq	LBB40_87
LBB40_54:                               ; %bb31.i.i.us.2
                                        ;   in Loop: Header=BB40_29 Depth=3
	sub	x4, x5, #1
	and	x5, x4, x5
	cbz	x5, LBB40_84
; %bb.55:                               ; %bb17.i.i.us.3
                                        ;   in Loop: Header=BB40_29 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x2
	b.lo	LBB40_60
; %bb.56:                               ; %bb19.i.i.us.3
                                        ;   in Loop: Header=BB40_29 Depth=3
	cmp	x4, x3
	b.hs	LBB40_60
; %bb.57:                               ; %bb22.i.i.us.3
                                        ;   in Loop: Header=BB40_29 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x7, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB40_60
; %bb.58:                               ; %bb22.i.i.us.3
                                        ;   in Loop: Header=BB40_29 Depth=3
	cmp	w6, #2
	b.ne	LBB40_20
; %bb.59:                               ; %bb25.i.i.us.3
                                        ;   in Loop: Header=BB40_29 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x16
	b.eq	LBB40_87
LBB40_60:                               ; %bb31.i.i.us.3
                                        ;   in Loop: Header=BB40_29 Depth=3
	sub	x4, x5, #1
	and	x5, x4, x5
	cbz	x5, LBB40_84
; %bb.61:                               ; %bb17.i.i.us.4
                                        ;   in Loop: Header=BB40_29 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x2
	b.lo	LBB40_66
; %bb.62:                               ; %bb19.i.i.us.4
                                        ;   in Loop: Header=BB40_29 Depth=3
	cmp	x4, x3
	b.hs	LBB40_66
; %bb.63:                               ; %bb22.i.i.us.4
                                        ;   in Loop: Header=BB40_29 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x7, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB40_66
; %bb.64:                               ; %bb22.i.i.us.4
                                        ;   in Loop: Header=BB40_29 Depth=3
	cmp	w6, #2
	b.ne	LBB40_20
; %bb.65:                               ; %bb25.i.i.us.4
                                        ;   in Loop: Header=BB40_29 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x16
	b.eq	LBB40_87
LBB40_66:                               ; %bb31.i.i.us.4
                                        ;   in Loop: Header=BB40_29 Depth=3
	sub	x4, x5, #1
	and	x5, x4, x5
	cbz	x5, LBB40_84
; %bb.67:                               ; %bb17.i.i.us.5
                                        ;   in Loop: Header=BB40_29 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x2
	b.lo	LBB40_72
; %bb.68:                               ; %bb19.i.i.us.5
                                        ;   in Loop: Header=BB40_29 Depth=3
	cmp	x4, x3
	b.hs	LBB40_72
; %bb.69:                               ; %bb22.i.i.us.5
                                        ;   in Loop: Header=BB40_29 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x7, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB40_72
; %bb.70:                               ; %bb22.i.i.us.5
                                        ;   in Loop: Header=BB40_29 Depth=3
	cmp	w6, #2
	b.ne	LBB40_20
; %bb.71:                               ; %bb25.i.i.us.5
                                        ;   in Loop: Header=BB40_29 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x16
	b.eq	LBB40_87
LBB40_72:                               ; %bb31.i.i.us.5
                                        ;   in Loop: Header=BB40_29 Depth=3
	sub	x4, x5, #1
	and	x5, x4, x5
	cbz	x5, LBB40_84
; %bb.73:                               ; %bb17.i.i.us.6
                                        ;   in Loop: Header=BB40_29 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x2
	b.lo	LBB40_78
; %bb.74:                               ; %bb19.i.i.us.6
                                        ;   in Loop: Header=BB40_29 Depth=3
	cmp	x4, x3
	b.hs	LBB40_78
; %bb.75:                               ; %bb22.i.i.us.6
                                        ;   in Loop: Header=BB40_29 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x7, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB40_78
; %bb.76:                               ; %bb22.i.i.us.6
                                        ;   in Loop: Header=BB40_29 Depth=3
	cmp	w6, #2
	b.ne	LBB40_20
; %bb.77:                               ; %bb25.i.i.us.6
                                        ;   in Loop: Header=BB40_29 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x16
	b.eq	LBB40_87
LBB40_78:                               ; %bb31.i.i.us.6
                                        ;   in Loop: Header=BB40_29 Depth=3
	sub	x4, x5, #1
	and	x4, x4, x5
	cbz	x4, LBB40_84
; %bb.79:                               ; %bb17.i.i.us.7
                                        ;   in Loop: Header=BB40_29 Depth=3
	rbit	x4, x4
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x2, x4, x2
	b.lo	LBB40_84
; %bb.80:                               ; %bb19.i.i.us.7
                                        ;   in Loop: Header=BB40_29 Depth=3
	cmp	x2, x3
	b.hs	LBB40_84
; %bb.81:                               ; %bb22.i.i.us.7
                                        ;   in Loop: Header=BB40_29 Depth=3
	add	x2, x2, x12
	madd	x4, x2, x7, x9
	ldr	w2, [x4, #16]!
	cmp	w2, #1
	b.eq	LBB40_84
; %bb.82:                               ; %bb22.i.i.us.7
                                        ;   in Loop: Header=BB40_29 Depth=3
	cmp	w2, #2
	b.ne	LBB40_88
; %bb.83:                               ; %bb25.i.i.us.7
                                        ;   in Loop: Header=BB40_29 Depth=3
	ldr	x2, [x4, #8]
	cmp	x2, x16
	b.eq	LBB40_87
LBB40_84:                               ; %bb14.i.i.us
                                        ;   in Loop: Header=BB40_29 Depth=3
	cmp	x3, x1
	b.lo	LBB40_21
; %bb.85:                               ; %bb34.i.i.us
                                        ;   in Loop: Header=BB40_29 Depth=3
	add	x12, x1, x12
	cmp	x12, x10
	csel	x12, x12, xzr, lo
	cmp	x17, x10
	b.hs	LBB40_21
; %bb.86:                               ; %bb34.i.i.us
                                        ;   in Loop: Header=BB40_29 Depth=3
	add	x17, x17, #1
	sub	x0, x0, x1
	cbnz	x0, LBB40_29
	b	LBB40_21
LBB40_87:                               ; %bb2.i66.us
                                        ;   in Loop: Header=BB40_22 Depth=2
	ldr	x10, [x4, #16]
	str	wzr, [sp, #2544]
	str	x10, [sp, #2552]
	strb	wzr, [sp, #2560]
	mov	w11, #17161                     ; =0x4309
	mul	x8, x8, x11
	add	x8, x10, x8
	add	x8, x8, #131
	str	x8, [sp, #6744]
	add	x24, x24, #1
	ldr	x8, [sp, #672]                  ; 8-byte Folded Reload
	cmp	x24, x8
	b.ne	LBB40_22
	b	LBB40_90
LBB40_88:                               ; %bb22.i.i.us.7
                                        ;   in Loop: Header=BB40_22 Depth=2
	cbz	w2, LBB40_21
	b	LBB40_179
LBB40_89:                               ; %bb13.us.bb22.us_crit_edge
                                        ;   in Loop: Header=BB40_18 Depth=1
	ldr	x9, [sp, #6704]
	add	x20, sp, #704
LBB40_90:                               ; %bb22.us
                                        ;   in Loop: Header=BB40_18 Depth=1
	ldr	x1, [x9]
	mov	w8, #5984                       ; =0x1760
	add	x2, x20, x8
	ldr	x0, [sp, #696]                  ; 8-byte Folded Reload
	bl	_wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	str	w0, [sp, #2568]
	strb	w1, [sp, #2572]
	strb	w2, [sp, #2573]
	cbz	w0, LBB40_94
; %bb.91:                               ; %bb22.us
                                        ;   in Loop: Header=BB40_18 Depth=1
	cmp	w0, #1
	b.ne	LBB40_179
; %bb.92:                               ; %bb3.i.us
                                        ;   in Loop: Header=BB40_18 Depth=1
	ldr	x8, [sp, #6744]
	mul	x8, x8, x28
	mov	w30, #272                       ; =0x110
	str	x8, [sp, #6744]
	cbnz	x27, LBB40_95
LBB40_93:                               ; %bb32.preheader.us.bb93.loopexit.us_crit_edge
                                        ;   in Loop: Header=BB40_18 Depth=1
	ldr	x10, [sp, #336]                 ; 8-byte Folded Reload
	add	x10, x10, #1
	ldr	x8, [sp, #320]                  ; 8-byte Folded Reload
	add	x8, x8, x27
	str	x8, [sp, #320]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	cmp	x10, x8
	b.ne	LBB40_18
	b	LBB40_384
LBB40_94:                               ; %bb2.i.us
                                        ;   in Loop: Header=BB40_18 Depth=1
	ldr	x8, [sp, #6744]
	mov	x9, #1                          ; =0x1
	madd	x8, x8, x28, x9
	mov	w30, #272                       ; =0x110
	str	x8, [sp, #6744]
	cbz	x27, LBB40_93
LBB40_95:                               ; %bb28.lr.ph.us
                                        ;   in Loop: Header=BB40_18 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	x10, [sp, #6688]
	mov	w11, #5992                      ; =0x1768
	ldrb	w11, [x20, x11]
	ldr	x12, [sp, #6704]
	ldr	x13, [sp, #6728]
	ldr	x14, [sp, #6720]
	ldr	x15, [sp, #6736]
	b	LBB40_98
LBB40_96:                               ; %bb22.i.i1319.us
                                        ;   in Loop: Header=BB40_98 Depth=2
	cbnz	w24, LBB40_179
LBB40_97:                               ; %bb3.i228.us
                                        ;   in Loop: Header=BB40_98 Depth=2
	mov	w16, #1                         ; =0x1
	str	w16, [sp, #2576]
	str	xzr, [sp, #2584]
	mul	x8, x8, x28
	strb	wzr, [sp, #2592]
	str	x8, [sp, #6744]
	add	x9, x9, #1
	cmp	x9, x27
	b.eq	LBB40_162
LBB40_98:                               ; %bb28.us
                                        ;   Parent Loop BB40_18 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB40_102 Depth 3
	mov	w16, #1                         ; =0x1
	orr	x16, x16, x9, lsl #1
	str	x16, [sp, #6784]
	tbz	w11, #0, LBB40_100
; %bb.99:                               ;   in Loop: Header=BB40_98 Depth=2
	mov	x0, #0                          ; =0x0
	ldr	x17, [x12]
	cbnz	x17, LBB40_101
	b	LBB40_97
LBB40_100:                              ; %bb3.i.i.i1217.us
                                        ;   in Loop: Header=BB40_98 Depth=2
	eor	x17, x10, x16
	eor	x17, x17, x17, lsr #30
	mov	x0, #58809                      ; =0xe5b9
	movk	x0, #7396, lsl #16
	movk	x0, #18285, lsl #32
	movk	x0, #48984, lsl #48
	mul	x17, x17, x0
	eor	x17, x17, x17, lsr #27
	mov	x0, #4587                       ; =0x11eb
	movk	x0, #4913, lsl #16
	movk	x0, #18875, lsl #32
	movk	x0, #38096, lsl #48
	mul	x17, x17, x0
	eor	x0, x17, x17, lsr #31
	ldr	x17, [x12]
	cbz	x17, LBB40_97
LBB40_101:                              ; %bb3.i.i1233.us
                                        ;   in Loop: Header=BB40_98 Depth=2
	lsr	x2, x0, #57
	udiv	x1, x0, x17
	msub	x1, x1, x17, x0
	mov	x0, #72340172838076673          ; =0x101010101010101
	mul	x0, x2, x0
	mov	w2, #1                          ; =0x1
	mov	x3, x17
LBB40_102:                              ; %bb10.i.i1243.us
                                        ;   Parent Loop BB40_18 Depth=1
                                        ;     Parent Loop BB40_98 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	x5, x1, #0x7
	sub	x4, x17, x1
	sub	x6, x19, x5
	cmp	x6, x4
	csel	x4, x6, x4, lo
	cmp	x4, x3
	csel	x4, x4, x3, lo
	cbz	x13, LBB40_105
; %bb.103:                              ; %bb3.i21.i.i1253.us
                                        ;   in Loop: Header=BB40_102 Depth=3
	lsr	x6, x1, #3
	ldr	x7, [x15]
	cmp	x6, x7
	b.hs	LBB40_106
; %bb.104:                              ; %bb8.i.i.i1330.us
                                        ;   in Loop: Header=BB40_102 Depth=3
	add	x6, x15, x6, lsl #3
	ldr	x7, [x6, #8]
	b	LBB40_107
LBB40_105:                              ; %bb2.i.i.i1333.us
                                        ;   in Loop: Header=BB40_102 Depth=3
	cmp	x1, #8
	csel	x7, x14, x21, lo
	b	LBB40_107
LBB40_106:                              ; %bb9.i.i.i1257.us
                                        ;   in Loop: Header=BB40_102 Depth=3
	csel	x7, x14, x21, eq
LBB40_107:                              ; %wf_hash_map.hash_map_control_word.exit.i.i1260.us
                                        ;   in Loop: Header=BB40_102 Depth=3
	lsl	x6, x4, #3
	neg	x6, x6
	lsr	x6, x21, x6
	lsl	x20, x5, #3
	lsl	x22, x6, x20
	and	x6, x7, #0x7f7f7f7f7f7f7f7f
	sub	x6, x21, x6
	and	x6, x6, x7
	and	x6, x22, x6
	cmp	x6, #0
	rbit	x6, x6
	clz	x6, x6
	lsr	x24, x6, #3
	ccmp	x24, x5, #0, ne
	mov	x6, x4
	b.hs	LBB40_109
; %bb.108:                              ; %wf_hash_map.hash_map_control_stop.exit.i.i1284.us
                                        ;   in Loop: Header=BB40_102 Depth=3
	eor	x7, x7, x0
	and	x20, x7, #0x7f7f7f7f7f7f7f7f
	add	x20, x20, x26
	orr	x7, x20, x7
	bic	x22, x22, x7
	cbnz	x22, LBB40_110
	b	LBB40_157
LBB40_109:                              ; %bb5.i.i.i1281.us
                                        ;   in Loop: Header=BB40_102 Depth=3
	sub	x6, x24, x5
	cmp	x6, x4
	csel	x6, x6, x4, lo
	eor	x7, x7, x0
	and	x20, x7, #0x7f7f7f7f7f7f7f7f
	add	x20, x20, x26
	orr	x7, x20, x7
	bic	x22, x22, x7
	cbz	x22, LBB40_157
LBB40_110:                              ; %bb17.i.i1287.us
                                        ;   in Loop: Header=BB40_102 Depth=3
	rbit	x7, x22
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB40_115
; %bb.111:                              ; %bb19.i.i1295.us
                                        ;   in Loop: Header=BB40_102 Depth=3
	cmp	x7, x6
	b.hs	LBB40_115
; %bb.112:                              ; %bb22.i.i1319.us
                                        ;   in Loop: Header=BB40_102 Depth=3
	add	x7, x7, x1
	madd	x7, x7, x30, x12
	ldr	w24, [x7, #16]!
	cmp	w24, #1
	b.eq	LBB40_115
; %bb.113:                              ; %bb22.i.i1319.us
                                        ;   in Loop: Header=BB40_102 Depth=3
	cmp	w24, #2
	b.ne	LBB40_96
; %bb.114:                              ; %bb25.i.i1324.us
                                        ;   in Loop: Header=BB40_102 Depth=3
	ldr	x20, [x7, #8]
	cmp	x20, x16
	b.eq	LBB40_160
LBB40_115:                              ; %bb31.i.i1298.us
                                        ;   in Loop: Header=BB40_102 Depth=3
	sub	x7, x22, #1
	and	x22, x7, x22
	cbz	x22, LBB40_157
; %bb.116:                              ; %bb17.i.i1287.us.1
                                        ;   in Loop: Header=BB40_102 Depth=3
	rbit	x7, x22
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB40_121
; %bb.117:                              ; %bb19.i.i1295.us.1
                                        ;   in Loop: Header=BB40_102 Depth=3
	cmp	x7, x6
	b.hs	LBB40_121
; %bb.118:                              ; %bb22.i.i1319.us.1
                                        ;   in Loop: Header=BB40_102 Depth=3
	add	x7, x7, x1
	madd	x7, x7, x30, x12
	ldr	w24, [x7, #16]!
	cmp	w24, #1
	b.eq	LBB40_121
; %bb.119:                              ; %bb22.i.i1319.us.1
                                        ;   in Loop: Header=BB40_102 Depth=3
	cmp	w24, #2
	b.ne	LBB40_96
; %bb.120:                              ; %bb25.i.i1324.us.1
                                        ;   in Loop: Header=BB40_102 Depth=3
	ldr	x20, [x7, #8]
	cmp	x20, x16
	b.eq	LBB40_160
LBB40_121:                              ; %bb31.i.i1298.us.1
                                        ;   in Loop: Header=BB40_102 Depth=3
	sub	x7, x22, #1
	and	x22, x7, x22
	cbz	x22, LBB40_157
; %bb.122:                              ; %bb17.i.i1287.us.2
                                        ;   in Loop: Header=BB40_102 Depth=3
	rbit	x7, x22
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB40_127
; %bb.123:                              ; %bb19.i.i1295.us.2
                                        ;   in Loop: Header=BB40_102 Depth=3
	cmp	x7, x6
	b.hs	LBB40_127
; %bb.124:                              ; %bb22.i.i1319.us.2
                                        ;   in Loop: Header=BB40_102 Depth=3
	add	x7, x7, x1
	madd	x7, x7, x30, x12
	ldr	w24, [x7, #16]!
	cmp	w24, #1
	b.eq	LBB40_127
; %bb.125:                              ; %bb22.i.i1319.us.2
                                        ;   in Loop: Header=BB40_102 Depth=3
	cmp	w24, #2
	b.ne	LBB40_96
; %bb.126:                              ; %bb25.i.i1324.us.2
                                        ;   in Loop: Header=BB40_102 Depth=3
	ldr	x20, [x7, #8]
	cmp	x20, x16
	b.eq	LBB40_160
LBB40_127:                              ; %bb31.i.i1298.us.2
                                        ;   in Loop: Header=BB40_102 Depth=3
	sub	x7, x22, #1
	and	x22, x7, x22
	cbz	x22, LBB40_157
; %bb.128:                              ; %bb17.i.i1287.us.3
                                        ;   in Loop: Header=BB40_102 Depth=3
	rbit	x7, x22
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB40_133
; %bb.129:                              ; %bb19.i.i1295.us.3
                                        ;   in Loop: Header=BB40_102 Depth=3
	cmp	x7, x6
	b.hs	LBB40_133
; %bb.130:                              ; %bb22.i.i1319.us.3
                                        ;   in Loop: Header=BB40_102 Depth=3
	add	x7, x7, x1
	madd	x7, x7, x30, x12
	ldr	w24, [x7, #16]!
	cmp	w24, #1
	b.eq	LBB40_133
; %bb.131:                              ; %bb22.i.i1319.us.3
                                        ;   in Loop: Header=BB40_102 Depth=3
	cmp	w24, #2
	b.ne	LBB40_96
; %bb.132:                              ; %bb25.i.i1324.us.3
                                        ;   in Loop: Header=BB40_102 Depth=3
	ldr	x20, [x7, #8]
	cmp	x20, x16
	b.eq	LBB40_160
LBB40_133:                              ; %bb31.i.i1298.us.3
                                        ;   in Loop: Header=BB40_102 Depth=3
	sub	x7, x22, #1
	and	x22, x7, x22
	cbz	x22, LBB40_157
; %bb.134:                              ; %bb17.i.i1287.us.4
                                        ;   in Loop: Header=BB40_102 Depth=3
	rbit	x7, x22
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB40_139
; %bb.135:                              ; %bb19.i.i1295.us.4
                                        ;   in Loop: Header=BB40_102 Depth=3
	cmp	x7, x6
	b.hs	LBB40_139
; %bb.136:                              ; %bb22.i.i1319.us.4
                                        ;   in Loop: Header=BB40_102 Depth=3
	add	x7, x7, x1
	madd	x7, x7, x30, x12
	ldr	w24, [x7, #16]!
	cmp	w24, #1
	b.eq	LBB40_139
; %bb.137:                              ; %bb22.i.i1319.us.4
                                        ;   in Loop: Header=BB40_102 Depth=3
	cmp	w24, #2
	b.ne	LBB40_96
; %bb.138:                              ; %bb25.i.i1324.us.4
                                        ;   in Loop: Header=BB40_102 Depth=3
	ldr	x20, [x7, #8]
	cmp	x20, x16
	b.eq	LBB40_160
LBB40_139:                              ; %bb31.i.i1298.us.4
                                        ;   in Loop: Header=BB40_102 Depth=3
	sub	x7, x22, #1
	and	x22, x7, x22
	cbz	x22, LBB40_157
; %bb.140:                              ; %bb17.i.i1287.us.5
                                        ;   in Loop: Header=BB40_102 Depth=3
	rbit	x7, x22
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB40_145
; %bb.141:                              ; %bb19.i.i1295.us.5
                                        ;   in Loop: Header=BB40_102 Depth=3
	cmp	x7, x6
	b.hs	LBB40_145
; %bb.142:                              ; %bb22.i.i1319.us.5
                                        ;   in Loop: Header=BB40_102 Depth=3
	add	x7, x7, x1
	madd	x7, x7, x30, x12
	ldr	w24, [x7, #16]!
	cmp	w24, #1
	b.eq	LBB40_145
; %bb.143:                              ; %bb22.i.i1319.us.5
                                        ;   in Loop: Header=BB40_102 Depth=3
	cmp	w24, #2
	b.ne	LBB40_96
; %bb.144:                              ; %bb25.i.i1324.us.5
                                        ;   in Loop: Header=BB40_102 Depth=3
	ldr	x20, [x7, #8]
	cmp	x20, x16
	b.eq	LBB40_160
LBB40_145:                              ; %bb31.i.i1298.us.5
                                        ;   in Loop: Header=BB40_102 Depth=3
	sub	x7, x22, #1
	and	x22, x7, x22
	cbz	x22, LBB40_157
; %bb.146:                              ; %bb17.i.i1287.us.6
                                        ;   in Loop: Header=BB40_102 Depth=3
	rbit	x7, x22
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB40_151
; %bb.147:                              ; %bb19.i.i1295.us.6
                                        ;   in Loop: Header=BB40_102 Depth=3
	cmp	x7, x6
	b.hs	LBB40_151
; %bb.148:                              ; %bb22.i.i1319.us.6
                                        ;   in Loop: Header=BB40_102 Depth=3
	add	x7, x7, x1
	madd	x7, x7, x30, x12
	ldr	w24, [x7, #16]!
	cmp	w24, #1
	b.eq	LBB40_151
; %bb.149:                              ; %bb22.i.i1319.us.6
                                        ;   in Loop: Header=BB40_102 Depth=3
	cmp	w24, #2
	b.ne	LBB40_96
; %bb.150:                              ; %bb25.i.i1324.us.6
                                        ;   in Loop: Header=BB40_102 Depth=3
	ldr	x20, [x7, #8]
	cmp	x20, x16
	b.eq	LBB40_160
LBB40_151:                              ; %bb31.i.i1298.us.6
                                        ;   in Loop: Header=BB40_102 Depth=3
	sub	x7, x22, #1
	and	x7, x7, x22
	cbz	x7, LBB40_157
; %bb.152:                              ; %bb17.i.i1287.us.7
                                        ;   in Loop: Header=BB40_102 Depth=3
	rbit	x7, x7
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x5, x7, x5
	b.lo	LBB40_157
; %bb.153:                              ; %bb19.i.i1295.us.7
                                        ;   in Loop: Header=BB40_102 Depth=3
	cmp	x5, x6
	b.hs	LBB40_157
; %bb.154:                              ; %bb22.i.i1319.us.7
                                        ;   in Loop: Header=BB40_102 Depth=3
	add	x5, x5, x1
	madd	x7, x5, x30, x12
	ldr	w5, [x7, #16]!
	cmp	w5, #1
	b.eq	LBB40_157
; %bb.155:                              ; %bb22.i.i1319.us.7
                                        ;   in Loop: Header=BB40_102 Depth=3
	cmp	w5, #2
	b.ne	LBB40_161
; %bb.156:                              ; %bb25.i.i1324.us.7
                                        ;   in Loop: Header=BB40_102 Depth=3
	ldr	x5, [x7, #8]
	cmp	x5, x16
	b.eq	LBB40_160
LBB40_157:                              ; %bb14.i.i1303.us
                                        ;   in Loop: Header=BB40_102 Depth=3
	cmp	x6, x4
	b.lo	LBB40_97
; %bb.158:                              ; %bb34.i.i1305.us
                                        ;   in Loop: Header=BB40_102 Depth=3
	add	x1, x4, x1
	cmp	x1, x17
	csel	x1, x1, xzr, lo
	cmp	x2, x17
	b.hs	LBB40_97
; %bb.159:                              ; %bb34.i.i1305.us
                                        ;   in Loop: Header=BB40_102 Depth=3
	add	x2, x2, #1
	sub	x3, x3, x4
	cbnz	x3, LBB40_102
	b	LBB40_97
LBB40_160:                              ; %bb2.i232.us
                                        ;   in Loop: Header=BB40_98 Depth=2
	ldr	x16, [x7, #16]
	str	wzr, [sp, #2576]
	str	x16, [sp, #2584]
	strb	wzr, [sp, #2592]
	mov	w17, #17161                     ; =0x4309
	madd	x8, x8, x17, x16
	add	x8, x8, #131
	str	x8, [sp, #6744]
	add	x9, x9, #1
	cmp	x9, x27
	b.ne	LBB40_98
	b	LBB40_162
LBB40_161:                              ; %bb22.i.i1319.us.7
                                        ;   in Loop: Header=BB40_98 Depth=2
	cbz	w5, LBB40_97
	b	LBB40_179
LBB40_162:                              ; %bb33.lr.ph.us
                                        ;   in Loop: Header=BB40_18 Depth=1
	ldr	x8, [sp, #336]                  ; 8-byte Folded Reload
	add	x8, x8, #1
	str	x8, [sp, #336]                  ; 8-byte Folded Spill
	ldr	x27, [sp, #320]                 ; 8-byte Folded Reload
	mov	w24, #1                         ; =0x1
	ldr	x22, [sp, #672]                 ; 8-byte Folded Reload
LBB40_163:                              ; %bb33.us
                                        ;   Parent Loop BB40_18 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x8, x27, #31
	str	x27, [sp, #2600]
	dup.2d	v0, x27
	ldr	q1, [sp, #656]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2608]
	ldr	q1, [sp, #640]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2624]
	ldr	q1, [sp, #624]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2640]
	ldr	q1, [sp, #608]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2656]
	ldr	q1, [sp, #592]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2672]
	ldr	q1, [sp, #576]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2688]
	ldr	q1, [sp, #560]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2704]
	ldr	q1, [sp, #544]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2720]
	ldr	q1, [sp, #528]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2736]
	ldr	q1, [sp, #512]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2752]
	ldr	q1, [sp, #496]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2768]
	ldr	q1, [sp, #480]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2784]
	ldr	q1, [sp, #464]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2800]
	ldr	q1, [sp, #448]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2816]
	ldr	q1, [sp, #432]                  ; 16-byte Folded Reload
	add.2d	v0, v0, v1
	str	q0, [sp, #2832]
	str	x8, [sp, #2848]
	ldp	q0, q1, [x25, #192]
	str	q0, [sp, #6992]
	str	q1, [sp, #7008]
	ldp	q0, q1, [x25, #224]
	str	q0, [sp, #7024]
	str	q1, [sp, #7040]
	ldp	q0, q1, [x25, #128]
	str	q0, [sp, #6928]
	str	q1, [sp, #6944]
	ldp	q0, q1, [x25, #160]
	str	q0, [sp, #6960]
	str	q1, [sp, #6976]
	ldp	q0, q1, [x25, #64]
	str	q0, [sp, #6864]
	str	q1, [sp, #6880]
	ldp	q0, q1, [x25, #96]
	str	q0, [sp, #6896]
	str	q1, [sp, #6912]
	ldp	q0, q1, [x25]
	str	q0, [sp, #6800]
	str	q1, [sp, #6816]
	ldp	q0, q1, [x25, #32]
	str	q0, [sp, #6832]
	str	q1, [sp, #6848]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2704
	add	x0, x8, #256
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #2704
	add	x8, sp, #704
	mov	w9, #5984                       ; =0x1760
	add	x4, x8, x9
	ldr	x1, [sp, #696]                  ; 8-byte Folded Reload
	mov	x2, x24
	bl	_wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65
	ldr	w8, [sp, #7056]
	cbz	w8, LBB40_168
; %bb.164:                              ; %bb33.us
                                        ;   in Loop: Header=BB40_163 Depth=2
	cmp	w8, #1
	b.ne	LBB40_179
; %bb.165:                              ; %bb2.i304.us
                                        ;   in Loop: Header=BB40_163 Depth=2
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2704
	ldrb	w20, [x8, #260]
	add	x0, x8, #528
	add	x1, x8, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	tbz	w20, #0, LBB40_170
; %bb.166:                              ; %bb4.i.us
                                        ;   in Loop: Header=BB40_163 Depth=2
	ldr	x8, [sp, #6704]
	ldr	x8, [x8]
	lsr	x9, x8, #14
	cbz	x9, LBB40_173
LBB40_167:                              ; %bb6.i.us
                                        ;   in Loop: Header=BB40_163 Depth=2
	mov	w9, #1                          ; =0x1
	str	x9, [sp, #2856]
	add	x8, sp, #704
	strb	w9, [x8, #2156]
	b	LBB40_171
LBB40_168:                              ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit.thread1606.us"
                                        ;   in Loop: Header=BB40_163 Depth=2
	ldr	x8, [sp, #416]                  ; 8-byte Folded Reload
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #240]
	stp	q0, q0, [x8, #208]
	stp	q0, q0, [x8, #176]
	stp	q0, q0, [x8, #144]
	stp	q0, q0, [x8, #112]
	stp	q0, q0, [x8, #80]
	stp	q0, q0, [x8, #48]
	stp	q0, q0, [x8, #16]
	str	q0, [x8]
LBB40_169:                              ; %bb37.us
                                        ;   in Loop: Header=BB40_163 Depth=2
	ldr	x8, [sp, #6744]
	mul	x8, x8, x28
	str	x8, [sp, #6744]
	add	x24, x24, #4
	add	x27, x27, #2
	subs	x22, x22, #1
	b.ne	LBB40_163
	b	LBB40_17
LBB40_170:                              ; %bb3.i305.us
                                        ;   in Loop: Header=BB40_163 Depth=2
	mov	w8, #1                          ; =0x1
	str	x8, [sp, #2856]
LBB40_171:                              ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit.thread.us"
                                        ;   in Loop: Header=BB40_163 Depth=2
	add	x23, sp, #704
	add	x0, x23, #2160
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2704
	add	x1, x8, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
LBB40_172:                              ; %bb38.us
                                        ;   in Loop: Header=BB40_163 Depth=2
	add	x8, sp, #704
	ldrb	w20, [x8, #2156]
	add	x0, x8, #2424
	add	x1, x23, #2160
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	ldr	x8, [sp, #6744]
	cmp	w20, #0
	mov	w9, #1                          ; =0x1
	cinc	x9, x9, ne
	madd	x8, x8, x28, x9
	ldr	x9, [sp, #3128]
	ldr	x11, [sp, #352]                 ; 8-byte Folded Reload
	ldp	q1, q0, [x11, #96]
	ldr	x10, [sp, #368]                 ; 8-byte Folded Reload
	stp	q1, q0, [x10, #96]
	ldp	q1, q0, [x11, #64]
	stp	q1, q0, [x10, #64]
	ldp	q1, q0, [x11, #160]
	stp	q1, q0, [x10, #160]
	ldp	q1, q0, [x11, #128]
	stp	q1, q0, [x10, #128]
	ldp	q1, q0, [x11, #224]
	stp	q1, q0, [x10, #224]
	ldp	q1, q0, [x11, #192]
	stp	q1, q0, [x10, #192]
	ldp	q1, q0, [x11, #32]
	stp	q1, q0, [x10, #32]
	ldp	q0, q1, [x11]
	stp	q0, q1, [x10]
	ldr	x10, [sp, #3392]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3400]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3408]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3416]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3424]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3432]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3440]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3448]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3456]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3464]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3472]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3480]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3488]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3496]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3504]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3512]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3520]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3528]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3536]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3544]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3552]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3560]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3568]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3576]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3584]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3592]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3600]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3608]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3616]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3624]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #3632]
	add	x8, x8, x10
	madd	x8, x9, x28, x8
	ldr	x9, [sp, #3640]
	madd	x8, x8, x28, x9
	mov	w23, #6072                      ; =0x17b8
	str	x8, [sp, #6744]
	add	x24, x24, #4
	add	x27, x27, #2
	subs	x22, x22, #1
	b.ne	LBB40_163
	b	LBB40_17
LBB40_173:                              ; %bb7.i.us
                                        ;   in Loop: Header=BB40_163 Depth=2
	cmp	x8, #2, lsl #12                 ; =8192
	mov	w9, #8192                       ; =0x2000
	csel	x9, x8, x9, lo
	lsl	x9, x9, #1
	cmp	x8, #0
	csinc	x1, x9, xzr, ne
	cmp	x1, x8
	b.ls	LBB40_176
; %bb.174:                              ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.i.us"
                                        ;   in Loop: Header=BB40_163 Depth=2
	add	x8, sp, #704
	mov	w9, #5984                       ; =0x1760
	add	x2, x8, x9
	ldr	x0, [sp, #696]                  ; 8-byte Folded Reload
	bl	_wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	str	w0, [sp, #7592]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2704
	strb	w1, [x8, #796]
	strb	w2, [x8, #797]
	cbz	w0, LBB40_177
; %bb.175:                              ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.i.us"
                                        ;   in Loop: Header=BB40_163 Depth=2
	cmp	w0, #1
	b.eq	LBB40_167
	b	LBB40_179
LBB40_176:                              ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.thread.i.us"
                                        ;   in Loop: Header=BB40_163 Depth=2
	str	wzr, [sp, #7592]
	strh	wzr, [sp, #7596]
LBB40_177:                              ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit.us"
                                        ;   in Loop: Header=BB40_163 Depth=2
	ldr	x2, [sp, #7328]
	ldp	x8, x3, [sp, #304]              ; 16-byte Folded Reload
	ldp	q0, q1, [x8, #192]
	stp	q0, q1, [x3, #192]
	ldp	q0, q1, [x8, #224]
	stp	q0, q1, [x3, #224]
	ldp	q0, q1, [x8, #128]
	stp	q0, q1, [x3, #128]
	ldp	q0, q1, [x8, #160]
	stp	q0, q1, [x3, #160]
	ldp	q0, q1, [x8, #64]
	stp	q0, q1, [x3, #64]
	ldp	q0, q1, [x8, #96]
	stp	q0, q1, [x3, #96]
	ldp	q0, q1, [x8]
	stp	q0, q1, [x3]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x3, #32]
	add	x8, sp, #704
	mov	w9, #5984                       ; =0x1760
	add	x4, x8, x9
	ldr	x0, [sp, #416]                  ; 8-byte Folded Reload
	ldr	x1, [sp, #696]                  ; 8-byte Folded Reload
	bl	_wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65
	ldr	w8, [sp, #2856]
	cbz	w8, LBB40_169
; %bb.178:                              ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit.us"
                                        ;   in Loop: Header=BB40_163 Depth=2
	cmp	w8, #1
	add	x23, sp, #704
	b.eq	LBB40_172
LBB40_179:                              ; %invalid.tag.b2
	bl	_abort
LBB40_180:                              ; %bb13.preheader
	mov	x20, #0                         ; =0x0
	add	x10, sp, #704
	add	x26, x10, #2976
	add	x8, x10, #3232
	str	x8, [sp, #96]                   ; 8-byte Folded Spill
Lloh112:
	adrp	x8, lCPI40_16@PAGE
Lloh113:
	ldr	q0, [x8, lCPI40_16@PAGEOFF]
	str	q0, [sp, #592]                  ; 16-byte Folded Spill
	add	x8, x10, #3768
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
Lloh114:
	adrp	x8, lCPI40_17@PAGE
Lloh115:
	ldr	q0, [x8, lCPI40_17@PAGEOFF]
	str	q0, [sp, #576]                  ; 16-byte Folded Spill
	mov	w8, #4296                       ; =0x10c8
Lloh116:
	adrp	x9, lCPI40_18@PAGE
Lloh117:
	ldr	q0, [x9, lCPI40_18@PAGEOFF]
	str	q0, [sp, #560]                  ; 16-byte Folded Spill
	add	x8, x10, x8
	str	x8, [sp, #80]                   ; 8-byte Folded Spill
Lloh118:
	adrp	x8, lCPI40_19@PAGE
Lloh119:
	ldr	q0, [x8, lCPI40_19@PAGEOFF]
	str	q0, [sp, #544]                  ; 16-byte Folded Spill
	mov	w8, #4560                       ; =0x11d0
Lloh120:
	adrp	x9, lCPI40_20@PAGE
Lloh121:
	ldr	q0, [x9, lCPI40_20@PAGEOFF]
	str	q0, [sp, #528]                  ; 16-byte Folded Spill
	add	x8, x10, x8
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
Lloh122:
	adrp	x8, lCPI40_21@PAGE
Lloh123:
	ldr	q0, [x8, lCPI40_21@PAGEOFF]
	str	q0, [sp, #512]                  ; 16-byte Folded Spill
	mov	w8, #4840                       ; =0x12e8
Lloh124:
	adrp	x9, lCPI40_22@PAGE
Lloh125:
	ldr	q0, [x9, lCPI40_22@PAGEOFF]
	str	q0, [sp, #496]                  ; 16-byte Folded Spill
	add	x28, x10, x8
Lloh126:
	adrp	x8, lCPI40_23@PAGE
Lloh127:
	ldr	q0, [x8, lCPI40_23@PAGEOFF]
	str	q0, [sp, #480]                  ; 16-byte Folded Spill
	mov	w8, #5096                       ; =0x13e8
Lloh128:
	adrp	x9, lCPI40_24@PAGE
Lloh129:
	ldr	q0, [x9, lCPI40_24@PAGEOFF]
	str	q0, [sp, #464]                  ; 16-byte Folded Spill
	add	x8, x10, x8
	str	x8, [sp, #88]                   ; 8-byte Folded Spill
Lloh130:
	adrp	x8, lCPI40_25@PAGE
Lloh131:
	ldr	q0, [x8, lCPI40_25@PAGEOFF]
	str	q0, [sp, #448]                  ; 16-byte Folded Spill
	mov	w8, #5368                       ; =0x14f8
Lloh132:
	adrp	x9, lCPI40_26@PAGE
Lloh133:
	ldr	q0, [x9, lCPI40_26@PAGEOFF]
	str	q0, [sp, #432]                  ; 16-byte Folded Spill
	add	x8, x10, x8
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
Lloh134:
	adrp	x8, lCPI40_27@PAGE
Lloh135:
	ldr	q0, [x8, lCPI40_27@PAGEOFF]
	str	q0, [sp, #416]                  ; 16-byte Folded Spill
	mov	w8, #5632                       ; =0x1600
Lloh136:
	adrp	x9, lCPI40_28@PAGE
Lloh137:
	ldr	q0, [x9, lCPI40_28@PAGEOFF]
	str	q0, [sp, #400]                  ; 16-byte Folded Spill
	add	x8, x10, x8
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
Lloh138:
	adrp	x8, lCPI40_29@PAGE
Lloh139:
	ldr	q0, [x8, lCPI40_29@PAGEOFF]
	str	q0, [sp, #384]                  ; 16-byte Folded Spill
Lloh140:
	adrp	x8, lCPI40_30@PAGE
Lloh141:
	ldr	q0, [x8, lCPI40_30@PAGEOFF]
	str	q0, [sp, #368]                  ; 16-byte Folded Spill
	sub	x8, x24, #9
	str	x8, [sp, #672]                  ; 8-byte Folded Spill
Lloh142:
	adrp	x8, lCPI40_1@PAGE
Lloh143:
	ldr	q0, [x8, lCPI40_1@PAGEOFF]
	str	q0, [sp, #352]                  ; 16-byte Folded Spill
Lloh144:
	adrp	x8, lCPI40_2@PAGE
Lloh145:
	ldr	q0, [x8, lCPI40_2@PAGEOFF]
	str	q0, [sp, #336]                  ; 16-byte Folded Spill
	add	x8, x11, #4040
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
Lloh146:
	adrp	x8, lCPI40_3@PAGE
Lloh147:
	ldr	q0, [x8, lCPI40_3@PAGEOFF]
	str	q0, [sp, #320]                  ; 16-byte Folded Spill
	mov	w8, #5112                       ; =0x13f8
Lloh148:
	adrp	x9, lCPI40_4@PAGE
Lloh149:
	ldr	q0, [x9, lCPI40_4@PAGEOFF]
	str	q0, [sp, #288]                  ; 16-byte Folded Spill
	add	x8, x11, x8
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
Lloh150:
	adrp	x8, lCPI40_5@PAGE
Lloh151:
	ldr	q0, [x8, lCPI40_5@PAGEOFF]
	str	q0, [sp, #272]                  ; 16-byte Folded Spill
	add	x8, x11, #3248
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
Lloh152:
	adrp	x8, lCPI40_6@PAGE
Lloh153:
	ldr	q0, [x8, lCPI40_6@PAGEOFF]
	str	q0, [sp, #256]                  ; 16-byte Folded Spill
	mov	w23, #131                       ; =0x83
Lloh154:
	adrp	x8, lCPI40_7@PAGE
Lloh155:
	ldr	q0, [x8, lCPI40_7@PAGEOFF]
	str	q0, [sp, #240]                  ; 16-byte Folded Spill
Lloh156:
	adrp	x8, lCPI40_8@PAGE
Lloh157:
	ldr	q0, [x8, lCPI40_8@PAGEOFF]
	str	q0, [sp, #224]                  ; 16-byte Folded Spill
	mov	w6, #1                          ; =0x1
Lloh158:
	adrp	x8, lCPI40_9@PAGE
Lloh159:
	ldr	q0, [x8, lCPI40_9@PAGEOFF]
	str	q0, [sp, #208]                  ; 16-byte Folded Spill
Lloh160:
	adrp	x8, lCPI40_10@PAGE
Lloh161:
	ldr	q0, [x8, lCPI40_10@PAGEOFF]
	str	q0, [sp, #192]                  ; 16-byte Folded Spill
Lloh162:
	adrp	x8, lCPI40_11@PAGE
Lloh163:
	ldr	q0, [x8, lCPI40_11@PAGEOFF]
	str	q0, [sp, #176]                  ; 16-byte Folded Spill
Lloh164:
	adrp	x8, lCPI40_12@PAGE
Lloh165:
	ldr	q0, [x8, lCPI40_12@PAGEOFF]
	str	q0, [sp, #160]                  ; 16-byte Folded Spill
Lloh166:
	adrp	x8, lCPI40_13@PAGE
Lloh167:
	ldr	q0, [x8, lCPI40_13@PAGEOFF]
	str	q0, [sp, #144]                  ; 16-byte Folded Spill
Lloh168:
	adrp	x8, lCPI40_14@PAGE
Lloh169:
	ldr	q0, [x8, lCPI40_14@PAGEOFF]
	str	q0, [sp, #128]                  ; 16-byte Folded Spill
	mov	w27, #8                         ; =0x8
Lloh170:
	adrp	x8, lCPI40_15@PAGE
Lloh171:
	ldr	q0, [x8, lCPI40_15@PAGEOFF]
	str	q0, [sp, #112]                  ; 16-byte Folded Spill
	mov	x25, #-9187201950435737472      ; =0x8080808080808080
	mov	x22, #9187201950435737471       ; =0x7f7f7f7f7f7f7f7f
	mov	w7, #272                        ; =0x110
	str	x19, [sp, #16]                  ; 8-byte Folded Spill
	b	LBB40_182
LBB40_181:                              ; %bb93.loopexit1667
                                        ;   in Loop: Header=BB40_182 Depth=1
	ldr	x8, [sp, #104]                  ; 8-byte Folded Reload
	ldr	x20, [sp, #608]                 ; 8-byte Folded Reload
	cmp	x20, x8
	ldr	x19, [sp, #16]                  ; 8-byte Folded Reload
	b.eq	LBB40_384
LBB40_182:                              ; %bb13
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB40_202 Depth 2
                                        ;       Child Loop BB40_286 Depth 3
                                        ;       Child Loop BB40_216 Depth 3
	cmp	x24, #4
	b.eq	LBB40_186
; %bb.183:                              ; %bb13
                                        ;   in Loop: Header=BB40_182 Depth=1
	cmp	x24, #9
	b.eq	LBB40_186
; %bb.184:                              ; %bb13
                                        ;   in Loop: Header=BB40_182 Depth=1
	cmp	x24, #10
	b.ne	LBB40_195
; %bb.185:                              ; %bb49.thread
                                        ;   in Loop: Header=BB40_182 Depth=1
	ldr	x8, [sp, #6744]
	mov	x9, #1                          ; =0x1
	madd	x8, x8, x23, x9
	str	x8, [sp, #6744]
	b	LBB40_194
LBB40_186:                              ; %bb51
                                        ;   in Loop: Header=BB40_182 Depth=1
	cmp	x19, #4, lsl #12                ; =16384
	b.ls	LBB40_190
; %bb.187:                              ;   in Loop: Header=BB40_182 Depth=1
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	str	w0, [sp, #3648]
	strb	w1, [sp, #3652]
	strb	w2, [sp, #3653]
	cbz	w0, LBB40_193
LBB40_188:                              ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit"
                                        ;   in Loop: Header=BB40_182 Depth=1
	cmp	w0, #1
	b.ne	LBB40_179
; %bb.189:                              ; %bb3.i458
                                        ;   in Loop: Header=BB40_182 Depth=1
	ldr	x8, [sp, #6744]
	mul	x8, x8, x23
	str	x8, [sp, #6744]
	ldr	x9, [sp, #672]                  ; 8-byte Folded Reload
	cmp	x9, #2
	b.lo	LBB40_194
	b	LBB40_195
LBB40_190:                              ; %bb3.i.i450
                                        ;   in Loop: Header=BB40_182 Depth=1
	ldr	x8, [sp, #6704]
	ldr	x8, [x8]
	cmp	x19, x8
	b.ls	LBB40_192
; %bb.191:                              ; %bb6.i.i
                                        ;   in Loop: Header=BB40_182 Depth=1
	add	x8, sp, #704
	mov	w9, #5984                       ; =0x1760
	add	x2, x8, x9
	ldr	x0, [sp, #696]                  ; 8-byte Folded Reload
	mov	x1, x19
	bl	_wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	mov	w7, #272                        ; =0x110
	mov	w6, #1                          ; =0x1
	str	w0, [sp, #3648]
	strb	w1, [sp, #3652]
	strb	w2, [sp, #3653]
	cbnz	w0, LBB40_188
	b	LBB40_193
LBB40_192:                              ;   in Loop: Header=BB40_182 Depth=1
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #3648]
	strb	w1, [sp, #3652]
	strb	w2, [sp, #3653]
	cbnz	w0, LBB40_188
LBB40_193:                              ; %bb2.i463
                                        ;   in Loop: Header=BB40_182 Depth=1
	ldr	x8, [sp, #6744]
	mov	x9, #1                          ; =0x1
	madd	x8, x8, x23, x9
	str	x8, [sp, #6744]
	ldr	x9, [sp, #672]                  ; 8-byte Folded Reload
	cmp	x9, #2
	b.hs	LBB40_195
LBB40_194:                              ; %bb53
                                        ;   in Loop: Header=BB40_182 Depth=1
	ldr	x9, [sp, #6704]
	ldr	x9, [x9]
	cmp	x9, x19
	mul	x8, x8, x23
	cinc	x8, x8, hs
	str	x8, [sp, #6744]
LBB40_195:                              ; %bb43
                                        ;   in Loop: Header=BB40_182 Depth=1
	add	x20, x20, #1
	str	x20, [sp, #608]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #688]                  ; 8-byte Folded Reload
	ldr	x19, [sp, #624]                 ; 8-byte Folded Reload
	cbz	x8, LBB40_181
; %bb.196:                              ; %bb59.lr.ph
                                        ;   in Loop: Header=BB40_182 Depth=1
	mov	x20, #0                         ; =0x0
	ldr	x8, [sp, #688]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	ldr	x10, [sp, #608]                 ; 8-byte Folded Reload
	madd	x8, x10, x8, x9
	str	x8, [sp, #640]                  ; 8-byte Folded Spill
	b	LBB40_202
LBB40_197:                              ; %bb22.i.i1441
                                        ;   in Loop: Header=BB40_202 Depth=2
	cbnz	w5, LBB40_179
LBB40_198:                              ; %bb3.i497
                                        ;   in Loop: Header=BB40_202 Depth=2
	str	w6, [sp, #3656]
	str	xzr, [sp, #3664]
	strb	wzr, [sp, #3672]
LBB40_199:                              ; %bb92.sink.split
                                        ;   in Loop: Header=BB40_202 Depth=2
	ldr	x8, [sp, #6744]
	mul	x8, x8, x23
LBB40_200:                              ; %bb92.sink.split
                                        ;   in Loop: Header=BB40_202 Depth=2
	str	x8, [sp, #6744]
LBB40_201:                              ; %bb92
                                        ;   in Loop: Header=BB40_202 Depth=2
	add	x20, x20, #1
	ldr	x8, [sp, #688]                  ; 8-byte Folded Reload
	cmp	x20, x8
	b.eq	LBB40_181
LBB40_202:                              ; %bb59
                                        ;   Parent Loop BB40_182 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB40_286 Depth 3
                                        ;       Child Loop BB40_216 Depth 3
	add	x8, x20, x19
	orr	x2, x6, x8, lsl #1
	str	x2, [sp, #6792]
	cmp	x24, #3
	b.gt	LBB40_209
; %bb.203:                              ; %bb59
                                        ;   in Loop: Header=BB40_202 Depth=2
	cmp	x24, #2
	b.lo	LBB40_212
; %bb.204:                              ; %bb59
                                        ;   in Loop: Header=BB40_202 Depth=2
	b.eq	LBB40_274
; %bb.205:                              ; %bb59
                                        ;   in Loop: Header=BB40_202 Depth=2
	cmp	x24, #3
	b.ne	LBB40_201
; %bb.206:                              ; %bb78
                                        ;   in Loop: Header=BB40_202 Depth=2
	mov	w21, #1                         ; =0x1
	add	x8, sp, #704
	add	x0, x8, #4024
	mov	w9, #6088                       ; =0x17c8
	add	x2, x8, x9
	mov	w9, #5984                       ; =0x1760
	add	x3, x8, x9
	ldr	x1, [sp, #696]                  ; 8-byte Folded Reload
	bl	_wf_hash_map.hash_map_remove$instance$28da32efc51c2b65
	ldr	w8, [sp, #4728]
	cbz	w8, LBB40_281
; %bb.207:                              ; %bb78
                                        ;   in Loop: Header=BB40_202 Depth=2
	cmp	w8, #1
	b.ne	LBB40_179
; %bb.208:                              ; %bb81
                                        ;   in Loop: Header=BB40_202 Depth=2
	add	x8, sp, #704
	add	x1, x8, #4032
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	ldr	x8, [sp, #6744]
	ldr	x9, [sp, #5000]
	ldp	x11, x10, [sp, #64]             ; 16-byte Folded Reload
	ldp	q1, q0, [x11, #32]
	stp	q1, q0, [x10, #32]
	ldp	q1, q0, [x11, #96]
	stp	q1, q0, [x10, #96]
	ldp	q1, q0, [x11, #64]
	stp	q1, q0, [x10, #64]
	ldp	q1, q0, [x11, #160]
	stp	q1, q0, [x10, #160]
	ldp	q1, q0, [x11, #128]
	stp	q1, q0, [x10, #128]
	ldp	q1, q0, [x11, #224]
	stp	q1, q0, [x10, #224]
	ldp	q1, q0, [x11, #192]
	stp	q1, q0, [x10, #192]
	ldp	q1, q0, [x11]
	stp	q1, q0, [x10]
	ldr	x10, [sp, #5504]
	madd	x8, x8, x23, x10
	ldr	x10, [sp, #5264]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5272]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5280]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5288]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5296]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5304]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5312]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5320]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5328]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5336]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5344]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5352]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5360]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5368]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5376]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5384]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5392]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5400]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5408]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5416]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5424]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5432]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5440]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5448]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5456]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5464]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5472]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5480]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5488]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #5496]
	madd	x9, x9, x23, x10
	madd	x8, x9, x23, x8
	ldr	x9, [sp, #5512]
	madd	x8, x8, x23, x9
	add	x8, x8, #131
	b	LBB40_282
LBB40_209:                              ; %bb59
                                        ;   in Loop: Header=BB40_202 Depth=2
	ldr	x8, [sp, #672]                  ; 8-byte Folded Reload
	cmp	x8, #2
	b.lo	LBB40_212
; %bb.210:                              ; %bb59
                                        ;   in Loop: Header=BB40_202 Depth=2
	cmp	x24, #7
	b.eq	LBB40_279
; %bb.211:                              ; %bb59
                                        ;   in Loop: Header=BB40_202 Depth=2
	cmp	x24, #4
	b.ne	LBB40_201
LBB40_212:                              ; %bb66
                                        ;   in Loop: Header=BB40_202 Depth=2
	add	x8, sp, #704
	mov	w9, #5992                       ; =0x1768
	ldrb	w8, [x8, x9]
	tbz	w8, #0, LBB40_214
; %bb.213:                              ;   in Loop: Header=BB40_202 Depth=2
	mov	x10, #0                         ; =0x0
	ldr	x8, [sp, #6704]
	ldr	x9, [x8]
	cbnz	x9, LBB40_215
	b	LBB40_198
LBB40_214:                              ; %bb3.i.i.i1339
                                        ;   in Loop: Header=BB40_202 Depth=2
	ldr	x8, [sp, #6688]
	eor	x8, x8, x2
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x10, x8, x8, lsr #31
	ldr	x8, [sp, #6704]
	ldr	x9, [x8]
	cbz	x9, LBB40_198
LBB40_215:                              ; %bb3.i.i1355
                                        ;   in Loop: Header=BB40_202 Depth=2
	lsr	x13, x10, #57
	udiv	x11, x10, x9
	msub	x11, x11, x9, x10
	ldr	x10, [sp, #6728]
	ldr	x12, [sp, #6720]
	mov	x14, #72340172838076673         ; =0x101010101010101
	mul	x13, x13, x14
	ldr	x14, [sp, #6736]
	mov	w15, #1                         ; =0x1
	mov	x16, x9
LBB40_216:                              ; %bb10.i.i1365
                                        ;   Parent Loop BB40_182 Depth=1
                                        ;     Parent Loop BB40_202 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	x0, x11, #0x7
	sub	x17, x9, x11
	sub	x1, x27, x0
	cmp	x1, x17
	csel	x17, x1, x17, lo
	cmp	x17, x16
	csel	x17, x17, x16, lo
	cbz	x10, LBB40_219
; %bb.217:                              ; %bb3.i21.i.i1375
                                        ;   in Loop: Header=BB40_216 Depth=3
	lsr	x1, x11, #3
	ldr	x3, [x14]
	cmp	x1, x3
	b.hs	LBB40_220
; %bb.218:                              ; %bb8.i.i.i1452
                                        ;   in Loop: Header=BB40_216 Depth=3
	add	x1, x14, x1, lsl #3
	ldr	x3, [x1, #8]
	b	LBB40_221
LBB40_219:                              ; %bb2.i.i.i1455
                                        ;   in Loop: Header=BB40_216 Depth=3
	cmp	x11, #8
	csel	x3, x12, x25, lo
	b	LBB40_221
LBB40_220:                              ; %bb9.i.i.i1379
                                        ;   in Loop: Header=BB40_216 Depth=3
	csel	x3, x12, x25, eq
LBB40_221:                              ; %wf_hash_map.hash_map_control_word.exit.i.i1382
                                        ;   in Loop: Header=BB40_216 Depth=3
	lsl	x1, x17, #3
	neg	x1, x1
	lsr	x1, x25, x1
	lsl	x4, x0, #3
	lsl	x4, x1, x4
	and	x1, x3, #0x7f7f7f7f7f7f7f7f
	sub	x1, x25, x1
	and	x1, x1, x3
	and	x1, x4, x1
	cmp	x1, #0
	rbit	x1, x1
	clz	x1, x1
	lsr	x5, x1, #3
	ccmp	x5, x0, #0, ne
	mov	x1, x17
	b.hs	LBB40_223
; %bb.222:                              ; %wf_hash_map.hash_map_control_stop.exit.i.i1406
                                        ;   in Loop: Header=BB40_216 Depth=3
	eor	x3, x3, x13
	and	x5, x3, #0x7f7f7f7f7f7f7f7f
	add	x5, x5, x22
	orr	x3, x5, x3
	bic	x4, x4, x3
	cbnz	x4, LBB40_224
	b	LBB40_271
LBB40_223:                              ; %bb5.i.i.i1403
                                        ;   in Loop: Header=BB40_216 Depth=3
	sub	x1, x5, x0
	cmp	x1, x17
	csel	x1, x1, x17, lo
	eor	x3, x3, x13
	and	x5, x3, #0x7f7f7f7f7f7f7f7f
	add	x5, x5, x22
	orr	x3, x5, x3
	bic	x4, x4, x3
	cbz	x4, LBB40_271
LBB40_224:                              ; %bb17.i.i1409
                                        ;   in Loop: Header=BB40_216 Depth=3
	rbit	x3, x4
	clz	x3, x3
	lsr	x3, x3, #3
	subs	x3, x3, x0
	b.lo	LBB40_229
; %bb.225:                              ; %bb19.i.i1417
                                        ;   in Loop: Header=BB40_216 Depth=3
	cmp	x3, x1
	b.hs	LBB40_229
; %bb.226:                              ; %bb22.i.i1441
                                        ;   in Loop: Header=BB40_216 Depth=3
	add	x3, x3, x11
	madd	x3, x3, x7, x8
	ldr	w5, [x3, #16]!
	cmp	w5, #1
	b.eq	LBB40_229
; %bb.227:                              ; %bb22.i.i1441
                                        ;   in Loop: Header=BB40_216 Depth=3
	cmp	w5, #2
	b.ne	LBB40_197
; %bb.228:                              ; %bb25.i.i1446
                                        ;   in Loop: Header=BB40_216 Depth=3
	ldr	x5, [x3, #8]
	cmp	x5, x2
	b.eq	LBB40_348
LBB40_229:                              ; %bb31.i.i1420
                                        ;   in Loop: Header=BB40_216 Depth=3
	sub	x3, x4, #1
	and	x4, x3, x4
	cbz	x4, LBB40_271
; %bb.230:                              ; %bb17.i.i1409.1
                                        ;   in Loop: Header=BB40_216 Depth=3
	rbit	x3, x4
	clz	x3, x3
	lsr	x3, x3, #3
	subs	x3, x3, x0
	b.lo	LBB40_235
; %bb.231:                              ; %bb19.i.i1417.1
                                        ;   in Loop: Header=BB40_216 Depth=3
	cmp	x3, x1
	b.hs	LBB40_235
; %bb.232:                              ; %bb22.i.i1441.1
                                        ;   in Loop: Header=BB40_216 Depth=3
	add	x3, x3, x11
	madd	x3, x3, x7, x8
	ldr	w5, [x3, #16]!
	cmp	w5, #1
	b.eq	LBB40_235
; %bb.233:                              ; %bb22.i.i1441.1
                                        ;   in Loop: Header=BB40_216 Depth=3
	cmp	w5, #2
	b.ne	LBB40_197
; %bb.234:                              ; %bb25.i.i1446.1
                                        ;   in Loop: Header=BB40_216 Depth=3
	ldr	x5, [x3, #8]
	cmp	x5, x2
	b.eq	LBB40_348
LBB40_235:                              ; %bb31.i.i1420.1
                                        ;   in Loop: Header=BB40_216 Depth=3
	sub	x3, x4, #1
	and	x4, x3, x4
	cbz	x4, LBB40_271
; %bb.236:                              ; %bb17.i.i1409.2
                                        ;   in Loop: Header=BB40_216 Depth=3
	rbit	x3, x4
	clz	x3, x3
	lsr	x3, x3, #3
	subs	x3, x3, x0
	b.lo	LBB40_241
; %bb.237:                              ; %bb19.i.i1417.2
                                        ;   in Loop: Header=BB40_216 Depth=3
	cmp	x3, x1
	b.hs	LBB40_241
; %bb.238:                              ; %bb22.i.i1441.2
                                        ;   in Loop: Header=BB40_216 Depth=3
	add	x3, x3, x11
	madd	x3, x3, x7, x8
	ldr	w5, [x3, #16]!
	cmp	w5, #1
	b.eq	LBB40_241
; %bb.239:                              ; %bb22.i.i1441.2
                                        ;   in Loop: Header=BB40_216 Depth=3
	cmp	w5, #2
	b.ne	LBB40_197
; %bb.240:                              ; %bb25.i.i1446.2
                                        ;   in Loop: Header=BB40_216 Depth=3
	ldr	x5, [x3, #8]
	cmp	x5, x2
	b.eq	LBB40_348
LBB40_241:                              ; %bb31.i.i1420.2
                                        ;   in Loop: Header=BB40_216 Depth=3
	sub	x3, x4, #1
	and	x4, x3, x4
	cbz	x4, LBB40_271
; %bb.242:                              ; %bb17.i.i1409.3
                                        ;   in Loop: Header=BB40_216 Depth=3
	rbit	x3, x4
	clz	x3, x3
	lsr	x3, x3, #3
	subs	x3, x3, x0
	b.lo	LBB40_247
; %bb.243:                              ; %bb19.i.i1417.3
                                        ;   in Loop: Header=BB40_216 Depth=3
	cmp	x3, x1
	b.hs	LBB40_247
; %bb.244:                              ; %bb22.i.i1441.3
                                        ;   in Loop: Header=BB40_216 Depth=3
	add	x3, x3, x11
	madd	x3, x3, x7, x8
	ldr	w5, [x3, #16]!
	cmp	w5, #1
	b.eq	LBB40_247
; %bb.245:                              ; %bb22.i.i1441.3
                                        ;   in Loop: Header=BB40_216 Depth=3
	cmp	w5, #2
	b.ne	LBB40_197
; %bb.246:                              ; %bb25.i.i1446.3
                                        ;   in Loop: Header=BB40_216 Depth=3
	ldr	x5, [x3, #8]
	cmp	x5, x2
	b.eq	LBB40_348
LBB40_247:                              ; %bb31.i.i1420.3
                                        ;   in Loop: Header=BB40_216 Depth=3
	sub	x3, x4, #1
	and	x4, x3, x4
	cbz	x4, LBB40_271
; %bb.248:                              ; %bb17.i.i1409.4
                                        ;   in Loop: Header=BB40_216 Depth=3
	rbit	x3, x4
	clz	x3, x3
	lsr	x3, x3, #3
	subs	x3, x3, x0
	b.lo	LBB40_253
; %bb.249:                              ; %bb19.i.i1417.4
                                        ;   in Loop: Header=BB40_216 Depth=3
	cmp	x3, x1
	b.hs	LBB40_253
; %bb.250:                              ; %bb22.i.i1441.4
                                        ;   in Loop: Header=BB40_216 Depth=3
	add	x3, x3, x11
	madd	x3, x3, x7, x8
	ldr	w5, [x3, #16]!
	cmp	w5, #1
	b.eq	LBB40_253
; %bb.251:                              ; %bb22.i.i1441.4
                                        ;   in Loop: Header=BB40_216 Depth=3
	cmp	w5, #2
	b.ne	LBB40_197
; %bb.252:                              ; %bb25.i.i1446.4
                                        ;   in Loop: Header=BB40_216 Depth=3
	ldr	x5, [x3, #8]
	cmp	x5, x2
	b.eq	LBB40_348
LBB40_253:                              ; %bb31.i.i1420.4
                                        ;   in Loop: Header=BB40_216 Depth=3
	sub	x3, x4, #1
	and	x4, x3, x4
	cbz	x4, LBB40_271
; %bb.254:                              ; %bb17.i.i1409.5
                                        ;   in Loop: Header=BB40_216 Depth=3
	rbit	x3, x4
	clz	x3, x3
	lsr	x3, x3, #3
	subs	x3, x3, x0
	b.lo	LBB40_259
; %bb.255:                              ; %bb19.i.i1417.5
                                        ;   in Loop: Header=BB40_216 Depth=3
	cmp	x3, x1
	b.hs	LBB40_259
; %bb.256:                              ; %bb22.i.i1441.5
                                        ;   in Loop: Header=BB40_216 Depth=3
	add	x3, x3, x11
	madd	x3, x3, x7, x8
	ldr	w5, [x3, #16]!
	cmp	w5, #1
	b.eq	LBB40_259
; %bb.257:                              ; %bb22.i.i1441.5
                                        ;   in Loop: Header=BB40_216 Depth=3
	cmp	w5, #2
	b.ne	LBB40_197
; %bb.258:                              ; %bb25.i.i1446.5
                                        ;   in Loop: Header=BB40_216 Depth=3
	ldr	x5, [x3, #8]
	cmp	x5, x2
	b.eq	LBB40_348
LBB40_259:                              ; %bb31.i.i1420.5
                                        ;   in Loop: Header=BB40_216 Depth=3
	sub	x3, x4, #1
	and	x4, x3, x4
	cbz	x4, LBB40_271
; %bb.260:                              ; %bb17.i.i1409.6
                                        ;   in Loop: Header=BB40_216 Depth=3
	rbit	x3, x4
	clz	x3, x3
	lsr	x3, x3, #3
	subs	x3, x3, x0
	b.lo	LBB40_265
; %bb.261:                              ; %bb19.i.i1417.6
                                        ;   in Loop: Header=BB40_216 Depth=3
	cmp	x3, x1
	b.hs	LBB40_265
; %bb.262:                              ; %bb22.i.i1441.6
                                        ;   in Loop: Header=BB40_216 Depth=3
	add	x3, x3, x11
	madd	x3, x3, x7, x8
	ldr	w5, [x3, #16]!
	cmp	w5, #1
	b.eq	LBB40_265
; %bb.263:                              ; %bb22.i.i1441.6
                                        ;   in Loop: Header=BB40_216 Depth=3
	cmp	w5, #2
	b.ne	LBB40_197
; %bb.264:                              ; %bb25.i.i1446.6
                                        ;   in Loop: Header=BB40_216 Depth=3
	ldr	x5, [x3, #8]
	cmp	x5, x2
	b.eq	LBB40_348
LBB40_265:                              ; %bb31.i.i1420.6
                                        ;   in Loop: Header=BB40_216 Depth=3
	sub	x3, x4, #1
	and	x3, x3, x4
	cbz	x3, LBB40_271
; %bb.266:                              ; %bb17.i.i1409.7
                                        ;   in Loop: Header=BB40_216 Depth=3
	rbit	x3, x3
	clz	x3, x3
	lsr	x3, x3, #3
	subs	x0, x3, x0
	b.lo	LBB40_271
; %bb.267:                              ; %bb19.i.i1417.7
                                        ;   in Loop: Header=BB40_216 Depth=3
	cmp	x0, x1
	b.hs	LBB40_271
; %bb.268:                              ; %bb22.i.i1441.7
                                        ;   in Loop: Header=BB40_216 Depth=3
	add	x0, x0, x11
	madd	x3, x0, x7, x8
	ldr	w0, [x3, #16]!
	cmp	w0, #1
	b.eq	LBB40_271
; %bb.269:                              ; %bb22.i.i1441.7
                                        ;   in Loop: Header=BB40_216 Depth=3
	cmp	w0, #2
	b.ne	LBB40_382
; %bb.270:                              ; %bb25.i.i1446.7
                                        ;   in Loop: Header=BB40_216 Depth=3
	ldr	x0, [x3, #8]
	cmp	x0, x2
	b.eq	LBB40_348
LBB40_271:                              ; %bb14.i.i1425
                                        ;   in Loop: Header=BB40_216 Depth=3
	cmp	x1, x17
	b.lo	LBB40_198
; %bb.272:                              ; %bb34.i.i1427
                                        ;   in Loop: Header=BB40_216 Depth=3
	add	x11, x17, x11
	cmp	x11, x9
	csel	x11, x11, xzr, lo
	cmp	x15, x9
	b.hs	LBB40_198
; %bb.273:                              ; %bb34.i.i1427
                                        ;   in Loop: Header=BB40_216 Depth=3
	add	x15, x15, #1
	sub	x16, x16, x17
	cbnz	x16, LBB40_216
	b	LBB40_198
LBB40_274:                              ; %bb69
                                        ;   in Loop: Header=BB40_202 Depth=2
	mov	w21, #1                         ; =0x1
	ldr	x8, [sp, #640]                  ; 8-byte Folded Reload
	add	x8, x8, x20
	str	x8, [sp, #3680]
	add	x9, x8, #1
	str	x9, [sp, #3688]
	dup.2d	v0, x8
	ldr	q1, [sp, #592]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3696]
	ldr	q1, [sp, #576]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3712]
	ldr	q1, [sp, #560]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3728]
	ldr	q1, [sp, #544]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3744]
	ldr	q1, [sp, #528]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3760]
	ldr	q1, [sp, #512]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3776]
	ldr	q1, [sp, #496]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3792]
	ldr	q1, [sp, #480]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3808]
	ldr	q1, [sp, #464]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3824]
	ldr	q1, [sp, #448]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3840]
	ldr	q1, [sp, #432]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3856]
	ldr	q1, [sp, #416]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3872]
	ldr	q1, [sp, #400]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3888]
	ldr	q1, [sp, #384]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3904]
	ldr	q1, [sp, #368]                  ; 16-byte Folded Reload
	add.2d	v0, v0, v1
	str	q0, [sp, #3920]
	ldp	q0, q1, [x26, #192]
	str	q0, [sp, #6992]
	str	q1, [sp, #7008]
	ldp	q0, q1, [x26, #224]
	str	q0, [sp, #7024]
	str	q1, [sp, #7040]
	ldp	q0, q1, [x26, #128]
	str	q0, [sp, #6928]
	str	q1, [sp, #6944]
	ldp	q0, q1, [x26, #160]
	str	q0, [sp, #6960]
	str	q1, [sp, #6976]
	ldp	q0, q1, [x26, #64]
	str	q0, [sp, #6864]
	str	q1, [sp, #6880]
	ldp	q0, q1, [x26, #96]
	str	q0, [sp, #6896]
	str	q1, [sp, #6912]
	ldp	q0, q1, [x26]
	str	q0, [sp, #6800]
	str	q1, [sp, #6816]
	ldp	q0, q1, [x26, #32]
	str	q0, [sp, #6832]
	str	q1, [sp, #6848]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2704
	add	x0, x8, #256
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #2704
	add	x8, sp, #704
	mov	w9, #5984                       ; =0x1760
	add	x4, x8, x9
	ldr	x1, [sp, #696]                  ; 8-byte Folded Reload
	bl	_wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65
	ldr	w8, [sp, #7056]
	cbz	w8, LBB40_344
; %bb.275:                              ; %bb69
                                        ;   in Loop: Header=BB40_202 Depth=2
	cmp	w8, #1
	b.ne	LBB40_179
; %bb.276:                              ; %bb2.i578
                                        ;   in Loop: Header=BB40_202 Depth=2
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2704
	ldrb	w19, [x8, #260]
	add	x0, x8, #528
	add	x1, x8, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	tbz	w19, #0, LBB40_349
; %bb.277:                              ; %bb4.i584
                                        ;   in Loop: Header=BB40_202 Depth=2
	ldr	x8, [sp, #6704]
	ldr	x8, [x8]
	cmp	x8, #4, lsl #12                 ; =16384
	mov	w9, #1                          ; =0x1
	b.lo	LBB40_354
LBB40_278:                              ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit615.thread"
                                        ;   in Loop: Header=BB40_202 Depth=2
	str	x9, [sp, #3936]
	add	x8, sp, #704
	strb	w9, [x8, #3236]
	b	LBB40_350
LBB40_279:                              ; %bb90
                                        ;   in Loop: Header=BB40_202 Depth=2
	add	x8, sp, #704
	mov	w9, #6088                       ; =0x17c8
	add	x1, x8, x9
	mov	w9, #5984                       ; =0x1760
	add	x2, x8, x9
	ldr	x0, [sp, #696]                  ; 8-byte Folded Reload
	bl	_wf_hash_map.hash_map_find$instance$28da32efc51c2b65
	cbz	w0, LBB40_346
; %bb.280:                              ; %bb90
                                        ;   in Loop: Header=BB40_202 Depth=2
	cmp	w0, #1
	mov	w6, #1                          ; =0x1
	mov	w7, #272                        ; =0x110
	b.eq	LBB40_347
	b	LBB40_179
LBB40_281:                              ; %bb82
                                        ;   in Loop: Header=BB40_202 Depth=2
	ldr	x8, [sp, #6744]
	mul	x8, x8, x23
LBB40_282:                              ; %bb80
                                        ;   in Loop: Header=BB40_202 Depth=2
	str	x8, [sp, #6744]
	add	x9, sp, #704
	mov	w10, #5992                      ; =0x1768
	ldrb	w9, [x9, x10]
	ldr	x2, [sp, #6792]
	mov	w7, #272                        ; =0x110
	tbz	w9, #0, LBB40_284
; %bb.283:                              ;   in Loop: Header=BB40_202 Depth=2
	mov	x11, #0                         ; =0x0
	ldr	x9, [sp, #6704]
	ldr	x10, [x9]
	cbnz	x10, LBB40_285
	b	LBB40_362
LBB40_284:                              ; %bb3.i.i.i1461
                                        ;   in Loop: Header=BB40_202 Depth=2
	ldr	x9, [sp, #6688]
	eor	x9, x2, x9
	eor	x9, x9, x9, lsr #30
	mov	x10, #58809                     ; =0xe5b9
	movk	x10, #7396, lsl #16
	movk	x10, #18285, lsl #32
	movk	x10, #48984, lsl #48
	mul	x9, x9, x10
	eor	x9, x9, x9, lsr #27
	mov	x10, #4587                      ; =0x11eb
	movk	x10, #4913, lsl #16
	movk	x10, #18875, lsl #32
	movk	x10, #38096, lsl #48
	mul	x9, x9, x10
	eor	x11, x9, x9, lsr #31
	ldr	x9, [sp, #6704]
	ldr	x10, [x9]
	cbz	x10, LBB40_362
LBB40_285:                              ; %bb3.i.i1477
                                        ;   in Loop: Header=BB40_202 Depth=2
	lsr	x14, x11, #57
	udiv	x12, x11, x10
	msub	x12, x12, x10, x11
	ldr	x11, [sp, #6728]
	ldr	x13, [sp, #6720]
	mov	x15, #72340172838076673         ; =0x101010101010101
	mul	x14, x14, x15
	ldr	x15, [sp, #6736]
	mov	w16, #1                         ; =0x1
	mov	x17, x10
LBB40_286:                              ; %bb10.i.i1487
                                        ;   Parent Loop BB40_182 Depth=1
                                        ;     Parent Loop BB40_202 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	x1, x12, #0x7
	sub	x0, x10, x12
	sub	x3, x27, x1
	cmp	x3, x0
	csel	x0, x3, x0, lo
	cmp	x0, x17
	csel	x0, x0, x17, lo
	cbz	x11, LBB40_289
; %bb.287:                              ; %bb3.i21.i.i1497
                                        ;   in Loop: Header=BB40_286 Depth=3
	lsr	x3, x12, #3
	ldr	x4, [x15]
	cmp	x3, x4
	b.hs	LBB40_290
; %bb.288:                              ; %bb8.i.i.i1574
                                        ;   in Loop: Header=BB40_286 Depth=3
	add	x3, x15, x3, lsl #3
	ldr	x4, [x3, #8]
	b	LBB40_291
LBB40_289:                              ; %bb2.i.i.i1577
                                        ;   in Loop: Header=BB40_286 Depth=3
	cmp	x12, #8
	csel	x4, x13, x25, lo
	b	LBB40_291
LBB40_290:                              ; %bb9.i.i.i1501
                                        ;   in Loop: Header=BB40_286 Depth=3
	csel	x4, x13, x25, eq
LBB40_291:                              ; %wf_hash_map.hash_map_control_word.exit.i.i1504
                                        ;   in Loop: Header=BB40_286 Depth=3
	lsl	x3, x0, #3
	neg	x3, x3
	lsr	x3, x25, x3
	lsl	x5, x1, #3
	lsl	x5, x3, x5
	and	x3, x4, #0x7f7f7f7f7f7f7f7f
	sub	x3, x25, x3
	and	x3, x3, x4
	and	x3, x5, x3
	cmp	x3, #0
	rbit	x3, x3
	clz	x3, x3
	lsr	x6, x3, #3
	ccmp	x6, x1, #0, ne
	mov	x3, x0
	b.hs	LBB40_293
; %bb.292:                              ; %wf_hash_map.hash_map_control_stop.exit.i.i1528
                                        ;   in Loop: Header=BB40_286 Depth=3
	eor	x4, x4, x14
	and	x6, x4, #0x7f7f7f7f7f7f7f7f
	add	x6, x6, x22
	orr	x4, x6, x4
	bic	x5, x5, x4
	cbnz	x5, LBB40_294
	b	LBB40_341
LBB40_293:                              ; %bb5.i.i.i1525
                                        ;   in Loop: Header=BB40_286 Depth=3
	sub	x3, x6, x1
	cmp	x3, x0
	csel	x3, x3, x0, lo
	eor	x4, x4, x14
	and	x6, x4, #0x7f7f7f7f7f7f7f7f
	add	x6, x6, x22
	orr	x4, x6, x4
	bic	x5, x5, x4
	cbz	x5, LBB40_341
LBB40_294:                              ; %bb17.i.i1531
                                        ;   in Loop: Header=BB40_286 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x1
	b.lo	LBB40_299
; %bb.295:                              ; %bb19.i.i1539
                                        ;   in Loop: Header=BB40_286 Depth=3
	cmp	x4, x3
	b.hs	LBB40_299
; %bb.296:                              ; %bb22.i.i1563
                                        ;   in Loop: Header=BB40_286 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x7, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB40_299
; %bb.297:                              ; %bb22.i.i1563
                                        ;   in Loop: Header=BB40_286 Depth=3
	cmp	w6, #2
	b.ne	LBB40_361
; %bb.298:                              ; %bb25.i.i1568
                                        ;   in Loop: Header=BB40_286 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x2
	b.eq	LBB40_381
LBB40_299:                              ; %bb31.i.i1542
                                        ;   in Loop: Header=BB40_286 Depth=3
	sub	x4, x5, #1
	and	x5, x4, x5
	cbz	x5, LBB40_341
; %bb.300:                              ; %bb17.i.i1531.1
                                        ;   in Loop: Header=BB40_286 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x1
	b.lo	LBB40_305
; %bb.301:                              ; %bb19.i.i1539.1
                                        ;   in Loop: Header=BB40_286 Depth=3
	cmp	x4, x3
	b.hs	LBB40_305
; %bb.302:                              ; %bb22.i.i1563.1
                                        ;   in Loop: Header=BB40_286 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x7, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB40_305
; %bb.303:                              ; %bb22.i.i1563.1
                                        ;   in Loop: Header=BB40_286 Depth=3
	cmp	w6, #2
	b.ne	LBB40_361
; %bb.304:                              ; %bb25.i.i1568.1
                                        ;   in Loop: Header=BB40_286 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x2
	b.eq	LBB40_381
LBB40_305:                              ; %bb31.i.i1542.1
                                        ;   in Loop: Header=BB40_286 Depth=3
	sub	x4, x5, #1
	and	x5, x4, x5
	cbz	x5, LBB40_341
; %bb.306:                              ; %bb17.i.i1531.2
                                        ;   in Loop: Header=BB40_286 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x1
	b.lo	LBB40_311
; %bb.307:                              ; %bb19.i.i1539.2
                                        ;   in Loop: Header=BB40_286 Depth=3
	cmp	x4, x3
	b.hs	LBB40_311
; %bb.308:                              ; %bb22.i.i1563.2
                                        ;   in Loop: Header=BB40_286 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x7, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB40_311
; %bb.309:                              ; %bb22.i.i1563.2
                                        ;   in Loop: Header=BB40_286 Depth=3
	cmp	w6, #2
	b.ne	LBB40_361
; %bb.310:                              ; %bb25.i.i1568.2
                                        ;   in Loop: Header=BB40_286 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x2
	b.eq	LBB40_381
LBB40_311:                              ; %bb31.i.i1542.2
                                        ;   in Loop: Header=BB40_286 Depth=3
	sub	x4, x5, #1
	and	x5, x4, x5
	cbz	x5, LBB40_341
; %bb.312:                              ; %bb17.i.i1531.3
                                        ;   in Loop: Header=BB40_286 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x1
	b.lo	LBB40_317
; %bb.313:                              ; %bb19.i.i1539.3
                                        ;   in Loop: Header=BB40_286 Depth=3
	cmp	x4, x3
	b.hs	LBB40_317
; %bb.314:                              ; %bb22.i.i1563.3
                                        ;   in Loop: Header=BB40_286 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x7, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB40_317
; %bb.315:                              ; %bb22.i.i1563.3
                                        ;   in Loop: Header=BB40_286 Depth=3
	cmp	w6, #2
	b.ne	LBB40_361
; %bb.316:                              ; %bb25.i.i1568.3
                                        ;   in Loop: Header=BB40_286 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x2
	b.eq	LBB40_381
LBB40_317:                              ; %bb31.i.i1542.3
                                        ;   in Loop: Header=BB40_286 Depth=3
	sub	x4, x5, #1
	and	x5, x4, x5
	cbz	x5, LBB40_341
; %bb.318:                              ; %bb17.i.i1531.4
                                        ;   in Loop: Header=BB40_286 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x1
	b.lo	LBB40_323
; %bb.319:                              ; %bb19.i.i1539.4
                                        ;   in Loop: Header=BB40_286 Depth=3
	cmp	x4, x3
	b.hs	LBB40_323
; %bb.320:                              ; %bb22.i.i1563.4
                                        ;   in Loop: Header=BB40_286 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x7, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB40_323
; %bb.321:                              ; %bb22.i.i1563.4
                                        ;   in Loop: Header=BB40_286 Depth=3
	cmp	w6, #2
	b.ne	LBB40_361
; %bb.322:                              ; %bb25.i.i1568.4
                                        ;   in Loop: Header=BB40_286 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x2
	b.eq	LBB40_381
LBB40_323:                              ; %bb31.i.i1542.4
                                        ;   in Loop: Header=BB40_286 Depth=3
	sub	x4, x5, #1
	and	x5, x4, x5
	cbz	x5, LBB40_341
; %bb.324:                              ; %bb17.i.i1531.5
                                        ;   in Loop: Header=BB40_286 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x1
	b.lo	LBB40_329
; %bb.325:                              ; %bb19.i.i1539.5
                                        ;   in Loop: Header=BB40_286 Depth=3
	cmp	x4, x3
	b.hs	LBB40_329
; %bb.326:                              ; %bb22.i.i1563.5
                                        ;   in Loop: Header=BB40_286 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x7, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB40_329
; %bb.327:                              ; %bb22.i.i1563.5
                                        ;   in Loop: Header=BB40_286 Depth=3
	cmp	w6, #2
	b.ne	LBB40_361
; %bb.328:                              ; %bb25.i.i1568.5
                                        ;   in Loop: Header=BB40_286 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x2
	b.eq	LBB40_381
LBB40_329:                              ; %bb31.i.i1542.5
                                        ;   in Loop: Header=BB40_286 Depth=3
	sub	x4, x5, #1
	and	x5, x4, x5
	cbz	x5, LBB40_341
; %bb.330:                              ; %bb17.i.i1531.6
                                        ;   in Loop: Header=BB40_286 Depth=3
	rbit	x4, x5
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x4, x4, x1
	b.lo	LBB40_335
; %bb.331:                              ; %bb19.i.i1539.6
                                        ;   in Loop: Header=BB40_286 Depth=3
	cmp	x4, x3
	b.hs	LBB40_335
; %bb.332:                              ; %bb22.i.i1563.6
                                        ;   in Loop: Header=BB40_286 Depth=3
	add	x4, x4, x12
	madd	x4, x4, x7, x9
	ldr	w6, [x4, #16]!
	cmp	w6, #1
	b.eq	LBB40_335
; %bb.333:                              ; %bb22.i.i1563.6
                                        ;   in Loop: Header=BB40_286 Depth=3
	cmp	w6, #2
	b.ne	LBB40_361
; %bb.334:                              ; %bb25.i.i1568.6
                                        ;   in Loop: Header=BB40_286 Depth=3
	ldr	x6, [x4, #8]
	cmp	x6, x2
	b.eq	LBB40_381
LBB40_335:                              ; %bb31.i.i1542.6
                                        ;   in Loop: Header=BB40_286 Depth=3
	sub	x4, x5, #1
	and	x4, x4, x5
	cbz	x4, LBB40_341
; %bb.336:                              ; %bb17.i.i1531.7
                                        ;   in Loop: Header=BB40_286 Depth=3
	rbit	x4, x4
	clz	x4, x4
	lsr	x4, x4, #3
	subs	x1, x4, x1
	b.lo	LBB40_341
; %bb.337:                              ; %bb19.i.i1539.7
                                        ;   in Loop: Header=BB40_286 Depth=3
	cmp	x1, x3
	b.hs	LBB40_341
; %bb.338:                              ; %bb22.i.i1563.7
                                        ;   in Loop: Header=BB40_286 Depth=3
	add	x1, x1, x12
	madd	x4, x1, x7, x9
	ldr	w1, [x4, #16]!
	cmp	w1, #1
	b.eq	LBB40_341
; %bb.339:                              ; %bb22.i.i1563.7
                                        ;   in Loop: Header=BB40_286 Depth=3
	cmp	w1, #2
	b.ne	LBB40_383
; %bb.340:                              ; %bb25.i.i1568.7
                                        ;   in Loop: Header=BB40_286 Depth=3
	ldr	x1, [x4, #8]
	cmp	x1, x2
	b.eq	LBB40_381
LBB40_341:                              ; %bb14.i.i1547
                                        ;   in Loop: Header=BB40_286 Depth=3
	cmp	x3, x0
	b.lo	LBB40_362
; %bb.342:                              ; %bb34.i.i1549
                                        ;   in Loop: Header=BB40_286 Depth=3
	add	x12, x0, x12
	cmp	x12, x10
	csel	x12, x12, xzr, lo
	cmp	x16, x10
	b.hs	LBB40_362
; %bb.343:                              ; %bb34.i.i1549
                                        ;   in Loop: Header=BB40_286 Depth=3
	add	x16, x16, #1
	sub	x17, x17, x0
	cbnz	x17, LBB40_286
	b	LBB40_362
LBB40_344:                              ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit615.thread1621"
                                        ;   in Loop: Header=BB40_202 Depth=2
	ldr	x8, [sp, #96]                   ; 8-byte Folded Reload
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #240]
	stp	q0, q0, [x8, #208]
	stp	q0, q0, [x8, #176]
	stp	q0, q0, [x8, #144]
	stp	q0, q0, [x8, #112]
	stp	q0, q0, [x8, #80]
	stp	q0, q0, [x8, #48]
	stp	q0, q0, [x8, #16]
	str	q0, [x8]
	mov	w7, #272                        ; =0x110
LBB40_345:                              ; %bb72
                                        ;   in Loop: Header=BB40_202 Depth=2
	ldr	x8, [sp, #6744]
	mul	x8, x8, x23
	mov	w6, #1                          ; =0x1
	b	LBB40_200
LBB40_346:                              ; %bb1.i.i1176
                                        ;   in Loop: Header=BB40_202 Depth=2
	ldr	x8, [sp, #6704]
	mov	w7, #272                        ; =0x110
	madd	x8, x1, x7, x8
	ldr	w9, [x8, #16]!
	cmp	w9, #2
	mov	w6, #1                          ; =0x1
	b.hs	LBB40_352
LBB40_347:                              ; %bb3.i1187
                                        ;   in Loop: Header=BB40_202 Depth=2
	str	w6, [sp, #6592]
	str	xzr, [sp, #6600]
	ldr	x8, [sp, #656]                  ; 8-byte Folded Reload
	strb	wzr, [x8, #1072]
	b	LBB40_199
LBB40_348:                              ; %bb2.i502
                                        ;   in Loop: Header=BB40_202 Depth=2
	ldr	x8, [x3, #16]
	str	wzr, [sp, #3656]
	str	x8, [sp, #3664]
	strb	wzr, [sp, #3672]
	ldr	x9, [sp, #6744]
	mov	w10, #17161                     ; =0x4309
	madd	x8, x9, x10, x8
	add	x8, x8, #131
	b	LBB40_200
LBB40_349:                              ; %bb3.i582
                                        ;   in Loop: Header=BB40_202 Depth=2
	str	x21, [sp, #3936]
	add	x8, sp, #704
LBB40_350:                              ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit615.thread"
                                        ;   in Loop: Header=BB40_202 Depth=2
	add	x0, x8, #3240
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2704
	add	x1, x8, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	x9, sp, #704
LBB40_351:                              ; %bb73
                                        ;   in Loop: Header=BB40_202 Depth=2
	add	x8, sp, #704
	ldrb	w19, [x8, #3236]
	add	x0, x8, #3504
	add	x1, x9, #3240
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	ldr	x8, [sp, #6744]
	cmp	w19, #0
	mov	w6, #1                          ; =0x1
	cinc	x9, x6, ne
	madd	x8, x8, x23, x9
	ldr	x9, [sp, #4208]
	ldp	x11, x10, [sp, #48]             ; 16-byte Folded Reload
	ldp	q1, q0, [x11, #96]
	stp	q1, q0, [x10, #96]
	ldp	q1, q0, [x11, #64]
	stp	q1, q0, [x10, #64]
	ldp	q1, q0, [x11, #160]
	stp	q1, q0, [x10, #160]
	ldp	q1, q0, [x11, #128]
	stp	q1, q0, [x10, #128]
	ldp	q1, q0, [x11, #224]
	stp	q1, q0, [x10, #224]
	ldp	q1, q0, [x11, #192]
	stp	q1, q0, [x10, #192]
	ldp	q1, q0, [x11, #32]
	stp	q1, q0, [x10, #32]
	ldp	q0, q1, [x11]
	stp	q0, q1, [x10]
	ldr	x10, [sp, #4472]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4480]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4488]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4496]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4504]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4512]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4520]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4528]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4536]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4544]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4552]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4560]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4568]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4576]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4584]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4592]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4600]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4608]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4616]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4624]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4632]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4640]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4648]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4656]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4664]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4672]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4680]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4688]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4696]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4704]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #4712]
	add	x8, x8, x10
	madd	x8, x9, x23, x8
	ldr	x9, [sp, #4720]
	b	LBB40_373
LBB40_352:                              ; %bb1.i.i1176
                                        ;   in Loop: Header=BB40_202 Depth=2
	b.ne	LBB40_179
; %bb.353:                              ; %bb2.i1192
                                        ;   in Loop: Header=BB40_202 Depth=2
	ldr	x9, [x8, #16]
	add	x10, x9, #1
	str	x10, [x8, #16]
	str	wzr, [sp, #6592]
	str	x10, [sp, #6600]
	ldr	x8, [sp, #656]                  ; 8-byte Folded Reload
	strb	wzr, [x8, #1072]
	ldr	x8, [sp, #6744]
	mov	w10, #17161                     ; =0x4309
	madd	x8, x8, x10, x9
	add	x8, x8, #132
	b	LBB40_200
LBB40_354:                              ; %bb7.i588
                                        ;   in Loop: Header=BB40_202 Depth=2
	cmp	x8, #2, lsl #12                 ; =8192
	mov	w9, #8192                       ; =0x2000
	csel	x9, x8, x9, lo
	lsl	x9, x9, #1
	cmp	x8, #0
	csinc	x1, x9, xzr, ne
	cmp	x1, x8
	b.ls	LBB40_358
; %bb.355:                              ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.i599"
                                        ;   in Loop: Header=BB40_202 Depth=2
	add	x8, sp, #704
	mov	w9, #5984                       ; =0x1760
	add	x2, x8, x9
	ldr	x0, [sp, #696]                  ; 8-byte Folded Reload
	bl	_wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	str	w0, [sp, #7592]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2704
	strb	w1, [x8, #796]
	strb	w2, [x8, #797]
	ldr	x19, [sp, #624]                 ; 8-byte Folded Reload
	cbz	w0, LBB40_359
; %bb.356:                              ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.i599"
                                        ;   in Loop: Header=BB40_202 Depth=2
	cmp	w0, #1
	b.ne	LBB40_179
; %bb.357:                              ; %bb18.i606
                                        ;   in Loop: Header=BB40_202 Depth=2
	mov	w9, #1                          ; =0x1
	b	LBB40_278
LBB40_358:                              ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.thread.i593"
                                        ;   in Loop: Header=BB40_202 Depth=2
	str	wzr, [sp, #7592]
	strh	wzr, [sp, #7596]
	ldr	x19, [sp, #624]                 ; 8-byte Folded Reload
LBB40_359:                              ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit615"
                                        ;   in Loop: Header=BB40_202 Depth=2
	ldr	x2, [sp, #7328]
	ldp	x8, x3, [sp, #304]              ; 16-byte Folded Reload
	ldp	q0, q1, [x8, #192]
	stp	q0, q1, [x3, #192]
	ldp	q0, q1, [x8, #224]
	stp	q0, q1, [x3, #224]
	ldp	q0, q1, [x8, #128]
	stp	q0, q1, [x3, #128]
	ldp	q0, q1, [x8, #160]
	stp	q0, q1, [x3, #160]
	ldp	q0, q1, [x8, #64]
	stp	q0, q1, [x3, #64]
	ldp	q0, q1, [x8, #96]
	stp	q0, q1, [x3, #96]
	ldp	q0, q1, [x8]
	stp	q0, q1, [x3]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x3, #32]
	add	x8, sp, #704
	mov	w9, #5984                       ; =0x1760
	add	x4, x8, x9
	ldr	x0, [sp, #96]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #696]                  ; 8-byte Folded Reload
	bl	_wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65
	ldr	w8, [sp, #3936]
	mov	w7, #272                        ; =0x110
	cbz	w8, LBB40_345
; %bb.360:                              ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit615"
                                        ;   in Loop: Header=BB40_202 Depth=2
	cmp	w8, #1
	add	x9, sp, #704
	b.eq	LBB40_351
	b	LBB40_179
LBB40_361:                              ; %bb22.i.i1563
                                        ;   in Loop: Header=BB40_202 Depth=2
	cbnz	w6, LBB40_179
LBB40_362:                              ; %bb3.i775
                                        ;   in Loop: Header=BB40_202 Depth=2
	str	w21, [sp, #5520]
	str	xzr, [sp, #5528]
	mul	x8, x8, x23
	ldr	x9, [sp, #656]                  ; 8-byte Folded Reload
	strb	wzr, [x9]
LBB40_363:                              ; %wf_map_cost_lookup_result.exit787
                                        ;   in Loop: Header=BB40_202 Depth=2
	str	x8, [sp, #6744]
	ldr	x8, [sp, #640]                  ; 8-byte Folded Reload
	add	x8, x8, x20
	add	x9, x8, #31
	str	x8, [sp, #5544]
	dup.2d	v0, x8
	ldr	q1, [sp, #352]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5552]
	ldr	q1, [sp, #336]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5568]
	ldr	q1, [sp, #320]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5584]
	ldr	q1, [sp, #288]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5600]
	ldr	q1, [sp, #272]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5616]
	ldr	q1, [sp, #256]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5632]
	ldr	q1, [sp, #240]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5648]
	ldr	q1, [sp, #224]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5664]
	ldr	q1, [sp, #208]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5680]
	ldr	q1, [sp, #192]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5696]
	ldr	q1, [sp, #176]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5712]
	ldr	q1, [sp, #160]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5728]
	ldr	q1, [sp, #144]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5744]
	ldr	q1, [sp, #128]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5760]
	ldr	q1, [sp, #112]                  ; 16-byte Folded Reload
	add.2d	v0, v0, v1
	str	q0, [sp, #5776]
	str	x9, [sp, #5792]
	ldp	q0, q1, [x28, #192]
	str	q0, [sp, #6992]
	str	q1, [sp, #7008]
	ldp	q0, q1, [x28, #224]
	str	q0, [sp, #7024]
	str	q1, [sp, #7040]
	ldp	q0, q1, [x28, #128]
	str	q0, [sp, #6928]
	str	q1, [sp, #6944]
	ldp	q0, q1, [x28, #160]
	str	q0, [sp, #6960]
	str	q1, [sp, #6976]
	ldp	q0, q1, [x28, #64]
	str	q0, [sp, #6864]
	str	q1, [sp, #6880]
	ldp	q0, q1, [x28, #96]
	str	q0, [sp, #6896]
	str	q1, [sp, #6912]
	ldp	q0, q1, [x28]
	str	q0, [sp, #6800]
	str	q1, [sp, #6816]
	ldp	q0, q1, [x28, #32]
	str	q0, [sp, #6832]
	str	q1, [sp, #6848]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2704
	add	x0, x8, #256
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #2704
	add	x8, sp, #704
	mov	w9, #5984                       ; =0x1760
	add	x4, x8, x9
	ldr	x1, [sp, #696]                  ; 8-byte Folded Reload
	bl	_wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65
	ldr	w8, [sp, #7056]
	cbz	w8, LBB40_368
; %bb.364:                              ; %wf_map_cost_lookup_result.exit787
                                        ;   in Loop: Header=BB40_202 Depth=2
	cmp	w8, #1
	b.ne	LBB40_179
; %bb.365:                              ; %bb2.i856
                                        ;   in Loop: Header=BB40_202 Depth=2
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2704
	ldrb	w19, [x8, #260]
	add	x0, x8, #528
	add	x1, x8, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	tbz	w19, #0, LBB40_370
; %bb.366:                              ; %bb4.i862
                                        ;   in Loop: Header=BB40_202 Depth=2
	ldr	x8, [sp, #6704]
	ldr	x8, [x8]
	cmp	x8, #4, lsl #12                 ; =16384
	mov	w9, #1                          ; =0x1
	b.lo	LBB40_374
LBB40_367:                              ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit893.thread"
                                        ;   in Loop: Header=BB40_202 Depth=2
	str	x9, [sp, #5800]
	ldr	x8, [sp, #656]                  ; 8-byte Folded Reload
	strb	w9, [x8, #268]
	b	LBB40_371
LBB40_368:                              ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit893.thread1636"
                                        ;   in Loop: Header=BB40_202 Depth=2
	ldr	x8, [sp, #88]                   ; 8-byte Folded Reload
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #240]
	stp	q0, q0, [x8, #208]
	stp	q0, q0, [x8, #176]
	stp	q0, q0, [x8, #144]
	stp	q0, q0, [x8, #112]
	stp	q0, q0, [x8, #80]
	stp	q0, q0, [x8, #48]
	stp	q0, q0, [x8, #16]
	str	q0, [x8]
LBB40_369:                              ; %bb84
                                        ;   in Loop: Header=BB40_202 Depth=2
	ldr	x8, [sp, #6744]
	mul	x8, x8, x23
	mov	w6, #1                          ; =0x1
	mov	w7, #272                        ; =0x110
	b	LBB40_200
LBB40_370:                              ; %bb3.i860
                                        ;   in Loop: Header=BB40_202 Depth=2
	str	x21, [sp, #5800]
LBB40_371:                              ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit893.thread"
                                        ;   in Loop: Header=BB40_202 Depth=2
	mov	w8, #5104                       ; =0x13f0
	add	x9, sp, #704
	add	x0, x9, x8
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2704
	add	x1, x8, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	mov	w9, #5104                       ; =0x13f0
	add	x10, sp, #704
LBB40_372:                              ; %bb85
                                        ;   in Loop: Header=BB40_202 Depth=2
	ldr	x8, [sp, #656]                  ; 8-byte Folded Reload
	ldrb	w19, [x8, #268]
	add	x1, x10, x9
	ldr	x0, [sp, #40]                   ; 8-byte Folded Reload
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	ldr	x8, [sp, #6744]
	cmp	w19, #0
	mov	w6, #1                          ; =0x1
	cinc	x9, x6, ne
	madd	x8, x8, x23, x9
	ldr	x9, [sp, #6072]
	ldp	x11, x10, [sp, #24]             ; 16-byte Folded Reload
	ldp	q1, q0, [x11, #96]
	stp	q1, q0, [x10, #96]
	ldp	q1, q0, [x11, #64]
	stp	q1, q0, [x10, #64]
	ldp	q1, q0, [x11, #160]
	stp	q1, q0, [x10, #160]
	ldp	q1, q0, [x11, #128]
	stp	q1, q0, [x10, #128]
	ldp	q1, q0, [x11, #224]
	stp	q1, q0, [x10, #224]
	ldp	q1, q0, [x11, #192]
	stp	q1, q0, [x10, #192]
	ldp	q1, q0, [x11, #32]
	stp	q1, q0, [x10, #32]
	ldp	q0, q1, [x11]
	stp	q0, q1, [x10]
	ldr	x10, [sp, #6336]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6344]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6352]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6360]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6368]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6376]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6384]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6392]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6400]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6408]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6416]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6424]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6432]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6440]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6448]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6456]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6464]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6472]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6480]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6488]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6496]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6504]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6512]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6520]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6528]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6536]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6544]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6552]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6560]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6568]
	madd	x9, x9, x23, x10
	ldr	x10, [sp, #6576]
	add	x8, x8, x10
	madd	x8, x9, x23, x8
	ldr	x9, [sp, #6584]
LBB40_373:                              ; %bb92.sink.split
                                        ;   in Loop: Header=BB40_202 Depth=2
	madd	x8, x8, x23, x9
	ldr	x19, [sp, #624]                 ; 8-byte Folded Reload
	mov	w7, #272                        ; =0x110
	b	LBB40_200
LBB40_374:                              ; %bb7.i866
                                        ;   in Loop: Header=BB40_202 Depth=2
	cmp	x8, #2, lsl #12                 ; =8192
	mov	w9, #8192                       ; =0x2000
	csel	x9, x8, x9, lo
	lsl	x9, x9, #1
	cmp	x8, #0
	csinc	x1, x9, xzr, ne
	cmp	x1, x8
	b.ls	LBB40_378
; %bb.375:                              ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.i877"
                                        ;   in Loop: Header=BB40_202 Depth=2
	add	x8, sp, #704
	mov	w9, #5984                       ; =0x1760
	add	x2, x8, x9
	ldr	x0, [sp, #696]                  ; 8-byte Folded Reload
	bl	_wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	str	w0, [sp, #7592]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2704
	strb	w1, [x8, #796]
	strb	w2, [x8, #797]
	ldr	x19, [sp, #624]                 ; 8-byte Folded Reload
	cbz	w0, LBB40_379
; %bb.376:                              ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.i877"
                                        ;   in Loop: Header=BB40_202 Depth=2
	cmp	w0, #1
	b.ne	LBB40_179
; %bb.377:                              ; %bb18.i884
                                        ;   in Loop: Header=BB40_202 Depth=2
	mov	w9, #1                          ; =0x1
	b	LBB40_367
LBB40_378:                              ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.thread.i871"
                                        ;   in Loop: Header=BB40_202 Depth=2
	str	wzr, [sp, #7592]
	strh	wzr, [sp, #7596]
	ldr	x19, [sp, #624]                 ; 8-byte Folded Reload
LBB40_379:                              ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit893"
                                        ;   in Loop: Header=BB40_202 Depth=2
	ldr	x2, [sp, #7328]
	ldp	x8, x3, [sp, #304]              ; 16-byte Folded Reload
	ldp	q0, q1, [x8, #192]
	stp	q0, q1, [x3, #192]
	ldp	q0, q1, [x8, #224]
	stp	q0, q1, [x3, #224]
	ldp	q0, q1, [x8, #128]
	stp	q0, q1, [x3, #128]
	ldp	q0, q1, [x8, #160]
	stp	q0, q1, [x3, #160]
	ldp	q0, q1, [x8, #64]
	stp	q0, q1, [x3, #64]
	ldp	q0, q1, [x8, #96]
	stp	q0, q1, [x3, #96]
	ldp	q0, q1, [x8]
	stp	q0, q1, [x3]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x3, #32]
	add	x8, sp, #704
	mov	w9, #5984                       ; =0x1760
	add	x4, x8, x9
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	ldr	x1, [sp, #696]                  ; 8-byte Folded Reload
	bl	_wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65
	ldr	w8, [sp, #5800]
	cbz	w8, LBB40_369
; %bb.380:                              ; %"wf_hash_map.hash_map_put$instance$28da32efc51c2b65.exit893"
                                        ;   in Loop: Header=BB40_202 Depth=2
	cmp	w8, #1
	mov	w9, #5104                       ; =0x13f0
	add	x10, sp, #704
	b.eq	LBB40_372
	b	LBB40_179
LBB40_381:                              ; %bb2.i780
                                        ;   in Loop: Header=BB40_202 Depth=2
	ldr	x9, [x4, #16]
	str	wzr, [sp, #5520]
	str	x9, [sp, #5528]
	ldr	x10, [sp, #656]                 ; 8-byte Folded Reload
	strb	wzr, [x10]
	mov	w10, #17161                     ; =0x4309
	madd	x8, x8, x10, x9
	add	x8, x8, #131
	b	LBB40_363
LBB40_382:                              ; %bb22.i.i1441.7
                                        ;   in Loop: Header=BB40_202 Depth=2
	cbz	w0, LBB40_198
	b	LBB40_179
LBB40_383:                              ; %bb22.i.i1563.7
                                        ;   in Loop: Header=BB40_202 Depth=2
	cbz	w1, LBB40_362
	b	LBB40_179
LBB40_384:                              ; %bb15
	mov	w8, #6040                       ; =0x1798
	add	x9, sp, #704
	add	x19, x9, x8
	mov	w8, #5912                       ; =0x1718
	add	x0, x9, x8
	ldr	x8, [sp, #696]                  ; 8-byte Folded Reload
	ldp	q0, q1, [x8]
	stp	q0, q1, [x0]
	ldr	x8, [x8, #32]
	str	x8, [sp, #6648]
	mov	x1, x19
	bl	_wf_hash_map.hash_map_free$instance$d5f8785ab7665d71
	ldp	q0, q1, [x19]
	str	q0, [sp, #6656]
	str	q1, [sp, #6672]
	ldr	x8, [sp, #6656]
	ldr	x9, [sp, #6664]
	ldr	x10, [sp, #6672]
	ldr	x11, [sp, #6680]
	eor	x8, x8, x8, lsr #30
	mov	x13, #58809                     ; =0xe5b9
	movk	x13, #7396, lsl #16
	movk	x13, #18285, lsl #32
	movk	x13, #48984, lsl #48
	mul	x8, x8, x13
	eor	x8, x8, x8, lsr #27
	mov	x12, #4587                      ; =0x11eb
	movk	x12, #4913, lsl #16
	movk	x12, #18875, lsl #32
	movk	x12, #38096, lsl #48
	mul	x8, x8, x12
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x13
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x12
	eor	x12, x9, x8
	mov	x13, #31765                     ; =0x7c15
	movk	x13, #32586, lsl #16
	movk	x13, #31161, lsl #32
	movk	x13, #40503, lsl #48
	mul	x11, x11, x13
	eor	x10, x10, x11
	eor	x10, x10, x12, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #3760
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB40_385:                              ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpLdr	Lloh80, Lloh81
	.loh AdrpAdrp	Lloh78, Lloh80
	.loh AdrpLdr	Lloh78, Lloh79
	.loh AdrpAdrp	Lloh76, Lloh78
	.loh AdrpLdr	Lloh76, Lloh77
	.loh AdrpAdrp	Lloh74, Lloh76
	.loh AdrpLdr	Lloh74, Lloh75
	.loh AdrpAdrp	Lloh72, Lloh74
	.loh AdrpLdr	Lloh72, Lloh73
	.loh AdrpAdrp	Lloh70, Lloh72
	.loh AdrpLdr	Lloh70, Lloh71
	.loh AdrpAdrp	Lloh68, Lloh70
	.loh AdrpLdr	Lloh68, Lloh69
	.loh AdrpAdrp	Lloh66, Lloh68
	.loh AdrpLdr	Lloh66, Lloh67
	.loh AdrpAdrp	Lloh64, Lloh66
	.loh AdrpLdr	Lloh64, Lloh65
	.loh AdrpAdrp	Lloh62, Lloh64
	.loh AdrpLdr	Lloh62, Lloh63
	.loh AdrpAdrp	Lloh60, Lloh62
	.loh AdrpLdr	Lloh60, Lloh61
	.loh AdrpAdrp	Lloh58, Lloh60
	.loh AdrpLdr	Lloh58, Lloh59
	.loh AdrpAdrp	Lloh56, Lloh58
	.loh AdrpLdr	Lloh56, Lloh57
	.loh AdrpAdrp	Lloh54, Lloh56
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpLdr	Lloh52, Lloh53
	.loh AdrpLdr	Lloh110, Lloh111
	.loh AdrpAdrp	Lloh108, Lloh110
	.loh AdrpLdr	Lloh108, Lloh109
	.loh AdrpAdrp	Lloh106, Lloh108
	.loh AdrpLdr	Lloh106, Lloh107
	.loh AdrpAdrp	Lloh104, Lloh106
	.loh AdrpLdr	Lloh104, Lloh105
	.loh AdrpAdrp	Lloh102, Lloh104
	.loh AdrpLdr	Lloh102, Lloh103
	.loh AdrpAdrp	Lloh100, Lloh102
	.loh AdrpLdr	Lloh100, Lloh101
	.loh AdrpAdrp	Lloh98, Lloh100
	.loh AdrpLdr	Lloh98, Lloh99
	.loh AdrpAdrp	Lloh96, Lloh98
	.loh AdrpLdr	Lloh96, Lloh97
	.loh AdrpAdrp	Lloh94, Lloh96
	.loh AdrpLdr	Lloh94, Lloh95
	.loh AdrpAdrp	Lloh92, Lloh94
	.loh AdrpLdr	Lloh92, Lloh93
	.loh AdrpLdr	Lloh90, Lloh91
	.loh AdrpAdrp	Lloh88, Lloh90
	.loh AdrpLdr	Lloh88, Lloh89
	.loh AdrpAdrp	Lloh86, Lloh88
	.loh AdrpLdr	Lloh86, Lloh87
	.loh AdrpAdrp	Lloh84, Lloh86
	.loh AdrpLdr	Lloh84, Lloh85
	.loh AdrpLdr	Lloh82, Lloh83
	.loh AdrpLdr	Lloh170, Lloh171
	.loh AdrpAdrp	Lloh168, Lloh170
	.loh AdrpLdr	Lloh168, Lloh169
	.loh AdrpAdrp	Lloh166, Lloh168
	.loh AdrpLdr	Lloh166, Lloh167
	.loh AdrpAdrp	Lloh164, Lloh166
	.loh AdrpLdr	Lloh164, Lloh165
	.loh AdrpAdrp	Lloh162, Lloh164
	.loh AdrpLdr	Lloh162, Lloh163
	.loh AdrpAdrp	Lloh160, Lloh162
	.loh AdrpLdr	Lloh160, Lloh161
	.loh AdrpAdrp	Lloh158, Lloh160
	.loh AdrpLdr	Lloh158, Lloh159
	.loh AdrpAdrp	Lloh156, Lloh158
	.loh AdrpLdr	Lloh156, Lloh157
	.loh AdrpAdrp	Lloh154, Lloh156
	.loh AdrpLdr	Lloh154, Lloh155
	.loh AdrpAdrp	Lloh152, Lloh154
	.loh AdrpLdr	Lloh152, Lloh153
	.loh AdrpLdr	Lloh150, Lloh151
	.loh AdrpLdr	Lloh148, Lloh149
	.loh AdrpLdr	Lloh146, Lloh147
	.loh AdrpLdr	Lloh144, Lloh145
	.loh AdrpAdrp	Lloh142, Lloh144
	.loh AdrpLdr	Lloh142, Lloh143
	.loh AdrpLdr	Lloh140, Lloh141
	.loh AdrpAdrp	Lloh138, Lloh140
	.loh AdrpLdr	Lloh138, Lloh139
	.loh AdrpAdrp	Lloh136, Lloh148
	.loh AdrpLdr	Lloh136, Lloh137
	.loh AdrpLdr	Lloh134, Lloh135
	.loh AdrpAdrp	Lloh132, Lloh136
	.loh AdrpLdr	Lloh132, Lloh133
	.loh AdrpLdr	Lloh130, Lloh131
	.loh AdrpAdrp	Lloh128, Lloh132
	.loh AdrpLdr	Lloh128, Lloh129
	.loh AdrpLdr	Lloh126, Lloh127
	.loh AdrpAdrp	Lloh124, Lloh128
	.loh AdrpLdr	Lloh124, Lloh125
	.loh AdrpLdr	Lloh122, Lloh123
	.loh AdrpAdrp	Lloh120, Lloh124
	.loh AdrpLdr	Lloh120, Lloh121
	.loh AdrpLdr	Lloh118, Lloh119
	.loh AdrpAdrp	Lloh116, Lloh120
	.loh AdrpLdr	Lloh116, Lloh117
	.loh AdrpLdr	Lloh114, Lloh115
	.loh AdrpLdr	Lloh112, Lloh113
	.loh AdrpLdrGot	Lloh48, Lloh49
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd
lCPI41_0:
	.quad	0                               ; 0x0
	.quad	-9187201950435737472            ; 0x8080808080808080
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd
	.p2align	2
_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd: ; @"wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #192
	stp	x26, x25, [sp, #112]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #128]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #144]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #160]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 192
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
	mov	x24, #31765                     ; =0x7c15
	movk	x24, #32586, lsl #16
	movk	x24, #31161, lsl #32
	movk	x24, #40503, lsl #48
	eor	x8, x2, x24
	str	x8, [sp, #72]
	strb	wzr, [sp, #80]
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB41_18
; %bb.1:                                ; %bb1.i.i
	stp	xzr, x21, [x0]
	cbz	x21, LBB41_7
; %bb.2:                                ; %bb5.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
LBB41_3:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x9], #24
	cmp	x21, x8
	b.ne	LBB41_3
; %bb.4:                                ; %"wf_hash_map.hash_map_extend$instance$820b2044b97e0fbd.exit.i"
	str	x21, [x0]
	cmp	x21, #9
	b.lo	LBB41_7
; %bb.5:                                ; %bb2.i.i.i
	mov	x25, x0
	and	x23, x21, #0xfffffffffffffff8
	add	x0, x23, #8
	bl	_malloc
	cbz	x0, LBB41_18
; %bb.6:                                ; %buffer.fill.init.v2.i.i.i.i
	mov	x22, x0
	lsr	x8, x21, #3
	str	x8, [x0], #8
	mov	w1, #128                        ; =0x80
	mov	x2, x23
	bl	_memset
	mov	w8, #1                          ; =0x1
	mov	x0, x25
	b	LBB41_8
LBB41_7:
	mov	x22, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
LBB41_8:                                ; %"wf_hash_map.hash_map_new$instance$820b2044b97e0fbd.exit"
	stp	xzr, x0, [sp, #24]
Lloh172:
	adrp	x9, lCPI41_0@PAGE
Lloh173:
	ldr	q0, [x9, lCPI41_0@PAGEOFF]
	stur	q0, [sp, #40]
	stp	x8, x22, [sp, #56]
	stp	xzr, xzr, [sp, #8]
	cbz	x20, LBB41_15
; %bb.9:                                ; %bb2.lr.ph
	mov	w22, #1                         ; =0x1
	mov	w25, #131                       ; =0x83
	mov	w21, #1                         ; =0x1
	mov	x23, x19
	b	LBB41_11
LBB41_10:                               ; %bb2.i
                                        ;   in Loop: Header=BB41_11 Depth=1
	mul	x23, x23, x25
	add	x19, x19, #1
	add	x21, x21, #2
	subs	x20, x20, #1
	b.eq	LBB41_14
LBB41_11:                               ; %bb2
                                        ; =>This Inner Loop Header: Depth=1
	add	x0, sp, #88
	add	x1, sp, #32
	add	x4, sp, #72
	mov	x2, x21
	mov	x3, x19
	bl	_wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad
	ldr	w8, [sp, #88]
	cbz	w8, LBB41_10
; %bb.12:                               ; %bb2
                                        ;   in Loop: Header=BB41_11 Depth=1
	cmp	w8, #1
	b.ne	LBB41_17
; %bb.13:                               ; %bb3.i
                                        ;   in Loop: Header=BB41_11 Depth=1
	ldp	x9, x8, [sp, #96]
	ldrb	w10, [sp, #92]
	tst	w10, #0x1
	cinc	x10, x22, ne
	add	x9, x10, x9
	madd	x9, x23, x25, x9
	madd	x23, x9, x25, x8
	add	x19, x19, #1
	add	x21, x21, #2
	subs	x20, x20, #1
	b.ne	LBB41_11
LBB41_14:                               ; %bb4.loopexit
	ldp	x9, x8, [sp, #32]
	ldr	x21, [x9]
	mov	x19, x23
	b	LBB41_16
LBB41_15:
	mov	x8, #0                          ; =0x0
LBB41_16:                               ; %bb4
	str	x19, [sp]
	add	x19, x8, x21, lsl #32
	add	x0, sp, #32
	mov	x1, sp
	bl	_wf_hash_map.hash_map_free$instance$001ff12ace7d7c19
	ldp	x8, x9, [sp]
	ldp	x10, x11, [sp, #16]
	eor	x8, x8, x8, lsr #30
	mov	x12, #58809                     ; =0xe5b9
	movk	x12, #7396, lsl #16
	movk	x12, #18285, lsl #32
	movk	x12, #48984, lsl #48
	mul	x8, x8, x12
	eor	x8, x8, x8, lsr #27
	mov	x13, #4587                      ; =0x11eb
	movk	x13, #4913, lsl #16
	movk	x13, #18875, lsl #32
	movk	x13, #38096, lsl #48
	mul	x8, x8, x13
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x12
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x13
	eor	x12, x9, x8
	mul	x11, x11, x24
	eor	x10, x19, x10
	eor	x10, x10, x11
	eor	x10, x10, x12, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #160]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #144]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #128]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
LBB41_17:                               ; %invalid.tag.b0.i
	bl	_abort
LBB41_18:                               ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh172, Lloh173
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_map_cost_library_geometry$instance$4250cb78d3f44027
lCPI42_0:
	.quad	0                               ; 0x0
	.quad	-9187201950435737472            ; 0x8080808080808080
lCPI42_1:
	.quad	1                               ; 0x1
	.quad	2                               ; 0x2
lCPI42_2:
	.quad	3                               ; 0x3
	.quad	4                               ; 0x4
lCPI42_3:
	.quad	5                               ; 0x5
	.quad	6                               ; 0x6
lCPI42_4:
	.quad	7                               ; 0x7
	.quad	8                               ; 0x8
lCPI42_5:
	.quad	9                               ; 0x9
	.quad	10                              ; 0xa
lCPI42_6:
	.quad	11                              ; 0xb
	.quad	12                              ; 0xc
lCPI42_7:
	.quad	13                              ; 0xd
	.quad	14                              ; 0xe
lCPI42_8:
	.quad	15                              ; 0xf
	.quad	16                              ; 0x10
lCPI42_9:
	.quad	17                              ; 0x11
	.quad	18                              ; 0x12
lCPI42_10:
	.quad	19                              ; 0x13
	.quad	20                              ; 0x14
lCPI42_11:
	.quad	21                              ; 0x15
	.quad	22                              ; 0x16
lCPI42_12:
	.quad	23                              ; 0x17
	.quad	24                              ; 0x18
lCPI42_13:
	.quad	25                              ; 0x19
	.quad	26                              ; 0x1a
lCPI42_14:
	.quad	27                              ; 0x1b
	.quad	28                              ; 0x1c
lCPI42_15:
	.quad	29                              ; 0x1d
	.quad	30                              ; 0x1e
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_map_cost_library_geometry$instance$4250cb78d3f44027
	.p2align	2
_wf_map_cost_library_geometry$instance$4250cb78d3f44027: ; @"wf_map_cost_library_geometry$instance$4250cb78d3f44027"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #864
	.cfi_def_cfa_offset 944
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
	mov	x24, #31765                     ; =0x7c15
	movk	x24, #32586, lsl #16
	movk	x24, #31161, lsl #32
	movk	x24, #40503, lsl #48
	eor	x8, x2, x24
	str	x8, [sp, #320]
	strb	wzr, [sp, #328]
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB42_14
; %bb.1:                                ; %bb1.i.i
	stp	xzr, x21, [x0]
	cbz	x21, LBB42_7
; %bb.2:                                ; %bb5.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
	movi.2d	v0, #0000000000000000
LBB42_3:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	q0, q0, [x9]
	stp	q0, q0, [x9, #32]
	stp	q0, q0, [x9, #64]
	stp	q0, q0, [x9, #96]
	stp	q0, q0, [x9, #128]
	stp	q0, q0, [x9, #160]
	stp	q0, q0, [x9, #192]
	stp	q0, q0, [x9, #224]
	str	xzr, [x9, #256]
	add	x9, x9, #272
	cmp	x21, x8
	b.ne	LBB42_3
; %bb.4:                                ; %"wf_hash_map.hash_map_extend$instance$0e108827ecbbe374.exit.i"
	str	x21, [x0]
	cmp	x21, #9
	b.lo	LBB42_7
; %bb.5:                                ; %bb2.i.i.i
	mov	x25, x0
	and	x23, x21, #0xfffffffffffffff8
	add	x0, x23, #8
	bl	_malloc
	cbz	x0, LBB42_14
; %bb.6:                                ; %buffer.fill.init.v2.i.i.i.i
	mov	x22, x0
	lsr	x8, x21, #3
	str	x8, [x0], #8
	mov	w1, #128                        ; =0x80
	mov	x2, x23
	bl	_memset
	mov	w8, #1                          ; =0x1
	mov	x0, x25
	b	LBB42_8
LBB42_7:
	mov	x22, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
LBB42_8:                                ; %"wf_hash_map.hash_map_new$instance$0e108827ecbbe374.exit"
	stp	xzr, x0, [sp, #272]
Lloh174:
	adrp	x9, lCPI42_0@PAGE
Lloh175:
	ldr	q0, [x9, lCPI42_0@PAGEOFF]
	add	x9, sp, #33
	stur	q0, [x9, #255]
	stp	x8, x22, [sp, #304]
	stp	x19, xzr, [sp, #248]
	str	xzr, [sp, #264]
	cbz	x20, LBB42_12
; %bb.9:                                ; %bb2.lr.ph
Lloh176:
	adrp	x8, lCPI42_1@PAGE
Lloh177:
	ldr	q0, [x8, lCPI42_1@PAGEOFF]
	str	q0, [sp, #224]                  ; 16-byte Folded Spill
	add	x22, sp, #608
Lloh178:
	adrp	x8, lCPI42_2@PAGE
Lloh179:
	ldr	q0, [x8, lCPI42_2@PAGEOFF]
	str	q0, [sp, #208]                  ; 16-byte Folded Spill
	mov	w21, #1                         ; =0x1
Lloh180:
	adrp	x8, lCPI42_3@PAGE
Lloh181:
	ldr	q0, [x8, lCPI42_3@PAGEOFF]
	str	q0, [sp, #192]                  ; 16-byte Folded Spill
Lloh182:
	adrp	x8, lCPI42_4@PAGE
Lloh183:
	ldr	q0, [x8, lCPI42_4@PAGEOFF]
	str	q0, [sp, #176]                  ; 16-byte Folded Spill
Lloh184:
	adrp	x8, lCPI42_5@PAGE
Lloh185:
	ldr	q0, [x8, lCPI42_5@PAGEOFF]
	str	q0, [sp, #160]                  ; 16-byte Folded Spill
Lloh186:
	adrp	x8, lCPI42_6@PAGE
Lloh187:
	ldr	q0, [x8, lCPI42_6@PAGEOFF]
	str	q0, [sp, #144]                  ; 16-byte Folded Spill
Lloh188:
	adrp	x8, lCPI42_7@PAGE
Lloh189:
	ldr	q0, [x8, lCPI42_7@PAGEOFF]
	str	q0, [sp, #128]                  ; 16-byte Folded Spill
Lloh190:
	adrp	x8, lCPI42_8@PAGE
Lloh191:
	ldr	q0, [x8, lCPI42_8@PAGEOFF]
	str	q0, [sp, #112]                  ; 16-byte Folded Spill
Lloh192:
	adrp	x8, lCPI42_9@PAGE
Lloh193:
	ldr	q0, [x8, lCPI42_9@PAGEOFF]
	str	q0, [sp, #96]                   ; 16-byte Folded Spill
Lloh194:
	adrp	x8, lCPI42_10@PAGE
Lloh195:
	ldr	q0, [x8, lCPI42_10@PAGEOFF]
	str	q0, [sp, #80]                   ; 16-byte Folded Spill
Lloh196:
	adrp	x8, lCPI42_11@PAGE
Lloh197:
	ldr	q0, [x8, lCPI42_11@PAGEOFF]
	str	q0, [sp, #64]                   ; 16-byte Folded Spill
Lloh198:
	adrp	x8, lCPI42_12@PAGE
Lloh199:
	ldr	q0, [x8, lCPI42_12@PAGEOFF]
	str	q0, [sp, #48]                   ; 16-byte Folded Spill
Lloh200:
	adrp	x8, lCPI42_13@PAGE
Lloh201:
	ldr	q0, [x8, lCPI42_13@PAGEOFF]
	str	q0, [sp, #32]                   ; 16-byte Folded Spill
Lloh202:
	adrp	x8, lCPI42_14@PAGE
Lloh203:
	ldr	q0, [x8, lCPI42_14@PAGEOFF]
	str	q0, [sp, #16]                   ; 16-byte Folded Spill
Lloh204:
	adrp	x8, lCPI42_15@PAGE
Lloh205:
	ldr	q0, [x8, lCPI42_15@PAGEOFF]
	str	q0, [sp]                        ; 16-byte Folded Spill
LBB42_10:                               ; %bb2
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v0, x19
	add	x8, x19, #31
	ldr	q1, [sp, #224]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x22, #8]
	ldr	q1, [sp, #208]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x22, #24]
	ldr	q1, [sp, #192]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x22, #40]
	ldr	q1, [sp, #176]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x22, #56]
	ldr	q1, [sp, #160]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x22, #72]
	ldr	q1, [sp, #144]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x22, #88]
	ldr	q1, [sp, #128]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x22, #104]
	ldr	q1, [sp, #112]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x22, #120]
	ldr	q1, [sp, #96]                   ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x22, #136]
	ldr	q1, [sp, #80]                   ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x22, #152]
	ldr	q1, [sp, #64]                   ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x22, #168]
	ldr	q1, [sp, #48]                   ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x22, #184]
	ldr	q1, [sp, #32]                   ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x22, #200]
	ldr	q1, [sp, #16]                   ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x22, #216]
	ldr	q1, [sp]                        ; 16-byte Folded Reload
	add.2d	v0, v0, v1
	stur	q0, [x22, #232]
	str	x19, [sp, #608]
	str	x8, [sp, #856]
	add	x0, sp, #336
	add	x1, sp, #280
	add	x3, sp, #608
	add	x4, sp, #320
	mov	x2, x21
	bl	_wf_hash_map.hash_map_put$instance$28da32efc51c2b65
	add	x0, sp, #336
	add	x1, sp, #248
	bl	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
	add	x19, x19, #1
	add	x21, x21, #2
	subs	x20, x20, #1
	b.ne	LBB42_10
; %bb.11:                               ; %bb4.loopexit
	ldp	x9, x8, [sp, #280]
	ldr	x21, [x9]
	b	LBB42_13
LBB42_12:
	mov	x8, #0                          ; =0x0
LBB42_13:                               ; %bb4
	add	x19, x8, x21, lsl #32
	add	x0, sp, #280
	add	x1, sp, #248
	bl	_wf_hash_map.hash_map_free$instance$d5f8785ab7665d71
	ldp	x8, x9, [sp, #248]
	ldp	x10, x11, [sp, #264]
	eor	x8, x8, x8, lsr #30
	mov	x12, #58809                     ; =0xe5b9
	movk	x12, #7396, lsl #16
	movk	x12, #18285, lsl #32
	movk	x12, #48984, lsl #48
	mul	x8, x8, x12
	eor	x8, x8, x8, lsr #27
	mov	x13, #4587                      ; =0x11eb
	movk	x13, #4913, lsl #16
	movk	x13, #18875, lsl #32
	movk	x13, #38096, lsl #48
	mul	x8, x8, x13
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x12
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x13
	eor	x12, x9, x8
	mul	x11, x11, x24
	eor	x10, x19, x10
	eor	x10, x10, x11
	eor	x10, x10, x12, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	add	sp, sp, #864
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
LBB42_14:                               ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh174, Lloh175
	.loh AdrpLdr	Lloh204, Lloh205
	.loh AdrpAdrp	Lloh202, Lloh204
	.loh AdrpLdr	Lloh202, Lloh203
	.loh AdrpAdrp	Lloh200, Lloh202
	.loh AdrpLdr	Lloh200, Lloh201
	.loh AdrpAdrp	Lloh198, Lloh200
	.loh AdrpLdr	Lloh198, Lloh199
	.loh AdrpAdrp	Lloh196, Lloh198
	.loh AdrpLdr	Lloh196, Lloh197
	.loh AdrpAdrp	Lloh194, Lloh196
	.loh AdrpLdr	Lloh194, Lloh195
	.loh AdrpAdrp	Lloh192, Lloh194
	.loh AdrpLdr	Lloh192, Lloh193
	.loh AdrpAdrp	Lloh190, Lloh192
	.loh AdrpLdr	Lloh190, Lloh191
	.loh AdrpAdrp	Lloh188, Lloh190
	.loh AdrpLdr	Lloh188, Lloh189
	.loh AdrpAdrp	Lloh186, Lloh188
	.loh AdrpLdr	Lloh186, Lloh187
	.loh AdrpAdrp	Lloh184, Lloh186
	.loh AdrpLdr	Lloh184, Lloh185
	.loh AdrpAdrp	Lloh182, Lloh184
	.loh AdrpLdr	Lloh182, Lloh183
	.loh AdrpAdrp	Lloh180, Lloh182
	.loh AdrpLdr	Lloh180, Lloh181
	.loh AdrpAdrp	Lloh178, Lloh180
	.loh AdrpLdr	Lloh178, Lloh179
	.loh AdrpAdrp	Lloh176, Lloh178
	.loh AdrpLdr	Lloh176, Lloh177
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_hash_map.hash_map_new$instance$a62a753cf2b0b5ca
lCPI43_0:
	.quad	0                               ; 0x0
	.quad	-9187201950435737472            ; 0x8080808080808080
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_hash_map.hash_map_new$instance$a62a753cf2b0b5ca
	.p2align	2
_wf_hash_map.hash_map_new$instance$a62a753cf2b0b5ca: ; @"wf_hash_map.hash_map_new$instance$a62a753cf2b0b5ca"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x1
	mov	x19, x0
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	madd	x0, x1, x8, x9
	bl	_malloc
	cbz	x0, LBB43_9
; %bb.1:                                ; %bb1.i
	stp	xzr, x20, [x0]
	cbz	x20, LBB43_7
; %bb.2:                                ; %bb5.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
LBB43_3:                                ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x9], #24
	cmp	x20, x8
	b.ne	LBB43_3
; %bb.4:                                ; %"wf_hash_map.hash_map_extend$instance$a62a753cf2b0b5ca.exit"
	str	x20, [x0]
	cmp	x20, #9
	b.lo	LBB43_7
; %bb.5:                                ; %bb2.i.i
	mov	x23, x0
	and	x22, x20, #0xfffffffffffffff8
	add	x0, x22, #8
	bl	_malloc
	cbz	x0, LBB43_9
; %bb.6:                                ; %buffer.fill.init.v2.i.i.i
	mov	x21, x0
	lsr	x8, x20, #3
	str	x8, [x0], #8
	mov	w1, #128                        ; =0x80
	mov	x2, x22
	bl	_memset
	mov	w8, #1                          ; =0x1
	mov	x0, x23
	b	LBB43_8
LBB43_7:
	mov	x21, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
LBB43_8:                                ; %"wf_hash_map.hash_map_controls_new$instance$c559014c068e16a3.exit"
	str	x0, [x19]
Lloh206:
	adrp	x9, lCPI43_0@PAGE
Lloh207:
	ldr	q0, [x9, lCPI43_0@PAGEOFF]
	stur	q0, [x19, #8]
	stp	x8, x21, [x19, #24]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB43_9:                                ; %window.block.oom.v1.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh206, Lloh207
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_put$instance$c7b22b9ef52855b6 ; -- Begin function wf_hash_map.hash_map_put$instance$c7b22b9ef52855b6
	.p2align	2
_wf_hash_map.hash_map_put$instance$c7b22b9ef52855b6: ; @"wf_hash_map.hash_map_put$instance$c7b22b9ef52855b6"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #112
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 112
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x4
	mov	x21, x1
	mov	x19, x0
	mov	x23, sp
	mov	x0, sp
	bl	_wf_hash_map.hash_map_try_put$instance$c7b22b9ef52855b6
	ldr	w8, [sp]
	cbz	w8, LBB44_5
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB44_11
; %bb.2:                                ; %bb2
	mov	x22, sp
	ldrb	w8, [sp, #4]
	ldur	q0, [sp, #8]
	stur	q0, [x23, #24]
	tbz	w8, #0, LBB44_6
; %bb.3:                                ; %bb4
	ldr	x8, [x21]
	ldr	x8, [x8]
	cmp	x8, #3
	b.lo	LBB44_8
LBB44_4:                                ; %bb6
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	strb	w8, [x19, #4]
	b	LBB44_7
LBB44_5:                                ; %bb1
	stp	xzr, xzr, [x19]
	str	xzr, [x19, #16]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB44_6:                                ; %bb3
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
LBB44_7:                                ; %common.ret
	ldur	q0, [x22, #8]
	stur	q0, [x19, #8]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB44_8:                                ; %bb7
	mov	w9, #1                          ; =0x1
	mov	w10, #3                         ; =0x3
	lsl	x11, x8, #1
	cmp	x8, #2
	csel	x10, x10, x11, eq
	cmp	x8, #0
	csel	x1, x9, x10, eq
	cmp	x1, x8
	b.ls	LBB44_12
; %bb.9:                                ; %"wf_hash_map.hash_map_reserve$instance$c7b22b9ef52855b6.exit"
	mov	x0, x21
	mov	x2, x20
	bl	_wf_hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6
	cbz	w0, LBB44_12
; %bb.10:                               ; %"wf_hash_map.hash_map_reserve$instance$c7b22b9ef52855b6.exit"
	cmp	w0, #1
	b.eq	LBB44_4
LBB44_11:                               ; %invalid.tag.b0
	bl	_abort
LBB44_12:                               ; %bb17
	ldp	x2, x3, [sp, #24]
	mov	x0, x19
	mov	x1, x21
	mov	x4, x20
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
	b	_wf_hash_map.hash_map_try_put$instance$c7b22b9ef52855b6
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd ; -- Begin function wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd
	.p2align	2
_wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd: ; @"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd"
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cbz	w8, LBB45_3
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB45_4
; %bb.2:                                ; %bb3
	ldp	x9, x8, [x0, #8]
	ldrb	w10, [x0, #4]
	ldr	x11, [x1]
	mov	w12, #131                       ; =0x83
	tst	w10, #0x1
	mov	w10, #1                         ; =0x1
	cinc	x10, x10, ne
	madd	x10, x11, x12, x10
	add	x9, x10, x9
	madd	x8, x9, x12, x8
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
LBB45_3:                                ; %bb2
	ldr	x8, [x1]
	mov	w9, #131                        ; =0x83
	mul	x8, x8, x9
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
LBB45_4:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_free$instance$5c6f40d0925a4760 ; -- Begin function wf_hash_map.hash_map_free$instance$5c6f40d0925a4760
	.p2align	2
_wf_hash_map.hash_map_free$instance$5c6f40d0925a4760: ; @"wf_hash_map.hash_map_free$instance$5c6f40d0925a4760"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	mov	x8, x0
	ldr	x0, [x0]
	ldp	x19, x20, [x8, #24]
	ldr	x12, [x0]
	cbz	x12, LBB46_7
; %bb.1:                                ; %bb5.lr.ph
	ldp	x8, x9, [x1, #8]
	ldr	x10, [x1, #24]
	sub	x11, x12, #1
	mov	w13, #24                        ; =0x18
	madd	x12, x12, x13, x0
	mov	w13, #131                       ; =0x83
	mov	x14, #58809                     ; =0xe5b9
	movk	x14, #7396, lsl #16
	movk	x14, #18285, lsl #32
	movk	x14, #48984, lsl #48
	mov	x15, #4587                      ; =0x11eb
	movk	x15, #4913, lsl #16
	movk	x15, #18875, lsl #32
	movk	x15, #38096, lsl #48
	b	LBB46_4
LBB46_2:                                ; %bb7
                                        ;   in Loop: Header=BB46_4 Depth=1
	ldp	x17, x16, [x12]
	madd	x16, x17, x13, x16
	add	x8, x16, x8
	eor	x16, x16, x16, lsr #30
	mul	x16, x16, x14
	eor	x16, x16, x16, lsr #27
	mul	x16, x16, x15
	eor	x9, x9, x16, lsr #31
	eor	x9, x9, x16
	stp	x8, x9, [x1, #8]
	add	x10, x10, #1
	str	x10, [x1, #24]
LBB46_3:                                ; %bb6
                                        ;   in Loop: Header=BB46_4 Depth=1
	sub	x11, x11, #1
	sub	x12, x12, #24
	cmn	x11, #1
	b.eq	LBB46_7
LBB46_4:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	str	x11, [x0]
	ldur	w16, [x12, #-8]
	cmp	w16, #2
	b.lo	LBB46_3
; %bb.5:                                ; %bb5
                                        ;   in Loop: Header=BB46_4 Depth=1
	b.eq	LBB46_2
; %bb.6:                                ; %invalid.tag.b3
	bl	_abort
LBB46_7:                                ; %bb4
	bl	_free
	stp	x19, x20, [sp]
	cbz	x19, LBB46_10
; %bb.8:                                ; %body.i.preheader
	mov	x20, #0                         ; =0x0
	mov	x8, sp
	add	x21, x8, #8
LBB46_9:                                ; %body.i
                                        ; =>This Inner Loop Header: Depth=1
	cmp	x20, #1
	csinc	x8, x20, xzr, lo
	sub	x8, x21, x8, lsl #3
	ldr	x0, [x8]
	bl	_free
	add	x20, x20, #1
	add	x21, x21, #8
	subs	x19, x19, #1
	b.ne	LBB46_9
LBB46_10:                               ; %wf.drop.run.707f874ef98d2803.exit
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_hash_map.hash_map_new$instance$820b2044b97e0fbd
lCPI47_0:
	.quad	0                               ; 0x0
	.quad	-9187201950435737472            ; 0x8080808080808080
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_hash_map.hash_map_new$instance$820b2044b97e0fbd
	.p2align	2
_wf_hash_map.hash_map_new$instance$820b2044b97e0fbd: ; @"wf_hash_map.hash_map_new$instance$820b2044b97e0fbd"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x1
	mov	x19, x0
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	madd	x0, x1, x8, x9
	bl	_malloc
	cbz	x0, LBB47_9
; %bb.1:                                ; %bb1.i
	stp	xzr, x20, [x0]
	cbz	x20, LBB47_7
; %bb.2:                                ; %bb5.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
LBB47_3:                                ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x9], #24
	cmp	x20, x8
	b.ne	LBB47_3
; %bb.4:                                ; %"wf_hash_map.hash_map_extend$instance$820b2044b97e0fbd.exit"
	str	x20, [x0]
	cmp	x20, #9
	b.lo	LBB47_7
; %bb.5:                                ; %bb2.i.i
	mov	x23, x0
	and	x22, x20, #0xfffffffffffffff8
	add	x0, x22, #8
	bl	_malloc
	cbz	x0, LBB47_9
; %bb.6:                                ; %buffer.fill.init.v2.i.i.i
	mov	x21, x0
	lsr	x8, x20, #3
	str	x8, [x0], #8
	mov	w1, #128                        ; =0x80
	mov	x2, x22
	bl	_memset
	mov	w8, #1                          ; =0x1
	mov	x0, x23
	b	LBB47_8
LBB47_7:
	mov	x21, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
LBB47_8:                                ; %"wf_hash_map.hash_map_controls_new$instance$fd5e04af5c7e1250.exit"
	str	x0, [x19]
Lloh208:
	adrp	x9, lCPI47_0@PAGE
Lloh209:
	ldr	q0, [x9, lCPI47_0@PAGEOFF]
	stur	q0, [x19, #8]
	stp	x8, x21, [x19, #24]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB47_9:                                ; %window.block.oom.v1.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh208, Lloh209
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad ; -- Begin function wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad
	.p2align	2
_wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad: ; @"wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #112
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 112
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x4
	mov	x21, x1
	mov	x19, x0
	mov	x23, sp
	mov	x0, sp
	bl	_wf_hash_map.hash_map_try_put$instance$fde7c6722a8b0dad
	ldr	w8, [sp]
	cbz	w8, LBB48_5
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB48_11
; %bb.2:                                ; %bb2
	mov	x22, sp
	ldrb	w8, [sp, #4]
	ldur	q0, [sp, #8]
	stur	q0, [x23, #24]
	tbz	w8, #0, LBB48_6
; %bb.3:                                ; %bb4
	ldr	x8, [x21]
	ldr	x8, [x8]
	cmp	x8, #4, lsl #12                 ; =16384
	b.lo	LBB48_8
LBB48_4:                                ; %bb6
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	strb	w8, [x19, #4]
	b	LBB48_7
LBB48_5:                                ; %bb1
	stp	xzr, xzr, [x19]
	str	xzr, [x19, #16]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB48_6:                                ; %bb3
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
LBB48_7:                                ; %common.ret
	ldur	q0, [x22, #8]
	stur	q0, [x19, #8]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB48_8:                                ; %bb7
	mov	w9, #8192                       ; =0x2000
	cmp	x8, #2, lsl #12                 ; =8192
	csel	x9, x8, x9, lo
	lsl	x9, x9, #1
	cmp	x8, #0
	csinc	x1, x9, xzr, ne
	cmp	x1, x8
	b.ls	LBB48_12
; %bb.9:                                ; %"wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit"
	mov	x0, x21
	mov	x2, x20
	bl	_wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	cbz	w0, LBB48_12
; %bb.10:                               ; %"wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit"
	cmp	w0, #1
	b.eq	LBB48_4
LBB48_11:                               ; %invalid.tag.b0
	bl	_abort
LBB48_12:                               ; %bb17
	ldp	x2, x3, [sp, #24]
	mov	x0, x19
	mov	x1, x21
	mov	x4, x20
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
	b	_wf_hash_map.hash_map_try_put$instance$fde7c6722a8b0dad
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_remove$instance$fde7c6722a8b0dad ; -- Begin function wf_hash_map.hash_map_remove$instance$fde7c6722a8b0dad
	.p2align	2
_wf_hash_map.hash_map_remove$instance$fde7c6722a8b0dad: ; @"wf_hash_map.hash_map_remove$instance$fde7c6722a8b0dad"
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	ldr	x20, [x0, #8]
	cbz	x20, LBB49_9
; %bb.1:                                ; %bb3.i
	mov	x19, x0
	bl	_wf_hash_map.hash_map_find$instance$fde7c6722a8b0dad
	cmp	w0, #1
	b.eq	LBB49_9
; %bb.2:                                ; %bb3.i
	cbnz	w0, LBB49_13
; %bb.3:                                ; %bb4.i
	mov	x8, x1
	ldr	x9, [x19]
	mov	w10, #24                        ; =0x18
	madd	x12, x1, x10, x9
	ldr	w9, [x12, #16]
	ldp	x1, x2, [x12, #24]
	mov	w10, #1                         ; =0x1
	str	w10, [x12, #16]
	ubfiz	x11, x8, #3, #3
	mov	w10, #255                       ; =0xff
	lsl	x10, x10, x11
	mvn	x10, x10
	mov	w13, #254                       ; =0xfe
	lsl	x11, x13, x11
	stp	xzr, xzr, [x12, #24]
	ldr	x12, [x19, #24]
	cbz	x12, LBB49_6
; %bb.4:                                ; %bb3.i.i
	lsr	x8, x8, #3
	ldr	x12, [x19, #32]
	ldr	x13, [x12]
	cmp	x8, x13
	b.hs	LBB49_12
; %bb.5:                                ; %bb8.i.i
	add	x8, x12, x8, lsl #3
	ldr	x12, [x8, #8]
	and	x10, x12, x10
	orr	x10, x10, x11
	str	x10, [x8, #8]
	b	LBB49_8
LBB49_6:                                ; %bb2.i.i
	cmp	x8, #8
	b.hs	LBB49_8
LBB49_7:                                ; %bb11.i.i
	ldr	x8, [x19, #16]
	and	x8, x8, x10
	orr	x8, x8, x11
	str	x8, [x19, #16]
LBB49_8:                                ; %wf_hash_map.hash_map_control_set.exit.i
	cmp	w9, #2
	b.hs	LBB49_10
LBB49_9:
	mov	w0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB49_10:                               ; %wf_hash_map.hash_map_control_set.exit.i
	b.ne	LBB49_13
; %bb.11:                               ; %bb6.i
	sub	x8, x20, #1
	str	x8, [x19, #8]
	mov	w0, #1                          ; =0x1
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB49_12:                               ; %bb9.i.i
	b.eq	LBB49_7
	b	LBB49_8
LBB49_13:                               ; %invalid.tag.b1.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50 ; -- Begin function wf_hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50
	.p2align	2
_wf_hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50: ; @"wf_hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50"
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	mov	x19, x0
	bl	_wf_hash_map.hash_map_find$instance$fde7c6722a8b0dad
	cbz	w0, LBB50_3
; %bb.1:                                ; %entry
	cmp	w0, #1
	b.ne	LBB50_7
; %bb.2:
	mov	x1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB50_3:                                ; %bb1.i
	ldr	x8, [x19]
	mov	w9, #24                         ; =0x18
	madd	x8, x1, x9, x8
	ldr	w9, [x8, #16]!
	cmp	w9, #2
	b.hs	LBB50_5
; %bb.4:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB50_5:                                ; %bb1.i
	b.ne	LBB50_7
; %bb.6:                                ; %bb3.i
	mov	w0, #0                          ; =0x0
	ldr	x1, [x8, #16]
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB50_7:                                ; %invalid.tag.b0.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_rehash$instance$fde7c6722a8b0dad ; -- Begin function wf_hash_map.hash_map_rehash$instance$fde7c6722a8b0dad
	.p2align	2
_wf_hash_map.hash_map_rehash$instance$fde7c6722a8b0dad: ; @"wf_hash_map.hash_map_rehash$instance$fde7c6722a8b0dad"
	.cfi_startproc
; %bb.0:                                ; %entry
	mov	x2, x1
	ldr	x8, [x0]
	ldr	x1, [x8]
	b	_wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad ; -- Begin function wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad
	.p2align	2
_wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad: ; @"wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad"
	.cfi_startproc
; %bb.0:                                ; %entry
	cmp	x1, #4, lsl #12                 ; =16384
	b.ls	LBB52_2
; %bb.1:
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	ret
LBB52_2:                                ; %bb3.i
	ldr	x8, [x0]
	ldr	x8, [x8]
	cmp	x1, x8
	b.ls	LBB52_4
; %bb.3:                                ; %bb6.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB52_4:
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_capacity$instance$820b2044b97e0fbd ; -- Begin function wf_hash_map.hash_map_capacity$instance$820b2044b97e0fbd
	.p2align	2
_wf_hash_map.hash_map_capacity$instance$820b2044b97e0fbd: ; @"wf_hash_map.hash_map_capacity$instance$820b2044b97e0fbd"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x0, [x8]
	ret
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_edit$instance$25497bb333d90567 ; -- Begin function wf_hash_map.hash_map_edit$instance$25497bb333d90567
	.p2align	2
_wf_hash_map.hash_map_edit$instance$25497bb333d90567: ; @"wf_hash_map.hash_map_edit$instance$25497bb333d90567"
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	mov	x19, x0
	bl	_wf_hash_map.hash_map_find$instance$fde7c6722a8b0dad
	cbz	w0, LBB54_3
; %bb.1:                                ; %entry
	cmp	w0, #1
	b.ne	LBB54_7
; %bb.2:
	mov	x1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB54_3:                                ; %bb1.i
	ldr	x8, [x19]
	mov	w9, #24                         ; =0x18
	madd	x8, x1, x9, x8
	ldr	w9, [x8, #16]!
	cmp	w9, #2
	b.hs	LBB54_5
; %bb.4:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB54_5:                                ; %bb1.i
	b.ne	LBB54_7
; %bb.6:                                ; %bb3.i
	mov	w0, #0                          ; =0x0
	ldr	x9, [x8, #16]
	add	x1, x9, #1
	str	x1, [x8, #16]
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB54_7:                                ; %invalid.tag.b0.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_free$instance$001ff12ace7d7c19 ; -- Begin function wf_hash_map.hash_map_free$instance$001ff12ace7d7c19
	.p2align	2
_wf_hash_map.hash_map_free$instance$001ff12ace7d7c19: ; @"wf_hash_map.hash_map_free$instance$001ff12ace7d7c19"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	mov	x8, x0
	ldr	x0, [x0]
	ldp	x19, x20, [x8, #24]
	ldr	x12, [x0]
	cbz	x12, LBB55_7
; %bb.1:                                ; %bb5.lr.ph
	ldp	x8, x9, [x1, #8]
	ldr	x10, [x1, #24]
	sub	x11, x12, #1
	mov	w13, #24                        ; =0x18
	madd	x12, x12, x13, x0
	mov	w13, #131                       ; =0x83
	mov	x14, #58809                     ; =0xe5b9
	movk	x14, #7396, lsl #16
	movk	x14, #18285, lsl #32
	movk	x14, #48984, lsl #48
	mov	x15, #4587                      ; =0x11eb
	movk	x15, #4913, lsl #16
	movk	x15, #18875, lsl #32
	movk	x15, #38096, lsl #48
	b	LBB55_4
LBB55_2:                                ; %bb7
                                        ;   in Loop: Header=BB55_4 Depth=1
	ldp	x17, x16, [x12]
	madd	x16, x17, x13, x16
	add	x8, x16, x8
	eor	x16, x16, x16, lsr #30
	mul	x16, x16, x14
	eor	x16, x16, x16, lsr #27
	mul	x16, x16, x15
	eor	x9, x9, x16, lsr #31
	eor	x9, x9, x16
	stp	x8, x9, [x1, #8]
	add	x10, x10, #1
	str	x10, [x1, #24]
LBB55_3:                                ; %bb6
                                        ;   in Loop: Header=BB55_4 Depth=1
	sub	x11, x11, #1
	sub	x12, x12, #24
	cmn	x11, #1
	b.eq	LBB55_7
LBB55_4:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	str	x11, [x0]
	ldur	w16, [x12, #-8]
	cmp	w16, #2
	b.lo	LBB55_3
; %bb.5:                                ; %bb5
                                        ;   in Loop: Header=BB55_4 Depth=1
	b.eq	LBB55_2
; %bb.6:                                ; %invalid.tag.b3
	bl	_abort
LBB55_7:                                ; %bb4
	bl	_free
	stp	x19, x20, [sp]
	cbz	x19, LBB55_10
; %bb.8:                                ; %body.i.preheader
	mov	x20, #0                         ; =0x0
	mov	x8, sp
	add	x21, x8, #8
LBB55_9:                                ; %body.i
                                        ; =>This Inner Loop Header: Depth=1
	cmp	x20, #1
	csinc	x8, x20, xzr, lo
	sub	x8, x21, x8, lsl #3
	ldr	x0, [x8]
	bl	_free
	add	x20, x20, #1
	add	x21, x21, #8
	subs	x19, x19, #1
	b.ne	LBB55_9
LBB55_10:                               ; %wf.drop.run.707f874ef98d2803.exit
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_hash_map.hash_map_new$instance$96033bf6ddb80743
lCPI56_0:
	.quad	0                               ; 0x0
	.quad	-9187201950435737472            ; 0x8080808080808080
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_hash_map.hash_map_new$instance$96033bf6ddb80743
	.p2align	2
_wf_hash_map.hash_map_new$instance$96033bf6ddb80743: ; @"wf_hash_map.hash_map_new$instance$96033bf6ddb80743"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x1
	mov	x19, x0
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	madd	x0, x1, x8, x9
	bl	_malloc
	cbz	x0, LBB56_9
; %bb.1:                                ; %bb1.i
	stp	xzr, x20, [x0]
	cbz	x20, LBB56_7
; %bb.2:                                ; %bb5.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
	movi.2d	v0, #0000000000000000
LBB56_3:                                ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	q0, q0, [x9]
	stp	q0, q0, [x9, #32]
	stp	q0, q0, [x9, #64]
	stp	q0, q0, [x9, #96]
	stp	q0, q0, [x9, #128]
	stp	q0, q0, [x9, #160]
	stp	q0, q0, [x9, #192]
	stp	q0, q0, [x9, #224]
	str	xzr, [x9, #256]
	add	x9, x9, #272
	cmp	x20, x8
	b.ne	LBB56_3
; %bb.4:                                ; %"wf_hash_map.hash_map_extend$instance$96033bf6ddb80743.exit"
	str	x20, [x0]
	cmp	x20, #9
	b.lo	LBB56_7
; %bb.5:                                ; %bb2.i.i
	mov	x23, x0
	and	x22, x20, #0xfffffffffffffff8
	add	x0, x22, #8
	bl	_malloc
	cbz	x0, LBB56_9
; %bb.6:                                ; %buffer.fill.init.v2.i.i.i
	mov	x21, x0
	lsr	x8, x20, #3
	str	x8, [x0], #8
	mov	w1, #128                        ; =0x80
	mov	x2, x22
	bl	_memset
	mov	w8, #1                          ; =0x1
	mov	x0, x23
	b	LBB56_8
LBB56_7:
	mov	x21, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
LBB56_8:                                ; %"wf_hash_map.hash_map_controls_new$instance$c559014c068e16a3.exit"
	str	x0, [x19]
Lloh210:
	adrp	x9, lCPI56_0@PAGE
Lloh211:
	ldr	q0, [x9, lCPI56_0@PAGEOFF]
	stur	q0, [x19, #8]
	stp	x8, x21, [x19, #24]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB56_9:                                ; %window.block.oom.v1.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh210, Lloh211
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_put$instance$8d5197e2f00c3b07 ; -- Begin function wf_hash_map.hash_map_put$instance$8d5197e2f00c3b07
	.p2align	2
_wf_hash_map.hash_map_put$instance$8d5197e2f00c3b07: ; @"wf_hash_map.hash_map_put$instance$8d5197e2f00c3b07"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #1056
	.cfi_def_cfa_offset 1136
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	mov	x20, x4
	mov	x21, x1
	mov	x19, x0
	ldp	q0, q1, [x3, #192]
	mov	x22, sp
	stp	q0, q1, [sp, #192]
	ldp	q0, q1, [x3, #224]
	stp	q0, q1, [sp, #224]
	ldp	q0, q1, [x3, #128]
	stp	q0, q1, [sp, #128]
	ldp	q0, q1, [x3, #160]
	stp	q0, q1, [sp, #160]
	ldp	q0, q1, [x3, #64]
	stp	q0, q1, [sp, #64]
	ldp	q0, q1, [x3, #96]
	stp	q0, q1, [sp, #96]
	ldp	q0, q1, [x3]
	stp	q0, q1, [sp]
	ldp	q0, q1, [x3, #32]
	stp	q0, q1, [sp, #32]
	add	x0, x22, #256
	mov	x3, sp
	bl	_wf_hash_map.hash_map_try_put$instance$8d5197e2f00c3b07
	ldr	w8, [sp, #256]
	cbz	w8, LBB57_5
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB57_15
; %bb.2:                                ; %bb2
	mov	x23, sp
	ldrb	w24, [sp, #260]
	add	x0, x22, #528
	add	x1, x23, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	tbz	w24, #0, LBB57_6
; %bb.3:                                ; %bb4
	ldr	x8, [x21]
	ldr	x8, [x8]
	cmp	x8, #3
	b.lo	LBB57_9
LBB57_4:                                ; %bb6
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	strb	w8, [x19, #4]
	add	x0, x19, #8
	add	x1, x23, #264
	b	LBB57_7
LBB57_5:                                ; %bb1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #240]
	stp	q0, q0, [x19, #208]
	stp	q0, q0, [x19, #176]
	stp	q0, q0, [x19, #144]
	stp	q0, q0, [x19, #112]
	stp	q0, q0, [x19, #80]
	stp	q0, q0, [x19, #48]
	stp	q0, q0, [x19, #16]
	str	q0, [x19]
	b	LBB57_8
LBB57_6:                                ; %bb3
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19], #8
	add	x1, x23, #264
	mov	x0, x19
LBB57_7:                                ; %common.ret
	mov	w2, #264                        ; =0x108
	bl	_memcpy
LBB57_8:                                ; %common.ret
	add	sp, sp, #1056
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
LBB57_9:                                ; %bb7
	cbz	x8, LBB57_12
; %bb.10:                               ; %bb7
	cmp	x8, #2
	b.ne	LBB57_16
; %bb.11:                               ; %bb3.i.i.fold.split
	mov	w1, #3                          ; =0x3
	cmp	x1, x8
	b.hi	LBB57_13
	b	LBB57_17
LBB57_12:
	mov	w1, #1                          ; =0x1
	cmp	x1, x8
	b.ls	LBB57_17
LBB57_13:                               ; %"wf_hash_map.hash_map_reserve$instance$8d5197e2f00c3b07.exit"
	mov	x0, x21
	mov	x2, x20
	bl	_wf_hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07
	str	w0, [sp, #792]
	strb	w1, [sp, #796]
	strb	w2, [sp, #797]
	cbz	w0, LBB57_18
; %bb.14:                               ; %"wf_hash_map.hash_map_reserve$instance$8d5197e2f00c3b07.exit"
	cmp	w0, #1
	b.eq	LBB57_4
LBB57_15:                               ; %invalid.tag.b0
	bl	_abort
LBB57_16:                               ; %bb8
	lsl	x1, x8, #1
	cmp	x1, x8
	b.hi	LBB57_13
LBB57_17:                               ; %"wf_hash_map.hash_map_reserve$instance$8d5197e2f00c3b07.exit.thread"
	str	wzr, [sp, #792]
	strh	wzr, [sp, #796]
LBB57_18:                               ; %bb17
	add	x3, x22, #800
	ldr	x2, [sp, #528]
	mov	x8, sp
	add	x8, x8, #536
	ldp	q0, q1, [x8, #192]
	stp	q0, q1, [x3, #192]
	ldp	q0, q1, [x8, #224]
	stp	q0, q1, [x3, #224]
	ldp	q0, q1, [x8, #128]
	stp	q0, q1, [x3, #128]
	ldp	q0, q1, [x8, #160]
	stp	q0, q1, [x3, #160]
	ldp	q0, q1, [x8, #64]
	stp	q0, q1, [x3, #64]
	ldp	q0, q1, [x8, #96]
	stp	q0, q1, [x3, #96]
	ldp	q0, q1, [x8]
	stp	q0, q1, [x3]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x3, #32]
	mov	x0, x19
	mov	x1, x21
	mov	x4, x20
	bl	_wf_hash_map.hash_map_try_put$instance$8d5197e2f00c3b07
	b	LBB57_8
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027 ; -- Begin function wf_map_cost_library_policy_result$instance$4250cb78d3f44027
	.p2align	2
_wf_map_cost_library_policy_result$instance$4250cb78d3f44027: ; @"wf_map_cost_library_policy_result$instance$4250cb78d3f44027"
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cbz	w8, LBB58_3
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB58_4
; %bb.2:                                ; %bb3
	ldrb	w9, [x0, #4]
	ldr	x10, [x1]
	mov	w8, #131                        ; =0x83
	tst	w9, #0x1
	mov	w9, #1                          ; =0x1
	cinc	x9, x9, ne
	madd	x9, x10, x8, x9
	ldp	x11, x10, [x0, #8]
	madd	x10, x11, x8, x10
	ldr	x11, [x0, #24]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #32]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #40]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #48]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #56]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #64]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #72]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #80]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #88]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #96]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #104]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #112]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #120]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #128]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #136]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #144]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #152]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #160]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #168]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #176]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #184]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #192]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #200]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #208]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #216]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #224]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #232]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #240]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #248]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #256]
	madd	x10, x10, x8, x11
	add	x9, x10, x9
	ldr	x10, [x0, #264]
	madd	x8, x9, x8, x10
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
LBB58_3:                                ; %bb2
	ldr	x8, [x1]
	mov	w9, #131                        ; =0x83
	mul	x8, x8, x9
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
LBB58_4:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_free$instance$72d84b2e6d0b7146 ; -- Begin function wf_hash_map.hash_map_free$instance$72d84b2e6d0b7146
	.p2align	2
_wf_hash_map.hash_map_free$instance$72d84b2e6d0b7146: ; @"wf_hash_map.hash_map_free$instance$72d84b2e6d0b7146"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	mov	x8, x0
	ldr	x0, [x0]
	ldp	x19, x20, [x8, #24]
	ldr	x11, [x0]
	cbz	x11, LBB59_7
; %bb.1:                                ; %bb5.lr.ph
	ldp	x8, x9, [x1, #8]
	sub	x10, x11, #1
	mov	w12, #272                       ; =0x110
	madd	x12, x11, x12, x0
	ldr	x11, [x1, #24]
	sub	x12, x12, #120
	mov	w13, #131                       ; =0x83
	mov	x14, #58809                     ; =0xe5b9
	movk	x14, #7396, lsl #16
	movk	x14, #18285, lsl #32
	movk	x14, #48984, lsl #48
	mov	x15, #4587                      ; =0x11eb
	movk	x15, #4913, lsl #16
	movk	x15, #18875, lsl #32
	movk	x15, #38096, lsl #48
	b	LBB59_4
LBB59_2:                                ; %bb7
                                        ;   in Loop: Header=BB59_4 Depth=1
	ldp	x17, x16, [x12, #-128]
	madd	x16, x17, x13, x16
	ldur	x17, [x12, #-112]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-104]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-96]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-88]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-80]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-72]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-64]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-56]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-48]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-40]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-32]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-24]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-16]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-8]
	madd	x16, x16, x13, x17
	ldr	x17, [x12]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #8]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #16]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #24]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #32]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #40]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #48]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #56]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #64]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #72]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #80]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #88]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #96]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #104]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #112]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #120]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #128]
	madd	x16, x16, x13, x17
	add	x8, x16, x8
	eor	x16, x16, x16, lsr #30
	mul	x16, x16, x14
	eor	x16, x16, x16, lsr #27
	mul	x16, x16, x15
	eor	x9, x9, x16, lsr #31
	eor	x9, x9, x16
	stp	x8, x9, [x1, #8]
	add	x11, x11, #1
	str	x11, [x1, #24]
LBB59_3:                                ; %bb6
                                        ;   in Loop: Header=BB59_4 Depth=1
	sub	x10, x10, #1
	sub	x12, x12, #272
	cmn	x10, #1
	b.eq	LBB59_7
LBB59_4:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	str	x10, [x0]
	ldur	w16, [x12, #-136]
	cmp	w16, #2
	b.lo	LBB59_3
; %bb.5:                                ; %bb5
                                        ;   in Loop: Header=BB59_4 Depth=1
	b.eq	LBB59_2
; %bb.6:                                ; %invalid.tag.b3
	bl	_abort
LBB59_7:                                ; %bb4
	bl	_free
	stp	x19, x20, [sp]
	cbz	x19, LBB59_10
; %bb.8:                                ; %body.i.preheader
	mov	x20, #0                         ; =0x0
	mov	x8, sp
	add	x21, x8, #8
LBB59_9:                                ; %body.i
                                        ; =>This Inner Loop Header: Depth=1
	cmp	x20, #1
	csinc	x8, x20, xzr, lo
	sub	x8, x21, x8, lsl #3
	ldr	x0, [x8]
	bl	_free
	add	x20, x20, #1
	add	x21, x21, #8
	subs	x19, x19, #1
	b.ne	LBB59_9
LBB59_10:                               ; %wf.drop.run.707f874ef98d2803.exit
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_hash_map.hash_map_new$instance$0e108827ecbbe374
lCPI60_0:
	.quad	0                               ; 0x0
	.quad	-9187201950435737472            ; 0x8080808080808080
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_hash_map.hash_map_new$instance$0e108827ecbbe374
	.p2align	2
_wf_hash_map.hash_map_new$instance$0e108827ecbbe374: ; @"wf_hash_map.hash_map_new$instance$0e108827ecbbe374"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x1
	mov	x19, x0
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	madd	x0, x1, x8, x9
	bl	_malloc
	cbz	x0, LBB60_9
; %bb.1:                                ; %bb1.i
	stp	xzr, x20, [x0]
	cbz	x20, LBB60_7
; %bb.2:                                ; %bb5.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
	movi.2d	v0, #0000000000000000
LBB60_3:                                ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	q0, q0, [x9]
	stp	q0, q0, [x9, #32]
	stp	q0, q0, [x9, #64]
	stp	q0, q0, [x9, #96]
	stp	q0, q0, [x9, #128]
	stp	q0, q0, [x9, #160]
	stp	q0, q0, [x9, #192]
	stp	q0, q0, [x9, #224]
	str	xzr, [x9, #256]
	add	x9, x9, #272
	cmp	x20, x8
	b.ne	LBB60_3
; %bb.4:                                ; %"wf_hash_map.hash_map_extend$instance$0e108827ecbbe374.exit"
	str	x20, [x0]
	cmp	x20, #9
	b.lo	LBB60_7
; %bb.5:                                ; %bb2.i.i
	mov	x23, x0
	and	x22, x20, #0xfffffffffffffff8
	add	x0, x22, #8
	bl	_malloc
	cbz	x0, LBB60_9
; %bb.6:                                ; %buffer.fill.init.v2.i.i.i
	mov	x21, x0
	lsr	x8, x20, #3
	str	x8, [x0], #8
	mov	w1, #128                        ; =0x80
	mov	x2, x22
	bl	_memset
	mov	w8, #1                          ; =0x1
	mov	x0, x23
	b	LBB60_8
LBB60_7:
	mov	x21, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
LBB60_8:                                ; %"wf_hash_map.hash_map_controls_new$instance$fd5e04af5c7e1250.exit"
	str	x0, [x19]
Lloh212:
	adrp	x9, lCPI60_0@PAGE
Lloh213:
	ldr	q0, [x9, lCPI60_0@PAGEOFF]
	stur	q0, [x19, #8]
	stp	x8, x21, [x19, #24]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB60_9:                                ; %window.block.oom.v1.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh212, Lloh213
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_put$instance$28da32efc51c2b65 ; -- Begin function wf_hash_map.hash_map_put$instance$28da32efc51c2b65
	.p2align	2
_wf_hash_map.hash_map_put$instance$28da32efc51c2b65: ; @"wf_hash_map.hash_map_put$instance$28da32efc51c2b65"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #1056
	.cfi_def_cfa_offset 1136
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	mov	x20, x4
	mov	x21, x1
	mov	x19, x0
	ldp	q0, q1, [x3, #192]
	mov	x22, sp
	stp	q0, q1, [sp, #192]
	ldp	q0, q1, [x3, #224]
	stp	q0, q1, [sp, #224]
	ldp	q0, q1, [x3, #128]
	stp	q0, q1, [sp, #128]
	ldp	q0, q1, [x3, #160]
	stp	q0, q1, [sp, #160]
	ldp	q0, q1, [x3, #64]
	stp	q0, q1, [sp, #64]
	ldp	q0, q1, [x3, #96]
	stp	q0, q1, [sp, #96]
	ldp	q0, q1, [x3]
	stp	q0, q1, [sp]
	ldp	q0, q1, [x3, #32]
	stp	q0, q1, [sp, #32]
	add	x0, x22, #256
	mov	x3, sp
	bl	_wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65
	ldr	w8, [sp, #256]
	cbz	w8, LBB61_5
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB61_12
; %bb.2:                                ; %bb2
	mov	x23, sp
	ldrb	w24, [sp, #260]
	add	x0, x22, #528
	add	x1, x23, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	tbz	w24, #0, LBB61_6
; %bb.3:                                ; %bb4
	ldr	x8, [x21]
	ldr	x8, [x8]
	cmp	x8, #4, lsl #12                 ; =16384
	b.lo	LBB61_9
LBB61_4:                                ; %bb6
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	strb	w8, [x19, #4]
	add	x0, x19, #8
	add	x1, x23, #264
	b	LBB61_7
LBB61_5:                                ; %bb1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #240]
	stp	q0, q0, [x19, #208]
	stp	q0, q0, [x19, #176]
	stp	q0, q0, [x19, #144]
	stp	q0, q0, [x19, #112]
	stp	q0, q0, [x19, #80]
	stp	q0, q0, [x19, #48]
	stp	q0, q0, [x19, #16]
	str	q0, [x19]
	b	LBB61_8
LBB61_6:                                ; %bb3
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19], #8
	add	x1, x23, #264
	mov	x0, x19
LBB61_7:                                ; %common.ret
	mov	w2, #264                        ; =0x108
	bl	_memcpy
LBB61_8:                                ; %common.ret
	add	sp, sp, #1056
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
LBB61_9:                                ; %bb7
	mov	w9, #8192                       ; =0x2000
	cmp	x8, #2, lsl #12                 ; =8192
	csel	x9, x8, x9, lo
	lsl	x9, x9, #1
	cmp	x8, #0
	csinc	x1, x9, xzr, ne
	cmp	x1, x8
	b.ls	LBB61_13
; %bb.10:                               ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit"
	mov	x0, x21
	mov	x2, x20
	bl	_wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	str	w0, [sp, #792]
	strb	w1, [sp, #796]
	strb	w2, [sp, #797]
	cbz	w0, LBB61_14
; %bb.11:                               ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit"
	cmp	w0, #1
	b.eq	LBB61_4
LBB61_12:                               ; %invalid.tag.b0
	bl	_abort
LBB61_13:                               ; %"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.thread"
	str	wzr, [sp, #792]
	strh	wzr, [sp, #796]
LBB61_14:                               ; %bb17
	add	x3, x22, #800
	ldr	x2, [sp, #528]
	mov	x8, sp
	add	x8, x8, #536
	ldp	q0, q1, [x8, #192]
	stp	q0, q1, [x3, #192]
	ldp	q0, q1, [x8, #224]
	stp	q0, q1, [x3, #224]
	ldp	q0, q1, [x8, #128]
	stp	q0, q1, [x3, #128]
	ldp	q0, q1, [x8, #160]
	stp	q0, q1, [x3, #160]
	ldp	q0, q1, [x8, #64]
	stp	q0, q1, [x3, #64]
	ldp	q0, q1, [x8, #96]
	stp	q0, q1, [x3, #96]
	ldp	q0, q1, [x8]
	stp	q0, q1, [x3]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x3, #32]
	mov	x0, x19
	mov	x1, x21
	mov	x4, x20
	bl	_wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65
	b	LBB61_8
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_remove$instance$28da32efc51c2b65 ; -- Begin function wf_hash_map.hash_map_remove$instance$28da32efc51c2b65
	.p2align	2
_wf_hash_map.hash_map_remove$instance$28da32efc51c2b65: ; @"wf_hash_map.hash_map_remove$instance$28da32efc51c2b65"
; %bb.0:                                ; %entry
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	mov	x19, x0
	ldr	x21, [x1, #8]
	cbz	x21, LBB62_12
; %bb.1:                                ; %bb3
	mov	x20, x1
	mov	x0, x1
	mov	x1, x2
	mov	x2, x3
	bl	_wf_hash_map.hash_map_find$instance$28da32efc51c2b65
	cmp	w0, #1
	b.eq	LBB62_12
; %bb.2:                                ; %bb3
	cbnz	w0, LBB62_14
; %bb.3:                                ; %bb4
	ldr	x8, [x20]
	mov	w9, #272                        ; =0x110
	madd	x12, x1, x9, x8
	ldr	w9, [x12, #16]!
	ldur	q0, [x12, #8]
	ldur	q1, [x12, #24]
	ldur	q2, [x12, #40]
	ldur	q3, [x12, #56]
	ldur	q4, [x12, #72]
	ldur	q5, [x12, #88]
	ldur	q6, [x12, #104]
	ldur	q7, [x12, #120]
	ldur	q16, [x12, #136]
	ldur	q17, [x12, #152]
	ldur	q18, [x12, #168]
	ldur	q19, [x12, #184]
	ldur	q20, [x12, #200]
	ldur	q21, [x12, #216]
	ldur	q22, [x12, #232]
	ldur	q23, [x12, #248]
	ldr	x8, [x12, #264]
	mov	w10, #1                         ; =0x1
	str	w10, [x12]
	ubfiz	x11, x1, #3, #3
	mov	w10, #255                       ; =0xff
	lsl	x10, x10, x11
	mvn	x10, x10
	mov	w13, #254                       ; =0xfe
	lsl	x11, x13, x11
	movi.2d	v24, #0000000000000000
	stur	q24, [x12, #8]
	stur	q24, [x12, #24]
	stur	q24, [x12, #40]
	stur	q24, [x12, #56]
	stur	q24, [x12, #72]
	stur	q24, [x12, #88]
	stur	q24, [x12, #104]
	stur	q24, [x12, #120]
	stur	q24, [x12, #136]
	stur	q24, [x12, #152]
	stur	q24, [x12, #168]
	stur	q24, [x12, #184]
	stur	q24, [x12, #200]
	stur	q24, [x12, #216]
	stur	q24, [x12, #232]
	stur	q24, [x12, #248]
	str	xzr, [x12, #264]
	ldr	x12, [x20, #24]
	cbz	x12, LBB62_6
; %bb.4:                                ; %bb3.i
	lsr	x12, x1, #3
	ldr	x13, [x20, #32]
	ldr	x14, [x13]
	cmp	x12, x14
	b.hs	LBB62_13
; %bb.5:                                ; %bb8.i
	add	x12, x13, x12, lsl #3
	ldr	x13, [x12, #8]
	and	x10, x13, x10
	orr	x10, x10, x11
	str	x10, [x12, #8]
	b	LBB62_8
LBB62_6:                                ; %bb2.i
	cmp	x1, #8
	b.hs	LBB62_8
LBB62_7:                                ; %bb11.i
	ldr	x12, [x20, #16]
	and	x10, x12, x10
	orr	x10, x10, x11
	str	x10, [x20, #16]
LBB62_8:                                ; %wf_hash_map.hash_map_control_set.exit
	cbz	w9, LBB62_12
; %bb.9:                                ; %wf_hash_map.hash_map_control_set.exit
	cmp	w9, #1
	b.eq	LBB62_12
; %bb.10:                               ; %wf_hash_map.hash_map_control_set.exit
	cmp	w9, #2
	b.ne	LBB62_14
; %bb.11:                               ; %bb6
	sub	x9, x21, #1
	str	x9, [x20, #8]
	str	xzr, [x19]
	mov	w9, #1                          ; =0x1
	str	w9, [x19]
	stur	q0, [x19, #8]
	stur	q1, [x19, #24]
	stur	q2, [x19, #40]
	stur	q3, [x19, #56]
	stur	q4, [x19, #72]
	stur	q5, [x19, #88]
	stur	q6, [x19, #104]
	stur	q7, [x19, #120]
	stur	q16, [x19, #136]
	stur	q17, [x19, #152]
	stur	q18, [x19, #168]
	stur	q19, [x19, #184]
	stur	q20, [x19, #200]
	stur	q21, [x19, #216]
	stur	q22, [x19, #232]
	stur	q23, [x19, #248]
	str	x8, [x19, #264]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB62_12:                               ; %bb2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #240]
	stp	q0, q0, [x19, #208]
	stp	q0, q0, [x19, #176]
	stp	q0, q0, [x19, #144]
	stp	q0, q0, [x19, #112]
	stp	q0, q0, [x19, #80]
	stp	q0, q0, [x19, #48]
	stp	q0, q0, [x19, #16]
	str	q0, [x19]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB62_13:                               ; %bb9.i
	b.eq	LBB62_7
	b	LBB62_8
LBB62_14:                               ; %invalid.tag.b1
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_lookup$instance$000400fb603e42fe ; -- Begin function wf_hash_map.hash_map_lookup$instance$000400fb603e42fe
	.p2align	2
_wf_hash_map.hash_map_lookup$instance$000400fb603e42fe: ; @"wf_hash_map.hash_map_lookup$instance$000400fb603e42fe"
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	mov	x19, x0
	bl	_wf_hash_map.hash_map_find$instance$28da32efc51c2b65
	cbz	w0, LBB63_3
; %bb.1:                                ; %entry
	cmp	w0, #1
	b.ne	LBB63_7
; %bb.2:
	mov	x1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB63_3:                                ; %bb1.i
	ldr	x8, [x19]
	mov	w9, #272                        ; =0x110
	madd	x8, x1, x9, x8
	ldr	w9, [x8, #16]!
	cmp	w9, #2
	b.hs	LBB63_5
; %bb.4:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB63_5:                                ; %bb1.i
	b.ne	LBB63_7
; %bb.6:                                ; %bb3.i
	mov	w0, #0                          ; =0x0
	ldr	x1, [x8, #16]
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB63_7:                                ; %invalid.tag.b0.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_rehash$instance$28da32efc51c2b65 ; -- Begin function wf_hash_map.hash_map_rehash$instance$28da32efc51c2b65
	.p2align	2
_wf_hash_map.hash_map_rehash$instance$28da32efc51c2b65: ; @"wf_hash_map.hash_map_rehash$instance$28da32efc51c2b65"
	.cfi_startproc
; %bb.0:                                ; %entry
	mov	x2, x1
	ldr	x8, [x0]
	ldr	x1, [x8]
	b	_wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65 ; -- Begin function wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65
	.p2align	2
_wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65: ; @"wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65"
	.cfi_startproc
; %bb.0:                                ; %entry
	cmp	x1, #4, lsl #12                 ; =16384
	b.ls	LBB65_2
; %bb.1:
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	ret
LBB65_2:                                ; %bb3.i
	ldr	x8, [x0]
	ldr	x8, [x8]
	cmp	x1, x8
	b.ls	LBB65_4
; %bb.3:                                ; %bb6.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB65_4:
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_capacity$instance$0e108827ecbbe374 ; -- Begin function wf_hash_map.hash_map_capacity$instance$0e108827ecbbe374
	.p2align	2
_wf_hash_map.hash_map_capacity$instance$0e108827ecbbe374: ; @"wf_hash_map.hash_map_capacity$instance$0e108827ecbbe374"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x0, [x8]
	ret
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_edit$instance$ec3fd08e444cbe49 ; -- Begin function wf_hash_map.hash_map_edit$instance$ec3fd08e444cbe49
	.p2align	2
_wf_hash_map.hash_map_edit$instance$ec3fd08e444cbe49: ; @"wf_hash_map.hash_map_edit$instance$ec3fd08e444cbe49"
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	mov	x19, x0
	bl	_wf_hash_map.hash_map_find$instance$28da32efc51c2b65
	cbz	w0, LBB67_3
; %bb.1:                                ; %entry
	cmp	w0, #1
	b.ne	LBB67_7
; %bb.2:
	mov	x1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB67_3:                                ; %bb1.i
	ldr	x8, [x19]
	mov	w9, #272                        ; =0x110
	madd	x8, x1, x9, x8
	ldr	w9, [x8, #16]!
	cmp	w9, #2
	b.hs	LBB67_5
; %bb.4:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB67_5:                                ; %bb1.i
	b.ne	LBB67_7
; %bb.6:                                ; %bb3.i
	mov	w0, #0                          ; =0x0
	ldr	x9, [x8, #16]
	add	x1, x9, #1
	str	x1, [x8, #16]
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB67_7:                                ; %invalid.tag.b0.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_free$instance$d5f8785ab7665d71 ; -- Begin function wf_hash_map.hash_map_free$instance$d5f8785ab7665d71
	.p2align	2
_wf_hash_map.hash_map_free$instance$d5f8785ab7665d71: ; @"wf_hash_map.hash_map_free$instance$d5f8785ab7665d71"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	mov	x8, x0
	ldr	x0, [x0]
	ldp	x19, x20, [x8, #24]
	ldr	x11, [x0]
	cbz	x11, LBB68_7
; %bb.1:                                ; %bb5.lr.ph
	ldp	x8, x9, [x1, #8]
	sub	x10, x11, #1
	mov	w12, #272                       ; =0x110
	madd	x12, x11, x12, x0
	ldr	x11, [x1, #24]
	sub	x12, x12, #120
	mov	w13, #131                       ; =0x83
	mov	x14, #58809                     ; =0xe5b9
	movk	x14, #7396, lsl #16
	movk	x14, #18285, lsl #32
	movk	x14, #48984, lsl #48
	mov	x15, #4587                      ; =0x11eb
	movk	x15, #4913, lsl #16
	movk	x15, #18875, lsl #32
	movk	x15, #38096, lsl #48
	b	LBB68_4
LBB68_2:                                ; %bb7
                                        ;   in Loop: Header=BB68_4 Depth=1
	ldp	x17, x16, [x12, #-128]
	madd	x16, x17, x13, x16
	ldur	x17, [x12, #-112]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-104]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-96]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-88]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-80]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-72]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-64]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-56]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-48]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-40]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-32]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-24]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-16]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-8]
	madd	x16, x16, x13, x17
	ldr	x17, [x12]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #8]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #16]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #24]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #32]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #40]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #48]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #56]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #64]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #72]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #80]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #88]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #96]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #104]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #112]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #120]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #128]
	madd	x16, x16, x13, x17
	add	x8, x16, x8
	eor	x16, x16, x16, lsr #30
	mul	x16, x16, x14
	eor	x16, x16, x16, lsr #27
	mul	x16, x16, x15
	eor	x9, x9, x16, lsr #31
	eor	x9, x9, x16
	stp	x8, x9, [x1, #8]
	add	x11, x11, #1
	str	x11, [x1, #24]
LBB68_3:                                ; %bb6
                                        ;   in Loop: Header=BB68_4 Depth=1
	sub	x10, x10, #1
	sub	x12, x12, #272
	cmn	x10, #1
	b.eq	LBB68_7
LBB68_4:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	str	x10, [x0]
	ldur	w16, [x12, #-136]
	cmp	w16, #2
	b.lo	LBB68_3
; %bb.5:                                ; %bb5
                                        ;   in Loop: Header=BB68_4 Depth=1
	b.eq	LBB68_2
; %bb.6:                                ; %invalid.tag.b3
	bl	_abort
LBB68_7:                                ; %bb4
	bl	_free
	stp	x19, x20, [sp]
	cbz	x19, LBB68_10
; %bb.8:                                ; %body.i.preheader
	mov	x20, #0                         ; =0x0
	mov	x8, sp
	add	x21, x8, #8
LBB68_9:                                ; %body.i
                                        ; =>This Inner Loop Header: Depth=1
	cmp	x20, #1
	csinc	x8, x20, xzr, lo
	sub	x8, x21, x8, lsl #3
	ldr	x0, [x8]
	bl	_free
	add	x20, x20, #1
	add	x21, x21, #8
	subs	x19, x19, #1
	b.ne	LBB68_9
LBB68_10:                               ; %wf.drop.run.707f874ef98d2803.exit
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_len$instance$820b2044b97e0fbd ; -- Begin function wf_hash_map.hash_map_len$instance$820b2044b97e0fbd
	.p2align	2
_wf_hash_map.hash_map_len$instance$820b2044b97e0fbd: ; @"wf_hash_map.hash_map_len$instance$820b2044b97e0fbd"
; %bb.0:                                ; %entry
	ldr	x0, [x0, #8]
	ret
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_len$instance$0e108827ecbbe374 ; -- Begin function wf_hash_map.hash_map_len$instance$0e108827ecbbe374
	.p2align	2
_wf_hash_map.hash_map_len$instance$0e108827ecbbe374: ; @"wf_hash_map.hash_map_len$instance$0e108827ecbbe374"
; %bb.0:                                ; %entry
	ldr	x0, [x0, #8]
	ret
                                        ; -- End function
	.globl	_wf_box_slots_new$instance$087f541e70b769ea ; -- Begin function wf_box_slots_new$instance$087f541e70b769ea
	.p2align	2
_wf_box_slots_new$instance$087f541e70b769ea: ; @"wf_box_slots_new$instance$087f541e70b769ea"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB71_2
; %bb.1:                                ; %window.block.ready.v1
	stp	xzr, x19, [x0]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB71_2:                                ; %window.block.oom.v1
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_extend$instance$a62a753cf2b0b5ca ; -- Begin function wf_hash_map.hash_map_extend$instance$a62a753cf2b0b5ca
	.p2align	2
_wf_hash_map.hash_map_extend$instance$a62a753cf2b0b5ca: ; @"wf_hash_map.hash_map_extend$instance$a62a753cf2b0b5ca"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x1
	ldr	x20, [x0]
	ldr	x8, [x20, #8]
	cmp	x8, x1
	b.hs	LBB72_4
; %bb.1:                                ; %bb2
	mov	x21, x0
	ldr	x23, [x20]
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	madd	x0, x19, x8, x9
	bl	_malloc
	cbz	x0, LBB72_8
; %bb.2:                                ; %"wf_grow$instance$087f541e70b769ea.exit"
	mov	x22, x0
	stp	x23, x19, [x0], #16
	add	x8, x23, x23, lsl #1
	lsl	x2, x8, #3
	add	x1, x20, #16
	bl	_memmove
	mov	x0, x20
	bl	_free
	str	x22, [x21]
	mov	x20, x22
	cmp	x23, x19
	b.lo	LBB72_5
LBB72_3:                                ; %bb7
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB72_4:                                ; %entry.bb1_crit_edge
	ldr	x23, [x20]
	cmp	x23, x19
	b.hs	LBB72_3
LBB72_5:                                ; %bb5.preheader
	mov	w8, #24                         ; =0x18
	madd	x8, x23, x8, x20
	add	x8, x8, #24
LBB72_6:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x8, #-8]
	add	x23, x23, #1
	stp	xzr, xzr, [x8], #24
	cmp	x19, x23
	b.ne	LBB72_6
; %bb.7:                                ; %bb4.bb7_crit_edge
	str	x23, [x20]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB72_8:                                ; %window.block.oom.v2.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_controls_new$instance$c559014c068e16a3 ; -- Begin function wf_hash_map.hash_map_controls_new$instance$c559014c068e16a3
	.p2align	2
_wf_hash_map.hash_map_controls_new$instance$c559014c068e16a3: ; @"wf_hash_map.hash_map_controls_new$instance$c559014c068e16a3"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	cmp	x0, #9
	b.lo	LBB73_3
; %bb.1:                                ; %bb2.i
	mov	x21, x0
	and	x20, x0, #0xfffffffffffffff8
	add	x0, x20, #8
	bl	_malloc
	cbz	x0, LBB73_4
; %bb.2:                                ; %buffer.fill.init.v2.i.i
	mov	x19, x0
	lsr	x8, x21, #3
	str	x8, [x0], #8
	mov	w1, #128                        ; =0x80
	mov	x2, x20
	bl	_memset
	mov	w1, #1                          ; =0x1
	mov	x0, #-9187201950435737472       ; =0x8080808080808080
	mov	x2, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB73_3:
	mov	x19, #0                         ; =0x0
	mov	x1, #0                          ; =0x0
	mov	x0, #-9187201950435737472       ; =0x8080808080808080
	mov	x2, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB73_4:                                ; %buffer.fill.oom.v2.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_try_put$instance$c7b22b9ef52855b6 ; -- Begin function wf_hash_map.hash_map_try_put$instance$c7b22b9ef52855b6
	.p2align	2
_wf_hash_map.hash_map_try_put$instance$c7b22b9ef52855b6: ; @"wf_hash_map.hash_map_try_put$instance$c7b22b9ef52855b6"
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	ldrb	w8, [x4, #8]
	tbz	w8, #0, LBB74_81
; %bb.1:
	mov	x9, #0                          ; =0x0
	lsr	x8, x9, #57
	ldr	x10, [x1]
	ldr	x12, [x10]
	cbz	x12, LBB74_82
LBB74_2:                                ; %bb2
	udiv	x11, x9, x12
	msub	x14, x11, x12, x9
	mov	x9, #72340172838076673          ; =0x101010101010101
	mul	x15, x8, x9
	mov	w16, #1                         ; =0x1
	mov	w17, #8                         ; =0x8
	mov	x4, #-9187201950435737472       ; =0x8080808080808080
	ldp	x11, x13, [x1, #16]
	mov	x5, #9187201950435737471        ; =0x7f7f7f7f7f7f7f7f
	mov	w6, #24                         ; =0x18
	mov	x7, x12
	mov	x9, x12
LBB74_3:                                ; %bb10
                                        ; =>This Inner Loop Header: Depth=1
	and	x21, x14, #0x7
	sub	x19, x12, x14
	sub	x20, x17, x21
	cmp	x20, x19
	csel	x19, x20, x19, lo
	cmp	x19, x7
	csel	x19, x19, x7, lo
	cbz	x13, LBB74_6
; %bb.4:                                ; %bb3.i42
                                        ;   in Loop: Header=BB74_3 Depth=1
	lsr	x20, x14, #3
	ldr	x22, [x1, #32]
	ldr	x23, [x22]
	cmp	x20, x23
	b.hs	LBB74_7
; %bb.5:                                ; %bb8.i
                                        ;   in Loop: Header=BB74_3 Depth=1
	add	x20, x22, x20, lsl #3
	ldr	x22, [x20, #8]
	b	LBB74_8
LBB74_6:                                ; %bb2.i
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	x14, #8
	csel	x22, x11, x4, lo
	b	LBB74_8
LBB74_7:                                ; %bb9.i
                                        ;   in Loop: Header=BB74_3 Depth=1
	csel	x22, x11, x4, eq
LBB74_8:                                ; %wf_hash_map.hash_map_control_word.exit
                                        ;   in Loop: Header=BB74_3 Depth=1
	lsl	x20, x19, #3
	neg	x20, x20
	lsr	x20, x4, x20
	lsl	x23, x21, #3
	lsl	x23, x20, x23
	and	x20, x22, #0x7f7f7f7f7f7f7f7f
	add	x20, x20, x5
	orn	x20, x20, x22
	eor	x24, x20, #0x8080808080808080
	ands	x20, x24, x23
	b.eq	LBB74_60
; %bb.9:                                ; %bb2.i63
                                        ;   in Loop: Header=BB74_3 Depth=1
	rbit	x20, x20
	clz	x20, x20
	lsr	x20, x20, #3
	sub	x25, x20, x21
	cmp	x25, x19
	csel	x25, x25, x19, lo
	cmp	x20, x21
	csel	x20, x19, x25, lo
	cmp	x9, x12
	b.ne	LBB74_11
LBB74_10:                               ; %wf_hash_map.hash_map_control_stop.exit
                                        ;   in Loop: Header=BB74_3 Depth=1
	eor	x25, x22, #0xfefefefefefefefe
	and	x26, x25, #0x7f7f7f7f7f7f7f7f
	add	x26, x26, x5
	orr	x25, x26, x25
	orn	x24, x24, x25
	and	x24, x24, x23
	rbit	x25, x24
	clz	x25, x25
	lsr	x25, x25, #3
	sub	x26, x25, x21
	add	x27, x26, x14
	cmp	x26, x19
	csel	x26, x27, x12, lo
	cmp	x25, x21
	csel	x25, x12, x26, lo
	cmp	x24, #0
	csel	x9, x25, x9, ne
LBB74_11:                               ; %bb11
                                        ;   in Loop: Header=BB74_3 Depth=1
	eor	x22, x22, x15
	and	x24, x22, #0x7f7f7f7f7f7f7f7f
	add	x24, x24, x5
	orr	x22, x24, x22
	bic	x24, x23, x22
	cbz	x24, LBB74_63
; %bb.12:                               ; %bb29
                                        ;   in Loop: Header=BB74_3 Depth=1
	rbit	x22, x24
	clz	x22, x22
	lsr	x22, x22, #3
	subs	x25, x22, x21
	b.lo	LBB74_18
; %bb.13:                               ; %bb31
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	x25, x20
	b.hs	LBB74_18
; %bb.14:                               ; %bb34
                                        ;   in Loop: Header=BB74_3 Depth=1
	add	x22, x25, x14
	madd	x23, x22, x6, x10
	ldr	w26, [x23, #16]!
	cbz	w26, LBB74_61
; %bb.15:                               ; %bb34
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	w26, #1
	b.eq	LBB74_66
; %bb.16:                               ; %bb34
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	w26, #2
	b.ne	LBB74_106
; %bb.17:                               ; %bb3.i70
                                        ;   in Loop: Header=BB74_3 Depth=1
	ldr	x25, [x23, #8]
	cmp	x25, x2
	b.eq	LBB74_100
LBB74_18:                               ; %bb47
                                        ;   in Loop: Header=BB74_3 Depth=1
	sub	x22, x24, #1
	and	x24, x22, x24
	cbz	x24, LBB74_63
LBB74_19:                               ; %bb29.1
                                        ;   in Loop: Header=BB74_3 Depth=1
	rbit	x22, x24
	clz	x22, x22
	lsr	x22, x22, #3
	subs	x25, x22, x21
	b.lo	LBB74_25
; %bb.20:                               ; %bb31.1
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	x25, x20
	b.hs	LBB74_25
; %bb.21:                               ; %bb34.1
                                        ;   in Loop: Header=BB74_3 Depth=1
	add	x22, x25, x14
	madd	x23, x22, x6, x10
	ldr	w26, [x23, #16]!
	cbz	w26, LBB74_61
; %bb.22:                               ; %bb34.1
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	w26, #1
	b.eq	LBB74_67
; %bb.23:                               ; %bb34.1
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	w26, #2
	b.ne	LBB74_106
; %bb.24:                               ; %bb3.i70.1
                                        ;   in Loop: Header=BB74_3 Depth=1
	ldr	x25, [x23, #8]
	cmp	x25, x2
	b.eq	LBB74_100
LBB74_25:                               ; %bb47.1
                                        ;   in Loop: Header=BB74_3 Depth=1
	sub	x22, x24, #1
	and	x24, x22, x24
	cbz	x24, LBB74_63
LBB74_26:                               ; %bb29.2
                                        ;   in Loop: Header=BB74_3 Depth=1
	rbit	x22, x24
	clz	x22, x22
	lsr	x22, x22, #3
	subs	x25, x22, x21
	b.lo	LBB74_32
; %bb.27:                               ; %bb31.2
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	x25, x20
	b.hs	LBB74_32
; %bb.28:                               ; %bb34.2
                                        ;   in Loop: Header=BB74_3 Depth=1
	add	x22, x25, x14
	madd	x23, x22, x6, x10
	ldr	w26, [x23, #16]!
	cbz	w26, LBB74_61
; %bb.29:                               ; %bb34.2
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	w26, #1
	b.eq	LBB74_68
; %bb.30:                               ; %bb34.2
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	w26, #2
	b.ne	LBB74_106
; %bb.31:                               ; %bb3.i70.2
                                        ;   in Loop: Header=BB74_3 Depth=1
	ldr	x25, [x23, #8]
	cmp	x25, x2
	b.eq	LBB74_100
LBB74_32:                               ; %bb47.2
                                        ;   in Loop: Header=BB74_3 Depth=1
	sub	x22, x24, #1
	and	x24, x22, x24
	cbz	x24, LBB74_63
LBB74_33:                               ; %bb29.3
                                        ;   in Loop: Header=BB74_3 Depth=1
	rbit	x22, x24
	clz	x22, x22
	lsr	x22, x22, #3
	subs	x25, x22, x21
	b.lo	LBB74_39
; %bb.34:                               ; %bb31.3
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	x25, x20
	b.hs	LBB74_39
; %bb.35:                               ; %bb34.3
                                        ;   in Loop: Header=BB74_3 Depth=1
	add	x22, x25, x14
	madd	x23, x22, x6, x10
	ldr	w26, [x23, #16]!
	cbz	w26, LBB74_61
; %bb.36:                               ; %bb34.3
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	w26, #1
	b.eq	LBB74_69
; %bb.37:                               ; %bb34.3
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	w26, #2
	b.ne	LBB74_106
; %bb.38:                               ; %bb3.i70.3
                                        ;   in Loop: Header=BB74_3 Depth=1
	ldr	x25, [x23, #8]
	cmp	x25, x2
	b.eq	LBB74_100
LBB74_39:                               ; %bb47.3
                                        ;   in Loop: Header=BB74_3 Depth=1
	sub	x22, x24, #1
	and	x24, x22, x24
	cbz	x24, LBB74_63
LBB74_40:                               ; %bb29.4
                                        ;   in Loop: Header=BB74_3 Depth=1
	rbit	x22, x24
	clz	x22, x22
	lsr	x22, x22, #3
	subs	x25, x22, x21
	b.lo	LBB74_46
; %bb.41:                               ; %bb31.4
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	x25, x20
	b.hs	LBB74_46
; %bb.42:                               ; %bb34.4
                                        ;   in Loop: Header=BB74_3 Depth=1
	add	x22, x25, x14
	madd	x23, x22, x6, x10
	ldr	w26, [x23, #16]!
	cbz	w26, LBB74_61
; %bb.43:                               ; %bb34.4
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	w26, #1
	b.eq	LBB74_70
; %bb.44:                               ; %bb34.4
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	w26, #2
	b.ne	LBB74_106
; %bb.45:                               ; %bb3.i70.4
                                        ;   in Loop: Header=BB74_3 Depth=1
	ldr	x25, [x23, #8]
	cmp	x25, x2
	b.eq	LBB74_100
LBB74_46:                               ; %bb47.4
                                        ;   in Loop: Header=BB74_3 Depth=1
	sub	x22, x24, #1
	and	x24, x22, x24
	cbz	x24, LBB74_63
LBB74_47:                               ; %bb29.5
                                        ;   in Loop: Header=BB74_3 Depth=1
	rbit	x22, x24
	clz	x22, x22
	lsr	x22, x22, #3
	subs	x25, x22, x21
	b.lo	LBB74_53
; %bb.48:                               ; %bb31.5
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	x25, x20
	b.hs	LBB74_53
; %bb.49:                               ; %bb34.5
                                        ;   in Loop: Header=BB74_3 Depth=1
	add	x22, x25, x14
	madd	x23, x22, x6, x10
	ldr	w26, [x23, #16]!
	cbz	w26, LBB74_61
; %bb.50:                               ; %bb34.5
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	w26, #1
	b.eq	LBB74_71
; %bb.51:                               ; %bb34.5
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	w26, #2
	b.ne	LBB74_106
; %bb.52:                               ; %bb3.i70.5
                                        ;   in Loop: Header=BB74_3 Depth=1
	ldr	x25, [x23, #8]
	cmp	x25, x2
	b.eq	LBB74_100
LBB74_53:                               ; %bb47.5
                                        ;   in Loop: Header=BB74_3 Depth=1
	sub	x22, x24, #1
	and	x24, x22, x24
	cbz	x24, LBB74_63
LBB74_54:                               ; %bb29.6
                                        ;   in Loop: Header=BB74_3 Depth=1
	rbit	x22, x24
	clz	x22, x22
	lsr	x22, x22, #3
	subs	x25, x22, x21
	b.lo	LBB74_73
; %bb.55:                               ; %bb31.6
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	x25, x20
	b.hs	LBB74_73
; %bb.56:                               ; %bb34.6
                                        ;   in Loop: Header=BB74_3 Depth=1
	add	x22, x25, x14
	madd	x23, x22, x6, x10
	ldr	w26, [x23, #16]!
	cbz	w26, LBB74_61
; %bb.57:                               ; %bb34.6
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	w26, #1
	b.eq	LBB74_72
; %bb.58:                               ; %bb34.6
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	w26, #2
	b.ne	LBB74_106
; %bb.59:                               ; %bb3.i70.6
                                        ;   in Loop: Header=BB74_3 Depth=1
	ldr	x25, [x23, #8]
	cmp	x25, x2
	b.ne	LBB74_73
	b	LBB74_100
LBB74_60:                               ;   in Loop: Header=BB74_3 Depth=1
	mov	x20, x19
	cmp	x9, x12
	b.eq	LBB74_10
	b	LBB74_11
LBB74_61:                               ;   in Loop: Header=BB74_3 Depth=1
	mov	x20, x25
LBB74_62:                               ; %bb38
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	x9, x12
	csel	x9, x22, x9, eq
LBB74_63:                               ; %bb26
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	x20, x19
	b.lo	LBB74_83
; %bb.64:                               ; %bb50
                                        ;   in Loop: Header=BB74_3 Depth=1
	add	x14, x19, x14
	cmp	x14, x12
	csel	x14, x14, xzr, lo
	cmp	x16, x12
	b.hs	LBB74_83
; %bb.65:                               ; %bb50
                                        ;   in Loop: Header=BB74_3 Depth=1
	add	x16, x16, #1
	sub	x7, x7, x19
	cbnz	x7, LBB74_3
	b	LBB74_83
LBB74_66:                               ; %bb39
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	x9, x12
	csel	x9, x22, x9, eq
	sub	x22, x24, #1
	and	x24, x22, x24
	cbnz	x24, LBB74_19
	b	LBB74_63
LBB74_67:                               ; %bb39.1
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	x9, x12
	csel	x9, x22, x9, eq
	sub	x22, x24, #1
	and	x24, x22, x24
	cbnz	x24, LBB74_26
	b	LBB74_63
LBB74_68:                               ; %bb39.2
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	x9, x12
	csel	x9, x22, x9, eq
	sub	x22, x24, #1
	and	x24, x22, x24
	cbnz	x24, LBB74_33
	b	LBB74_63
LBB74_69:                               ; %bb39.3
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	x9, x12
	csel	x9, x22, x9, eq
	sub	x22, x24, #1
	and	x24, x22, x24
	cbnz	x24, LBB74_40
	b	LBB74_63
LBB74_70:                               ; %bb39.4
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	x9, x12
	csel	x9, x22, x9, eq
	sub	x22, x24, #1
	and	x24, x22, x24
	cbnz	x24, LBB74_47
	b	LBB74_63
LBB74_71:                               ; %bb39.5
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	x9, x12
	csel	x9, x22, x9, eq
	sub	x22, x24, #1
	and	x24, x22, x24
	cbnz	x24, LBB74_54
	b	LBB74_63
LBB74_72:                               ; %bb39.6
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	x9, x12
	csel	x9, x22, x9, eq
LBB74_73:                               ; %bb47.6
                                        ;   in Loop: Header=BB74_3 Depth=1
	sub	x22, x24, #1
	and	x22, x22, x24
	cbz	x22, LBB74_63
; %bb.74:                               ; %bb29.7
                                        ;   in Loop: Header=BB74_3 Depth=1
	rbit	x22, x22
	clz	x22, x22
	lsr	x22, x22, #3
	subs	x21, x22, x21
	b.lo	LBB74_63
; %bb.75:                               ; %bb31.7
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	x21, x20
	b.hs	LBB74_63
; %bb.76:                               ; %bb34.7
                                        ;   in Loop: Header=BB74_3 Depth=1
	add	x22, x21, x14
	madd	x23, x22, x6, x10
	ldr	w24, [x23, #16]!
	cbz	w24, LBB74_80
; %bb.77:                               ; %bb34.7
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	w24, #1
	b.eq	LBB74_62
; %bb.78:                               ; %bb34.7
                                        ;   in Loop: Header=BB74_3 Depth=1
	cmp	w24, #2
	b.ne	LBB74_106
; %bb.79:                               ; %bb3.i70.7
                                        ;   in Loop: Header=BB74_3 Depth=1
	ldr	x21, [x23, #8]
	cmp	x21, x2
	b.ne	LBB74_63
	b	LBB74_100
LBB74_80:                               ;   in Loop: Header=BB74_3 Depth=1
	mov	x20, x21
	b	LBB74_62
LBB74_81:                               ; %bb3.i
	ldr	x8, [x4]
	eor	x8, x8, x2
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x9, x8, x8, lsr #31
	lsr	x8, x9, #57
	ldr	x10, [x1]
	ldr	x12, [x10]
	cbnz	x12, LBB74_2
LBB74_82:
	mov	x9, #0                          ; =0x0
LBB74_83:                               ; %bb1
	cmp	x9, x12
	b.hs	LBB74_87
; %bb.84:                               ; %bb56
	ldr	x11, [x1, #8]
	cmp	x11, #2
	b.hi	LBB74_87
; %bb.85:                               ; %bb59
	mov	w12, #24                        ; =0x18
	madd	x10, x9, x12, x10
	ldr	w12, [x10, #16]
	ldur	q0, [x10, #24]
	mov	w13, #2                         ; =0x2
	str	w13, [x10, #16]
	stp	x2, x3, [x10, #24]
	cmp	w12, #2
	b.hs	LBB74_89
; %bb.86:
	mov	x10, #0                         ; =0x0
	movi.2d	v0, #0000000000000000
	mov	w12, #1                         ; =0x1
	b	LBB74_91
LBB74_87:                               ; %bb55
	stp	xzr, x2, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	strb	w8, [x0, #4]
	str	x3, [x0, #16]
LBB74_88:                               ; %common.ret
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
LBB74_89:                               ; %bb59
	b.ne	LBB74_106
; %bb.90:                               ; %bb3.i99
	mov	w12, #0                         ; =0x0
	mov	w10, #1                         ; =0x1
LBB74_91:                               ; %"wf_hash_map.hash_map_exchange$instance$0ed342445dd803f3.exit105"
	ubfiz	x14, x9, #3, #3
	mov	w13, #255                       ; =0xff
	lsl	x13, x13, x14
	mvn	x13, x13
	lsl	x8, x8, x14
	ldr	x14, [x1, #24]
	cbz	x14, LBB74_94
; %bb.92:                               ; %bb3.i114
	lsr	x9, x9, #3
	ldr	x14, [x1, #32]
	ldr	x15, [x14]
	cmp	x9, x15
	b.hs	LBB74_99
; %bb.93:                               ; %bb8.i125
	add	x9, x14, x9, lsl #3
	ldr	x14, [x9, #8]
	and	x13, x14, x13
	orr	x8, x13, x8
	str	x8, [x9, #8]
	b	LBB74_96
LBB74_94:                               ; %bb2.i130
	cmp	x9, #8
	b.hs	LBB74_96
LBB74_95:                               ; %bb11.i121
	ldr	x9, [x1, #16]
	and	x9, x9, x13
	orr	x8, x9, x8
	str	x8, [x1, #16]
LBB74_96:                               ; %wf_hash_map.hash_map_control_set.exit136
	tbz	w12, #0, LBB74_98
; %bb.97:                               ; %bb62
	add	x8, x11, #1
	str	x8, [x1, #8]
LBB74_98:                               ; %bb61
	str	x10, [x0]
	stur	q0, [x0, #8]
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
LBB74_99:                               ; %bb9.i119
	b.eq	LBB74_95
	b	LBB74_96
LBB74_100:                              ; %"wf_hash_map.hash_map_exchange$instance$0ed342445dd803f3.exit"
	ldr	x9, [x23, #16]
	mov	w10, #2                         ; =0x2
	str	w10, [x23]
	str	x3, [x23, #16]
	mov	w10, #1                         ; =0x1
	stp	x10, x2, [x0]
	str	x9, [x0, #16]
	ubfiz	x10, x22, #3, #3
	mov	w9, #255                        ; =0xff
	lsl	x9, x9, x10
	mvn	x9, x9
	lsl	x8, x8, x10
	cbz	x13, LBB74_103
; %bb.101:                              ; %bb3.i84
	lsr	x10, x22, #3
	ldr	x12, [x1, #32]
	ldr	x13, [x12]
	cmp	x10, x13
	b.hs	LBB74_104
; %bb.102:                              ; %bb8.i87
	add	x10, x12, x10, lsl #3
	ldr	x11, [x10, #8]
	and	x9, x11, x9
	orr	x8, x9, x8
	str	x8, [x10, #8]
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
LBB74_103:                              ; %bb2.i88
	cmp	x22, #8
	b.hs	LBB74_88
	b	LBB74_105
LBB74_104:                              ; %bb9.i85
	b.ne	LBB74_88
LBB74_105:                              ; %bb5.i89
	and	x9, x11, x9
	orr	x8, x9, x8
	str	x8, [x1, #16]
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
LBB74_106:                              ; %invalid.tag.b0.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_reserve$instance$c7b22b9ef52855b6 ; -- Begin function wf_hash_map.hash_map_reserve$instance$c7b22b9ef52855b6
	.p2align	2
_wf_hash_map.hash_map_reserve$instance$c7b22b9ef52855b6: ; @"wf_hash_map.hash_map_reserve$instance$c7b22b9ef52855b6"
	.cfi_startproc
; %bb.0:                                ; %entry
	cmp	x1, #3
	b.ls	LBB75_2
; %bb.1:
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	ret
LBB75_2:                                ; %bb3.i
	ldr	x8, [x0]
	ldr	x8, [x8]
	cmp	x1, x8
	b.ls	LBB75_4
; %bb.3:                                ; %bb6.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_wf_hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB75_4:
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_extend$instance$820b2044b97e0fbd ; -- Begin function wf_hash_map.hash_map_extend$instance$820b2044b97e0fbd
	.p2align	2
_wf_hash_map.hash_map_extend$instance$820b2044b97e0fbd: ; @"wf_hash_map.hash_map_extend$instance$820b2044b97e0fbd"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x1
	ldr	x20, [x0]
	ldr	x8, [x20, #8]
	cmp	x8, x1
	b.hs	LBB76_4
; %bb.1:                                ; %bb2
	mov	x21, x0
	ldr	x23, [x20]
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	madd	x0, x19, x8, x9
	bl	_malloc
	cbz	x0, LBB76_8
; %bb.2:                                ; %"wf_grow$instance$087f541e70b769ea.exit"
	mov	x22, x0
	stp	x23, x19, [x0], #16
	add	x8, x23, x23, lsl #1
	lsl	x2, x8, #3
	add	x1, x20, #16
	bl	_memmove
	mov	x0, x20
	bl	_free
	str	x22, [x21]
	mov	x20, x22
	cmp	x23, x19
	b.lo	LBB76_5
LBB76_3:                                ; %bb7
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB76_4:                                ; %entry.bb1_crit_edge
	ldr	x23, [x20]
	cmp	x23, x19
	b.hs	LBB76_3
LBB76_5:                                ; %bb5.preheader
	mov	w8, #24                         ; =0x18
	madd	x8, x23, x8, x20
	add	x8, x8, #24
LBB76_6:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x8, #-8]
	add	x23, x23, #1
	stp	xzr, xzr, [x8], #24
	cmp	x19, x23
	b.ne	LBB76_6
; %bb.7:                                ; %bb4.bb7_crit_edge
	str	x23, [x20]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB76_8:                                ; %window.block.oom.v2.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_controls_new$instance$fd5e04af5c7e1250 ; -- Begin function wf_hash_map.hash_map_controls_new$instance$fd5e04af5c7e1250
	.p2align	2
_wf_hash_map.hash_map_controls_new$instance$fd5e04af5c7e1250: ; @"wf_hash_map.hash_map_controls_new$instance$fd5e04af5c7e1250"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	cmp	x0, #9
	b.lo	LBB77_3
; %bb.1:                                ; %bb2.i
	mov	x21, x0
	and	x20, x0, #0xfffffffffffffff8
	add	x0, x20, #8
	bl	_malloc
	cbz	x0, LBB77_4
; %bb.2:                                ; %buffer.fill.init.v2.i.i
	mov	x19, x0
	lsr	x8, x21, #3
	str	x8, [x0], #8
	mov	w1, #128                        ; =0x80
	mov	x2, x20
	bl	_memset
	mov	w1, #1                          ; =0x1
	mov	x0, #-9187201950435737472       ; =0x8080808080808080
	mov	x2, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB77_3:
	mov	x19, #0                         ; =0x0
	mov	x1, #0                          ; =0x0
	mov	x0, #-9187201950435737472       ; =0x8080808080808080
	mov	x2, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB77_4:                                ; %buffer.fill.oom.v2.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_try_put$instance$fde7c6722a8b0dad ; -- Begin function wf_hash_map.hash_map_try_put$instance$fde7c6722a8b0dad
	.p2align	2
_wf_hash_map.hash_map_try_put$instance$fde7c6722a8b0dad: ; @"wf_hash_map.hash_map_try_put$instance$fde7c6722a8b0dad"
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	ldrb	w8, [x4, #8]
	tbz	w8, #0, LBB78_81
; %bb.1:
	mov	x9, #0                          ; =0x0
	lsr	x8, x9, #57
	ldr	x10, [x1]
	ldr	x12, [x10]
	cbz	x12, LBB78_82
LBB78_2:                                ; %bb2
	udiv	x11, x9, x12
	msub	x14, x11, x12, x9
	mov	x9, #72340172838076673          ; =0x101010101010101
	mul	x15, x8, x9
	mov	w16, #1                         ; =0x1
	mov	w17, #8                         ; =0x8
	mov	x4, #-9187201950435737472       ; =0x8080808080808080
	ldp	x11, x13, [x1, #16]
	mov	x5, #9187201950435737471        ; =0x7f7f7f7f7f7f7f7f
	mov	w6, #24                         ; =0x18
	mov	x7, x12
	mov	x9, x12
LBB78_3:                                ; %bb10
                                        ; =>This Inner Loop Header: Depth=1
	and	x21, x14, #0x7
	sub	x19, x12, x14
	sub	x20, x17, x21
	cmp	x20, x19
	csel	x19, x20, x19, lo
	cmp	x19, x7
	csel	x19, x19, x7, lo
	cbz	x13, LBB78_6
; %bb.4:                                ; %bb3.i42
                                        ;   in Loop: Header=BB78_3 Depth=1
	lsr	x20, x14, #3
	ldr	x22, [x1, #32]
	ldr	x23, [x22]
	cmp	x20, x23
	b.hs	LBB78_7
; %bb.5:                                ; %bb8.i
                                        ;   in Loop: Header=BB78_3 Depth=1
	add	x20, x22, x20, lsl #3
	ldr	x22, [x20, #8]
	b	LBB78_8
LBB78_6:                                ; %bb2.i
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	x14, #8
	csel	x22, x11, x4, lo
	b	LBB78_8
LBB78_7:                                ; %bb9.i
                                        ;   in Loop: Header=BB78_3 Depth=1
	csel	x22, x11, x4, eq
LBB78_8:                                ; %wf_hash_map.hash_map_control_word.exit
                                        ;   in Loop: Header=BB78_3 Depth=1
	lsl	x20, x19, #3
	neg	x20, x20
	lsr	x20, x4, x20
	lsl	x23, x21, #3
	lsl	x23, x20, x23
	and	x20, x22, #0x7f7f7f7f7f7f7f7f
	add	x20, x20, x5
	orn	x20, x20, x22
	eor	x24, x20, #0x8080808080808080
	ands	x20, x24, x23
	b.eq	LBB78_60
; %bb.9:                                ; %bb2.i63
                                        ;   in Loop: Header=BB78_3 Depth=1
	rbit	x20, x20
	clz	x20, x20
	lsr	x20, x20, #3
	sub	x25, x20, x21
	cmp	x25, x19
	csel	x25, x25, x19, lo
	cmp	x20, x21
	csel	x20, x19, x25, lo
	cmp	x9, x12
	b.ne	LBB78_11
LBB78_10:                               ; %wf_hash_map.hash_map_control_stop.exit
                                        ;   in Loop: Header=BB78_3 Depth=1
	eor	x25, x22, #0xfefefefefefefefe
	and	x26, x25, #0x7f7f7f7f7f7f7f7f
	add	x26, x26, x5
	orr	x25, x26, x25
	orn	x24, x24, x25
	and	x24, x24, x23
	rbit	x25, x24
	clz	x25, x25
	lsr	x25, x25, #3
	sub	x26, x25, x21
	add	x27, x26, x14
	cmp	x26, x19
	csel	x26, x27, x12, lo
	cmp	x25, x21
	csel	x25, x12, x26, lo
	cmp	x24, #0
	csel	x9, x25, x9, ne
LBB78_11:                               ; %bb11
                                        ;   in Loop: Header=BB78_3 Depth=1
	eor	x22, x22, x15
	and	x24, x22, #0x7f7f7f7f7f7f7f7f
	add	x24, x24, x5
	orr	x22, x24, x22
	bic	x24, x23, x22
	cbz	x24, LBB78_63
; %bb.12:                               ; %bb29
                                        ;   in Loop: Header=BB78_3 Depth=1
	rbit	x22, x24
	clz	x22, x22
	lsr	x22, x22, #3
	subs	x25, x22, x21
	b.lo	LBB78_18
; %bb.13:                               ; %bb31
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	x25, x20
	b.hs	LBB78_18
; %bb.14:                               ; %bb34
                                        ;   in Loop: Header=BB78_3 Depth=1
	add	x22, x25, x14
	madd	x23, x22, x6, x10
	ldr	w26, [x23, #16]!
	cbz	w26, LBB78_61
; %bb.15:                               ; %bb34
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	w26, #1
	b.eq	LBB78_66
; %bb.16:                               ; %bb34
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	w26, #2
	b.ne	LBB78_106
; %bb.17:                               ; %bb3.i70
                                        ;   in Loop: Header=BB78_3 Depth=1
	ldr	x25, [x23, #8]
	cmp	x25, x2
	b.eq	LBB78_100
LBB78_18:                               ; %bb47
                                        ;   in Loop: Header=BB78_3 Depth=1
	sub	x22, x24, #1
	and	x24, x22, x24
	cbz	x24, LBB78_63
LBB78_19:                               ; %bb29.1
                                        ;   in Loop: Header=BB78_3 Depth=1
	rbit	x22, x24
	clz	x22, x22
	lsr	x22, x22, #3
	subs	x25, x22, x21
	b.lo	LBB78_25
; %bb.20:                               ; %bb31.1
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	x25, x20
	b.hs	LBB78_25
; %bb.21:                               ; %bb34.1
                                        ;   in Loop: Header=BB78_3 Depth=1
	add	x22, x25, x14
	madd	x23, x22, x6, x10
	ldr	w26, [x23, #16]!
	cbz	w26, LBB78_61
; %bb.22:                               ; %bb34.1
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	w26, #1
	b.eq	LBB78_67
; %bb.23:                               ; %bb34.1
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	w26, #2
	b.ne	LBB78_106
; %bb.24:                               ; %bb3.i70.1
                                        ;   in Loop: Header=BB78_3 Depth=1
	ldr	x25, [x23, #8]
	cmp	x25, x2
	b.eq	LBB78_100
LBB78_25:                               ; %bb47.1
                                        ;   in Loop: Header=BB78_3 Depth=1
	sub	x22, x24, #1
	and	x24, x22, x24
	cbz	x24, LBB78_63
LBB78_26:                               ; %bb29.2
                                        ;   in Loop: Header=BB78_3 Depth=1
	rbit	x22, x24
	clz	x22, x22
	lsr	x22, x22, #3
	subs	x25, x22, x21
	b.lo	LBB78_32
; %bb.27:                               ; %bb31.2
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	x25, x20
	b.hs	LBB78_32
; %bb.28:                               ; %bb34.2
                                        ;   in Loop: Header=BB78_3 Depth=1
	add	x22, x25, x14
	madd	x23, x22, x6, x10
	ldr	w26, [x23, #16]!
	cbz	w26, LBB78_61
; %bb.29:                               ; %bb34.2
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	w26, #1
	b.eq	LBB78_68
; %bb.30:                               ; %bb34.2
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	w26, #2
	b.ne	LBB78_106
; %bb.31:                               ; %bb3.i70.2
                                        ;   in Loop: Header=BB78_3 Depth=1
	ldr	x25, [x23, #8]
	cmp	x25, x2
	b.eq	LBB78_100
LBB78_32:                               ; %bb47.2
                                        ;   in Loop: Header=BB78_3 Depth=1
	sub	x22, x24, #1
	and	x24, x22, x24
	cbz	x24, LBB78_63
LBB78_33:                               ; %bb29.3
                                        ;   in Loop: Header=BB78_3 Depth=1
	rbit	x22, x24
	clz	x22, x22
	lsr	x22, x22, #3
	subs	x25, x22, x21
	b.lo	LBB78_39
; %bb.34:                               ; %bb31.3
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	x25, x20
	b.hs	LBB78_39
; %bb.35:                               ; %bb34.3
                                        ;   in Loop: Header=BB78_3 Depth=1
	add	x22, x25, x14
	madd	x23, x22, x6, x10
	ldr	w26, [x23, #16]!
	cbz	w26, LBB78_61
; %bb.36:                               ; %bb34.3
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	w26, #1
	b.eq	LBB78_69
; %bb.37:                               ; %bb34.3
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	w26, #2
	b.ne	LBB78_106
; %bb.38:                               ; %bb3.i70.3
                                        ;   in Loop: Header=BB78_3 Depth=1
	ldr	x25, [x23, #8]
	cmp	x25, x2
	b.eq	LBB78_100
LBB78_39:                               ; %bb47.3
                                        ;   in Loop: Header=BB78_3 Depth=1
	sub	x22, x24, #1
	and	x24, x22, x24
	cbz	x24, LBB78_63
LBB78_40:                               ; %bb29.4
                                        ;   in Loop: Header=BB78_3 Depth=1
	rbit	x22, x24
	clz	x22, x22
	lsr	x22, x22, #3
	subs	x25, x22, x21
	b.lo	LBB78_46
; %bb.41:                               ; %bb31.4
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	x25, x20
	b.hs	LBB78_46
; %bb.42:                               ; %bb34.4
                                        ;   in Loop: Header=BB78_3 Depth=1
	add	x22, x25, x14
	madd	x23, x22, x6, x10
	ldr	w26, [x23, #16]!
	cbz	w26, LBB78_61
; %bb.43:                               ; %bb34.4
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	w26, #1
	b.eq	LBB78_70
; %bb.44:                               ; %bb34.4
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	w26, #2
	b.ne	LBB78_106
; %bb.45:                               ; %bb3.i70.4
                                        ;   in Loop: Header=BB78_3 Depth=1
	ldr	x25, [x23, #8]
	cmp	x25, x2
	b.eq	LBB78_100
LBB78_46:                               ; %bb47.4
                                        ;   in Loop: Header=BB78_3 Depth=1
	sub	x22, x24, #1
	and	x24, x22, x24
	cbz	x24, LBB78_63
LBB78_47:                               ; %bb29.5
                                        ;   in Loop: Header=BB78_3 Depth=1
	rbit	x22, x24
	clz	x22, x22
	lsr	x22, x22, #3
	subs	x25, x22, x21
	b.lo	LBB78_53
; %bb.48:                               ; %bb31.5
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	x25, x20
	b.hs	LBB78_53
; %bb.49:                               ; %bb34.5
                                        ;   in Loop: Header=BB78_3 Depth=1
	add	x22, x25, x14
	madd	x23, x22, x6, x10
	ldr	w26, [x23, #16]!
	cbz	w26, LBB78_61
; %bb.50:                               ; %bb34.5
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	w26, #1
	b.eq	LBB78_71
; %bb.51:                               ; %bb34.5
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	w26, #2
	b.ne	LBB78_106
; %bb.52:                               ; %bb3.i70.5
                                        ;   in Loop: Header=BB78_3 Depth=1
	ldr	x25, [x23, #8]
	cmp	x25, x2
	b.eq	LBB78_100
LBB78_53:                               ; %bb47.5
                                        ;   in Loop: Header=BB78_3 Depth=1
	sub	x22, x24, #1
	and	x24, x22, x24
	cbz	x24, LBB78_63
LBB78_54:                               ; %bb29.6
                                        ;   in Loop: Header=BB78_3 Depth=1
	rbit	x22, x24
	clz	x22, x22
	lsr	x22, x22, #3
	subs	x25, x22, x21
	b.lo	LBB78_73
; %bb.55:                               ; %bb31.6
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	x25, x20
	b.hs	LBB78_73
; %bb.56:                               ; %bb34.6
                                        ;   in Loop: Header=BB78_3 Depth=1
	add	x22, x25, x14
	madd	x23, x22, x6, x10
	ldr	w26, [x23, #16]!
	cbz	w26, LBB78_61
; %bb.57:                               ; %bb34.6
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	w26, #1
	b.eq	LBB78_72
; %bb.58:                               ; %bb34.6
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	w26, #2
	b.ne	LBB78_106
; %bb.59:                               ; %bb3.i70.6
                                        ;   in Loop: Header=BB78_3 Depth=1
	ldr	x25, [x23, #8]
	cmp	x25, x2
	b.ne	LBB78_73
	b	LBB78_100
LBB78_60:                               ;   in Loop: Header=BB78_3 Depth=1
	mov	x20, x19
	cmp	x9, x12
	b.eq	LBB78_10
	b	LBB78_11
LBB78_61:                               ;   in Loop: Header=BB78_3 Depth=1
	mov	x20, x25
LBB78_62:                               ; %bb38
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	x9, x12
	csel	x9, x22, x9, eq
LBB78_63:                               ; %bb26
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	x20, x19
	b.lo	LBB78_83
; %bb.64:                               ; %bb50
                                        ;   in Loop: Header=BB78_3 Depth=1
	add	x14, x19, x14
	cmp	x14, x12
	csel	x14, x14, xzr, lo
	cmp	x16, x12
	b.hs	LBB78_83
; %bb.65:                               ; %bb50
                                        ;   in Loop: Header=BB78_3 Depth=1
	add	x16, x16, #1
	sub	x7, x7, x19
	cbnz	x7, LBB78_3
	b	LBB78_83
LBB78_66:                               ; %bb39
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	x9, x12
	csel	x9, x22, x9, eq
	sub	x22, x24, #1
	and	x24, x22, x24
	cbnz	x24, LBB78_19
	b	LBB78_63
LBB78_67:                               ; %bb39.1
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	x9, x12
	csel	x9, x22, x9, eq
	sub	x22, x24, #1
	and	x24, x22, x24
	cbnz	x24, LBB78_26
	b	LBB78_63
LBB78_68:                               ; %bb39.2
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	x9, x12
	csel	x9, x22, x9, eq
	sub	x22, x24, #1
	and	x24, x22, x24
	cbnz	x24, LBB78_33
	b	LBB78_63
LBB78_69:                               ; %bb39.3
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	x9, x12
	csel	x9, x22, x9, eq
	sub	x22, x24, #1
	and	x24, x22, x24
	cbnz	x24, LBB78_40
	b	LBB78_63
LBB78_70:                               ; %bb39.4
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	x9, x12
	csel	x9, x22, x9, eq
	sub	x22, x24, #1
	and	x24, x22, x24
	cbnz	x24, LBB78_47
	b	LBB78_63
LBB78_71:                               ; %bb39.5
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	x9, x12
	csel	x9, x22, x9, eq
	sub	x22, x24, #1
	and	x24, x22, x24
	cbnz	x24, LBB78_54
	b	LBB78_63
LBB78_72:                               ; %bb39.6
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	x9, x12
	csel	x9, x22, x9, eq
LBB78_73:                               ; %bb47.6
                                        ;   in Loop: Header=BB78_3 Depth=1
	sub	x22, x24, #1
	and	x22, x22, x24
	cbz	x22, LBB78_63
; %bb.74:                               ; %bb29.7
                                        ;   in Loop: Header=BB78_3 Depth=1
	rbit	x22, x22
	clz	x22, x22
	lsr	x22, x22, #3
	subs	x21, x22, x21
	b.lo	LBB78_63
; %bb.75:                               ; %bb31.7
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	x21, x20
	b.hs	LBB78_63
; %bb.76:                               ; %bb34.7
                                        ;   in Loop: Header=BB78_3 Depth=1
	add	x22, x21, x14
	madd	x23, x22, x6, x10
	ldr	w24, [x23, #16]!
	cbz	w24, LBB78_80
; %bb.77:                               ; %bb34.7
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	w24, #1
	b.eq	LBB78_62
; %bb.78:                               ; %bb34.7
                                        ;   in Loop: Header=BB78_3 Depth=1
	cmp	w24, #2
	b.ne	LBB78_106
; %bb.79:                               ; %bb3.i70.7
                                        ;   in Loop: Header=BB78_3 Depth=1
	ldr	x21, [x23, #8]
	cmp	x21, x2
	b.ne	LBB78_63
	b	LBB78_100
LBB78_80:                               ;   in Loop: Header=BB78_3 Depth=1
	mov	x20, x21
	b	LBB78_62
LBB78_81:                               ; %bb3.i
	ldr	x8, [x4]
	eor	x8, x8, x2
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x9, x8, x8, lsr #31
	lsr	x8, x9, #57
	ldr	x10, [x1]
	ldr	x12, [x10]
	cbnz	x12, LBB78_2
LBB78_82:
	mov	x9, #0                          ; =0x0
LBB78_83:                               ; %bb1
	cmp	x9, x12
	b.hs	LBB78_87
; %bb.84:                               ; %bb56
	ldr	x11, [x1, #8]
	lsr	x12, x11, #14
	cbnz	x12, LBB78_87
; %bb.85:                               ; %bb59
	mov	w12, #24                        ; =0x18
	madd	x10, x9, x12, x10
	ldr	w12, [x10, #16]
	ldur	q0, [x10, #24]
	mov	w13, #2                         ; =0x2
	str	w13, [x10, #16]
	stp	x2, x3, [x10, #24]
	cmp	w12, #2
	b.hs	LBB78_89
; %bb.86:
	mov	x10, #0                         ; =0x0
	movi.2d	v0, #0000000000000000
	mov	w12, #1                         ; =0x1
	b	LBB78_91
LBB78_87:                               ; %bb55
	stp	xzr, x2, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	strb	w8, [x0, #4]
	str	x3, [x0, #16]
LBB78_88:                               ; %common.ret
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
LBB78_89:                               ; %bb59
	b.ne	LBB78_106
; %bb.90:                               ; %bb3.i99
	mov	w12, #0                         ; =0x0
	mov	w10, #1                         ; =0x1
LBB78_91:                               ; %"wf_hash_map.hash_map_exchange$instance$0ed342445dd803f3.exit105"
	ubfiz	x14, x9, #3, #3
	mov	w13, #255                       ; =0xff
	lsl	x13, x13, x14
	mvn	x13, x13
	lsl	x8, x8, x14
	ldr	x14, [x1, #24]
	cbz	x14, LBB78_94
; %bb.92:                               ; %bb3.i114
	lsr	x9, x9, #3
	ldr	x14, [x1, #32]
	ldr	x15, [x14]
	cmp	x9, x15
	b.hs	LBB78_99
; %bb.93:                               ; %bb8.i125
	add	x9, x14, x9, lsl #3
	ldr	x14, [x9, #8]
	and	x13, x14, x13
	orr	x8, x13, x8
	str	x8, [x9, #8]
	b	LBB78_96
LBB78_94:                               ; %bb2.i130
	cmp	x9, #8
	b.hs	LBB78_96
LBB78_95:                               ; %bb11.i121
	ldr	x9, [x1, #16]
	and	x9, x9, x13
	orr	x8, x9, x8
	str	x8, [x1, #16]
LBB78_96:                               ; %wf_hash_map.hash_map_control_set.exit136
	tbz	w12, #0, LBB78_98
; %bb.97:                               ; %bb62
	add	x8, x11, #1
	str	x8, [x1, #8]
LBB78_98:                               ; %bb61
	str	x10, [x0]
	stur	q0, [x0, #8]
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
LBB78_99:                               ; %bb9.i119
	b.eq	LBB78_95
	b	LBB78_96
LBB78_100:                              ; %"wf_hash_map.hash_map_exchange$instance$0ed342445dd803f3.exit"
	ldr	x9, [x23, #16]
	mov	w10, #2                         ; =0x2
	str	w10, [x23]
	str	x3, [x23, #16]
	mov	w10, #1                         ; =0x1
	stp	x10, x2, [x0]
	str	x9, [x0, #16]
	ubfiz	x10, x22, #3, #3
	mov	w9, #255                        ; =0xff
	lsl	x9, x9, x10
	mvn	x9, x9
	lsl	x8, x8, x10
	cbz	x13, LBB78_103
; %bb.101:                              ; %bb3.i84
	lsr	x10, x22, #3
	ldr	x12, [x1, #32]
	ldr	x13, [x12]
	cmp	x10, x13
	b.hs	LBB78_104
; %bb.102:                              ; %bb8.i87
	add	x10, x12, x10, lsl #3
	ldr	x11, [x10, #8]
	and	x9, x11, x9
	orr	x8, x9, x8
	str	x8, [x10, #8]
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
LBB78_103:                              ; %bb2.i88
	cmp	x22, #8
	b.hs	LBB78_88
	b	LBB78_105
LBB78_104:                              ; %bb9.i85
	b.ne	LBB78_88
LBB78_105:                              ; %bb5.i89
	and	x9, x11, x9
	orr	x8, x9, x8
	str	x8, [x1, #16]
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
LBB78_106:                              ; %invalid.tag.b0.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_find$instance$fde7c6722a8b0dad ; -- Begin function wf_hash_map.hash_map_find$instance$fde7c6722a8b0dad
	.p2align	2
_wf_hash_map.hash_map_find$instance$fde7c6722a8b0dad: ; @"wf_hash_map.hash_map_find$instance$fde7c6722a8b0dad"
; %bb.0:                                ; %entry
	stp	x22, x21, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	ldrb	w8, [x2, #8]
	tbz	w8, #0, LBB79_2
; %bb.1:
	mov	x8, #0                          ; =0x0
	ldr	x10, [x0]
	ldr	x11, [x10]
	cbnz	x11, LBB79_3
	b	LBB79_63
LBB79_2:                                ; %bb3.i.i
	ldr	x8, [x2]
	ldr	x9, [x1]
	eor	x8, x9, x8
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #31
	ldr	x10, [x0]
	ldr	x11, [x10]
	cbz	x11, LBB79_63
LBB79_3:                                ; %bb3.i
	lsr	x9, x8, #57
	udiv	x12, x8, x11
	msub	x12, x12, x11, x8
	mov	x8, #72340172838076673          ; =0x101010101010101
	mul	x13, x9, x8
	mov	w14, #1                         ; =0x1
	mov	w15, #8                         ; =0x8
	ldp	x17, x16, [x0, #16]
	mov	x2, #-9187201950435737472       ; =0x8080808080808080
	mov	x3, #9187201950435737471        ; =0x7f7f7f7f7f7f7f7f
	mov	w4, #24                         ; =0x18
	mov	x5, x11
LBB79_4:                                ; %bb10.i
                                        ; =>This Inner Loop Header: Depth=1
	and	x9, x12, #0x7
	sub	x8, x11, x12
	sub	x6, x15, x9
	cmp	x6, x8
	csel	x8, x6, x8, lo
	cmp	x8, x5
	csel	x6, x8, x5, lo
	cbz	x16, LBB79_7
; %bb.5:                                ; %bb3.i21.i
                                        ;   in Loop: Header=BB79_4 Depth=1
	lsr	x8, x12, #3
	ldr	x7, [x0, #32]
	ldr	x19, [x7]
	cmp	x8, x19
	b.hs	LBB79_8
; %bb.6:                                ; %bb8.i.i
                                        ;   in Loop: Header=BB79_4 Depth=1
	add	x8, x7, x8, lsl #3
	ldr	x8, [x8, #8]
	b	LBB79_9
LBB79_7:                                ; %bb2.i.i
                                        ;   in Loop: Header=BB79_4 Depth=1
	cmp	x12, #8
	csel	x8, x17, x2, lo
	b	LBB79_9
LBB79_8:                                ; %bb9.i.i
                                        ;   in Loop: Header=BB79_4 Depth=1
	csel	x8, x17, x2, eq
LBB79_9:                                ; %wf_hash_map.hash_map_control_word.exit.i
                                        ;   in Loop: Header=BB79_4 Depth=1
	lsl	x7, x6, #3
	neg	x7, x7
	lsr	x7, x2, x7
	lsl	x19, x9, #3
	lsl	x19, x7, x19
	and	x7, x8, #0x7f7f7f7f7f7f7f7f
	sub	x7, x2, x7
	and	x7, x7, x8
	and	x7, x19, x7
	cmp	x7, #0
	rbit	x7, x7
	clz	x7, x7
	lsr	x20, x7, #3
	ccmp	x20, x9, #0, ne
	mov	x7, x6
	b.hs	LBB79_11
; %bb.10:                               ; %wf_hash_map.hash_map_control_stop.exit.i
                                        ;   in Loop: Header=BB79_4 Depth=1
	eor	x8, x8, x13
	and	x20, x8, #0x7f7f7f7f7f7f7f7f
	add	x20, x20, x3
	orr	x8, x20, x8
	bic	x19, x19, x8
	cbnz	x19, LBB79_12
	b	LBB79_59
LBB79_11:                               ; %bb5.i.i
                                        ;   in Loop: Header=BB79_4 Depth=1
	sub	x7, x20, x9
	cmp	x7, x6
	csel	x7, x7, x6, lo
	eor	x8, x8, x13
	and	x20, x8, #0x7f7f7f7f7f7f7f7f
	add	x20, x20, x3
	orr	x8, x20, x8
	bic	x19, x19, x8
	cbz	x19, LBB79_59
LBB79_12:                               ; %bb17.i
                                        ;   in Loop: Header=BB79_4 Depth=1
	rbit	x8, x19
	clz	x8, x8
	lsr	x8, x8, #3
	subs	x8, x8, x9
	b.lo	LBB79_17
; %bb.13:                               ; %bb19.i
                                        ;   in Loop: Header=BB79_4 Depth=1
	cmp	x8, x7
	b.hs	LBB79_17
; %bb.14:                               ; %bb22.i
                                        ;   in Loop: Header=BB79_4 Depth=1
	add	x20, x8, x12
	madd	x21, x20, x4, x10
	ldr	w8, [x21, #16]!
	cmp	w8, #1
	b.eq	LBB79_17
; %bb.15:                               ; %bb22.i
                                        ;   in Loop: Header=BB79_4 Depth=1
	cmp	w8, #2
	b.ne	LBB79_65
; %bb.16:                               ; %bb25.i
                                        ;   in Loop: Header=BB79_4 Depth=1
	ldr	x8, [x21, #8]
	ldr	x21, [x1]
	cmp	x8, x21
	b.eq	LBB79_67
LBB79_17:                               ; %bb31.i
                                        ;   in Loop: Header=BB79_4 Depth=1
	sub	x8, x19, #1
	and	x19, x8, x19
	cbz	x19, LBB79_59
; %bb.18:                               ; %bb17.i.1
                                        ;   in Loop: Header=BB79_4 Depth=1
	rbit	x8, x19
	clz	x8, x8
	lsr	x8, x8, #3
	subs	x8, x8, x9
	b.lo	LBB79_23
; %bb.19:                               ; %bb19.i.1
                                        ;   in Loop: Header=BB79_4 Depth=1
	cmp	x8, x7
	b.hs	LBB79_23
; %bb.20:                               ; %bb22.i.1
                                        ;   in Loop: Header=BB79_4 Depth=1
	add	x20, x8, x12
	madd	x21, x20, x4, x10
	ldr	w8, [x21, #16]!
	cmp	w8, #1
	b.eq	LBB79_23
; %bb.21:                               ; %bb22.i.1
                                        ;   in Loop: Header=BB79_4 Depth=1
	cmp	w8, #2
	b.ne	LBB79_65
; %bb.22:                               ; %bb25.i.1
                                        ;   in Loop: Header=BB79_4 Depth=1
	ldr	x8, [x21, #8]
	ldr	x21, [x1]
	cmp	x8, x21
	b.eq	LBB79_67
LBB79_23:                               ; %bb31.i.1
                                        ;   in Loop: Header=BB79_4 Depth=1
	sub	x8, x19, #1
	and	x19, x8, x19
	cbz	x19, LBB79_59
; %bb.24:                               ; %bb17.i.2
                                        ;   in Loop: Header=BB79_4 Depth=1
	rbit	x8, x19
	clz	x8, x8
	lsr	x8, x8, #3
	subs	x8, x8, x9
	b.lo	LBB79_29
; %bb.25:                               ; %bb19.i.2
                                        ;   in Loop: Header=BB79_4 Depth=1
	cmp	x8, x7
	b.hs	LBB79_29
; %bb.26:                               ; %bb22.i.2
                                        ;   in Loop: Header=BB79_4 Depth=1
	add	x20, x8, x12
	madd	x21, x20, x4, x10
	ldr	w8, [x21, #16]!
	cmp	w8, #1
	b.eq	LBB79_29
; %bb.27:                               ; %bb22.i.2
                                        ;   in Loop: Header=BB79_4 Depth=1
	cmp	w8, #2
	b.ne	LBB79_65
; %bb.28:                               ; %bb25.i.2
                                        ;   in Loop: Header=BB79_4 Depth=1
	ldr	x8, [x21, #8]
	ldr	x21, [x1]
	cmp	x8, x21
	b.eq	LBB79_67
LBB79_29:                               ; %bb31.i.2
                                        ;   in Loop: Header=BB79_4 Depth=1
	sub	x8, x19, #1
	and	x19, x8, x19
	cbz	x19, LBB79_59
; %bb.30:                               ; %bb17.i.3
                                        ;   in Loop: Header=BB79_4 Depth=1
	rbit	x8, x19
	clz	x8, x8
	lsr	x8, x8, #3
	subs	x8, x8, x9
	b.lo	LBB79_35
; %bb.31:                               ; %bb19.i.3
                                        ;   in Loop: Header=BB79_4 Depth=1
	cmp	x8, x7
	b.hs	LBB79_35
; %bb.32:                               ; %bb22.i.3
                                        ;   in Loop: Header=BB79_4 Depth=1
	add	x20, x8, x12
	madd	x21, x20, x4, x10
	ldr	w8, [x21, #16]!
	cmp	w8, #1
	b.eq	LBB79_35
; %bb.33:                               ; %bb22.i.3
                                        ;   in Loop: Header=BB79_4 Depth=1
	cmp	w8, #2
	b.ne	LBB79_65
; %bb.34:                               ; %bb25.i.3
                                        ;   in Loop: Header=BB79_4 Depth=1
	ldr	x8, [x21, #8]
	ldr	x21, [x1]
	cmp	x8, x21
	b.eq	LBB79_67
LBB79_35:                               ; %bb31.i.3
                                        ;   in Loop: Header=BB79_4 Depth=1
	sub	x8, x19, #1
	and	x19, x8, x19
	cbz	x19, LBB79_59
; %bb.36:                               ; %bb17.i.4
                                        ;   in Loop: Header=BB79_4 Depth=1
	rbit	x8, x19
	clz	x8, x8
	lsr	x8, x8, #3
	subs	x8, x8, x9
	b.lo	LBB79_41
; %bb.37:                               ; %bb19.i.4
                                        ;   in Loop: Header=BB79_4 Depth=1
	cmp	x8, x7
	b.hs	LBB79_41
; %bb.38:                               ; %bb22.i.4
                                        ;   in Loop: Header=BB79_4 Depth=1
	add	x20, x8, x12
	madd	x21, x20, x4, x10
	ldr	w8, [x21, #16]!
	cmp	w8, #1
	b.eq	LBB79_41
; %bb.39:                               ; %bb22.i.4
                                        ;   in Loop: Header=BB79_4 Depth=1
	cmp	w8, #2
	b.ne	LBB79_65
; %bb.40:                               ; %bb25.i.4
                                        ;   in Loop: Header=BB79_4 Depth=1
	ldr	x8, [x21, #8]
	ldr	x21, [x1]
	cmp	x8, x21
	b.eq	LBB79_67
LBB79_41:                               ; %bb31.i.4
                                        ;   in Loop: Header=BB79_4 Depth=1
	sub	x8, x19, #1
	and	x19, x8, x19
	cbz	x19, LBB79_59
; %bb.42:                               ; %bb17.i.5
                                        ;   in Loop: Header=BB79_4 Depth=1
	rbit	x8, x19
	clz	x8, x8
	lsr	x8, x8, #3
	subs	x8, x8, x9
	b.lo	LBB79_47
; %bb.43:                               ; %bb19.i.5
                                        ;   in Loop: Header=BB79_4 Depth=1
	cmp	x8, x7
	b.hs	LBB79_47
; %bb.44:                               ; %bb22.i.5
                                        ;   in Loop: Header=BB79_4 Depth=1
	add	x20, x8, x12
	madd	x21, x20, x4, x10
	ldr	w8, [x21, #16]!
	cmp	w8, #1
	b.eq	LBB79_47
; %bb.45:                               ; %bb22.i.5
                                        ;   in Loop: Header=BB79_4 Depth=1
	cmp	w8, #2
	b.ne	LBB79_65
; %bb.46:                               ; %bb25.i.5
                                        ;   in Loop: Header=BB79_4 Depth=1
	ldr	x8, [x21, #8]
	ldr	x21, [x1]
	cmp	x8, x21
	b.eq	LBB79_67
LBB79_47:                               ; %bb31.i.5
                                        ;   in Loop: Header=BB79_4 Depth=1
	sub	x8, x19, #1
	and	x19, x8, x19
	cbz	x19, LBB79_59
; %bb.48:                               ; %bb17.i.6
                                        ;   in Loop: Header=BB79_4 Depth=1
	rbit	x8, x19
	clz	x8, x8
	lsr	x8, x8, #3
	subs	x8, x8, x9
	b.lo	LBB79_53
; %bb.49:                               ; %bb19.i.6
                                        ;   in Loop: Header=BB79_4 Depth=1
	cmp	x8, x7
	b.hs	LBB79_53
; %bb.50:                               ; %bb22.i.6
                                        ;   in Loop: Header=BB79_4 Depth=1
	add	x20, x8, x12
	madd	x21, x20, x4, x10
	ldr	w8, [x21, #16]!
	cmp	w8, #1
	b.eq	LBB79_53
; %bb.51:                               ; %bb22.i.6
                                        ;   in Loop: Header=BB79_4 Depth=1
	cmp	w8, #2
	b.ne	LBB79_65
; %bb.52:                               ; %bb25.i.6
                                        ;   in Loop: Header=BB79_4 Depth=1
	ldr	x8, [x21, #8]
	ldr	x21, [x1]
	cmp	x8, x21
	b.eq	LBB79_67
LBB79_53:                               ; %bb31.i.6
                                        ;   in Loop: Header=BB79_4 Depth=1
	sub	x8, x19, #1
	and	x8, x8, x19
	cbz	x8, LBB79_59
; %bb.54:                               ; %bb17.i.7
                                        ;   in Loop: Header=BB79_4 Depth=1
	rbit	x8, x8
	clz	x8, x8
	lsr	x8, x8, #3
	subs	x8, x8, x9
	b.lo	LBB79_59
; %bb.55:                               ; %bb19.i.7
                                        ;   in Loop: Header=BB79_4 Depth=1
	cmp	x8, x7
	b.hs	LBB79_59
; %bb.56:                               ; %bb22.i.7
                                        ;   in Loop: Header=BB79_4 Depth=1
	add	x19, x8, x12
	madd	x9, x19, x4, x10
	ldr	w8, [x9, #16]!
	cmp	w8, #1
	b.eq	LBB79_59
; %bb.57:                               ; %bb22.i.7
                                        ;   in Loop: Header=BB79_4 Depth=1
	cmp	w8, #2
	b.ne	LBB79_65
; %bb.58:                               ; %bb25.i.7
                                        ;   in Loop: Header=BB79_4 Depth=1
	ldr	x8, [x9, #8]
	ldr	x9, [x1]
	cmp	x8, x9
	b.eq	LBB79_68
LBB79_59:                               ; %bb14.i
                                        ;   in Loop: Header=BB79_4 Depth=1
	cmp	x7, x6
	b.lo	LBB79_63
; %bb.60:                               ; %bb34.i
                                        ;   in Loop: Header=BB79_4 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x6, x12
	cmp	x9, x11
	csel	x12, x9, xzr, lo
	mov	w9, #1                          ; =0x1
	cmp	x14, x11
	b.hs	LBB79_62
; %bb.61:                               ; %bb34.i
                                        ;   in Loop: Header=BB79_4 Depth=1
	add	x14, x14, #1
	sub	x5, x5, x6
	cbnz	x5, LBB79_4
LBB79_62:                               ; %"wf_hash_map.hash_map_find$instance$fde7c6722a8b0dad.body.exit"
	mov	x0, x9
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #32             ; 16-byte Folded Reload
	ret
LBB79_63:
	mov	x8, #0                          ; =0x0
LBB79_64:
	mov	w9, #1                          ; =0x1
	mov	x0, x9
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #32             ; 16-byte Folded Reload
	ret
LBB79_65:                               ; %bb22.i
	cbz	w8, LBB79_64
; %bb.66:                               ; %invalid.tag.b22.i
	bl	_abort
LBB79_67:
	mov	w9, #0                          ; =0x0
	mov	x8, x20
	mov	x0, x9
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #32             ; 16-byte Folded Reload
	ret
LBB79_68:
	mov	w9, #0                          ; =0x0
	mov	x8, x19
	mov	x0, x9
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #32             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad ; -- Begin function wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	.p2align	2
_wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad: ; @"wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #144
	stp	x28, x27, [sp, #48]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 144
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cmp	x1, #4, lsl #12                 ; =16384
	b.hi	LBB80_2
; %bb.1:                                ; %bb3.i
	ldr	x19, [x0]
	ldr	x26, [x19]
	cmp	x1, x26
	b.hs	LBB80_3
LBB80_2:
	mov	w0, #1                          ; =0x1
	b	LBB80_36
LBB80_3:                                ; %bb6.i
	cbz	x1, LBB80_35
; %bb.4:                                ; %bb9.i
	mov	x25, x0
	ldr	x23, [x2]
	ldrb	w24, [x2, #8]
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	mov	x27, x1
	madd	x0, x1, x8, x9
	bl	_malloc
	cbz	x0, LBB80_38
; %bb.5:                                ; %bb1.i.i
	mov	x20, x0
	mov	x9, #0                          ; =0x0
	mov	x8, x27
	str	x27, [x0, #8]
	add	x10, x0, #24
LBB80_6:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x10, #-8]
	add	x9, x9, #1
	stp	xzr, xzr, [x10], #24
	cmp	x8, x9
	b.ne	LBB80_6
; %bb.7:                                ; %"wf_hash_map.hash_map_extend$instance$820b2044b97e0fbd.exit.i"
	str	x8, [x20]
	cmp	x8, #9
	b.hs	LBB80_9
; %bb.8:
	mov	x21, #0                         ; =0x0
	mov	x10, #0                         ; =0x0
	b	LBB80_11
LBB80_9:                                ; %bb2.i.i.i
	and	x22, x8, #0x7ff8
	add	x0, x22, #8
	bl	_malloc
	cbz	x0, LBB80_38
; %bb.10:                               ; %buffer.fill.init.v2.i.i.i.i
	mov	x21, x0
	lsr	x8, x27, #3
	str	x8, [x0], #8
	mov	w1, #128                        ; =0x80
	mov	x2, x22
	bl	_memset
	mov	x8, x27
	mov	w10, #1                         ; =0x1
LBB80_11:                               ; %"wf_hash_map.hash_map_controls_new$instance$fd5e04af5c7e1250.exit.i"
	mov	x9, x25
	str	x20, [x25]
	ldp	x22, x25, [x25, #24]
	mov	x11, #-9187201950435737472      ; =0x8080808080808080
	stp	x11, x10, [x9, #16]
	str	x21, [x9, #32]
	cbz	x26, LBB80_32
; %bb.12:                               ; %bb14.lr.ph.i
	mov	x10, #-9187201950435737472      ; =0x8080808080808080
	mov	w11, #24                        ; =0x18
	mov	x12, #58809                     ; =0xe5b9
	movk	x12, #7396, lsl #16
	movk	x12, #18285, lsl #32
	movk	x12, #48984, lsl #48
	mov	x13, #4587                      ; =0x11eb
	movk	x13, #4913, lsl #16
	movk	x13, #18875, lsl #32
	movk	x13, #38096, lsl #48
	add	x14, sp, #8
	mov	w15, #2                         ; =0x2
	mov	w16, #255                       ; =0xff
	b	LBB80_14
LBB80_13:                               ; %bb15.i
                                        ;   in Loop: Header=BB80_14 Depth=1
	mov	x26, x17
	cbz	x17, LBB80_32
LBB80_14:                               ; %bb14.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB80_21 Depth 2
                                        ;       Child Loop BB80_23 Depth 3
	sub	x17, x26, #1
	str	x17, [x19]
	madd	x0, x26, x11, x19
	ldr	w1, [x0, #-8]!
	cmp	w1, #2
	b.lo	LBB80_13
; %bb.15:                               ; %bb14.i
                                        ;   in Loop: Header=BB80_14 Depth=1
	b.ne	LBB80_37
; %bb.16:                               ; %bb23.preheader.i
                                        ;   in Loop: Header=BB80_14 Depth=1
	ldur	q0, [x0, #8]
	ldr	x0, [x0, #8]
	stur	q0, [sp, #16]
	eor	x0, x0, x23
	eor	x0, x0, x0, lsr #30
	mul	x0, x0, x12
	eor	x0, x0, x0, lsr #27
	mul	x0, x0, x13
	eor	x0, x0, x0, lsr #31
	tst	w24, #0x1
	csel	x0, xzr, x0, ne
	ldr	x3, [x20]
	cbz	x3, LBB80_31
; %bb.17:                               ; %bb23.i.preheader
                                        ;   in Loop: Header=BB80_14 Depth=1
	lsr	x1, x0, #57
	mov	w2, #1                          ; =0x1
	b	LBB80_21
LBB80_18:                               ; %bb8.i.i
                                        ;   in Loop: Header=BB80_21 Depth=2
	add	x5, x21, x5, lsl #3
	ldr	x6, [x5, #8]
	and	x4, x6, x4
	orr	x3, x4, x3
	str	x3, [x5, #8]
LBB80_19:                               ; %bb27.i
                                        ;   in Loop: Header=BB80_21 Depth=2
	cbz	x2, LBB80_13
LBB80_20:                               ; %bb23.ithread-pre-split
                                        ;   in Loop: Header=BB80_21 Depth=2
	ldr	x3, [x20]
LBB80_21:                               ; %bb23.i
                                        ;   Parent Loop BB80_14 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB80_23 Depth 3
	cbz	x3, LBB80_20
; %bb.22:                               ; %bb25.lr.ph.i
                                        ;   in Loop: Header=BB80_21 Depth=2
	mov	x4, #0                          ; =0x0
	udiv	x5, x0, x3
	msub	x5, x5, x3, x0
	sub	x6, x3, x5
	neg	x7, x6
LBB80_23:                               ; %bb25.i
                                        ;   Parent Loop BB80_14 Depth=1
                                        ;     Parent Loop BB80_21 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x4, x6
	csel	x26, x5, x7, lo
	add	x27, x26, x4
	madd	x27, x27, x11, x20
	ldr	w28, [x27, #16]!
	cmp	w28, #2
	b.ne	LBB80_25
; %bb.24:                               ; %bb3.i28.i
                                        ;   in Loop: Header=BB80_23 Depth=3
	add	x4, x4, #1
	cmp	x3, x4
	b.ne	LBB80_23
	b	LBB80_20
LBB80_25:                               ; %bb25.i
                                        ;   in Loop: Header=BB80_21 Depth=2
	b.hs	LBB80_37
; %bb.26:                               ; %bb29.i
                                        ;   in Loop: Header=BB80_21 Depth=2
	sub	x2, x2, #1
	add	x3, x14, x2, lsl #4
	str	x2, [sp, #8]
	str	w15, [x27]
	ldur	q0, [x3, #8]
	stur	q0, [x27, #8]
	add	x5, x26, x4
	ubfiz	x3, x5, #3, #3
	lsl	x4, x16, x3
	mvn	x4, x4
	lsl	x3, x1, x3
	cmp	x8, #8
	b.hi	LBB80_28
; %bb.27:                               ; %bb2.i46.i
                                        ;   in Loop: Header=BB80_21 Depth=2
	cmp	x5, #8
	b.hs	LBB80_19
	b	LBB80_30
LBB80_28:                               ; %bb3.i44.i
                                        ;   in Loop: Header=BB80_21 Depth=2
	lsr	x5, x5, #3
	ldr	x6, [x21]
	cmp	x5, x6
	b.lo	LBB80_18
; %bb.29:                               ; %bb9.i.i
                                        ;   in Loop: Header=BB80_21 Depth=2
	b.ne	LBB80_19
LBB80_30:                               ; %bb5.i47.i
                                        ;   in Loop: Header=BB80_21 Depth=2
	and	x10, x10, x4
	orr	x10, x10, x3
	str	x10, [x9, #16]
	b	LBB80_19
LBB80_31:                               ; %bb23.i.us
                                        ; =>This Inner Loop Header: Depth=1
	b	LBB80_31
LBB80_32:                               ; %bb13.i
	mov	x0, x19
	bl	_free
	stp	x22, x25, [sp, #32]
	cbz	x22, LBB80_35
; %bb.33:                               ; %body.i.i.preheader
	mov	x19, #0                         ; =0x0
	add	x8, sp, #32
	add	x20, x8, #8
LBB80_34:                               ; %body.i.i
                                        ; =>This Inner Loop Header: Depth=1
	cmp	x19, #1
	csinc	x8, x19, xzr, lo
	sub	x8, x20, x8, lsl #3
	ldr	x0, [x8]
	bl	_free
	add	x19, x19, #1
	add	x20, x20, #8
	subs	x22, x22, #1
	b.ne	LBB80_34
LBB80_35:                               ; %wf.drop.run.707f874ef98d2803.exit.i
	mov	w0, #0                          ; =0x0
LBB80_36:                               ; %"wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
LBB80_37:                               ; %invalid.tag.b12.i
	bl	_abort
LBB80_38:                               ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_box_slots_new$instance$b1cfa6e689dc9e10 ; -- Begin function wf_box_slots_new$instance$b1cfa6e689dc9e10
	.p2align	2
_wf_box_slots_new$instance$b1cfa6e689dc9e10: ; @"wf_box_slots_new$instance$b1cfa6e689dc9e10"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB81_2
; %bb.1:                                ; %window.block.ready.v1
	stp	xzr, x19, [x0]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB81_2:                                ; %window.block.oom.v1
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_extend$instance$96033bf6ddb80743 ; -- Begin function wf_hash_map.hash_map_extend$instance$96033bf6ddb80743
	.p2align	2
_wf_hash_map.hash_map_extend$instance$96033bf6ddb80743: ; @"wf_hash_map.hash_map_extend$instance$96033bf6ddb80743"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x1
	ldr	x20, [x0]
	ldr	x8, [x20, #8]
	cmp	x8, x1
	b.hs	LBB82_4
; %bb.1:                                ; %bb2
	mov	x21, x0
	ldr	x23, [x20]
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	madd	x0, x19, x8, x9
	bl	_malloc
	cbz	x0, LBB82_8
; %bb.2:                                ; %"wf_grow$instance$b1cfa6e689dc9e10.exit"
	mov	x22, x0
	stp	x23, x19, [x0], #16
	add	x8, x23, x23, lsl #4
	lsl	x2, x8, #4
	add	x1, x20, #16
	bl	_memmove
	mov	x0, x20
	bl	_free
	str	x22, [x21]
	mov	x20, x22
	cmp	x23, x19
	b.lo	LBB82_5
LBB82_3:                                ; %bb7
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB82_4:                                ; %entry.bb1_crit_edge
	ldr	x23, [x20]
	cmp	x23, x19
	b.hs	LBB82_3
LBB82_5:                                ; %bb5.preheader
	mov	w8, #272                        ; =0x110
	madd	x8, x23, x8, x20
	add	x8, x8, #24
	movi.2d	v0, #0000000000000000
LBB82_6:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x8, #-8]
	add	x23, x23, #1
	stp	q0, q0, [x8]
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8, #64]
	stp	q0, q0, [x8, #96]
	stp	q0, q0, [x8, #128]
	stp	q0, q0, [x8, #160]
	stp	q0, q0, [x8, #192]
	stp	q0, q0, [x8, #224]
	str	xzr, [x8, #256]
	add	x8, x8, #272
	cmp	x19, x23
	b.ne	LBB82_6
; %bb.7:                                ; %bb4.bb7_crit_edge
	str	x23, [x20]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB82_8:                                ; %window.block.oom.v2.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_try_put$instance$8d5197e2f00c3b07 ; -- Begin function wf_hash_map.hash_map_try_put$instance$8d5197e2f00c3b07
	.p2align	2
_wf_hash_map.hash_map_try_put$instance$8d5197e2f00c3b07: ; @"wf_hash_map.hash_map_try_put$instance$8d5197e2f00c3b07"
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #528
	ldp	q0, q1, [x3, #192]
	stp	q0, q1, [sp, #464]
	ldp	q0, q1, [x3, #224]
	stp	q0, q1, [sp, #496]
	ldp	q0, q1, [x3, #128]
	stp	q0, q1, [sp, #400]
	ldp	q0, q1, [x3, #160]
	stp	q0, q1, [sp, #432]
	ldp	q0, q1, [x3, #64]
	stp	q0, q1, [sp, #336]
	ldp	q0, q1, [x3, #96]
	stp	q0, q1, [sp, #368]
	ldp	q0, q1, [x3]
	stp	q0, q1, [sp, #272]
	ldp	q0, q1, [x3, #32]
	stp	q0, q1, [sp, #304]
	ldrb	w8, [x4, #8]
	tbz	w8, #0, LBB83_81
; %bb.1:
	mov	x10, #0                         ; =0x0
	lsr	x21, x10, #57
	ldr	x9, [x1]
	ldr	x8, [x9]
	cbz	x8, LBB83_82
LBB83_2:                                ; %bb2
	udiv	x11, x10, x8
	msub	x10, x11, x8, x10
	mov	x11, #72340172838076673         ; =0x101010101010101
	mul	x11, x21, x11
	mov	w12, #1                         ; =0x1
	mov	w13, #8                         ; =0x8
	mov	x14, #-9187201950435737472      ; =0x8080808080808080
	ldp	x22, x23, [x1, #16]
	mov	x15, #9187201950435737471       ; =0x7f7f7f7f7f7f7f7f
	mov	w16, #272                       ; =0x110
	mov	x17, x8
	mov	x19, x8
LBB83_3:                                ; %bb10
                                        ; =>This Inner Loop Header: Depth=1
	and	x5, x10, #0x7
	sub	x3, x8, x10
	sub	x4, x13, x5
	cmp	x4, x3
	csel	x3, x4, x3, lo
	cmp	x3, x17
	csel	x3, x3, x17, lo
	cbz	x23, LBB83_6
; %bb.4:                                ; %bb3.i42
                                        ;   in Loop: Header=BB83_3 Depth=1
	lsr	x4, x10, #3
	ldr	x6, [x1, #32]
	ldr	x7, [x6]
	cmp	x4, x7
	b.hs	LBB83_7
; %bb.5:                                ; %bb8.i
                                        ;   in Loop: Header=BB83_3 Depth=1
	add	x4, x6, x4, lsl #3
	ldr	x6, [x4, #8]
	b	LBB83_8
LBB83_6:                                ; %bb2.i
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	x10, #8
	csel	x6, x22, x14, lo
	b	LBB83_8
LBB83_7:                                ; %bb9.i
                                        ;   in Loop: Header=BB83_3 Depth=1
	csel	x6, x22, x14, eq
LBB83_8:                                ; %wf_hash_map.hash_map_control_word.exit
                                        ;   in Loop: Header=BB83_3 Depth=1
	lsl	x4, x3, #3
	neg	x4, x4
	lsr	x4, x14, x4
	lsl	x7, x5, #3
	lsl	x7, x4, x7
	and	x4, x6, #0x7f7f7f7f7f7f7f7f
	add	x4, x4, x15
	orn	x4, x4, x6
	eor	x20, x4, #0x8080808080808080
	ands	x4, x20, x7
	b.eq	LBB83_60
; %bb.9:                                ; %bb2.i63
                                        ;   in Loop: Header=BB83_3 Depth=1
	rbit	x4, x4
	clz	x4, x4
	lsr	x4, x4, #3
	sub	x24, x4, x5
	cmp	x24, x3
	csel	x24, x24, x3, lo
	cmp	x4, x5
	csel	x4, x3, x24, lo
	cmp	x19, x8
	b.ne	LBB83_11
LBB83_10:                               ; %wf_hash_map.hash_map_control_stop.exit
                                        ;   in Loop: Header=BB83_3 Depth=1
	eor	x24, x6, #0xfefefefefefefefe
	and	x25, x24, #0x7f7f7f7f7f7f7f7f
	add	x25, x25, x15
	orr	x24, x25, x24
	orn	x20, x20, x24
	and	x20, x20, x7
	rbit	x24, x20
	clz	x24, x24
	lsr	x24, x24, #3
	sub	x25, x24, x5
	add	x26, x25, x10
	cmp	x25, x3
	csel	x25, x26, x8, lo
	cmp	x24, x5
	csel	x24, x8, x25, lo
	cmp	x20, #0
	csel	x19, x24, x19, ne
LBB83_11:                               ; %bb11
                                        ;   in Loop: Header=BB83_3 Depth=1
	eor	x6, x6, x11
	and	x20, x6, #0x7f7f7f7f7f7f7f7f
	add	x20, x20, x15
	orr	x6, x20, x6
	bic	x6, x7, x6
	cbz	x6, LBB83_63
; %bb.12:                               ; %bb29
                                        ;   in Loop: Header=BB83_3 Depth=1
	rbit	x7, x6
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB83_18
; %bb.13:                               ; %bb31
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	x7, x4
	b.hs	LBB83_18
; %bb.14:                               ; %bb34
                                        ;   in Loop: Header=BB83_3 Depth=1
	add	x20, x7, x10
	madd	x24, x20, x16, x9
	ldr	w25, [x24, #16]!
	cbz	w25, LBB83_61
; %bb.15:                               ; %bb34
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	w25, #1
	b.eq	LBB83_66
; %bb.16:                               ; %bb34
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	w25, #2
	b.ne	LBB83_93
; %bb.17:                               ; %bb3.i70
                                        ;   in Loop: Header=BB83_3 Depth=1
	ldr	x7, [x24, #8]
	cmp	x7, x2
	b.eq	LBB83_98
LBB83_18:                               ; %bb47
                                        ;   in Loop: Header=BB83_3 Depth=1
	sub	x7, x6, #1
	and	x6, x7, x6
	cbz	x6, LBB83_63
LBB83_19:                               ; %bb29.1
                                        ;   in Loop: Header=BB83_3 Depth=1
	rbit	x7, x6
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB83_25
; %bb.20:                               ; %bb31.1
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	x7, x4
	b.hs	LBB83_25
; %bb.21:                               ; %bb34.1
                                        ;   in Loop: Header=BB83_3 Depth=1
	add	x20, x7, x10
	madd	x24, x20, x16, x9
	ldr	w25, [x24, #16]!
	cbz	w25, LBB83_61
; %bb.22:                               ; %bb34.1
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	w25, #1
	b.eq	LBB83_67
; %bb.23:                               ; %bb34.1
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	w25, #2
	b.ne	LBB83_93
; %bb.24:                               ; %bb3.i70.1
                                        ;   in Loop: Header=BB83_3 Depth=1
	ldr	x7, [x24, #8]
	cmp	x7, x2
	b.eq	LBB83_98
LBB83_25:                               ; %bb47.1
                                        ;   in Loop: Header=BB83_3 Depth=1
	sub	x7, x6, #1
	and	x6, x7, x6
	cbz	x6, LBB83_63
LBB83_26:                               ; %bb29.2
                                        ;   in Loop: Header=BB83_3 Depth=1
	rbit	x7, x6
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB83_32
; %bb.27:                               ; %bb31.2
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	x7, x4
	b.hs	LBB83_32
; %bb.28:                               ; %bb34.2
                                        ;   in Loop: Header=BB83_3 Depth=1
	add	x20, x7, x10
	madd	x24, x20, x16, x9
	ldr	w25, [x24, #16]!
	cbz	w25, LBB83_61
; %bb.29:                               ; %bb34.2
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	w25, #1
	b.eq	LBB83_68
; %bb.30:                               ; %bb34.2
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	w25, #2
	b.ne	LBB83_93
; %bb.31:                               ; %bb3.i70.2
                                        ;   in Loop: Header=BB83_3 Depth=1
	ldr	x7, [x24, #8]
	cmp	x7, x2
	b.eq	LBB83_98
LBB83_32:                               ; %bb47.2
                                        ;   in Loop: Header=BB83_3 Depth=1
	sub	x7, x6, #1
	and	x6, x7, x6
	cbz	x6, LBB83_63
LBB83_33:                               ; %bb29.3
                                        ;   in Loop: Header=BB83_3 Depth=1
	rbit	x7, x6
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB83_39
; %bb.34:                               ; %bb31.3
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	x7, x4
	b.hs	LBB83_39
; %bb.35:                               ; %bb34.3
                                        ;   in Loop: Header=BB83_3 Depth=1
	add	x20, x7, x10
	madd	x24, x20, x16, x9
	ldr	w25, [x24, #16]!
	cbz	w25, LBB83_61
; %bb.36:                               ; %bb34.3
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	w25, #1
	b.eq	LBB83_69
; %bb.37:                               ; %bb34.3
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	w25, #2
	b.ne	LBB83_93
; %bb.38:                               ; %bb3.i70.3
                                        ;   in Loop: Header=BB83_3 Depth=1
	ldr	x7, [x24, #8]
	cmp	x7, x2
	b.eq	LBB83_98
LBB83_39:                               ; %bb47.3
                                        ;   in Loop: Header=BB83_3 Depth=1
	sub	x7, x6, #1
	and	x6, x7, x6
	cbz	x6, LBB83_63
LBB83_40:                               ; %bb29.4
                                        ;   in Loop: Header=BB83_3 Depth=1
	rbit	x7, x6
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB83_46
; %bb.41:                               ; %bb31.4
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	x7, x4
	b.hs	LBB83_46
; %bb.42:                               ; %bb34.4
                                        ;   in Loop: Header=BB83_3 Depth=1
	add	x20, x7, x10
	madd	x24, x20, x16, x9
	ldr	w25, [x24, #16]!
	cbz	w25, LBB83_61
; %bb.43:                               ; %bb34.4
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	w25, #1
	b.eq	LBB83_70
; %bb.44:                               ; %bb34.4
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	w25, #2
	b.ne	LBB83_93
; %bb.45:                               ; %bb3.i70.4
                                        ;   in Loop: Header=BB83_3 Depth=1
	ldr	x7, [x24, #8]
	cmp	x7, x2
	b.eq	LBB83_98
LBB83_46:                               ; %bb47.4
                                        ;   in Loop: Header=BB83_3 Depth=1
	sub	x7, x6, #1
	and	x6, x7, x6
	cbz	x6, LBB83_63
LBB83_47:                               ; %bb29.5
                                        ;   in Loop: Header=BB83_3 Depth=1
	rbit	x7, x6
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB83_53
; %bb.48:                               ; %bb31.5
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	x7, x4
	b.hs	LBB83_53
; %bb.49:                               ; %bb34.5
                                        ;   in Loop: Header=BB83_3 Depth=1
	add	x20, x7, x10
	madd	x24, x20, x16, x9
	ldr	w25, [x24, #16]!
	cbz	w25, LBB83_61
; %bb.50:                               ; %bb34.5
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	w25, #1
	b.eq	LBB83_71
; %bb.51:                               ; %bb34.5
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	w25, #2
	b.ne	LBB83_93
; %bb.52:                               ; %bb3.i70.5
                                        ;   in Loop: Header=BB83_3 Depth=1
	ldr	x7, [x24, #8]
	cmp	x7, x2
	b.eq	LBB83_98
LBB83_53:                               ; %bb47.5
                                        ;   in Loop: Header=BB83_3 Depth=1
	sub	x7, x6, #1
	and	x6, x7, x6
	cbz	x6, LBB83_63
LBB83_54:                               ; %bb29.6
                                        ;   in Loop: Header=BB83_3 Depth=1
	rbit	x7, x6
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB83_73
; %bb.55:                               ; %bb31.6
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	x7, x4
	b.hs	LBB83_73
; %bb.56:                               ; %bb34.6
                                        ;   in Loop: Header=BB83_3 Depth=1
	add	x20, x7, x10
	madd	x24, x20, x16, x9
	ldr	w25, [x24, #16]!
	cbz	w25, LBB83_61
; %bb.57:                               ; %bb34.6
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	w25, #1
	b.eq	LBB83_72
; %bb.58:                               ; %bb34.6
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	w25, #2
	b.ne	LBB83_93
; %bb.59:                               ; %bb3.i70.6
                                        ;   in Loop: Header=BB83_3 Depth=1
	ldr	x7, [x24, #8]
	cmp	x7, x2
	b.ne	LBB83_73
	b	LBB83_98
LBB83_60:                               ;   in Loop: Header=BB83_3 Depth=1
	mov	x4, x3
	cmp	x19, x8
	b.eq	LBB83_10
	b	LBB83_11
LBB83_61:                               ;   in Loop: Header=BB83_3 Depth=1
	mov	x4, x7
LBB83_62:                               ; %bb38
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	x19, x8
	csel	x19, x20, x19, eq
LBB83_63:                               ; %bb26
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	x4, x3
	b.lo	LBB83_83
; %bb.64:                               ; %bb50
                                        ;   in Loop: Header=BB83_3 Depth=1
	add	x10, x3, x10
	cmp	x10, x8
	csel	x10, x10, xzr, lo
	cmp	x12, x8
	b.hs	LBB83_83
; %bb.65:                               ; %bb50
                                        ;   in Loop: Header=BB83_3 Depth=1
	add	x12, x12, #1
	sub	x17, x17, x3
	cbnz	x17, LBB83_3
	b	LBB83_83
LBB83_66:                               ; %bb39
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	x19, x8
	csel	x19, x20, x19, eq
	sub	x7, x6, #1
	and	x6, x7, x6
	cbnz	x6, LBB83_19
	b	LBB83_63
LBB83_67:                               ; %bb39.1
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	x19, x8
	csel	x19, x20, x19, eq
	sub	x7, x6, #1
	and	x6, x7, x6
	cbnz	x6, LBB83_26
	b	LBB83_63
LBB83_68:                               ; %bb39.2
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	x19, x8
	csel	x19, x20, x19, eq
	sub	x7, x6, #1
	and	x6, x7, x6
	cbnz	x6, LBB83_33
	b	LBB83_63
LBB83_69:                               ; %bb39.3
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	x19, x8
	csel	x19, x20, x19, eq
	sub	x7, x6, #1
	and	x6, x7, x6
	cbnz	x6, LBB83_40
	b	LBB83_63
LBB83_70:                               ; %bb39.4
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	x19, x8
	csel	x19, x20, x19, eq
	sub	x7, x6, #1
	and	x6, x7, x6
	cbnz	x6, LBB83_47
	b	LBB83_63
LBB83_71:                               ; %bb39.5
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	x19, x8
	csel	x19, x20, x19, eq
	sub	x7, x6, #1
	and	x6, x7, x6
	cbnz	x6, LBB83_54
	b	LBB83_63
LBB83_72:                               ; %bb39.6
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	x19, x8
	csel	x19, x20, x19, eq
LBB83_73:                               ; %bb47.6
                                        ;   in Loop: Header=BB83_3 Depth=1
	sub	x7, x6, #1
	and	x6, x7, x6
	cbz	x6, LBB83_63
; %bb.74:                               ; %bb29.7
                                        ;   in Loop: Header=BB83_3 Depth=1
	rbit	x6, x6
	clz	x6, x6
	lsr	x6, x6, #3
	subs	x5, x6, x5
	b.lo	LBB83_63
; %bb.75:                               ; %bb31.7
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	x5, x4
	b.hs	LBB83_63
; %bb.76:                               ; %bb34.7
                                        ;   in Loop: Header=BB83_3 Depth=1
	add	x20, x5, x10
	madd	x6, x20, x16, x9
	ldr	w7, [x6, #16]!
	cbz	w7, LBB83_80
; %bb.77:                               ; %bb34.7
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	w7, #1
	b.eq	LBB83_62
; %bb.78:                               ; %bb34.7
                                        ;   in Loop: Header=BB83_3 Depth=1
	cmp	w7, #2
	b.ne	LBB83_93
; %bb.79:                               ; %bb3.i70.7
                                        ;   in Loop: Header=BB83_3 Depth=1
	ldr	x5, [x6, #8]
	cmp	x5, x2
	b.ne	LBB83_63
	b	LBB83_98
LBB83_80:                               ;   in Loop: Header=BB83_3 Depth=1
	mov	x4, x5
	b	LBB83_62
LBB83_81:                               ; %bb3.i
	ldr	x8, [x4]
	eor	x8, x8, x2
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x10, x8, x8, lsr #31
	lsr	x21, x10, #57
	ldr	x9, [x1]
	ldr	x8, [x9]
	cbnz	x8, LBB83_2
LBB83_82:
	mov	x19, #0                         ; =0x0
LBB83_83:                               ; %bb1
	cmp	x19, x8
	b.hs	LBB83_88
; %bb.84:                               ; %bb56
	ldr	x22, [x1, #8]
	cmp	x22, #2
	b.hi	LBB83_88
; %bb.85:                               ; %bb59
	mov	x23, x0
	mov	x0, sp
	add	x4, sp, #272
	mov	x20, x1
	mov	x3, x2
	mov	x2, x19
	bl	_wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449
	ubfiz	x8, x19, #3, #3
	mov	w9, #255                        ; =0xff
	lsl	x9, x9, x8
	mvn	x9, x9
	lsl	x8, x21, x8
	ldr	x10, [x20, #24]
	cbz	x10, LBB83_89
; %bb.86:                               ; %bb3.i94
	lsr	x10, x19, #3
	ldr	x11, [x20, #32]
	ldr	x12, [x11]
	cmp	x10, x12
	b.hs	LBB83_97
; %bb.87:                               ; %bb8.i105
	add	x10, x11, x10, lsl #3
	ldr	x11, [x10, #8]
	and	x9, x11, x9
	orr	x8, x9, x8
	str	x8, [x10, #8]
	mov	x0, x23
	b	LBB83_91
LBB83_88:                               ; %bb55
	stp	xzr, x2, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	strb	w8, [x0, #4]
	ldp	q0, q1, [sp, #272]
	stp	q0, q1, [x0, #16]
	ldp	q0, q1, [sp, #304]
	stp	q0, q1, [x0, #48]
	ldp	q0, q1, [sp, #336]
	stp	q0, q1, [x0, #80]
	ldp	q0, q1, [sp, #368]
	stp	q0, q1, [x0, #112]
	ldp	q0, q1, [sp, #400]
	stp	q0, q1, [x0, #144]
	ldp	q0, q1, [sp, #432]
	stp	q0, q1, [x0, #176]
	ldp	q0, q1, [sp, #464]
	stp	q0, q1, [x0, #208]
	ldp	q0, q1, [sp, #496]
	stp	q0, q1, [x0, #240]
	b	LBB83_96
LBB83_89:                               ; %bb2.i110
	cmp	x19, #8
	mov	x0, x23
	b.hs	LBB83_91
LBB83_90:                               ; %bb11.i101
	ldr	x10, [x20, #16]
	and	x9, x10, x9
	orr	x8, x9, x8
	str	x8, [x20, #16]
LBB83_91:                               ; %wf_hash_map.hash_map_control_set.exit116
	ldr	w8, [sp]
	cbz	w8, LBB83_94
; %bb.92:                               ; %wf_hash_map.hash_map_control_set.exit116
	cmp	w8, #1
	b.eq	LBB83_95
LBB83_93:                               ; %invalid.tag.b0.i
	bl	_abort
LBB83_94:                               ; %bb62
	add	x8, x22, #1
	str	x8, [x20, #8]
LBB83_95:                               ; %bb61
	mov	x1, sp
	mov	w2, #272                        ; =0x110
	bl	_memcpy
LBB83_96:                               ; %common.ret
	add	sp, sp, #528
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB83_97:                               ; %bb9.i99
	mov	x0, x23
	b.eq	LBB83_90
	b	LBB83_91
LBB83_98:                               ; %bb37
	add	x4, sp, #272
	mov	x19, x1
	mov	x3, x2
	mov	x2, x20
	bl	_wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449
	ubfiz	x8, x20, #3, #3
	mov	w9, #255                        ; =0xff
	lsl	x9, x9, x8
	mvn	x9, x9
	lsl	x8, x21, x8
	cbz	x23, LBB83_101
; %bb.99:                               ; %bb3.i79
	lsr	x10, x20, #3
	ldr	x11, [x19, #32]
	ldr	x12, [x11]
	cmp	x10, x12
	b.hs	LBB83_102
; %bb.100:                              ; %bb8.i82
	add	x10, x11, x10, lsl #3
	ldr	x11, [x10, #8]
	and	x9, x11, x9
	orr	x8, x9, x8
	str	x8, [x10, #8]
	b	LBB83_96
LBB83_101:                              ; %bb2.i83
	cmp	x20, #8
	b.hs	LBB83_96
	b	LBB83_103
LBB83_102:                              ; %bb9.i80
	b.ne	LBB83_96
LBB83_103:                              ; %bb5.i84
	and	x9, x22, x9
	orr	x8, x9, x8
	str	x8, [x19, #16]
	b	LBB83_96
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_reserve$instance$8d5197e2f00c3b07 ; -- Begin function wf_hash_map.hash_map_reserve$instance$8d5197e2f00c3b07
	.p2align	2
_wf_hash_map.hash_map_reserve$instance$8d5197e2f00c3b07: ; @"wf_hash_map.hash_map_reserve$instance$8d5197e2f00c3b07"
	.cfi_startproc
; %bb.0:                                ; %entry
	cmp	x1, #3
	b.ls	LBB84_2
; %bb.1:
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	ret
LBB84_2:                                ; %bb3.i
	ldr	x8, [x0]
	ldr	x8, [x8]
	cmp	x1, x8
	b.ls	LBB84_4
; %bb.3:                                ; %bb6.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_wf_hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB84_4:
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_extend$instance$0e108827ecbbe374 ; -- Begin function wf_hash_map.hash_map_extend$instance$0e108827ecbbe374
	.p2align	2
_wf_hash_map.hash_map_extend$instance$0e108827ecbbe374: ; @"wf_hash_map.hash_map_extend$instance$0e108827ecbbe374"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x1
	ldr	x20, [x0]
	ldr	x8, [x20, #8]
	cmp	x8, x1
	b.hs	LBB85_4
; %bb.1:                                ; %bb2
	mov	x21, x0
	ldr	x23, [x20]
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	madd	x0, x19, x8, x9
	bl	_malloc
	cbz	x0, LBB85_8
; %bb.2:                                ; %"wf_grow$instance$b1cfa6e689dc9e10.exit"
	mov	x22, x0
	stp	x23, x19, [x0], #16
	add	x8, x23, x23, lsl #4
	lsl	x2, x8, #4
	add	x1, x20, #16
	bl	_memmove
	mov	x0, x20
	bl	_free
	str	x22, [x21]
	mov	x20, x22
	cmp	x23, x19
	b.lo	LBB85_5
LBB85_3:                                ; %bb7
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB85_4:                                ; %entry.bb1_crit_edge
	ldr	x23, [x20]
	cmp	x23, x19
	b.hs	LBB85_3
LBB85_5:                                ; %bb5.preheader
	mov	w8, #272                        ; =0x110
	madd	x8, x23, x8, x20
	add	x8, x8, #24
	movi.2d	v0, #0000000000000000
LBB85_6:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x8, #-8]
	add	x23, x23, #1
	stp	q0, q0, [x8]
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8, #64]
	stp	q0, q0, [x8, #96]
	stp	q0, q0, [x8, #128]
	stp	q0, q0, [x8, #160]
	stp	q0, q0, [x8, #192]
	stp	q0, q0, [x8, #224]
	str	xzr, [x8, #256]
	add	x8, x8, #272
	cmp	x19, x23
	b.ne	LBB85_6
; %bb.7:                                ; %bb4.bb7_crit_edge
	str	x23, [x20]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB85_8:                                ; %window.block.oom.v2.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65 ; -- Begin function wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65
	.p2align	2
_wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65: ; @"wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65"
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #528
	ldp	q0, q1, [x3, #192]
	stp	q0, q1, [sp, #464]
	ldp	q0, q1, [x3, #224]
	stp	q0, q1, [sp, #496]
	ldp	q0, q1, [x3, #128]
	stp	q0, q1, [sp, #400]
	ldp	q0, q1, [x3, #160]
	stp	q0, q1, [sp, #432]
	ldp	q0, q1, [x3, #64]
	stp	q0, q1, [sp, #336]
	ldp	q0, q1, [x3, #96]
	stp	q0, q1, [sp, #368]
	ldp	q0, q1, [x3]
	stp	q0, q1, [sp, #272]
	ldp	q0, q1, [x3, #32]
	stp	q0, q1, [sp, #304]
	ldrb	w8, [x4, #8]
	tbz	w8, #0, LBB86_81
; %bb.1:
	mov	x10, #0                         ; =0x0
	lsr	x21, x10, #57
	ldr	x9, [x1]
	ldr	x8, [x9]
	cbz	x8, LBB86_82
LBB86_2:                                ; %bb2
	udiv	x11, x10, x8
	msub	x10, x11, x8, x10
	mov	x11, #72340172838076673         ; =0x101010101010101
	mul	x11, x21, x11
	mov	w12, #1                         ; =0x1
	mov	w13, #8                         ; =0x8
	mov	x14, #-9187201950435737472      ; =0x8080808080808080
	ldp	x22, x23, [x1, #16]
	mov	x15, #9187201950435737471       ; =0x7f7f7f7f7f7f7f7f
	mov	w16, #272                       ; =0x110
	mov	x17, x8
	mov	x19, x8
LBB86_3:                                ; %bb10
                                        ; =>This Inner Loop Header: Depth=1
	and	x5, x10, #0x7
	sub	x3, x8, x10
	sub	x4, x13, x5
	cmp	x4, x3
	csel	x3, x4, x3, lo
	cmp	x3, x17
	csel	x3, x3, x17, lo
	cbz	x23, LBB86_6
; %bb.4:                                ; %bb3.i42
                                        ;   in Loop: Header=BB86_3 Depth=1
	lsr	x4, x10, #3
	ldr	x6, [x1, #32]
	ldr	x7, [x6]
	cmp	x4, x7
	b.hs	LBB86_7
; %bb.5:                                ; %bb8.i
                                        ;   in Loop: Header=BB86_3 Depth=1
	add	x4, x6, x4, lsl #3
	ldr	x6, [x4, #8]
	b	LBB86_8
LBB86_6:                                ; %bb2.i
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	x10, #8
	csel	x6, x22, x14, lo
	b	LBB86_8
LBB86_7:                                ; %bb9.i
                                        ;   in Loop: Header=BB86_3 Depth=1
	csel	x6, x22, x14, eq
LBB86_8:                                ; %wf_hash_map.hash_map_control_word.exit
                                        ;   in Loop: Header=BB86_3 Depth=1
	lsl	x4, x3, #3
	neg	x4, x4
	lsr	x4, x14, x4
	lsl	x7, x5, #3
	lsl	x7, x4, x7
	and	x4, x6, #0x7f7f7f7f7f7f7f7f
	add	x4, x4, x15
	orn	x4, x4, x6
	eor	x20, x4, #0x8080808080808080
	ands	x4, x20, x7
	b.eq	LBB86_60
; %bb.9:                                ; %bb2.i63
                                        ;   in Loop: Header=BB86_3 Depth=1
	rbit	x4, x4
	clz	x4, x4
	lsr	x4, x4, #3
	sub	x24, x4, x5
	cmp	x24, x3
	csel	x24, x24, x3, lo
	cmp	x4, x5
	csel	x4, x3, x24, lo
	cmp	x19, x8
	b.ne	LBB86_11
LBB86_10:                               ; %wf_hash_map.hash_map_control_stop.exit
                                        ;   in Loop: Header=BB86_3 Depth=1
	eor	x24, x6, #0xfefefefefefefefe
	and	x25, x24, #0x7f7f7f7f7f7f7f7f
	add	x25, x25, x15
	orr	x24, x25, x24
	orn	x20, x20, x24
	and	x20, x20, x7
	rbit	x24, x20
	clz	x24, x24
	lsr	x24, x24, #3
	sub	x25, x24, x5
	add	x26, x25, x10
	cmp	x25, x3
	csel	x25, x26, x8, lo
	cmp	x24, x5
	csel	x24, x8, x25, lo
	cmp	x20, #0
	csel	x19, x24, x19, ne
LBB86_11:                               ; %bb11
                                        ;   in Loop: Header=BB86_3 Depth=1
	eor	x6, x6, x11
	and	x20, x6, #0x7f7f7f7f7f7f7f7f
	add	x20, x20, x15
	orr	x6, x20, x6
	bic	x6, x7, x6
	cbz	x6, LBB86_63
; %bb.12:                               ; %bb29
                                        ;   in Loop: Header=BB86_3 Depth=1
	rbit	x7, x6
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB86_18
; %bb.13:                               ; %bb31
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	x7, x4
	b.hs	LBB86_18
; %bb.14:                               ; %bb34
                                        ;   in Loop: Header=BB86_3 Depth=1
	add	x20, x7, x10
	madd	x24, x20, x16, x9
	ldr	w25, [x24, #16]!
	cbz	w25, LBB86_61
; %bb.15:                               ; %bb34
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	w25, #1
	b.eq	LBB86_66
; %bb.16:                               ; %bb34
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	w25, #2
	b.ne	LBB86_93
; %bb.17:                               ; %bb3.i70
                                        ;   in Loop: Header=BB86_3 Depth=1
	ldr	x7, [x24, #8]
	cmp	x7, x2
	b.eq	LBB86_98
LBB86_18:                               ; %bb47
                                        ;   in Loop: Header=BB86_3 Depth=1
	sub	x7, x6, #1
	and	x6, x7, x6
	cbz	x6, LBB86_63
LBB86_19:                               ; %bb29.1
                                        ;   in Loop: Header=BB86_3 Depth=1
	rbit	x7, x6
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB86_25
; %bb.20:                               ; %bb31.1
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	x7, x4
	b.hs	LBB86_25
; %bb.21:                               ; %bb34.1
                                        ;   in Loop: Header=BB86_3 Depth=1
	add	x20, x7, x10
	madd	x24, x20, x16, x9
	ldr	w25, [x24, #16]!
	cbz	w25, LBB86_61
; %bb.22:                               ; %bb34.1
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	w25, #1
	b.eq	LBB86_67
; %bb.23:                               ; %bb34.1
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	w25, #2
	b.ne	LBB86_93
; %bb.24:                               ; %bb3.i70.1
                                        ;   in Loop: Header=BB86_3 Depth=1
	ldr	x7, [x24, #8]
	cmp	x7, x2
	b.eq	LBB86_98
LBB86_25:                               ; %bb47.1
                                        ;   in Loop: Header=BB86_3 Depth=1
	sub	x7, x6, #1
	and	x6, x7, x6
	cbz	x6, LBB86_63
LBB86_26:                               ; %bb29.2
                                        ;   in Loop: Header=BB86_3 Depth=1
	rbit	x7, x6
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB86_32
; %bb.27:                               ; %bb31.2
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	x7, x4
	b.hs	LBB86_32
; %bb.28:                               ; %bb34.2
                                        ;   in Loop: Header=BB86_3 Depth=1
	add	x20, x7, x10
	madd	x24, x20, x16, x9
	ldr	w25, [x24, #16]!
	cbz	w25, LBB86_61
; %bb.29:                               ; %bb34.2
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	w25, #1
	b.eq	LBB86_68
; %bb.30:                               ; %bb34.2
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	w25, #2
	b.ne	LBB86_93
; %bb.31:                               ; %bb3.i70.2
                                        ;   in Loop: Header=BB86_3 Depth=1
	ldr	x7, [x24, #8]
	cmp	x7, x2
	b.eq	LBB86_98
LBB86_32:                               ; %bb47.2
                                        ;   in Loop: Header=BB86_3 Depth=1
	sub	x7, x6, #1
	and	x6, x7, x6
	cbz	x6, LBB86_63
LBB86_33:                               ; %bb29.3
                                        ;   in Loop: Header=BB86_3 Depth=1
	rbit	x7, x6
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB86_39
; %bb.34:                               ; %bb31.3
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	x7, x4
	b.hs	LBB86_39
; %bb.35:                               ; %bb34.3
                                        ;   in Loop: Header=BB86_3 Depth=1
	add	x20, x7, x10
	madd	x24, x20, x16, x9
	ldr	w25, [x24, #16]!
	cbz	w25, LBB86_61
; %bb.36:                               ; %bb34.3
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	w25, #1
	b.eq	LBB86_69
; %bb.37:                               ; %bb34.3
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	w25, #2
	b.ne	LBB86_93
; %bb.38:                               ; %bb3.i70.3
                                        ;   in Loop: Header=BB86_3 Depth=1
	ldr	x7, [x24, #8]
	cmp	x7, x2
	b.eq	LBB86_98
LBB86_39:                               ; %bb47.3
                                        ;   in Loop: Header=BB86_3 Depth=1
	sub	x7, x6, #1
	and	x6, x7, x6
	cbz	x6, LBB86_63
LBB86_40:                               ; %bb29.4
                                        ;   in Loop: Header=BB86_3 Depth=1
	rbit	x7, x6
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB86_46
; %bb.41:                               ; %bb31.4
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	x7, x4
	b.hs	LBB86_46
; %bb.42:                               ; %bb34.4
                                        ;   in Loop: Header=BB86_3 Depth=1
	add	x20, x7, x10
	madd	x24, x20, x16, x9
	ldr	w25, [x24, #16]!
	cbz	w25, LBB86_61
; %bb.43:                               ; %bb34.4
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	w25, #1
	b.eq	LBB86_70
; %bb.44:                               ; %bb34.4
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	w25, #2
	b.ne	LBB86_93
; %bb.45:                               ; %bb3.i70.4
                                        ;   in Loop: Header=BB86_3 Depth=1
	ldr	x7, [x24, #8]
	cmp	x7, x2
	b.eq	LBB86_98
LBB86_46:                               ; %bb47.4
                                        ;   in Loop: Header=BB86_3 Depth=1
	sub	x7, x6, #1
	and	x6, x7, x6
	cbz	x6, LBB86_63
LBB86_47:                               ; %bb29.5
                                        ;   in Loop: Header=BB86_3 Depth=1
	rbit	x7, x6
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB86_53
; %bb.48:                               ; %bb31.5
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	x7, x4
	b.hs	LBB86_53
; %bb.49:                               ; %bb34.5
                                        ;   in Loop: Header=BB86_3 Depth=1
	add	x20, x7, x10
	madd	x24, x20, x16, x9
	ldr	w25, [x24, #16]!
	cbz	w25, LBB86_61
; %bb.50:                               ; %bb34.5
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	w25, #1
	b.eq	LBB86_71
; %bb.51:                               ; %bb34.5
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	w25, #2
	b.ne	LBB86_93
; %bb.52:                               ; %bb3.i70.5
                                        ;   in Loop: Header=BB86_3 Depth=1
	ldr	x7, [x24, #8]
	cmp	x7, x2
	b.eq	LBB86_98
LBB86_53:                               ; %bb47.5
                                        ;   in Loop: Header=BB86_3 Depth=1
	sub	x7, x6, #1
	and	x6, x7, x6
	cbz	x6, LBB86_63
LBB86_54:                               ; %bb29.6
                                        ;   in Loop: Header=BB86_3 Depth=1
	rbit	x7, x6
	clz	x7, x7
	lsr	x7, x7, #3
	subs	x7, x7, x5
	b.lo	LBB86_73
; %bb.55:                               ; %bb31.6
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	x7, x4
	b.hs	LBB86_73
; %bb.56:                               ; %bb34.6
                                        ;   in Loop: Header=BB86_3 Depth=1
	add	x20, x7, x10
	madd	x24, x20, x16, x9
	ldr	w25, [x24, #16]!
	cbz	w25, LBB86_61
; %bb.57:                               ; %bb34.6
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	w25, #1
	b.eq	LBB86_72
; %bb.58:                               ; %bb34.6
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	w25, #2
	b.ne	LBB86_93
; %bb.59:                               ; %bb3.i70.6
                                        ;   in Loop: Header=BB86_3 Depth=1
	ldr	x7, [x24, #8]
	cmp	x7, x2
	b.ne	LBB86_73
	b	LBB86_98
LBB86_60:                               ;   in Loop: Header=BB86_3 Depth=1
	mov	x4, x3
	cmp	x19, x8
	b.eq	LBB86_10
	b	LBB86_11
LBB86_61:                               ;   in Loop: Header=BB86_3 Depth=1
	mov	x4, x7
LBB86_62:                               ; %bb38
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	x19, x8
	csel	x19, x20, x19, eq
LBB86_63:                               ; %bb26
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	x4, x3
	b.lo	LBB86_83
; %bb.64:                               ; %bb50
                                        ;   in Loop: Header=BB86_3 Depth=1
	add	x10, x3, x10
	cmp	x10, x8
	csel	x10, x10, xzr, lo
	cmp	x12, x8
	b.hs	LBB86_83
; %bb.65:                               ; %bb50
                                        ;   in Loop: Header=BB86_3 Depth=1
	add	x12, x12, #1
	sub	x17, x17, x3
	cbnz	x17, LBB86_3
	b	LBB86_83
LBB86_66:                               ; %bb39
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	x19, x8
	csel	x19, x20, x19, eq
	sub	x7, x6, #1
	and	x6, x7, x6
	cbnz	x6, LBB86_19
	b	LBB86_63
LBB86_67:                               ; %bb39.1
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	x19, x8
	csel	x19, x20, x19, eq
	sub	x7, x6, #1
	and	x6, x7, x6
	cbnz	x6, LBB86_26
	b	LBB86_63
LBB86_68:                               ; %bb39.2
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	x19, x8
	csel	x19, x20, x19, eq
	sub	x7, x6, #1
	and	x6, x7, x6
	cbnz	x6, LBB86_33
	b	LBB86_63
LBB86_69:                               ; %bb39.3
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	x19, x8
	csel	x19, x20, x19, eq
	sub	x7, x6, #1
	and	x6, x7, x6
	cbnz	x6, LBB86_40
	b	LBB86_63
LBB86_70:                               ; %bb39.4
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	x19, x8
	csel	x19, x20, x19, eq
	sub	x7, x6, #1
	and	x6, x7, x6
	cbnz	x6, LBB86_47
	b	LBB86_63
LBB86_71:                               ; %bb39.5
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	x19, x8
	csel	x19, x20, x19, eq
	sub	x7, x6, #1
	and	x6, x7, x6
	cbnz	x6, LBB86_54
	b	LBB86_63
LBB86_72:                               ; %bb39.6
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	x19, x8
	csel	x19, x20, x19, eq
LBB86_73:                               ; %bb47.6
                                        ;   in Loop: Header=BB86_3 Depth=1
	sub	x7, x6, #1
	and	x6, x7, x6
	cbz	x6, LBB86_63
; %bb.74:                               ; %bb29.7
                                        ;   in Loop: Header=BB86_3 Depth=1
	rbit	x6, x6
	clz	x6, x6
	lsr	x6, x6, #3
	subs	x5, x6, x5
	b.lo	LBB86_63
; %bb.75:                               ; %bb31.7
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	x5, x4
	b.hs	LBB86_63
; %bb.76:                               ; %bb34.7
                                        ;   in Loop: Header=BB86_3 Depth=1
	add	x20, x5, x10
	madd	x6, x20, x16, x9
	ldr	w7, [x6, #16]!
	cbz	w7, LBB86_80
; %bb.77:                               ; %bb34.7
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	w7, #1
	b.eq	LBB86_62
; %bb.78:                               ; %bb34.7
                                        ;   in Loop: Header=BB86_3 Depth=1
	cmp	w7, #2
	b.ne	LBB86_93
; %bb.79:                               ; %bb3.i70.7
                                        ;   in Loop: Header=BB86_3 Depth=1
	ldr	x5, [x6, #8]
	cmp	x5, x2
	b.ne	LBB86_63
	b	LBB86_98
LBB86_80:                               ;   in Loop: Header=BB86_3 Depth=1
	mov	x4, x5
	b	LBB86_62
LBB86_81:                               ; %bb3.i
	ldr	x8, [x4]
	eor	x8, x8, x2
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x10, x8, x8, lsr #31
	lsr	x21, x10, #57
	ldr	x9, [x1]
	ldr	x8, [x9]
	cbnz	x8, LBB86_2
LBB86_82:
	mov	x19, #0                         ; =0x0
LBB86_83:                               ; %bb1
	cmp	x19, x8
	b.hs	LBB86_88
; %bb.84:                               ; %bb56
	ldr	x22, [x1, #8]
	lsr	x8, x22, #14
	cbnz	x8, LBB86_88
; %bb.85:                               ; %bb59
	mov	x23, x0
	mov	x0, sp
	add	x4, sp, #272
	mov	x20, x1
	mov	x3, x2
	mov	x2, x19
	bl	_wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449
	ubfiz	x8, x19, #3, #3
	mov	w9, #255                        ; =0xff
	lsl	x9, x9, x8
	mvn	x9, x9
	lsl	x8, x21, x8
	ldr	x10, [x20, #24]
	cbz	x10, LBB86_89
; %bb.86:                               ; %bb3.i94
	lsr	x10, x19, #3
	ldr	x11, [x20, #32]
	ldr	x12, [x11]
	cmp	x10, x12
	b.hs	LBB86_97
; %bb.87:                               ; %bb8.i105
	add	x10, x11, x10, lsl #3
	ldr	x11, [x10, #8]
	and	x9, x11, x9
	orr	x8, x9, x8
	str	x8, [x10, #8]
	mov	x0, x23
	b	LBB86_91
LBB86_88:                               ; %bb55
	stp	xzr, x2, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	strb	w8, [x0, #4]
	ldp	q0, q1, [sp, #272]
	stp	q0, q1, [x0, #16]
	ldp	q0, q1, [sp, #304]
	stp	q0, q1, [x0, #48]
	ldp	q0, q1, [sp, #336]
	stp	q0, q1, [x0, #80]
	ldp	q0, q1, [sp, #368]
	stp	q0, q1, [x0, #112]
	ldp	q0, q1, [sp, #400]
	stp	q0, q1, [x0, #144]
	ldp	q0, q1, [sp, #432]
	stp	q0, q1, [x0, #176]
	ldp	q0, q1, [sp, #464]
	stp	q0, q1, [x0, #208]
	ldp	q0, q1, [sp, #496]
	stp	q0, q1, [x0, #240]
	b	LBB86_96
LBB86_89:                               ; %bb2.i110
	cmp	x19, #8
	mov	x0, x23
	b.hs	LBB86_91
LBB86_90:                               ; %bb11.i101
	ldr	x10, [x20, #16]
	and	x9, x10, x9
	orr	x8, x9, x8
	str	x8, [x20, #16]
LBB86_91:                               ; %wf_hash_map.hash_map_control_set.exit116
	ldr	w8, [sp]
	cbz	w8, LBB86_94
; %bb.92:                               ; %wf_hash_map.hash_map_control_set.exit116
	cmp	w8, #1
	b.eq	LBB86_95
LBB86_93:                               ; %invalid.tag.b0.i
	bl	_abort
LBB86_94:                               ; %bb62
	add	x8, x22, #1
	str	x8, [x20, #8]
LBB86_95:                               ; %bb61
	mov	x1, sp
	mov	w2, #272                        ; =0x110
	bl	_memcpy
LBB86_96:                               ; %common.ret
	add	sp, sp, #528
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB86_97:                               ; %bb9.i99
	mov	x0, x23
	b.eq	LBB86_90
	b	LBB86_91
LBB86_98:                               ; %bb37
	add	x4, sp, #272
	mov	x19, x1
	mov	x3, x2
	mov	x2, x20
	bl	_wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449
	ubfiz	x8, x20, #3, #3
	mov	w9, #255                        ; =0xff
	lsl	x9, x9, x8
	mvn	x9, x9
	lsl	x8, x21, x8
	cbz	x23, LBB86_101
; %bb.99:                               ; %bb3.i79
	lsr	x10, x20, #3
	ldr	x11, [x19, #32]
	ldr	x12, [x11]
	cmp	x10, x12
	b.hs	LBB86_102
; %bb.100:                              ; %bb8.i82
	add	x10, x11, x10, lsl #3
	ldr	x11, [x10, #8]
	and	x9, x11, x9
	orr	x8, x9, x8
	str	x8, [x10, #8]
	b	LBB86_96
LBB86_101:                              ; %bb2.i83
	cmp	x20, #8
	b.hs	LBB86_96
	b	LBB86_103
LBB86_102:                              ; %bb9.i80
	b.ne	LBB86_96
LBB86_103:                              ; %bb5.i84
	and	x9, x22, x9
	orr	x8, x9, x8
	str	x8, [x19, #16]
	b	LBB86_96
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_find$instance$28da32efc51c2b65 ; -- Begin function wf_hash_map.hash_map_find$instance$28da32efc51c2b65
	.p2align	2
_wf_hash_map.hash_map_find$instance$28da32efc51c2b65: ; @"wf_hash_map.hash_map_find$instance$28da32efc51c2b65"
; %bb.0:                                ; %entry
	stp	x22, x21, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	ldrb	w8, [x2, #8]
	tbz	w8, #0, LBB87_2
; %bb.1:
	mov	x8, #0                          ; =0x0
	ldr	x10, [x0]
	ldr	x11, [x10]
	cbnz	x11, LBB87_3
	b	LBB87_63
LBB87_2:                                ; %bb3.i.i
	ldr	x8, [x2]
	ldr	x9, [x1]
	eor	x8, x9, x8
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #31
	ldr	x10, [x0]
	ldr	x11, [x10]
	cbz	x11, LBB87_63
LBB87_3:                                ; %bb3.i
	lsr	x9, x8, #57
	udiv	x12, x8, x11
	msub	x12, x12, x11, x8
	mov	x8, #72340172838076673          ; =0x101010101010101
	mul	x13, x9, x8
	mov	w14, #1                         ; =0x1
	mov	w15, #8                         ; =0x8
	ldp	x17, x16, [x0, #16]
	mov	x2, #-9187201950435737472       ; =0x8080808080808080
	mov	x3, #9187201950435737471        ; =0x7f7f7f7f7f7f7f7f
	mov	w4, #272                        ; =0x110
	mov	x5, x11
LBB87_4:                                ; %bb10.i
                                        ; =>This Inner Loop Header: Depth=1
	and	x9, x12, #0x7
	sub	x8, x11, x12
	sub	x6, x15, x9
	cmp	x6, x8
	csel	x8, x6, x8, lo
	cmp	x8, x5
	csel	x6, x8, x5, lo
	cbz	x16, LBB87_7
; %bb.5:                                ; %bb3.i21.i
                                        ;   in Loop: Header=BB87_4 Depth=1
	lsr	x8, x12, #3
	ldr	x7, [x0, #32]
	ldr	x19, [x7]
	cmp	x8, x19
	b.hs	LBB87_8
; %bb.6:                                ; %bb8.i.i
                                        ;   in Loop: Header=BB87_4 Depth=1
	add	x8, x7, x8, lsl #3
	ldr	x8, [x8, #8]
	b	LBB87_9
LBB87_7:                                ; %bb2.i.i
                                        ;   in Loop: Header=BB87_4 Depth=1
	cmp	x12, #8
	csel	x8, x17, x2, lo
	b	LBB87_9
LBB87_8:                                ; %bb9.i.i
                                        ;   in Loop: Header=BB87_4 Depth=1
	csel	x8, x17, x2, eq
LBB87_9:                                ; %wf_hash_map.hash_map_control_word.exit.i
                                        ;   in Loop: Header=BB87_4 Depth=1
	lsl	x7, x6, #3
	neg	x7, x7
	lsr	x7, x2, x7
	lsl	x19, x9, #3
	lsl	x19, x7, x19
	and	x7, x8, #0x7f7f7f7f7f7f7f7f
	sub	x7, x2, x7
	and	x7, x7, x8
	and	x7, x19, x7
	cmp	x7, #0
	rbit	x7, x7
	clz	x7, x7
	lsr	x20, x7, #3
	ccmp	x20, x9, #0, ne
	mov	x7, x6
	b.hs	LBB87_11
; %bb.10:                               ; %wf_hash_map.hash_map_control_stop.exit.i
                                        ;   in Loop: Header=BB87_4 Depth=1
	eor	x8, x8, x13
	and	x20, x8, #0x7f7f7f7f7f7f7f7f
	add	x20, x20, x3
	orr	x8, x20, x8
	bic	x19, x19, x8
	cbnz	x19, LBB87_12
	b	LBB87_59
LBB87_11:                               ; %bb5.i.i
                                        ;   in Loop: Header=BB87_4 Depth=1
	sub	x7, x20, x9
	cmp	x7, x6
	csel	x7, x7, x6, lo
	eor	x8, x8, x13
	and	x20, x8, #0x7f7f7f7f7f7f7f7f
	add	x20, x20, x3
	orr	x8, x20, x8
	bic	x19, x19, x8
	cbz	x19, LBB87_59
LBB87_12:                               ; %bb17.i
                                        ;   in Loop: Header=BB87_4 Depth=1
	rbit	x8, x19
	clz	x8, x8
	lsr	x8, x8, #3
	subs	x8, x8, x9
	b.lo	LBB87_17
; %bb.13:                               ; %bb19.i
                                        ;   in Loop: Header=BB87_4 Depth=1
	cmp	x8, x7
	b.hs	LBB87_17
; %bb.14:                               ; %bb22.i
                                        ;   in Loop: Header=BB87_4 Depth=1
	add	x20, x8, x12
	madd	x21, x20, x4, x10
	ldr	w8, [x21, #16]!
	cmp	w8, #1
	b.eq	LBB87_17
; %bb.15:                               ; %bb22.i
                                        ;   in Loop: Header=BB87_4 Depth=1
	cmp	w8, #2
	b.ne	LBB87_65
; %bb.16:                               ; %bb25.i
                                        ;   in Loop: Header=BB87_4 Depth=1
	ldr	x8, [x21, #8]
	ldr	x21, [x1]
	cmp	x8, x21
	b.eq	LBB87_67
LBB87_17:                               ; %bb31.i
                                        ;   in Loop: Header=BB87_4 Depth=1
	sub	x8, x19, #1
	and	x19, x8, x19
	cbz	x19, LBB87_59
; %bb.18:                               ; %bb17.i.1
                                        ;   in Loop: Header=BB87_4 Depth=1
	rbit	x8, x19
	clz	x8, x8
	lsr	x8, x8, #3
	subs	x8, x8, x9
	b.lo	LBB87_23
; %bb.19:                               ; %bb19.i.1
                                        ;   in Loop: Header=BB87_4 Depth=1
	cmp	x8, x7
	b.hs	LBB87_23
; %bb.20:                               ; %bb22.i.1
                                        ;   in Loop: Header=BB87_4 Depth=1
	add	x20, x8, x12
	madd	x21, x20, x4, x10
	ldr	w8, [x21, #16]!
	cmp	w8, #1
	b.eq	LBB87_23
; %bb.21:                               ; %bb22.i.1
                                        ;   in Loop: Header=BB87_4 Depth=1
	cmp	w8, #2
	b.ne	LBB87_65
; %bb.22:                               ; %bb25.i.1
                                        ;   in Loop: Header=BB87_4 Depth=1
	ldr	x8, [x21, #8]
	ldr	x21, [x1]
	cmp	x8, x21
	b.eq	LBB87_67
LBB87_23:                               ; %bb31.i.1
                                        ;   in Loop: Header=BB87_4 Depth=1
	sub	x8, x19, #1
	and	x19, x8, x19
	cbz	x19, LBB87_59
; %bb.24:                               ; %bb17.i.2
                                        ;   in Loop: Header=BB87_4 Depth=1
	rbit	x8, x19
	clz	x8, x8
	lsr	x8, x8, #3
	subs	x8, x8, x9
	b.lo	LBB87_29
; %bb.25:                               ; %bb19.i.2
                                        ;   in Loop: Header=BB87_4 Depth=1
	cmp	x8, x7
	b.hs	LBB87_29
; %bb.26:                               ; %bb22.i.2
                                        ;   in Loop: Header=BB87_4 Depth=1
	add	x20, x8, x12
	madd	x21, x20, x4, x10
	ldr	w8, [x21, #16]!
	cmp	w8, #1
	b.eq	LBB87_29
; %bb.27:                               ; %bb22.i.2
                                        ;   in Loop: Header=BB87_4 Depth=1
	cmp	w8, #2
	b.ne	LBB87_65
; %bb.28:                               ; %bb25.i.2
                                        ;   in Loop: Header=BB87_4 Depth=1
	ldr	x8, [x21, #8]
	ldr	x21, [x1]
	cmp	x8, x21
	b.eq	LBB87_67
LBB87_29:                               ; %bb31.i.2
                                        ;   in Loop: Header=BB87_4 Depth=1
	sub	x8, x19, #1
	and	x19, x8, x19
	cbz	x19, LBB87_59
; %bb.30:                               ; %bb17.i.3
                                        ;   in Loop: Header=BB87_4 Depth=1
	rbit	x8, x19
	clz	x8, x8
	lsr	x8, x8, #3
	subs	x8, x8, x9
	b.lo	LBB87_35
; %bb.31:                               ; %bb19.i.3
                                        ;   in Loop: Header=BB87_4 Depth=1
	cmp	x8, x7
	b.hs	LBB87_35
; %bb.32:                               ; %bb22.i.3
                                        ;   in Loop: Header=BB87_4 Depth=1
	add	x20, x8, x12
	madd	x21, x20, x4, x10
	ldr	w8, [x21, #16]!
	cmp	w8, #1
	b.eq	LBB87_35
; %bb.33:                               ; %bb22.i.3
                                        ;   in Loop: Header=BB87_4 Depth=1
	cmp	w8, #2
	b.ne	LBB87_65
; %bb.34:                               ; %bb25.i.3
                                        ;   in Loop: Header=BB87_4 Depth=1
	ldr	x8, [x21, #8]
	ldr	x21, [x1]
	cmp	x8, x21
	b.eq	LBB87_67
LBB87_35:                               ; %bb31.i.3
                                        ;   in Loop: Header=BB87_4 Depth=1
	sub	x8, x19, #1
	and	x19, x8, x19
	cbz	x19, LBB87_59
; %bb.36:                               ; %bb17.i.4
                                        ;   in Loop: Header=BB87_4 Depth=1
	rbit	x8, x19
	clz	x8, x8
	lsr	x8, x8, #3
	subs	x8, x8, x9
	b.lo	LBB87_41
; %bb.37:                               ; %bb19.i.4
                                        ;   in Loop: Header=BB87_4 Depth=1
	cmp	x8, x7
	b.hs	LBB87_41
; %bb.38:                               ; %bb22.i.4
                                        ;   in Loop: Header=BB87_4 Depth=1
	add	x20, x8, x12
	madd	x21, x20, x4, x10
	ldr	w8, [x21, #16]!
	cmp	w8, #1
	b.eq	LBB87_41
; %bb.39:                               ; %bb22.i.4
                                        ;   in Loop: Header=BB87_4 Depth=1
	cmp	w8, #2
	b.ne	LBB87_65
; %bb.40:                               ; %bb25.i.4
                                        ;   in Loop: Header=BB87_4 Depth=1
	ldr	x8, [x21, #8]
	ldr	x21, [x1]
	cmp	x8, x21
	b.eq	LBB87_67
LBB87_41:                               ; %bb31.i.4
                                        ;   in Loop: Header=BB87_4 Depth=1
	sub	x8, x19, #1
	and	x19, x8, x19
	cbz	x19, LBB87_59
; %bb.42:                               ; %bb17.i.5
                                        ;   in Loop: Header=BB87_4 Depth=1
	rbit	x8, x19
	clz	x8, x8
	lsr	x8, x8, #3
	subs	x8, x8, x9
	b.lo	LBB87_47
; %bb.43:                               ; %bb19.i.5
                                        ;   in Loop: Header=BB87_4 Depth=1
	cmp	x8, x7
	b.hs	LBB87_47
; %bb.44:                               ; %bb22.i.5
                                        ;   in Loop: Header=BB87_4 Depth=1
	add	x20, x8, x12
	madd	x21, x20, x4, x10
	ldr	w8, [x21, #16]!
	cmp	w8, #1
	b.eq	LBB87_47
; %bb.45:                               ; %bb22.i.5
                                        ;   in Loop: Header=BB87_4 Depth=1
	cmp	w8, #2
	b.ne	LBB87_65
; %bb.46:                               ; %bb25.i.5
                                        ;   in Loop: Header=BB87_4 Depth=1
	ldr	x8, [x21, #8]
	ldr	x21, [x1]
	cmp	x8, x21
	b.eq	LBB87_67
LBB87_47:                               ; %bb31.i.5
                                        ;   in Loop: Header=BB87_4 Depth=1
	sub	x8, x19, #1
	and	x19, x8, x19
	cbz	x19, LBB87_59
; %bb.48:                               ; %bb17.i.6
                                        ;   in Loop: Header=BB87_4 Depth=1
	rbit	x8, x19
	clz	x8, x8
	lsr	x8, x8, #3
	subs	x8, x8, x9
	b.lo	LBB87_53
; %bb.49:                               ; %bb19.i.6
                                        ;   in Loop: Header=BB87_4 Depth=1
	cmp	x8, x7
	b.hs	LBB87_53
; %bb.50:                               ; %bb22.i.6
                                        ;   in Loop: Header=BB87_4 Depth=1
	add	x20, x8, x12
	madd	x21, x20, x4, x10
	ldr	w8, [x21, #16]!
	cmp	w8, #1
	b.eq	LBB87_53
; %bb.51:                               ; %bb22.i.6
                                        ;   in Loop: Header=BB87_4 Depth=1
	cmp	w8, #2
	b.ne	LBB87_65
; %bb.52:                               ; %bb25.i.6
                                        ;   in Loop: Header=BB87_4 Depth=1
	ldr	x8, [x21, #8]
	ldr	x21, [x1]
	cmp	x8, x21
	b.eq	LBB87_67
LBB87_53:                               ; %bb31.i.6
                                        ;   in Loop: Header=BB87_4 Depth=1
	sub	x8, x19, #1
	and	x8, x8, x19
	cbz	x8, LBB87_59
; %bb.54:                               ; %bb17.i.7
                                        ;   in Loop: Header=BB87_4 Depth=1
	rbit	x8, x8
	clz	x8, x8
	lsr	x8, x8, #3
	subs	x8, x8, x9
	b.lo	LBB87_59
; %bb.55:                               ; %bb19.i.7
                                        ;   in Loop: Header=BB87_4 Depth=1
	cmp	x8, x7
	b.hs	LBB87_59
; %bb.56:                               ; %bb22.i.7
                                        ;   in Loop: Header=BB87_4 Depth=1
	add	x19, x8, x12
	madd	x9, x19, x4, x10
	ldr	w8, [x9, #16]!
	cmp	w8, #1
	b.eq	LBB87_59
; %bb.57:                               ; %bb22.i.7
                                        ;   in Loop: Header=BB87_4 Depth=1
	cmp	w8, #2
	b.ne	LBB87_65
; %bb.58:                               ; %bb25.i.7
                                        ;   in Loop: Header=BB87_4 Depth=1
	ldr	x8, [x9, #8]
	ldr	x9, [x1]
	cmp	x8, x9
	b.eq	LBB87_68
LBB87_59:                               ; %bb14.i
                                        ;   in Loop: Header=BB87_4 Depth=1
	cmp	x7, x6
	b.lo	LBB87_63
; %bb.60:                               ; %bb34.i
                                        ;   in Loop: Header=BB87_4 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x6, x12
	cmp	x9, x11
	csel	x12, x9, xzr, lo
	mov	w9, #1                          ; =0x1
	cmp	x14, x11
	b.hs	LBB87_62
; %bb.61:                               ; %bb34.i
                                        ;   in Loop: Header=BB87_4 Depth=1
	add	x14, x14, #1
	sub	x5, x5, x6
	cbnz	x5, LBB87_4
LBB87_62:                               ; %"wf_hash_map.hash_map_find$instance$28da32efc51c2b65.body.exit"
	mov	x0, x9
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #32             ; 16-byte Folded Reload
	ret
LBB87_63:
	mov	x8, #0                          ; =0x0
LBB87_64:
	mov	w9, #1                          ; =0x1
	mov	x0, x9
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #32             ; 16-byte Folded Reload
	ret
LBB87_65:                               ; %bb22.i
	cbz	w8, LBB87_64
; %bb.66:                               ; %invalid.tag.b22.i
	bl	_abort
LBB87_67:
	mov	w9, #0                          ; =0x0
	mov	x8, x20
	mov	x0, x9
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #32             ; 16-byte Folded Reload
	ret
LBB87_68:
	mov	w9, #0                          ; =0x0
	mov	x8, x19
	mov	x0, x9
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #32             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65 ; -- Begin function wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	.p2align	2
_wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65: ; @"wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #624
	.cfi_def_cfa_offset 720
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cmp	x1, #4, lsl #12                 ; =16384
	b.hi	LBB88_2
; %bb.1:                                ; %bb3.i
	ldr	x25, [x0]
	ldr	x8, [x25]
	cmp	x1, x8
	b.hs	LBB88_3
LBB88_2:
	mov	w0, #1                          ; =0x1
	b	LBB88_40
LBB88_3:                                ; %bb6.i
	cbz	x1, LBB88_39
; %bb.4:                                ; %bb9.i
	mov	x20, x0
	ldr	x8, [x2]
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	ldrb	w27, [x2, #8]
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	mov	x19, x1
	madd	x0, x1, x8, x9
	bl	_malloc
	cbz	x0, LBB88_42
; %bb.5:                                ; %bb1.i.i
	mov	x22, x0
	mov	x8, #0                          ; =0x0
	mov	x10, x19
	str	x19, [x0, #8]
	add	x9, x0, #24
	movi.2d	v0, #0000000000000000
LBB88_6:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	q0, q0, [x9]
	stp	q0, q0, [x9, #32]
	stp	q0, q0, [x9, #64]
	stp	q0, q0, [x9, #96]
	stp	q0, q0, [x9, #128]
	stp	q0, q0, [x9, #160]
	stp	q0, q0, [x9, #192]
	stp	q0, q0, [x9, #224]
	str	xzr, [x9, #256]
	add	x9, x9, #272
	cmp	x10, x8
	b.ne	LBB88_6
; %bb.7:                                ; %"wf_hash_map.hash_map_extend$instance$0e108827ecbbe374.exit.i"
	str	x10, [x22]
	cmp	x10, #9
	str	x19, [sp, #48]                  ; 8-byte Folded Spill
	b.hs	LBB88_9
; %bb.8:
	mov	x21, #0                         ; =0x0
	mov	x8, #0                          ; =0x0
	b	LBB88_11
LBB88_9:                                ; %bb2.i.i.i
	and	x24, x10, #0x7ff8
	add	x0, x24, #8
	bl	_malloc
	cbz	x0, LBB88_42
; %bb.10:                               ; %buffer.fill.init.v2.i.i.i.i
	mov	x21, x0
	lsr	x8, x19, #3
	str	x8, [x0], #8
	mov	w1, #128                        ; =0x80
	mov	x2, x24
	bl	_memset
	mov	w8, #1                          ; =0x1
LBB88_11:                               ; %"wf_hash_map.hash_map_controls_new$instance$fd5e04af5c7e1250.exit.i"
	mov	x10, x20
	str	x22, [x20]
	ldp	x28, x9, [x20, #24]
	str	x9, [sp, #16]                   ; 8-byte Folded Spill
	mov	x9, #-9187201950435737472       ; =0x8080808080808080
	stp	x9, x8, [x20, #16]
	str	x21, [sp, #32]                  ; 8-byte Folded Spill
	str	x21, [x20, #32]
	ldr	x8, [x25]
	cbz	x8, LBB88_36
; %bb.12:                               ; %bb14.lr.ph.i
	mov	x23, x10
	str	x9, [sp, #40]                   ; 8-byte Folded Spill
	mov	w21, #272                       ; =0x110
	str	x25, [sp, #24]                  ; 8-byte Folded Spill
	b	LBB88_15
LBB88_13:                               ; %bb15thread-pre-split.i
                                        ;   in Loop: Header=BB88_15 Depth=1
	ldr	x25, [sp, #24]                  ; 8-byte Folded Reload
	ldr	x9, [x25]
LBB88_14:                               ; %bb15.i
                                        ;   in Loop: Header=BB88_15 Depth=1
	mov	x8, x9
	cbz	x9, LBB88_36
LBB88_15:                               ; %bb14.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB88_19 Depth 2
                                        ;       Child Loop BB88_23 Depth 3
	sub	x9, x8, #1
	str	x9, [x25]
	madd	x8, x8, x21, x25
	ldr	w10, [x8, #-256]!
	cmp	w10, #2
	b.lo	LBB88_14
; %bb.16:                               ; %bb14.i
                                        ;   in Loop: Header=BB88_15 Depth=1
	b.ne	LBB88_41
; %bb.17:                               ; %bb23.preheader.i
                                        ;   in Loop: Header=BB88_15 Depth=1
	ldr	x9, [x8, #264]
	ldur	q0, [x8, #8]
	stur	q0, [sp, #72]
	ldur	q0, [x8, #24]
	stur	q0, [sp, #88]
	ldur	q0, [x8, #40]
	stur	q0, [sp, #104]
	ldur	q0, [x8, #56]
	stur	q0, [sp, #120]
	ldur	q0, [x8, #72]
	stur	q0, [sp, #136]
	ldur	q0, [x8, #88]
	stur	q0, [sp, #152]
	ldur	q0, [x8, #104]
	stur	q0, [sp, #168]
	ldur	q0, [x8, #120]
	stur	q0, [sp, #184]
	ldur	q0, [x8, #136]
	add	x10, sp, #64
	stur	q0, [x10, #136]
	ldur	q0, [x8, #152]
	stur	q0, [x10, #152]
	ldur	q0, [x8, #168]
	stur	q0, [x10, #168]
	ldur	q0, [x8, #184]
	stur	q0, [x10, #184]
	ldur	q0, [x8, #200]
	stur	q0, [x10, #200]
	ldur	q0, [x8, #216]
	stur	q0, [x10, #216]
	ldur	q0, [x8, #232]
	stur	q0, [x10, #232]
	ldur	q0, [x8, #248]
	stur	q0, [x10, #248]
	str	x9, [sp, #328]
	mov	w26, #1                         ; =0x1
	mov	w8, #1                          ; =0x1
	str	x8, [sp, #64]
	b	LBB88_19
LBB88_18:                               ; %bb27.i
                                        ;   in Loop: Header=BB88_19 Depth=2
	cbz	x26, LBB88_13
LBB88_19:                               ; %bb23.i
                                        ;   Parent Loop BB88_15 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB88_23 Depth 3
	tbz	w27, #0, LBB88_21
; %bb.20:                               ;   in Loop: Header=BB88_19 Depth=2
	mov	x19, #0                         ; =0x0
	ldr	x9, [x22]
	cbnz	x9, LBB88_22
	b	LBB88_18
LBB88_21:                               ; %bb3.i.i
                                        ;   in Loop: Header=BB88_19 Depth=2
	ldr	x8, [sp, #72]
	ldr	x9, [sp, #56]                   ; 8-byte Folded Reload
	eor	x8, x8, x9
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x19, x8, x8, lsr #31
	ldr	x9, [x22]
	cbz	x9, LBB88_18
LBB88_22:                               ; %bb25.lr.ph.i
                                        ;   in Loop: Header=BB88_19 Depth=2
	mov	x8, #0                          ; =0x0
	udiv	x10, x19, x9
	msub	x10, x10, x9, x19
	sub	x11, x9, x10
	neg	x12, x11
LBB88_23:                               ; %bb25.i
                                        ;   Parent Loop BB88_15 Depth=1
                                        ;     Parent Loop BB88_19 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x8, x11
	csel	x13, x10, x12, lo
	add	x14, x13, x8
	madd	x14, x14, x21, x22
	ldr	w14, [x14, #16]
	cmp	w14, #2
	b.ne	LBB88_25
; %bb.24:                               ; %bb3.i27.i
                                        ;   in Loop: Header=BB88_23 Depth=3
	add	x8, x8, #1
	cmp	x9, x8
	b.ne	LBB88_23
	b	LBB88_18
LBB88_25:                               ; %bb25.i
                                        ;   in Loop: Header=BB88_19 Depth=2
	b.hs	LBB88_41
; %bb.26:                               ; %bb29.i
                                        ;   in Loop: Header=BB88_19 Depth=2
	sub	x20, x26, #1
	str	x20, [sp, #64]
	mov	w9, #264                        ; =0x108
	add	x10, sp, #64
	madd	x24, x26, x9, x10
	ldr	x3, [x24, #-256]!
	add	x25, x13, x8
	add	x0, sp, #336
	add	x4, x24, #8
	mov	x1, x23
	mov	x2, x25
	bl	_wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449
	lsr	x8, x19, #57
	ubfiz	x10, x25, #3, #3
	mov	w9, #255                        ; =0xff
	lsl	x9, x9, x10
	mvn	x9, x9
	lsl	x8, x8, x10
	ldr	x10, [sp, #48]                  ; 8-byte Folded Reload
	cmp	x10, #8
	b.hi	LBB88_28
; %bb.27:                               ; %bb2.i37.i
                                        ;   in Loop: Header=BB88_19 Depth=2
	cmp	x25, #8
	b.lo	LBB88_31
	b	LBB88_32
LBB88_28:                               ; %bb3.i35.i
                                        ;   in Loop: Header=BB88_19 Depth=2
	lsr	x10, x25, #3
	ldr	x12, [sp, #32]                  ; 8-byte Folded Reload
	ldr	x11, [x12]
	cmp	x10, x11
	b.hs	LBB88_30
; %bb.29:                               ; %bb8.i.i
                                        ;   in Loop: Header=BB88_19 Depth=2
	add	x10, x12, x10, lsl #3
	ldr	x11, [x10, #8]
	and	x9, x11, x9
	orr	x8, x9, x8
	str	x8, [x10, #8]
	b	LBB88_32
LBB88_30:                               ; %bb9.i.i
                                        ;   in Loop: Header=BB88_19 Depth=2
	b.ne	LBB88_32
LBB88_31:                               ; %bb11.i.i
                                        ;   in Loop: Header=BB88_19 Depth=2
	ldr	x10, [sp, #40]                  ; 8-byte Folded Reload
	and	x9, x10, x9
	orr	x8, x9, x8
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	str	x8, [x23, #16]
LBB88_32:                               ; %wf_hash_map.hash_map_control_set.exit.i
                                        ;   in Loop: Header=BB88_19 Depth=2
	ldr	w8, [sp, #336]
	cbz	w8, LBB88_35
; %bb.33:                               ; %wf_hash_map.hash_map_control_set.exit.i
                                        ;   in Loop: Header=BB88_19 Depth=2
	cmp	w8, #1
	b.ne	LBB88_41
; %bb.34:                               ; %bb33.i
                                        ;   in Loop: Header=BB88_19 Depth=2
	add	x8, sp, #336
	add	x1, x8, #8
	mov	x0, x24
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	str	x26, [sp, #64]
	cbnz	x26, LBB88_19
	b	LBB88_13
LBB88_35:                               ;   in Loop: Header=BB88_19 Depth=2
	mov	x26, x20
	cbnz	x20, LBB88_19
	b	LBB88_13
LBB88_36:                               ; %bb13.i
	mov	x0, x25
	bl	_free
	str	x28, [sp, #608]
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	str	x8, [sp, #616]
	cbz	x28, LBB88_39
; %bb.37:                               ; %body.i.i.preheader
	mov	x19, #0                         ; =0x0
	add	x8, sp, #608
	add	x20, x8, #8
LBB88_38:                               ; %body.i.i
                                        ; =>This Inner Loop Header: Depth=1
	cmp	x19, #1
	csinc	x8, x19, xzr, lo
	sub	x8, x20, x8, lsl #3
	ldr	x0, [x8]
	bl	_free
	add	x19, x19, #1
	add	x20, x20, #8
	subs	x28, x28, #1
	b.ne	LBB88_38
LBB88_39:                               ; %wf.drop.run.707f874ef98d2803.exit.i
	mov	w0, #0                          ; =0x0
LBB88_40:                               ; %"wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	add	sp, sp, #624
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB88_41:                               ; %invalid.tag.b12.i
	bl	_abort
LBB88_42:                               ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_slots_new$instance$bc7a70143afe699c ; -- Begin function wf_slots_new$instance$bc7a70143afe699c
	.p2align	2
_wf_slots_new$instance$bc7a70143afe699c: ; @"wf_slots_new$instance$bc7a70143afe699c"
; %bb.0:                                ; %entry
	mov	x0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_box_array_filled$instance$e194368921a477a7 ; -- Begin function wf_box_array_filled$instance$e194368921a477a7
	.p2align	2
_wf_box_array_filled$instance$e194368921a477a7: ; @"wf_box_array_filled$instance$e194368921a477a7"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	mov	x20, x0
	lsl	x8, x0, #3
	add	x0, x8, #8
	bl	_malloc
	cbz	x0, LBB90_10
; %bb.1:                                ; %buffer.fill.init.v2
	str	x20, [x0]
	cbz	x20, LBB90_9
; %bb.2:                                ; %buffer.fill.body.v2.preheader
	cmp	x20, #8
	b.hs	LBB90_4
; %bb.3:
	mov	x8, #0                          ; =0x0
	b	LBB90_7
LBB90_4:                                ; %vector.ph
	and	x8, x20, #0xfffffffffffffff8
	dup.2d	v0, x19
	add	x9, x0, #40
	mov	x10, x8
LBB90_5:                                ; %vector.body
                                        ; =>This Inner Loop Header: Depth=1
	stp	q0, q0, [x9, #-32]
	stp	q0, q0, [x9], #64
	subs	x10, x10, #8
	b.ne	LBB90_5
; %bb.6:                                ; %middle.block
	cmp	x20, x8
	b.eq	LBB90_9
LBB90_7:                                ; %buffer.fill.body.v2.preheader4
	sub	x9, x20, x8
	add	x8, x0, x8, lsl #3
	add	x8, x8, #8
LBB90_8:                                ; %buffer.fill.body.v2
                                        ; =>This Inner Loop Header: Depth=1
	str	x19, [x8], #8
	subs	x9, x9, #1
	b.ne	LBB90_8
LBB90_9:                                ; %buffer.fill.done.v2
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB90_10:                               ; %buffer.fill.oom.v2
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_action$instance$fc5e3cb62bdf3601 ; -- Begin function wf_hash_map.hash_map_action$instance$fc5e3cb62bdf3601
	.p2align	2
_wf_hash_map.hash_map_action$instance$fc5e3cb62bdf3601: ; @"wf_hash_map.hash_map_action$instance$fc5e3cb62bdf3601"
; %bb.0:                                ; %entry
	mov	x8, x0
	ldr	w0, [x0]
	cmp	w0, #2
	b.hs	LBB91_2
; %bb.1:                                ; %common.ret
	ret
LBB91_2:                                ; %entry
	b.ne	LBB91_4
; %bb.3:                                ; %bb3
	ldr	x8, [x8, #8]
	ldr	x9, [x1]
	cmp	x8, x9
	mov	w8, #2                          ; =0x2
	cinc	w0, w8, eq
	ret
LBB91_4:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_exchange$instance$0ed342445dd803f3 ; -- Begin function wf_hash_map.hash_map_exchange$instance$0ed342445dd803f3
	.p2align	2
_wf_hash_map.hash_map_exchange$instance$0ed342445dd803f3: ; @"wf_hash_map.hash_map_exchange$instance$0ed342445dd803f3"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	mov	w9, #24                         ; =0x18
	madd	x9, x2, x9, x8
	ldr	w8, [x9, #16]
	ldur	q0, [x9, #24]
	mov	w10, #2                         ; =0x2
	str	w10, [x9, #16]
	stp	x3, x4, [x9, #24]
	cbz	w8, LBB92_4
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.eq	LBB92_4
; %bb.2:                                ; %entry
	cmp	w8, #2
	b.ne	LBB92_5
; %bb.3:                                ; %bb3
	str	xzr, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	stur	q0, [x0, #8]
	ret
LBB92_4:                                ; %bb2
	stp	xzr, xzr, [x0]
	str	xzr, [x0, #16]
	ret
LBB92_5:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_control_inserted$instance$0ed342445dd803f3 ; -- Begin function wf_hash_map.hash_map_control_inserted$instance$0ed342445dd803f3
	.p2align	2
_wf_hash_map.hash_map_control_inserted$instance$0ed342445dd803f3: ; @"wf_hash_map.hash_map_control_inserted$instance$0ed342445dd803f3"
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cbz	w8, LBB93_3
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB93_4
; %bb.2:                                ; %bb2
	mov	w0, #0                          ; =0x0
	ret
LBB93_3:
	mov	w0, #1                          ; =0x1
	ret
LBB93_4:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6 ; -- Begin function wf_hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6
	.p2align	2
_wf_hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6: ; @"wf_hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #128
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 128
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	cmp	x1, #3
	b.hi	LBB94_2
; %bb.1:                                ; %bb3.i
	ldr	x19, [x0]
	ldr	x24, [x19]
	cmp	x1, x24
	b.hs	LBB94_3
LBB94_2:
	mov	w0, #1                          ; =0x1
	b	LBB94_28
LBB94_3:                                ; %bb6.i
	cbz	x1, LBB94_27
; %bb.4:                                ; %bb9.i
	mov	x22, x0
	ldr	x20, [x2]
	ldrb	w21, [x2, #8]
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	mov	x23, x1
	madd	x0, x1, x8, x9
	bl	_malloc
	cbz	x0, LBB94_30
; %bb.5:                                ; %bb1.i.i
	mov	x9, #0                          ; =0x0
	mov	x10, x23
	str	x23, [x0, #8]
	add	x11, x0, #24
	mov	x8, x22
LBB94_6:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x11, #-8]
	add	x9, x9, #1
	stp	xzr, xzr, [x11], #24
	cmp	x10, x9
	b.ne	LBB94_6
; %bb.7:                                ; %"wf_hash_map.hash_map_extend$instance$a62a753cf2b0b5ca.exit.i"
	str	x10, [x0]
	str	x0, [x8]
	ldp	x22, x23, [x8, #24]
	mov	x9, #-9187201950435737472       ; =0x8080808080808080
	stp	x9, xzr, [x8, #16]
	str	xzr, [x8, #32]
	cbz	x24, LBB94_24
; %bb.8:                                ; %bb14.lr.ph.i
	mov	w10, #24                        ; =0x18
	mov	x11, #58809                     ; =0xe5b9
	movk	x11, #7396, lsl #16
	movk	x11, #18285, lsl #32
	movk	x11, #48984, lsl #48
	mov	x12, #4587                      ; =0x11eb
	movk	x12, #4913, lsl #16
	movk	x12, #18875, lsl #32
	movk	x12, #38096, lsl #48
	add	x13, sp, #8
	mov	w14, #2                         ; =0x2
	mov	w15, #255                       ; =0xff
	b	LBB94_10
LBB94_9:                                ; %bb15.i
                                        ;   in Loop: Header=BB94_10 Depth=1
	mov	x24, x16
	cbz	x16, LBB94_24
LBB94_10:                               ; %bb14.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB94_16 Depth 2
                                        ;       Child Loop BB94_18 Depth 3
	sub	x16, x24, #1
	str	x16, [x19]
	madd	x17, x24, x10, x19
	ldr	w1, [x17, #-8]!
	cmp	w1, #2
	b.lo	LBB94_9
; %bb.11:                               ; %bb14.i
                                        ;   in Loop: Header=BB94_10 Depth=1
	b.ne	LBB94_29
; %bb.12:                               ; %bb23.preheader.i
                                        ;   in Loop: Header=BB94_10 Depth=1
	ldur	q0, [x17, #8]
	ldr	x17, [x17, #8]
	stur	q0, [sp, #16]
	eor	x17, x17, x20
	eor	x17, x17, x17, lsr #30
	mul	x17, x17, x11
	eor	x17, x17, x17, lsr #27
	mul	x17, x17, x12
	eor	x17, x17, x17, lsr #31
	tst	w21, #0x1
	csel	x17, xzr, x17, ne
	ldr	x3, [x0]
	cbz	x3, LBB94_23
; %bb.13:                               ; %bb23.i.preheader
                                        ;   in Loop: Header=BB94_10 Depth=1
	lsr	x1, x17, #57
	mov	w2, #1                          ; =0x1
	b	LBB94_16
LBB94_14:                               ; %bb27.i
                                        ;   in Loop: Header=BB94_16 Depth=2
	cbz	x2, LBB94_9
LBB94_15:                               ; %bb23.ithread-pre-split
                                        ;   in Loop: Header=BB94_16 Depth=2
	ldr	x3, [x0]
LBB94_16:                               ; %bb23.i
                                        ;   Parent Loop BB94_10 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB94_18 Depth 3
	cbz	x3, LBB94_15
; %bb.17:                               ; %bb25.lr.ph.i
                                        ;   in Loop: Header=BB94_16 Depth=2
	mov	x4, #0                          ; =0x0
	udiv	x5, x17, x3
	msub	x5, x5, x3, x17
	sub	x6, x3, x5
	neg	x7, x6
LBB94_18:                               ; %bb25.i
                                        ;   Parent Loop BB94_10 Depth=1
                                        ;     Parent Loop BB94_16 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x4, x6
	csel	x24, x5, x7, lo
	add	x25, x24, x4
	madd	x25, x25, x10, x0
	ldr	w26, [x25, #16]!
	cmp	w26, #2
	b.ne	LBB94_20
; %bb.19:                               ; %bb3.i28.i
                                        ;   in Loop: Header=BB94_18 Depth=3
	add	x4, x4, #1
	cmp	x3, x4
	b.ne	LBB94_18
	b	LBB94_15
LBB94_20:                               ; %bb25.i
                                        ;   in Loop: Header=BB94_16 Depth=2
	b.hs	LBB94_29
; %bb.21:                               ; %bb2.i46.i
                                        ;   in Loop: Header=BB94_16 Depth=2
	sub	x2, x2, #1
	add	x3, x13, x2, lsl #4
	str	x2, [sp, #8]
	str	w14, [x25]
	ldur	q0, [x3, #8]
	stur	q0, [x25, #8]
	add	x3, x24, x4
	cmp	x3, #7
	b.hi	LBB94_14
; %bb.22:                               ; %bb5.i47.i
                                        ;   in Loop: Header=BB94_16 Depth=2
	lsl	x3, x3, #3
	lsl	x4, x1, x3
	lsl	x3, x15, x3
	bic	x9, x9, x3
	orr	x9, x9, x4
	str	x9, [x8, #16]
	b	LBB94_14
LBB94_23:                               ; %bb23.i.us
                                        ; =>This Inner Loop Header: Depth=1
	b	LBB94_23
LBB94_24:                               ; %bb13.i
	mov	x0, x19
	bl	_free
	stp	x22, x23, [sp, #32]
	cbz	x22, LBB94_27
; %bb.25:                               ; %body.i.i.preheader
	mov	x19, #0                         ; =0x0
	add	x8, sp, #32
	add	x20, x8, #8
LBB94_26:                               ; %body.i.i
                                        ; =>This Inner Loop Header: Depth=1
	cmp	x19, #1
	csinc	x8, x19, xzr, lo
	sub	x8, x20, x8, lsl #3
	ldr	x0, [x8]
	bl	_free
	add	x19, x19, #1
	add	x20, x20, #8
	subs	x22, x22, #1
	b.ne	LBB94_26
LBB94_27:                               ; %wf.drop.run.707f874ef98d2803.exit.i
	mov	w0, #0                          ; =0x0
LBB94_28:                               ; %"wf_hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
LBB94_29:                               ; %invalid.tag.b12.i
	bl	_abort
LBB94_30:                               ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_slots_new$instance$f6f95306140971d3 ; -- Begin function wf_slots_new$instance$f6f95306140971d3
	.p2align	2
_wf_slots_new$instance$f6f95306140971d3: ; @"wf_slots_new$instance$f6f95306140971d3"
; %bb.0:                                ; %entry
	mov	x0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_is_available$instance$0ed342445dd803f3 ; -- Begin function wf_hash_map.hash_map_is_available$instance$0ed342445dd803f3
	.p2align	2
_wf_hash_map.hash_map_is_available$instance$0ed342445dd803f3: ; @"wf_hash_map.hash_map_is_available$instance$0ed342445dd803f3"
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cmp	w8, #3
	b.hs	LBB96_2
; %bb.1:                                ; %switch.lookup
	mov	w9, #3                          ; =0x3
	lsr	w8, w9, w8
	and	w0, w8, #0x1
	ret
LBB96_2:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_action$instance$c6df3d8464f8cde0 ; -- Begin function wf_hash_map.hash_map_action$instance$c6df3d8464f8cde0
	.p2align	2
_wf_hash_map.hash_map_action$instance$c6df3d8464f8cde0: ; @"wf_hash_map.hash_map_action$instance$c6df3d8464f8cde0"
; %bb.0:                                ; %entry
	mov	x8, x0
	ldr	w0, [x0]
	cmp	w0, #2
	b.hs	LBB97_2
; %bb.1:                                ; %common.ret
	ret
LBB97_2:                                ; %entry
	b.ne	LBB97_4
; %bb.3:                                ; %bb3
	ldr	x8, [x8, #8]
	ldr	x9, [x1]
	cmp	x8, x9
	mov	w8, #2                          ; =0x2
	cinc	w0, w8, eq
	ret
LBB97_4:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449 ; -- Begin function wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449
	.p2align	2
_wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449: ; @"wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449"
; %bb.0:                                ; %entry
	stp	d15, d14, [sp, #-64]!           ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	ldr	x8, [x1]
	mov	w9, #272                        ; =0x110
	madd	x10, x2, x9, x8
	ldr	w9, [x10, #16]!
	ldur	q0, [x10, #8]
	ldur	q1, [x10, #24]
	ldur	q2, [x10, #40]
	ldur	q3, [x10, #56]
	ldur	q4, [x10, #72]
	ldur	q5, [x10, #88]
	ldur	q6, [x10, #104]
	ldur	q7, [x10, #120]
	ldur	q16, [x10, #136]
	ldur	q17, [x10, #152]
	ldur	q18, [x10, #168]
	ldur	q19, [x10, #184]
	ldur	q20, [x10, #200]
	ldur	q21, [x10, #216]
	ldur	q22, [x10, #232]
	ldur	q23, [x10, #248]
	ldr	x8, [x10, #264]
	ldp	q24, q25, [x4]
	ldp	q26, q27, [x4, #32]
	ldp	q28, q29, [x4, #64]
	ldp	q30, q31, [x4, #96]
	ldp	q8, q9, [x4, #128]
	ldp	q10, q11, [x4, #160]
	ldp	q12, q13, [x4, #192]
	ldp	q14, q15, [x4, #224]
	mov	w11, #2                         ; =0x2
	str	w11, [x10]
	str	x3, [x10, #8]
	stp	q24, q25, [x10, #16]
	stp	q26, q27, [x10, #48]
	stp	q28, q29, [x10, #80]
	stp	q30, q31, [x10, #112]
	stp	q8, q9, [x10, #144]
	stp	q10, q11, [x10, #176]
	stp	q12, q13, [x10, #208]
	stp	q14, q15, [x10, #240]
	cbz	w9, LBB98_4
; %bb.1:                                ; %entry
	cmp	w9, #1
	b.eq	LBB98_4
; %bb.2:                                ; %entry
	cmp	w9, #2
	b.ne	LBB98_5
; %bb.3:                                ; %bb3
	str	xzr, [x0]
	mov	w9, #1                          ; =0x1
	str	w9, [x0]
	stur	q0, [x0, #8]
	stur	q1, [x0, #24]
	stur	q2, [x0, #40]
	stur	q3, [x0, #56]
	stur	q4, [x0, #72]
	stur	q5, [x0, #88]
	stur	q6, [x0, #104]
	stur	q7, [x0, #120]
	stur	q16, [x0, #136]
	stur	q17, [x0, #152]
	stur	q18, [x0, #168]
	stur	q19, [x0, #184]
	stur	q20, [x0, #200]
	stur	q21, [x0, #216]
	stur	q22, [x0, #232]
	stur	q23, [x0, #248]
	str	x8, [x0, #264]
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #64             ; 16-byte Folded Reload
	ret
LBB98_4:                                ; %bb2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0, #240]
	stp	q0, q0, [x0, #208]
	stp	q0, q0, [x0, #176]
	stp	q0, q0, [x0, #144]
	stp	q0, q0, [x0, #112]
	stp	q0, q0, [x0, #80]
	stp	q0, q0, [x0, #48]
	stp	q0, q0, [x0, #16]
	str	q0, [x0]
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #64             ; 16-byte Folded Reload
	ret
LBB98_5:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_control_inserted$instance$d7a1a90c27bba449 ; -- Begin function wf_hash_map.hash_map_control_inserted$instance$d7a1a90c27bba449
	.p2align	2
_wf_hash_map.hash_map_control_inserted$instance$d7a1a90c27bba449: ; @"wf_hash_map.hash_map_control_inserted$instance$d7a1a90c27bba449"
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cbz	w8, LBB99_3
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB99_4
; %bb.2:                                ; %bb2
	mov	w0, #0                          ; =0x0
	ret
LBB99_3:
	mov	w0, #1                          ; =0x1
	ret
LBB99_4:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07 ; -- Begin function wf_hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07
	.p2align	2
_wf_hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07: ; @"wf_hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #608
	.cfi_def_cfa_offset 704
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cmp	x1, #3
	b.hi	LBB100_2
; %bb.1:                                ; %bb3.i
	mov	x19, x0
	ldr	x9, [x0]
	ldr	x8, [x9]
	cmp	x1, x8
	b.hs	LBB100_3
LBB100_2:
	mov	w0, #1                          ; =0x1
	b	LBB100_36
LBB100_3:                               ; %bb6.i
	cbz	x1, LBB100_35
; %bb.4:                                ; %bb9.i
	str	x9, [sp, #24]                   ; 8-byte Folded Spill
	ldr	x8, [x2]
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	ldrb	w25, [x2, #8]
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	mov	x20, x1
	madd	x0, x1, x8, x9
	bl	_malloc
	cbz	x0, LBB100_38
; %bb.5:                                ; %bb1.i.i
	mov	x21, x0
	mov	x8, #0                          ; =0x0
	mov	x9, x20
	str	x20, [x0, #8]
	add	x10, x0, #24
	movi.2d	v0, #0000000000000000
LBB100_6:                               ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x10, #-8]
	add	x8, x8, #1
	stp	q0, q0, [x10]
	stp	q0, q0, [x10, #32]
	stp	q0, q0, [x10, #64]
	stp	q0, q0, [x10, #96]
	stp	q0, q0, [x10, #128]
	stp	q0, q0, [x10, #160]
	stp	q0, q0, [x10, #192]
	stp	q0, q0, [x10, #224]
	str	xzr, [x10, #256]
	add	x10, x10, #272
	cmp	x9, x8
	b.ne	LBB100_6
; %bb.7:                                ; %"wf_hash_map.hash_map_extend$instance$96033bf6ddb80743.exit.i"
	str	x9, [x21]
	str	x21, [x19]
	ldp	x27, x8, [x19, #24]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	mov	x8, #-9187201950435737472       ; =0x8080808080808080
	stp	x8, xzr, [x19, #16]
	str	xzr, [x19, #32]
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x8, [x0]
	cbz	x8, LBB100_32
; %bb.8:                                ; %bb14.lr.ph.i
	mov	x9, #-9187201950435737472       ; =0x8080808080808080
	str	x9, [sp, #32]                   ; 8-byte Folded Spill
	mov	w26, #272                       ; =0x110
	b	LBB100_11
LBB100_9:                               ; %bb15thread-pre-split.i
                                        ;   in Loop: Header=BB100_11 Depth=1
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
	ldr	x9, [x0]
LBB100_10:                              ; %bb15.i
                                        ;   in Loop: Header=BB100_11 Depth=1
	mov	x8, x9
	cbz	x9, LBB100_32
LBB100_11:                              ; %bb14.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB100_15 Depth 2
                                        ;       Child Loop BB100_19 Depth 3
	sub	x9, x8, #1
	str	x9, [x0]
	madd	x8, x8, x26, x0
	ldr	w10, [x8, #-256]!
	cmp	w10, #2
	b.lo	LBB100_10
; %bb.12:                               ; %bb14.i
                                        ;   in Loop: Header=BB100_11 Depth=1
	b.ne	LBB100_37
; %bb.13:                               ; %bb23.preheader.i
                                        ;   in Loop: Header=BB100_11 Depth=1
	ldr	x9, [x8, #264]
	ldur	q0, [x8, #8]
	stur	q0, [sp, #56]
	ldur	q0, [x8, #24]
	stur	q0, [sp, #72]
	ldur	q0, [x8, #40]
	stur	q0, [sp, #88]
	ldur	q0, [x8, #56]
	stur	q0, [sp, #104]
	ldur	q0, [x8, #72]
	stur	q0, [sp, #120]
	ldur	q0, [x8, #88]
	stur	q0, [sp, #136]
	ldur	q0, [x8, #104]
	stur	q0, [sp, #152]
	ldur	q0, [x8, #120]
	stur	q0, [sp, #168]
	ldur	q0, [x8, #136]
	add	x10, sp, #48
	stur	q0, [x10, #136]
	ldur	q0, [x8, #152]
	stur	q0, [x10, #152]
	ldur	q0, [x8, #168]
	stur	q0, [x10, #168]
	ldur	q0, [x8, #184]
	stur	q0, [x10, #184]
	ldur	q0, [x8, #200]
	stur	q0, [x10, #200]
	ldur	q0, [x8, #216]
	stur	q0, [x10, #216]
	ldur	q0, [x8, #232]
	stur	q0, [x10, #232]
	ldur	q0, [x8, #248]
	stur	q0, [x10, #248]
	str	x9, [sp, #312]
	mov	w20, #1                         ; =0x1
	mov	w8, #1                          ; =0x1
	str	x8, [sp, #48]
	b	LBB100_15
LBB100_14:                              ; %bb27.i
                                        ;   in Loop: Header=BB100_15 Depth=2
	cbz	x20, LBB100_9
LBB100_15:                              ; %bb23.i
                                        ;   Parent Loop BB100_11 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB100_19 Depth 3
	tbz	w25, #0, LBB100_17
; %bb.16:                               ;   in Loop: Header=BB100_15 Depth=2
	mov	x28, #0                         ; =0x0
	ldr	x9, [x21]
	cbnz	x9, LBB100_18
	b	LBB100_14
LBB100_17:                              ; %bb3.i.i
                                        ;   in Loop: Header=BB100_15 Depth=2
	ldr	x8, [sp, #56]
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	eor	x8, x8, x9
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x28, x8, x8, lsr #31
	ldr	x9, [x21]
	cbz	x9, LBB100_14
LBB100_18:                              ; %bb25.lr.ph.i
                                        ;   in Loop: Header=BB100_15 Depth=2
	mov	x8, #0                          ; =0x0
	udiv	x10, x28, x9
	msub	x10, x10, x9, x28
	sub	x11, x9, x10
	neg	x12, x11
LBB100_19:                              ; %bb25.i
                                        ;   Parent Loop BB100_11 Depth=1
                                        ;     Parent Loop BB100_15 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x8, x11
	csel	x13, x10, x12, lo
	add	x14, x13, x8
	madd	x14, x14, x26, x21
	ldr	w14, [x14, #16]
	cmp	w14, #2
	b.ne	LBB100_21
; %bb.20:                               ; %bb3.i27.i
                                        ;   in Loop: Header=BB100_19 Depth=3
	add	x8, x8, #1
	cmp	x9, x8
	b.ne	LBB100_19
	b	LBB100_14
LBB100_21:                              ; %bb25.i
                                        ;   in Loop: Header=BB100_15 Depth=2
	b.hs	LBB100_37
; %bb.22:                               ; %bb29.i
                                        ;   in Loop: Header=BB100_15 Depth=2
	sub	x24, x20, #1
	str	x24, [sp, #48]
	mov	w9, #264                        ; =0x108
	add	x10, sp, #48
	madd	x22, x20, x9, x10
	ldr	x3, [x22, #-256]!
	add	x23, x13, x8
	add	x0, sp, #320
	add	x4, x22, #8
	mov	x1, x19
	mov	x2, x23
	bl	_wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449
	lsr	x8, x28, #57
	ubfiz	x10, x23, #3, #3
	mov	w9, #255                        ; =0xff
	lsl	x9, x9, x10
	mvn	x9, x9
	lsl	x8, x8, x10
	ldr	x10, [x19, #24]
	cbz	x10, LBB100_25
; %bb.23:                               ; %bb3.i35.i
                                        ;   in Loop: Header=BB100_15 Depth=2
	lsr	x10, x23, #3
	ldr	x11, [x19, #32]
	ldr	x12, [x11]
	cmp	x10, x12
	b.hs	LBB100_31
; %bb.24:                               ; %bb8.i.i
                                        ;   in Loop: Header=BB100_15 Depth=2
	add	x10, x11, x10, lsl #3
	ldr	x11, [x10, #8]
	and	x9, x11, x9
	orr	x8, x9, x8
	str	x8, [x10, #8]
	b	LBB100_27
LBB100_25:                              ; %bb2.i37.i
                                        ;   in Loop: Header=BB100_15 Depth=2
	cmp	x23, #8
	b.hs	LBB100_27
LBB100_26:                              ; %bb11.i.i
                                        ;   in Loop: Header=BB100_15 Depth=2
	ldr	x10, [sp, #32]                  ; 8-byte Folded Reload
	and	x9, x10, x9
	orr	x8, x9, x8
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	str	x8, [x19, #16]
LBB100_27:                              ; %wf_hash_map.hash_map_control_set.exit.i
                                        ;   in Loop: Header=BB100_15 Depth=2
	ldr	w8, [sp, #320]
	cbz	w8, LBB100_30
; %bb.28:                               ; %wf_hash_map.hash_map_control_set.exit.i
                                        ;   in Loop: Header=BB100_15 Depth=2
	cmp	w8, #1
	b.ne	LBB100_37
; %bb.29:                               ; %bb33.i
                                        ;   in Loop: Header=BB100_15 Depth=2
	add	x8, sp, #320
	add	x1, x8, #8
	mov	x0, x22
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	str	x20, [sp, #48]
	cbnz	x20, LBB100_15
	b	LBB100_9
LBB100_30:                              ;   in Loop: Header=BB100_15 Depth=2
	mov	x20, x24
	cbnz	x24, LBB100_15
	b	LBB100_9
LBB100_31:                              ; %bb9.i.i
                                        ;   in Loop: Header=BB100_15 Depth=2
	b.eq	LBB100_26
	b	LBB100_27
LBB100_32:                              ; %bb13.i
	bl	_free
	str	x27, [sp, #592]
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	str	x8, [sp, #600]
	cbz	x27, LBB100_35
; %bb.33:                               ; %body.i.i.preheader
	mov	x19, #0                         ; =0x0
	add	x8, sp, #592
	add	x20, x8, #8
LBB100_34:                              ; %body.i.i
                                        ; =>This Inner Loop Header: Depth=1
	cmp	x19, #1
	csinc	x8, x19, xzr, lo
	sub	x8, x20, x8, lsl #3
	ldr	x0, [x8]
	bl	_free
	add	x19, x19, #1
	add	x20, x20, #8
	subs	x27, x27, #1
	b.ne	LBB100_34
LBB100_35:                              ; %wf.drop.run.707f874ef98d2803.exit.i
	mov	w0, #0                          ; =0x0
LBB100_36:                              ; %"wf_hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	add	sp, sp, #608
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB100_37:                              ; %invalid.tag.b12.i
	bl	_abort
LBB100_38:                              ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_slots_new$instance$7445cefb96d3b406 ; -- Begin function wf_slots_new$instance$7445cefb96d3b406
	.p2align	2
_wf_slots_new$instance$7445cefb96d3b406: ; @"wf_slots_new$instance$7445cefb96d3b406"
; %bb.0:                                ; %entry
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0, #240]
	stp	q0, q0, [x0, #208]
	stp	q0, q0, [x0, #176]
	stp	q0, q0, [x0, #144]
	stp	q0, q0, [x0, #112]
	stp	q0, q0, [x0, #80]
	stp	q0, q0, [x0, #48]
	stp	q0, q0, [x0, #16]
	str	q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_hash_map.hash_map_is_available$instance$d7a1a90c27bba449 ; -- Begin function wf_hash_map.hash_map_is_available$instance$d7a1a90c27bba449
	.p2align	2
_wf_hash_map.hash_map_is_available$instance$d7a1a90c27bba449: ; @"wf_hash_map.hash_map_is_available$instance$d7a1a90c27bba449"
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cmp	w8, #3
	b.hs	LBB102_2
; %bb.1:                                ; %switch.lookup
	mov	w9, #3                          ; =0x3
	lsr	w8, w9, w8
	and	w0, w8, #0x1
	ret
LBB102_2:                               ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_take_back$instance$20364da1adbcdc5f ; -- Begin function wf_take_back$instance$20364da1adbcdc5f
	.p2align	2
_wf_take_back$instance$20364da1adbcdc5f: ; @"wf_take_back$instance$20364da1adbcdc5f"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x9, [x8]
	sub	x10, x9, #1
	str	x10, [x8]
	mov	w10, #24                        ; =0x18
	madd	x8, x9, x10, x8
	ldur	w0, [x8, #-8]
	ldp	x1, x2, [x8]
	ret
                                        ; -- End function
	.globl	_wf_free_empty$instance$fd33b528f0517054 ; -- Begin function wf_free_empty$instance$fd33b528f0517054
	.p2align	2
_wf_free_empty$instance$fd33b528f0517054: ; @"wf_free_empty$instance$fd33b528f0517054"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	bl	_free
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_swap$instance$087f541e70b769ea ; -- Begin function wf_swap$instance$087f541e70b769ea
	.p2align	2
_wf_swap$instance$087f541e70b769ea:     ; @"wf_swap$instance$087f541e70b769ea"
; %bb.0:                                ; %entry
	ldr	q0, [x0]
	str	q0, [sp, #-32]!
	ldr	x8, [x0, #16]
	str	x8, [sp, #16]
	ldr	x9, [x1, #16]
	ldr	q1, [x1]
	str	q1, [x0]
	str	x9, [x0, #16]
	str	q0, [x1]
	str	x8, [x1, #16]
	mov	w0, #0                          ; =0x0
	add	sp, sp, #32
	ret
                                        ; -- End function
	.globl	_wf_take_back$instance$2af1311599ac146a ; -- Begin function wf_take_back$instance$2af1311599ac146a
	.p2align	2
_wf_take_back$instance$2af1311599ac146a: ; @"wf_take_back$instance$2af1311599ac146a"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x8]
	sub	x10, x9, #1
	mov	w11, #272                       ; =0x110
	madd	x9, x9, x11, x8
	sub	x1, x9, #256
	str	x10, [x8]
	mov	w2, #272                        ; =0x110
	b	_memmove
                                        ; -- End function
	.globl	_wf_free_empty$instance$1b41cffa653e924b ; -- Begin function wf_free_empty$instance$1b41cffa653e924b
	.p2align	2
_wf_free_empty$instance$1b41cffa653e924b: ; @"wf_free_empty$instance$1b41cffa653e924b"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	bl	_free
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_swap$instance$b1cfa6e689dc9e10 ; -- Begin function wf_swap$instance$b1cfa6e689dc9e10
	.p2align	2
_wf_swap$instance$b1cfa6e689dc9e10:     ; @"wf_swap$instance$b1cfa6e689dc9e10"
; %bb.0:                                ; %entry
	sub	sp, sp, #320
	stp	x28, x27, [sp, #272]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #288]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #304]            ; 16-byte Folded Spill
	mov	x19, x1
	mov	x20, x0
	mov	x0, sp
	mov	x1, x20
	mov	w2, #272                        ; =0x110
	bl	_memcpy
	mov	x0, x20
	mov	x1, x19
	mov	w2, #272                        ; =0x110
	bl	_memmove
	mov	x1, sp
	mov	x0, x19
	mov	w2, #272                        ; =0x110
	bl	_memcpy
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #304]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #288]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #272]            ; 16-byte Folded Reload
	add	sp, sp, #320
	ret
                                        ; -- End function
	.globl	_wf_grow$instance$087f541e70b769ea ; -- Begin function wf_grow$instance$087f541e70b769ea
	.p2align	2
_wf_grow$instance$087f541e70b769ea:     ; @"wf_grow$instance$087f541e70b769ea"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x22, x1
	mov	x19, x0
	ldr	x20, [x0]
	ldr	x23, [x20]
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	madd	x0, x1, x8, x9
	bl	_malloc
	cbz	x0, LBB109_2
; %bb.1:                                ; %window.block.ready.v2
	mov	x21, x0
	stp	x23, x22, [x0], #16
	add	x8, x23, x23, lsl #1
	lsl	x2, x8, #3
	add	x1, x20, #16
	bl	_memmove
	mov	x0, x20
	bl	_free
	str	x21, [x19]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB109_2:                               ; %window.block.oom.v2
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_place_back$instance$20364da1adbcdc5f ; -- Begin function wf_place_back$instance$20364da1adbcdc5f
	.p2align	2
_wf_place_back$instance$20364da1adbcdc5f: ; @"wf_place_back$instance$20364da1adbcdc5f"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x9, [x8]
	mov	w10, #24                        ; =0x18
	madd	x10, x9, x10, x8
	ldr	x11, [x1, #16]
	ldr	q0, [x1]
	str	q0, [x10, #16]
	str	x11, [x10, #32]
	add	x9, x9, #1
	str	x9, [x8]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_place_back$instance$38dd27730d5cd43b ; -- Begin function wf_place_back$instance$38dd27730d5cd43b
	.p2align	2
_wf_place_back$instance$38dd27730d5cd43b: ; @"wf_place_back$instance$38dd27730d5cd43b"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	add	x9, x0, x8, lsl #3
	str	x1, [x9, #8]
	add	x8, x8, #1
	str	x8, [x0]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_swap$instance$fd33b528f0517054 ; -- Begin function wf_swap$instance$fd33b528f0517054
	.p2align	2
_wf_swap$instance$fd33b528f0517054:     ; @"wf_swap$instance$fd33b528f0517054"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x9, [x1]
	str	x9, [x0]
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_swap$instance$d89c7f330eeb5a04 ; -- Begin function wf_swap$instance$d89c7f330eeb5a04
	.p2align	2
_wf_swap$instance$d89c7f330eeb5a04:     ; @"wf_swap$instance$d89c7f330eeb5a04"
; %bb.0:                                ; %entry
	ldr	q0, [x0]
	str	q0, [sp, #-32]!
	ldr	x8, [x0, #16]
	str	x8, [sp, #16]
	ldr	x9, [x1, #16]
	ldr	q1, [x1]
	str	q1, [x0]
	str	x9, [x0, #16]
	str	q0, [x1]
	str	x8, [x1, #16]
	mov	w0, #0                          ; =0x0
	add	sp, sp, #32
	ret
                                        ; -- End function
	.globl	_wf_place_back$instance$22267f8259e51fb5 ; -- Begin function wf_place_back$instance$22267f8259e51fb5
	.p2align	2
_wf_place_back$instance$22267f8259e51fb5: ; @"wf_place_back$instance$22267f8259e51fb5"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	add	x9, x0, x8, lsl #4
	ldr	q0, [x1]
	stur	q0, [x9, #8]
	add	x8, x8, #1
	str	x8, [x0]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_take_back$instance$22267f8259e51fb5 ; -- Begin function wf_take_back$instance$22267f8259e51fb5
	.p2align	2
_wf_take_back$instance$22267f8259e51fb5: ; @"wf_take_back$instance$22267f8259e51fb5"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	sub	x8, x8, #1
	add	x9, x0, x8, lsl #4
	str	x8, [x0]
	ldp	x0, x1, [x9, #8]
	ret
                                        ; -- End function
	.globl	_wf_free_empty$instance$b7fb76652ce23509 ; -- Begin function wf_free_empty$instance$b7fb76652ce23509
	.p2align	2
_wf_free_empty$instance$b7fb76652ce23509: ; @"wf_free_empty$instance$b7fb76652ce23509"
; %bb.0:                                ; %entry
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_grow$instance$b1cfa6e689dc9e10 ; -- Begin function wf_grow$instance$b1cfa6e689dc9e10
	.p2align	2
_wf_grow$instance$b1cfa6e689dc9e10:     ; @"wf_grow$instance$b1cfa6e689dc9e10"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x22, x1
	mov	x19, x0
	ldr	x20, [x0]
	ldr	x23, [x20]
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	madd	x0, x1, x8, x9
	bl	_malloc
	cbz	x0, LBB117_2
; %bb.1:                                ; %window.block.ready.v2
	mov	x21, x0
	stp	x23, x22, [x0], #16
	add	x8, x23, x23, lsl #4
	lsl	x2, x8, #4
	add	x1, x20, #16
	bl	_memmove
	mov	x0, x20
	bl	_free
	str	x21, [x19]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB117_2:                               ; %window.block.oom.v2
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_place_back$instance$2af1311599ac146a ; -- Begin function wf_place_back$instance$2af1311599ac146a
	.p2align	2
_wf_place_back$instance$2af1311599ac146a: ; @"wf_place_back$instance$2af1311599ac146a"
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	ldr	x19, [x0]
	ldr	x20, [x19]
	mov	w8, #272                        ; =0x110
	madd	x8, x20, x8, x19
	add	x0, x8, #16
	mov	w2, #272                        ; =0x110
	bl	_memmove
	add	x8, x20, #1
	str	x8, [x19]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_swap$instance$1b41cffa653e924b ; -- Begin function wf_swap$instance$1b41cffa653e924b
	.p2align	2
_wf_swap$instance$1b41cffa653e924b:     ; @"wf_swap$instance$1b41cffa653e924b"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x9, [x1]
	str	x9, [x0]
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_place_back$instance$48adfc37250fbcc6 ; -- Begin function wf_place_back$instance$48adfc37250fbcc6
	.p2align	2
_wf_place_back$instance$48adfc37250fbcc6: ; @"wf_place_back$instance$48adfc37250fbcc6"
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	mov	x19, x0
	ldr	x20, [x0]
	mov	w8, #264                        ; =0x108
	madd	x8, x20, x8, x0
	add	x0, x8, #8
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	x8, x20, #1
	str	x8, [x19]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_take_back$instance$48adfc37250fbcc6 ; -- Begin function wf_take_back$instance$48adfc37250fbcc6
	.p2align	2
_wf_take_back$instance$48adfc37250fbcc6: ; @"wf_take_back$instance$48adfc37250fbcc6"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	sub	x9, x8, #1
	mov	w10, #264                       ; =0x108
	madd	x8, x8, x10, x1
	sub	x8, x8, #256
	str	x9, [x1]
	mov	x1, x8
	mov	w2, #264                        ; =0x108
	b	_memcpy
                                        ; -- End function
	.globl	_wf_free_empty$instance$d97c759d7de32f56 ; -- Begin function wf_free_empty$instance$d97c759d7de32f56
	.p2align	2
_wf_free_empty$instance$d97c759d7de32f56: ; @"wf_free_empty$instance$d97c759d7de32f56"
; %bb.0:                                ; %entry
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf__floor_run                  ; -- Begin function wf__floor_run
	.weak_definition	_wf__floor_run
	.p2align	2
_wf__floor_run:                         ; @wf__floor_run
	.cfi_startproc
; %bb.0:                                ; %entry
	b	_wf__main_body
	.cfi_endproc
                                        ; -- End function
	.globl	_wf__main_body                  ; -- Begin function wf__main_body
	.p2align	2
_wf__main_body:                         ; @wf__main_body
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w0, #3                          ; =0x3
	mov	w1, #2                          ; =0x2
	mov	w2, #2                          ; =0x2
	mov	w3, #17                         ; =0x11
	mov	x5, #0                          ; =0x0
	mov	w4, #7                          ; =0x7
	bl	_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd
	mov	w0, #3                          ; =0x3
	mov	w1, #2                          ; =0x2
	mov	w2, #2                          ; =0x2
	mov	w3, #17                         ; =0x11
	mov	w4, #3                          ; =0x3
	mov	w5, #1                          ; =0x1
	bl	_wf_map_cost_library_trace$instance$4250cb78d3f44027
	mov	x0, sp
	mov	w1, #0                          ; =0x0
	bl	_wf_std.process.exit_status
	mov	w0, #3                          ; =0x3
	mov	w1, #2                          ; =0x2
	mov	w2, #17                         ; =0x11
	bl	_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd
	mov	w0, #3                          ; =0x3
	mov	w1, #2                          ; =0x2
	mov	w2, #17                         ; =0x11
	bl	_wf_map_cost_library_geometry$instance$4250cb78d3f44027
	mov	x0, sp
	bl	_wf__ordinary_exit_code
	and	w0, w0, #0xff
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_fixture_main                ; -- Begin function wf_fixture_main
	.p2align	2
_wf_fixture_main:                       ; @wf_fixture_main
	.cfi_startproc
; %bb.0:                                ; %entry
	b	_wf__floor_run
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__const
l_.wf_resource.heap:                    ; @.wf_resource.heap
	.ascii	"{\"resource\":\"heap\"}\n"

.subsections_via_symbols
