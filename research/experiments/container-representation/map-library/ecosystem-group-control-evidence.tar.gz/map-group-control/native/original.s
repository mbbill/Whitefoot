	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function wf_resource_record_abort
l_wf_resource_record_abort:             ; @wf_resource_record_abort
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
Lloh0:
	adrp	x19, l_.wf_resource.heap@PAGE
Lloh1:
	add	x19, x19, l_.wf_resource.heap@PAGEOFF
	mov	w20, #20                        ; =0x14
	mov	w0, #2                          ; =0x2
	mov	x1, x19
	mov	x2, x20
	bl	_write
	tbz	x0, #63, LBB0_3
LBB0_1:                                 ; %error.i
                                        ; =>This Inner Loop Header: Depth=1
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #4
	b.ne	LBB0_6
; %bb.2:                                ; %write.i
                                        ;   in Loop: Header=BB0_1 Depth=1
	mov	w0, #2                          ; =0x2
	mov	x1, x19
	mov	x2, x20
	bl	_write
	tbnz	x0, #63, LBB0_1
LBB0_3:                                 ; %wf_resource_write.exit
                                        ; =>This Inner Loop Header: Depth=1
	subs	x20, x20, x0
	b.eq	LBB0_6
; %bb.4:                                ; %wf_resource_write.exit
                                        ;   in Loop: Header=BB0_3 Depth=1
	cbz	x0, LBB0_6
; %bb.5:                                ; %write.more
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x19, x19, x0
	mov	w0, #2                          ; =0x2
	mov	x1, x19
	mov	x2, x20
	bl	_write
	tbnz	x0, #63, LBB0_1
	b	LBB0_3
LBB0_6:                                 ; %abort
	bl	_abort
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_resource_abort
l_wf_resource_abort:                    ; @wf_resource_abort
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	l_wf_resource_record_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_map_cost_mix                ; -- Begin function wf_map_cost_mix
	.p2align	2
_wf_map_cost_mix:                       ; @wf_map_cost_mix
; %bb.0:                                ; %entry
	eor	x8, x0, x0, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x0, x8, x8, lsr #31
	ret
                                        ; -- End function
	.globl	_wf_map_cost_hash               ; -- Begin function wf_map_cost_hash
	.p2align	2
_wf_map_cost_hash:                      ; @wf_map_cost_hash
; %bb.0:                                ; %entry
	ldrb	w8, [x0, #8]
	tbz	w8, #0, LBB3_2
; %bb.1:
	mov	x0, #0                          ; =0x0
	ret
LBB3_2:                                 ; %bb3
	ldr	x8, [x1]
	ldr	x9, [x0]
	eor	x8, x9, x8
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x0, x8, x8, lsr #31
	ret
                                        ; -- End function
	.globl	_wf_map_cost_equal              ; -- Begin function wf_map_cost_equal
	.p2align	2
_wf_map_cost_equal:                     ; @wf_map_cost_equal
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x2]
	cmp	x8, x9
	cset	w0, eq
	ret
                                        ; -- End function
	.globl	_wf_map_cost_key                ; -- Begin function wf_map_cost_key
	.p2align	2
_wf_map_cost_key:                       ; @wf_map_cost_key
; %bb.0:                                ; %entry
	mov	w8, #1                          ; =0x1
	orr	x0, x8, x0, lsl #1
	ret
                                        ; -- End function
	.globl	_wf_map_cost_ordered            ; -- Begin function wf_map_cost_ordered
	.p2align	2
_wf_map_cost_ordered:                   ; @wf_map_cost_ordered
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	mov	w9, #131                        ; =0x83
	madd	x8, x8, x9, x1
	str	x8, [x0]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_map_cost_final              ; -- Begin function wf_map_cost_final
	.p2align	2
_wf_map_cost_final:                     ; @wf_map_cost_final
; %bb.0:                                ; %entry
	ldp	x8, x9, [x0, #8]
	add	x8, x8, x1
	eor	x10, x1, x1, lsr #30
	mov	x11, #58809                     ; =0xe5b9
	movk	x11, #7396, lsl #16
	movk	x11, #18285, lsl #32
	movk	x11, #48984, lsl #48
	mul	x10, x10, x11
	eor	x10, x10, x10, lsr #27
	mov	x11, #4587                      ; =0x11eb
	movk	x11, #4913, lsl #16
	movk	x11, #18875, lsl #32
	movk	x11, #38096, lsl #48
	mul	x10, x10, x11
	eor	x9, x9, x10, lsr #31
	eor	x9, x9, x10
	stp	x8, x9, [x0, #8]
	ldr	x8, [x0, #24]
	add	x8, x8, #1
	str	x8, [x0, #24]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_map_cost_finish             ; -- Begin function wf_map_cost_finish
	.p2align	2
_wf_map_cost_finish:                    ; @wf_map_cost_finish
; %bb.0:                                ; %entry
	ldp	x8, x9, [x0]
	ldp	x10, x11, [x0, #16]
	eor	x8, x8, x8, lsr #30
	mov	x12, #58809                     ; =0xe5b9
	movk	x12, #7396, lsl #16
	movk	x12, #18285, lsl #32
	movk	x12, #48984, lsl #48
	mul	x8, x8, x12
	eor	x8, x8, x8, lsr #27
	mov	x13, #4587                      ; =0x11eb
	movk	x13, #4913, lsl #16
	movk	x13, #18875, lsl #32
	movk	x13, #38096, lsl #48
	mul	x8, x8, x13
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x12
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x13
	eor	x12, x9, x8
	mov	x13, #31765                     ; =0x7c15
	movk	x13, #32586, lsl #16
	movk	x13, #31161, lsl #32
	movk	x13, #40503, lsl #48
	mul	x11, x11, x13
	eor	x10, x10, x11
	eor	x10, x10, x12, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	ret
                                        ; -- End function
	.globl	_wf_map_cost_word_make          ; -- Begin function wf_map_cost_word_make
	.p2align	2
_wf_map_cost_word_make:                 ; @wf_map_cost_word_make
; %bb.0:                                ; %entry
	ret
                                        ; -- End function
	.globl	_wf_map_cost_word_content       ; -- Begin function wf_map_cost_word_content
	.p2align	2
_wf_map_cost_word_content:              ; @wf_map_cost_word_content
; %bb.0:                                ; %entry
	mov	w8, #131                        ; =0x83
	madd	x0, x0, x8, x1
	ret
                                        ; -- End function
	.globl	_wf_map_cost_word_observe       ; -- Begin function wf_map_cost_word_observe
	.p2align	2
_wf_map_cost_word_observe:              ; @wf_map_cost_word_observe
; %bb.0:                                ; %entry
	ldr	x0, [x2]
	ret
                                        ; -- End function
	.globl	_wf_map_cost_word_edit          ; -- Begin function wf_map_cost_word_edit
	.p2align	2
_wf_map_cost_word_edit:                 ; @wf_map_cost_word_edit
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	add	x0, x8, #1
	str	x0, [x2]
	ret
                                        ; -- End function
	.globl	_wf_map_cost_word_consume       ; -- Begin function wf_map_cost_word_consume
	.p2align	2
_wf_map_cost_word_consume:              ; @wf_map_cost_word_consume
; %bb.0:                                ; %entry
	mov	w8, #131                        ; =0x83
	madd	x8, x1, x8, x2
	ldp	x9, x10, [x0, #8]
	add	x9, x9, x8
	eor	x8, x8, x8, lsr #30
	mov	x11, #58809                     ; =0xe5b9
	movk	x11, #7396, lsl #16
	movk	x11, #18285, lsl #32
	movk	x11, #48984, lsl #48
	mul	x8, x8, x11
	eor	x8, x8, x8, lsr #27
	mov	x11, #4587                      ; =0x11eb
	movk	x11, #4913, lsl #16
	movk	x11, #18875, lsl #32
	movk	x11, #38096, lsl #48
	mul	x8, x8, x11
	eor	x10, x10, x8, lsr #31
	eor	x8, x10, x8
	stp	x9, x8, [x0, #8]
	ldr	x8, [x0, #24]
	add	x8, x8, #1
	str	x8, [x0, #24]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_map_cost_record_make
lCPI14_0:
	.quad	1                               ; 0x1
	.quad	2                               ; 0x2
lCPI14_1:
	.quad	3                               ; 0x3
	.quad	4                               ; 0x4
lCPI14_2:
	.quad	5                               ; 0x5
	.quad	6                               ; 0x6
lCPI14_3:
	.quad	7                               ; 0x7
	.quad	8                               ; 0x8
lCPI14_4:
	.quad	9                               ; 0x9
	.quad	10                              ; 0xa
lCPI14_5:
	.quad	11                              ; 0xb
	.quad	12                              ; 0xc
lCPI14_6:
	.quad	13                              ; 0xd
	.quad	14                              ; 0xe
lCPI14_7:
	.quad	15                              ; 0xf
	.quad	16                              ; 0x10
lCPI14_8:
	.quad	17                              ; 0x11
	.quad	18                              ; 0x12
lCPI14_9:
	.quad	19                              ; 0x13
	.quad	20                              ; 0x14
lCPI14_10:
	.quad	21                              ; 0x15
	.quad	22                              ; 0x16
lCPI14_11:
	.quad	23                              ; 0x17
	.quad	24                              ; 0x18
lCPI14_12:
	.quad	25                              ; 0x19
	.quad	26                              ; 0x1a
lCPI14_13:
	.quad	27                              ; 0x1b
	.quad	28                              ; 0x1c
lCPI14_14:
	.quad	29                              ; 0x1d
	.quad	30                              ; 0x1e
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_map_cost_record_make
	.p2align	2
_wf_map_cost_record_make:               ; @wf_map_cost_record_make
; %bb.0:                                ; %entry
	dup.2d	v0, x1
Lloh2:
	adrp	x8, lCPI14_0@PAGE
Lloh3:
	ldr	q1, [x8, lCPI14_0@PAGEOFF]
Lloh4:
	adrp	x8, lCPI14_1@PAGE
Lloh5:
	ldr	q2, [x8, lCPI14_1@PAGEOFF]
	add.2d	v1, v0, v1
Lloh6:
	adrp	x8, lCPI14_2@PAGE
Lloh7:
	ldr	q3, [x8, lCPI14_2@PAGEOFF]
	add.2d	v2, v0, v2
Lloh8:
	adrp	x8, lCPI14_3@PAGE
Lloh9:
	ldr	q4, [x8, lCPI14_3@PAGEOFF]
	add.2d	v3, v0, v3
Lloh10:
	adrp	x8, lCPI14_4@PAGE
Lloh11:
	ldr	q5, [x8, lCPI14_4@PAGEOFF]
	add.2d	v4, v0, v4
Lloh12:
	adrp	x8, lCPI14_5@PAGE
Lloh13:
	ldr	q6, [x8, lCPI14_5@PAGEOFF]
	add.2d	v5, v0, v5
Lloh14:
	adrp	x8, lCPI14_6@PAGE
Lloh15:
	ldr	q7, [x8, lCPI14_6@PAGEOFF]
	add.2d	v6, v0, v6
Lloh16:
	adrp	x8, lCPI14_7@PAGE
Lloh17:
	ldr	q16, [x8, lCPI14_7@PAGEOFF]
	add.2d	v7, v0, v7
Lloh18:
	adrp	x8, lCPI14_8@PAGE
Lloh19:
	ldr	q17, [x8, lCPI14_8@PAGEOFF]
	add.2d	v16, v0, v16
Lloh20:
	adrp	x8, lCPI14_9@PAGE
Lloh21:
	ldr	q18, [x8, lCPI14_9@PAGEOFF]
	add.2d	v17, v0, v17
Lloh22:
	adrp	x8, lCPI14_10@PAGE
Lloh23:
	ldr	q19, [x8, lCPI14_10@PAGEOFF]
	add.2d	v18, v0, v18
Lloh24:
	adrp	x8, lCPI14_11@PAGE
Lloh25:
	ldr	q20, [x8, lCPI14_11@PAGEOFF]
	add.2d	v19, v0, v19
Lloh26:
	adrp	x8, lCPI14_12@PAGE
Lloh27:
	ldr	q21, [x8, lCPI14_12@PAGEOFF]
	add.2d	v20, v0, v20
Lloh28:
	adrp	x8, lCPI14_13@PAGE
Lloh29:
	ldr	q22, [x8, lCPI14_13@PAGEOFF]
	add.2d	v21, v0, v21
Lloh30:
	adrp	x8, lCPI14_14@PAGE
Lloh31:
	ldr	q23, [x8, lCPI14_14@PAGEOFF]
	add.2d	v22, v0, v22
	add.2d	v0, v0, v23
	str	x1, [x0]
	add	x8, x1, #31
	stur	q1, [x0, #8]
	stur	q2, [x0, #24]
	stur	q3, [x0, #40]
	stur	q4, [x0, #56]
	stur	q5, [x0, #72]
	stur	q6, [x0, #88]
	stur	q7, [x0, #104]
	stur	q16, [x0, #120]
	stur	q17, [x0, #136]
	stur	q18, [x0, #152]
	stur	q19, [x0, #168]
	stur	q20, [x0, #184]
	stur	q21, [x0, #200]
	stur	q22, [x0, #216]
	stur	q0, [x0, #232]
	str	x8, [x0, #248]
	ret
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdrp	Lloh28, Lloh30
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
                                        ; -- End function
	.globl	_wf_map_cost_record_content     ; -- Begin function wf_map_cost_record_content
	.p2align	2
_wf_map_cost_record_content:            ; @wf_map_cost_record_content
; %bb.0:                                ; %entry
	ldp	x9, x10, [x1]
	mov	w8, #131                        ; =0x83
	madd	x9, x0, x8, x9
	madd	x9, x9, x8, x10
	ldp	x10, x11, [x1, #16]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #32]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #48]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #64]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #80]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #96]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #112]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #128]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #144]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #160]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #176]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #192]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #208]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #224]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #240]
	madd	x9, x9, x8, x10
	madd	x0, x9, x8, x11
	ret
                                        ; -- End function
	.globl	_wf_map_cost_record_observe     ; -- Begin function wf_map_cost_record_observe
	.p2align	2
_wf_map_cost_record_observe:            ; @wf_map_cost_record_observe
; %bb.0:                                ; %entry
	ldr	x0, [x2]
	ret
                                        ; -- End function
	.globl	_wf_map_cost_record_edit        ; -- Begin function wf_map_cost_record_edit
	.p2align	2
_wf_map_cost_record_edit:               ; @wf_map_cost_record_edit
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	add	x0, x8, #1
	str	x0, [x2]
	ret
                                        ; -- End function
	.globl	_wf_map_cost_record_consume     ; -- Begin function wf_map_cost_record_consume
	.p2align	2
_wf_map_cost_record_consume:            ; @wf_map_cost_record_consume
; %bb.0:                                ; %entry
	ldp	x9, x10, [x2]
	mov	w8, #131                        ; =0x83
	madd	x9, x1, x8, x9
	madd	x9, x9, x8, x10
	ldp	x10, x11, [x2, #16]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #32]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #48]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #64]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #80]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #96]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #112]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #128]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #144]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #160]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #176]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #192]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #208]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #224]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #240]
	madd	x9, x9, x8, x10
	madd	x8, x9, x8, x11
	ldp	x9, x10, [x0, #8]
	add	x9, x8, x9
	eor	x8, x8, x8, lsr #30
	mov	x11, #58809                     ; =0xe5b9
	movk	x11, #7396, lsl #16
	movk	x11, #18285, lsl #32
	movk	x11, #48984, lsl #48
	mul	x8, x8, x11
	eor	x8, x8, x8, lsr #27
	mov	x11, #4587                      ; =0x11eb
	movk	x11, #4913, lsl #16
	movk	x11, #18875, lsl #32
	movk	x11, #38096, lsl #48
	mul	x8, x8, x11
	eor	x10, x10, x8, lsr #31
	eor	x8, x10, x8
	stp	x9, x8, [x0, #8]
	ldr	x8, [x0, #24]
	add	x8, x8, #1
	str	x8, [x0, #24]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_map_cost_lookup_result      ; -- Begin function wf_map_cost_lookup_result
	.p2align	2
_wf_map_cost_lookup_result:             ; @wf_map_cost_lookup_result
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cbz	w8, LBB19_3
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB19_4
; %bb.2:                                ; %bb3
	ldr	x8, [x1]
	mov	w9, #131                        ; =0x83
	mul	x8, x8, x9
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
LBB19_3:                                ; %bb2
	ldr	x8, [x0, #8]
	ldr	x9, [x1]
	mov	w10, #17161                     ; =0x4309
	madd	x8, x9, x10, x8
	add	x8, x8, #131
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
LBB19_4:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_map_cost_rebuild_result     ; -- Begin function wf_map_cost_rebuild_result
	.p2align	2
_wf_map_cost_rebuild_result:            ; @wf_map_cost_rebuild_result
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cbz	w8, LBB20_3
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB20_4
; %bb.2:                                ; %bb3
	ldr	x8, [x1]
	mov	w9, #131                        ; =0x83
	mul	x8, x8, x9
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
LBB20_3:                                ; %bb2
	ldr	x8, [x1]
	mov	w9, #131                        ; =0x83
	mov	x10, #1                         ; =0x1
	madd	x8, x8, x9, x10
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
LBB20_4:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_map_cost_library_word_trace ; -- Begin function wf_map_cost_library_word_trace
	.p2align	2
_wf_map_cost_library_word_trace:        ; @wf_map_cost_library_word_trace
	.cfi_startproc
; %bb.0:                                ; %entry
	cmp	x4, #8
	b.ne	LBB21_2
; %bb.1:                                ; %bb2
	mov	x0, x3
	mov	x1, x5
	b	_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd
LBB21_2:                                ; %bb3
	b	_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_map_cost_library_record_trace ; -- Begin function wf_map_cost_library_record_trace
	.p2align	2
_wf_map_cost_library_record_trace:      ; @wf_map_cost_library_record_trace
	.cfi_startproc
; %bb.0:                                ; %entry
	cmp	x4, #8
	b.ne	LBB22_2
; %bb.1:                                ; %bb2
	mov	x0, x3
	mov	x1, x5
	b	_wf_map_cost_library_policy$instance$4250cb78d3f44027
LBB22_2:                                ; %bb3
	b	_wf_map_cost_library_trace$instance$4250cb78d3f44027
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_map_cost_library_word_geometry ; -- Begin function wf_map_cost_library_word_geometry
	.p2align	2
_wf_map_cost_library_word_geometry:     ; @wf_map_cost_library_word_geometry
	.cfi_startproc
; %bb.0:                                ; %entry
	b	_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_map_cost_library_record_geometry ; -- Begin function wf_map_cost_library_record_geometry
	.p2align	2
_wf_map_cost_library_record_geometry:   ; @wf_map_cost_library_record_geometry
	.cfi_startproc
; %bb.0:                                ; %entry
	b	_wf_map_cost_library_geometry$instance$4250cb78d3f44027
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_main                        ; -- Begin function wf_main
	.p2align	2
_wf_main:                               ; @wf_main
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w0, #3                          ; =0x3
	mov	w1, #2                          ; =0x2
	mov	w2, #2                          ; =0x2
	mov	w3, #17                         ; =0x11
	mov	x5, #0                          ; =0x0
	mov	w4, #7                          ; =0x7
	bl	_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd
	mov	w0, #3                          ; =0x3
	mov	w1, #2                          ; =0x2
	mov	w2, #2                          ; =0x2
	mov	w3, #17                         ; =0x11
	mov	w4, #3                          ; =0x3
	mov	w5, #1                          ; =0x1
	bl	_wf_map_cost_library_trace$instance$4250cb78d3f44027
	mov	x0, x19
	mov	w1, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_wf_std.process.exit_status
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_probe ; -- Begin function wf_std.collections.hash_map.hash_map_probe
	.p2align	2
_wf_std.collections.hash_map.hash_map_probe: ; @wf_std.collections.hash_map.hash_map_probe
; %bb.0:                                ; %entry
	sub	x8, x2, x0
	cmp	x1, x8
	csneg	x8, x0, x8, lo
	add	x0, x8, x1
	ret
                                        ; -- End function
	.globl	_wf_array_filled$instance$581665c886d1d2c8 ; -- Begin function wf_array_filled$instance$581665c886d1d2c8
	.p2align	2
_wf_array_filled$instance$581665c886d1d2c8: ; @"wf_array_filled$instance$581665c886d1d2c8"
; %bb.0:                                ; %entry
	dup.2d	v0, x1
	stp	q0, q0, [x0]
	stp	q0, q0, [x0, #32]
	stp	q0, q0, [x0, #64]
	stp	q0, q0, [x0, #96]
	stp	q0, q0, [x0, #128]
	stp	q0, q0, [x0, #160]
	stp	q0, q0, [x0, #192]
	stp	q0, q0, [x0, #224]
	ret
                                        ; -- End function
	.globl	_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd ; -- Begin function wf_map_cost_library_policy$instance$c7c8cd11e7f079bd
	.p2align	2
_wf_map_cost_library_policy$instance$c7c8cd11e7f079bd: ; @"wf_map_cost_library_policy$instance$c7c8cd11e7f079bd"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #176
	stp	x24, x23, [sp, #112]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 176
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x0
	mov	x20, #31765                     ; =0x7c15
	movk	x20, #32586, lsl #16
	movk	x20, #31161, lsl #32
	movk	x20, #40503, lsl #48
	eor	x8, x0, x20
	cmp	x1, #0
	cset	w9, ne
	str	x8, [sp, #24]
	strb	w9, [sp, #32]
	mov	w0, #88                         ; =0x58
	bl	_malloc
	cbz	x0, LBB28_31
; %bb.1:                                ; %bb1.i.i.i
	str	wzr, [x0, #16]
	stp	xzr, xzr, [x0, #72]
	stp	xzr, xzr, [x0, #24]
	str	wzr, [x0, #40]
	stp	xzr, xzr, [x0, #48]
	str	wzr, [x0, #64]
	mov	w8, #3                          ; =0x3
	dup.2d	v0, x8
	str	q0, [x0]
	stp	x0, xzr, [sp, #8]
	add	x0, sp, #88
	add	x1, sp, #8
	add	x4, sp, #24
	mov	w2, #1                          ; =0x1
	mov	x3, x19
	bl	_wf_std.collections.hash_map.hash_map_put$instance$c7b22b9ef52855b6
	ldr	w8, [sp, #88]
	cbz	w8, LBB28_4
; %bb.2:                                ; %bb1.i.i.i
	cmp	w8, #1
	b.ne	LBB28_30
; %bb.3:                                ; %bb3.i
	ldp	x9, x8, [sp, #96]
	ldrb	w10, [sp, #92]
	mov	w11, #131                       ; =0x83
	tst	w10, #0x1
	mov	w10, #1                         ; =0x1
	cinc	x10, x10, ne
	madd	x9, x19, x11, x9
	add	x9, x9, x10
	madd	x21, x9, x11, x8
	b	LBB28_5
LBB28_4:                                ; %bb2.i
	mov	w8, #131                        ; =0x83
	mul	x21, x19, x8
LBB28_5:                                ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit"
	add	x0, sp, #88
	add	x1, sp, #8
	add	x3, x19, #1
	add	x4, sp, #24
	mov	w2, #3                          ; =0x3
	bl	_wf_std.collections.hash_map.hash_map_put$instance$c7b22b9ef52855b6
	ldr	w8, [sp, #88]
	cbz	w8, LBB28_8
; %bb.6:                                ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit"
	cmp	w8, #1
	b.ne	LBB28_30
; %bb.7:                                ; %bb3.i.1
	ldp	x9, x8, [sp, #96]
	ldrb	w10, [sp, #92]
	mov	w11, #131                       ; =0x83
	tst	w10, #0x1
	mov	w10, #1                         ; =0x1
	cinc	x10, x10, ne
	madd	x9, x21, x11, x9
	add	x9, x9, x10
	madd	x21, x9, x11, x8
	b	LBB28_9
LBB28_8:                                ; %bb2.i.1
	mov	w8, #131                        ; =0x83
	mul	x21, x21, x8
LBB28_9:                                ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit.1"
	add	x0, sp, #88
	add	x1, sp, #8
	add	x3, x19, #2
	add	x4, sp, #24
	mov	w2, #5                          ; =0x5
	bl	_wf_std.collections.hash_map.hash_map_put$instance$c7b22b9ef52855b6
	ldr	w8, [sp, #88]
	cbz	w8, LBB28_12
; %bb.10:                               ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit.1"
	cmp	w8, #1
	b.ne	LBB28_30
; %bb.11:                               ; %bb3.i.2
	ldp	x9, x8, [sp, #96]
	ldrb	w10, [sp, #92]
	mov	w11, #131                       ; =0x83
	tst	w10, #0x1
	mov	w10, #1                         ; =0x1
	cinc	x10, x10, ne
	madd	x9, x21, x11, x9
	add	x9, x9, x10
	madd	x21, x9, x11, x8
	b	LBB28_13
LBB28_12:                               ; %bb2.i.2
	mov	w8, #131                        ; =0x83
	mul	x21, x21, x8
LBB28_13:                               ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit.2"
	add	x0, sp, #64
	add	x1, sp, #8
	add	x3, x19, #10
	add	x4, sp, #24
	mov	w2, #1                          ; =0x1
	bl	_wf_std.collections.hash_map.hash_map_put$instance$c7b22b9ef52855b6
	ldr	w8, [sp, #64]
	cbz	w8, LBB28_16
; %bb.14:                               ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit.2"
	cmp	w8, #1
	b.ne	LBB28_30
; %bb.15:                               ; %bb3.i5
	ldp	x9, x8, [sp, #72]
	ldrb	w10, [sp, #68]
	mov	w11, #131                       ; =0x83
	tst	w10, #0x1
	mov	w10, #1                         ; =0x1
	cinc	x10, x10, ne
	madd	x9, x21, x11, x9
	add	x9, x9, x10
	madd	x21, x9, x11, x8
	b	LBB28_17
LBB28_16:                               ; %bb2.i19
	mov	w8, #131                        ; =0x83
	mul	x21, x21, x8
LBB28_17:                               ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit23"
	add	x0, sp, #40
	add	x1, sp, #8
	add	x3, x19, #20
	add	x4, sp, #24
	mov	w2, #7                          ; =0x7
	bl	_wf_std.collections.hash_map.hash_map_put$instance$c7b22b9ef52855b6
	ldr	w8, [sp, #40]
	cbz	w8, LBB28_20
; %bb.18:                               ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit23"
	cmp	w8, #1
	b.ne	LBB28_30
; %bb.19:                               ; %bb3.i25
	ldp	x9, x8, [sp, #48]
	ldrb	w10, [sp, #44]
	mov	w11, #131                       ; =0x83
	tst	w10, #0x1
	mov	w10, #1                         ; =0x1
	cinc	x10, x10, ne
	madd	x9, x21, x11, x9
	add	x9, x9, x10
	madd	x19, x9, x11, x8
	b	LBB28_21
LBB28_20:                               ; %bb2.i39
	mov	w8, #131                        ; =0x83
	mul	x19, x21, x8
LBB28_21:                               ; %"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd.exit43"
	mov	x22, #58809                     ; =0xe5b9
	movk	x22, #7396, lsl #16
	movk	x22, #18285, lsl #32
	movk	x22, #48984, lsl #48
	mov	x21, #4587                      ; =0x11eb
	movk	x21, #4913, lsl #16
	movk	x21, #18875, lsl #32
	movk	x21, #38096, lsl #48
	ldr	x0, [sp, #8]
	ldr	x11, [x0]
	cbz	x11, LBB28_28
; %bb.22:                               ; %bb5.i.preheader
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	x23, #0                         ; =0x0
	sub	x10, x11, #1
	mov	w12, #24                        ; =0x18
	madd	x11, x11, x12, x0
	mov	w12, #131                       ; =0x83
	b	LBB28_24
LBB28_23:                               ; %bb6.i
                                        ;   in Loop: Header=BB28_24 Depth=1
	sub	x10, x10, #1
	sub	x11, x11, #24
	cmn	x10, #1
	b.eq	LBB28_27
LBB28_24:                               ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	str	x10, [x0]
	ldur	w13, [x11, #-8]
	cmp	w13, #2
	b.lo	LBB28_23
; %bb.25:                               ; %bb5.i
                                        ;   in Loop: Header=BB28_24 Depth=1
	b.ne	LBB28_30
; %bb.26:                               ; %bb7.i
                                        ;   in Loop: Header=BB28_24 Depth=1
	ldp	x14, x13, [x11]
	madd	x13, x14, x12, x13
	add	x23, x13, x23
	eor	x13, x13, x13, lsr #30
	mul	x13, x13, x22
	eor	x13, x13, x13, lsr #27
	mul	x13, x13, x21
	eor	x9, x9, x13, lsr #31
	eor	x9, x9, x13
	add	x8, x8, #1
	b	LBB28_23
LBB28_27:                               ; %"wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760.exit.loopexit"
	mul	x8, x8, x20
	eor	x20, x8, x9
	b	LBB28_29
LBB28_28:
	mov	x23, #0                         ; =0x0
	mov	x20, #0                         ; =0x0
LBB28_29:                               ; %"wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760.exit"
	bl	_free
	eor	x8, x19, x19, lsr #30
	mul	x8, x8, x22
	eor	x8, x8, x8, lsr #27
	mul	x8, x8, x21
	eor	x9, x23, x23, lsr #30
	mul	x9, x9, x22
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x21
	eor	x10, x9, x8
	eor	x10, x20, x10, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #144]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
LBB28_30:                               ; %invalid.tag.b0.i
	bl	_abort
LBB28_31:                               ; %window.block.oom.v1.i.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd ; -- Begin function wf_map_cost_library_trace$instance$c7c8cd11e7f079bd
	.p2align	2
_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd: ; @"wf_map_cost_library_trace$instance$c7c8cd11e7f079bd"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #576
	.cfi_def_cfa_offset 672
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x23, x4
	str	x2, [sp, #48]                   ; 8-byte Folded Spill
	mov	x21, x1
	mov	x24, x0
	mov	x8, #31765                      ; =0x7c15
	movk	x8, #32586, lsl #16
	movk	x8, #31161, lsl #32
	movk	x8, #40503, lsl #48
	str	x3, [sp, #24]                   ; 8-byte Folded Spill
	eor	x8, x3, x8
	cmp	x5, #0
	cset	w9, ne
	str	x8, [sp, #488]
	strb	w9, [sp, #496]
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB29_233
; %bb.1:                                ; %bb1.i.i.i
	add	x7, sp, #64
	stp	xzr, x24, [x0]
	cbz	x24, LBB29_5
; %bb.2:                                ; %bb5.i.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
LBB29_3:                                ; %bb5.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x9], #24
	cmp	x24, x8
	b.ne	LBB29_3
; %bb.4:                                ; %bb4.bb7_crit_edge.i.i.i
	str	x24, [x0]
LBB29_5:                                ; %"wf_std.collections.hash_map.hash_map_new$instance$820b2044b97e0fbd.exit"
	add	x8, x7, #440
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
	stp	x0, xzr, [sp, #504]
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	x8, [sp, #520]
	str	xzr, [sp, #528]
	str	xzr, [sp, #544]
	str	xzr, [sp, #536]
	cbz	x21, LBB29_11
; %bb.6:                                ; %bb2.lr.ph
	add	x19, sp, #64
	mov	w20, #1                         ; =0x1
	mov	w22, #131                       ; =0x83
	mov	w25, #1                         ; =0x1
	mov	x27, x21
	ldr	x26, [sp, #24]                  ; 8-byte Folded Reload
	b	LBB29_8
LBB29_7:                                ; %bb6
                                        ;   in Loop: Header=BB29_8 Depth=1
	ldr	x8, [sp, #520]
	mul	x8, x8, x22
	add	x7, sp, #64
	str	x8, [sp, #520]
	add	x26, x26, #1
	add	x25, x25, #2
	subs	x27, x27, #1
	b.eq	LBB29_11
LBB29_8:                                ; %bb2
                                        ; =>This Inner Loop Header: Depth=1
	add	x0, sp, #64
	add	x4, x7, #424
	ldr	x1, [sp, #56]                   ; 8-byte Folded Reload
	mov	x2, x25
	mov	x3, x26
	bl	_wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad
	ldr	w8, [sp, #64]
	cbz	w8, LBB29_7
; %bb.9:                                ; %bb2
                                        ;   in Loop: Header=BB29_8 Depth=1
	cmp	w8, #1
	b.ne	LBB29_232
; %bb.10:                               ; %bb7
                                        ;   in Loop: Header=BB29_8 Depth=1
	ldrb	w8, [sp, #68]
	ldur	q0, [x19, #8]
	add	x7, sp, #64
	stur	q0, [x7, #24]
	ldr	x9, [sp, #520]
	cmp	w8, #0
	cinc	x8, x20, ne
	madd	x8, x9, x22, x8
	ldp	x9, x10, [sp, #88]
	add	x8, x9, x8
	madd	x8, x8, x22, x10
	str	x8, [sp, #520]
	add	x26, x26, #1
	add	x25, x25, #2
	subs	x27, x27, #1
	b.ne	LBB29_8
LBB29_11:                               ; %bb12.preheader
	mov	x30, #4587                      ; =0x11eb
	movk	x30, #4913, lsl #16
	movk	x30, #18875, lsl #32
	movk	x30, #38096, lsl #48
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	cbz	x9, LBB29_93
; %bb.12:                               ; %bb13.lr.ph
	lsl	x9, x24, #1
	cmp	x24, #0
	csinc	x28, x9, xzr, ne
	cmp	x23, #1
	csel	x24, x21, xzr, eq
	add	x20, sp, #64
	cmp	x23, #5
	b.ne	LBB29_100
; %bb.13:                               ; %bb13.us.preheader
	mov	x23, #0                         ; =0x0
	sub	x9, x21, x21, lsr #1
	cmp	x9, #1
	csinc	x22, x9, xzr, hi
	mov	w25, #131                       ; =0x83
	mov	w27, #1                         ; =0x1
	mov	w26, #24                        ; =0x18
	mov	w24, #17161                     ; =0x4309
	b	LBB29_15
LBB29_14:                               ;   in Loop: Header=BB29_15 Depth=1
	ldp	x23, x9, [sp, #40]              ; 16-byte Folded Reload
	mov	w24, #17161                     ; =0x4309
	cmp	x23, x9
	b.eq	LBB29_93
LBB29_15:                               ; %bb13.us
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB29_19 Depth 2
                                        ;       Child Loop BB29_25 Depth 3
                                        ;       Child Loop BB29_36 Depth 3
                                        ;     Child Loop BB29_50 Depth 2
                                        ;       Child Loop BB29_55 Depth 3
                                        ;     Child Loop BB29_63 Depth 2
                                        ;       Child Loop BB29_68 Depth 3
	ldr	x9, [sp, #504]
	cbz	x21, LBB29_41
; %bb.16:                               ; %bb20.lr.ph.us
                                        ;   in Loop: Header=BB29_15 Depth=1
	mov	x10, #0                         ; =0x0
	ldr	x11, [sp, #488]
	ldrb	w12, [sp, #496]
	ldr	x13, [sp, #512]
	mov	x14, x12
	mov	x15, x11
	mov	x19, #58809                     ; =0xe5b9
	movk	x19, #7396, lsl #16
	movk	x19, #18285, lsl #32
	movk	x19, #48984, lsl #48
	b	LBB29_19
LBB29_17:                               ; %bb2.i.i.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	cbnz	w6, LBB29_232
LBB29_18:                               ; %bb3.i81.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	str	w27, [sp, #144]
	str	xzr, [sp, #152]
	mul	x8, x8, x25
	strb	wzr, [sp, #160]
	str	x8, [sp, #520]
	add	x10, x10, #1
	cmp	x10, x22
	b.eq	LBB29_40
LBB29_19:                               ; %bb20.us
                                        ;   Parent Loop BB29_15 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB29_25 Depth 3
                                        ;       Child Loop BB29_36 Depth 3
	orr	x16, x27, x10, lsl #2
	str	x16, [sp, #552]
	cbz	x13, LBB29_31
; %bb.20:                               ; %bb3.i.i.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	tbz	w12, #0, LBB29_22
; %bb.21:                               ;   in Loop: Header=BB29_19 Depth=2
	mov	x1, #0                          ; =0x0
	ldr	x17, [x9]
	cbnz	x17, LBB29_23
	b	LBB29_31
LBB29_22:                               ; %bb3.i.i.i.i.i.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	eor	x17, x11, x16
	eor	x17, x17, x17, lsr #30
	mul	x17, x17, x19
	eor	x17, x17, x17, lsr #27
	mul	x17, x17, x30
	eor	x1, x17, x17, lsr #31
	ldr	x17, [x9]
	cbz	x17, LBB29_31
LBB29_23:                               ; %bb2.lr.ph.i.i.i.i.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	mov	x0, #0                          ; =0x0
	udiv	x2, x1, x17
	msub	x1, x2, x17, x1
	sub	x2, x17, x1
	neg	x3, x2
	b	LBB29_25
LBB29_24:                               ; %bb10.i.i.i.i.us
                                        ;   in Loop: Header=BB29_25 Depth=3
	add	x0, x0, #1
	cmp	x17, x0
	b.eq	LBB29_31
LBB29_25:                               ; %bb2.i.i.i.i.us
                                        ;   Parent Loop BB29_15 Depth=1
                                        ;     Parent Loop BB29_19 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x0, x2
	csel	x4, x1, x3, lo
	add	x4, x4, x0
	madd	x4, x4, x26, x9
	ldr	w5, [x4, #16]!
	cmp	w5, #1
	b.eq	LBB29_24
; %bb.26:                               ; %bb2.i.i.i.i.us
                                        ;   in Loop: Header=BB29_25 Depth=3
	cmp	w5, #2
	b.ne	LBB29_30
; %bb.27:                               ; %bb3.i3.i.i.i.i.us
                                        ;   in Loop: Header=BB29_25 Depth=3
	ldr	x5, [x4, #8]
	cmp	x5, x16
	b.ne	LBB29_24
; %bb.28:                               ; %bb24.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	ldr	x8, [x4, #16]
	mov	w14, #1                         ; =0x1
	str	w14, [x4]
	sub	x13, x13, #1
	stp	xzr, xzr, [x4, #8]
	str	w14, [sp, #104]
	stp	x16, x8, [sp, #112]
	ldur	q0, [x20, #48]
	stur	q0, [x7, #64]
	ldr	x8, [sp, #520]
	ldp	x15, x16, [sp, #128]
	madd	x8, x8, x25, x15
	madd	x8, x8, x25, x16
	add	x8, x8, #131
	ldr	x15, [sp, #488]
	ldrb	w16, [sp, #496]
	str	x13, [sp, #512]
	str	x8, [sp, #520]
	tbz	w16, #0, LBB29_33
; %bb.29:                               ;   in Loop: Header=BB29_19 Depth=2
	mov	x1, #0                          ; =0x0
	ldr	x16, [sp, #504]
	ldr	x17, [x16]
	cbnz	x17, LBB29_34
	b	LBB29_18
LBB29_30:                               ; %bb2.i.i.i.i.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	cbnz	w5, LBB29_232
LBB29_31:                               ; %bb23.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	str	wzr, [sp, #104]
	mul	x8, x8, x25
	stp	xzr, xzr, [x20, #48]
	str	x8, [sp, #520]
	tbz	w14, #0, LBB29_33
; %bb.32:                               ;   in Loop: Header=BB29_19 Depth=2
	mov	x1, #0                          ; =0x0
	mov	w14, #1                         ; =0x1
	ldr	x16, [sp, #504]
	ldr	x17, [x16]
	cbnz	x17, LBB29_34
	b	LBB29_18
LBB29_33:                               ; %bb3.i.i.i.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	mov	w14, #0                         ; =0x0
	ldr	x16, [sp, #552]
	eor	x16, x16, x15
	eor	x16, x16, x16, lsr #30
	mul	x16, x16, x19
	eor	x16, x16, x16, lsr #27
	mul	x16, x16, x30
	eor	x1, x16, x16, lsr #31
	ldr	x16, [sp, #504]
	ldr	x17, [x16]
	cbz	x17, LBB29_18
LBB29_34:                               ; %bb2.lr.ph.i.i.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	mov	x0, #0                          ; =0x0
	udiv	x2, x1, x17
	msub	x1, x2, x17, x1
	sub	x2, x17, x1
	neg	x3, x2
	ldr	x4, [sp, #552]
	b	LBB29_36
LBB29_35:                               ; %bb12.i.i.us
                                        ;   in Loop: Header=BB29_36 Depth=3
	add	x0, x0, #1
	cmp	x17, x0
	b.eq	LBB29_18
LBB29_36:                               ; %bb2.i.i.us
                                        ;   Parent Loop BB29_15 Depth=1
                                        ;     Parent Loop BB29_19 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x0, x2
	csel	x5, x1, x3, lo
	add	x5, x5, x0
	madd	x5, x5, x26, x16
	ldr	w6, [x5, #16]!
	cmp	w6, #1
	b.eq	LBB29_35
; %bb.37:                               ; %bb2.i.i.us
                                        ;   in Loop: Header=BB29_36 Depth=3
	cmp	w6, #2
	b.ne	LBB29_17
; %bb.38:                               ; %bb6.i.i78.us
                                        ;   in Loop: Header=BB29_36 Depth=3
	ldr	x6, [x5, #8]
	cmp	x6, x4
	b.ne	LBB29_35
; %bb.39:                               ; %bb2.i83.us
                                        ;   in Loop: Header=BB29_19 Depth=2
	ldr	x17, [x5, #16]
	str	wzr, [sp, #144]
	str	x17, [sp, #152]
	strb	wzr, [sp, #160]
	madd	x8, x8, x24, x17
	add	x8, x8, #131
	str	x8, [sp, #520]
	add	x10, x10, #1
	cmp	x10, x22
	b.ne	LBB29_19
LBB29_40:                               ;   in Loop: Header=BB29_15 Depth=1
	mov	x9, x16
	b	LBB29_42
LBB29_41:                               ;   in Loop: Header=BB29_15 Depth=1
	mov	x19, #58809                     ; =0xe5b9
	movk	x19, #7396, lsl #16
	movk	x19, #18285, lsl #32
	movk	x19, #48984, lsl #48
LBB29_42:                               ; %bb22.us
                                        ;   in Loop: Header=BB29_15 Depth=1
	ldr	x1, [x9]
	add	x2, x7, #424
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	bl	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	str	w0, [sp, #168]
	strb	w1, [sp, #172]
	strb	w2, [sp, #173]
	cbz	w0, LBB29_45
; %bb.43:                               ; %bb22.us
                                        ;   in Loop: Header=BB29_15 Depth=1
	cmp	w0, #1
	b.ne	LBB29_232
; %bb.44:                               ; %bb3.i.us
                                        ;   in Loop: Header=BB29_15 Depth=1
	ldr	x8, [sp, #520]
	mul	x8, x8, x25
	b	LBB29_46
LBB29_45:                               ; %bb2.i.us
                                        ;   in Loop: Header=BB29_15 Depth=1
	ldr	x8, [sp, #520]
	mov	x9, #1                          ; =0x1
	madd	x8, x8, x25, x9
LBB29_46:                               ; %wf_map_cost_rebuild_result.exit.us
                                        ;   in Loop: Header=BB29_15 Depth=1
	add	x7, sp, #64
	mov	x30, #4587                      ; =0x11eb
	movk	x30, #4913, lsl #16
	movk	x30, #18875, lsl #32
	movk	x30, #38096, lsl #48
	str	x8, [sp, #520]
	cbz	x21, LBB29_92
; %bb.47:                               ; %bb28.lr.ph.us
                                        ;   in Loop: Header=BB29_15 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	x10, [sp, #488]
	ldrb	w11, [sp, #496]
	ldr	x12, [sp, #504]
	b	LBB29_50
LBB29_48:                               ; %bb2.i.i121.us
                                        ;   in Loop: Header=BB29_50 Depth=2
	cbnz	w2, LBB29_232
LBB29_49:                               ; %bb3.i148.us
                                        ;   in Loop: Header=BB29_50 Depth=2
	str	w27, [sp, #176]
	str	xzr, [sp, #184]
	mul	x8, x8, x25
	strb	wzr, [sp, #192]
	str	x8, [sp, #520]
	add	x9, x9, #1
	cmp	x9, x21
	b.eq	LBB29_59
LBB29_50:                               ; %bb28.us
                                        ;   Parent Loop BB29_15 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB29_55 Depth 3
	orr	x13, x27, x9, lsl #1
	str	x13, [sp, #560]
	tbz	w11, #0, LBB29_52
; %bb.51:                               ;   in Loop: Header=BB29_50 Depth=2
	mov	x16, #0                         ; =0x0
	ldr	x14, [x12]
	cbnz	x14, LBB29_53
	b	LBB29_49
LBB29_52:                               ; %bb3.i.i.i102.us
                                        ;   in Loop: Header=BB29_50 Depth=2
	eor	x14, x10, x13
	eor	x14, x14, x14, lsr #30
	mul	x14, x14, x19
	eor	x14, x14, x14, lsr #27
	mul	x14, x14, x30
	eor	x16, x14, x14, lsr #31
	ldr	x14, [x12]
	cbz	x14, LBB29_49
LBB29_53:                               ; %bb2.lr.ph.i.i118.us
                                        ;   in Loop: Header=BB29_50 Depth=2
	mov	x15, #0                         ; =0x0
	udiv	x17, x16, x14
	msub	x16, x17, x14, x16
	sub	x17, x14, x16
	neg	x0, x17
	b	LBB29_55
LBB29_54:                               ; %bb12.i.i129.us
                                        ;   in Loop: Header=BB29_55 Depth=3
	add	x15, x15, #1
	cmp	x14, x15
	b.eq	LBB29_49
LBB29_55:                               ; %bb2.i.i121.us
                                        ;   Parent Loop BB29_15 Depth=1
                                        ;     Parent Loop BB29_50 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x15, x17
	csel	x1, x16, x0, lo
	add	x1, x1, x15
	madd	x1, x1, x26, x12
	ldr	w2, [x1, #16]!
	cmp	w2, #1
	b.eq	LBB29_54
; %bb.56:                               ; %bb2.i.i121.us
                                        ;   in Loop: Header=BB29_55 Depth=3
	cmp	w2, #2
	b.ne	LBB29_48
; %bb.57:                               ; %bb6.i.i137.us
                                        ;   in Loop: Header=BB29_55 Depth=3
	ldr	x2, [x1, #8]
	cmp	x2, x13
	b.ne	LBB29_54
; %bb.58:                               ; %bb2.i152.us
                                        ;   in Loop: Header=BB29_50 Depth=2
	ldr	x13, [x1, #16]
	str	wzr, [sp, #176]
	str	x13, [sp, #184]
	strb	wzr, [sp, #192]
	madd	x8, x8, x24, x13
	add	x8, x8, #131
	str	x8, [sp, #520]
	add	x9, x9, #1
	cmp	x9, x21
	b.ne	LBB29_50
LBB29_59:                               ; %bb33.lr.ph.us
                                        ;   in Loop: Header=BB29_15 Depth=1
	mov	x19, #0                         ; =0x0
	add	x23, x23, #1
	ldr	x28, [sp, #24]                  ; 8-byte Folded Reload
	str	x23, [sp, #40]                  ; 8-byte Folded Spill
	madd	x28, x23, x21, x28
	b	LBB29_63
LBB29_60:                               ; %bb38.us.thread
                                        ;   in Loop: Header=BB29_63 Depth=2
	stp	x27, x23, [sp, #200]
	strb	w27, [sp, #204]
	str	x24, [sp, #216]
	ldur	q0, [x20, #144]
	stur	q0, [x7, #160]
LBB29_61:                               ; %bb41.us
                                        ;   in Loop: Header=BB29_63 Depth=2
	mov	w8, #2                          ; =0x2
LBB29_62:                               ; %bb39.us
                                        ;   in Loop: Header=BB29_63 Depth=2
	ldr	x9, [sp, #520]
	madd	x8, x9, x25, x8
	ldp	x9, x10, [sp, #224]
	add	x8, x9, x8
	madd	x8, x8, x25, x10
	str	x8, [sp, #520]
	add	x19, x19, #1
	cmp	x19, x22
	b.eq	LBB29_14
LBB29_63:                               ; %bb33.us
                                        ;   Parent Loop BB29_15 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB29_68 Depth 3
	orr	x23, x27, x19, lsl #2
	ldrb	w8, [sp, #496]
	tbz	w8, #0, LBB29_72
; %bb.64:                               ;   in Loop: Header=BB29_63 Depth=2
	mov	x10, #0                         ; =0x0
	add	x24, x28, x19, lsl #1
	ldr	x9, [sp, #504]
	ldr	x8, [x9]
	cbz	x8, LBB29_73
LBB29_65:                               ; %bb2.lr.ph.i.us
                                        ;   in Loop: Header=BB29_63 Depth=2
	mov	x11, #0                         ; =0x0
	udiv	x12, x10, x8
	msub	x12, x12, x8, x10
	sub	x13, x8, x12
	neg	x14, x13
	mov	x10, x8
	b	LBB29_68
LBB29_66:                               ; %bb8.i.us
                                        ;   in Loop: Header=BB29_68 Depth=3
	cmp	x10, x8
	csel	x10, x0, x10, eq
LBB29_67:                               ; %bb16.i.us
                                        ;   in Loop: Header=BB29_68 Depth=3
	add	x11, x11, #1
	cmp	x8, x11
	b.eq	LBB29_74
LBB29_68:                               ; %bb2.i567.us
                                        ;   Parent Loop BB29_15 Depth=1
                                        ;     Parent Loop BB29_63 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x11, x13
	csel	x16, x12, x14, lo
	add	x0, x16, x11
	madd	x15, x0, x26, x9
	ldr	w17, [x15, #16]!
	cmp	w17, #1
	b.eq	LBB29_66
; %bb.69:                               ; %bb2.i567.us
                                        ;   in Loop: Header=BB29_68 Depth=3
	cmp	w17, #2
	b.ne	LBB29_78
; %bb.70:                               ; %bb3.i13.i.us
                                        ;   in Loop: Header=BB29_68 Depth=3
	ldr	x16, [x15, #8]
	cmp	x16, x23
	b.ne	LBB29_67
; %bb.71:                               ; %"wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3.exit.i.us"
                                        ;   in Loop: Header=BB29_63 Depth=2
	ldr	x8, [x15, #16]
	mov	w9, #2                          ; =0x2
	str	w9, [x15]
	str	x24, [x15, #16]
	b	LBB29_90
LBB29_72:                               ; %bb3.i.i558.us
                                        ;   in Loop: Header=BB29_63 Depth=2
	ldr	x8, [sp, #488]
	eor	x8, x8, x23
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mul	x8, x8, x30
	eor	x10, x8, x8, lsr #31
	add	x24, x28, x19, lsl #1
	ldr	x9, [sp, #504]
	ldr	x8, [x9]
	cbnz	x8, LBB29_65
LBB29_73:                               ;   in Loop: Header=BB29_63 Depth=2
	mov	x10, #0                         ; =0x0
LBB29_74:                               ; %bb4.i570.us
                                        ;   in Loop: Header=BB29_63 Depth=2
	cmp	x10, x8
	b.hs	LBB29_80
LBB29_75:                               ; %bb18.i572.us
                                        ;   in Loop: Header=BB29_63 Depth=2
	ldr	x11, [sp, #512]
	cmp	x11, #4, lsl #12                ; =16384
	b.hs	LBB29_80
; %bb.76:                               ; %bb21.i.us
                                        ;   in Loop: Header=BB29_63 Depth=2
	add	x8, x11, #1
	str	x8, [sp, #512]
	madd	x10, x10, x26, x9
	ldr	w11, [x10, #16]
	ldp	x9, x8, [x10, #24]
	mov	w12, #2                         ; =0x2
	str	w12, [x10, #16]
	stp	x23, x24, [x10, #24]
	cmp	w11, #2
	b.hs	LBB29_88
; %bb.77:                               ; %"wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit.thread.us"
                                        ;   in Loop: Header=BB29_63 Depth=2
	stp	xzr, xzr, [x7, #136]
	stur	xzr, [x7, #152]
	b	LBB29_87
LBB29_78:                               ; %bb2.i567.us
                                        ;   in Loop: Header=BB29_63 Depth=2
	cbnz	w17, LBB29_232
; %bb.79:                               ; %bb7.i574.us
                                        ;   in Loop: Header=BB29_63 Depth=2
	add	x11, x16, x11
	cmp	x10, x8
	csel	x10, x11, x10, eq
	cmp	x10, x8
	b.lo	LBB29_75
LBB29_80:                               ; %bb4.i.us
                                        ;   in Loop: Header=BB29_63 Depth=2
	lsr	x9, x8, #14
	cbnz	x9, LBB29_60
; %bb.81:                               ; %bb7.i164.us
                                        ;   in Loop: Header=BB29_63 Depth=2
	cmp	x8, #2, lsl #12                 ; =8192
	mov	w9, #8192                       ; =0x2000
	csel	x9, x8, x9, lo
	lsl	x9, x9, #1
	cmp	x8, #0
	csinc	x1, x9, xzr, ne
	cmp	x1, x8
	b.ls	LBB29_84
; %bb.82:                               ; %"wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit.i.us"
                                        ;   in Loop: Header=BB29_63 Depth=2
	add	x2, x7, #424
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	bl	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	add	x7, sp, #64
	cmp	w0, #1
	mov	x30, #4587                      ; =0x11eb
	movk	x30, #4913, lsl #16
	movk	x30, #18875, lsl #32
	movk	x30, #38096, lsl #48
	b.eq	LBB29_60
; %bb.83:                               ; %"wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit.i.us"
                                        ;   in Loop: Header=BB29_63 Depth=2
	cbnz	w0, LBB29_232
LBB29_84:                               ; %"wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit.us"
                                        ;   in Loop: Header=BB29_63 Depth=2
	add	x0, x7, #136
	add	x4, x7, #424
	ldr	x1, [sp, #56]                   ; 8-byte Folded Reload
	mov	x2, x23
	mov	x3, x24
	bl	_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad
	add	x7, sp, #64
	ldr	w8, [sp, #200]
	mov	x30, #4587                      ; =0x11eb
	movk	x30, #4913, lsl #16
	movk	x30, #18875, lsl #32
	movk	x30, #38096, lsl #48
	cbz	w8, LBB29_87
; %bb.85:                               ; %"wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit.us"
                                        ;   in Loop: Header=BB29_63 Depth=2
	cmp	w8, #1
	b.ne	LBB29_232
; %bb.86:                               ; %bb38.us
                                        ;   in Loop: Header=BB29_63 Depth=2
	ldrb	w8, [sp, #204]
	ldur	q0, [x20, #144]
	stur	q0, [x7, #160]
	cmp	w8, #1
	b.eq	LBB29_61
	b	LBB29_91
LBB29_87:                               ; %bb37.us
                                        ;   in Loop: Header=BB29_63 Depth=2
	ldr	x8, [sp, #520]
	mul	x8, x8, x25
	str	x8, [sp, #520]
	add	x19, x19, #1
	cmp	x19, x22
	b.ne	LBB29_63
	b	LBB29_14
LBB29_88:                               ; %bb21.i.us
                                        ;   in Loop: Header=BB29_63 Depth=2
	b.ne	LBB29_232
; %bb.89:                               ;   in Loop: Header=BB29_63 Depth=2
	mov	x23, x9
LBB29_90:                               ; %"wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit.thread816.us"
                                        ;   in Loop: Header=BB29_63 Depth=2
	stp	x27, x23, [sp, #200]
	str	x8, [sp, #216]
	ldrb	w8, [sp, #204]
	ldur	q0, [x20, #144]
	stur	q0, [x7, #160]
	cmp	w8, #1
	b.eq	LBB29_61
LBB29_91:                               ;   in Loop: Header=BB29_63 Depth=2
	mov	w8, #1                          ; =0x1
	b	LBB29_62
LBB29_92:                               ; %bb32.preheader.us.bb93.loopexit.us_crit_edge
                                        ;   in Loop: Header=BB29_15 Depth=1
	add	x23, x23, #1
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	cmp	x23, x9
	b.ne	LBB29_15
LBB29_93:                               ; %bb15
	add	x8, sp, #64
	add	x9, x8, #376
	ldr	x10, [sp, #56]                  ; 8-byte Folded Reload
	ldr	q0, [x10]
	str	q0, [x9]
	ldr	x0, [sp, #440]
	ldr	x13, [x0]
	mov	x22, #58809                     ; =0xe5b9
	movk	x22, #7396, lsl #16
	movk	x22, #18285, lsl #32
	movk	x22, #48984, lsl #48
	cbz	x13, LBB29_99
; %bb.94:                               ; %bb5.lr.ph.i
	ldr	x9, [sp, #528]
	ldr	x10, [sp, #536]
	ldr	x11, [sp, #544]
	sub	x12, x13, #1
	mov	w14, #24                        ; =0x18
	madd	x13, x13, x14, x0
	mov	w14, #131                       ; =0x83
	b	LBB29_96
LBB29_95:                               ; %bb6.i
                                        ;   in Loop: Header=BB29_96 Depth=1
	sub	x12, x12, #1
	sub	x13, x13, #24
	cmn	x12, #1
	b.eq	LBB29_99
LBB29_96:                               ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	str	x12, [x0]
	ldur	w15, [x13, #-8]
	cmp	w15, #2
	b.lo	LBB29_95
; %bb.97:                               ; %bb5.i
                                        ;   in Loop: Header=BB29_96 Depth=1
	b.ne	LBB29_232
; %bb.98:                               ; %bb7.i
                                        ;   in Loop: Header=BB29_96 Depth=1
	ldp	x16, x15, [x13]
	madd	x15, x16, x14, x15
	add	x9, x15, x9
	eor	x15, x15, x15, lsr #30
	mul	x15, x15, x22
	eor	x15, x15, x15, lsr #27
	mul	x15, x15, x30
	eor	x10, x10, x15, lsr #31
	eor	x10, x10, x15
	str	x9, [sp, #528]
	str	x10, [sp, #536]
	add	x11, x11, #1
	str	x11, [sp, #544]
	b	LBB29_95
LBB29_99:                               ; %"wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19.exit"
	add	x19, x7, #456
	add	x20, x8, #392
	mov	x21, x30
	bl	_free
	ldp	q0, q1, [x19]
	stp	q0, q1, [x20]
	ldp	x8, x9, [sp, #456]
	ldp	x10, x11, [sp, #472]
	eor	x8, x8, x8, lsr #30
	mul	x8, x8, x22
	eor	x8, x8, x8, lsr #27
	mul	x8, x8, x21
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x22
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x21
	eor	x12, x9, x8
	mov	x13, #31765                     ; =0x7c15
	movk	x13, #32586, lsl #16
	movk	x13, #31161, lsl #32
	movk	x13, #40503, lsl #48
	mul	x11, x11, x13
	eor	x10, x10, x11
	eor	x10, x10, x12, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	add	sp, sp, #576
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB29_100:                              ; %bb13.preheader
	mov	x3, #0                          ; =0x0
	sub	x4, x23, #9
	mov	w5, #131                        ; =0x83
	mov	w22, #1                         ; =0x1
	mov	w27, #24                        ; =0x18
	str	x4, [sp, #16]                   ; 8-byte Folded Spill
	b	LBB29_102
LBB29_101:                              ; %bb93.loopexit929
                                        ;   in Loop: Header=BB29_102 Depth=1
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	cmp	x3, x9
	b.eq	LBB29_93
LBB29_102:                              ; %bb13
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB29_121 Depth 2
                                        ;       Child Loop BB29_166 Depth 3
                                        ;       Child Loop BB29_129 Depth 3
                                        ;       Child Loop BB29_189 Depth 3
                                        ;       Child Loop BB29_197 Depth 3
                                        ;       Child Loop BB29_151 Depth 3
                                        ;       Child Loop BB29_142 Depth 3
	cmp	x23, #4
	b.eq	LBB29_106
; %bb.103:                              ; %bb13
                                        ;   in Loop: Header=BB29_102 Depth=1
	cmp	x23, #9
	b.eq	LBB29_106
; %bb.104:                              ; %bb13
                                        ;   in Loop: Header=BB29_102 Depth=1
	cmp	x23, #10
	b.ne	LBB29_115
; %bb.105:                              ; %bb49.thread
                                        ;   in Loop: Header=BB29_102 Depth=1
	mov	x9, #1                          ; =0x1
	madd	x8, x8, x5, x9
	str	x8, [sp, #520]
	b	LBB29_114
LBB29_106:                              ; %bb51
                                        ;   in Loop: Header=BB29_102 Depth=1
	cmp	x28, #4, lsl #12                ; =16384
	b.ls	LBB29_108
; %bb.107:                              ;   in Loop: Header=BB29_102 Depth=1
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	str	w0, [sp, #240]
	strb	w1, [sp, #244]
	strb	w2, [sp, #245]
	cbnz	w0, LBB29_110
	b	LBB29_113
LBB29_108:                              ; %bb3.i.i184
                                        ;   in Loop: Header=BB29_102 Depth=1
	ldr	x8, [sp, #504]
	ldr	x8, [x8]
	cmp	x28, x8
	b.ls	LBB29_112
; %bb.109:                              ; %bb6.i.i191
                                        ;   in Loop: Header=BB29_102 Depth=1
	add	x2, x7, #424
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	mov	x1, x28
	mov	x25, x3
	bl	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	mov	w5, #131                        ; =0x83
	ldr	x4, [sp, #16]                   ; 8-byte Folded Reload
	mov	x3, x25
	mov	x30, #4587                      ; =0x11eb
	movk	x30, #4913, lsl #16
	movk	x30, #18875, lsl #32
	movk	x30, #38096, lsl #48
	add	x7, sp, #64
	str	w0, [sp, #240]
	strb	w1, [sp, #244]
	strb	w2, [sp, #245]
	cbz	w0, LBB29_113
LBB29_110:                              ; %"wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit"
                                        ;   in Loop: Header=BB29_102 Depth=1
	cmp	w0, #1
	b.ne	LBB29_232
; %bb.111:                              ; %bb3.i193
                                        ;   in Loop: Header=BB29_102 Depth=1
	ldr	x8, [sp, #520]
	mul	x8, x8, x5
	str	x8, [sp, #520]
	cmp	x4, #2
	b.lo	LBB29_114
	b	LBB29_115
LBB29_112:                              ;   in Loop: Header=BB29_102 Depth=1
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #240]
	strb	w1, [sp, #244]
	strb	w2, [sp, #245]
	cbnz	w0, LBB29_110
LBB29_113:                              ; %bb2.i198
                                        ;   in Loop: Header=BB29_102 Depth=1
	ldr	x8, [sp, #520]
	mov	x9, #1                          ; =0x1
	madd	x8, x8, x5, x9
	str	x8, [sp, #520]
	cmp	x4, #2
	b.hs	LBB29_115
LBB29_114:                              ; %bb53
                                        ;   in Loop: Header=BB29_102 Depth=1
	ldr	x9, [sp, #504]
	ldr	x9, [x9]
	cmp	x9, x28
	mul	x8, x8, x5
	cinc	x8, x8, hs
	str	x8, [sp, #520]
LBB29_115:                              ; %bb43
                                        ;   in Loop: Header=BB29_102 Depth=1
	add	x3, x3, #1
	cbz	x21, LBB29_101
; %bb.116:                              ; %bb59.lr.ph
                                        ;   in Loop: Header=BB29_102 Depth=1
	mov	x19, #0                         ; =0x0
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	madd	x2, x3, x21, x9
	stp	x2, x3, [sp, #32]               ; 16-byte Folded Spill
	b	LBB29_121
LBB29_117:                              ; %bb2.i.i233
                                        ;   in Loop: Header=BB29_121 Depth=2
	cbnz	w16, LBB29_232
LBB29_118:                              ; %bb3.i260
                                        ;   in Loop: Header=BB29_121 Depth=2
	str	w22, [sp, #248]
	str	xzr, [sp, #256]
	mul	x8, x8, x5
	strb	wzr, [sp, #264]
LBB29_119:                              ; %bb92.sink.split
                                        ;   in Loop: Header=BB29_121 Depth=2
	str	x8, [sp, #520]
LBB29_120:                              ; %bb92
                                        ;   in Loop: Header=BB29_121 Depth=2
	add	x19, x19, #1
	cmp	x19, x21
	b.eq	LBB29_101
LBB29_121:                              ; %bb59
                                        ;   Parent Loop BB29_102 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB29_166 Depth 3
                                        ;       Child Loop BB29_129 Depth 3
                                        ;       Child Loop BB29_189 Depth 3
                                        ;       Child Loop BB29_197 Depth 3
                                        ;       Child Loop BB29_151 Depth 3
                                        ;       Child Loop BB29_142 Depth 3
	add	x9, x19, x24
	orr	x25, x22, x9, lsl #1
	str	x25, [sp, #568]
	cmp	x23, #3
	b.gt	LBB29_134
; %bb.122:                              ; %bb59
                                        ;   in Loop: Header=BB29_121 Depth=2
	cmp	x23, #2
	b.lo	LBB29_137
; %bb.123:                              ; %bb59
                                        ;   in Loop: Header=BB29_121 Depth=2
	b.eq	LBB29_146
; %bb.124:                              ; %bb59
                                        ;   in Loop: Header=BB29_121 Depth=2
	cmp	x23, #3
	b.ne	LBB29_120
; %bb.125:                              ; %bb78
                                        ;   in Loop: Header=BB29_121 Depth=2
	ldr	x10, [sp, #488]
	ldrb	w11, [sp, #496]
	ldr	x9, [sp, #512]
	cbz	x9, LBB29_184
; %bb.126:                              ; %bb3.i.i327
                                        ;   in Loop: Header=BB29_121 Depth=2
	eor	x12, x10, x25
	eor	x12, x12, x12, lsr #30
	mov	x13, #58809                     ; =0xe5b9
	movk	x13, #7396, lsl #16
	movk	x13, #18285, lsl #32
	movk	x13, #48984, lsl #48
	mul	x12, x12, x13
	eor	x12, x12, x12, lsr #27
	mul	x12, x12, x30
	eor	x12, x12, x12, lsr #31
	tst	w11, #0x1
	csel	x15, xzr, x12, ne
	ldr	x12, [sp, #504]
	ldr	x13, [x12]
	cbz	x13, LBB29_184
; %bb.127:                              ; %bb2.lr.ph.i.i.i.i344
                                        ;   in Loop: Header=BB29_121 Depth=2
	mov	x14, #0                         ; =0x0
	udiv	x16, x15, x13
	msub	x15, x16, x13, x15
	sub	x16, x13, x15
	neg	x17, x16
	b	LBB29_129
LBB29_128:                              ; %bb10.i.i.i.i360
                                        ;   in Loop: Header=BB29_129 Depth=3
	add	x14, x14, #1
	cmp	x13, x14
	b.eq	LBB29_184
LBB29_129:                              ; %bb2.i.i.i.i347
                                        ;   Parent Loop BB29_102 Depth=1
                                        ;     Parent Loop BB29_121 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x14, x16
	csel	x0, x15, x17, lo
	add	x0, x0, x14
	madd	x0, x0, x27, x12
	ldr	w1, [x0, #16]!
	cmp	w1, #1
	b.eq	LBB29_128
; %bb.130:                              ; %bb2.i.i.i.i347
                                        ;   in Loop: Header=BB29_129 Depth=3
	cmp	w1, #2
	b.ne	LBB29_183
; %bb.131:                              ; %bb3.i3.i.i.i.i355
                                        ;   in Loop: Header=BB29_129 Depth=3
	ldr	x1, [x0, #8]
	cmp	x1, x25
	b.ne	LBB29_128
; %bb.132:                              ; %bb81
                                        ;   in Loop: Header=BB29_121 Depth=2
	ldr	x8, [x0, #16]
	mov	w11, #1                         ; =0x1
	str	w11, [x0]
	sub	x9, x9, #1
	stp	xzr, xzr, [x0, #8]
	str	w11, [sp, #312]
	stp	x25, x8, [sp, #320]
	ldr	q0, [x20, #256]
	str	q0, [x7, #272]
	ldp	x8, x10, [sp, #336]
	ldr	x12, [sp, #520]
	ldr	x25, [sp, #568]
	madd	x8, x12, x5, x8
	madd	x8, x8, x5, x10
	add	x12, x8, #131
	ldr	x10, [sp, #488]
	ldrb	w8, [sp, #496]
	str	x9, [sp, #512]
	str	x12, [sp, #520]
	tbz	w8, #0, LBB29_186
; %bb.133:                              ;   in Loop: Header=BB29_121 Depth=2
	mov	x14, #0                         ; =0x0
	ldr	x8, [sp, #504]
	ldr	x13, [x8]
	cbnz	x13, LBB29_187
	b	LBB29_202
LBB29_134:                              ; %bb59
                                        ;   in Loop: Header=BB29_121 Depth=2
	cmp	x4, #2
	b.lo	LBB29_137
; %bb.135:                              ; %bb59
                                        ;   in Loop: Header=BB29_121 Depth=2
	cmp	x23, #7
	b.eq	LBB29_155
; %bb.136:                              ; %bb59
                                        ;   in Loop: Header=BB29_121 Depth=2
	cmp	x23, #4
	b.ne	LBB29_120
LBB29_137:                              ; %bb66
                                        ;   in Loop: Header=BB29_121 Depth=2
	ldrb	w9, [sp, #496]
	tbz	w9, #0, LBB29_139
; %bb.138:                              ;   in Loop: Header=BB29_121 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	x9, [sp, #504]
	ldr	x10, [x9]
	cbnz	x10, LBB29_140
	b	LBB29_118
LBB29_139:                              ; %bb3.i.i.i214
                                        ;   in Loop: Header=BB29_121 Depth=2
	ldr	x9, [sp, #488]
	eor	x9, x9, x25
	eor	x9, x9, x9, lsr #30
	mov	x10, #58809                     ; =0xe5b9
	movk	x10, #7396, lsl #16
	movk	x10, #18285, lsl #32
	movk	x10, #48984, lsl #48
	mul	x9, x9, x10
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x30
	eor	x12, x9, x9, lsr #31
	ldr	x9, [sp, #504]
	ldr	x10, [x9]
	cbz	x10, LBB29_118
LBB29_140:                              ; %bb2.lr.ph.i.i230
                                        ;   in Loop: Header=BB29_121 Depth=2
	mov	x11, #0                         ; =0x0
	udiv	x13, x12, x10
	msub	x12, x13, x10, x12
	sub	x13, x10, x12
	neg	x14, x13
	b	LBB29_142
LBB29_141:                              ; %bb12.i.i241
                                        ;   in Loop: Header=BB29_142 Depth=3
	add	x11, x11, #1
	cmp	x10, x11
	b.eq	LBB29_118
LBB29_142:                              ; %bb2.i.i233
                                        ;   Parent Loop BB29_102 Depth=1
                                        ;     Parent Loop BB29_121 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x11, x13
	csel	x15, x12, x14, lo
	add	x15, x15, x11
	madd	x15, x15, x27, x9
	ldr	w16, [x15, #16]!
	cmp	w16, #1
	b.eq	LBB29_141
; %bb.143:                              ; %bb2.i.i233
                                        ;   in Loop: Header=BB29_142 Depth=3
	cmp	w16, #2
	b.ne	LBB29_117
; %bb.144:                              ; %bb6.i.i249
                                        ;   in Loop: Header=BB29_142 Depth=3
	ldr	x16, [x15, #8]
	cmp	x16, x25
	b.ne	LBB29_141
; %bb.145:                              ; %bb2.i265
                                        ;   in Loop: Header=BB29_121 Depth=2
	ldr	x9, [x15, #16]
	str	wzr, [sp, #248]
	str	x9, [sp, #256]
	strb	wzr, [sp, #264]
	mov	w10, #17161                     ; =0x4309
	madd	x8, x8, x10, x9
	add	x8, x8, #131
	b	LBB29_119
LBB29_146:                              ; %bb69
                                        ;   in Loop: Header=BB29_121 Depth=2
	ldrb	w8, [sp, #496]
	tbz	w8, #0, LBB29_157
; %bb.147:                              ;   in Loop: Header=BB29_121 Depth=2
	mov	x10, #0                         ; =0x0
	add	x26, x2, x19
	ldr	x9, [sp, #504]
	ldr	x8, [x9]
	cbz	x8, LBB29_158
LBB29_148:                              ; %bb2.lr.ph.i593
                                        ;   in Loop: Header=BB29_121 Depth=2
	mov	x11, #0                         ; =0x0
	udiv	x12, x10, x8
	msub	x12, x12, x8, x10
	sub	x13, x8, x12
	neg	x14, x13
	mov	x10, x8
	b	LBB29_151
LBB29_149:                              ; %bb8.i644
                                        ;   in Loop: Header=BB29_151 Depth=3
	cmp	x10, x8
	csel	x10, x0, x10, eq
LBB29_150:                              ; %bb16.i609
                                        ;   in Loop: Header=BB29_151 Depth=3
	add	x11, x11, #1
	cmp	x8, x11
	b.eq	LBB29_159
LBB29_151:                              ; %bb2.i596
                                        ;   Parent Loop BB29_102 Depth=1
                                        ;     Parent Loop BB29_121 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x11, x13
	csel	x16, x12, x14, lo
	add	x0, x16, x11
	madd	x15, x0, x27, x9
	ldr	w17, [x15, #16]!
	cmp	w17, #1
	b.eq	LBB29_149
; %bb.152:                              ; %bb2.i596
                                        ;   in Loop: Header=BB29_151 Depth=3
	cmp	w17, #2
	b.ne	LBB29_170
; %bb.153:                              ; %bb3.i13.i605
                                        ;   in Loop: Header=BB29_151 Depth=3
	ldr	x16, [x15, #8]
	cmp	x16, x25
	b.ne	LBB29_150
; %bb.154:                              ; %"wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3.exit.i639"
                                        ;   in Loop: Header=BB29_121 Depth=2
	ldr	x8, [x15, #16]
	mov	w9, #2                          ; =0x2
	str	w9, [x15]
	str	x26, [x15, #16]
	b	LBB29_228
LBB29_155:                              ; %bb90
                                        ;   in Loop: Header=BB29_121 Depth=2
	ldrb	w9, [sp, #496]
	tbz	w9, #0, LBB29_163
; %bb.156:                              ;   in Loop: Header=BB29_121 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	x9, [sp, #504]
	ldr	x10, [x9]
	cbnz	x10, LBB29_164
	b	LBB29_182
LBB29_157:                              ; %bb3.i.i577
                                        ;   in Loop: Header=BB29_121 Depth=2
	ldr	x8, [sp, #488]
	eor	x8, x8, x25
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mul	x8, x8, x30
	eor	x10, x8, x8, lsr #31
	add	x26, x2, x19
	ldr	x9, [sp, #504]
	ldr	x8, [x9]
	cbnz	x8, LBB29_148
LBB29_158:                              ;   in Loop: Header=BB29_121 Depth=2
	mov	x10, #0                         ; =0x0
LBB29_159:                              ; %bb4.i613
                                        ;   in Loop: Header=BB29_121 Depth=2
	cmp	x10, x8
	b.hs	LBB29_172
LBB29_160:                              ; %bb18.i620
                                        ;   in Loop: Header=BB29_121 Depth=2
	ldr	x11, [sp, #512]
	lsr	x12, x11, #14
	cbnz	x12, LBB29_172
; %bb.161:                              ; %bb21.i624
                                        ;   in Loop: Header=BB29_121 Depth=2
	add	x8, x11, #1
	str	x8, [sp, #512]
	madd	x10, x10, x27, x9
	ldr	w11, [x10, #16]
	ldp	x9, x8, [x10, #24]
	mov	w12, #2                         ; =0x2
	str	w12, [x10, #16]
	stp	x25, x26, [x10, #24]
	cmp	w11, #2
	b.hs	LBB29_226
; %bb.162:                              ; %"wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit307.thread"
                                        ;   in Loop: Header=BB29_121 Depth=2
	stp	xzr, xzr, [x7, #208]
	stur	xzr, [x7, #224]
	b	LBB29_220
LBB29_163:                              ; %bb3.i.i.i499
                                        ;   in Loop: Header=BB29_121 Depth=2
	ldr	x9, [sp, #488]
	eor	x9, x9, x25
	eor	x9, x9, x9, lsr #30
	mov	x10, #58809                     ; =0xe5b9
	movk	x10, #7396, lsl #16
	movk	x10, #18285, lsl #32
	movk	x10, #48984, lsl #48
	mul	x9, x9, x10
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x30
	eor	x12, x9, x9, lsr #31
	ldr	x9, [sp, #504]
	ldr	x10, [x9]
	cbz	x10, LBB29_182
LBB29_164:                              ; %bb2.lr.ph.i.i515
                                        ;   in Loop: Header=BB29_121 Depth=2
	mov	x11, #0                         ; =0x0
	udiv	x13, x12, x10
	msub	x12, x13, x10, x12
	sub	x13, x10, x12
	neg	x14, x13
	b	LBB29_166
LBB29_165:                              ; %bb12.i.i526
                                        ;   in Loop: Header=BB29_166 Depth=3
	add	x11, x11, #1
	cmp	x10, x11
	b.eq	LBB29_182
LBB29_166:                              ; %bb2.i.i518
                                        ;   Parent Loop BB29_102 Depth=1
                                        ;     Parent Loop BB29_121 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x11, x13
	csel	x15, x12, x14, lo
	add	x15, x15, x11
	madd	x15, x15, x27, x9
	ldr	w16, [x15, #16]!
	cmp	w16, #1
	b.eq	LBB29_165
; %bb.167:                              ; %bb2.i.i518
                                        ;   in Loop: Header=BB29_166 Depth=3
	cmp	w16, #2
	b.ne	LBB29_181
; %bb.168:                              ; %bb6.i.i534
                                        ;   in Loop: Header=BB29_166 Depth=3
	ldr	x16, [x15, #8]
	cmp	x16, x25
	b.ne	LBB29_165
; %bb.169:                              ; %bb2.i549
                                        ;   in Loop: Header=BB29_121 Depth=2
	ldr	x8, [x15, #16]
	add	x9, x8, #1
	str	x9, [x15, #16]
	str	wzr, [sp, #416]
	str	x9, [sp, #424]
	strb	wzr, [sp, #432]
	ldr	x9, [sp, #520]
	mov	w10, #17161                     ; =0x4309
	madd	x8, x9, x10, x8
	add	x8, x8, #132
	b	LBB29_119
LBB29_170:                              ; %bb2.i596
                                        ;   in Loop: Header=BB29_121 Depth=2
	cbnz	w17, LBB29_232
; %bb.171:                              ; %bb7.i647
                                        ;   in Loop: Header=BB29_121 Depth=2
	add	x11, x16, x11
	cmp	x10, x8
	csel	x10, x11, x10, eq
	cmp	x10, x8
	b.lo	LBB29_160
LBB29_172:                              ; %bb4.i282
                                        ;   in Loop: Header=BB29_121 Depth=2
	lsr	x9, x8, #14
	cbz	x9, LBB29_174
LBB29_173:                              ; %bb73.thread
                                        ;   in Loop: Header=BB29_121 Depth=2
	stp	x22, x25, [sp, #272]
	strb	w22, [sp, #276]
	str	x26, [sp, #288]
	ldur	q0, [x20, #216]
	stur	q0, [x7, #232]
	b	LBB29_180
LBB29_174:                              ; %bb7.i286
                                        ;   in Loop: Header=BB29_121 Depth=2
	cmp	x8, #2, lsl #12                 ; =8192
	mov	w9, #8192                       ; =0x2000
	csel	x9, x8, x9, lo
	lsl	x9, x9, #1
	cmp	x8, #0
	csinc	x1, x9, xzr, ne
	cmp	x1, x8
	b.ls	LBB29_177
; %bb.175:                              ; %"wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit.i295"
                                        ;   in Loop: Header=BB29_121 Depth=2
	add	x2, x7, #424
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	bl	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	add	x7, sp, #64
	cbz	w0, LBB29_177
; %bb.176:                              ; %"wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit.i295"
                                        ;   in Loop: Header=BB29_121 Depth=2
	cmp	w0, #1
	mov	x30, #4587                      ; =0x11eb
	movk	x30, #4913, lsl #16
	movk	x30, #18875, lsl #32
	movk	x30, #38096, lsl #48
	ldp	x2, x3, [sp, #32]               ; 16-byte Folded Reload
	ldr	x4, [sp, #16]                   ; 8-byte Folded Reload
	mov	w5, #131                        ; =0x83
	b.eq	LBB29_173
	b	LBB29_232
LBB29_177:                              ; %"wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit307"
                                        ;   in Loop: Header=BB29_121 Depth=2
	add	x0, x7, #208
	add	x4, x7, #424
	ldr	x1, [sp, #56]                   ; 8-byte Folded Reload
	mov	x2, x25
	mov	x3, x26
	bl	_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad
	add	x7, sp, #64
	ldr	w8, [sp, #272]
	mov	x30, #4587                      ; =0x11eb
	movk	x30, #4913, lsl #16
	movk	x30, #18875, lsl #32
	movk	x30, #38096, lsl #48
	ldp	x2, x3, [sp, #32]               ; 16-byte Folded Reload
	ldr	x4, [sp, #16]                   ; 8-byte Folded Reload
	mov	w5, #131                        ; =0x83
	cbz	w8, LBB29_220
; %bb.178:                              ; %"wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit307"
                                        ;   in Loop: Header=BB29_121 Depth=2
	cmp	w8, #1
	b.ne	LBB29_232
; %bb.179:                              ; %bb73
                                        ;   in Loop: Header=BB29_121 Depth=2
	ldrb	w8, [sp, #276]
	ldur	q0, [x20, #216]
	stur	q0, [x7, #232]
	tbz	w8, #0, LBB29_229
LBB29_180:                              ; %bb76
                                        ;   in Loop: Header=BB29_121 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB29_230
LBB29_181:                              ; %bb2.i.i518
                                        ;   in Loop: Header=BB29_121 Depth=2
	cbnz	w16, LBB29_232
LBB29_182:                              ; %bb3.i544
                                        ;   in Loop: Header=BB29_121 Depth=2
	str	w22, [sp, #416]
	str	xzr, [sp, #424]
	mul	x8, x8, x5
	strb	wzr, [sp, #432]
	b	LBB29_119
LBB29_183:                              ; %bb2.i.i.i.i347
                                        ;   in Loop: Header=BB29_121 Depth=2
	cbnz	w1, LBB29_232
LBB29_184:                              ; %bb80
                                        ;   in Loop: Header=BB29_121 Depth=2
	str	wzr, [sp, #312]
	mul	x12, x8, x5
	stp	xzr, xzr, [x20, #256]
	str	x12, [sp, #520]
	tbz	w11, #0, LBB29_186
; %bb.185:                              ;   in Loop: Header=BB29_121 Depth=2
	mov	x14, #0                         ; =0x0
	mov	w11, #1                         ; =0x1
	ldr	x8, [sp, #504]
	ldr	x13, [x8]
	cbnz	x13, LBB29_187
	b	LBB29_202
LBB29_186:                              ; %bb3.i.i.i378
                                        ;   in Loop: Header=BB29_121 Depth=2
	mov	w11, #0                         ; =0x0
	eor	x8, x25, x10
	eor	x8, x8, x8, lsr #30
	mov	x13, #58809                     ; =0xe5b9
	movk	x13, #7396, lsl #16
	movk	x13, #18285, lsl #32
	movk	x13, #48984, lsl #48
	mul	x8, x8, x13
	eor	x8, x8, x8, lsr #27
	mul	x8, x8, x30
	eor	x14, x8, x8, lsr #31
	ldr	x8, [sp, #504]
	ldr	x13, [x8]
	cbz	x13, LBB29_202
LBB29_187:                              ; %bb2.lr.ph.i.i394
                                        ;   in Loop: Header=BB29_121 Depth=2
	mov	x15, #0                         ; =0x0
	udiv	x16, x14, x13
	msub	x14, x16, x13, x14
	sub	x16, x13, x14
	neg	x17, x16
	b	LBB29_189
LBB29_188:                              ; %bb12.i.i405
                                        ;   in Loop: Header=BB29_189 Depth=3
	add	x15, x15, #1
	cmp	x13, x15
	b.eq	LBB29_202
LBB29_189:                              ; %bb2.i.i397
                                        ;   Parent Loop BB29_102 Depth=1
                                        ;     Parent Loop BB29_121 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x15, x16
	csel	x0, x14, x17, lo
	add	x0, x0, x15
	madd	x0, x0, x27, x8
	ldr	w1, [x0, #16]!
	cmp	w1, #1
	b.eq	LBB29_188
; %bb.190:                              ; %bb2.i.i397
                                        ;   in Loop: Header=BB29_189 Depth=3
	cmp	w1, #2
	b.ne	LBB29_201
; %bb.191:                              ; %bb6.i.i413
                                        ;   in Loop: Header=BB29_189 Depth=3
	ldr	x1, [x0, #8]
	cmp	x1, x25
	b.ne	LBB29_188
; %bb.192:                              ; %bb2.i429
                                        ;   in Loop: Header=BB29_121 Depth=2
	ldr	x13, [x0, #16]
	str	wzr, [sp, #352]
	str	x13, [sp, #360]
	strb	wzr, [sp, #368]
	mov	w14, #17161                     ; =0x4309
	madd	x12, x12, x14, x13
	add	x12, x12, #131
	str	x12, [sp, #520]
	tbnz	w11, #0, LBB29_203
LBB29_193:                              ; %bb3.i.i653
                                        ;   in Loop: Header=BB29_121 Depth=2
	eor	x10, x25, x10
	eor	x10, x10, x10, lsr #30
	mov	x11, #58809                     ; =0xe5b9
	movk	x11, #7396, lsl #16
	movk	x11, #18285, lsl #32
	movk	x11, #48984, lsl #48
	mul	x10, x10, x11
	eor	x10, x10, x10, lsr #27
	mul	x10, x10, x30
	eor	x11, x10, x10, lsr #31
	add	x26, x2, x19
	ldr	x10, [x8]
	cbz	x10, LBB29_204
LBB29_194:                              ; %bb2.lr.ph.i669
                                        ;   in Loop: Header=BB29_121 Depth=2
	mov	x12, #0                         ; =0x0
	udiv	x13, x11, x10
	msub	x13, x13, x10, x11
	sub	x14, x10, x13
	neg	x15, x14
	mov	x11, x10
	b	LBB29_197
LBB29_195:                              ; %bb8.i720
                                        ;   in Loop: Header=BB29_197 Depth=3
	cmp	x11, x10
	csel	x11, x1, x11, eq
LBB29_196:                              ; %bb16.i685
                                        ;   in Loop: Header=BB29_197 Depth=3
	add	x12, x12, #1
	cmp	x10, x12
	b.eq	LBB29_205
LBB29_197:                              ; %bb2.i672
                                        ;   Parent Loop BB29_102 Depth=1
                                        ;     Parent Loop BB29_121 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x12, x14
	csel	x17, x13, x15, lo
	add	x1, x17, x12
	madd	x16, x1, x27, x8
	ldr	w0, [x16, #16]!
	cmp	w0, #1
	b.eq	LBB29_195
; %bb.198:                              ; %bb2.i672
                                        ;   in Loop: Header=BB29_197 Depth=3
	cmp	w0, #2
	b.ne	LBB29_209
; %bb.199:                              ; %bb3.i13.i681
                                        ;   in Loop: Header=BB29_197 Depth=3
	ldr	x17, [x16, #8]
	cmp	x17, x25
	b.ne	LBB29_196
; %bb.200:                              ; %"wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3.exit.i715"
                                        ;   in Loop: Header=BB29_121 Depth=2
	ldr	x8, [x16, #16]
	mov	w9, #2                          ; =0x2
	str	w9, [x16]
	str	x26, [x16, #16]
	b	LBB29_223
LBB29_201:                              ; %bb2.i.i397
                                        ;   in Loop: Header=BB29_121 Depth=2
	cbnz	w1, LBB29_232
LBB29_202:                              ; %bb3.i424
                                        ;   in Loop: Header=BB29_121 Depth=2
	str	w22, [sp, #352]
	str	xzr, [sp, #360]
	mul	x12, x12, x5
	strb	wzr, [sp, #368]
	str	x12, [sp, #520]
	tbz	w11, #0, LBB29_193
LBB29_203:                              ;   in Loop: Header=BB29_121 Depth=2
	mov	x11, #0                         ; =0x0
	add	x26, x2, x19
	ldr	x10, [x8]
	cbnz	x10, LBB29_194
LBB29_204:                              ;   in Loop: Header=BB29_121 Depth=2
	mov	x11, #0                         ; =0x0
LBB29_205:                              ; %bb4.i689
                                        ;   in Loop: Header=BB29_121 Depth=2
	cmp	x11, x10
	b.hs	LBB29_211
LBB29_206:                              ; %bb4.i689
                                        ;   in Loop: Header=BB29_121 Depth=2
	cmp	x9, #4, lsl #12                 ; =16384
	b.hs	LBB29_211
; %bb.207:                              ; %bb21.i700
                                        ;   in Loop: Header=BB29_121 Depth=2
	add	x9, x9, #1
	str	x9, [sp, #512]
	madd	x10, x11, x27, x8
	ldr	w11, [x10, #16]
	ldp	x9, x8, [x10, #24]
	mov	w12, #2                         ; =0x2
	str	w12, [x10, #16]
	stp	x25, x26, [x10, #24]
	cmp	w11, #2
	b.hs	LBB29_221
; %bb.208:                              ; %"wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit471.thread"
                                        ;   in Loop: Header=BB29_121 Depth=2
	stp	xzr, xzr, [x7, #312]
	str	xzr, [x7, #328]
	b	LBB29_220
LBB29_209:                              ; %bb2.i672
                                        ;   in Loop: Header=BB29_121 Depth=2
	cbnz	w0, LBB29_232
; %bb.210:                              ; %bb7.i723
                                        ;   in Loop: Header=BB29_121 Depth=2
	add	x12, x17, x12
	cmp	x11, x10
	csel	x11, x12, x11, eq
	cmp	x11, x10
	b.lo	LBB29_206
LBB29_211:                              ; %bb4.i446
                                        ;   in Loop: Header=BB29_121 Depth=2
	lsr	x8, x10, #14
	cbz	x8, LBB29_213
LBB29_212:                              ; %bb85.thread
                                        ;   in Loop: Header=BB29_121 Depth=2
	stp	x22, x25, [sp, #376]
	strb	w22, [x7, #316]
	str	x26, [sp, #392]
	ldr	q0, [x20, #320]
	str	q0, [x7, #336]
	b	LBB29_219
LBB29_213:                              ; %bb7.i450
                                        ;   in Loop: Header=BB29_121 Depth=2
	cmp	x10, #2, lsl #12                ; =8192
	mov	w8, #8192                       ; =0x2000
	csel	x8, x10, x8, lo
	lsl	x8, x8, #1
	cmp	x10, #0
	csinc	x1, x8, xzr, ne
	cmp	x1, x10
	b.ls	LBB29_216
; %bb.214:                              ; %"wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit.i459"
                                        ;   in Loop: Header=BB29_121 Depth=2
	add	x2, x7, #424
	ldr	x0, [sp, #56]                   ; 8-byte Folded Reload
	bl	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	add	x7, sp, #64
	cbz	w0, LBB29_216
; %bb.215:                              ; %"wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit.i459"
                                        ;   in Loop: Header=BB29_121 Depth=2
	cmp	w0, #1
	mov	x30, #4587                      ; =0x11eb
	movk	x30, #4913, lsl #16
	movk	x30, #18875, lsl #32
	movk	x30, #38096, lsl #48
	ldp	x2, x3, [sp, #32]               ; 16-byte Folded Reload
	ldr	x4, [sp, #16]                   ; 8-byte Folded Reload
	mov	w5, #131                        ; =0x83
	b.eq	LBB29_212
	b	LBB29_232
LBB29_216:                              ; %"wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit471"
                                        ;   in Loop: Header=BB29_121 Depth=2
	add	x0, x7, #312
	add	x4, x7, #424
	ldr	x1, [sp, #56]                   ; 8-byte Folded Reload
	mov	x2, x25
	mov	x3, x26
	bl	_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad
	add	x7, sp, #64
	ldr	w8, [sp, #376]
	mov	x30, #4587                      ; =0x11eb
	movk	x30, #4913, lsl #16
	movk	x30, #18875, lsl #32
	movk	x30, #38096, lsl #48
	ldp	x2, x3, [sp, #32]               ; 16-byte Folded Reload
	ldr	x4, [sp, #16]                   ; 8-byte Folded Reload
	mov	w5, #131                        ; =0x83
	cbz	w8, LBB29_220
; %bb.217:                              ; %"wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit471"
                                        ;   in Loop: Header=BB29_121 Depth=2
	cmp	w8, #1
	b.ne	LBB29_232
; %bb.218:                              ; %bb85
                                        ;   in Loop: Header=BB29_121 Depth=2
	ldrb	w8, [x7, #316]
	ldr	q0, [x20, #320]
	str	q0, [x7, #336]
	tbz	w8, #0, LBB29_224
LBB29_219:                              ; %bb88
                                        ;   in Loop: Header=BB29_121 Depth=2
	mov	w8, #2                          ; =0x2
	b	LBB29_225
LBB29_220:                              ; %bb72
                                        ;   in Loop: Header=BB29_121 Depth=2
	ldr	x8, [sp, #520]
	mul	x8, x8, x5
	b	LBB29_119
LBB29_221:                              ; %bb21.i700
                                        ;   in Loop: Header=BB29_121 Depth=2
	b.ne	LBB29_232
; %bb.222:                              ;   in Loop: Header=BB29_121 Depth=2
	mov	x25, x9
LBB29_223:                              ; %"wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit471.thread896"
                                        ;   in Loop: Header=BB29_121 Depth=2
	stp	x22, x25, [sp, #376]
	str	x8, [sp, #392]
	ldrb	w8, [x7, #316]
	ldr	q0, [x20, #320]
	str	q0, [x7, #336]
	tbnz	w8, #0, LBB29_219
LBB29_224:                              ;   in Loop: Header=BB29_121 Depth=2
	mov	w8, #1                          ; =0x1
LBB29_225:                              ; %bb86
                                        ;   in Loop: Header=BB29_121 Depth=2
	ldr	x9, [sp, #520]
	madd	x8, x9, x5, x8
	ldp	x9, x10, [sp, #400]
	b	LBB29_231
LBB29_226:                              ; %bb21.i624
                                        ;   in Loop: Header=BB29_121 Depth=2
	b.ne	LBB29_232
; %bb.227:                              ;   in Loop: Header=BB29_121 Depth=2
	mov	x25, x9
LBB29_228:                              ; %"wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad.exit307.thread852"
                                        ;   in Loop: Header=BB29_121 Depth=2
	stp	x22, x25, [sp, #272]
	str	x8, [sp, #288]
	ldrb	w8, [sp, #276]
	ldur	q0, [x20, #216]
	stur	q0, [x7, #232]
	tbnz	w8, #0, LBB29_180
LBB29_229:                              ;   in Loop: Header=BB29_121 Depth=2
	mov	w8, #1                          ; =0x1
LBB29_230:                              ; %bb74
                                        ;   in Loop: Header=BB29_121 Depth=2
	ldr	x9, [sp, #520]
	madd	x8, x9, x5, x8
	ldp	x9, x10, [sp, #296]
LBB29_231:                              ; %bb92.sink.split
                                        ;   in Loop: Header=BB29_121 Depth=2
	add	x8, x9, x8
	madd	x8, x8, x5, x10
	b	LBB29_119
LBB29_232:                              ; %invalid.tag.b2
	bl	_abort
LBB29_233:                              ; %window.block.oom.v1.i.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_map_cost_library_policy$instance$4250cb78d3f44027
lCPI30_0:
	.quad	42                              ; 0x2a
	.quad	43                              ; 0x2b
lCPI30_1:
	.quad	44                              ; 0x2c
	.quad	45                              ; 0x2d
lCPI30_2:
	.quad	46                              ; 0x2e
	.quad	47                              ; 0x2f
lCPI30_3:
	.quad	48                              ; 0x30
	.quad	49                              ; 0x31
lCPI30_4:
	.quad	50                              ; 0x32
	.quad	51                              ; 0x33
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_map_cost_library_policy$instance$4250cb78d3f44027
	.p2align	2
_wf_map_cost_library_policy$instance$4250cb78d3f44027: ; @"wf_map_cost_library_policy$instance$4250cb78d3f44027"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #1904
	.cfi_def_cfa_offset 2000
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
	mov	x8, #31765                      ; =0x7c15
	movk	x8, #32586, lsl #16
	movk	x8, #31161, lsl #32
	movk	x8, #40503, lsl #48
	eor	x8, x0, x8
	cmp	x1, #0
	cset	w9, ne
	str	x8, [sp, #304]
	strb	w9, [sp, #312]
	mov	w0, #832                        ; =0x340
	bl	_malloc
	cbz	x0, LBB30_2
; %bb.1:                                ; %bb1.i.i.i
	str	wzr, [x0, #16]
	add	x8, x0, #296
	add	x9, x0, #568
	str	xzr, [x0, #824]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9]
	stp	q0, q0, [x9, #32]
	stp	q0, q0, [x9, #64]
	stp	q0, q0, [x9, #96]
	stp	q0, q0, [x9, #128]
	stp	q0, q0, [x9, #160]
	stp	q0, q0, [x9, #192]
	stp	q0, q0, [x9, #224]
	stur	q0, [x0, #248]
	stur	q0, [x0, #232]
	stur	q0, [x0, #216]
	stur	q0, [x0, #200]
	stur	q0, [x0, #184]
	stur	q0, [x0, #168]
	stur	q0, [x0, #152]
	stur	q0, [x0, #136]
	stur	q0, [x0, #120]
	stur	q0, [x0, #104]
	stur	q0, [x0, #88]
	stur	q0, [x0, #72]
	stur	q0, [x0, #56]
	stur	q0, [x0, #40]
	mov	x9, x0
	str	q0, [x9, #24]!
	stur	q0, [x9, #252]
	str	q0, [x9, #240]
	stur	q0, [x8, #252]
	stp	q0, q0, [x8, #224]
	stp	q0, q0, [x8, #192]
	stp	q0, q0, [x8, #160]
	stp	q0, q0, [x8, #128]
	stp	q0, q0, [x8, #96]
	stp	q0, q0, [x8, #64]
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8]
	mov	w8, #3                          ; =0x3
	dup.2d	v0, x8
	str	q0, [x0]
	stp	x0, xzr, [sp, #288]
	add	x8, x19, #1
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	add	x24, x19, #2
	add	x25, x19, #3
	stp	x25, x24, [sp, #128]            ; 16-byte Folded Spill
	add	x26, x19, #4
	add	x27, x19, #5
	stp	x27, x26, [sp, #112]            ; 16-byte Folded Spill
	add	x28, x19, #6
	add	x30, x19, #7
	stp	x30, x28, [sp, #96]             ; 16-byte Folded Spill
	add	x9, x19, #8
	add	x8, x19, #9
	stp	x8, x9, [sp, #8]                ; 16-byte Folded Spill
	add	x21, x19, #10
	add	x22, x19, #11
	add	x23, x19, #12
	stp	x23, x22, [sp, #232]            ; 16-byte Folded Spill
	add	x20, x19, #13
	add	x7, x19, #14
	add	x6, x19, #15
	add	x5, x19, #16
	stp	x6, x5, [sp, #184]              ; 16-byte Folded Spill
	add	x4, x19, #17
	add	x3, x19, #18
	add	x2, x19, #19
	add	x8, x19, #20
	str	x8, [sp, #248]                  ; 8-byte Folded Spill
	add	x9, x19, #21
	add	x10, x19, #22
	stp	x10, x9, [sp, #48]              ; 16-byte Folded Spill
	add	x11, x19, #23
	add	x12, x19, #24
	stp	x12, x11, [sp, #32]             ; 16-byte Folded Spill
	add	x13, x19, #25
	str	x13, [sp, #24]                  ; 8-byte Folded Spill
	add	x14, x19, #26
	add	x15, x19, #27
	stp	x15, x14, [sp, #216]            ; 16-byte Folded Spill
	add	x16, x19, #28
	add	x17, x19, #29
	stp	x17, x16, [sp, #200]            ; 16-byte Folded Spill
	add	x0, x19, #30
	add	x1, x19, #31
	stp	x1, x0, [sp, #152]              ; 16-byte Folded Spill
	stp	x19, xzr, [sp, #256]
	stp	xzr, xzr, [sp, #272]
	str	x19, [sp, #1648]
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	x8, [sp, #1656]
	str	x24, [sp, #1664]
	str	x25, [sp, #1672]
	str	x26, [sp, #1680]
	str	x27, [sp, #1688]
	str	x28, [sp, #1696]
	str	x30, [sp, #1704]
	ldp	x25, x24, [sp, #8]              ; 16-byte Folded Reload
	str	x24, [sp, #1712]
	str	x25, [sp, #1720]
	str	x21, [sp, #1728]
	mov	x28, x21
	stp	x21, x20, [sp, #72]             ; 16-byte Folded Spill
	str	x22, [sp, #1736]
	str	x23, [sp, #1744]
	str	x20, [sp, #1752]
	mov	x27, x20
	str	x7, [sp, #1760]
	mov	x26, x7
	str	x7, [sp, #88]                   ; 8-byte Folded Spill
	str	x6, [sp, #1768]
	str	x5, [sp, #1776]
	str	x4, [sp, #1784]
	mov	x23, x4
	str	x4, [sp, #144]                  ; 8-byte Folded Spill
	str	x3, [sp, #1792]
	mov	x22, x3
	stp	x3, x2, [sp, #168]              ; 16-byte Folded Spill
	str	x2, [sp, #1800]
	mov	x21, x2
	ldr	x20, [sp, #248]                 ; 8-byte Folded Reload
	str	x20, [sp, #1808]
	str	x9, [sp, #1816]
	str	x10, [sp, #1824]
	str	x11, [sp, #1832]
	str	x12, [sp, #1840]
	str	x13, [sp, #1848]
	str	x14, [sp, #1856]
	str	x15, [sp, #1864]
	str	x16, [sp, #1872]
	str	x17, [sp, #1880]
	str	x0, [sp, #1888]
	str	x1, [sp, #1896]
	add	x0, sp, #1376
	add	x1, sp, #288
	add	x3, sp, #1648
	add	x4, sp, #304
	mov	w2, #1                          ; =0x1
	bl	_wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07
	add	x0, sp, #1376
	add	x1, sp, #256
	bl	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	x8, [sp, #1648]
	add	x8, x19, #32
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
	ldp	x9, x10, [sp, #128]             ; 16-byte Folded Reload
	str	x10, [sp, #1656]
	str	x9, [sp, #1664]
	ldp	x9, x10, [sp, #112]             ; 16-byte Folded Reload
	str	x10, [sp, #1672]
	str	x9, [sp, #1680]
	ldp	x9, x10, [sp, #96]              ; 16-byte Folded Reload
	str	x10, [sp, #1688]
	str	x9, [sp, #1696]
	str	x24, [sp, #1704]
	str	x25, [sp, #1712]
	str	x28, [sp, #1720]
	ldp	x9, x10, [sp, #232]             ; 16-byte Folded Reload
	str	x10, [sp, #1728]
	str	x9, [sp, #1736]
	str	x27, [sp, #1744]
	str	x26, [sp, #1752]
	ldp	x10, x9, [sp, #184]             ; 16-byte Folded Reload
	str	x10, [sp, #1760]
	str	x9, [sp, #1768]
	str	x23, [sp, #1776]
	str	x22, [sp, #1784]
	str	x21, [sp, #1792]
	str	x20, [sp, #1800]
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	str	x21, [sp, #1808]
	str	x22, [sp, #1816]
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	str	x23, [sp, #1824]
	str	x24, [sp, #1832]
	ldr	x25, [sp, #24]                  ; 8-byte Folded Reload
	str	x25, [sp, #1840]
	ldp	x27, x26, [sp, #216]            ; 16-byte Folded Reload
	str	x26, [sp, #1848]
	str	x27, [sp, #1856]
	ldp	x20, x28, [sp, #200]            ; 16-byte Folded Reload
	str	x28, [sp, #1864]
	str	x20, [sp, #1872]
	ldp	x9, x10, [sp, #152]             ; 16-byte Folded Reload
	str	x10, [sp, #1880]
	str	x9, [sp, #1888]
	str	x8, [sp, #1896]
	add	x0, sp, #1376
	add	x1, sp, #288
	add	x3, sp, #1648
	add	x4, sp, #304
	mov	w2, #3                          ; =0x3
	bl	_wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07
	add	x0, sp, #1376
	add	x1, sp, #256
	bl	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
	ldp	x8, x9, [sp, #128]              ; 16-byte Folded Reload
	str	x9, [sp, #1648]
	str	x8, [sp, #1656]
	ldp	x8, x9, [sp, #112]              ; 16-byte Folded Reload
	str	x9, [sp, #1664]
	str	x8, [sp, #1672]
	ldp	x8, x9, [sp, #96]               ; 16-byte Folded Reload
	str	x9, [sp, #1680]
	str	x8, [sp, #1688]
	ldp	x8, x9, [sp, #8]                ; 16-byte Folded Reload
	str	x9, [sp, #1696]
	str	x8, [sp, #1704]
	add	x9, x19, #33
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	str	x8, [sp, #1712]
	ldp	x8, x10, [sp, #232]             ; 16-byte Folded Reload
	str	x10, [sp, #1720]
	str	x8, [sp, #1728]
	ldp	x10, x8, [sp, #80]              ; 16-byte Folded Reload
	str	x10, [sp, #1736]
	str	x8, [sp, #1744]
	ldp	x10, x8, [sp, #184]             ; 16-byte Folded Reload
	str	x10, [sp, #1752]
	str	x8, [sp, #1760]
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	str	x8, [sp, #1768]
	ldp	x10, x8, [sp, #168]             ; 16-byte Folded Reload
	str	x10, [sp, #1776]
	str	x8, [sp, #1784]
	ldr	x8, [sp, #248]                  ; 8-byte Folded Reload
	str	x8, [sp, #1792]
	str	x21, [sp, #1800]
	str	x22, [sp, #1808]
	str	x23, [sp, #1816]
	str	x24, [sp, #1824]
	str	x25, [sp, #1832]
	str	x26, [sp, #1840]
	str	x27, [sp, #1848]
	str	x28, [sp, #1856]
	str	x20, [sp, #1864]
	ldp	x21, x20, [sp, #152]            ; 16-byte Folded Reload
	str	x20, [sp, #1872]
	str	x21, [sp, #1880]
	ldr	x23, [sp, #64]                  ; 8-byte Folded Reload
	str	x23, [sp, #1888]
	str	x9, [sp, #1896]
	mov	x22, x9
	add	x0, sp, #1376
	add	x1, sp, #288
	add	x3, sp, #1648
	add	x4, sp, #304
	mov	w2, #5                          ; =0x5
	bl	_wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07
	add	x0, sp, #1376
	add	x1, sp, #256
	bl	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	str	x8, [sp, #1120]
	ldp	x8, x9, [sp, #232]              ; 16-byte Folded Reload
	str	x9, [sp, #1128]
	str	x8, [sp, #1136]
	add	x9, x19, #34
	ldp	x11, x8, [sp, #80]              ; 16-byte Folded Reload
	str	x11, [sp, #1144]
	add	x10, x19, #35
	stp	x10, x9, [sp, #232]             ; 16-byte Folded Spill
	str	x8, [sp, #1152]
	add	x11, x19, #36
	ldr	x8, [sp, #184]                  ; 8-byte Folded Reload
	str	x8, [sp, #1160]
	add	x12, x19, #37
	ldr	x8, [sp, #192]                  ; 8-byte Folded Reload
	str	x8, [sp, #1168]
	add	x13, x19, #38
	stp	x12, x13, [sp, #184]            ; 16-byte Folded Spill
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	str	x8, [sp, #1176]
	add	x14, x19, #39
	stp	x11, x14, [sp, #136]            ; 16-byte Folded Spill
	ldr	x8, [sp, #168]                  ; 8-byte Folded Reload
	str	x8, [sp, #1184]
	add	x15, x19, #40
	ldr	x8, [sp, #176]                  ; 8-byte Folded Reload
	str	x8, [sp, #1192]
	add	x16, x19, #41
	stp	x15, x16, [sp, #168]            ; 16-byte Folded Spill
	ldr	x8, [sp, #248]                  ; 8-byte Folded Reload
	str	x8, [sp, #1200]
	ldp	x25, x24, [sp, #48]             ; 16-byte Folded Reload
	str	x24, [sp, #1208]
	str	x25, [sp, #1216]
	ldp	x27, x26, [sp, #32]             ; 16-byte Folded Reload
	str	x26, [sp, #1224]
	str	x27, [sp, #1232]
	ldr	x28, [sp, #24]                  ; 8-byte Folded Reload
	str	x28, [sp, #1240]
	ldr	x8, [sp, #224]                  ; 8-byte Folded Reload
	str	x8, [sp, #1248]
	ldr	x8, [sp, #216]                  ; 8-byte Folded Reload
	str	x8, [sp, #1256]
	ldr	x8, [sp, #208]                  ; 8-byte Folded Reload
	str	x8, [sp, #1264]
	ldr	x8, [sp, #200]                  ; 8-byte Folded Reload
	str	x8, [sp, #1272]
	str	x20, [sp, #1280]
	str	x21, [sp, #1288]
	str	x23, [sp, #1296]
	str	x22, [sp, #1304]
	str	x9, [sp, #1312]
	str	x10, [sp, #1320]
	str	x11, [sp, #1328]
	str	x12, [sp, #1336]
	str	x13, [sp, #1344]
	str	x14, [sp, #1352]
	str	x15, [sp, #1360]
	str	x16, [sp, #1368]
	add	x0, sp, #848
	add	x1, sp, #288
	add	x3, sp, #1120
	add	x4, sp, #304
	mov	w2, #1                          ; =0x1
	bl	_wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07
	add	x0, sp, #848
	add	x1, sp, #256
	bl	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
	dup.2d	v0, x19
Lloh32:
	adrp	x8, lCPI30_0@PAGE
Lloh33:
	ldr	q1, [x8, lCPI30_0@PAGEOFF]
	add.2d	v1, v0, v1
Lloh34:
	adrp	x8, lCPI30_1@PAGE
Lloh35:
	ldr	q2, [x8, lCPI30_1@PAGEOFF]
	add.2d	v2, v0, v2
Lloh36:
	adrp	x8, lCPI30_2@PAGE
Lloh37:
	ldr	q3, [x8, lCPI30_2@PAGEOFF]
	add.2d	v3, v0, v3
Lloh38:
	adrp	x8, lCPI30_3@PAGE
Lloh39:
	ldr	q4, [x8, lCPI30_3@PAGEOFF]
	add.2d	v4, v0, v4
Lloh40:
	adrp	x8, lCPI30_4@PAGE
Lloh41:
	ldr	q5, [x8, lCPI30_4@PAGEOFF]
	add.2d	v0, v0, v5
	ldr	x8, [sp, #248]                  ; 8-byte Folded Reload
	str	x8, [sp, #592]
	str	x24, [sp, #600]
	str	x25, [sp, #608]
	str	x26, [sp, #616]
	str	x27, [sp, #624]
	str	x28, [sp, #632]
	ldp	x8, x9, [sp, #216]              ; 16-byte Folded Reload
	str	x9, [sp, #640]
	str	x8, [sp, #648]
	ldp	x8, x9, [sp, #200]              ; 16-byte Folded Reload
	str	x9, [sp, #656]
	str	x8, [sp, #664]
	str	x20, [sp, #672]
	str	x21, [sp, #680]
	str	x23, [sp, #688]
	str	x22, [sp, #696]
	ldp	x8, x9, [sp, #232]              ; 16-byte Folded Reload
	str	x9, [sp, #704]
	str	x8, [sp, #712]
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	str	x8, [sp, #720]
	ldp	x9, x8, [sp, #184]              ; 16-byte Folded Reload
	str	x9, [sp, #728]
	str	x8, [sp, #736]
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	str	x8, [sp, #744]
	ldp	x9, x8, [sp, #168]              ; 16-byte Folded Reload
	str	x9, [sp, #752]
	str	x8, [sp, #760]
	stp	q1, q2, [sp, #768]
	stp	q3, q4, [sp, #800]
	str	q0, [sp, #832]
	add	x0, sp, #320
	add	x1, sp, #288
	add	x3, sp, #592
	add	x4, sp, #304
	mov	w2, #7                          ; =0x7
	bl	_wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07
	add	x0, sp, #320
	add	x1, sp, #256
	bl	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
	add	x0, sp, #288
	add	x1, sp, #256
	bl	_wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146
	ldp	x8, x9, [sp, #256]
	ldp	x10, x11, [sp, #272]
	eor	x8, x8, x8, lsr #30
	mov	x12, #58809                     ; =0xe5b9
	movk	x12, #7396, lsl #16
	movk	x12, #18285, lsl #32
	movk	x12, #48984, lsl #48
	mul	x8, x8, x12
	eor	x8, x8, x8, lsr #27
	mov	x13, #4587                      ; =0x11eb
	movk	x13, #4913, lsl #16
	movk	x13, #18875, lsl #32
	movk	x13, #38096, lsl #48
	mul	x8, x8, x13
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x12
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x13
	eor	x12, x9, x8
	mov	x13, #31765                     ; =0x7c15
	movk	x13, #32586, lsl #16
	movk	x13, #31161, lsl #32
	movk	x13, #40503, lsl #48
	mul	x11, x11, x13
	eor	x10, x10, x11
	eor	x10, x10, x12, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	add	sp, sp, #1904
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB30_2:                                ; %window.block.oom.v1.i.i.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpAdrp	Lloh38, Lloh40
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpAdrp	Lloh36, Lloh38
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpAdrp	Lloh34, Lloh36
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpAdrp	Lloh32, Lloh34
	.loh AdrpLdr	Lloh32, Lloh33
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_map_cost_library_trace$instance$4250cb78d3f44027
lCPI31_0:
	.quad	1                               ; 0x1
	.quad	2                               ; 0x2
lCPI31_1:
	.quad	3                               ; 0x3
	.quad	4                               ; 0x4
lCPI31_2:
	.quad	5                               ; 0x5
	.quad	6                               ; 0x6
lCPI31_3:
	.quad	7                               ; 0x7
	.quad	8                               ; 0x8
lCPI31_4:
	.quad	9                               ; 0x9
	.quad	10                              ; 0xa
lCPI31_5:
	.quad	11                              ; 0xb
	.quad	12                              ; 0xc
lCPI31_6:
	.quad	13                              ; 0xd
	.quad	14                              ; 0xe
lCPI31_7:
	.quad	15                              ; 0xf
	.quad	16                              ; 0x10
lCPI31_8:
	.quad	17                              ; 0x11
	.quad	18                              ; 0x12
lCPI31_9:
	.quad	19                              ; 0x13
	.quad	20                              ; 0x14
lCPI31_10:
	.quad	21                              ; 0x15
	.quad	22                              ; 0x16
lCPI31_11:
	.quad	23                              ; 0x17
	.quad	24                              ; 0x18
lCPI31_12:
	.quad	25                              ; 0x19
	.quad	26                              ; 0x1a
lCPI31_13:
	.quad	27                              ; 0x1b
	.quad	28                              ; 0x1c
lCPI31_14:
	.quad	29                              ; 0x1d
	.quad	30                              ; 0x1e
lCPI31_15:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI31_16:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI31_17:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI31_18:
	.quad	8                               ; 0x8
	.quad	9                               ; 0x9
lCPI31_19:
	.quad	10                              ; 0xa
	.quad	11                              ; 0xb
lCPI31_20:
	.quad	12                              ; 0xc
	.quad	13                              ; 0xd
lCPI31_21:
	.quad	14                              ; 0xe
	.quad	15                              ; 0xf
lCPI31_22:
	.quad	16                              ; 0x10
	.quad	17                              ; 0x11
lCPI31_23:
	.quad	18                              ; 0x12
	.quad	19                              ; 0x13
lCPI31_24:
	.quad	20                              ; 0x14
	.quad	21                              ; 0x15
lCPI31_25:
	.quad	22                              ; 0x16
	.quad	23                              ; 0x17
lCPI31_26:
	.quad	24                              ; 0x18
	.quad	25                              ; 0x19
lCPI31_27:
	.quad	26                              ; 0x1a
	.quad	27                              ; 0x1b
lCPI31_28:
	.quad	28                              ; 0x1c
	.quad	29                              ; 0x1d
lCPI31_29:
	.quad	30                              ; 0x1e
	.quad	31                              ; 0x1f
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_map_cost_library_trace$instance$4250cb78d3f44027
	.p2align	2
_wf_map_cost_library_trace$instance$4250cb78d3f44027: ; @"wf_map_cost_library_trace$instance$4250cb78d3f44027"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	mov	w9, #7952                       ; =0x1f10
Lloh42:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh43:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #3856
	.cfi_def_cfa_offset 8048
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x23, x4
	str	x2, [sp, #248]                  ; 8-byte Folded Spill
	mov	x20, x1
	mov	x21, x0
	add	x10, sp, #848
	mov	x8, #31765                      ; =0x7c15
	movk	x8, #32586, lsl #16
	movk	x8, #31161, lsl #32
	movk	x8, #40503, lsl #48
	str	x3, [sp, #160]                  ; 8-byte Folded Spill
	eor	x8, x3, x8
	cmp	x5, #0
	cset	w9, ne
	mov	w11, #5968                      ; =0x1750
	str	x8, [sp, #6808]
	add	x19, sp, #848
	strb	w9, [x10, x11]
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB31_182
; %bb.1:                                ; %bb1.i.i.i
	stp	xzr, x21, [x0]
	cbz	x21, LBB31_5
; %bb.2:                                ; %bb5.i.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
	movi.2d	v0, #0000000000000000
LBB31_3:                                ; %bb5.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	q0, q0, [x9]
	stp	q0, q0, [x9, #32]
	stp	q0, q0, [x9, #64]
	stp	q0, q0, [x9, #96]
	stp	q0, q0, [x9, #128]
	stp	q0, q0, [x9, #160]
	stp	q0, q0, [x9, #192]
	stp	q0, q0, [x9, #224]
	str	xzr, [x9, #256]
	add	x9, x9, #272
	cmp	x21, x8
	b.ne	LBB31_3
; %bb.4:                                ; %bb4.bb7_crit_edge.i.i.i
	str	x21, [x0]
LBB31_5:                                ; %"wf_std.collections.hash_map.hash_map_new$instance$0e108827ecbbe374.exit"
	add	x8, x19, #260
	str	x8, [sp, #600]                  ; 8-byte Folded Spill
	str	x0, [sp, #6824]
	str	xzr, [sp, #6832]
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	str	x8, [sp, #6840]
	str	xzr, [sp, #6848]
	str	xzr, [sp, #6864]
	str	xzr, [sp, #6856]
	str	x20, [sp, #216]                 ; 8-byte Folded Spill
	cbz	x20, LBB31_11
; %bb.6:                                ; %bb2.lr.ph
Lloh44:
	adrp	x8, lCPI31_0@PAGE
Lloh45:
	ldr	q0, [x8, lCPI31_0@PAGEOFF]
	str	q0, [sp, #832]                  ; 16-byte Folded Spill
	add	x19, x19, #792
Lloh46:
	adrp	x8, lCPI31_1@PAGE
Lloh47:
	ldr	q0, [x8, lCPI31_1@PAGEOFF]
	str	q0, [sp, #816]                  ; 16-byte Folded Spill
	add	x20, sp, #848
Lloh48:
	adrp	x8, lCPI31_2@PAGE
Lloh49:
	ldr	q0, [x8, lCPI31_2@PAGEOFF]
	str	q0, [sp, #800]                  ; 16-byte Folded Spill
Lloh50:
	adrp	x8, lCPI31_3@PAGE
Lloh51:
	ldr	q0, [x8, lCPI31_3@PAGEOFF]
	str	q0, [sp, #784]                  ; 16-byte Folded Spill
Lloh52:
	adrp	x8, lCPI31_4@PAGE
Lloh53:
	ldr	q0, [x8, lCPI31_4@PAGEOFF]
	str	q0, [sp, #768]                  ; 16-byte Folded Spill
Lloh54:
	adrp	x8, lCPI31_5@PAGE
Lloh55:
	ldr	q0, [x8, lCPI31_5@PAGEOFF]
	str	q0, [sp, #752]                  ; 16-byte Folded Spill
Lloh56:
	adrp	x8, lCPI31_6@PAGE
Lloh57:
	ldr	q0, [x8, lCPI31_6@PAGEOFF]
	str	q0, [sp, #736]                  ; 16-byte Folded Spill
Lloh58:
	adrp	x8, lCPI31_7@PAGE
Lloh59:
	ldr	q0, [x8, lCPI31_7@PAGEOFF]
	str	q0, [sp, #720]                  ; 16-byte Folded Spill
Lloh60:
	adrp	x8, lCPI31_8@PAGE
Lloh61:
	ldr	q0, [x8, lCPI31_8@PAGEOFF]
	str	q0, [sp, #704]                  ; 16-byte Folded Spill
Lloh62:
	adrp	x8, lCPI31_9@PAGE
Lloh63:
	ldr	q0, [x8, lCPI31_9@PAGEOFF]
	str	q0, [sp, #688]                  ; 16-byte Folded Spill
Lloh64:
	adrp	x8, lCPI31_10@PAGE
Lloh65:
	ldr	q0, [x8, lCPI31_10@PAGEOFF]
	str	q0, [sp, #672]                  ; 16-byte Folded Spill
Lloh66:
	adrp	x8, lCPI31_11@PAGE
Lloh67:
	ldr	q0, [x8, lCPI31_11@PAGEOFF]
	str	q0, [sp, #656]                  ; 16-byte Folded Spill
	mov	w25, #131                       ; =0x83
Lloh68:
	adrp	x8, lCPI31_12@PAGE
Lloh69:
	ldr	q0, [x8, lCPI31_12@PAGEOFF]
	str	q0, [sp, #640]                  ; 16-byte Folded Spill
	mov	w24, #1                         ; =0x1
Lloh70:
	adrp	x8, lCPI31_13@PAGE
Lloh71:
	ldr	q0, [x8, lCPI31_13@PAGEOFF]
	str	q0, [sp, #624]                  ; 16-byte Folded Spill
	ldr	x26, [sp, #216]                 ; 8-byte Folded Reload
Lloh72:
	adrp	x8, lCPI31_14@PAGE
Lloh73:
	ldr	q0, [x8, lCPI31_14@PAGEOFF]
	str	q0, [sp, #608]                  ; 16-byte Folded Spill
	ldr	x27, [sp, #160]                 ; 8-byte Folded Reload
	b	LBB31_8
LBB31_7:                                ; %bb6
                                        ;   in Loop: Header=BB31_8 Depth=1
	ldr	x8, [sp, #6840]
	mul	x8, x8, x25
	str	x8, [sp, #6840]
	add	x27, x27, #1
	add	x24, x24, #2
	subs	x26, x26, #1
	b.eq	LBB31_11
LBB31_8:                                ; %bb2
                                        ; =>This Inner Loop Header: Depth=1
	add	x8, x27, #31
	str	x27, [sp, #848]
	dup.2d	v0, x27
	ldr	q1, [sp, #832]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #601
	stur	q1, [x9, #255]
	ldr	q1, [sp, #816]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #617
	stur	q1, [x9, #255]
	ldr	q1, [sp, #800]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #633
	stur	q1, [x9, #255]
	ldr	q1, [sp, #784]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #649
	stur	q1, [x9, #255]
	ldr	q1, [sp, #768]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #665
	stur	q1, [x9, #255]
	ldr	q1, [sp, #752]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #681
	stur	q1, [x9, #255]
	ldr	q1, [sp, #736]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #697
	stur	q1, [x9, #255]
	ldr	q1, [sp, #720]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #713
	stur	q1, [x9, #255]
	ldr	q1, [sp, #704]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #848
	stur	q1, [x9, #136]
	ldr	q1, [sp, #688]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x9, #152]
	ldr	q1, [sp, #672]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x9, #168]
	ldr	q1, [sp, #656]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x9, #184]
	ldr	q1, [sp, #640]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x9, #200]
	ldr	q1, [sp, #624]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x9, #216]
	ldr	q1, [sp, #608]                  ; 16-byte Folded Reload
	add.2d	v0, v0, v1
	stur	q0, [x9, #232]
	str	x8, [sp, #1096]
	add	x0, x9, #256
	mov	w8, #5976                       ; =0x1758
	add	x1, x9, x8
	add	x3, sp, #848
	add	x22, sp, #848
	mov	w8, #5960                       ; =0x1748
	add	x4, x9, x8
	mov	x2, x24
	bl	_wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65
	ldr	w8, [sp, #1104]
	cbz	w8, LBB31_7
; %bb.9:                                ; %bb2
                                        ;   in Loop: Header=BB31_8 Depth=1
	cmp	w8, #1
	b.ne	LBB31_181
; %bb.10:                               ; %bb7
                                        ;   in Loop: Header=BB31_8 Depth=1
	ldr	x8, [sp, #600]                  ; 8-byte Folded Reload
	ldrb	w28, [x8]
	add	x0, x22, #528
	add	x1, x20, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	ldr	x8, [sp, #6840]
	cmp	w28, #0
	mov	w9, #1                          ; =0x1
	cinc	x9, x9, ne
	madd	x8, x8, x25, x9
	str	x8, [sp, #6840]
	ldr	x9, [sp, #1376]
	ldp	q1, q0, [x20, #368]
	stp	q1, q0, [x19, #96]
	ldp	q1, q0, [x20, #336]
	stp	q1, q0, [x19, #64]
	ldp	q1, q0, [x20, #432]
	stp	q1, q0, [x19, #160]
	ldp	q1, q0, [x20, #400]
	stp	q1, q0, [x19, #128]
	ldp	q1, q0, [x20, #496]
	stp	q1, q0, [x19, #224]
	ldp	q1, q0, [x20, #464]
	stp	q1, q0, [x19, #192]
	ldp	q1, q0, [x20, #304]
	stp	q1, q0, [x19, #32]
	ldp	q0, q1, [x20, #272]
	stp	q0, q1, [x19]
	ldr	x10, [sp, #1640]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1648]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1656]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1664]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1672]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1680]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1688]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1696]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1704]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1712]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1720]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1728]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1736]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1744]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1752]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1760]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1768]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1776]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1784]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1792]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1800]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1808]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1816]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1824]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1832]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1840]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1848]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1856]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1864]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1872]
	madd	x9, x9, x25, x10
	ldr	x10, [sp, #1880]
	add	x8, x8, x10
	madd	x8, x9, x25, x8
	ldr	x9, [sp, #1888]
	madd	x8, x8, x25, x9
	str	x8, [sp, #6840]
	add	x27, x27, #1
	add	x24, x24, #2
	subs	x26, x26, #1
	b.ne	LBB31_8
LBB31_11:                               ; %bb12.preheader
	mov	x5, #58809                      ; =0xe5b9
	movk	x5, #7396, lsl #16
	movk	x5, #18285, lsl #32
	movk	x5, #48984, lsl #48
	mov	x4, #4587                       ; =0x11eb
	movk	x4, #4913, lsl #16
	movk	x4, #18875, lsl #32
	movk	x4, #38096, lsl #48
	ldr	x8, [sp, #248]                  ; 8-byte Folded Reload
	ldr	x25, [sp, #216]                 ; 8-byte Folded Reload
	mov	w3, #5968                       ; =0x1750
	cbz	x8, LBB31_77
; %bb.12:                               ; %bb13.lr.ph
	lsl	x8, x21, #1
	cmp	x21, #0
	csinc	x21, x8, xzr, ne
	cmp	x23, #1
	csel	x8, x25, xzr, eq
	str	x8, [sp, #784]                  ; 8-byte Folded Spill
	add	x16, sp, #848
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #2800
	add	x10, x9, #800
	add	x8, x9, #536
	stp	x8, x10, [sp, #496]             ; 16-byte Folded Spill
	cmp	x23, #5
	b.ne	LBB31_78
; %bb.13:                               ; %bb13.us.preheader
	mov	x28, #0                         ; =0x0
	add	x8, sp, #848
	add	x24, x8, #1048
	add	x9, x8, #1584
	str	x9, [sp, #464]                  ; 8-byte Folded Spill
	add	x27, x8, #1896
	add	x23, x8, #2152
	add	x8, x8, #2688
	str	x8, [sp, #576]                  ; 8-byte Folded Spill
	ldr	x9, [sp, #600]                  ; 8-byte Folded Reload
	add	x8, x9, #804
	str	x8, [sp, #448]                  ; 8-byte Folded Spill
	add	x8, x9, #820
	str	x8, [sp, #432]                  ; 8-byte Folded Spill
	add	x8, x9, #836
	str	x8, [sp, #416]                  ; 8-byte Folded Spill
	add	x8, x9, #852
	str	x8, [sp, #400]                  ; 8-byte Folded Spill
	add	x8, x9, #868
	str	x8, [sp, #384]                  ; 8-byte Folded Spill
	add	x8, x9, #884
	str	x8, [sp, #368]                  ; 8-byte Folded Spill
	add	x8, x9, #900
	str	x8, [sp, #352]                  ; 8-byte Folded Spill
	add	x8, x9, #916
	str	x8, [sp, #336]                  ; 8-byte Folded Spill
	add	x8, x9, #932
	str	x8, [sp, #320]                  ; 8-byte Folded Spill
	add	x8, x9, #948
	str	x8, [sp, #304]                  ; 8-byte Folded Spill
	add	x8, x9, #964
	str	x8, [sp, #288]                  ; 8-byte Folded Spill
	add	x8, x9, #980
	str	x8, [sp, #272]                  ; 8-byte Folded Spill
	add	x8, x9, #996
	str	x8, [sp, #256]                  ; 8-byte Folded Spill
Lloh74:
	adrp	x8, lCPI31_0@PAGE
Lloh75:
	ldr	q0, [x8, lCPI31_0@PAGEOFF]
	str	q0, [sp, #832]                  ; 16-byte Folded Spill
	add	x8, x9, #1012
	str	x8, [sp, #240]                  ; 8-byte Folded Spill
Lloh76:
	adrp	x8, lCPI31_1@PAGE
Lloh77:
	ldr	q0, [x8, lCPI31_1@PAGEOFF]
	str	q0, [sp, #816]                  ; 16-byte Folded Spill
	add	x8, x9, #1028
	str	x8, [sp, #232]                  ; 8-byte Folded Spill
Lloh78:
	adrp	x8, lCPI31_2@PAGE
Lloh79:
	ldr	q0, [x8, lCPI31_2@PAGEOFF]
	str	q0, [sp, #800]                  ; 16-byte Folded Spill
	add	x8, x9, #1044
	str	x8, [sp, #224]                  ; 8-byte Folded Spill
Lloh80:
	adrp	x8, lCPI31_3@PAGE
Lloh81:
	ldr	q0, [x8, lCPI31_3@PAGEOFF]
	str	q0, [sp, #784]                  ; 16-byte Folded Spill
Lloh82:
	adrp	x8, lCPI31_4@PAGE
Lloh83:
	ldr	q0, [x8, lCPI31_4@PAGEOFF]
	str	q0, [sp, #768]                  ; 16-byte Folded Spill
	sub	x8, x25, x25, lsr #1
Lloh84:
	adrp	x9, lCPI31_5@PAGE
Lloh85:
	ldr	q0, [x9, lCPI31_5@PAGEOFF]
	str	q0, [sp, #752]                  ; 16-byte Folded Spill
	cmp	x8, #1
Lloh86:
	adrp	x9, lCPI31_6@PAGE
Lloh87:
	ldr	q0, [x9, lCPI31_6@PAGEOFF]
	str	q0, [sp, #736]                  ; 16-byte Folded Spill
	csinc	x6, x8, xzr, hi
Lloh88:
	adrp	x8, lCPI31_7@PAGE
Lloh89:
	ldr	q0, [x8, lCPI31_7@PAGEOFF]
	str	q0, [sp, #720]                  ; 16-byte Folded Spill
	add	x8, x16, #2168
	str	x8, [sp, #560]                  ; 8-byte Folded Spill
Lloh90:
	adrp	x8, lCPI31_8@PAGE
Lloh91:
	ldr	q0, [x8, lCPI31_8@PAGEOFF]
	str	q0, [sp, #704]                  ; 16-byte Folded Spill
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	add	x19, x8, x25
Lloh92:
	adrp	x8, lCPI31_9@PAGE
Lloh93:
	ldr	q0, [x8, lCPI31_9@PAGEOFF]
	str	q0, [sp, #688]                  ; 16-byte Folded Spill
	mov	w21, #131                       ; =0x83
Lloh94:
	adrp	x8, lCPI31_10@PAGE
Lloh95:
	ldr	q0, [x8, lCPI31_10@PAGEOFF]
	str	q0, [sp, #672]                  ; 16-byte Folded Spill
Lloh96:
	adrp	x8, lCPI31_11@PAGE
Lloh97:
	ldr	q0, [x8, lCPI31_11@PAGEOFF]
	str	q0, [sp, #656]                  ; 16-byte Folded Spill
	mov	w7, #1                          ; =0x1
Lloh98:
	adrp	x8, lCPI31_12@PAGE
Lloh99:
	ldr	q0, [x8, lCPI31_12@PAGEOFF]
	str	q0, [sp, #640]                  ; 16-byte Folded Spill
Lloh100:
	adrp	x8, lCPI31_13@PAGE
Lloh101:
	ldr	q0, [x8, lCPI31_13@PAGEOFF]
	str	q0, [sp, #624]                  ; 16-byte Folded Spill
Lloh102:
	adrp	x8, lCPI31_14@PAGE
Lloh103:
	ldr	q0, [x8, lCPI31_14@PAGEOFF]
	str	q0, [sp, #608]                  ; 16-byte Folded Spill
	mov	w26, #272                       ; =0x110
	mov	w20, #17161                     ; =0x4309
	str	x6, [sp, #544]                  ; 8-byte Folded Spill
	b	LBB31_15
LBB31_14:                               ;   in Loop: Header=BB31_15 Depth=1
	ldr	x25, [sp, #216]                 ; 8-byte Folded Reload
	mov	w3, #5968                       ; =0x1750
	mov	x4, #4587                       ; =0x11eb
	movk	x4, #4913, lsl #16
	movk	x4, #18875, lsl #32
	movk	x4, #38096, lsl #48
	mov	x5, #58809                      ; =0xe5b9
	movk	x5, #7396, lsl #16
	movk	x5, #18285, lsl #32
	movk	x5, #48984, lsl #48
	ldr	x28, [sp, #512]                 ; 8-byte Folded Reload
	ldr	x6, [sp, #544]                  ; 8-byte Folded Reload
	ldr	x19, [sp, #480]                 ; 8-byte Folded Reload
	mov	w20, #17161                     ; =0x4309
	add	x19, x19, x25
	ldr	x8, [sp, #248]                  ; 8-byte Folded Reload
	cmp	x28, x8
	b.eq	LBB31_77
LBB31_15:                               ; %bb13.us
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB31_19 Depth 2
                                        ;       Child Loop BB31_25 Depth 3
                                        ;       Child Loop BB31_35 Depth 3
                                        ;     Child Loop BB31_48 Depth 2
                                        ;       Child Loop BB31_53 Depth 3
                                        ;     Child Loop BB31_60 Depth 2
	ldr	x22, [sp, #6824]
	str	x19, [sp, #480]                 ; 8-byte Folded Spill
	cbz	x25, LBB31_40
; %bb.16:                               ; %bb20.lr.ph.us
                                        ;   in Loop: Header=BB31_15 Depth=1
	str	x28, [sp, #512]                 ; 8-byte Folded Spill
	mov	x19, #0                         ; =0x0
	ldr	x0, [sp, #6808]
	add	x8, sp, #848
	ldrb	w28, [x8, x3]
	ldr	x25, [sp, #6832]
	str	x0, [sp, #528]                  ; 8-byte Folded Spill
	b	LBB31_19
LBB31_17:                               ; %bb2.i.i.us
                                        ;   in Loop: Header=BB31_19 Depth=2
	cbnz	w17, LBB31_181
LBB31_18:                               ; %bb3.i71.us
                                        ;   in Loop: Header=BB31_19 Depth=2
	str	w7, [sp, #2688]
	str	xzr, [sp, #2696]
	mul	x8, x8, x21
	strb	wzr, [sp, #2704]
	str	x8, [sp, #6840]
	add	x19, x19, #1
	cmp	x19, x6
	b.eq	LBB31_39
LBB31_19:                               ; %bb20.us
                                        ;   Parent Loop BB31_15 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB31_25 Depth 3
                                        ;       Child Loop BB31_35 Depth 3
	orr	x8, x7, x19, lsl #2
	str	x8, [sp, #6872]
	cbz	x25, LBB31_31
; %bb.20:                               ; %bb3.i.us
                                        ;   in Loop: Header=BB31_19 Depth=2
	tbz	w28, #0, LBB31_22
; %bb.21:                               ;   in Loop: Header=BB31_19 Depth=2
	mov	x9, #0                          ; =0x0
	ldr	x10, [x22]
	cbnz	x10, LBB31_23
	b	LBB31_31
LBB31_22:                               ; %bb3.i.i.i.i.us
                                        ;   in Loop: Header=BB31_19 Depth=2
	eor	x9, x0, x8
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x5
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x4
	eor	x9, x9, x9, lsr #31
	ldr	x10, [x22]
	cbz	x10, LBB31_31
LBB31_23:                               ; %bb2.lr.ph.i.i.i.us
                                        ;   in Loop: Header=BB31_19 Depth=2
	mov	x11, #0                         ; =0x0
	udiv	x12, x9, x10
	msub	x12, x12, x10, x9
	sub	x13, x10, x12
	neg	x14, x13
	b	LBB31_25
LBB31_24:                               ; %bb10.i.i.i.us
                                        ;   in Loop: Header=BB31_25 Depth=3
	add	x11, x11, #1
	cmp	x10, x11
	b.eq	LBB31_31
LBB31_25:                               ; %bb2.i.i.i.us
                                        ;   Parent Loop BB31_15 Depth=1
                                        ;     Parent Loop BB31_19 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x11, x13
	csel	x9, x12, x14, lo
	add	x9, x9, x11
	madd	x9, x9, x26, x22
	ldr	w15, [x9, #16]!
	cmp	w15, #1
	b.eq	LBB31_24
; %bb.26:                               ; %bb2.i.i.i.us
                                        ;   in Loop: Header=BB31_25 Depth=3
	cmp	w15, #2
	b.ne	LBB31_30
; %bb.27:                               ; %bb3.i3.i.i.i.us
                                        ;   in Loop: Header=BB31_25 Depth=3
	ldr	x15, [x9, #8]
	cmp	x15, x8
	b.ne	LBB31_24
; %bb.28:                               ; %bb24.us
                                        ;   in Loop: Header=BB31_19 Depth=2
	str	w7, [x9]
	sub	x25, x25, #1
	ldp	q0, q1, [x9, #16]
	ldp	q2, q3, [x9, #48]
	ldp	q4, q5, [x9, #80]
	ldp	q6, q7, [x9, #112]
	ldp	q16, q17, [x9, #144]
	ldp	q18, q19, [x9, #176]
	ldp	q20, q21, [x9, #208]
	ldp	q22, q23, [x9, #240]
	movi.2d	v24, #0000000000000000
	stur	q24, [x9, #24]
	stur	q24, [x9, #40]
	stur	q24, [x9, #56]
	stur	q24, [x9, #72]
	stur	q24, [x9, #88]
	stur	q24, [x9, #104]
	stur	q24, [x9, #120]
	stur	q24, [x9, #136]
	stur	q24, [x9, #152]
	stur	q24, [x9, #168]
	stur	q24, [x9, #184]
	stur	q24, [x9, #200]
	stur	q24, [x9, #216]
	stur	q24, [x9, #232]
	stur	q24, [x9, #248]
	stur	q24, [x9, #8]
	str	xzr, [x9, #264]
	str	x25, [sp, #6832]
	str	x7, [sp, #1896]
	str	x8, [sp, #1904]
	ldr	x20, [sp, #448]                 ; 8-byte Folded Reload
	str	q0, [x20]
	ldr	x8, [sp, #432]                  ; 8-byte Folded Reload
	str	q1, [x8]
	ldr	x8, [sp, #416]                  ; 8-byte Folded Reload
	str	q2, [x8]
	ldr	x8, [sp, #400]                  ; 8-byte Folded Reload
	str	q3, [x8]
	ldr	x8, [sp, #384]                  ; 8-byte Folded Reload
	str	q4, [x8]
	ldr	x8, [sp, #368]                  ; 8-byte Folded Reload
	str	q5, [x8]
	ldr	x8, [sp, #352]                  ; 8-byte Folded Reload
	str	q6, [x8]
	ldr	x8, [sp, #336]                  ; 8-byte Folded Reload
	str	q7, [x8]
	ldr	x8, [sp, #320]                  ; 8-byte Folded Reload
	str	q16, [x8]
	ldr	x8, [sp, #304]                  ; 8-byte Folded Reload
	str	q17, [x8]
	ldr	x8, [sp, #288]                  ; 8-byte Folded Reload
	str	q18, [x8]
	ldr	x8, [sp, #272]                  ; 8-byte Folded Reload
	str	q19, [x8]
	ldr	x8, [sp, #256]                  ; 8-byte Folded Reload
	str	q20, [x8]
	ldp	x8, x9, [sp, #232]              ; 16-byte Folded Reload
	str	q21, [x9]
	str	q22, [x8]
	ldr	x8, [sp, #224]                  ; 8-byte Folded Reload
	str	q23, [x8]
	add	x8, sp, #848
	add	x0, x8, #1320
	add	x1, x8, #1056
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	ldr	x0, [sp, #528]                  ; 8-byte Folded Reload
	mov	w7, #1                          ; =0x1
	ldr	x6, [sp, #544]                  ; 8-byte Folded Reload
	mov	x5, #58809                      ; =0xe5b9
	movk	x5, #7396, lsl #16
	movk	x5, #18285, lsl #32
	movk	x5, #48984, lsl #48
	mov	x4, #4587                       ; =0x11eb
	movk	x4, #4913, lsl #16
	movk	x4, #18875, lsl #32
	movk	x4, #38096, lsl #48
	mov	w3, #5968                       ; =0x1750
	ldr	x8, [sp, #6840]
	ldr	x9, [sp, #2168]
	ldp	q1, q0, [x20, #32]
	ldr	x10, [sp, #464]                 ; 8-byte Folded Reload
	stp	q1, q0, [x10, #32]
	ldp	q1, q0, [x20, #96]
	stp	q1, q0, [x10, #96]
	ldp	q1, q0, [x20, #64]
	stp	q1, q0, [x10, #64]
	ldp	q1, q0, [x20, #160]
	stp	q1, q0, [x10, #160]
	ldp	q1, q0, [x20, #128]
	stp	q1, q0, [x10, #128]
	ldp	q1, q0, [x20, #224]
	stp	q1, q0, [x10, #224]
	ldp	q1, q0, [x20, #192]
	stp	q1, q0, [x10, #192]
	ldp	q1, q0, [x20]
	mov	w20, #17161                     ; =0x4309
	stp	q1, q0, [x10]
	ldr	x10, [sp, #2672]
	madd	x8, x8, x21, x10
	ldr	x10, [sp, #2432]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2440]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2448]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2456]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2464]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2472]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2480]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2488]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2496]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2504]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2512]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2520]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2528]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2536]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2544]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2552]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2560]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2568]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2576]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2584]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2592]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2600]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2608]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2616]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2624]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2632]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2640]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2648]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2656]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #2664]
	madd	x9, x9, x21, x10
	madd	x8, x9, x21, x8
	ldr	x9, [sp, #2680]
	madd	x8, x8, x21, x9
	add	x8, x8, #131
	str	x8, [sp, #6840]
	add	x9, sp, #848
	ldrb	w9, [x9, x3]
	tbnz	w9, #0, LBB31_32
LBB31_29:                               ; %bb3.i.i.i.us
                                        ;   in Loop: Header=BB31_19 Depth=2
	ldr	x9, [sp, #6808]
	ldr	x10, [sp, #6872]
	eor	x9, x10, x9
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x5
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x4
	eor	x12, x9, x9, lsr #31
	ldr	x9, [sp, #6824]
	ldr	x10, [x9]
	cbnz	x10, LBB31_33
	b	LBB31_18
LBB31_30:                               ; %bb2.i.i.i.us
                                        ;   in Loop: Header=BB31_19 Depth=2
	cbnz	w15, LBB31_181
LBB31_31:                               ; %bb25.us
                                        ;   in Loop: Header=BB31_19 Depth=2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x24, #240]
	stp	q0, q0, [x24, #208]
	stp	q0, q0, [x24, #176]
	stp	q0, q0, [x24, #144]
	stp	q0, q0, [x24, #112]
	stp	q0, q0, [x24, #80]
	stp	q0, q0, [x24, #48]
	stp	q0, q0, [x24, #16]
	ldr	x8, [sp, #6840]
	mul	x8, x8, x21
	str	q0, [x24]
	str	x8, [sp, #6840]
	add	x9, sp, #848
	ldrb	w9, [x9, x3]
	tbz	w9, #0, LBB31_29
LBB31_32:                               ;   in Loop: Header=BB31_19 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	x9, [sp, #6824]
	ldr	x10, [x9]
	cbz	x10, LBB31_18
LBB31_33:                               ; %bb2.lr.ph.i.i.us
                                        ;   in Loop: Header=BB31_19 Depth=2
	mov	x11, #0                         ; =0x0
	udiv	x13, x12, x10
	msub	x12, x13, x10, x12
	sub	x13, x10, x12
	neg	x14, x13
	ldr	x15, [sp, #6872]
	b	LBB31_35
LBB31_34:                               ; %bb12.i.i.us
                                        ;   in Loop: Header=BB31_35 Depth=3
	add	x11, x11, #1
	cmp	x10, x11
	b.eq	LBB31_18
LBB31_35:                               ; %bb2.i.i.us
                                        ;   Parent Loop BB31_15 Depth=1
                                        ;     Parent Loop BB31_19 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x11, x13
	csel	x16, x12, x14, lo
	add	x16, x16, x11
	madd	x16, x16, x26, x9
	ldr	w17, [x16, #16]!
	cmp	w17, #1
	b.eq	LBB31_34
; %bb.36:                               ; %bb2.i.i.us
                                        ;   in Loop: Header=BB31_35 Depth=3
	cmp	w17, #2
	b.ne	LBB31_17
; %bb.37:                               ; %bb6.i.i.us
                                        ;   in Loop: Header=BB31_35 Depth=3
	ldr	x17, [x16, #8]
	cmp	x17, x15
	b.ne	LBB31_34
; %bb.38:                               ; %bb2.i73.us
                                        ;   in Loop: Header=BB31_19 Depth=2
	ldr	x10, [x16, #16]
	str	wzr, [sp, #2688]
	str	x10, [sp, #2696]
	strb	wzr, [sp, #2704]
	madd	x8, x8, x20, x10
	add	x8, x8, #131
	str	x8, [sp, #6840]
	add	x19, x19, #1
	cmp	x19, x6
	b.ne	LBB31_19
LBB31_39:                               ;   in Loop: Header=BB31_15 Depth=1
	mov	x22, x9
	ldr	x25, [sp, #216]                 ; 8-byte Folded Reload
	ldr	x28, [sp, #512]                 ; 8-byte Folded Reload
	ldr	x19, [sp, #480]                 ; 8-byte Folded Reload
LBB31_40:                               ; %bb22.us
                                        ;   in Loop: Header=BB31_15 Depth=1
	ldr	x1, [x22]
	add	x8, sp, #848
	mov	w9, #5976                       ; =0x1758
	add	x0, x8, x9
	mov	w9, #5960                       ; =0x1748
	add	x2, x8, x9
	bl	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	str	w0, [sp, #2712]
	strb	w1, [sp, #2716]
	strb	w2, [sp, #2717]
	cbz	w0, LBB31_43
; %bb.41:                               ; %bb22.us
                                        ;   in Loop: Header=BB31_15 Depth=1
	cmp	w0, #1
	b.ne	LBB31_181
; %bb.42:                               ; %bb3.i58.us
                                        ;   in Loop: Header=BB31_15 Depth=1
	ldr	x8, [sp, #6840]
	mul	x8, x8, x21
	b	LBB31_44
LBB31_43:                               ; %bb2.i59.us
                                        ;   in Loop: Header=BB31_15 Depth=1
	ldr	x8, [sp, #6840]
	mov	x9, #1                          ; =0x1
	madd	x8, x8, x21, x9
LBB31_44:                               ; %wf_map_cost_rebuild_result.exit.us
                                        ;   in Loop: Header=BB31_15 Depth=1
	mov	w3, #5968                       ; =0x1750
	mov	x4, #4587                       ; =0x11eb
	movk	x4, #4913, lsl #16
	movk	x4, #18875, lsl #32
	movk	x4, #38096, lsl #48
	mov	x5, #58809                      ; =0xe5b9
	movk	x5, #7396, lsl #16
	movk	x5, #18285, lsl #32
	movk	x5, #48984, lsl #48
	ldr	x6, [sp, #544]                  ; 8-byte Folded Reload
	mov	w7, #1                          ; =0x1
	str	x8, [sp, #6840]
	cbz	x25, LBB31_76
; %bb.45:                               ; %bb28.lr.ph.us
                                        ;   in Loop: Header=BB31_15 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	x10, [sp, #6808]
	add	x11, sp, #848
	ldrb	w11, [x11, x3]
	ldr	x12, [sp, #6824]
	b	LBB31_48
LBB31_46:                               ; %bb2.i.i236.us
                                        ;   in Loop: Header=BB31_48 Depth=2
	cbnz	w2, LBB31_181
LBB31_47:                               ; %bb3.i263.us
                                        ;   in Loop: Header=BB31_48 Depth=2
	str	w7, [sp, #2720]
	str	xzr, [sp, #2728]
	mul	x8, x8, x21
	strb	wzr, [sp, #2736]
	str	x8, [sp, #6840]
	add	x9, x9, #1
	cmp	x9, x25
	b.eq	LBB31_57
LBB31_48:                               ; %bb28.us
                                        ;   Parent Loop BB31_15 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB31_53 Depth 3
	orr	x13, x7, x9, lsl #1
	str	x13, [sp, #6880]
	tbz	w11, #0, LBB31_50
; %bb.49:                               ;   in Loop: Header=BB31_48 Depth=2
	mov	x16, #0                         ; =0x0
	ldr	x14, [x12]
	cbnz	x14, LBB31_51
	b	LBB31_47
LBB31_50:                               ; %bb3.i.i.i217.us
                                        ;   in Loop: Header=BB31_48 Depth=2
	eor	x14, x10, x13
	eor	x14, x14, x14, lsr #30
	mul	x14, x14, x5
	eor	x14, x14, x14, lsr #27
	mul	x14, x14, x4
	eor	x16, x14, x14, lsr #31
	ldr	x14, [x12]
	cbz	x14, LBB31_47
LBB31_51:                               ; %bb2.lr.ph.i.i233.us
                                        ;   in Loop: Header=BB31_48 Depth=2
	mov	x15, #0                         ; =0x0
	udiv	x17, x16, x14
	msub	x16, x17, x14, x16
	sub	x17, x14, x16
	neg	x0, x17
	b	LBB31_53
LBB31_52:                               ; %bb12.i.i244.us
                                        ;   in Loop: Header=BB31_53 Depth=3
	add	x15, x15, #1
	cmp	x14, x15
	b.eq	LBB31_47
LBB31_53:                               ; %bb2.i.i236.us
                                        ;   Parent Loop BB31_15 Depth=1
                                        ;     Parent Loop BB31_48 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x15, x17
	csel	x1, x16, x0, lo
	add	x1, x1, x15
	madd	x1, x1, x26, x12
	ldr	w2, [x1, #16]!
	cmp	w2, #1
	b.eq	LBB31_52
; %bb.54:                               ; %bb2.i.i236.us
                                        ;   in Loop: Header=BB31_53 Depth=3
	cmp	w2, #2
	b.ne	LBB31_46
; %bb.55:                               ; %bb6.i.i252.us
                                        ;   in Loop: Header=BB31_53 Depth=3
	ldr	x2, [x1, #8]
	cmp	x2, x13
	b.ne	LBB31_52
; %bb.56:                               ; %bb2.i267.us
                                        ;   in Loop: Header=BB31_48 Depth=2
	ldr	x13, [x1, #16]
	str	wzr, [sp, #2720]
	str	x13, [sp, #2728]
	strb	wzr, [sp, #2736]
	madd	x8, x8, x20, x13
	add	x8, x8, #131
	str	x8, [sp, #6840]
	add	x9, x9, #1
	cmp	x9, x25
	b.ne	LBB31_48
LBB31_57:                               ; %bb33.lr.ph.us
                                        ;   in Loop: Header=BB31_15 Depth=1
	add	x28, x28, #1
	str	x28, [sp, #512]                 ; 8-byte Folded Spill
	mov	w22, #1                         ; =0x1
	mov	x25, x6
	b	LBB31_60
LBB31_58:                               ; %"wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65.exit.thread1481.us"
                                        ;   in Loop: Header=BB31_60 Depth=2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x23, #240]
	stp	q0, q0, [x23, #208]
	stp	q0, q0, [x23, #176]
	stp	q0, q0, [x23, #144]
	stp	q0, q0, [x23, #112]
	stp	q0, q0, [x23, #80]
	stp	q0, q0, [x23, #48]
	stp	q0, q0, [x23, #16]
	str	q0, [x23]
LBB31_59:                               ; %bb37.us
                                        ;   in Loop: Header=BB31_60 Depth=2
	ldr	x8, [sp, #6840]
	mul	x8, x8, x21
	mov	w7, #1                          ; =0x1
	str	x8, [sp, #6840]
	add	x22, x22, #4
	add	x19, x19, #2
	subs	x25, x25, #1
	b.eq	LBB31_14
LBB31_60:                               ; %bb33.us
                                        ;   Parent Loop BB31_15 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov	w20, #1                         ; =0x1
	add	x8, x19, #31
	str	x19, [sp, #2744]
	dup.2d	v0, x19
	ldr	q1, [sp, #832]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2752]
	ldr	q1, [sp, #816]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2768]
	ldr	q1, [sp, #800]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2784]
	ldr	q1, [sp, #784]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2800]
	ldr	q1, [sp, #768]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2816]
	ldr	q1, [sp, #752]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2832]
	ldr	q1, [sp, #736]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2848]
	ldr	q1, [sp, #720]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2864]
	ldr	q1, [sp, #704]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2880]
	ldr	q1, [sp, #688]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2896]
	ldr	q1, [sp, #672]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2912]
	ldr	q1, [sp, #656]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2928]
	ldr	q1, [sp, #640]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2944]
	ldr	q1, [sp, #624]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2960]
	ldr	q1, [sp, #608]                  ; 16-byte Folded Reload
	add.2d	v0, v0, v1
	str	q0, [sp, #2976]
	str	x8, [sp, #2992]
	ldp	q0, q1, [x27, #192]
	str	q0, [sp, #7088]
	str	q1, [sp, #7104]
	ldp	q0, q1, [x27, #224]
	str	q0, [sp, #7120]
	str	q1, [sp, #7136]
	ldp	q0, q1, [x27, #128]
	str	q0, [sp, #7024]
	str	q1, [sp, #7040]
	ldp	q0, q1, [x27, #160]
	str	q0, [sp, #7056]
	str	q1, [sp, #7072]
	ldp	q0, q1, [x27, #64]
	str	q0, [sp, #6960]
	str	q1, [sp, #6976]
	ldp	q0, q1, [x27, #96]
	str	q0, [sp, #6992]
	str	q1, [sp, #7008]
	ldp	q0, q1, [x27]
	str	q0, [sp, #6896]
	str	q1, [sp, #6912]
	ldp	q0, q1, [x27, #32]
	str	q0, [sp, #6928]
	str	q1, [sp, #6944]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2800
	add	x0, x8, #256
	add	x8, sp, #848
	mov	w9, #5976                       ; =0x1758
	add	x1, x8, x9
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #2800
	mov	w9, #5960                       ; =0x1748
	add	x4, x8, x9
	mov	x2, x22
	bl	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
	ldr	w8, [sp, #7152]
	cbz	w8, LBB31_58
; %bb.61:                               ; %bb33.us
                                        ;   in Loop: Header=BB31_60 Depth=2
	cmp	w8, #1
	b.ne	LBB31_181
; %bb.62:                               ; %bb2.i339.us
                                        ;   in Loop: Header=BB31_60 Depth=2
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2800
	ldrb	w28, [x8, #260]
	add	x0, x8, #528
	add	x1, x8, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	tbz	w28, #0, LBB31_66
; %bb.63:                               ; %bb4.i.us
                                        ;   in Loop: Header=BB31_60 Depth=2
	ldr	x8, [sp, #6824]
	ldr	x8, [x8]
	lsr	x9, x8, #14
	mov	w10, #1                         ; =0x1
	cbz	x9, LBB31_69
; %bb.64:                               ; %bb6.i342.us
                                        ;   in Loop: Header=BB31_60 Depth=2
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #2800
LBB31_65:                               ; %"wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65.exit.thread.us"
                                        ;   in Loop: Header=BB31_60 Depth=2
	str	x10, [sp, #3000]
	ldr	x8, [sp, #600]                  ; 8-byte Folded Reload
	strb	w10, [x8, #1896]
	b	LBB31_67
LBB31_66:                               ; %bb3.i340.us
                                        ;   in Loop: Header=BB31_60 Depth=2
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #2800
	str	x20, [sp, #3000]
LBB31_67:                               ; %"wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65.exit.thread.us"
                                        ;   in Loop: Header=BB31_60 Depth=2
	add	x20, sp, #848
	add	x0, x20, #2160
	add	x1, x9, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
LBB31_68:                               ; %bb38.us
                                        ;   in Loop: Header=BB31_60 Depth=2
	ldr	x8, [sp, #600]                  ; 8-byte Folded Reload
	ldrb	w28, [x8, #1896]
	add	x8, sp, #848
	add	x0, x8, #2424
	add	x1, x20, #2160
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	ldr	x8, [sp, #6840]
	cmp	w28, #0
	mov	w7, #1                          ; =0x1
	cinc	x9, x7, ne
	madd	x8, x8, x21, x9
	ldr	x9, [sp, #3272]
	ldr	x11, [sp, #560]                 ; 8-byte Folded Reload
	ldp	q1, q0, [x11, #96]
	ldr	x10, [sp, #576]                 ; 8-byte Folded Reload
	stp	q1, q0, [x10, #96]
	ldp	q1, q0, [x11, #64]
	stp	q1, q0, [x10, #64]
	ldp	q1, q0, [x11, #160]
	stp	q1, q0, [x10, #160]
	ldp	q1, q0, [x11, #128]
	stp	q1, q0, [x10, #128]
	ldp	q1, q0, [x11, #224]
	stp	q1, q0, [x10, #224]
	ldp	q1, q0, [x11, #192]
	stp	q1, q0, [x10, #192]
	ldp	q1, q0, [x11, #32]
	stp	q1, q0, [x10, #32]
	ldp	q0, q1, [x11]
	stp	q0, q1, [x10]
	ldr	x10, [sp, #3536]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3544]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3552]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3560]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3568]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3576]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3584]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3592]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3600]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3608]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3616]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3624]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3632]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3640]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3648]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3656]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3664]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3672]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3680]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3688]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3696]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3704]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3712]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3720]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3728]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3736]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3744]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3752]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3760]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3768]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3776]
	add	x8, x8, x10
	madd	x8, x9, x21, x8
	ldr	x9, [sp, #3784]
	madd	x8, x8, x21, x9
	str	x8, [sp, #6840]
	add	x22, x22, #4
	add	x19, x19, #2
	subs	x25, x25, #1
	b.ne	LBB31_60
	b	LBB31_14
LBB31_69:                               ; %bb7.i.us
                                        ;   in Loop: Header=BB31_60 Depth=2
	cmp	x8, #2, lsl #12                 ; =8192
	mov	w9, #8192                       ; =0x2000
	csel	x9, x8, x9, lo
	lsl	x9, x9, #1
	cmp	x8, #0
	csinc	x1, x9, xzr, ne
	cmp	x1, x8
	b.ls	LBB31_73
; %bb.70:                               ; %"wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.i.us"
                                        ;   in Loop: Header=BB31_60 Depth=2
	add	x8, sp, #848
	mov	w9, #5976                       ; =0x1758
	add	x0, x8, x9
	mov	w9, #5960                       ; =0x1748
	add	x2, x8, x9
	bl	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	str	w0, [sp, #7688]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2800
	strb	w1, [x8, #796]
	strb	w2, [x8, #797]
	cbz	w0, LBB31_74
; %bb.71:                               ; %"wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.i.us"
                                        ;   in Loop: Header=BB31_60 Depth=2
	cmp	w0, #1
	b.ne	LBB31_181
; %bb.72:                               ; %bb18.i.us
                                        ;   in Loop: Header=BB31_60 Depth=2
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #2800
	mov	w10, #1                         ; =0x1
	b	LBB31_65
LBB31_73:                               ; %"wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.thread.i.us"
                                        ;   in Loop: Header=BB31_60 Depth=2
	str	wzr, [sp, #7688]
	strh	wzr, [sp, #7692]
LBB31_74:                               ; %"wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65.exit.us"
                                        ;   in Loop: Header=BB31_60 Depth=2
	ldr	x2, [sp, #7424]
	ldp	x8, x3, [sp, #496]              ; 16-byte Folded Reload
	ldp	q0, q1, [x8, #192]
	stp	q0, q1, [x3, #192]
	ldp	q0, q1, [x8, #224]
	stp	q0, q1, [x3, #224]
	ldp	q0, q1, [x8, #128]
	stp	q0, q1, [x3, #128]
	ldp	q0, q1, [x8, #160]
	stp	q0, q1, [x3, #160]
	ldp	q0, q1, [x8, #64]
	stp	q0, q1, [x3, #64]
	ldp	q0, q1, [x8, #96]
	stp	q0, q1, [x3, #96]
	ldp	q0, q1, [x8]
	stp	q0, q1, [x3]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x3, #32]
	add	x8, sp, #848
	mov	w9, #5976                       ; =0x1758
	add	x1, x8, x9
	mov	w9, #5960                       ; =0x1748
	add	x4, x8, x9
	mov	x0, x23
	bl	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
	ldr	w8, [sp, #3000]
	cbz	w8, LBB31_59
; %bb.75:                               ; %"wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65.exit.us"
                                        ;   in Loop: Header=BB31_60 Depth=2
	cmp	w8, #1
	add	x20, sp, #848
	b.eq	LBB31_68
	b	LBB31_181
LBB31_76:                               ; %bb32.preheader.us.bb93.loopexit.us_crit_edge
                                        ;   in Loop: Header=BB31_15 Depth=1
	add	x28, x28, #1
	add	x19, x19, x25
	ldr	x8, [sp, #248]                  ; 8-byte Folded Reload
	cmp	x28, x8
	b.ne	LBB31_15
LBB31_77:                               ; %bb15
	mov	w8, #5992                       ; =0x1768
	add	x10, sp, #848
	add	x19, x10, x8
	mov	w8, #5928                       ; =0x1728
	add	x9, sp, #848
	add	x20, x9, x8
	mov	w8, #5912                       ; =0x1718
	mov	w11, #5976                      ; =0x1758
	ldr	q0, [x10, x11]
	str	q0, [x9, x8]
	add	x0, x9, x8
	mov	x1, x19
	mov	x21, x4
	mov	x22, x5
	bl	_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71
	ldp	q0, q1, [x19]
	stp	q0, q1, [x20]
	ldr	x8, [sp, #6776]
	ldr	x9, [sp, #6784]
	ldr	x10, [sp, #6792]
	ldr	x11, [sp, #6800]
	eor	x8, x8, x8, lsr #30
	mul	x8, x8, x22
	eor	x8, x8, x8, lsr #27
	mul	x8, x8, x21
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x22
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x21
	eor	x12, x9, x8
	mov	x13, #31765                     ; =0x7c15
	movk	x13, #32586, lsl #16
	movk	x13, #31161, lsl #32
	movk	x13, #40503, lsl #48
	mul	x11, x11, x13
	eor	x10, x10, x11
	eor	x10, x10, x12, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #3856
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB31_78:                               ; %bb13.preheader
	mov	x24, #0                         ; =0x0
	mov	w8, #4832                       ; =0x12e0
	mov	w9, #4296                       ; =0x10c8
	mov	w10, #4560                      ; =0x11d0
	mov	w11, #4840                      ; =0x12e8
	mov	w12, #5096                      ; =0x13e8
	mov	w13, #5368                      ; =0x14f8
	mov	w14, #5632                      ; =0x1600
	add	x15, sp, #848
	add	x8, x15, x8
	str	x8, [sp, #832]                  ; 8-byte Folded Spill
	add	x8, x15, x9
	str	x8, [sp, #152]                  ; 8-byte Folded Spill
	add	x8, x15, x10
	str	x8, [sp, #144]                  ; 8-byte Folded Spill
	add	x27, x15, x11
	add	x8, x15, x12
	str	x8, [sp, #232]                  ; 8-byte Folded Spill
	add	x8, x15, x13
	str	x8, [sp, #200]                  ; 8-byte Folded Spill
	add	x8, x15, x14
	str	x8, [sp, #192]                  ; 8-byte Folded Spill
	add	x26, x15, #2976
Lloh104:
	adrp	x8, lCPI31_15@PAGE
Lloh105:
	ldr	q0, [x8, lCPI31_15@PAGEOFF]
	str	q0, [sp, #752]                  ; 16-byte Folded Spill
	add	x8, x15, #3232
	str	x8, [sp, #240]                  ; 8-byte Folded Spill
Lloh106:
	adrp	x8, lCPI31_16@PAGE
Lloh107:
	ldr	q0, [x8, lCPI31_16@PAGEOFF]
	str	q0, [sp, #736]                  ; 16-byte Folded Spill
	add	x8, x15, #3768
	str	x8, [sp, #224]                  ; 8-byte Folded Spill
Lloh108:
	adrp	x8, lCPI31_17@PAGE
Lloh109:
	ldr	q0, [x8, lCPI31_17@PAGEOFF]
	str	q0, [sp, #720]                  ; 16-byte Folded Spill
	add	x22, x15, #4024
Lloh110:
	adrp	x8, lCPI31_18@PAGE
Lloh111:
	ldr	q0, [x8, lCPI31_18@PAGEOFF]
	str	q0, [sp, #704]                  ; 16-byte Folded Spill
	sub	x10, x23, #9
Lloh112:
	adrp	x8, lCPI31_19@PAGE
Lloh113:
	ldr	q0, [x8, lCPI31_19@PAGEOFF]
	str	q0, [sp, #688]                  ; 16-byte Folded Spill
	ldr	x9, [sp, #600]                  ; 8-byte Folded Reload
	add	x8, x9, #3780
	str	x8, [sp, #136]                  ; 8-byte Folded Spill
Lloh114:
	adrp	x8, lCPI31_20@PAGE
Lloh115:
	ldr	q0, [x8, lCPI31_20@PAGEOFF]
	str	q0, [sp, #672]                  ; 16-byte Folded Spill
	add	x8, x9, #3796
	str	x8, [sp, #120]                  ; 8-byte Folded Spill
Lloh116:
	adrp	x8, lCPI31_21@PAGE
Lloh117:
	ldr	q0, [x8, lCPI31_21@PAGEOFF]
	str	q0, [sp, #656]                  ; 16-byte Folded Spill
	add	x8, x9, #3812
	str	x8, [sp, #112]                  ; 8-byte Folded Spill
Lloh118:
	adrp	x8, lCPI31_22@PAGE
Lloh119:
	ldr	q0, [x8, lCPI31_22@PAGEOFF]
	str	q0, [sp, #640]                  ; 16-byte Folded Spill
	add	x8, x9, #3828
	str	x8, [sp, #104]                  ; 8-byte Folded Spill
Lloh120:
	adrp	x8, lCPI31_23@PAGE
Lloh121:
	ldr	q0, [x8, lCPI31_23@PAGEOFF]
	str	q0, [sp, #624]                  ; 16-byte Folded Spill
	add	x8, x9, #3844
	str	x8, [sp, #96]                   ; 8-byte Folded Spill
Lloh122:
	adrp	x8, lCPI31_24@PAGE
Lloh123:
	ldr	q0, [x8, lCPI31_24@PAGEOFF]
	str	q0, [sp, #608]                  ; 16-byte Folded Spill
	add	x8, x9, #3860
	str	x8, [sp, #88]                   ; 8-byte Folded Spill
Lloh124:
	adrp	x8, lCPI31_25@PAGE
Lloh125:
	ldr	q0, [x8, lCPI31_25@PAGEOFF]
	str	q0, [sp, #576]                  ; 16-byte Folded Spill
	add	x8, x9, #3876
	str	x8, [sp, #80]                   ; 8-byte Folded Spill
Lloh126:
	adrp	x8, lCPI31_26@PAGE
Lloh127:
	ldr	q0, [x8, lCPI31_26@PAGEOFF]
	str	q0, [sp, #560]                  ; 16-byte Folded Spill
	add	x8, x9, #3892
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
Lloh128:
	adrp	x8, lCPI31_27@PAGE
Lloh129:
	ldr	q0, [x8, lCPI31_27@PAGEOFF]
	str	q0, [sp, #544]                  ; 16-byte Folded Spill
	add	x8, x9, #3908
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
Lloh130:
	adrp	x8, lCPI31_28@PAGE
Lloh131:
	ldr	q0, [x8, lCPI31_28@PAGEOFF]
	str	q0, [sp, #528]                  ; 16-byte Folded Spill
	add	x8, x9, #3924
	str	x8, [sp, #56]                   ; 8-byte Folded Spill
Lloh132:
	adrp	x8, lCPI31_29@PAGE
Lloh133:
	ldr	q0, [x8, lCPI31_29@PAGEOFF]
	str	q0, [sp, #512]                  ; 16-byte Folded Spill
	add	x8, x9, #3940
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
Lloh134:
	adrp	x8, lCPI31_0@PAGE
Lloh135:
	ldr	q0, [x8, lCPI31_0@PAGEOFF]
	str	q0, [sp, #480]                  ; 16-byte Folded Spill
	add	x8, x9, #3956
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
Lloh136:
	adrp	x8, lCPI31_1@PAGE
Lloh137:
	ldr	q0, [x8, lCPI31_1@PAGEOFF]
	str	q0, [sp, #464]                  ; 16-byte Folded Spill
	add	x8, x9, #3972
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
Lloh138:
	adrp	x8, lCPI31_2@PAGE
Lloh139:
	ldr	q0, [x8, lCPI31_2@PAGEOFF]
	str	q0, [sp, #448]                  ; 16-byte Folded Spill
	add	x8, x9, #3988
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
Lloh140:
	adrp	x8, lCPI31_3@PAGE
Lloh141:
	ldr	q0, [x8, lCPI31_3@PAGEOFF]
	str	q0, [sp, #432]                  ; 16-byte Folded Spill
	add	x8, x9, #4004
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
Lloh142:
	adrp	x8, lCPI31_4@PAGE
Lloh143:
	ldr	q0, [x8, lCPI31_4@PAGEOFF]
	str	q0, [sp, #416]                  ; 16-byte Folded Spill
	add	x8, x9, #4020
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
Lloh144:
	adrp	x8, lCPI31_5@PAGE
Lloh145:
	ldr	q0, [x8, lCPI31_5@PAGEOFF]
	str	q0, [sp, #400]                  ; 16-byte Folded Spill
Lloh146:
	adrp	x8, lCPI31_6@PAGE
Lloh147:
	ldr	q0, [x8, lCPI31_6@PAGEOFF]
	str	q0, [sp, #384]                  ; 16-byte Folded Spill
Lloh148:
	adrp	x8, lCPI31_7@PAGE
Lloh149:
	ldr	q0, [x8, lCPI31_7@PAGEOFF]
	str	q0, [sp, #368]                  ; 16-byte Folded Spill
Lloh150:
	adrp	x8, lCPI31_8@PAGE
Lloh151:
	ldr	q0, [x8, lCPI31_8@PAGEOFF]
	str	q0, [sp, #352]                  ; 16-byte Folded Spill
Lloh152:
	adrp	x8, lCPI31_9@PAGE
Lloh153:
	ldr	q0, [x8, lCPI31_9@PAGEOFF]
	str	q0, [sp, #336]                  ; 16-byte Folded Spill
Lloh154:
	adrp	x8, lCPI31_10@PAGE
Lloh155:
	ldr	q0, [x8, lCPI31_10@PAGEOFF]
	str	q0, [sp, #320]                  ; 16-byte Folded Spill
Lloh156:
	adrp	x8, lCPI31_11@PAGE
Lloh157:
	ldr	q0, [x8, lCPI31_11@PAGEOFF]
	str	q0, [sp, #304]                  ; 16-byte Folded Spill
Lloh158:
	adrp	x8, lCPI31_12@PAGE
Lloh159:
	ldr	q0, [x8, lCPI31_12@PAGEOFF]
	str	q0, [sp, #288]                  ; 16-byte Folded Spill
Lloh160:
	adrp	x8, lCPI31_13@PAGE
Lloh161:
	ldr	q0, [x8, lCPI31_13@PAGEOFF]
	str	q0, [sp, #272]                  ; 16-byte Folded Spill
Lloh162:
	adrp	x8, lCPI31_14@PAGE
Lloh163:
	ldr	q0, [x8, lCPI31_14@PAGEOFF]
	str	q0, [sp, #256]                  ; 16-byte Folded Spill
	mov	w8, #5112                       ; =0x13f8
	add	x8, x16, x8
	stp	x8, x27, [sp, #176]             ; 16-byte Folded Spill
	add	x8, x16, #3248
	str	x8, [sp, #208]                  ; 8-byte Folded Spill
	mov	x16, x10
	mov	w28, #131                       ; =0x83
	mov	w17, #1                         ; =0x1
	mov	w19, #272                       ; =0x110
	str	x10, [sp, #800]                 ; 8-byte Folded Spill
	str	x21, [sp, #168]                 ; 8-byte Folded Spill
	str	x22, [sp, #128]                 ; 8-byte Folded Spill
	b	LBB31_80
LBB31_79:                               ; %bb93.loopexit1529
                                        ;   in Loop: Header=BB31_80 Depth=1
	ldr	x8, [sp, #248]                  ; 8-byte Folded Reload
	ldr	x24, [sp, #768]                 ; 8-byte Folded Reload
	cmp	x24, x8
	ldr	x21, [sp, #168]                 ; 8-byte Folded Reload
	b.eq	LBB31_77
LBB31_80:                               ; %bb13
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB31_100 Depth 2
                                        ;       Child Loop BB31_129 Depth 3
                                        ;       Child Loop BB31_138 Depth 3
                                        ;       Child Loop BB31_156 Depth 3
                                        ;       Child Loop BB31_115 Depth 3
	cmp	x23, #4
	b.eq	LBB31_84
; %bb.81:                               ; %bb13
                                        ;   in Loop: Header=BB31_80 Depth=1
	cmp	x23, #9
	b.eq	LBB31_84
; %bb.82:                               ; %bb13
                                        ;   in Loop: Header=BB31_80 Depth=1
	cmp	x23, #10
	b.ne	LBB31_93
; %bb.83:                               ; %bb49.thread
                                        ;   in Loop: Header=BB31_80 Depth=1
	ldr	x8, [sp, #6840]
	mov	x9, #1                          ; =0x1
	madd	x8, x8, x28, x9
	str	x8, [sp, #6840]
	b	LBB31_92
LBB31_84:                               ; %bb51
                                        ;   in Loop: Header=BB31_80 Depth=1
	cmp	x21, #4, lsl #12                ; =16384
	b.ls	LBB31_86
; %bb.85:                               ;   in Loop: Header=BB31_80 Depth=1
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	str	w0, [sp, #3792]
	strb	w1, [sp, #3796]
	strb	w2, [sp, #3797]
	cbnz	w0, LBB31_88
	b	LBB31_91
LBB31_86:                               ; %bb3.i.i
                                        ;   in Loop: Header=BB31_80 Depth=1
	ldr	x8, [sp, #6824]
	ldr	x8, [x8]
	cmp	x21, x8
	b.ls	LBB31_90
; %bb.87:                               ; %bb6.i.i492
                                        ;   in Loop: Header=BB31_80 Depth=1
	add	x8, sp, #848
	mov	w9, #5976                       ; =0x1758
	add	x0, x8, x9
	mov	w9, #5960                       ; =0x1748
	add	x2, x8, x9
	mov	x1, x21
	bl	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	ldr	x16, [sp, #800]                 ; 8-byte Folded Reload
	mov	x5, #58809                      ; =0xe5b9
	movk	x5, #7396, lsl #16
	movk	x5, #18285, lsl #32
	movk	x5, #48984, lsl #48
	mov	x4, #4587                       ; =0x11eb
	movk	x4, #4913, lsl #16
	movk	x4, #18875, lsl #32
	movk	x4, #38096, lsl #48
	mov	w3, #5968                       ; =0x1750
	str	w0, [sp, #3792]
	strb	w1, [sp, #3796]
	strb	w2, [sp, #3797]
	cbz	w0, LBB31_91
LBB31_88:                               ; %"wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit"
                                        ;   in Loop: Header=BB31_80 Depth=1
	cmp	w0, #1
	mov	w17, #1                         ; =0x1
	b.ne	LBB31_181
; %bb.89:                               ; %bb3.i494
                                        ;   in Loop: Header=BB31_80 Depth=1
	ldr	x8, [sp, #6840]
	mul	x8, x8, x28
	str	x8, [sp, #6840]
	cmp	x16, #2
	b.lo	LBB31_92
	b	LBB31_93
LBB31_90:                               ;   in Loop: Header=BB31_80 Depth=1
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #0                          ; =0x0
	str	w0, [sp, #3792]
	strb	w1, [sp, #3796]
	strb	w2, [sp, #3797]
	cbnz	w0, LBB31_88
LBB31_91:                               ; %bb2.i499
                                        ;   in Loop: Header=BB31_80 Depth=1
	ldr	x8, [sp, #6840]
	mov	x9, #1                          ; =0x1
	madd	x8, x8, x28, x9
	mov	w17, #1                         ; =0x1
	str	x8, [sp, #6840]
	cmp	x16, #2
	b.hs	LBB31_93
LBB31_92:                               ; %bb53
                                        ;   in Loop: Header=BB31_80 Depth=1
	ldr	x9, [sp, #6824]
	ldr	x9, [x9]
	cmp	x9, x21
	mul	x8, x8, x28
	cinc	x8, x8, hs
	str	x8, [sp, #6840]
LBB31_93:                               ; %bb43
                                        ;   in Loop: Header=BB31_80 Depth=1
	add	x24, x24, #1
	str	x24, [sp, #768]                 ; 8-byte Folded Spill
	ldr	x21, [sp, #784]                 ; 8-byte Folded Reload
	cbz	x25, LBB31_79
; %bb.94:                               ; %bb59.lr.ph
                                        ;   in Loop: Header=BB31_80 Depth=1
	mov	x24, #0                         ; =0x0
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #768]                  ; 8-byte Folded Reload
	madd	x8, x9, x25, x8
	str	x8, [sp, #816]                  ; 8-byte Folded Spill
	b	LBB31_100
LBB31_95:                               ; %bb2.i.i534
                                        ;   in Loop: Header=BB31_100 Depth=2
	cbnz	w15, LBB31_181
LBB31_96:                               ; %bb3.i561
                                        ;   in Loop: Header=BB31_100 Depth=2
	str	w17, [sp, #3800]
	str	xzr, [sp, #3808]
	strb	wzr, [sp, #3816]
LBB31_97:                               ; %bb92.sink.split
                                        ;   in Loop: Header=BB31_100 Depth=2
	ldr	x8, [sp, #6840]
	mul	x8, x8, x28
LBB31_98:                               ; %bb92.sink.split
                                        ;   in Loop: Header=BB31_100 Depth=2
	str	x8, [sp, #6840]
LBB31_99:                               ; %bb92
                                        ;   in Loop: Header=BB31_100 Depth=2
	add	x24, x24, #1
	cmp	x24, x25
	b.eq	LBB31_79
LBB31_100:                              ; %bb59
                                        ;   Parent Loop BB31_80 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB31_129 Depth 3
                                        ;       Child Loop BB31_138 Depth 3
                                        ;       Child Loop BB31_156 Depth 3
                                        ;       Child Loop BB31_115 Depth 3
	add	x8, x24, x21
	orr	x2, x17, x8, lsl #1
	str	x2, [sp, #6888]
	cmp	x23, #3
	b.gt	LBB31_107
; %bb.101:                              ; %bb59
                                        ;   in Loop: Header=BB31_100 Depth=2
	cmp	x23, #2
	b.lo	LBB31_110
; %bb.102:                              ; %bb59
                                        ;   in Loop: Header=BB31_100 Depth=2
	b.eq	LBB31_119
; %bb.103:                              ; %bb59
                                        ;   in Loop: Header=BB31_100 Depth=2
	cmp	x23, #3
	b.ne	LBB31_99
; %bb.104:                              ; %bb78
                                        ;   in Loop: Header=BB31_100 Depth=2
	ldr	x8, [sp, #6832]
	cbz	x8, LBB31_152
; %bb.105:                              ; %bb3.i822
                                        ;   in Loop: Header=BB31_100 Depth=2
	add	x9, sp, #848
	ldrb	w9, [x9, x3]
	tbz	w9, #0, LBB31_135
; %bb.106:                              ;   in Loop: Header=BB31_100 Depth=2
	mov	x9, #0                          ; =0x0
	ldr	x10, [sp, #6824]
	ldr	x11, [x10]
	cbnz	x11, LBB31_136
	b	LBB31_152
LBB31_107:                              ; %bb59
                                        ;   in Loop: Header=BB31_100 Depth=2
	cmp	x16, #2
	b.lo	LBB31_110
; %bb.108:                              ; %bb59
                                        ;   in Loop: Header=BB31_100 Depth=2
	cmp	x23, #7
	b.eq	LBB31_124
; %bb.109:                              ; %bb59
                                        ;   in Loop: Header=BB31_100 Depth=2
	cmp	x23, #4
	b.ne	LBB31_99
LBB31_110:                              ; %bb66
                                        ;   in Loop: Header=BB31_100 Depth=2
	add	x8, sp, #848
	ldrb	w8, [x8, x3]
	tbz	w8, #0, LBB31_112
; %bb.111:                              ;   in Loop: Header=BB31_100 Depth=2
	mov	x11, #0                         ; =0x0
	ldr	x8, [sp, #6824]
	ldr	x9, [x8]
	cbnz	x9, LBB31_113
	b	LBB31_96
LBB31_112:                              ; %bb3.i.i.i515
                                        ;   in Loop: Header=BB31_100 Depth=2
	ldr	x8, [sp, #6808]
	eor	x8, x8, x2
	eor	x8, x8, x8, lsr #30
	mul	x8, x8, x5
	eor	x8, x8, x8, lsr #27
	mul	x8, x8, x4
	eor	x11, x8, x8, lsr #31
	ldr	x8, [sp, #6824]
	ldr	x9, [x8]
	cbz	x9, LBB31_96
LBB31_113:                              ; %bb2.lr.ph.i.i531
                                        ;   in Loop: Header=BB31_100 Depth=2
	mov	x10, #0                         ; =0x0
	udiv	x12, x11, x9
	msub	x11, x12, x9, x11
	sub	x12, x9, x11
	neg	x13, x12
	b	LBB31_115
LBB31_114:                              ; %bb12.i.i542
                                        ;   in Loop: Header=BB31_115 Depth=3
	add	x10, x10, #1
	cmp	x9, x10
	b.eq	LBB31_96
LBB31_115:                              ; %bb2.i.i534
                                        ;   Parent Loop BB31_80 Depth=1
                                        ;     Parent Loop BB31_100 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x10, x12
	csel	x14, x11, x13, lo
	add	x14, x14, x10
	madd	x14, x14, x19, x8
	ldr	w15, [x14, #16]!
	cmp	w15, #1
	b.eq	LBB31_114
; %bb.116:                              ; %bb2.i.i534
                                        ;   in Loop: Header=BB31_115 Depth=3
	cmp	w15, #2
	b.ne	LBB31_95
; %bb.117:                              ; %bb6.i.i550
                                        ;   in Loop: Header=BB31_115 Depth=3
	ldr	x15, [x14, #8]
	cmp	x15, x2
	b.ne	LBB31_114
; %bb.118:                              ; %bb2.i566
                                        ;   in Loop: Header=BB31_100 Depth=2
	ldr	x8, [x14, #16]
	str	wzr, [sp, #3800]
	str	x8, [sp, #3808]
	strb	wzr, [sp, #3816]
	ldr	x9, [sp, #6840]
	mov	w10, #17161                     ; =0x4309
	madd	x8, x9, x10, x8
	add	x8, x8, #131
	b	LBB31_98
LBB31_119:                              ; %bb69
                                        ;   in Loop: Header=BB31_100 Depth=2
	ldr	x8, [sp, #816]                  ; 8-byte Folded Reload
	add	x8, x8, x24
	str	x8, [sp, #3824]
	add	x9, x8, #1
	str	x9, [sp, #3832]
	dup.2d	v0, x8
	ldr	q1, [sp, #752]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3840]
	ldr	q1, [sp, #736]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3856]
	ldr	q1, [sp, #720]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3872]
	ldr	q1, [sp, #704]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3888]
	ldr	q1, [sp, #688]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3904]
	ldr	q1, [sp, #672]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3920]
	ldr	q1, [sp, #656]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3936]
	ldr	q1, [sp, #640]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3952]
	ldr	q1, [sp, #624]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3968]
	ldr	q1, [sp, #608]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #3984]
	ldr	q1, [sp, #576]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #4000]
	ldr	q1, [sp, #560]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #4016]
	ldr	q1, [sp, #544]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #4032]
	ldr	q1, [sp, #528]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #4048]
	ldr	q1, [sp, #512]                  ; 16-byte Folded Reload
	add.2d	v0, v0, v1
	str	q0, [sp, #4064]
	ldp	q0, q1, [x26, #192]
	str	q0, [sp, #7088]
	str	q1, [sp, #7104]
	ldp	q0, q1, [x26, #224]
	str	q0, [sp, #7120]
	str	q1, [sp, #7136]
	ldp	q0, q1, [x26, #128]
	str	q0, [sp, #7024]
	str	q1, [sp, #7040]
	ldp	q0, q1, [x26, #160]
	str	q0, [sp, #7056]
	str	q1, [sp, #7072]
	ldp	q0, q1, [x26, #64]
	str	q0, [sp, #6960]
	str	q1, [sp, #6976]
	ldp	q0, q1, [x26, #96]
	str	q0, [sp, #6992]
	str	q1, [sp, #7008]
	ldp	q0, q1, [x26]
	str	q0, [sp, #6896]
	str	q1, [sp, #6912]
	ldp	q0, q1, [x26, #32]
	str	q0, [sp, #6928]
	str	q1, [sp, #6944]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2800
	add	x0, x8, #256
	add	x8, sp, #848
	mov	w9, #5976                       ; =0x1758
	add	x1, x8, x9
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #2800
	mov	w9, #5960                       ; =0x1748
	add	x4, x8, x9
	bl	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
	ldr	w8, [sp, #7152]
	cbz	w8, LBB31_133
; %bb.120:                              ; %bb69
                                        ;   in Loop: Header=BB31_100 Depth=2
	cmp	w8, #1
	b.ne	LBB31_181
; %bb.121:                              ; %bb2.i642
                                        ;   in Loop: Header=BB31_100 Depth=2
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2800
	ldrb	w20, [x8, #260]
	add	x0, x8, #528
	add	x1, x8, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	tbz	w20, #0, LBB31_143
; %bb.122:                              ; %bb4.i648
                                        ;   in Loop: Header=BB31_100 Depth=2
	ldr	x8, [sp, #6824]
	ldr	x8, [x8]
	cmp	x8, #4, lsl #12                 ; =16384
	b.lo	LBB31_148
LBB31_123:                              ; %bb18.i670
                                        ;   in Loop: Header=BB31_100 Depth=2
	mov	w9, #1                          ; =0x1
	str	x9, [sp, #4080]
	ldr	x8, [sp, #600]                  ; 8-byte Folded Reload
	strb	w9, [x8, #2976]
	b	LBB31_144
LBB31_124:                              ; %bb90
                                        ;   in Loop: Header=BB31_100 Depth=2
	add	x8, sp, #848
	ldrb	w8, [x8, x3]
	tbz	w8, #0, LBB31_126
; %bb.125:                              ;   in Loop: Header=BB31_100 Depth=2
	mov	x11, #0                         ; =0x0
	ldr	x8, [sp, #6824]
	ldr	x9, [x8]
	cbnz	x9, LBB31_127
	b	LBB31_147
LBB31_126:                              ; %bb3.i.i.i1408
                                        ;   in Loop: Header=BB31_100 Depth=2
	ldr	x8, [sp, #6808]
	eor	x8, x8, x2
	eor	x8, x8, x8, lsr #30
	mul	x8, x8, x5
	eor	x8, x8, x8, lsr #27
	mul	x8, x8, x4
	eor	x11, x8, x8, lsr #31
	ldr	x8, [sp, #6824]
	ldr	x9, [x8]
	cbz	x9, LBB31_147
LBB31_127:                              ; %bb2.lr.ph.i.i1424
                                        ;   in Loop: Header=BB31_100 Depth=2
	mov	x10, #0                         ; =0x0
	udiv	x12, x11, x9
	msub	x11, x12, x9, x11
	sub	x12, x9, x11
	neg	x13, x12
	b	LBB31_129
LBB31_128:                              ; %bb12.i.i1435
                                        ;   in Loop: Header=BB31_129 Depth=3
	add	x10, x10, #1
	cmp	x9, x10
	b.eq	LBB31_147
LBB31_129:                              ; %bb2.i.i1427
                                        ;   Parent Loop BB31_80 Depth=1
                                        ;     Parent Loop BB31_100 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x10, x12
	csel	x14, x11, x13, lo
	add	x14, x14, x10
	madd	x14, x14, x19, x8
	ldr	w15, [x14, #16]!
	cmp	w15, #1
	b.eq	LBB31_128
; %bb.130:                              ; %bb2.i.i1427
                                        ;   in Loop: Header=BB31_129 Depth=3
	cmp	w15, #2
	b.ne	LBB31_146
; %bb.131:                              ; %bb6.i.i1443
                                        ;   in Loop: Header=BB31_129 Depth=3
	ldr	x15, [x14, #8]
	cmp	x15, x2
	b.ne	LBB31_128
; %bb.132:                              ; %bb2.i1457
                                        ;   in Loop: Header=BB31_100 Depth=2
	ldr	x8, [x14, #16]
	add	x9, x8, #1
	str	x9, [x14, #16]
	str	wzr, [sp, #6736]
	str	x9, [sp, #6744]
	ldr	x9, [sp, #832]                  ; 8-byte Folded Reload
	strb	wzr, [x9, #1072]
	ldr	x9, [sp, #6840]
	mov	w10, #17161                     ; =0x4309
	madd	x8, x9, x10, x8
	add	x8, x8, #132
	b	LBB31_98
LBB31_133:                              ; %"wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65.exit679.thread1491"
                                        ;   in Loop: Header=BB31_100 Depth=2
	ldr	x8, [sp, #240]                  ; 8-byte Folded Reload
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #240]
	stp	q0, q0, [x8, #208]
	stp	q0, q0, [x8, #176]
	stp	q0, q0, [x8, #144]
	stp	q0, q0, [x8, #112]
	stp	q0, q0, [x8, #80]
	stp	q0, q0, [x8, #48]
	stp	q0, q0, [x8, #16]
	str	q0, [x8]
LBB31_134:                              ; %bb72
                                        ;   in Loop: Header=BB31_100 Depth=2
	ldr	x8, [sp, #6840]
	mul	x8, x8, x28
	mov	w3, #5968                       ; =0x1750
	mov	x4, #4587                       ; =0x11eb
	movk	x4, #4913, lsl #16
	movk	x4, #18875, lsl #32
	movk	x4, #38096, lsl #48
	mov	x5, #58809                      ; =0xe5b9
	movk	x5, #7396, lsl #16
	movk	x5, #18285, lsl #32
	movk	x5, #48984, lsl #48
	ldr	x16, [sp, #800]                 ; 8-byte Folded Reload
	mov	w17, #1                         ; =0x1
	b	LBB31_98
LBB31_135:                              ; %bb3.i.i.i.i825
                                        ;   in Loop: Header=BB31_100 Depth=2
	ldr	x9, [sp, #6808]
	eor	x9, x9, x2
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x5
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x4
	eor	x9, x9, x9, lsr #31
	ldr	x10, [sp, #6824]
	ldr	x11, [x10]
	cbz	x11, LBB31_152
LBB31_136:                              ; %bb2.lr.ph.i.i.i841
                                        ;   in Loop: Header=BB31_100 Depth=2
	mov	x12, #0                         ; =0x0
	udiv	x13, x9, x11
	msub	x13, x13, x11, x9
	sub	x14, x11, x13
	neg	x15, x14
	b	LBB31_138
LBB31_137:                              ; %bb10.i.i.i857
                                        ;   in Loop: Header=BB31_138 Depth=3
	add	x12, x12, #1
	cmp	x11, x12
	b.eq	LBB31_152
LBB31_138:                              ; %bb2.i.i.i844
                                        ;   Parent Loop BB31_80 Depth=1
                                        ;     Parent Loop BB31_100 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x12, x14
	csel	x9, x13, x15, lo
	add	x9, x9, x12
	madd	x9, x9, x19, x10
	ldr	w16, [x9, #16]!
	cmp	w16, #1
	b.eq	LBB31_137
; %bb.139:                              ; %bb2.i.i.i844
                                        ;   in Loop: Header=BB31_138 Depth=3
	cmp	w16, #2
	b.ne	LBB31_151
; %bb.140:                              ; %bb3.i3.i.i.i852
                                        ;   in Loop: Header=BB31_138 Depth=3
	ldr	x16, [x9, #8]
	cmp	x16, x2
	b.ne	LBB31_137
; %bb.141:                              ; %bb81
                                        ;   in Loop: Header=BB31_100 Depth=2
	str	w17, [x9]
	sub	x8, x8, #1
	ldp	q0, q1, [x9, #16]
	ldp	q2, q3, [x9, #48]
	ldp	q4, q5, [x9, #80]
	ldp	q6, q7, [x9, #112]
	ldp	q16, q17, [x9, #144]
	ldp	q18, q19, [x9, #176]
	ldp	q20, q21, [x9, #208]
	ldp	q22, q23, [x9, #240]
	movi.2d	v24, #0000000000000000
	stur	q24, [x9, #24]
	stur	q24, [x9, #40]
	stur	q24, [x9, #56]
	stur	q24, [x9, #72]
	stur	q24, [x9, #88]
	stur	q24, [x9, #104]
	stur	q24, [x9, #120]
	stur	q24, [x9, #136]
	stur	q24, [x9, #152]
	stur	q24, [x9, #168]
	stur	q24, [x9, #184]
	stur	q24, [x9, #200]
	stur	q24, [x9, #216]
	stur	q24, [x9, #232]
	stur	q24, [x9, #248]
	stur	q24, [x9, #8]
	str	xzr, [x9, #264]
	str	x8, [sp, #6832]
	str	x17, [sp, #4872]
	str	x2, [sp, #4880]
	ldr	x22, [sp, #136]                 ; 8-byte Folded Reload
	str	q0, [x22]
	ldp	x8, x9, [sp, #112]              ; 16-byte Folded Reload
	str	q1, [x9]
	str	q2, [x8]
	ldp	x8, x9, [sp, #96]               ; 16-byte Folded Reload
	str	q3, [x9]
	str	q4, [x8]
	ldp	x8, x9, [sp, #80]               ; 16-byte Folded Reload
	str	q5, [x9]
	str	q6, [x8]
	ldp	x8, x9, [sp, #64]               ; 16-byte Folded Reload
	str	q7, [x9]
	str	q16, [x8]
	ldp	x8, x9, [sp, #48]               ; 16-byte Folded Reload
	str	q17, [x9]
	str	q18, [x8]
	ldp	x8, x9, [sp, #32]               ; 16-byte Folded Reload
	str	q19, [x9]
	str	q20, [x8]
	ldp	x8, x9, [sp, #16]               ; 16-byte Folded Reload
	str	q21, [x9]
	str	q22, [x8]
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	q23, [x8]
	add	x8, sp, #848
	add	x1, x8, #4032
	ldr	x0, [sp, #152]                  ; 8-byte Folded Reload
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	mov	w17, #1                         ; =0x1
	mov	x5, #58809                      ; =0xe5b9
	movk	x5, #7396, lsl #16
	movk	x5, #18285, lsl #32
	movk	x5, #48984, lsl #48
	mov	x4, #4587                       ; =0x11eb
	movk	x4, #4913, lsl #16
	movk	x4, #18875, lsl #32
	movk	x4, #38096, lsl #48
	mov	w3, #5968                       ; =0x1750
	ldr	x8, [sp, #6840]
	ldr	x9, [sp, #5144]
	ldp	q1, q0, [x22, #32]
	ldr	x10, [sp, #144]                 ; 8-byte Folded Reload
	stp	q1, q0, [x10, #32]
	ldp	q1, q0, [x22, #96]
	stp	q1, q0, [x10, #96]
	ldp	q1, q0, [x22, #64]
	stp	q1, q0, [x10, #64]
	ldp	q1, q0, [x22, #160]
	stp	q1, q0, [x10, #160]
	ldp	q1, q0, [x22, #128]
	stp	q1, q0, [x10, #128]
	ldp	q1, q0, [x22, #224]
	stp	q1, q0, [x10, #224]
	ldp	q1, q0, [x22, #192]
	stp	q1, q0, [x10, #192]
	ldp	q1, q0, [x22]
	ldr	x22, [sp, #128]                 ; 8-byte Folded Reload
	stp	q1, q0, [x10]
	ldr	x10, [sp, #5648]
	madd	x8, x8, x28, x10
	ldr	x10, [sp, #5408]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5416]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5424]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5432]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5440]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5448]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5456]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5464]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5472]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5480]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5488]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5496]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5504]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5512]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5520]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5528]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5536]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5544]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5552]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5560]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5568]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5576]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5584]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5592]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5600]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5608]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5616]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5624]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5632]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #5640]
	madd	x9, x9, x28, x10
	madd	x8, x9, x28, x8
	ldr	x9, [sp, #5656]
	madd	x8, x8, x28, x9
	add	x8, x8, #131
	str	x8, [sp, #6840]
	add	x9, sp, #848
	ldrb	w9, [x9, x3]
	ldr	x2, [sp, #6888]
	tbnz	w9, #0, LBB31_153
LBB31_142:                              ; %bb3.i.i.i966
                                        ;   in Loop: Header=BB31_100 Depth=2
	ldr	x9, [sp, #6808]
	eor	x9, x2, x9
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x5
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x4
	eor	x12, x9, x9, lsr #31
	ldr	x9, [sp, #6824]
	ldr	x10, [x9]
	cbnz	x10, LBB31_154
	b	LBB31_161
LBB31_143:                              ; %bb3.i646
                                        ;   in Loop: Header=BB31_100 Depth=2
	mov	w8, #1                          ; =0x1
	str	x8, [sp, #4080]
LBB31_144:                              ; %"wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65.exit679.thread"
                                        ;   in Loop: Header=BB31_100 Depth=2
	add	x21, sp, #848
	add	x0, x21, #3240
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2800
	add	x1, x8, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
LBB31_145:                              ; %bb73
                                        ;   in Loop: Header=BB31_100 Depth=2
	ldr	x8, [sp, #600]                  ; 8-byte Folded Reload
	ldrb	w20, [x8, #2976]
	add	x8, sp, #848
	add	x0, x8, #3504
	add	x1, x21, #3240
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	ldr	x8, [sp, #6840]
	cmp	w20, #0
	mov	w17, #1                         ; =0x1
	cinc	x9, x17, ne
	madd	x8, x8, x28, x9
	ldr	x9, [sp, #4352]
	ldr	x11, [sp, #208]                 ; 8-byte Folded Reload
	ldp	q1, q0, [x11, #96]
	ldr	x10, [sp, #224]                 ; 8-byte Folded Reload
	stp	q1, q0, [x10, #96]
	ldp	q1, q0, [x11, #64]
	stp	q1, q0, [x10, #64]
	ldp	q1, q0, [x11, #160]
	stp	q1, q0, [x10, #160]
	ldp	q1, q0, [x11, #128]
	stp	q1, q0, [x10, #128]
	ldp	q1, q0, [x11, #224]
	stp	q1, q0, [x10, #224]
	ldp	q1, q0, [x11, #192]
	stp	q1, q0, [x10, #192]
	ldp	q1, q0, [x11, #32]
	stp	q1, q0, [x10, #32]
	ldp	q0, q1, [x11]
	stp	q0, q1, [x10]
	ldr	x10, [sp, #4616]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4624]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4632]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4640]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4648]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4656]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4664]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4672]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4680]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4688]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4696]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4704]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4712]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4720]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4728]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4736]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4744]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4752]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4760]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4768]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4776]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4784]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4792]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4800]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4808]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4816]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4824]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4832]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4840]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4848]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #4856]
	add	x8, x8, x10
	madd	x8, x9, x28, x8
	ldr	x9, [sp, #4864]
	madd	x8, x8, x28, x9
	mov	w3, #5968                       ; =0x1750
	mov	x4, #4587                       ; =0x11eb
	movk	x4, #4913, lsl #16
	movk	x4, #18875, lsl #32
	movk	x4, #38096, lsl #48
	mov	x5, #58809                      ; =0xe5b9
	movk	x5, #7396, lsl #16
	movk	x5, #18285, lsl #32
	movk	x5, #48984, lsl #48
	ldr	x21, [sp, #784]                 ; 8-byte Folded Reload
	ldr	x16, [sp, #800]                 ; 8-byte Folded Reload
	b	LBB31_98
LBB31_146:                              ; %bb2.i.i1427
                                        ;   in Loop: Header=BB31_100 Depth=2
	cbnz	w15, LBB31_181
LBB31_147:                              ; %bb3.i1452
                                        ;   in Loop: Header=BB31_100 Depth=2
	str	w17, [sp, #6736]
	str	xzr, [sp, #6744]
	ldr	x8, [sp, #832]                  ; 8-byte Folded Reload
	strb	wzr, [x8, #1072]
	b	LBB31_97
LBB31_148:                              ; %bb7.i652
                                        ;   in Loop: Header=BB31_100 Depth=2
	cmp	x8, #2, lsl #12                 ; =8192
	mov	w9, #8192                       ; =0x2000
	csel	x9, x8, x9, lo
	lsl	x9, x9, #1
	cmp	x8, #0
	csinc	x1, x9, xzr, ne
	cmp	x1, x8
	b.ls	LBB31_175
; %bb.149:                              ; %"wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.i663"
                                        ;   in Loop: Header=BB31_100 Depth=2
	add	x8, sp, #848
	mov	w9, #5976                       ; =0x1758
	add	x0, x8, x9
	mov	w9, #5960                       ; =0x1748
	add	x2, x8, x9
	bl	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	str	w0, [sp, #7688]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2800
	strb	w1, [x8, #796]
	strb	w2, [x8, #797]
	cbz	w0, LBB31_176
; %bb.150:                              ; %"wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.i663"
                                        ;   in Loop: Header=BB31_100 Depth=2
	cmp	w0, #1
	b.eq	LBB31_123
	b	LBB31_181
LBB31_151:                              ; %bb2.i.i.i844
                                        ;   in Loop: Header=BB31_100 Depth=2
	cbnz	w16, LBB31_181
LBB31_152:                              ; %bb82
                                        ;   in Loop: Header=BB31_100 Depth=2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x22, #240]
	stp	q0, q0, [x22, #208]
	stp	q0, q0, [x22, #176]
	stp	q0, q0, [x22, #144]
	stp	q0, q0, [x22, #112]
	stp	q0, q0, [x22, #80]
	stp	q0, q0, [x22, #48]
	stp	q0, q0, [x22, #16]
	ldr	x8, [sp, #6840]
	mul	x8, x8, x28
	str	q0, [x22]
	str	x8, [sp, #6840]
	add	x9, sp, #848
	ldrb	w9, [x9, x3]
	ldr	x2, [sp, #6888]
	tbz	w9, #0, LBB31_142
LBB31_153:                              ;   in Loop: Header=BB31_100 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	x9, [sp, #6824]
	ldr	x10, [x9]
	cbz	x10, LBB31_161
LBB31_154:                              ; %bb2.lr.ph.i.i982
                                        ;   in Loop: Header=BB31_100 Depth=2
	mov	x11, #0                         ; =0x0
	udiv	x13, x12, x10
	msub	x12, x13, x10, x12
	sub	x13, x10, x12
	neg	x14, x13
	b	LBB31_156
LBB31_155:                              ; %bb12.i.i993
                                        ;   in Loop: Header=BB31_156 Depth=3
	add	x11, x11, #1
	cmp	x10, x11
	b.eq	LBB31_161
LBB31_156:                              ; %bb2.i.i985
                                        ;   Parent Loop BB31_80 Depth=1
                                        ;     Parent Loop BB31_100 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x11, x13
	csel	x15, x12, x14, lo
	add	x15, x15, x11
	madd	x15, x15, x19, x9
	ldr	w16, [x15, #16]!
	cmp	w16, #1
	b.eq	LBB31_155
; %bb.157:                              ; %bb2.i.i985
                                        ;   in Loop: Header=BB31_156 Depth=3
	cmp	w16, #2
	b.ne	LBB31_160
; %bb.158:                              ; %bb6.i.i1001
                                        ;   in Loop: Header=BB31_156 Depth=3
	ldr	x16, [x15, #8]
	cmp	x16, x2
	b.ne	LBB31_155
; %bb.159:                              ; %bb2.i1017
                                        ;   in Loop: Header=BB31_100 Depth=2
	ldr	x9, [x15, #16]
	str	wzr, [sp, #5664]
	str	x9, [sp, #5672]
	ldr	x10, [sp, #832]                 ; 8-byte Folded Reload
	strb	wzr, [x10]
	mov	w10, #17161                     ; =0x4309
	madd	x8, x8, x10, x9
	add	x8, x8, #131
	b	LBB31_162
LBB31_160:                              ; %bb2.i.i985
                                        ;   in Loop: Header=BB31_100 Depth=2
	cbnz	w16, LBB31_181
LBB31_161:                              ; %bb3.i1012
                                        ;   in Loop: Header=BB31_100 Depth=2
	str	w17, [sp, #5664]
	str	xzr, [sp, #5672]
	mul	x8, x8, x28
	ldr	x9, [sp, #832]                  ; 8-byte Folded Reload
	strb	wzr, [x9]
LBB31_162:                              ; %wf_map_cost_lookup_result.exit1024
                                        ;   in Loop: Header=BB31_100 Depth=2
	str	x8, [sp, #6840]
	ldr	x8, [sp, #816]                  ; 8-byte Folded Reload
	add	x8, x8, x24
	add	x9, x8, #31
	str	x8, [sp, #5688]
	dup.2d	v0, x8
	ldr	q1, [sp, #480]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5696]
	ldr	q1, [sp, #464]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5712]
	ldr	q1, [sp, #448]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5728]
	ldr	q1, [sp, #432]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5744]
	ldr	q1, [sp, #416]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5760]
	ldr	q1, [sp, #400]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5776]
	ldr	q1, [sp, #384]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5792]
	ldr	q1, [sp, #368]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5808]
	ldr	q1, [sp, #352]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5824]
	ldr	q1, [sp, #336]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5840]
	ldr	q1, [sp, #320]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5856]
	ldr	q1, [sp, #304]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5872]
	ldr	q1, [sp, #288]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5888]
	ldr	q1, [sp, #272]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #5904]
	ldr	q1, [sp, #256]                  ; 16-byte Folded Reload
	add.2d	v0, v0, v1
	str	q0, [sp, #5920]
	str	x9, [sp, #5936]
	ldp	q0, q1, [x27, #192]
	str	q0, [sp, #7088]
	str	q1, [sp, #7104]
	ldp	q0, q1, [x27, #224]
	str	q0, [sp, #7120]
	str	q1, [sp, #7136]
	ldp	q0, q1, [x27, #128]
	str	q0, [sp, #7024]
	str	q1, [sp, #7040]
	ldp	q0, q1, [x27, #160]
	str	q0, [sp, #7056]
	str	q1, [sp, #7072]
	ldp	q0, q1, [x27, #64]
	str	q0, [sp, #6960]
	str	q1, [sp, #6976]
	ldp	q0, q1, [x27, #96]
	str	q0, [sp, #6992]
	str	q1, [sp, #7008]
	ldp	q0, q1, [x27]
	str	q0, [sp, #6896]
	str	q1, [sp, #6912]
	ldp	q0, q1, [x27, #32]
	str	q0, [sp, #6928]
	str	q1, [sp, #6944]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2800
	add	x0, x8, #256
	add	x8, sp, #848
	mov	w9, #5976                       ; =0x1758
	add	x1, x8, x9
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #2800
	mov	w9, #5960                       ; =0x1748
	add	x4, x8, x9
	bl	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
	ldr	w8, [sp, #7152]
	cbz	w8, LBB31_167
; %bb.163:                              ; %wf_map_cost_lookup_result.exit1024
                                        ;   in Loop: Header=BB31_100 Depth=2
	cmp	w8, #1
	b.ne	LBB31_181
; %bb.164:                              ; %bb2.i1093
                                        ;   in Loop: Header=BB31_100 Depth=2
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2800
	ldrb	w20, [x8, #260]
	add	x0, x8, #528
	add	x1, x8, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	tbz	w20, #0, LBB31_169
; %bb.165:                              ; %bb4.i1099
                                        ;   in Loop: Header=BB31_100 Depth=2
	ldr	x8, [sp, #6824]
	ldr	x8, [x8]
	cmp	x8, #4, lsl #12                 ; =16384
	mov	w9, #5104                       ; =0x13f0
	b.lo	LBB31_172
LBB31_166:                              ; %bb18.i1121
                                        ;   in Loop: Header=BB31_100 Depth=2
	mov	w10, #1                         ; =0x1
	str	x10, [sp, #5944]
	ldr	x8, [sp, #832]                  ; 8-byte Folded Reload
	strb	w10, [x8, #268]
	b	LBB31_170
LBB31_167:                              ; %"wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65.exit1130.thread1502"
                                        ;   in Loop: Header=BB31_100 Depth=2
	ldr	x8, [sp, #232]                  ; 8-byte Folded Reload
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x8, #240]
	stp	q0, q0, [x8, #208]
	stp	q0, q0, [x8, #176]
	stp	q0, q0, [x8, #144]
	stp	q0, q0, [x8, #112]
	stp	q0, q0, [x8, #80]
	stp	q0, q0, [x8, #48]
	stp	q0, q0, [x8, #16]
	str	q0, [x8]
	mov	w3, #5968                       ; =0x1750
	ldr	x16, [sp, #800]                 ; 8-byte Folded Reload
LBB31_168:                              ; %bb84
                                        ;   in Loop: Header=BB31_100 Depth=2
	ldr	x8, [sp, #6840]
	mul	x8, x8, x28
	mov	x4, #4587                       ; =0x11eb
	movk	x4, #4913, lsl #16
	movk	x4, #18875, lsl #32
	movk	x4, #38096, lsl #48
	mov	x5, #58809                      ; =0xe5b9
	movk	x5, #7396, lsl #16
	movk	x5, #18285, lsl #32
	movk	x5, #48984, lsl #48
	mov	w17, #1                         ; =0x1
	b	LBB31_98
LBB31_169:                              ; %bb3.i1097
                                        ;   in Loop: Header=BB31_100 Depth=2
	mov	w8, #1                          ; =0x1
	str	x8, [sp, #5944]
	mov	w9, #5104                       ; =0x13f0
LBB31_170:                              ; %"wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65.exit1130.thread"
                                        ;   in Loop: Header=BB31_100 Depth=2
	add	x21, sp, #848
	add	x0, x21, x9
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2800
	add	x1, x8, #264
	mov	w2, #264                        ; =0x108
	mov	w27, #5104                      ; =0x13f0
	bl	_memcpy
LBB31_171:                              ; %bb85
                                        ;   in Loop: Header=BB31_100 Depth=2
	ldr	x8, [sp, #832]                  ; 8-byte Folded Reload
	ldrb	w20, [x8, #268]
	add	x1, x21, x27
	ldr	x0, [sp, #200]                  ; 8-byte Folded Reload
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	ldr	x8, [sp, #6840]
	cmp	w20, #0
	mov	w17, #1                         ; =0x1
	cinc	x9, x17, ne
	madd	x8, x8, x28, x9
	ldr	x9, [sp, #6216]
	ldr	x11, [sp, #176]                 ; 8-byte Folded Reload
	ldp	q1, q0, [x11, #96]
	ldr	x10, [sp, #192]                 ; 8-byte Folded Reload
	stp	q1, q0, [x10, #96]
	ldp	q1, q0, [x11, #64]
	stp	q1, q0, [x10, #64]
	ldp	q1, q0, [x11, #160]
	stp	q1, q0, [x10, #160]
	ldp	q1, q0, [x11, #128]
	stp	q1, q0, [x10, #128]
	ldp	q1, q0, [x11, #224]
	stp	q1, q0, [x10, #224]
	ldp	q1, q0, [x11, #192]
	stp	q1, q0, [x10, #192]
	ldp	q1, q0, [x11, #32]
	stp	q1, q0, [x10, #32]
	ldp	q0, q1, [x11]
	stp	q0, q1, [x10]
	ldr	x10, [sp, #6480]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6488]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6496]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6504]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6512]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6520]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6528]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6536]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6544]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6552]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6560]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6568]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6576]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6584]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6592]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6600]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6608]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6616]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6624]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6632]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6640]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6648]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6656]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6664]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6672]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6680]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6688]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6696]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6704]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6712]
	madd	x9, x9, x28, x10
	ldr	x10, [sp, #6720]
	add	x8, x8, x10
	madd	x8, x9, x28, x8
	ldr	x9, [sp, #6728]
	madd	x8, x8, x28, x9
	mov	w3, #5968                       ; =0x1750
	mov	x4, #4587                       ; =0x11eb
	movk	x4, #4913, lsl #16
	movk	x4, #18875, lsl #32
	movk	x4, #38096, lsl #48
	mov	x5, #58809                      ; =0xe5b9
	movk	x5, #7396, lsl #16
	movk	x5, #18285, lsl #32
	movk	x5, #48984, lsl #48
	ldr	x21, [sp, #784]                 ; 8-byte Folded Reload
	ldr	x16, [sp, #800]                 ; 8-byte Folded Reload
	ldr	x27, [sp, #184]                 ; 8-byte Folded Reload
	b	LBB31_98
LBB31_172:                              ; %bb7.i1103
                                        ;   in Loop: Header=BB31_100 Depth=2
	cmp	x8, #2, lsl #12                 ; =8192
	mov	w9, #8192                       ; =0x2000
	csel	x9, x8, x9, lo
	lsl	x9, x9, #1
	cmp	x8, #0
	csinc	x1, x9, xzr, ne
	cmp	x1, x8
	b.ls	LBB31_178
; %bb.173:                              ; %"wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.i1114"
                                        ;   in Loop: Header=BB31_100 Depth=2
	add	x8, sp, #848
	mov	w9, #5976                       ; =0x1758
	add	x0, x8, x9
	mov	w9, #5960                       ; =0x1748
	add	x2, x8, x9
	bl	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	str	w0, [sp, #7688]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2800
	strb	w1, [x8, #796]
	strb	w2, [x8, #797]
	cbz	w0, LBB31_179
; %bb.174:                              ; %"wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.i1114"
                                        ;   in Loop: Header=BB31_100 Depth=2
	cmp	w0, #1
	mov	w9, #5104                       ; =0x13f0
	b.eq	LBB31_166
	b	LBB31_181
LBB31_175:                              ; %"wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.thread.i657"
                                        ;   in Loop: Header=BB31_100 Depth=2
	str	wzr, [sp, #7688]
	strh	wzr, [sp, #7692]
LBB31_176:                              ; %"wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65.exit679"
                                        ;   in Loop: Header=BB31_100 Depth=2
	ldr	x2, [sp, #7424]
	ldp	x8, x3, [sp, #496]              ; 16-byte Folded Reload
	ldp	q0, q1, [x8, #192]
	stp	q0, q1, [x3, #192]
	ldp	q0, q1, [x8, #224]
	stp	q0, q1, [x3, #224]
	ldp	q0, q1, [x8, #128]
	stp	q0, q1, [x3, #128]
	ldp	q0, q1, [x8, #160]
	stp	q0, q1, [x3, #160]
	ldp	q0, q1, [x8, #64]
	stp	q0, q1, [x3, #64]
	ldp	q0, q1, [x8, #96]
	stp	q0, q1, [x3, #96]
	ldp	q0, q1, [x8]
	stp	q0, q1, [x3]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x3, #32]
	add	x8, sp, #848
	mov	w9, #5976                       ; =0x1758
	add	x1, x8, x9
	mov	w9, #5960                       ; =0x1748
	add	x4, x8, x9
	ldr	x0, [sp, #240]                  ; 8-byte Folded Reload
	bl	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
	ldr	w8, [sp, #4080]
	cbz	w8, LBB31_134
; %bb.177:                              ; %"wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65.exit679"
                                        ;   in Loop: Header=BB31_100 Depth=2
	cmp	w8, #1
	add	x21, sp, #848
	b.eq	LBB31_145
	b	LBB31_181
LBB31_178:                              ; %"wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.thread.i1108"
                                        ;   in Loop: Header=BB31_100 Depth=2
	str	wzr, [sp, #7688]
	strh	wzr, [sp, #7692]
LBB31_179:                              ; %"wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65.exit1130"
                                        ;   in Loop: Header=BB31_100 Depth=2
	ldr	x2, [sp, #7424]
	ldp	x8, x3, [sp, #496]              ; 16-byte Folded Reload
	ldp	q0, q1, [x8, #192]
	stp	q0, q1, [x3, #192]
	ldp	q0, q1, [x8, #224]
	stp	q0, q1, [x3, #224]
	ldp	q0, q1, [x8, #128]
	stp	q0, q1, [x3, #128]
	ldp	q0, q1, [x8, #160]
	stp	q0, q1, [x3, #160]
	ldp	q0, q1, [x8, #64]
	stp	q0, q1, [x3, #64]
	ldp	q0, q1, [x8, #96]
	stp	q0, q1, [x3, #96]
	ldp	q0, q1, [x8]
	stp	q0, q1, [x3]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x3, #32]
	add	x8, sp, #848
	mov	w9, #5976                       ; =0x1758
	add	x1, x8, x9
	mov	w9, #5960                       ; =0x1748
	add	x4, x8, x9
	ldr	x0, [sp, #232]                  ; 8-byte Folded Reload
	bl	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
	ldr	w8, [sp, #5944]
	mov	w3, #5968                       ; =0x1750
	ldr	x16, [sp, #800]                 ; 8-byte Folded Reload
	cbz	w8, LBB31_168
; %bb.180:                              ; %"wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65.exit1130"
                                        ;   in Loop: Header=BB31_100 Depth=2
	cmp	w8, #1
	add	x21, sp, #848
	mov	w27, #5104                      ; =0x13f0
	b.eq	LBB31_171
LBB31_181:                              ; %invalid.tag.b2
	bl	_abort
LBB31_182:                              ; %window.block.oom.v1.i.i.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh72, Lloh73
	.loh AdrpAdrp	Lloh70, Lloh72
	.loh AdrpLdr	Lloh70, Lloh71
	.loh AdrpAdrp	Lloh68, Lloh70
	.loh AdrpLdr	Lloh68, Lloh69
	.loh AdrpAdrp	Lloh66, Lloh68
	.loh AdrpLdr	Lloh66, Lloh67
	.loh AdrpAdrp	Lloh64, Lloh66
	.loh AdrpLdr	Lloh64, Lloh65
	.loh AdrpAdrp	Lloh62, Lloh64
	.loh AdrpLdr	Lloh62, Lloh63
	.loh AdrpAdrp	Lloh60, Lloh62
	.loh AdrpLdr	Lloh60, Lloh61
	.loh AdrpAdrp	Lloh58, Lloh60
	.loh AdrpLdr	Lloh58, Lloh59
	.loh AdrpAdrp	Lloh56, Lloh58
	.loh AdrpLdr	Lloh56, Lloh57
	.loh AdrpAdrp	Lloh54, Lloh56
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpAdrp	Lloh52, Lloh54
	.loh AdrpLdr	Lloh52, Lloh53
	.loh AdrpAdrp	Lloh50, Lloh52
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpAdrp	Lloh48, Lloh50
	.loh AdrpLdr	Lloh48, Lloh49
	.loh AdrpAdrp	Lloh46, Lloh48
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpAdrp	Lloh44, Lloh46
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpLdr	Lloh102, Lloh103
	.loh AdrpAdrp	Lloh100, Lloh102
	.loh AdrpLdr	Lloh100, Lloh101
	.loh AdrpAdrp	Lloh98, Lloh100
	.loh AdrpLdr	Lloh98, Lloh99
	.loh AdrpAdrp	Lloh96, Lloh98
	.loh AdrpLdr	Lloh96, Lloh97
	.loh AdrpAdrp	Lloh94, Lloh96
	.loh AdrpLdr	Lloh94, Lloh95
	.loh AdrpAdrp	Lloh92, Lloh94
	.loh AdrpLdr	Lloh92, Lloh93
	.loh AdrpLdr	Lloh90, Lloh91
	.loh AdrpLdr	Lloh88, Lloh89
	.loh AdrpLdr	Lloh86, Lloh87
	.loh AdrpAdrp	Lloh84, Lloh86
	.loh AdrpLdr	Lloh84, Lloh85
	.loh AdrpLdr	Lloh82, Lloh83
	.loh AdrpAdrp	Lloh80, Lloh82
	.loh AdrpLdr	Lloh80, Lloh81
	.loh AdrpLdr	Lloh78, Lloh79
	.loh AdrpLdr	Lloh76, Lloh77
	.loh AdrpLdr	Lloh74, Lloh75
	.loh AdrpLdr	Lloh162, Lloh163
	.loh AdrpAdrp	Lloh160, Lloh162
	.loh AdrpLdr	Lloh160, Lloh161
	.loh AdrpAdrp	Lloh158, Lloh160
	.loh AdrpLdr	Lloh158, Lloh159
	.loh AdrpAdrp	Lloh156, Lloh158
	.loh AdrpLdr	Lloh156, Lloh157
	.loh AdrpAdrp	Lloh154, Lloh156
	.loh AdrpLdr	Lloh154, Lloh155
	.loh AdrpAdrp	Lloh152, Lloh154
	.loh AdrpLdr	Lloh152, Lloh153
	.loh AdrpAdrp	Lloh150, Lloh152
	.loh AdrpLdr	Lloh150, Lloh151
	.loh AdrpAdrp	Lloh148, Lloh150
	.loh AdrpLdr	Lloh148, Lloh149
	.loh AdrpAdrp	Lloh146, Lloh148
	.loh AdrpLdr	Lloh146, Lloh147
	.loh AdrpAdrp	Lloh144, Lloh146
	.loh AdrpLdr	Lloh144, Lloh145
	.loh AdrpLdr	Lloh142, Lloh143
	.loh AdrpLdr	Lloh140, Lloh141
	.loh AdrpLdr	Lloh138, Lloh139
	.loh AdrpLdr	Lloh136, Lloh137
	.loh AdrpLdr	Lloh134, Lloh135
	.loh AdrpLdr	Lloh132, Lloh133
	.loh AdrpLdr	Lloh130, Lloh131
	.loh AdrpLdr	Lloh128, Lloh129
	.loh AdrpLdr	Lloh126, Lloh127
	.loh AdrpLdr	Lloh124, Lloh125
	.loh AdrpLdr	Lloh122, Lloh123
	.loh AdrpLdr	Lloh120, Lloh121
	.loh AdrpLdr	Lloh118, Lloh119
	.loh AdrpLdr	Lloh116, Lloh117
	.loh AdrpLdr	Lloh114, Lloh115
	.loh AdrpLdr	Lloh112, Lloh113
	.loh AdrpAdrp	Lloh110, Lloh112
	.loh AdrpLdr	Lloh110, Lloh111
	.loh AdrpAdrp	Lloh108, Lloh110
	.loh AdrpLdr	Lloh108, Lloh109
	.loh AdrpLdr	Lloh106, Lloh107
	.loh AdrpLdr	Lloh104, Lloh105
	.loh AdrpLdrGot	Lloh42, Lloh43
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd ; -- Begin function wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd
	.p2align	2
_wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd: ; @"wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #144
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 144
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x2
	mov	x21, x1
	mov	x20, x0
	mov	x22, #31765                     ; =0x7c15
	movk	x22, #32586, lsl #16
	movk	x22, #31161, lsl #32
	movk	x22, #40503, lsl #48
	eor	x8, x2, x22
	str	x8, [sp, #24]
	strb	wzr, [sp, #32]
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB32_23
; %bb.1:                                ; %bb1.i.i.i
	stp	xzr, x20, [x0]
	cbz	x20, LBB32_5
; %bb.2:                                ; %bb5.i.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
LBB32_3:                                ; %bb5.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x9], #24
	cmp	x20, x8
	b.ne	LBB32_3
; %bb.4:                                ; %bb4.bb7_crit_edge.i.i.i
	str	x20, [x0]
LBB32_5:                                ; %"wf_std.collections.hash_map.hash_map_new$instance$820b2044b97e0fbd.exit"
	stp	x0, xzr, [sp, #8]
	cbz	x21, LBB32_12
; %bb.6:                                ; %bb2.lr.ph
	mov	w23, #1                         ; =0x1
	mov	w25, #131                       ; =0x83
	mov	w20, #1                         ; =0x1
	mov	x24, x19
	b	LBB32_8
LBB32_7:                                ; %bb2.i
                                        ;   in Loop: Header=BB32_8 Depth=1
	mul	x24, x24, x25
	add	x19, x19, #1
	add	x20, x20, #2
	subs	x21, x21, #1
	b.eq	LBB32_11
LBB32_8:                                ; %bb2
                                        ; =>This Inner Loop Header: Depth=1
	add	x0, sp, #40
	add	x1, sp, #8
	add	x4, sp, #24
	mov	x2, x20
	mov	x3, x19
	bl	_wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad
	ldr	w8, [sp, #40]
	cbz	w8, LBB32_7
; %bb.9:                                ; %bb2
                                        ;   in Loop: Header=BB32_8 Depth=1
	cmp	w8, #1
	b.ne	LBB32_19
; %bb.10:                               ; %bb3.i
                                        ;   in Loop: Header=BB32_8 Depth=1
	ldp	x9, x8, [sp, #48]
	ldrb	w10, [sp, #44]
	tst	w10, #0x1
	cinc	x10, x23, ne
	madd	x9, x24, x25, x9
	add	x9, x9, x10
	madd	x24, x9, x25, x8
	add	x19, x19, #1
	add	x20, x20, #2
	subs	x21, x21, #1
	b.ne	LBB32_8
LBB32_11:                               ; %bb4.loopexit
	ldp	x0, x8, [sp, #8]
	ldr	x20, [x0]
	mov	x19, x24
	b	LBB32_13
LBB32_12:
	mov	x8, #0                          ; =0x0
LBB32_13:                               ; %bb4
	mov	x23, #58809                     ; =0xe5b9
	movk	x23, #7396, lsl #16
	movk	x23, #18285, lsl #32
	movk	x23, #48984, lsl #48
	mov	x21, #4587                      ; =0x11eb
	movk	x21, #4913, lsl #16
	movk	x21, #18875, lsl #32
	movk	x21, #38096, lsl #48
	cbz	x20, LBB32_21
; %bb.14:                               ; %bb5.i.preheader
	mov	x9, #0                          ; =0x0
	mov	x24, #0                         ; =0x0
	mov	x25, #0                         ; =0x0
	sub	x10, x20, #1
	mov	w11, #24                        ; =0x18
	madd	x11, x20, x11, x0
	mov	w12, #131                       ; =0x83
	b	LBB32_17
LBB32_15:                               ; %bb7.i
                                        ;   in Loop: Header=BB32_17 Depth=1
	ldp	x14, x13, [x11]
	madd	x13, x14, x12, x13
	add	x25, x13, x25
	eor	x13, x13, x13, lsr #30
	mul	x13, x13, x23
	eor	x13, x13, x13, lsr #27
	mul	x13, x13, x21
	eor	x14, x24, x13, lsr #31
	eor	x24, x14, x13
	add	x9, x9, #1
LBB32_16:                               ; %bb6.i
                                        ;   in Loop: Header=BB32_17 Depth=1
	sub	x10, x10, #1
	sub	x11, x11, #24
	cmn	x10, #1
	b.eq	LBB32_20
LBB32_17:                               ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	str	x10, [x0]
	ldur	w13, [x11, #-8]
	cmp	w13, #2
	b.lo	LBB32_16
; %bb.18:                               ; %bb5.i
                                        ;   in Loop: Header=BB32_17 Depth=1
	b.eq	LBB32_15
LBB32_19:                               ; %invalid.tag.b0.i
	bl	_abort
LBB32_20:                               ; %"wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19.exit.loopexit"
	mul	x22, x9, x22
	b	LBB32_22
LBB32_21:
	mov	x22, #0                         ; =0x0
	mov	x24, #0                         ; =0x0
	mov	x25, #0                         ; =0x0
LBB32_22:                               ; %"wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19.exit"
	add	x20, x8, x20, lsl #32
	bl	_free
	eor	x8, x19, x19, lsr #30
	mul	x8, x8, x23
	eor	x8, x8, x8, lsr #27
	mul	x8, x8, x21
	eor	x9, x25, x25, lsr #30
	mul	x9, x9, x23
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x21
	eor	x10, x9, x8
	eor	x11, x20, x24
	eor	x11, x11, x22
	eor	x10, x11, x10, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
LBB32_23:                               ; %window.block.oom.v1.i.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_map_cost_library_geometry$instance$4250cb78d3f44027
lCPI33_0:
	.quad	1                               ; 0x1
	.quad	2                               ; 0x2
lCPI33_1:
	.quad	3                               ; 0x3
	.quad	4                               ; 0x4
lCPI33_2:
	.quad	5                               ; 0x5
	.quad	6                               ; 0x6
lCPI33_3:
	.quad	7                               ; 0x7
	.quad	8                               ; 0x8
lCPI33_4:
	.quad	9                               ; 0x9
	.quad	10                              ; 0xa
lCPI33_5:
	.quad	11                              ; 0xb
	.quad	12                              ; 0xc
lCPI33_6:
	.quad	13                              ; 0xd
	.quad	14                              ; 0xe
lCPI33_7:
	.quad	15                              ; 0xf
	.quad	16                              ; 0x10
lCPI33_8:
	.quad	17                              ; 0x11
	.quad	18                              ; 0x12
lCPI33_9:
	.quad	19                              ; 0x13
	.quad	20                              ; 0x14
lCPI33_10:
	.quad	21                              ; 0x15
	.quad	22                              ; 0x16
lCPI33_11:
	.quad	23                              ; 0x17
	.quad	24                              ; 0x18
lCPI33_12:
	.quad	25                              ; 0x19
	.quad	26                              ; 0x1a
lCPI33_13:
	.quad	27                              ; 0x1b
	.quad	28                              ; 0x1c
lCPI33_14:
	.quad	29                              ; 0x1d
	.quad	30                              ; 0x1e
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_map_cost_library_geometry$instance$4250cb78d3f44027
	.p2align	2
_wf_map_cost_library_geometry$instance$4250cb78d3f44027: ; @"wf_map_cost_library_geometry$instance$4250cb78d3f44027"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	sub	sp, sp, #832
	.cfi_def_cfa_offset 896
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
	mov	x22, #31765                     ; =0x7c15
	movk	x22, #32586, lsl #16
	movk	x22, #31161, lsl #32
	movk	x22, #40503, lsl #48
	eor	x8, x2, x22
	str	x8, [sp, #288]
	strb	wzr, [sp, #296]
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB33_11
; %bb.1:                                ; %bb1.i.i.i
	stp	xzr, x21, [x0]
	cbz	x21, LBB33_5
; %bb.2:                                ; %bb5.i.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
	movi.2d	v0, #0000000000000000
LBB33_3:                                ; %bb5.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	q0, q0, [x9]
	stp	q0, q0, [x9, #32]
	stp	q0, q0, [x9, #64]
	stp	q0, q0, [x9, #96]
	stp	q0, q0, [x9, #128]
	stp	q0, q0, [x9, #160]
	stp	q0, q0, [x9, #192]
	stp	q0, q0, [x9, #224]
	str	xzr, [x9, #256]
	add	x9, x9, #272
	cmp	x21, x8
	b.ne	LBB33_3
; %bb.4:                                ; %bb4.bb7_crit_edge.i.i.i
	str	x21, [x0]
LBB33_5:                                ; %"wf_std.collections.hash_map.hash_map_new$instance$0e108827ecbbe374.exit"
	stp	x0, xzr, [sp, #272]
	stp	x19, xzr, [sp, #240]
	stp	xzr, xzr, [sp, #256]
	cbz	x20, LBB33_9
; %bb.6:                                ; %bb2.lr.ph
Lloh164:
	adrp	x8, lCPI33_0@PAGE
Lloh165:
	ldr	q0, [x8, lCPI33_0@PAGEOFF]
	str	q0, [sp, #224]                  ; 16-byte Folded Spill
	add	x23, sp, #576
Lloh166:
	adrp	x8, lCPI33_1@PAGE
Lloh167:
	ldr	q0, [x8, lCPI33_1@PAGEOFF]
	str	q0, [sp, #208]                  ; 16-byte Folded Spill
	mov	w21, #1                         ; =0x1
Lloh168:
	adrp	x8, lCPI33_2@PAGE
Lloh169:
	ldr	q0, [x8, lCPI33_2@PAGEOFF]
	str	q0, [sp, #192]                  ; 16-byte Folded Spill
Lloh170:
	adrp	x8, lCPI33_3@PAGE
Lloh171:
	ldr	q0, [x8, lCPI33_3@PAGEOFF]
	str	q0, [sp, #176]                  ; 16-byte Folded Spill
Lloh172:
	adrp	x8, lCPI33_4@PAGE
Lloh173:
	ldr	q0, [x8, lCPI33_4@PAGEOFF]
	str	q0, [sp, #160]                  ; 16-byte Folded Spill
Lloh174:
	adrp	x8, lCPI33_5@PAGE
Lloh175:
	ldr	q0, [x8, lCPI33_5@PAGEOFF]
	str	q0, [sp, #144]                  ; 16-byte Folded Spill
Lloh176:
	adrp	x8, lCPI33_6@PAGE
Lloh177:
	ldr	q0, [x8, lCPI33_6@PAGEOFF]
	str	q0, [sp, #128]                  ; 16-byte Folded Spill
Lloh178:
	adrp	x8, lCPI33_7@PAGE
Lloh179:
	ldr	q0, [x8, lCPI33_7@PAGEOFF]
	str	q0, [sp, #112]                  ; 16-byte Folded Spill
Lloh180:
	adrp	x8, lCPI33_8@PAGE
Lloh181:
	ldr	q0, [x8, lCPI33_8@PAGEOFF]
	str	q0, [sp, #96]                   ; 16-byte Folded Spill
Lloh182:
	adrp	x8, lCPI33_9@PAGE
Lloh183:
	ldr	q0, [x8, lCPI33_9@PAGEOFF]
	str	q0, [sp, #80]                   ; 16-byte Folded Spill
Lloh184:
	adrp	x8, lCPI33_10@PAGE
Lloh185:
	ldr	q0, [x8, lCPI33_10@PAGEOFF]
	str	q0, [sp, #64]                   ; 16-byte Folded Spill
Lloh186:
	adrp	x8, lCPI33_11@PAGE
Lloh187:
	ldr	q0, [x8, lCPI33_11@PAGEOFF]
	str	q0, [sp, #48]                   ; 16-byte Folded Spill
Lloh188:
	adrp	x8, lCPI33_12@PAGE
Lloh189:
	ldr	q0, [x8, lCPI33_12@PAGEOFF]
	str	q0, [sp, #32]                   ; 16-byte Folded Spill
Lloh190:
	adrp	x8, lCPI33_13@PAGE
Lloh191:
	ldr	q0, [x8, lCPI33_13@PAGEOFF]
	str	q0, [sp, #16]                   ; 16-byte Folded Spill
Lloh192:
	adrp	x8, lCPI33_14@PAGE
Lloh193:
	ldr	q0, [x8, lCPI33_14@PAGEOFF]
	str	q0, [sp]                        ; 16-byte Folded Spill
LBB33_7:                                ; %bb2
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v0, x19
	add	x8, x19, #31
	ldr	q1, [sp, #224]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #8]
	ldr	q1, [sp, #208]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #24]
	ldr	q1, [sp, #192]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #40]
	ldr	q1, [sp, #176]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #56]
	ldr	q1, [sp, #160]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #72]
	ldr	q1, [sp, #144]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #88]
	ldr	q1, [sp, #128]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #104]
	ldr	q1, [sp, #112]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #120]
	ldr	q1, [sp, #96]                   ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #136]
	ldr	q1, [sp, #80]                   ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #152]
	ldr	q1, [sp, #64]                   ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #168]
	ldr	q1, [sp, #48]                   ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #184]
	ldr	q1, [sp, #32]                   ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #200]
	ldr	q1, [sp, #16]                   ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x23, #216]
	ldr	q1, [sp]                        ; 16-byte Folded Reload
	add.2d	v0, v0, v1
	stur	q0, [x23, #232]
	str	x19, [sp, #576]
	str	x8, [sp, #824]
	add	x0, sp, #304
	add	x1, sp, #272
	add	x3, sp, #576
	add	x4, sp, #288
	mov	x2, x21
	bl	_wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65
	add	x0, sp, #304
	add	x1, sp, #240
	bl	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027
	add	x19, x19, #1
	add	x21, x21, #2
	subs	x20, x20, #1
	b.ne	LBB33_7
; %bb.8:                                ; %bb4.loopexit
	ldp	x9, x8, [sp, #272]
	ldr	x21, [x9]
	b	LBB33_10
LBB33_9:
	mov	x8, #0                          ; =0x0
LBB33_10:                               ; %bb4
	add	x19, x8, x21, lsl #32
	add	x0, sp, #272
	add	x1, sp, #240
	bl	_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71
	ldp	x8, x9, [sp, #240]
	ldp	x10, x11, [sp, #256]
	eor	x8, x8, x8, lsr #30
	mov	x12, #58809                     ; =0xe5b9
	movk	x12, #7396, lsl #16
	movk	x12, #18285, lsl #32
	movk	x12, #48984, lsl #48
	mul	x8, x8, x12
	eor	x8, x8, x8, lsr #27
	mov	x13, #4587                      ; =0x11eb
	movk	x13, #4913, lsl #16
	movk	x13, #18875, lsl #32
	movk	x13, #38096, lsl #48
	mul	x8, x8, x13
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x12
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x13
	eor	x12, x9, x8
	mul	x11, x11, x22
	eor	x10, x19, x10
	eor	x10, x10, x11
	eor	x10, x10, x12, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	add	sp, sp, #832
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB33_11:                               ; %window.block.oom.v1.i.i.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh192, Lloh193
	.loh AdrpAdrp	Lloh190, Lloh192
	.loh AdrpLdr	Lloh190, Lloh191
	.loh AdrpAdrp	Lloh188, Lloh190
	.loh AdrpLdr	Lloh188, Lloh189
	.loh AdrpAdrp	Lloh186, Lloh188
	.loh AdrpLdr	Lloh186, Lloh187
	.loh AdrpAdrp	Lloh184, Lloh186
	.loh AdrpLdr	Lloh184, Lloh185
	.loh AdrpAdrp	Lloh182, Lloh184
	.loh AdrpLdr	Lloh182, Lloh183
	.loh AdrpAdrp	Lloh180, Lloh182
	.loh AdrpLdr	Lloh180, Lloh181
	.loh AdrpAdrp	Lloh178, Lloh180
	.loh AdrpLdr	Lloh178, Lloh179
	.loh AdrpAdrp	Lloh176, Lloh178
	.loh AdrpLdr	Lloh176, Lloh177
	.loh AdrpAdrp	Lloh174, Lloh176
	.loh AdrpLdr	Lloh174, Lloh175
	.loh AdrpAdrp	Lloh172, Lloh174
	.loh AdrpLdr	Lloh172, Lloh173
	.loh AdrpAdrp	Lloh170, Lloh172
	.loh AdrpLdr	Lloh170, Lloh171
	.loh AdrpAdrp	Lloh168, Lloh170
	.loh AdrpLdr	Lloh168, Lloh169
	.loh AdrpAdrp	Lloh166, Lloh168
	.loh AdrpLdr	Lloh166, Lloh167
	.loh AdrpAdrp	Lloh164, Lloh166
	.loh AdrpLdr	Lloh164, Lloh165
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_new$instance$a62a753cf2b0b5ca ; -- Begin function wf_std.collections.hash_map.hash_map_new$instance$a62a753cf2b0b5ca
	.p2align	2
_wf_std.collections.hash_map.hash_map_new$instance$a62a753cf2b0b5ca: ; @"wf_std.collections.hash_map.hash_map_new$instance$a62a753cf2b0b5ca"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB34_6
; %bb.1:                                ; %bb1.i.i
	stp	xzr, x19, [x0]
	cbz	x19, LBB34_5
; %bb.2:                                ; %bb5.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
LBB34_3:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x9], #24
	cmp	x19, x8
	b.ne	LBB34_3
; %bb.4:                                ; %bb4.bb7_crit_edge.i.i
	str	x19, [x0]
LBB34_5:                                ; %"wf_std.collections.hash_map.hash_map_new$instance$a62a753cf2b0b5ca.body.exit"
	mov	x1, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB34_6:                                ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_put$instance$c7b22b9ef52855b6 ; -- Begin function wf_std.collections.hash_map.hash_map_put$instance$c7b22b9ef52855b6
	.p2align	2
_wf_std.collections.hash_map.hash_map_put$instance$c7b22b9ef52855b6: ; @"wf_std.collections.hash_map.hash_map_put$instance$c7b22b9ef52855b6"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #112
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 112
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x4
	mov	x21, x1
	mov	x19, x0
	mov	x23, sp
	mov	x0, sp
	bl	_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6
	ldr	w8, [sp]
	cbz	w8, LBB35_5
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB35_11
; %bb.2:                                ; %bb2
	mov	x22, sp
	ldrb	w8, [sp, #4]
	ldur	q0, [sp, #8]
	stur	q0, [x23, #24]
	tbz	w8, #0, LBB35_6
; %bb.3:                                ; %bb4
	ldr	x8, [x21]
	ldr	x8, [x8]
	cmp	x8, #3
	b.lo	LBB35_8
LBB35_4:                                ; %bb6
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	strb	w8, [x19, #4]
	b	LBB35_7
LBB35_5:                                ; %bb1
	stp	xzr, xzr, [x19]
	str	xzr, [x19, #16]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB35_6:                                ; %bb3
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
LBB35_7:                                ; %common.ret
	ldur	q0, [x22, #8]
	stur	q0, [x19, #8]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB35_8:                                ; %bb7
	mov	w9, #1                          ; =0x1
	mov	w10, #3                         ; =0x3
	lsl	x11, x8, #1
	cmp	x8, #2
	csel	x10, x10, x11, eq
	cmp	x8, #0
	csel	x1, x9, x10, eq
	cmp	x1, x8
	b.ls	LBB35_12
; %bb.9:                                ; %"wf_std.collections.hash_map.hash_map_reserve$instance$c7b22b9ef52855b6.exit"
	mov	x0, x21
	mov	x2, x20
	bl	_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6
	cbz	w0, LBB35_12
; %bb.10:                               ; %"wf_std.collections.hash_map.hash_map_reserve$instance$c7b22b9ef52855b6.exit"
	cmp	w0, #1
	b.eq	LBB35_4
LBB35_11:                               ; %invalid.tag.b0
	bl	_abort
LBB35_12:                               ; %bb17
	ldp	x2, x3, [sp, #24]
	mov	x0, x19
	mov	x1, x21
	mov	x4, x20
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
	b	_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd ; -- Begin function wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd
	.p2align	2
_wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd: ; @"wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd"
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cbz	w8, LBB36_3
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB36_4
; %bb.2:                                ; %bb3
	ldp	x9, x8, [x0, #8]
	ldrb	w10, [x0, #4]
	ldr	x11, [x1]
	mov	w12, #131                       ; =0x83
	tst	w10, #0x1
	mov	w10, #1                         ; =0x1
	cinc	x10, x10, ne
	madd	x10, x11, x12, x10
	add	x9, x10, x9
	madd	x8, x9, x12, x8
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
LBB36_3:                                ; %bb2
	ldr	x8, [x1]
	mov	w9, #131                        ; =0x83
	mul	x8, x8, x9
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
LBB36_4:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760 ; -- Begin function wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760
	.p2align	2
_wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760: ; @"wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0]
	ldr	x12, [x0]
	cbz	x12, LBB37_6
; %bb.1:                                ; %bb5.lr.ph
	ldp	x8, x9, [x1, #8]
	ldr	x10, [x1, #24]
	sub	x11, x12, #1
	mov	w13, #24                        ; =0x18
	madd	x12, x12, x13, x0
	mov	w13, #131                       ; =0x83
	mov	x14, #58809                     ; =0xe5b9
	movk	x14, #7396, lsl #16
	movk	x14, #18285, lsl #32
	movk	x14, #48984, lsl #48
	mov	x15, #4587                      ; =0x11eb
	movk	x15, #4913, lsl #16
	movk	x15, #18875, lsl #32
	movk	x15, #38096, lsl #48
	b	LBB37_3
LBB37_2:                                ; %bb6
                                        ;   in Loop: Header=BB37_3 Depth=1
	sub	x11, x11, #1
	sub	x12, x12, #24
	cmn	x11, #1
	b.eq	LBB37_6
LBB37_3:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	str	x11, [x0]
	ldur	w16, [x12, #-8]
	cmp	w16, #2
	b.lo	LBB37_2
; %bb.4:                                ; %bb5
                                        ;   in Loop: Header=BB37_3 Depth=1
	b.ne	LBB37_7
; %bb.5:                                ; %bb7
                                        ;   in Loop: Header=BB37_3 Depth=1
	ldp	x17, x16, [x12]
	madd	x16, x17, x13, x16
	add	x8, x16, x8
	eor	x16, x16, x16, lsr #30
	mul	x16, x16, x14
	eor	x16, x16, x16, lsr #27
	mul	x16, x16, x15
	eor	x9, x9, x16, lsr #31
	eor	x9, x9, x16
	stp	x8, x9, [x1, #8]
	add	x10, x10, #1
	str	x10, [x1, #24]
	b	LBB37_2
LBB37_6:                                ; %bb4
	bl	_free
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB37_7:                                ; %invalid.tag.b3
	bl	_abort
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_new$instance$820b2044b97e0fbd ; -- Begin function wf_std.collections.hash_map.hash_map_new$instance$820b2044b97e0fbd
	.p2align	2
_wf_std.collections.hash_map.hash_map_new$instance$820b2044b97e0fbd: ; @"wf_std.collections.hash_map.hash_map_new$instance$820b2044b97e0fbd"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB38_6
; %bb.1:                                ; %bb1.i.i
	stp	xzr, x19, [x0]
	cbz	x19, LBB38_5
; %bb.2:                                ; %bb5.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
LBB38_3:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x9], #24
	cmp	x19, x8
	b.ne	LBB38_3
; %bb.4:                                ; %bb4.bb7_crit_edge.i.i
	str	x19, [x0]
LBB38_5:                                ; %"wf_std.collections.hash_map.hash_map_new$instance$820b2044b97e0fbd.body.exit"
	mov	x1, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB38_6:                                ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad ; -- Begin function wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad
	.p2align	2
_wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad: ; @"wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #112
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 112
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x4
	mov	x21, x1
	mov	x19, x0
	mov	x23, sp
	mov	x0, sp
	bl	_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad
	ldr	w8, [sp]
	cbz	w8, LBB39_5
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB39_11
; %bb.2:                                ; %bb2
	mov	x22, sp
	ldrb	w8, [sp, #4]
	ldur	q0, [sp, #8]
	stur	q0, [x23, #24]
	tbz	w8, #0, LBB39_6
; %bb.3:                                ; %bb4
	ldr	x8, [x21]
	ldr	x8, [x8]
	cmp	x8, #4, lsl #12                 ; =16384
	b.lo	LBB39_8
LBB39_4:                                ; %bb6
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	strb	w8, [x19, #4]
	b	LBB39_7
LBB39_5:                                ; %bb1
	stp	xzr, xzr, [x19]
	str	xzr, [x19, #16]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB39_6:                                ; %bb3
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
LBB39_7:                                ; %common.ret
	ldur	q0, [x22, #8]
	stur	q0, [x19, #8]
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB39_8:                                ; %bb7
	mov	w9, #8192                       ; =0x2000
	cmp	x8, #2, lsl #12                 ; =8192
	csel	x9, x8, x9, lo
	lsl	x9, x9, #1
	cmp	x8, #0
	csinc	x1, x9, xzr, ne
	cmp	x1, x8
	b.ls	LBB39_12
; %bb.9:                                ; %"wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit"
	mov	x0, x21
	mov	x2, x20
	bl	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	cbz	w0, LBB39_12
; %bb.10:                               ; %"wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.exit"
	cmp	w0, #1
	b.eq	LBB39_4
LBB39_11:                               ; %invalid.tag.b0
	bl	_abort
LBB39_12:                               ; %bb17
	ldp	x2, x3, [sp, #24]
	mov	x0, x19
	mov	x1, x21
	mov	x4, x20
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
	b	_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad ; -- Begin function wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad
	.p2align	2
_wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad: ; @"wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad"
; %bb.0:                                ; %entry
	ldr	x10, [x0, #8]
	cbz	x10, LBB40_11
; %bb.1:                                ; %bb3.i
	ldrb	w8, [x2, #8]
	tbz	w8, #0, LBB40_3
; %bb.2:
	mov	x8, #0                          ; =0x0
	ldr	x11, [x0]
	ldr	x12, [x11]
	cbnz	x12, LBB40_4
	b	LBB40_11
LBB40_3:                                ; %bb3.i.i.i.i
	ldr	x8, [x2]
	ldr	x9, [x1]
	eor	x8, x9, x8
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #31
	ldr	x11, [x0]
	ldr	x12, [x11]
	cbz	x12, LBB40_11
LBB40_4:                                ; %bb2.lr.ph.i.i.i
	mov	x13, #0                         ; =0x0
	udiv	x9, x8, x12
	msub	x14, x9, x12, x8
	sub	x15, x12, x14
	neg	x16, x15
	mov	w17, #24                        ; =0x18
	b	LBB40_6
LBB40_5:                                ; %bb10.i.i.i
                                        ;   in Loop: Header=BB40_6 Depth=1
	add	x13, x13, #1
	cmp	x12, x13
	b.eq	LBB40_11
LBB40_6:                                ; %bb2.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	cmp	x13, x15
	csel	x8, x14, x16, lo
	add	x8, x8, x13
	madd	x3, x8, x17, x11
	ldr	w8, [x3, #16]!
	cmp	w8, #1
	b.eq	LBB40_5
; %bb.7:                                ; %bb2.i.i.i
                                        ;   in Loop: Header=BB40_6 Depth=1
	cmp	w8, #2
	b.ne	LBB40_12
; %bb.8:                                ; %bb3.i3.i.i.i
                                        ;   in Loop: Header=BB40_6 Depth=1
	ldr	x9, [x3, #8]
	ldr	x8, [x1]
	cmp	x9, x8
	b.ne	LBB40_5
; %bb.9:                                ; %bb6.i
	ldr	x2, [x3, #16]
	mov	w8, #1                          ; =0x1
	str	w8, [x3]
	sub	x10, x10, #1
	stp	xzr, xzr, [x3, #8]
	str	x10, [x0, #8]
LBB40_10:                               ; %"wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad.body.exit"
	mov	x0, x8
	mov	x1, x9
	ret
LBB40_11:
	mov	w8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	mov	x0, x8
	mov	x1, x9
	ret
LBB40_12:                               ; %bb2.i.i.i
	mov	x9, x8
	mov	x2, x8
	cbz	w8, LBB40_10
; %bb.13:                               ; %invalid.tag.b0.i.i.i.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50 ; -- Begin function wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50
	.p2align	2
_wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50: ; @"wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50"
; %bb.0:                                ; %entry
	ldrb	w8, [x2, #8]
	tbz	w8, #0, LBB41_2
; %bb.1:
	mov	x8, #0                          ; =0x0
	ldr	x9, [x0]
	ldr	x10, [x9]
	cbnz	x10, LBB41_3
	b	LBB41_9
LBB41_2:                                ; %bb3.i.i
	ldr	x8, [x2]
	ldr	x9, [x1]
	eor	x8, x9, x8
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #31
	ldr	x9, [x0]
	ldr	x10, [x9]
	cbz	x10, LBB41_9
LBB41_3:                                ; %bb2.lr.ph.i
	mov	x11, #0                         ; =0x0
	udiv	x12, x8, x10
	msub	x12, x12, x10, x8
	sub	x13, x10, x12
	neg	x14, x13
	mov	w15, #24                        ; =0x18
	b	LBB41_5
LBB41_4:                                ; %bb12.i
                                        ;   in Loop: Header=BB41_5 Depth=1
	add	x11, x11, #1
	cmp	x10, x11
	b.eq	LBB41_9
LBB41_5:                                ; %bb2.i
                                        ; =>This Inner Loop Header: Depth=1
	cmp	x11, x13
	csel	x8, x12, x14, lo
	add	x8, x8, x11
	madd	x16, x8, x15, x9
	ldr	w8, [x16, #16]!
	cmp	w8, #1
	b.eq	LBB41_4
; %bb.6:                                ; %bb2.i
                                        ;   in Loop: Header=BB41_5 Depth=1
	cmp	w8, #2
	b.ne	LBB41_11
; %bb.7:                                ; %bb6.i
                                        ;   in Loop: Header=BB41_5 Depth=1
	ldr	x8, [x16, #8]
	ldr	x17, [x1]
	cmp	x8, x17
	b.ne	LBB41_4
; %bb.8:                                ; %bb10.i
	mov	w0, #0                          ; =0x0
	ldr	x8, [x16, #16]
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ret
LBB41_9:
	mov	x8, #0                          ; =0x0
LBB41_10:                               ; %"wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50.body.exit"
	mov	w0, #1                          ; =0x1
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ret
LBB41_11:                               ; %bb2.i
	cbz	w8, LBB41_10
; %bb.12:                               ; %invalid.tag.b2.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_rehash$instance$fde7c6722a8b0dad ; -- Begin function wf_std.collections.hash_map.hash_map_rehash$instance$fde7c6722a8b0dad
	.p2align	2
_wf_std.collections.hash_map.hash_map_rehash$instance$fde7c6722a8b0dad: ; @"wf_std.collections.hash_map.hash_map_rehash$instance$fde7c6722a8b0dad"
	.cfi_startproc
; %bb.0:                                ; %entry
	mov	x2, x1
	ldr	x8, [x0]
	ldr	x1, [x8]
	b	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad ; -- Begin function wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad
	.p2align	2
_wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad: ; @"wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad"
	.cfi_startproc
; %bb.0:                                ; %entry
	cmp	x1, #4, lsl #12                 ; =16384
	b.ls	LBB43_2
; %bb.1:
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	ret
LBB43_2:                                ; %bb3.i
	ldr	x8, [x0]
	ldr	x8, [x8]
	cmp	x1, x8
	b.ls	LBB43_4
; %bb.3:                                ; %bb6.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB43_4:
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_capacity$instance$820b2044b97e0fbd ; -- Begin function wf_std.collections.hash_map.hash_map_capacity$instance$820b2044b97e0fbd
	.p2align	2
_wf_std.collections.hash_map.hash_map_capacity$instance$820b2044b97e0fbd: ; @"wf_std.collections.hash_map.hash_map_capacity$instance$820b2044b97e0fbd"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x0, [x8]
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567 ; -- Begin function wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567
	.p2align	2
_wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567: ; @"wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567"
; %bb.0:                                ; %entry
	ldrb	w8, [x2, #8]
	tbz	w8, #0, LBB45_2
; %bb.1:
	mov	x8, #0                          ; =0x0
	ldr	x9, [x0]
	ldr	x10, [x9]
	cbnz	x10, LBB45_3
	b	LBB45_9
LBB45_2:                                ; %bb3.i.i
	ldr	x8, [x2]
	ldr	x9, [x1]
	eor	x8, x9, x8
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #31
	ldr	x9, [x0]
	ldr	x10, [x9]
	cbz	x10, LBB45_9
LBB45_3:                                ; %bb2.lr.ph.i
	mov	x11, #0                         ; =0x0
	udiv	x12, x8, x10
	msub	x12, x12, x10, x8
	sub	x13, x10, x12
	neg	x14, x13
	mov	w15, #24                        ; =0x18
	b	LBB45_5
LBB45_4:                                ; %bb12.i
                                        ;   in Loop: Header=BB45_5 Depth=1
	add	x11, x11, #1
	cmp	x10, x11
	b.eq	LBB45_9
LBB45_5:                                ; %bb2.i
                                        ; =>This Inner Loop Header: Depth=1
	cmp	x11, x13
	csel	x8, x12, x14, lo
	add	x8, x8, x11
	madd	x16, x8, x15, x9
	ldr	w8, [x16, #16]!
	cmp	w8, #1
	b.eq	LBB45_4
; %bb.6:                                ; %bb2.i
                                        ;   in Loop: Header=BB45_5 Depth=1
	cmp	w8, #2
	b.ne	LBB45_11
; %bb.7:                                ; %bb6.i
                                        ;   in Loop: Header=BB45_5 Depth=1
	ldr	x8, [x16, #8]
	ldr	x17, [x1]
	cmp	x8, x17
	b.ne	LBB45_4
; %bb.8:                                ; %bb10.i
	mov	w0, #0                          ; =0x0
	ldr	x8, [x16, #16]
	add	x8, x8, #1
	str	x8, [x16, #16]
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ret
LBB45_9:
	mov	x8, #0                          ; =0x0
LBB45_10:                               ; %"wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567.body.exit"
	mov	w0, #1                          ; =0x1
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ret
LBB45_11:                               ; %bb2.i
	cbz	w8, LBB45_10
; %bb.12:                               ; %invalid.tag.b2.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19 ; -- Begin function wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19
	.p2align	2
_wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19: ; @"wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0]
	ldr	x12, [x0]
	cbz	x12, LBB46_6
; %bb.1:                                ; %bb5.lr.ph
	ldp	x8, x9, [x1, #8]
	ldr	x10, [x1, #24]
	sub	x11, x12, #1
	mov	w13, #24                        ; =0x18
	madd	x12, x12, x13, x0
	mov	w13, #131                       ; =0x83
	mov	x14, #58809                     ; =0xe5b9
	movk	x14, #7396, lsl #16
	movk	x14, #18285, lsl #32
	movk	x14, #48984, lsl #48
	mov	x15, #4587                      ; =0x11eb
	movk	x15, #4913, lsl #16
	movk	x15, #18875, lsl #32
	movk	x15, #38096, lsl #48
	b	LBB46_3
LBB46_2:                                ; %bb6
                                        ;   in Loop: Header=BB46_3 Depth=1
	sub	x11, x11, #1
	sub	x12, x12, #24
	cmn	x11, #1
	b.eq	LBB46_6
LBB46_3:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	str	x11, [x0]
	ldur	w16, [x12, #-8]
	cmp	w16, #2
	b.lo	LBB46_2
; %bb.4:                                ; %bb5
                                        ;   in Loop: Header=BB46_3 Depth=1
	b.ne	LBB46_7
; %bb.5:                                ; %bb7
                                        ;   in Loop: Header=BB46_3 Depth=1
	ldp	x17, x16, [x12]
	madd	x16, x17, x13, x16
	add	x8, x16, x8
	eor	x16, x16, x16, lsr #30
	mul	x16, x16, x14
	eor	x16, x16, x16, lsr #27
	mul	x16, x16, x15
	eor	x9, x9, x16, lsr #31
	eor	x9, x9, x16
	stp	x8, x9, [x1, #8]
	add	x10, x10, #1
	str	x10, [x1, #24]
	b	LBB46_2
LBB46_6:                                ; %bb4
	bl	_free
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB46_7:                                ; %invalid.tag.b3
	bl	_abort
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_new$instance$96033bf6ddb80743 ; -- Begin function wf_std.collections.hash_map.hash_map_new$instance$96033bf6ddb80743
	.p2align	2
_wf_std.collections.hash_map.hash_map_new$instance$96033bf6ddb80743: ; @"wf_std.collections.hash_map.hash_map_new$instance$96033bf6ddb80743"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB47_6
; %bb.1:                                ; %bb1.i.i
	stp	xzr, x19, [x0]
	cbz	x19, LBB47_5
; %bb.2:                                ; %bb5.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
	movi.2d	v0, #0000000000000000
LBB47_3:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	q0, q0, [x9]
	stp	q0, q0, [x9, #32]
	stp	q0, q0, [x9, #64]
	stp	q0, q0, [x9, #96]
	stp	q0, q0, [x9, #128]
	stp	q0, q0, [x9, #160]
	stp	q0, q0, [x9, #192]
	stp	q0, q0, [x9, #224]
	str	xzr, [x9, #256]
	add	x9, x9, #272
	cmp	x19, x8
	b.ne	LBB47_3
; %bb.4:                                ; %bb4.bb7_crit_edge.i.i
	str	x19, [x0]
LBB47_5:                                ; %"wf_std.collections.hash_map.hash_map_new$instance$96033bf6ddb80743.body.exit"
	mov	x1, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB47_6:                                ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07 ; -- Begin function wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07
	.p2align	2
_wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07: ; @"wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #1056
	.cfi_def_cfa_offset 1136
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	mov	x20, x4
	mov	x21, x1
	mov	x19, x0
	ldp	q0, q1, [x3, #192]
	mov	x22, sp
	stp	q0, q1, [sp, #192]
	ldp	q0, q1, [x3, #224]
	stp	q0, q1, [sp, #224]
	ldp	q0, q1, [x3, #128]
	stp	q0, q1, [sp, #128]
	ldp	q0, q1, [x3, #160]
	stp	q0, q1, [sp, #160]
	ldp	q0, q1, [x3, #64]
	stp	q0, q1, [sp, #64]
	ldp	q0, q1, [x3, #96]
	stp	q0, q1, [sp, #96]
	ldp	q0, q1, [x3]
	stp	q0, q1, [sp]
	ldp	q0, q1, [x3, #32]
	stp	q0, q1, [sp, #32]
	add	x0, x22, #256
	mov	x3, sp
	bl	_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07
	ldr	w8, [sp, #256]
	cbz	w8, LBB48_5
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB48_15
; %bb.2:                                ; %bb2
	mov	x23, sp
	ldrb	w24, [sp, #260]
	add	x0, x22, #528
	add	x1, x23, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	tbz	w24, #0, LBB48_6
; %bb.3:                                ; %bb4
	ldr	x8, [x21]
	ldr	x8, [x8]
	cmp	x8, #3
	b.lo	LBB48_9
LBB48_4:                                ; %bb6
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	strb	w8, [x19, #4]
	add	x0, x19, #8
	add	x1, x23, #264
	b	LBB48_7
LBB48_5:                                ; %bb1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #240]
	stp	q0, q0, [x19, #208]
	stp	q0, q0, [x19, #176]
	stp	q0, q0, [x19, #144]
	stp	q0, q0, [x19, #112]
	stp	q0, q0, [x19, #80]
	stp	q0, q0, [x19, #48]
	stp	q0, q0, [x19, #16]
	str	q0, [x19]
	b	LBB48_8
LBB48_6:                                ; %bb3
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19], #8
	add	x1, x23, #264
	mov	x0, x19
LBB48_7:                                ; %common.ret
	mov	w2, #264                        ; =0x108
	bl	_memcpy
LBB48_8:                                ; %common.ret
	add	sp, sp, #1056
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
LBB48_9:                                ; %bb7
	cbz	x8, LBB48_12
; %bb.10:                               ; %bb7
	cmp	x8, #2
	b.ne	LBB48_16
; %bb.11:                               ; %bb3.i.i.fold.split
	mov	w1, #3                          ; =0x3
	cmp	x1, x8
	b.hi	LBB48_13
	b	LBB48_17
LBB48_12:
	mov	w1, #1                          ; =0x1
	cmp	x1, x8
	b.ls	LBB48_17
LBB48_13:                               ; %"wf_std.collections.hash_map.hash_map_reserve$instance$8d5197e2f00c3b07.exit"
	mov	x0, x21
	mov	x2, x20
	bl	_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07
	str	w0, [sp, #792]
	strb	w1, [sp, #796]
	strb	w2, [sp, #797]
	cbz	w0, LBB48_18
; %bb.14:                               ; %"wf_std.collections.hash_map.hash_map_reserve$instance$8d5197e2f00c3b07.exit"
	cmp	w0, #1
	b.eq	LBB48_4
LBB48_15:                               ; %invalid.tag.b0
	bl	_abort
LBB48_16:                               ; %bb8
	lsl	x1, x8, #1
	cmp	x1, x8
	b.hi	LBB48_13
LBB48_17:                               ; %"wf_std.collections.hash_map.hash_map_reserve$instance$8d5197e2f00c3b07.exit.thread"
	str	wzr, [sp, #792]
	strh	wzr, [sp, #796]
LBB48_18:                               ; %bb17
	add	x3, x22, #800
	ldr	x2, [sp, #528]
	mov	x8, sp
	add	x8, x8, #536
	ldp	q0, q1, [x8, #192]
	stp	q0, q1, [x3, #192]
	ldp	q0, q1, [x8, #224]
	stp	q0, q1, [x3, #224]
	ldp	q0, q1, [x8, #128]
	stp	q0, q1, [x3, #128]
	ldp	q0, q1, [x8, #160]
	stp	q0, q1, [x3, #160]
	ldp	q0, q1, [x8, #64]
	stp	q0, q1, [x3, #64]
	ldp	q0, q1, [x8, #96]
	stp	q0, q1, [x3, #96]
	ldp	q0, q1, [x8]
	stp	q0, q1, [x3]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x3, #32]
	mov	x0, x19
	mov	x1, x21
	mov	x4, x20
	bl	_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07
	b	LBB48_8
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_map_cost_library_policy_result$instance$4250cb78d3f44027 ; -- Begin function wf_map_cost_library_policy_result$instance$4250cb78d3f44027
	.p2align	2
_wf_map_cost_library_policy_result$instance$4250cb78d3f44027: ; @"wf_map_cost_library_policy_result$instance$4250cb78d3f44027"
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cbz	w8, LBB49_3
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB49_4
; %bb.2:                                ; %bb3
	ldrb	w9, [x0, #4]
	ldr	x10, [x1]
	mov	w8, #131                        ; =0x83
	tst	w9, #0x1
	mov	w9, #1                          ; =0x1
	cinc	x9, x9, ne
	madd	x9, x10, x8, x9
	ldp	x11, x10, [x0, #8]
	madd	x10, x11, x8, x10
	ldr	x11, [x0, #24]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #32]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #40]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #48]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #56]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #64]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #72]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #80]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #88]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #96]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #104]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #112]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #120]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #128]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #136]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #144]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #152]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #160]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #168]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #176]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #184]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #192]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #200]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #208]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #216]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #224]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #232]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #240]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #248]
	madd	x10, x10, x8, x11
	ldr	x11, [x0, #256]
	madd	x10, x10, x8, x11
	add	x9, x10, x9
	ldr	x10, [x0, #264]
	madd	x8, x9, x8, x10
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
LBB49_3:                                ; %bb2
	ldr	x8, [x1]
	mov	w9, #131                        ; =0x83
	mul	x8, x8, x9
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
LBB49_4:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146 ; -- Begin function wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146
	.p2align	2
_wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146: ; @"wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0]
	ldr	x11, [x0]
	cbz	x11, LBB50_6
; %bb.1:                                ; %bb5.lr.ph
	ldp	x8, x9, [x1, #8]
	sub	x10, x11, #1
	mov	w12, #272                       ; =0x110
	madd	x12, x11, x12, x0
	ldr	x11, [x1, #24]
	sub	x12, x12, #120
	mov	w13, #131                       ; =0x83
	mov	x14, #58809                     ; =0xe5b9
	movk	x14, #7396, lsl #16
	movk	x14, #18285, lsl #32
	movk	x14, #48984, lsl #48
	mov	x15, #4587                      ; =0x11eb
	movk	x15, #4913, lsl #16
	movk	x15, #18875, lsl #32
	movk	x15, #38096, lsl #48
	b	LBB50_3
LBB50_2:                                ; %bb6
                                        ;   in Loop: Header=BB50_3 Depth=1
	sub	x10, x10, #1
	sub	x12, x12, #272
	cmn	x10, #1
	b.eq	LBB50_6
LBB50_3:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	str	x10, [x0]
	ldur	w16, [x12, #-136]
	cmp	w16, #2
	b.lo	LBB50_2
; %bb.4:                                ; %bb5
                                        ;   in Loop: Header=BB50_3 Depth=1
	b.ne	LBB50_7
; %bb.5:                                ; %bb7
                                        ;   in Loop: Header=BB50_3 Depth=1
	ldp	x17, x16, [x12, #-128]
	madd	x16, x17, x13, x16
	ldur	x17, [x12, #-112]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-104]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-96]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-88]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-80]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-72]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-64]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-56]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-48]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-40]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-32]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-24]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-16]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-8]
	madd	x16, x16, x13, x17
	ldr	x17, [x12]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #8]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #16]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #24]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #32]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #40]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #48]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #56]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #64]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #72]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #80]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #88]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #96]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #104]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #112]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #120]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #128]
	madd	x16, x16, x13, x17
	add	x8, x16, x8
	eor	x16, x16, x16, lsr #30
	mul	x16, x16, x14
	eor	x16, x16, x16, lsr #27
	mul	x16, x16, x15
	eor	x9, x9, x16, lsr #31
	eor	x9, x9, x16
	stp	x8, x9, [x1, #8]
	add	x11, x11, #1
	str	x11, [x1, #24]
	b	LBB50_2
LBB50_6:                                ; %bb4
	bl	_free
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB50_7:                                ; %invalid.tag.b3
	bl	_abort
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_new$instance$0e108827ecbbe374 ; -- Begin function wf_std.collections.hash_map.hash_map_new$instance$0e108827ecbbe374
	.p2align	2
_wf_std.collections.hash_map.hash_map_new$instance$0e108827ecbbe374: ; @"wf_std.collections.hash_map.hash_map_new$instance$0e108827ecbbe374"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB51_6
; %bb.1:                                ; %bb1.i.i
	stp	xzr, x19, [x0]
	cbz	x19, LBB51_5
; %bb.2:                                ; %bb5.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
	movi.2d	v0, #0000000000000000
LBB51_3:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	q0, q0, [x9]
	stp	q0, q0, [x9, #32]
	stp	q0, q0, [x9, #64]
	stp	q0, q0, [x9, #96]
	stp	q0, q0, [x9, #128]
	stp	q0, q0, [x9, #160]
	stp	q0, q0, [x9, #192]
	stp	q0, q0, [x9, #224]
	str	xzr, [x9, #256]
	add	x9, x9, #272
	cmp	x19, x8
	b.ne	LBB51_3
; %bb.4:                                ; %bb4.bb7_crit_edge.i.i
	str	x19, [x0]
LBB51_5:                                ; %"wf_std.collections.hash_map.hash_map_new$instance$0e108827ecbbe374.body.exit"
	mov	x1, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB51_6:                                ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65 ; -- Begin function wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65
	.p2align	2
_wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65: ; @"wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #1056
	.cfi_def_cfa_offset 1136
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	mov	x20, x4
	mov	x21, x1
	mov	x19, x0
	ldp	q0, q1, [x3, #192]
	mov	x22, sp
	stp	q0, q1, [sp, #192]
	ldp	q0, q1, [x3, #224]
	stp	q0, q1, [sp, #224]
	ldp	q0, q1, [x3, #128]
	stp	q0, q1, [sp, #128]
	ldp	q0, q1, [x3, #160]
	stp	q0, q1, [sp, #160]
	ldp	q0, q1, [x3, #64]
	stp	q0, q1, [sp, #64]
	ldp	q0, q1, [x3, #96]
	stp	q0, q1, [sp, #96]
	ldp	q0, q1, [x3]
	stp	q0, q1, [sp]
	ldp	q0, q1, [x3, #32]
	stp	q0, q1, [sp, #32]
	add	x0, x22, #256
	mov	x3, sp
	bl	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
	ldr	w8, [sp, #256]
	cbz	w8, LBB52_5
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.ne	LBB52_12
; %bb.2:                                ; %bb2
	mov	x23, sp
	ldrb	w24, [sp, #260]
	add	x0, x22, #528
	add	x1, x23, #264
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	tbz	w24, #0, LBB52_6
; %bb.3:                                ; %bb4
	ldr	x8, [x21]
	ldr	x8, [x8]
	cmp	x8, #4, lsl #12                 ; =16384
	b.lo	LBB52_9
LBB52_4:                                ; %bb6
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	strb	w8, [x19, #4]
	add	x0, x19, #8
	add	x1, x23, #264
	b	LBB52_7
LBB52_5:                                ; %bb1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #240]
	stp	q0, q0, [x19, #208]
	stp	q0, q0, [x19, #176]
	stp	q0, q0, [x19, #144]
	stp	q0, q0, [x19, #112]
	stp	q0, q0, [x19, #80]
	stp	q0, q0, [x19, #48]
	stp	q0, q0, [x19, #16]
	str	q0, [x19]
	b	LBB52_8
LBB52_6:                                ; %bb3
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19], #8
	add	x1, x23, #264
	mov	x0, x19
LBB52_7:                                ; %common.ret
	mov	w2, #264                        ; =0x108
	bl	_memcpy
LBB52_8:                                ; %common.ret
	add	sp, sp, #1056
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
LBB52_9:                                ; %bb7
	mov	w9, #8192                       ; =0x2000
	cmp	x8, #2, lsl #12                 ; =8192
	csel	x9, x8, x9, lo
	lsl	x9, x9, #1
	cmp	x8, #0
	csinc	x1, x9, xzr, ne
	cmp	x1, x8
	b.ls	LBB52_13
; %bb.10:                               ; %"wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit"
	mov	x0, x21
	mov	x2, x20
	bl	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	str	w0, [sp, #792]
	strb	w1, [sp, #796]
	strb	w2, [sp, #797]
	cbz	w0, LBB52_14
; %bb.11:                               ; %"wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit"
	cmp	w0, #1
	b.eq	LBB52_4
LBB52_12:                               ; %invalid.tag.b0
	bl	_abort
LBB52_13:                               ; %"wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65.exit.thread"
	str	wzr, [sp, #792]
	strh	wzr, [sp, #796]
LBB52_14:                               ; %bb17
	add	x3, x22, #800
	ldr	x2, [sp, #528]
	mov	x8, sp
	add	x8, x8, #536
	ldp	q0, q1, [x8, #192]
	stp	q0, q1, [x3, #192]
	ldp	q0, q1, [x8, #224]
	stp	q0, q1, [x3, #224]
	ldp	q0, q1, [x8, #128]
	stp	q0, q1, [x3, #128]
	ldp	q0, q1, [x8, #160]
	stp	q0, q1, [x3, #160]
	ldp	q0, q1, [x8, #64]
	stp	q0, q1, [x3, #64]
	ldp	q0, q1, [x8, #96]
	stp	q0, q1, [x3, #96]
	ldp	q0, q1, [x8]
	stp	q0, q1, [x3]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x3, #32]
	mov	x0, x19
	mov	x1, x21
	mov	x4, x20
	bl	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
	b	LBB52_8
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65 ; -- Begin function wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65
	.p2align	2
_wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65: ; @"wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65"
; %bb.0:                                ; %entry
	ldr	x8, [x1, #8]
	cbz	x8, LBB53_11
; %bb.1:                                ; %bb3
	ldrb	w9, [x3, #8]
	tbz	w9, #0, LBB53_3
; %bb.2:
	mov	x9, #0                          ; =0x0
	ldr	x11, [x1]
	ldr	x12, [x11]
	cbnz	x12, LBB53_4
	b	LBB53_11
LBB53_3:                                ; %bb3.i.i.i
	ldr	x9, [x3]
	ldr	x10, [x2]
	eor	x9, x10, x9
	eor	x9, x9, x9, lsr #30
	mov	x10, #58809                     ; =0xe5b9
	movk	x10, #7396, lsl #16
	movk	x10, #18285, lsl #32
	movk	x10, #48984, lsl #48
	mul	x9, x9, x10
	eor	x9, x9, x9, lsr #27
	mov	x10, #4587                      ; =0x11eb
	movk	x10, #4913, lsl #16
	movk	x10, #18875, lsl #32
	movk	x10, #38096, lsl #48
	mul	x9, x9, x10
	eor	x9, x9, x9, lsr #31
	ldr	x11, [x1]
	ldr	x12, [x11]
	cbz	x12, LBB53_11
LBB53_4:                                ; %bb2.lr.ph.i.i
	mov	x13, #0                         ; =0x0
	udiv	x10, x9, x12
	msub	x14, x10, x12, x9
	sub	x15, x12, x14
	neg	x16, x15
	mov	w17, #272                       ; =0x110
	b	LBB53_6
LBB53_5:                                ; %bb10.i.i
                                        ;   in Loop: Header=BB53_6 Depth=1
	add	x13, x13, #1
	cmp	x12, x13
	b.eq	LBB53_11
LBB53_6:                                ; %bb2.i.i
                                        ; =>This Inner Loop Header: Depth=1
	cmp	x13, x15
	csel	x9, x14, x16, lo
	add	x9, x9, x13
	madd	x9, x9, x17, x11
	ldr	w10, [x9, #16]!
	cmp	w10, #1
	b.eq	LBB53_5
; %bb.7:                                ; %bb2.i.i
                                        ;   in Loop: Header=BB53_6 Depth=1
	cmp	w10, #2
	b.ne	LBB53_10
; %bb.8:                                ; %bb3.i3.i.i
                                        ;   in Loop: Header=BB53_6 Depth=1
	ldr	x10, [x9, #8]
	ldr	x3, [x2]
	cmp	x10, x3
	b.ne	LBB53_5
; %bb.9:                                ; %bb6
	mov	w11, #1                         ; =0x1
	str	w11, [x9]
	sub	x8, x8, #1
	ldp	q0, q1, [x9, #16]
	ldp	q2, q3, [x9, #48]
	ldp	q4, q5, [x9, #80]
	ldp	q6, q7, [x9, #112]
	ldp	q16, q17, [x9, #144]
	ldp	q18, q19, [x9, #176]
	ldp	q20, q21, [x9, #208]
	ldp	q22, q23, [x9, #240]
	movi.2d	v24, #0000000000000000
	stur	q24, [x9, #24]
	stur	q24, [x9, #40]
	stur	q24, [x9, #56]
	stur	q24, [x9, #72]
	stur	q24, [x9, #88]
	stur	q24, [x9, #104]
	stur	q24, [x9, #120]
	stur	q24, [x9, #136]
	stur	q24, [x9, #152]
	stur	q24, [x9, #168]
	stur	q24, [x9, #184]
	stur	q24, [x9, #200]
	stur	q24, [x9, #216]
	stur	q24, [x9, #232]
	stur	q24, [x9, #248]
	stur	q24, [x9, #8]
	str	xzr, [x9, #264]
	str	x8, [x1, #8]
	stp	xzr, x10, [x0]
	str	w11, [x0]
	stp	q0, q1, [x0, #16]
	stp	q2, q3, [x0, #48]
	stp	q4, q5, [x0, #80]
	stp	q6, q7, [x0, #112]
	stp	q16, q17, [x0, #144]
	stp	q18, q19, [x0, #176]
	stp	q20, q21, [x0, #208]
	stp	q22, q23, [x0, #240]
	ret
LBB53_10:                               ; %bb2.i.i
	cbnz	w10, LBB53_12
LBB53_11:                               ; %bb2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0, #240]
	stp	q0, q0, [x0, #208]
	stp	q0, q0, [x0, #176]
	stp	q0, q0, [x0, #144]
	stp	q0, q0, [x0, #112]
	stp	q0, q0, [x0, #80]
	stp	q0, q0, [x0, #48]
	stp	q0, q0, [x0, #16]
	str	q0, [x0]
	ret
LBB53_12:                               ; %invalid.tag.b0.i.i.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe ; -- Begin function wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe
	.p2align	2
_wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe: ; @"wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe"
; %bb.0:                                ; %entry
	ldrb	w8, [x2, #8]
	tbz	w8, #0, LBB54_2
; %bb.1:
	mov	x8, #0                          ; =0x0
	ldr	x9, [x0]
	ldr	x10, [x9]
	cbnz	x10, LBB54_3
	b	LBB54_9
LBB54_2:                                ; %bb3.i.i
	ldr	x8, [x2]
	ldr	x9, [x1]
	eor	x8, x9, x8
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #31
	ldr	x9, [x0]
	ldr	x10, [x9]
	cbz	x10, LBB54_9
LBB54_3:                                ; %bb2.lr.ph.i
	mov	x11, #0                         ; =0x0
	udiv	x12, x8, x10
	msub	x12, x12, x10, x8
	sub	x13, x10, x12
	neg	x14, x13
	mov	w15, #272                       ; =0x110
	b	LBB54_5
LBB54_4:                                ; %bb12.i
                                        ;   in Loop: Header=BB54_5 Depth=1
	add	x11, x11, #1
	cmp	x10, x11
	b.eq	LBB54_9
LBB54_5:                                ; %bb2.i
                                        ; =>This Inner Loop Header: Depth=1
	cmp	x11, x13
	csel	x8, x12, x14, lo
	add	x8, x8, x11
	madd	x16, x8, x15, x9
	ldr	w8, [x16, #16]!
	cmp	w8, #1
	b.eq	LBB54_4
; %bb.6:                                ; %bb2.i
                                        ;   in Loop: Header=BB54_5 Depth=1
	cmp	w8, #2
	b.ne	LBB54_11
; %bb.7:                                ; %bb6.i
                                        ;   in Loop: Header=BB54_5 Depth=1
	ldr	x8, [x16, #8]
	ldr	x17, [x1]
	cmp	x8, x17
	b.ne	LBB54_4
; %bb.8:                                ; %bb10.i
	mov	w0, #0                          ; =0x0
	ldr	x8, [x16, #16]
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ret
LBB54_9:
	mov	x8, #0                          ; =0x0
LBB54_10:                               ; %"wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe.body.exit"
	mov	w0, #1                          ; =0x1
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ret
LBB54_11:                               ; %bb2.i
	cbz	w8, LBB54_10
; %bb.12:                               ; %invalid.tag.b2.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_rehash$instance$28da32efc51c2b65 ; -- Begin function wf_std.collections.hash_map.hash_map_rehash$instance$28da32efc51c2b65
	.p2align	2
_wf_std.collections.hash_map.hash_map_rehash$instance$28da32efc51c2b65: ; @"wf_std.collections.hash_map.hash_map_rehash$instance$28da32efc51c2b65"
	.cfi_startproc
; %bb.0:                                ; %entry
	mov	x2, x1
	ldr	x8, [x0]
	ldr	x1, [x8]
	b	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65 ; -- Begin function wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65
	.p2align	2
_wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65: ; @"wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65"
	.cfi_startproc
; %bb.0:                                ; %entry
	cmp	x1, #4, lsl #12                 ; =16384
	b.ls	LBB56_2
; %bb.1:
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	ret
LBB56_2:                                ; %bb3.i
	ldr	x8, [x0]
	ldr	x8, [x8]
	cmp	x1, x8
	b.ls	LBB56_4
; %bb.3:                                ; %bb6.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB56_4:
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_capacity$instance$0e108827ecbbe374 ; -- Begin function wf_std.collections.hash_map.hash_map_capacity$instance$0e108827ecbbe374
	.p2align	2
_wf_std.collections.hash_map.hash_map_capacity$instance$0e108827ecbbe374: ; @"wf_std.collections.hash_map.hash_map_capacity$instance$0e108827ecbbe374"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x0, [x8]
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49 ; -- Begin function wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49
	.p2align	2
_wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49: ; @"wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49"
; %bb.0:                                ; %entry
	ldrb	w8, [x2, #8]
	tbz	w8, #0, LBB58_2
; %bb.1:
	mov	x8, #0                          ; =0x0
	ldr	x9, [x0]
	ldr	x10, [x9]
	cbnz	x10, LBB58_3
	b	LBB58_9
LBB58_2:                                ; %bb3.i.i
	ldr	x8, [x2]
	ldr	x9, [x1]
	eor	x8, x9, x8
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #31
	ldr	x9, [x0]
	ldr	x10, [x9]
	cbz	x10, LBB58_9
LBB58_3:                                ; %bb2.lr.ph.i
	mov	x11, #0                         ; =0x0
	udiv	x12, x8, x10
	msub	x12, x12, x10, x8
	sub	x13, x10, x12
	neg	x14, x13
	mov	w15, #272                       ; =0x110
	b	LBB58_5
LBB58_4:                                ; %bb12.i
                                        ;   in Loop: Header=BB58_5 Depth=1
	add	x11, x11, #1
	cmp	x10, x11
	b.eq	LBB58_9
LBB58_5:                                ; %bb2.i
                                        ; =>This Inner Loop Header: Depth=1
	cmp	x11, x13
	csel	x8, x12, x14, lo
	add	x8, x8, x11
	madd	x16, x8, x15, x9
	ldr	w8, [x16, #16]!
	cmp	w8, #1
	b.eq	LBB58_4
; %bb.6:                                ; %bb2.i
                                        ;   in Loop: Header=BB58_5 Depth=1
	cmp	w8, #2
	b.ne	LBB58_11
; %bb.7:                                ; %bb6.i
                                        ;   in Loop: Header=BB58_5 Depth=1
	ldr	x8, [x16, #8]
	ldr	x17, [x1]
	cmp	x8, x17
	b.ne	LBB58_4
; %bb.8:                                ; %bb10.i
	mov	w0, #0                          ; =0x0
	ldr	x8, [x16, #16]
	add	x8, x8, #1
	str	x8, [x16, #16]
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ret
LBB58_9:
	mov	x8, #0                          ; =0x0
LBB58_10:                               ; %"wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49.body.exit"
	mov	w0, #1                          ; =0x1
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ret
LBB58_11:                               ; %bb2.i
	cbz	w8, LBB58_10
; %bb.12:                               ; %invalid.tag.b2.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71 ; -- Begin function wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71
	.p2align	2
_wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71: ; @"wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0]
	ldr	x11, [x0]
	cbz	x11, LBB59_6
; %bb.1:                                ; %bb5.lr.ph
	ldp	x8, x9, [x1, #8]
	sub	x10, x11, #1
	mov	w12, #272                       ; =0x110
	madd	x12, x11, x12, x0
	ldr	x11, [x1, #24]
	sub	x12, x12, #120
	mov	w13, #131                       ; =0x83
	mov	x14, #58809                     ; =0xe5b9
	movk	x14, #7396, lsl #16
	movk	x14, #18285, lsl #32
	movk	x14, #48984, lsl #48
	mov	x15, #4587                      ; =0x11eb
	movk	x15, #4913, lsl #16
	movk	x15, #18875, lsl #32
	movk	x15, #38096, lsl #48
	b	LBB59_3
LBB59_2:                                ; %bb6
                                        ;   in Loop: Header=BB59_3 Depth=1
	sub	x10, x10, #1
	sub	x12, x12, #272
	cmn	x10, #1
	b.eq	LBB59_6
LBB59_3:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	str	x10, [x0]
	ldur	w16, [x12, #-136]
	cmp	w16, #2
	b.lo	LBB59_2
; %bb.4:                                ; %bb5
                                        ;   in Loop: Header=BB59_3 Depth=1
	b.ne	LBB59_7
; %bb.5:                                ; %bb7
                                        ;   in Loop: Header=BB59_3 Depth=1
	ldp	x17, x16, [x12, #-128]
	madd	x16, x17, x13, x16
	ldur	x17, [x12, #-112]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-104]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-96]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-88]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-80]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-72]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-64]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-56]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-48]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-40]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-32]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-24]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-16]
	madd	x16, x16, x13, x17
	ldur	x17, [x12, #-8]
	madd	x16, x16, x13, x17
	ldr	x17, [x12]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #8]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #16]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #24]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #32]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #40]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #48]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #56]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #64]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #72]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #80]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #88]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #96]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #104]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #112]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #120]
	madd	x16, x16, x13, x17
	ldr	x17, [x12, #128]
	madd	x16, x16, x13, x17
	add	x8, x16, x8
	eor	x16, x16, x16, lsr #30
	mul	x16, x16, x14
	eor	x16, x16, x16, lsr #27
	mul	x16, x16, x15
	eor	x9, x9, x16, lsr #31
	eor	x9, x9, x16
	stp	x8, x9, [x1, #8]
	add	x11, x11, #1
	str	x11, [x1, #24]
	b	LBB59_2
LBB59_6:                                ; %bb4
	bl	_free
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB59_7:                                ; %invalid.tag.b3
	bl	_abort
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_len$instance$820b2044b97e0fbd ; -- Begin function wf_std.collections.hash_map.hash_map_len$instance$820b2044b97e0fbd
	.p2align	2
_wf_std.collections.hash_map.hash_map_len$instance$820b2044b97e0fbd: ; @"wf_std.collections.hash_map.hash_map_len$instance$820b2044b97e0fbd"
; %bb.0:                                ; %entry
	ldr	x0, [x0, #8]
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_len$instance$0e108827ecbbe374 ; -- Begin function wf_std.collections.hash_map.hash_map_len$instance$0e108827ecbbe374
	.p2align	2
_wf_std.collections.hash_map.hash_map_len$instance$0e108827ecbbe374: ; @"wf_std.collections.hash_map.hash_map_len$instance$0e108827ecbbe374"
; %bb.0:                                ; %entry
	ldr	x0, [x0, #8]
	ret
                                        ; -- End function
	.globl	_wf_box_slots_new$instance$b45b69d9d0c6bbd0 ; -- Begin function wf_box_slots_new$instance$b45b69d9d0c6bbd0
	.p2align	2
_wf_box_slots_new$instance$b45b69d9d0c6bbd0: ; @"wf_box_slots_new$instance$b45b69d9d0c6bbd0"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB62_2
; %bb.1:                                ; %window.block.ready.v1
	stp	xzr, x19, [x0]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB62_2:                                ; %window.block.oom.v1
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca ; -- Begin function wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca
	.p2align	2
_wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca: ; @"wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x1
	ldr	x20, [x0]
	ldr	x8, [x20, #8]
	cmp	x8, x1
	b.hs	LBB63_4
; %bb.1:                                ; %bb2
	mov	x21, x0
	ldr	x23, [x20]
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	madd	x0, x19, x8, x9
	bl	_malloc
	cbz	x0, LBB63_8
; %bb.2:                                ; %"wf_grow$instance$b45b69d9d0c6bbd0.exit"
	mov	x22, x0
	stp	x23, x19, [x0], #16
	add	x8, x23, x23, lsl #1
	lsl	x2, x8, #3
	add	x1, x20, #16
	bl	_memmove
	mov	x0, x20
	bl	_free
	str	x22, [x21]
	mov	x20, x22
	cmp	x23, x19
	b.lo	LBB63_5
LBB63_3:                                ; %bb7
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB63_4:                                ; %entry.bb1_crit_edge
	ldr	x23, [x20]
	cmp	x23, x19
	b.hs	LBB63_3
LBB63_5:                                ; %bb5.preheader
	mov	w8, #24                         ; =0x18
	madd	x8, x23, x8, x20
	add	x8, x8, #24
LBB63_6:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x8, #-8]
	add	x23, x23, #1
	stp	xzr, xzr, [x8], #24
	cmp	x19, x23
	b.ne	LBB63_6
; %bb.7:                                ; %bb4.bb7_crit_edge
	str	x23, [x20]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB63_8:                                ; %window.block.oom.v2.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6 ; -- Begin function wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6
	.p2align	2
_wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6: ; @"wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6"
; %bb.0:                                ; %entry
	ldrb	w8, [x4, #8]
	tbz	w8, #0, LBB64_9
; %bb.1:
	mov	x10, #0                         ; =0x0
	ldr	x8, [x1]
	ldr	x9, [x8]
	cbz	x9, LBB64_10
LBB64_2:                                ; %bb2.lr.ph
	mov	x11, #0                         ; =0x0
	udiv	x12, x10, x9
	msub	x12, x12, x9, x10
	sub	x13, x9, x12
	neg	x14, x13
	mov	w15, #24                        ; =0x18
	mov	x10, x9
	b	LBB64_5
LBB64_3:                                ; %bb8
                                        ;   in Loop: Header=BB64_5 Depth=1
	cmp	x10, x9
	csel	x10, x5, x10, eq
LBB64_4:                                ; %bb16
                                        ;   in Loop: Header=BB64_5 Depth=1
	add	x11, x11, #1
	cmp	x9, x11
	b.eq	LBB64_11
LBB64_5:                                ; %bb2
                                        ; =>This Inner Loop Header: Depth=1
	cmp	x11, x13
	csel	x17, x12, x14, lo
	add	x5, x17, x11
	madd	x16, x5, x15, x8
	ldr	w4, [x16, #16]!
	cmp	w4, #1
	b.eq	LBB64_3
; %bb.6:                                ; %bb2
                                        ;   in Loop: Header=BB64_5 Depth=1
	cmp	w4, #2
	b.ne	LBB64_17
; %bb.7:                                ; %bb3.i13
                                        ;   in Loop: Header=BB64_5 Depth=1
	ldr	x17, [x16, #8]
	cmp	x17, x2
	b.ne	LBB64_4
; %bb.8:                                ; %"wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3.exit"
	ldr	x8, [x16, #16]
	mov	w9, #2                          ; =0x2
	str	w9, [x16]
	str	x3, [x16, #16]
	mov	w9, #1                          ; =0x1
	stp	x9, x2, [x0]
	str	x8, [x0, #16]
	ret
LBB64_9:                                ; %bb3.i
	ldr	x8, [x4]
	eor	x8, x8, x2
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x10, x8, x8, lsr #31
	ldr	x8, [x1]
	ldr	x9, [x8]
	cbnz	x9, LBB64_2
LBB64_10:
	mov	x10, #0                         ; =0x0
LBB64_11:                               ; %bb4
	cmp	x10, x9
	b.hs	LBB64_19
LBB64_12:                               ; %bb18
	ldr	x9, [x1, #8]
	cmp	x9, #2
	b.hi	LBB64_19
; %bb.13:                               ; %bb21
	add	x9, x9, #1
	str	x9, [x1, #8]
	mov	w9, #24                         ; =0x18
	madd	x9, x10, x9, x8
	ldr	w8, [x9, #16]
	ldur	q0, [x9, #24]
	mov	w10, #2                         ; =0x2
	str	w10, [x9, #16]
	stp	x2, x3, [x9, #24]
	cbz	w8, LBB64_20
; %bb.14:                               ; %bb21
	cmp	w8, #1
	b.eq	LBB64_20
; %bb.15:                               ; %bb21
	cmp	w8, #2
	b.ne	LBB64_21
; %bb.16:                               ; %bb3.i28
	mov	w8, #1                          ; =0x1
	str	x8, [x0]
	stur	q0, [x0, #8]
	ret
LBB64_17:                               ; %bb2
	cbnz	w4, LBB64_21
; %bb.18:                               ; %bb7
	add	x11, x17, x11
	cmp	x10, x9
	csel	x10, x11, x10, eq
	cmp	x10, x9
	b.lo	LBB64_12
LBB64_19:                               ; %bb17
	stp	xzr, x2, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	strb	w8, [x0, #4]
	str	x3, [x0, #16]
	ret
LBB64_20:                               ; %bb2.i31
	stp	xzr, xzr, [x0]
	str	xzr, [x0, #16]
	ret
LBB64_21:                               ; %invalid.tag.b0.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_reserve$instance$c7b22b9ef52855b6 ; -- Begin function wf_std.collections.hash_map.hash_map_reserve$instance$c7b22b9ef52855b6
	.p2align	2
_wf_std.collections.hash_map.hash_map_reserve$instance$c7b22b9ef52855b6: ; @"wf_std.collections.hash_map.hash_map_reserve$instance$c7b22b9ef52855b6"
	.cfi_startproc
; %bb.0:                                ; %entry
	cmp	x1, #3
	b.ls	LBB65_2
; %bb.1:
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	ret
LBB65_2:                                ; %bb3.i
	ldr	x8, [x0]
	ldr	x8, [x8]
	cmp	x1, x8
	b.ls	LBB65_4
; %bb.3:                                ; %bb6.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB65_4:
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd ; -- Begin function wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd
	.p2align	2
_wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd: ; @"wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x1
	ldr	x20, [x0]
	ldr	x8, [x20, #8]
	cmp	x8, x1
	b.hs	LBB66_4
; %bb.1:                                ; %bb2
	mov	x21, x0
	ldr	x23, [x20]
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	madd	x0, x19, x8, x9
	bl	_malloc
	cbz	x0, LBB66_8
; %bb.2:                                ; %"wf_grow$instance$b45b69d9d0c6bbd0.exit"
	mov	x22, x0
	stp	x23, x19, [x0], #16
	add	x8, x23, x23, lsl #1
	lsl	x2, x8, #3
	add	x1, x20, #16
	bl	_memmove
	mov	x0, x20
	bl	_free
	str	x22, [x21]
	mov	x20, x22
	cmp	x23, x19
	b.lo	LBB66_5
LBB66_3:                                ; %bb7
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB66_4:                                ; %entry.bb1_crit_edge
	ldr	x23, [x20]
	cmp	x23, x19
	b.hs	LBB66_3
LBB66_5:                                ; %bb5.preheader
	mov	w8, #24                         ; =0x18
	madd	x8, x23, x8, x20
	add	x8, x8, #24
LBB66_6:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x8, #-8]
	add	x23, x23, #1
	stp	xzr, xzr, [x8], #24
	cmp	x19, x23
	b.ne	LBB66_6
; %bb.7:                                ; %bb4.bb7_crit_edge
	str	x23, [x20]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB66_8:                                ; %window.block.oom.v2.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad ; -- Begin function wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad
	.p2align	2
_wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad: ; @"wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad"
; %bb.0:                                ; %entry
	ldrb	w8, [x4, #8]
	tbz	w8, #0, LBB67_9
; %bb.1:
	mov	x10, #0                         ; =0x0
	ldr	x8, [x1]
	ldr	x9, [x8]
	cbz	x9, LBB67_10
LBB67_2:                                ; %bb2.lr.ph
	mov	x11, #0                         ; =0x0
	udiv	x12, x10, x9
	msub	x12, x12, x9, x10
	sub	x13, x9, x12
	neg	x14, x13
	mov	w15, #24                        ; =0x18
	mov	x10, x9
	b	LBB67_5
LBB67_3:                                ; %bb8
                                        ;   in Loop: Header=BB67_5 Depth=1
	cmp	x10, x9
	csel	x10, x5, x10, eq
LBB67_4:                                ; %bb16
                                        ;   in Loop: Header=BB67_5 Depth=1
	add	x11, x11, #1
	cmp	x9, x11
	b.eq	LBB67_11
LBB67_5:                                ; %bb2
                                        ; =>This Inner Loop Header: Depth=1
	cmp	x11, x13
	csel	x17, x12, x14, lo
	add	x5, x17, x11
	madd	x16, x5, x15, x8
	ldr	w4, [x16, #16]!
	cmp	w4, #1
	b.eq	LBB67_3
; %bb.6:                                ; %bb2
                                        ;   in Loop: Header=BB67_5 Depth=1
	cmp	w4, #2
	b.ne	LBB67_17
; %bb.7:                                ; %bb3.i13
                                        ;   in Loop: Header=BB67_5 Depth=1
	ldr	x17, [x16, #8]
	cmp	x17, x2
	b.ne	LBB67_4
; %bb.8:                                ; %"wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3.exit"
	ldr	x8, [x16, #16]
	mov	w9, #2                          ; =0x2
	str	w9, [x16]
	str	x3, [x16, #16]
	mov	w9, #1                          ; =0x1
	stp	x9, x2, [x0]
	str	x8, [x0, #16]
	ret
LBB67_9:                                ; %bb3.i
	ldr	x8, [x4]
	eor	x8, x8, x2
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x10, x8, x8, lsr #31
	ldr	x8, [x1]
	ldr	x9, [x8]
	cbnz	x9, LBB67_2
LBB67_10:
	mov	x10, #0                         ; =0x0
LBB67_11:                               ; %bb4
	cmp	x10, x9
	b.hs	LBB67_19
LBB67_12:                               ; %bb18
	ldr	x9, [x1, #8]
	lsr	x11, x9, #14
	cbnz	x11, LBB67_19
; %bb.13:                               ; %bb21
	add	x9, x9, #1
	str	x9, [x1, #8]
	mov	w9, #24                         ; =0x18
	madd	x9, x10, x9, x8
	ldr	w8, [x9, #16]
	ldur	q0, [x9, #24]
	mov	w10, #2                         ; =0x2
	str	w10, [x9, #16]
	stp	x2, x3, [x9, #24]
	cbz	w8, LBB67_20
; %bb.14:                               ; %bb21
	cmp	w8, #1
	b.eq	LBB67_20
; %bb.15:                               ; %bb21
	cmp	w8, #2
	b.ne	LBB67_21
; %bb.16:                               ; %bb3.i28
	mov	w8, #1                          ; =0x1
	str	x8, [x0]
	stur	q0, [x0, #8]
	ret
LBB67_17:                               ; %bb2
	cbnz	w4, LBB67_21
; %bb.18:                               ; %bb7
	add	x11, x17, x11
	cmp	x10, x9
	csel	x10, x11, x10, eq
	cmp	x10, x9
	b.lo	LBB67_12
LBB67_19:                               ; %bb17
	stp	xzr, x2, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	strb	w8, [x0, #4]
	str	x3, [x0, #16]
	ret
LBB67_20:                               ; %bb2.i31
	stp	xzr, xzr, [x0]
	str	xzr, [x0, #16]
	ret
LBB67_21:                               ; %invalid.tag.b0.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad ; -- Begin function wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad
	.p2align	2
_wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad: ; @"wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad"
; %bb.0:                                ; %entry
	ldrb	w8, [x2, #8]
	tbz	w8, #0, LBB68_2
; %bb.1:
	mov	x8, #0                          ; =0x0
	ldr	x9, [x0]
	ldr	x10, [x9]
	cbnz	x10, LBB68_3
	b	LBB68_9
LBB68_2:                                ; %bb3.i.i
	ldr	x8, [x2]
	ldr	x9, [x1]
	eor	x8, x9, x8
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #31
	ldr	x9, [x0]
	ldr	x10, [x9]
	cbz	x10, LBB68_9
LBB68_3:                                ; %bb2.lr.ph.i
	mov	x11, #0                         ; =0x0
	udiv	x12, x8, x10
	msub	x12, x12, x10, x8
	sub	x13, x10, x12
	neg	x14, x13
	mov	w15, #24                        ; =0x18
	b	LBB68_5
LBB68_4:                                ; %bb10.i
                                        ;   in Loop: Header=BB68_5 Depth=1
	add	x11, x11, #1
	cmp	x10, x11
	b.eq	LBB68_9
LBB68_5:                                ; %bb2.i
                                        ; =>This Inner Loop Header: Depth=1
	cmp	x11, x13
	csel	x16, x12, x14, lo
	add	x8, x16, x11
	madd	x17, x8, x15, x9
	ldr	w8, [x17, #16]!
	cmp	w8, #1
	b.eq	LBB68_4
; %bb.6:                                ; %bb2.i
                                        ;   in Loop: Header=BB68_5 Depth=1
	cmp	w8, #2
	b.ne	LBB68_10
; %bb.7:                                ; %bb3.i3.i
                                        ;   in Loop: Header=BB68_5 Depth=1
	ldr	x8, [x17, #8]
	ldr	x17, [x1]
	cmp	x8, x17
	b.ne	LBB68_4
; %bb.8:                                ; %"bb3.i3.i.wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad.body.exit.loopexit_crit_edge"
	mov	w0, #0                          ; =0x0
	add	x8, x16, x11
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ret
LBB68_9:
	mov	x8, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ret
LBB68_10:                               ; %bb2.i
	cbnz	w8, LBB68_12
; %bb.11:
	mov	w0, #1                          ; =0x1
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ret
LBB68_12:                               ; %invalid.tag.b0.i.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad ; -- Begin function wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad
	.p2align	2
_wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad: ; @"wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	cmp	x1, #4, lsl #12                 ; =16384
	b.hi	LBB69_2
; %bb.1:                                ; %bb3.i
	ldr	x19, [x0]
	ldr	x8, [x19]
	cmp	x1, x8
	b.hs	LBB69_3
LBB69_2:
	mov	w0, #1                          ; =0x1
	b	LBB69_35
LBB69_3:                                ; %bb6.i
	cbz	x1, LBB69_34
; %bb.4:                                ; %bb9.i
	mov	x22, x0
	ldr	x20, [x2]
	ldrb	w21, [x2, #8]
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	mov	x23, x1
	madd	x0, x1, x8, x9
	bl	_malloc
	cbz	x0, LBB69_37
; %bb.5:                                ; %bb1.i.i
	mov	x8, #0                          ; =0x0
	mov	x9, x23
	str	x23, [x0, #8]
	add	x10, x0, #24
LBB69_6:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x10, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x10], #24
	cmp	x9, x8
	b.ne	LBB69_6
; %bb.7:                                ; %bb4.bb7_crit_edge.i.i
	str	x9, [x0]
	str	x0, [x22]
	ldr	x12, [x19]
	cbz	x12, LBB69_33
; %bb.8:                                ; %bb14.lr.ph.i
	tbz	w21, #0, LBB69_21
; %bb.9:                                ; %bb14.us.i.preheader
	add	x8, x0, #16
	mov	w9, #24                         ; =0x18
	mov	w10, #2                         ; =0x2
	b	LBB69_13
LBB69_10:                               ; %bb25.us.us.i
                                        ;   in Loop: Header=BB69_13 Depth=1
	b.hs	LBB69_36
; %bb.11:                               ; %bb15.us.loopexit.i
                                        ;   in Loop: Header=BB69_13 Depth=1
	str	w10, [x14]
	stp	x12, x11, [x14, #8]
	ldr	x11, [x19]
LBB69_12:                               ; %bb15.us.i
                                        ;   in Loop: Header=BB69_13 Depth=1
	mov	x12, x11
	cbz	x11, LBB69_33
LBB69_13:                               ; %bb14.us.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB69_17 Depth 2
                                        ;       Child Loop BB69_18 Depth 3
	sub	x11, x12, #1
	str	x11, [x19]
	madd	x12, x12, x9, x19
	ldr	w13, [x12, #-8]!
	cmp	w13, #2
	b.lo	LBB69_12
; %bb.14:                               ; %bb14.us.i
                                        ;   in Loop: Header=BB69_13 Depth=1
	b.ne	LBB69_36
; %bb.15:                               ; %bb23.lr.ph.us.i
                                        ;   in Loop: Header=BB69_13 Depth=1
	ldr	x13, [x0]
	cbz	x13, LBB69_20
; %bb.16:                               ;   in Loop: Header=BB69_13 Depth=1
	ldp	x12, x11, [x12, #8]
LBB69_17:                               ; %bb25.us.us.i.preheader
                                        ;   Parent Loop BB69_13 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB69_18 Depth 3
	mov	x15, #0                         ; =0x0
	mov	x14, x8
LBB69_18:                               ; %bb25.us.us.i
                                        ;   Parent Loop BB69_13 Depth=1
                                        ;     Parent Loop BB69_17 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w16, [x14]
	cmp	w16, #2
	b.ne	LBB69_10
; %bb.19:                               ; %bb3.i26.us.us.i
                                        ;   in Loop: Header=BB69_18 Depth=3
	add	x15, x15, #1
	add	x14, x14, #24
	cmp	x13, x15
	b.ne	LBB69_18
	b	LBB69_17
LBB69_20:                               ; %bb23.us.us.i
                                        ; =>This Inner Loop Header: Depth=1
	b	LBB69_20
LBB69_21:
	mov	w8, #24                         ; =0x18
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mov	x10, #4587                      ; =0x11eb
	movk	x10, #4913, lsl #16
	movk	x10, #18875, lsl #32
	movk	x10, #38096, lsl #48
	mov	w11, #2                         ; =0x2
	b	LBB69_25
LBB69_22:                               ; %bb25.i
                                        ;   in Loop: Header=BB69_25 Depth=1
	b.hs	LBB69_36
; %bb.23:                               ; %bb15.loopexit.i
                                        ;   in Loop: Header=BB69_25 Depth=1
	str	w11, [x2]
	stp	x13, x12, [x2, #8]
	ldr	x13, [x19]
LBB69_24:                               ; %bb15.i
                                        ;   in Loop: Header=BB69_25 Depth=1
	mov	x12, x13
	cbz	x13, LBB69_33
LBB69_25:                               ; %bb14.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB69_29 Depth 2
                                        ;       Child Loop BB69_30 Depth 3
	sub	x13, x12, #1
	str	x13, [x19]
	madd	x15, x12, x8, x19
	ldr	w12, [x15, #-8]!
	cmp	w12, #2
	b.lo	LBB69_24
; %bb.26:                               ; %bb14.i
                                        ;   in Loop: Header=BB69_25 Depth=1
	b.ne	LBB69_36
; %bb.27:                               ; %bb23.lr.ph.i
                                        ;   in Loop: Header=BB69_25 Depth=1
	ldr	x14, [x0]
	cbz	x14, LBB69_32
; %bb.28:                               ; %bb23.preheader.i
                                        ;   in Loop: Header=BB69_25 Depth=1
	ldp	x13, x12, [x15, #8]
	eor	x15, x13, x20
	eor	x15, x15, x15, lsr #30
	mul	x15, x15, x9
	eor	x15, x15, x15, lsr #27
	mul	x15, x15, x10
	eor	x15, x15, x15, lsr #31
	udiv	x16, x15, x14
	msub	x15, x16, x14, x15
	sub	x16, x14, x15
	neg	x17, x16
LBB69_29:                               ; %bb25.lr.ph.i
                                        ;   Parent Loop BB69_25 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB69_30 Depth 3
	mov	x1, #0                          ; =0x0
LBB69_30:                               ; %bb25.i
                                        ;   Parent Loop BB69_25 Depth=1
                                        ;     Parent Loop BB69_29 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x1, x16
	csel	x2, x15, x17, lo
	add	x2, x2, x1
	madd	x2, x2, x8, x0
	ldr	w3, [x2, #16]!
	cmp	w3, #2
	b.ne	LBB69_22
; %bb.31:                               ; %bb3.i26.i
                                        ;   in Loop: Header=BB69_30 Depth=3
	add	x1, x1, #1
	cmp	x14, x1
	b.ne	LBB69_30
	b	LBB69_29
LBB69_32:                               ; %bb23.us16.i
                                        ; =>This Inner Loop Header: Depth=1
	b	LBB69_32
LBB69_33:                               ; %bb13.i
	mov	x0, x19
	bl	_free
LBB69_34:                               ; %"wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad.body.exit"
	mov	w0, #0                          ; =0x0
LBB69_35:                               ; %"wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB69_36:                               ; %invalid.tag.b12.i
	bl	_abort
LBB69_37:                               ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_box_slots_new$instance$9eabc50a9cce2251 ; -- Begin function wf_box_slots_new$instance$9eabc50a9cce2251
	.p2align	2
_wf_box_slots_new$instance$9eabc50a9cce2251: ; @"wf_box_slots_new$instance$9eabc50a9cce2251"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	madd	x0, x0, x8, x9
	bl	_malloc
	cbz	x0, LBB70_2
; %bb.1:                                ; %window.block.ready.v1
	stp	xzr, x19, [x0]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB70_2:                                ; %window.block.oom.v1
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743 ; -- Begin function wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743
	.p2align	2
_wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743: ; @"wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x1
	ldr	x20, [x0]
	ldr	x8, [x20, #8]
	cmp	x8, x1
	b.hs	LBB71_4
; %bb.1:                                ; %bb2
	mov	x21, x0
	ldr	x23, [x20]
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	madd	x0, x19, x8, x9
	bl	_malloc
	cbz	x0, LBB71_8
; %bb.2:                                ; %"wf_grow$instance$9eabc50a9cce2251.exit"
	mov	x22, x0
	stp	x23, x19, [x0], #16
	add	x8, x23, x23, lsl #4
	lsl	x2, x8, #4
	add	x1, x20, #16
	bl	_memmove
	mov	x0, x20
	bl	_free
	str	x22, [x21]
	mov	x20, x22
	cmp	x23, x19
	b.lo	LBB71_5
LBB71_3:                                ; %bb7
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB71_4:                                ; %entry.bb1_crit_edge
	ldr	x23, [x20]
	cmp	x23, x19
	b.hs	LBB71_3
LBB71_5:                                ; %bb5.preheader
	mov	w8, #272                        ; =0x110
	madd	x8, x23, x8, x20
	add	x8, x8, #24
	movi.2d	v0, #0000000000000000
LBB71_6:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x8, #-8]
	add	x23, x23, #1
	stp	q0, q0, [x8]
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8, #64]
	stp	q0, q0, [x8, #96]
	stp	q0, q0, [x8, #128]
	stp	q0, q0, [x8, #160]
	stp	q0, q0, [x8, #192]
	stp	q0, q0, [x8, #224]
	str	xzr, [x8, #256]
	add	x8, x8, #272
	cmp	x19, x23
	b.ne	LBB71_6
; %bb.7:                                ; %bb4.bb7_crit_edge
	str	x23, [x20]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB71_8:                                ; %window.block.oom.v2.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07 ; -- Begin function wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07
	.p2align	2
_wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07: ; @"wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07"
; %bb.0:                                ; %entry
	sub	sp, sp, #288
	stp	x28, x27, [sp, #256]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #272]            ; 16-byte Folded Spill
	mov	x8, x2
	ldp	q0, q1, [x3, #192]
	stp	q0, q1, [sp, #192]
	ldp	q0, q1, [x3, #224]
	stp	q0, q1, [sp, #224]
	ldp	q0, q1, [x3, #128]
	stp	q0, q1, [sp, #128]
	ldp	q0, q1, [x3, #160]
	stp	q0, q1, [sp, #160]
	ldp	q0, q1, [x3, #64]
	stp	q0, q1, [sp, #64]
	ldp	q0, q1, [x3, #96]
	stp	q0, q1, [sp, #96]
	ldp	q0, q1, [x3]
	stp	q0, q1, [sp]
	ldp	q0, q1, [x3, #32]
	stp	q0, q1, [sp, #32]
	ldrb	w9, [x4, #8]
	tbz	w9, #0, LBB72_9
; %bb.1:
	mov	x12, #0                         ; =0x0
	ldr	x11, [x1]
	ldr	x9, [x11]
	cbz	x9, LBB72_10
LBB72_2:                                ; %bb2.lr.ph
	mov	x10, #0                         ; =0x0
	udiv	x13, x12, x9
	msub	x12, x13, x9, x12
	sub	x13, x9, x12
	neg	x14, x13
	mov	w15, #272                       ; =0x110
	mov	x2, x9
	b	LBB72_5
LBB72_3:                                ; %bb8
                                        ;   in Loop: Header=BB72_5 Depth=1
	cmp	x2, x9
	csel	x2, x4, x2, eq
LBB72_4:                                ; %bb16
                                        ;   in Loop: Header=BB72_5 Depth=1
	add	x10, x10, #1
	cmp	x9, x10
	b.eq	LBB72_11
LBB72_5:                                ; %bb2
                                        ; =>This Inner Loop Header: Depth=1
	cmp	x10, x13
	csel	x16, x12, x14, lo
	add	x4, x16, x10
	madd	x17, x4, x15, x11
	ldr	w3, [x17, #16]!
	cmp	w3, #1
	b.eq	LBB72_3
; %bb.6:                                ; %bb2
                                        ;   in Loop: Header=BB72_5 Depth=1
	cmp	w3, #2
	b.ne	LBB72_15
; %bb.7:                                ; %bb3.i13
                                        ;   in Loop: Header=BB72_5 Depth=1
	ldr	x17, [x17, #8]
	cmp	x17, x8
	b.ne	LBB72_4
; %bb.8:                                ; %bb6
	add	x2, x16, x10
	b	LBB72_14
LBB72_9:                                ; %bb3.i
	ldr	x9, [x4]
	eor	x9, x9, x8
	eor	x9, x9, x9, lsr #30
	mov	x10, #58809                     ; =0xe5b9
	movk	x10, #7396, lsl #16
	movk	x10, #18285, lsl #32
	movk	x10, #48984, lsl #48
	mul	x9, x9, x10
	eor	x9, x9, x9, lsr #27
	mov	x10, #4587                      ; =0x11eb
	movk	x10, #4913, lsl #16
	movk	x10, #18875, lsl #32
	movk	x10, #38096, lsl #48
	mul	x9, x9, x10
	eor	x12, x9, x9, lsr #31
	ldr	x11, [x1]
	ldr	x9, [x11]
	cbnz	x9, LBB72_2
LBB72_10:
	mov	x2, #0                          ; =0x0
LBB72_11:                               ; %bb4
	cmp	x2, x9
	b.hs	LBB72_17
LBB72_12:                               ; %bb18
	ldr	x9, [x1, #8]
	cmp	x9, #2
	b.hi	LBB72_17
; %bb.13:                               ; %bb21
	add	x9, x9, #1
	str	x9, [x1, #8]
LBB72_14:                               ; %common.ret
	mov	x4, sp
	mov	x3, x8
	bl	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
	ldp	x29, x30, [sp, #272]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #256]            ; 16-byte Folded Reload
	add	sp, sp, #288
	ret
LBB72_15:                               ; %bb2
	cbnz	w3, LBB72_18
; %bb.16:                               ; %bb7
	add	x10, x16, x10
	cmp	x2, x9
	csel	x2, x10, x2, eq
	cmp	x2, x9
	b.lo	LBB72_12
LBB72_17:                               ; %bb17
	stp	xzr, x8, [x0]
	mov	w9, #1                          ; =0x1
	str	w9, [x0]
	strb	w9, [x0, #4]
	ldp	q0, q1, [sp]
	stp	q0, q1, [x0, #16]
	ldp	q0, q1, [sp, #32]
	stp	q0, q1, [x0, #48]
	ldp	q0, q1, [sp, #64]
	stp	q0, q1, [x0, #80]
	ldp	q0, q1, [sp, #96]
	stp	q0, q1, [x0, #112]
	ldp	q0, q1, [sp, #128]
	stp	q0, q1, [x0, #144]
	ldp	q0, q1, [sp, #160]
	stp	q0, q1, [x0, #176]
	ldp	q0, q1, [sp, #192]
	stp	q0, q1, [x0, #208]
	ldp	q0, q1, [sp, #224]
	stp	q0, q1, [x0, #240]
	ldp	x29, x30, [sp, #272]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #256]            ; 16-byte Folded Reload
	add	sp, sp, #288
	ret
LBB72_18:                               ; %invalid.tag.b0.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_reserve$instance$8d5197e2f00c3b07 ; -- Begin function wf_std.collections.hash_map.hash_map_reserve$instance$8d5197e2f00c3b07
	.p2align	2
_wf_std.collections.hash_map.hash_map_reserve$instance$8d5197e2f00c3b07: ; @"wf_std.collections.hash_map.hash_map_reserve$instance$8d5197e2f00c3b07"
	.cfi_startproc
; %bb.0:                                ; %entry
	cmp	x1, #3
	b.ls	LBB73_2
; %bb.1:
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	ret
LBB73_2:                                ; %bb3.i
	ldr	x8, [x0]
	ldr	x8, [x8]
	cmp	x1, x8
	b.ls	LBB73_4
; %bb.3:                                ; %bb6.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB73_4:
	mov	w2, #0                          ; =0x0
	mov	w1, #0                          ; =0x0
	mov	w0, #0                          ; =0x0
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374 ; -- Begin function wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374
	.p2align	2
_wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374: ; @"wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x1
	ldr	x20, [x0]
	ldr	x8, [x20, #8]
	cmp	x8, x1
	b.hs	LBB74_4
; %bb.1:                                ; %bb2
	mov	x21, x0
	ldr	x23, [x20]
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	madd	x0, x19, x8, x9
	bl	_malloc
	cbz	x0, LBB74_8
; %bb.2:                                ; %"wf_grow$instance$9eabc50a9cce2251.exit"
	mov	x22, x0
	stp	x23, x19, [x0], #16
	add	x8, x23, x23, lsl #4
	lsl	x2, x8, #4
	add	x1, x20, #16
	bl	_memmove
	mov	x0, x20
	bl	_free
	str	x22, [x21]
	mov	x20, x22
	cmp	x23, x19
	b.lo	LBB74_5
LBB74_3:                                ; %bb7
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB74_4:                                ; %entry.bb1_crit_edge
	ldr	x23, [x20]
	cmp	x23, x19
	b.hs	LBB74_3
LBB74_5:                                ; %bb5.preheader
	mov	w8, #272                        ; =0x110
	madd	x8, x23, x8, x20
	add	x8, x8, #24
	movi.2d	v0, #0000000000000000
LBB74_6:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x8, #-8]
	add	x23, x23, #1
	stp	q0, q0, [x8]
	stp	q0, q0, [x8, #32]
	stp	q0, q0, [x8, #64]
	stp	q0, q0, [x8, #96]
	stp	q0, q0, [x8, #128]
	stp	q0, q0, [x8, #160]
	stp	q0, q0, [x8, #192]
	stp	q0, q0, [x8, #224]
	str	xzr, [x8, #256]
	add	x8, x8, #272
	cmp	x19, x23
	b.ne	LBB74_6
; %bb.7:                                ; %bb4.bb7_crit_edge
	str	x23, [x20]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB74_8:                                ; %window.block.oom.v2.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65 ; -- Begin function wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65
	.p2align	2
_wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65: ; @"wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65"
; %bb.0:                                ; %entry
	sub	sp, sp, #288
	stp	x28, x27, [sp, #256]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #272]            ; 16-byte Folded Spill
	mov	x8, x2
	ldp	q0, q1, [x3, #192]
	stp	q0, q1, [sp, #192]
	ldp	q0, q1, [x3, #224]
	stp	q0, q1, [sp, #224]
	ldp	q0, q1, [x3, #128]
	stp	q0, q1, [sp, #128]
	ldp	q0, q1, [x3, #160]
	stp	q0, q1, [sp, #160]
	ldp	q0, q1, [x3, #64]
	stp	q0, q1, [sp, #64]
	ldp	q0, q1, [x3, #96]
	stp	q0, q1, [sp, #96]
	ldp	q0, q1, [x3]
	stp	q0, q1, [sp]
	ldp	q0, q1, [x3, #32]
	stp	q0, q1, [sp, #32]
	ldrb	w9, [x4, #8]
	tbz	w9, #0, LBB75_9
; %bb.1:
	mov	x12, #0                         ; =0x0
	ldr	x11, [x1]
	ldr	x9, [x11]
	cbz	x9, LBB75_10
LBB75_2:                                ; %bb2.lr.ph
	mov	x10, #0                         ; =0x0
	udiv	x13, x12, x9
	msub	x12, x13, x9, x12
	sub	x13, x9, x12
	neg	x14, x13
	mov	w15, #272                       ; =0x110
	mov	x2, x9
	b	LBB75_5
LBB75_3:                                ; %bb8
                                        ;   in Loop: Header=BB75_5 Depth=1
	cmp	x2, x9
	csel	x2, x4, x2, eq
LBB75_4:                                ; %bb16
                                        ;   in Loop: Header=BB75_5 Depth=1
	add	x10, x10, #1
	cmp	x9, x10
	b.eq	LBB75_11
LBB75_5:                                ; %bb2
                                        ; =>This Inner Loop Header: Depth=1
	cmp	x10, x13
	csel	x16, x12, x14, lo
	add	x4, x16, x10
	madd	x17, x4, x15, x11
	ldr	w3, [x17, #16]!
	cmp	w3, #1
	b.eq	LBB75_3
; %bb.6:                                ; %bb2
                                        ;   in Loop: Header=BB75_5 Depth=1
	cmp	w3, #2
	b.ne	LBB75_15
; %bb.7:                                ; %bb3.i13
                                        ;   in Loop: Header=BB75_5 Depth=1
	ldr	x17, [x17, #8]
	cmp	x17, x8
	b.ne	LBB75_4
; %bb.8:                                ; %bb6
	add	x2, x16, x10
	b	LBB75_14
LBB75_9:                                ; %bb3.i
	ldr	x9, [x4]
	eor	x9, x9, x8
	eor	x9, x9, x9, lsr #30
	mov	x10, #58809                     ; =0xe5b9
	movk	x10, #7396, lsl #16
	movk	x10, #18285, lsl #32
	movk	x10, #48984, lsl #48
	mul	x9, x9, x10
	eor	x9, x9, x9, lsr #27
	mov	x10, #4587                      ; =0x11eb
	movk	x10, #4913, lsl #16
	movk	x10, #18875, lsl #32
	movk	x10, #38096, lsl #48
	mul	x9, x9, x10
	eor	x12, x9, x9, lsr #31
	ldr	x11, [x1]
	ldr	x9, [x11]
	cbnz	x9, LBB75_2
LBB75_10:
	mov	x2, #0                          ; =0x0
LBB75_11:                               ; %bb4
	cmp	x2, x9
	b.hs	LBB75_17
LBB75_12:                               ; %bb18
	ldr	x9, [x1, #8]
	lsr	x10, x9, #14
	cbnz	x10, LBB75_17
; %bb.13:                               ; %bb21
	add	x9, x9, #1
	str	x9, [x1, #8]
LBB75_14:                               ; %common.ret
	mov	x4, sp
	mov	x3, x8
	bl	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
	ldp	x29, x30, [sp, #272]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #256]            ; 16-byte Folded Reload
	add	sp, sp, #288
	ret
LBB75_15:                               ; %bb2
	cbnz	w3, LBB75_18
; %bb.16:                               ; %bb7
	add	x10, x16, x10
	cmp	x2, x9
	csel	x2, x10, x2, eq
	cmp	x2, x9
	b.lo	LBB75_12
LBB75_17:                               ; %bb17
	stp	xzr, x8, [x0]
	mov	w9, #1                          ; =0x1
	str	w9, [x0]
	strb	w9, [x0, #4]
	ldp	q0, q1, [sp]
	stp	q0, q1, [x0, #16]
	ldp	q0, q1, [sp, #32]
	stp	q0, q1, [x0, #48]
	ldp	q0, q1, [sp, #64]
	stp	q0, q1, [x0, #80]
	ldp	q0, q1, [sp, #96]
	stp	q0, q1, [x0, #112]
	ldp	q0, q1, [sp, #128]
	stp	q0, q1, [x0, #144]
	ldp	q0, q1, [sp, #160]
	stp	q0, q1, [x0, #176]
	ldp	q0, q1, [sp, #192]
	stp	q0, q1, [x0, #208]
	ldp	q0, q1, [sp, #224]
	stp	q0, q1, [x0, #240]
	ldp	x29, x30, [sp, #272]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #256]            ; 16-byte Folded Reload
	add	sp, sp, #288
	ret
LBB75_18:                               ; %invalid.tag.b0.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65 ; -- Begin function wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65
	.p2align	2
_wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65: ; @"wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65"
; %bb.0:                                ; %entry
	ldrb	w8, [x2, #8]
	tbz	w8, #0, LBB76_2
; %bb.1:
	mov	x8, #0                          ; =0x0
	ldr	x9, [x0]
	ldr	x10, [x9]
	cbnz	x10, LBB76_3
	b	LBB76_9
LBB76_2:                                ; %bb3.i.i
	ldr	x8, [x2]
	ldr	x9, [x1]
	eor	x8, x9, x8
	eor	x8, x8, x8, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #31
	ldr	x9, [x0]
	ldr	x10, [x9]
	cbz	x10, LBB76_9
LBB76_3:                                ; %bb2.lr.ph.i
	mov	x11, #0                         ; =0x0
	udiv	x12, x8, x10
	msub	x12, x12, x10, x8
	sub	x13, x10, x12
	neg	x14, x13
	mov	w15, #272                       ; =0x110
	b	LBB76_5
LBB76_4:                                ; %bb10.i
                                        ;   in Loop: Header=BB76_5 Depth=1
	add	x11, x11, #1
	cmp	x10, x11
	b.eq	LBB76_9
LBB76_5:                                ; %bb2.i
                                        ; =>This Inner Loop Header: Depth=1
	cmp	x11, x13
	csel	x16, x12, x14, lo
	add	x8, x16, x11
	madd	x17, x8, x15, x9
	ldr	w8, [x17, #16]!
	cmp	w8, #1
	b.eq	LBB76_4
; %bb.6:                                ; %bb2.i
                                        ;   in Loop: Header=BB76_5 Depth=1
	cmp	w8, #2
	b.ne	LBB76_10
; %bb.7:                                ; %bb3.i3.i
                                        ;   in Loop: Header=BB76_5 Depth=1
	ldr	x8, [x17, #8]
	ldr	x17, [x1]
	cmp	x8, x17
	b.ne	LBB76_4
; %bb.8:                                ; %"bb3.i3.i.wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65.body.exit.loopexit_crit_edge"
	mov	w0, #0                          ; =0x0
	add	x8, x16, x11
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ret
LBB76_9:
	mov	x8, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ret
LBB76_10:                               ; %bb2.i
	cbnz	w8, LBB76_12
; %bb.11:
	mov	w0, #1                          ; =0x1
	mov	x1, x8
	mov	w2, #0                          ; =0x0
	ret
LBB76_12:                               ; %invalid.tag.b0.i.i
	bl	_abort
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65 ; -- Begin function wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65
	.p2align	2
_wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65: ; @"wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #576
	.cfi_def_cfa_offset 672
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cmp	x1, #4, lsl #12                 ; =16384
	b.hi	LBB77_2
; %bb.1:                                ; %bb3.i
	mov	x19, x0
	ldr	x26, [x0]
	ldr	x20, [x26]
	cmp	x1, x20
	b.hs	LBB77_3
LBB77_2:
	mov	w0, #1                          ; =0x1
	b	LBB77_42
LBB77_3:                                ; %bb6.i
	cbz	x1, LBB77_41
; %bb.4:                                ; %bb9.i
	ldr	x23, [x2]
	ldrb	w8, [x2, #8]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	mov	x22, x1
	madd	x0, x1, x8, x9
	bl	_malloc
	cbz	x0, LBB77_44
; %bb.5:                                ; %bb1.i.i
	mov	x21, x0
	mov	x8, #0                          ; =0x0
	mov	x9, x22
	str	x22, [x0, #8]
	add	x10, x0, #24
	movi.2d	v0, #0000000000000000
LBB77_6:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x10, #-8]
	add	x8, x8, #1
	stp	q0, q0, [x10]
	stp	q0, q0, [x10, #32]
	stp	q0, q0, [x10, #64]
	stp	q0, q0, [x10, #96]
	stp	q0, q0, [x10, #128]
	stp	q0, q0, [x10, #160]
	stp	q0, q0, [x10, #192]
	stp	q0, q0, [x10, #224]
	str	xzr, [x10, #256]
	add	x10, x10, #272
	cmp	x9, x8
	b.ne	LBB77_6
; %bb.7:                                ; %bb4.bb7_crit_edge.i.i
	str	x9, [x21]
	str	x21, [x19]
	cbz	x20, LBB77_40
; %bb.8:                                ; %bb14.lr.ph.i
	add	x27, x21, #16
	mov	w28, #272                       ; =0x110
	mov	w24, #264                       ; =0x108
	add	x25, sp, #32
	str	x26, [sp, #16]                  ; 8-byte Folded Spill
	b	LBB77_11
LBB77_9:                                ; %bb15thread-pre-split.i
                                        ;   in Loop: Header=BB77_11 Depth=1
	ldr	x26, [sp, #16]                  ; 8-byte Folded Reload
	ldr	x9, [x26]
LBB77_10:                               ; %bb15.i
                                        ;   in Loop: Header=BB77_11 Depth=1
	mov	x20, x9
	cbz	x9, LBB77_40
LBB77_11:                               ; %bb14.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB77_30 Depth 2
                                        ;       Child Loop BB77_32 Depth 3
                                        ;     Child Loop BB77_18 Depth 2
                                        ;       Child Loop BB77_20 Depth 3
	sub	x9, x20, #1
	str	x9, [x26]
	madd	x8, x20, x28, x26
	ldr	w10, [x8, #-256]!
	cmp	w10, #2
	b.lo	LBB77_10
; %bb.12:                               ; %bb14.i
                                        ;   in Loop: Header=BB77_11 Depth=1
	b.ne	LBB77_43
; %bb.13:                               ; %bb23.preheader.i
                                        ;   in Loop: Header=BB77_11 Depth=1
	ldr	x9, [x8, #264]
	str	xzr, [sp, #32]
	ldur	q0, [x8, #8]
	stur	q0, [sp, #40]
	ldur	q0, [x8, #24]
	stur	q0, [sp, #56]
	ldur	q0, [x8, #40]
	stur	q0, [sp, #72]
	ldur	q0, [x8, #56]
	stur	q0, [sp, #88]
	ldur	q0, [x8, #72]
	stur	q0, [sp, #104]
	ldur	q0, [x8, #88]
	stur	q0, [sp, #120]
	ldur	q0, [x8, #104]
	stur	q0, [sp, #136]
	ldur	q0, [x8, #120]
	stur	q0, [sp, #152]
	ldur	q0, [x8, #136]
	add	x10, sp, #32
	stur	q0, [x10, #136]
	ldur	q0, [x8, #152]
	stur	q0, [x10, #152]
	ldur	q0, [x8, #168]
	stur	q0, [x10, #168]
	ldur	q0, [x8, #184]
	stur	q0, [x10, #184]
	ldur	q0, [x8, #200]
	stur	q0, [x10, #200]
	ldur	q0, [x8, #216]
	stur	q0, [x10, #216]
	ldur	q0, [x8, #232]
	stur	q0, [x10, #232]
	ldur	q0, [x8, #248]
	stur	q0, [x10, #248]
	str	x9, [sp, #296]
	ldr	x8, [x21]
	ldr	w9, [sp, #28]                   ; 4-byte Folded Reload
	tbz	w9, #0, LBB77_26
; %bb.14:                               ; %bb23.preheader.i.split.us
                                        ;   in Loop: Header=BB77_11 Depth=1
	cbz	x8, LBB77_38
; %bb.15:                               ; %bb23.i.us.preheader
                                        ;   in Loop: Header=BB77_11 Depth=1
	mov	w20, #1                         ; =0x1
	b	LBB77_18
LBB77_16:                               ; %bb27.i.us
                                        ;   in Loop: Header=BB77_18 Depth=2
	mov	x20, x26
	cbz	x26, LBB77_9
LBB77_17:                               ; %bb23.i.usthread-pre-split
                                        ;   in Loop: Header=BB77_18 Depth=2
	ldr	x8, [x21]
LBB77_18:                               ; %bb23.i.us
                                        ;   Parent Loop BB77_11 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB77_20 Depth 3
	cbz	x8, LBB77_17
; %bb.19:                               ; %bb25.i.us.preheader
                                        ;   in Loop: Header=BB77_18 Depth=2
	mov	x2, #0                          ; =0x0
	mov	x9, x27
LBB77_20:                               ; %bb25.i.us
                                        ;   Parent Loop BB77_11 Depth=1
                                        ;     Parent Loop BB77_18 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w10, [x9]
	cmp	w10, #2
	b.ne	LBB77_22
; %bb.21:                               ; %bb3.i25.i.us
                                        ;   in Loop: Header=BB77_20 Depth=3
	add	x9, x9, #272
	add	x2, x2, #1
	cmp	x8, x2
	b.ne	LBB77_20
	b	LBB77_17
LBB77_22:                               ; %bb25.i.us
                                        ;   in Loop: Header=BB77_18 Depth=2
	b.hs	LBB77_43
; %bb.23:                               ; %bb29.i.us
                                        ;   in Loop: Header=BB77_18 Depth=2
	sub	x26, x20, #1
	str	x26, [sp, #32]
	madd	x22, x20, x24, x25
	ldr	x3, [x22, #-256]!
	add	x0, sp, #304
	add	x4, x22, #8
	mov	x1, x19
	bl	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
	ldr	w8, [sp, #304]
	cbz	w8, LBB77_16
; %bb.24:                               ; %bb29.i.us
                                        ;   in Loop: Header=BB77_18 Depth=2
	cmp	w8, #1
	b.ne	LBB77_43
; %bb.25:                               ; %bb33.i.us
                                        ;   in Loop: Header=BB77_18 Depth=2
	add	x8, sp, #304
	add	x1, x8, #8
	mov	x0, x22
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	str	x20, [sp, #32]
	b	LBB77_17
LBB77_26:                               ; %bb23.preheader.i.split
                                        ;   in Loop: Header=BB77_11 Depth=1
	cbz	x8, LBB77_39
; %bb.27:                               ; %bb23.i.preheader
                                        ;   in Loop: Header=BB77_11 Depth=1
	mov	w26, #1                         ; =0x1
	b	LBB77_30
LBB77_28:                               ; %bb27.i
                                        ;   in Loop: Header=BB77_30 Depth=2
	mov	x26, x20
	cbz	x20, LBB77_9
LBB77_29:                               ; %bb23.ithread-pre-split
                                        ;   in Loop: Header=BB77_30 Depth=2
	ldr	x8, [x21]
LBB77_30:                               ; %bb23.i
                                        ;   Parent Loop BB77_11 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB77_32 Depth 3
	cbz	x8, LBB77_29
; %bb.31:                               ; %bb25.lr.ph.i
                                        ;   in Loop: Header=BB77_30 Depth=2
	mov	x9, #0                          ; =0x0
	ldr	x10, [sp, #40]
	eor	x10, x10, x23
	eor	x10, x10, x10, lsr #30
	mov	x11, #58809                     ; =0xe5b9
	movk	x11, #7396, lsl #16
	movk	x11, #18285, lsl #32
	movk	x11, #48984, lsl #48
	mul	x10, x10, x11
	eor	x10, x10, x10, lsr #27
	mov	x11, #4587                      ; =0x11eb
	movk	x11, #4913, lsl #16
	movk	x11, #18875, lsl #32
	movk	x11, #38096, lsl #48
	mul	x10, x10, x11
	eor	x10, x10, x10, lsr #31
	udiv	x11, x10, x8
	msub	x10, x11, x8, x10
	sub	x11, x8, x10
	neg	x13, x11
LBB77_32:                               ; %bb25.i
                                        ;   Parent Loop BB77_11 Depth=1
                                        ;     Parent Loop BB77_30 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x9, x11
	csel	x12, x10, x13, lo
	add	x14, x12, x9
	madd	x14, x14, x28, x21
	ldr	w14, [x14, #16]
	cmp	w14, #2
	b.ne	LBB77_34
; %bb.33:                               ; %bb3.i25.i
                                        ;   in Loop: Header=BB77_32 Depth=3
	add	x9, x9, #1
	cmp	x8, x9
	b.ne	LBB77_32
	b	LBB77_29
LBB77_34:                               ; %bb25.i
                                        ;   in Loop: Header=BB77_30 Depth=2
	b.hs	LBB77_43
; %bb.35:                               ; %bb29.i
                                        ;   in Loop: Header=BB77_30 Depth=2
	sub	x20, x26, #1
	str	x20, [sp, #32]
	madd	x22, x26, x24, x25
	ldr	x3, [x22, #-256]!
	add	x0, sp, #304
	add	x2, x12, x9
	add	x4, x22, #8
	mov	x1, x19
	bl	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
	ldr	w8, [sp, #304]
	cbz	w8, LBB77_28
; %bb.36:                               ; %bb29.i
                                        ;   in Loop: Header=BB77_30 Depth=2
	cmp	w8, #1
	b.ne	LBB77_43
; %bb.37:                               ; %bb33.i
                                        ;   in Loop: Header=BB77_30 Depth=2
	add	x8, sp, #304
	add	x1, x8, #8
	mov	x0, x22
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	str	x26, [sp, #32]
	b	LBB77_29
LBB77_38:                               ; %bb23.i.us.us
                                        ; =>This Inner Loop Header: Depth=1
	b	LBB77_38
LBB77_39:                               ; %bb23.i.us4
                                        ; =>This Inner Loop Header: Depth=1
	b	LBB77_39
LBB77_40:                               ; %bb13.i
	mov	x0, x26
	bl	_free
LBB77_41:                               ; %"wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65.body.exit"
	mov	w0, #0                          ; =0x0
LBB77_42:                               ; %"wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	add	sp, sp, #576
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB77_43:                               ; %invalid.tag.b12.i
	bl	_abort
LBB77_44:                               ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_action$instance$fc5e3cb62bdf3601 ; -- Begin function wf_std.collections.hash_map.hash_map_action$instance$fc5e3cb62bdf3601
	.p2align	2
_wf_std.collections.hash_map.hash_map_action$instance$fc5e3cb62bdf3601: ; @"wf_std.collections.hash_map.hash_map_action$instance$fc5e3cb62bdf3601"
; %bb.0:                                ; %entry
	mov	x8, x0
	ldr	w0, [x0]
	cmp	w0, #2
	b.hs	LBB78_2
; %bb.1:                                ; %common.ret
	ret
LBB78_2:                                ; %entry
	b.ne	LBB78_4
; %bb.3:                                ; %bb3
	ldr	x8, [x8, #8]
	ldr	x9, [x1]
	cmp	x8, x9
	mov	w8, #2                          ; =0x2
	cinc	w0, w8, eq
	ret
LBB78_4:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3 ; -- Begin function wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3
	.p2align	2
_wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3: ; @"wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	mov	w9, #24                         ; =0x18
	madd	x9, x2, x9, x8
	ldr	w8, [x9, #16]
	ldur	q0, [x9, #24]
	mov	w10, #2                         ; =0x2
	str	w10, [x9, #16]
	stp	x3, x4, [x9, #24]
	cbz	w8, LBB79_4
; %bb.1:                                ; %entry
	cmp	w8, #1
	b.eq	LBB79_4
; %bb.2:                                ; %entry
	cmp	w8, #2
	b.ne	LBB79_5
; %bb.3:                                ; %bb3
	str	xzr, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	stur	q0, [x0, #8]
	ret
LBB79_4:                                ; %bb2
	stp	xzr, xzr, [x0]
	str	xzr, [x0, #16]
	ret
LBB79_5:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6 ; -- Begin function wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6
	.p2align	2
_wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6: ; @"wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	cmp	x1, #3
	b.hi	LBB80_2
; %bb.1:                                ; %bb3.i
	ldr	x19, [x0]
	ldr	x8, [x19]
	cmp	x1, x8
	b.hs	LBB80_3
LBB80_2:
	mov	w0, #1                          ; =0x1
	b	LBB80_35
LBB80_3:                                ; %bb6.i
	cbz	x1, LBB80_34
; %bb.4:                                ; %bb9.i
	mov	x22, x0
	ldr	x20, [x2]
	ldrb	w21, [x2, #8]
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	mov	x23, x1
	madd	x0, x1, x8, x9
	bl	_malloc
	cbz	x0, LBB80_37
; %bb.5:                                ; %bb1.i.i
	mov	x8, #0                          ; =0x0
	mov	x9, x23
	str	x23, [x0, #8]
	add	x10, x0, #24
LBB80_6:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x10, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x10], #24
	cmp	x9, x8
	b.ne	LBB80_6
; %bb.7:                                ; %bb4.bb7_crit_edge.i.i
	str	x9, [x0]
	str	x0, [x22]
	ldr	x12, [x19]
	cbz	x12, LBB80_33
; %bb.8:                                ; %bb14.lr.ph.i
	tbz	w21, #0, LBB80_21
; %bb.9:                                ; %bb14.us.i.preheader
	add	x8, x0, #16
	mov	w9, #24                         ; =0x18
	mov	w10, #2                         ; =0x2
	b	LBB80_13
LBB80_10:                               ; %bb25.us.us.i
                                        ;   in Loop: Header=BB80_13 Depth=1
	b.hs	LBB80_36
; %bb.11:                               ; %bb15.us.loopexit.i
                                        ;   in Loop: Header=BB80_13 Depth=1
	str	w10, [x14]
	stp	x12, x11, [x14, #8]
	ldr	x11, [x19]
LBB80_12:                               ; %bb15.us.i
                                        ;   in Loop: Header=BB80_13 Depth=1
	mov	x12, x11
	cbz	x11, LBB80_33
LBB80_13:                               ; %bb14.us.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB80_17 Depth 2
                                        ;       Child Loop BB80_18 Depth 3
	sub	x11, x12, #1
	str	x11, [x19]
	madd	x12, x12, x9, x19
	ldr	w13, [x12, #-8]!
	cmp	w13, #2
	b.lo	LBB80_12
; %bb.14:                               ; %bb14.us.i
                                        ;   in Loop: Header=BB80_13 Depth=1
	b.ne	LBB80_36
; %bb.15:                               ; %bb23.lr.ph.us.i
                                        ;   in Loop: Header=BB80_13 Depth=1
	ldr	x13, [x0]
	cbz	x13, LBB80_20
; %bb.16:                               ;   in Loop: Header=BB80_13 Depth=1
	ldp	x12, x11, [x12, #8]
LBB80_17:                               ; %bb25.us.us.i.preheader
                                        ;   Parent Loop BB80_13 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB80_18 Depth 3
	mov	x15, #0                         ; =0x0
	mov	x14, x8
LBB80_18:                               ; %bb25.us.us.i
                                        ;   Parent Loop BB80_13 Depth=1
                                        ;     Parent Loop BB80_17 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w16, [x14]
	cmp	w16, #2
	b.ne	LBB80_10
; %bb.19:                               ; %bb3.i26.us.us.i
                                        ;   in Loop: Header=BB80_18 Depth=3
	add	x15, x15, #1
	add	x14, x14, #24
	cmp	x13, x15
	b.ne	LBB80_18
	b	LBB80_17
LBB80_20:                               ; %bb23.us.us.i
                                        ; =>This Inner Loop Header: Depth=1
	b	LBB80_20
LBB80_21:
	mov	w8, #24                         ; =0x18
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mov	x10, #4587                      ; =0x11eb
	movk	x10, #4913, lsl #16
	movk	x10, #18875, lsl #32
	movk	x10, #38096, lsl #48
	mov	w11, #2                         ; =0x2
	b	LBB80_25
LBB80_22:                               ; %bb25.i
                                        ;   in Loop: Header=BB80_25 Depth=1
	b.hs	LBB80_36
; %bb.23:                               ; %bb15.loopexit.i
                                        ;   in Loop: Header=BB80_25 Depth=1
	str	w11, [x2]
	stp	x13, x12, [x2, #8]
	ldr	x13, [x19]
LBB80_24:                               ; %bb15.i
                                        ;   in Loop: Header=BB80_25 Depth=1
	mov	x12, x13
	cbz	x13, LBB80_33
LBB80_25:                               ; %bb14.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB80_29 Depth 2
                                        ;       Child Loop BB80_30 Depth 3
	sub	x13, x12, #1
	str	x13, [x19]
	madd	x15, x12, x8, x19
	ldr	w12, [x15, #-8]!
	cmp	w12, #2
	b.lo	LBB80_24
; %bb.26:                               ; %bb14.i
                                        ;   in Loop: Header=BB80_25 Depth=1
	b.ne	LBB80_36
; %bb.27:                               ; %bb23.lr.ph.i
                                        ;   in Loop: Header=BB80_25 Depth=1
	ldr	x14, [x0]
	cbz	x14, LBB80_32
; %bb.28:                               ; %bb23.preheader.i
                                        ;   in Loop: Header=BB80_25 Depth=1
	ldp	x13, x12, [x15, #8]
	eor	x15, x13, x20
	eor	x15, x15, x15, lsr #30
	mul	x15, x15, x9
	eor	x15, x15, x15, lsr #27
	mul	x15, x15, x10
	eor	x15, x15, x15, lsr #31
	udiv	x16, x15, x14
	msub	x15, x16, x14, x15
	sub	x16, x14, x15
	neg	x17, x16
LBB80_29:                               ; %bb25.lr.ph.i
                                        ;   Parent Loop BB80_25 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB80_30 Depth 3
	mov	x1, #0                          ; =0x0
LBB80_30:                               ; %bb25.i
                                        ;   Parent Loop BB80_25 Depth=1
                                        ;     Parent Loop BB80_29 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x1, x16
	csel	x2, x15, x17, lo
	add	x2, x2, x1
	madd	x2, x2, x8, x0
	ldr	w3, [x2, #16]!
	cmp	w3, #2
	b.ne	LBB80_22
; %bb.31:                               ; %bb3.i26.i
                                        ;   in Loop: Header=BB80_30 Depth=3
	add	x1, x1, #1
	cmp	x14, x1
	b.ne	LBB80_30
	b	LBB80_29
LBB80_32:                               ; %bb23.us16.i
                                        ; =>This Inner Loop Header: Depth=1
	b	LBB80_32
LBB80_33:                               ; %bb13.i
	mov	x0, x19
	bl	_free
LBB80_34:                               ; %"wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6.body.exit"
	mov	w0, #0                          ; =0x0
LBB80_35:                               ; %"wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB80_36:                               ; %invalid.tag.b12.i
	bl	_abort
LBB80_37:                               ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_slots_new$instance$15df03c28018958d ; -- Begin function wf_slots_new$instance$15df03c28018958d
	.p2align	2
_wf_slots_new$instance$15df03c28018958d: ; @"wf_slots_new$instance$15df03c28018958d"
; %bb.0:                                ; %entry
	mov	x0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_is_available$instance$0ed342445dd803f3 ; -- Begin function wf_std.collections.hash_map.hash_map_is_available$instance$0ed342445dd803f3
	.p2align	2
_wf_std.collections.hash_map.hash_map_is_available$instance$0ed342445dd803f3: ; @"wf_std.collections.hash_map.hash_map_is_available$instance$0ed342445dd803f3"
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cmp	w8, #3
	b.hs	LBB82_2
; %bb.1:                                ; %switch.lookup
	mov	w9, #3                          ; =0x3
	lsr	w8, w9, w8
	and	w0, w8, #0x1
	ret
LBB82_2:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_action$instance$c6df3d8464f8cde0 ; -- Begin function wf_std.collections.hash_map.hash_map_action$instance$c6df3d8464f8cde0
	.p2align	2
_wf_std.collections.hash_map.hash_map_action$instance$c6df3d8464f8cde0: ; @"wf_std.collections.hash_map.hash_map_action$instance$c6df3d8464f8cde0"
; %bb.0:                                ; %entry
	mov	x8, x0
	ldr	w0, [x0]
	cmp	w0, #2
	b.hs	LBB83_2
; %bb.1:                                ; %common.ret
	ret
LBB83_2:                                ; %entry
	b.ne	LBB83_4
; %bb.3:                                ; %bb3
	ldr	x8, [x8, #8]
	ldr	x9, [x1]
	cmp	x8, x9
	mov	w8, #2                          ; =0x2
	cinc	w0, w8, eq
	ret
LBB83_4:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449 ; -- Begin function wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
	.p2align	2
_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449: ; @"wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449"
; %bb.0:                                ; %entry
	stp	d15, d14, [sp, #-64]!           ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	ldr	x8, [x1]
	mov	w9, #272                        ; =0x110
	madd	x10, x2, x9, x8
	ldr	w9, [x10, #16]!
	ldur	q0, [x10, #8]
	ldur	q1, [x10, #24]
	ldur	q2, [x10, #40]
	ldur	q3, [x10, #56]
	ldur	q4, [x10, #72]
	ldur	q5, [x10, #88]
	ldur	q6, [x10, #104]
	ldur	q7, [x10, #120]
	ldur	q16, [x10, #136]
	ldur	q17, [x10, #152]
	ldur	q18, [x10, #168]
	ldur	q19, [x10, #184]
	ldur	q20, [x10, #200]
	ldur	q21, [x10, #216]
	ldur	q22, [x10, #232]
	ldur	q23, [x10, #248]
	ldr	x8, [x10, #264]
	ldp	q24, q25, [x4]
	ldp	q26, q27, [x4, #32]
	ldp	q28, q29, [x4, #64]
	ldp	q30, q31, [x4, #96]
	ldp	q8, q9, [x4, #128]
	ldp	q10, q11, [x4, #160]
	ldp	q12, q13, [x4, #192]
	ldp	q14, q15, [x4, #224]
	mov	w11, #2                         ; =0x2
	str	w11, [x10]
	str	x3, [x10, #8]
	stp	q24, q25, [x10, #16]
	stp	q26, q27, [x10, #48]
	stp	q28, q29, [x10, #80]
	stp	q30, q31, [x10, #112]
	stp	q8, q9, [x10, #144]
	stp	q10, q11, [x10, #176]
	stp	q12, q13, [x10, #208]
	stp	q14, q15, [x10, #240]
	cbz	w9, LBB84_4
; %bb.1:                                ; %entry
	cmp	w9, #1
	b.eq	LBB84_4
; %bb.2:                                ; %entry
	cmp	w9, #2
	b.ne	LBB84_5
; %bb.3:                                ; %bb3
	str	xzr, [x0]
	mov	w9, #1                          ; =0x1
	str	w9, [x0]
	stur	q0, [x0, #8]
	stur	q1, [x0, #24]
	stur	q2, [x0, #40]
	stur	q3, [x0, #56]
	stur	q4, [x0, #72]
	stur	q5, [x0, #88]
	stur	q6, [x0, #104]
	stur	q7, [x0, #120]
	stur	q16, [x0, #136]
	stur	q17, [x0, #152]
	stur	q18, [x0, #168]
	stur	q19, [x0, #184]
	stur	q20, [x0, #200]
	stur	q21, [x0, #216]
	stur	q22, [x0, #232]
	stur	q23, [x0, #248]
	str	x8, [x0, #264]
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #64             ; 16-byte Folded Reload
	ret
LBB84_4:                                ; %bb2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0, #240]
	stp	q0, q0, [x0, #208]
	stp	q0, q0, [x0, #176]
	stp	q0, q0, [x0, #144]
	stp	q0, q0, [x0, #112]
	stp	q0, q0, [x0, #80]
	stp	q0, q0, [x0, #48]
	stp	q0, q0, [x0, #16]
	str	q0, [x0]
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #64             ; 16-byte Folded Reload
	ret
LBB84_5:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07 ; -- Begin function wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07
	.p2align	2
_wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07: ; @"wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #576
	.cfi_def_cfa_offset 672
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	cmp	x1, #3
	b.hi	LBB85_2
; %bb.1:                                ; %bb3.i
	mov	x19, x0
	ldr	x26, [x0]
	ldr	x20, [x26]
	cmp	x1, x20
	b.hs	LBB85_3
LBB85_2:
	mov	w0, #1                          ; =0x1
	b	LBB85_42
LBB85_3:                                ; %bb6.i
	cbz	x1, LBB85_41
; %bb.4:                                ; %bb9.i
	ldr	x23, [x2]
	ldrb	w8, [x2, #8]
	str	w8, [sp, #28]                   ; 4-byte Folded Spill
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	mov	x22, x1
	madd	x0, x1, x8, x9
	bl	_malloc
	cbz	x0, LBB85_44
; %bb.5:                                ; %bb1.i.i
	mov	x21, x0
	mov	x8, #0                          ; =0x0
	mov	x9, x22
	str	x22, [x0, #8]
	add	x10, x0, #24
	movi.2d	v0, #0000000000000000
LBB85_6:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x10, #-8]
	add	x8, x8, #1
	stp	q0, q0, [x10]
	stp	q0, q0, [x10, #32]
	stp	q0, q0, [x10, #64]
	stp	q0, q0, [x10, #96]
	stp	q0, q0, [x10, #128]
	stp	q0, q0, [x10, #160]
	stp	q0, q0, [x10, #192]
	stp	q0, q0, [x10, #224]
	str	xzr, [x10, #256]
	add	x10, x10, #272
	cmp	x9, x8
	b.ne	LBB85_6
; %bb.7:                                ; %bb4.bb7_crit_edge.i.i
	str	x9, [x21]
	str	x21, [x19]
	cbz	x20, LBB85_40
; %bb.8:                                ; %bb14.lr.ph.i
	add	x27, x21, #16
	mov	w28, #272                       ; =0x110
	mov	w24, #264                       ; =0x108
	add	x25, sp, #32
	str	x26, [sp, #16]                  ; 8-byte Folded Spill
	b	LBB85_11
LBB85_9:                                ; %bb15thread-pre-split.i
                                        ;   in Loop: Header=BB85_11 Depth=1
	ldr	x26, [sp, #16]                  ; 8-byte Folded Reload
	ldr	x9, [x26]
LBB85_10:                               ; %bb15.i
                                        ;   in Loop: Header=BB85_11 Depth=1
	mov	x20, x9
	cbz	x9, LBB85_40
LBB85_11:                               ; %bb14.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB85_30 Depth 2
                                        ;       Child Loop BB85_32 Depth 3
                                        ;     Child Loop BB85_18 Depth 2
                                        ;       Child Loop BB85_20 Depth 3
	sub	x9, x20, #1
	str	x9, [x26]
	madd	x8, x20, x28, x26
	ldr	w10, [x8, #-256]!
	cmp	w10, #2
	b.lo	LBB85_10
; %bb.12:                               ; %bb14.i
                                        ;   in Loop: Header=BB85_11 Depth=1
	b.ne	LBB85_43
; %bb.13:                               ; %bb23.preheader.i
                                        ;   in Loop: Header=BB85_11 Depth=1
	ldr	x9, [x8, #264]
	str	xzr, [sp, #32]
	ldur	q0, [x8, #8]
	stur	q0, [sp, #40]
	ldur	q0, [x8, #24]
	stur	q0, [sp, #56]
	ldur	q0, [x8, #40]
	stur	q0, [sp, #72]
	ldur	q0, [x8, #56]
	stur	q0, [sp, #88]
	ldur	q0, [x8, #72]
	stur	q0, [sp, #104]
	ldur	q0, [x8, #88]
	stur	q0, [sp, #120]
	ldur	q0, [x8, #104]
	stur	q0, [sp, #136]
	ldur	q0, [x8, #120]
	stur	q0, [sp, #152]
	ldur	q0, [x8, #136]
	add	x10, sp, #32
	stur	q0, [x10, #136]
	ldur	q0, [x8, #152]
	stur	q0, [x10, #152]
	ldur	q0, [x8, #168]
	stur	q0, [x10, #168]
	ldur	q0, [x8, #184]
	stur	q0, [x10, #184]
	ldur	q0, [x8, #200]
	stur	q0, [x10, #200]
	ldur	q0, [x8, #216]
	stur	q0, [x10, #216]
	ldur	q0, [x8, #232]
	stur	q0, [x10, #232]
	ldur	q0, [x8, #248]
	stur	q0, [x10, #248]
	str	x9, [sp, #296]
	ldr	x8, [x21]
	ldr	w9, [sp, #28]                   ; 4-byte Folded Reload
	tbz	w9, #0, LBB85_26
; %bb.14:                               ; %bb23.preheader.i.split.us
                                        ;   in Loop: Header=BB85_11 Depth=1
	cbz	x8, LBB85_38
; %bb.15:                               ; %bb23.i.us.preheader
                                        ;   in Loop: Header=BB85_11 Depth=1
	mov	w20, #1                         ; =0x1
	b	LBB85_18
LBB85_16:                               ; %bb27.i.us
                                        ;   in Loop: Header=BB85_18 Depth=2
	mov	x20, x26
	cbz	x26, LBB85_9
LBB85_17:                               ; %bb23.i.usthread-pre-split
                                        ;   in Loop: Header=BB85_18 Depth=2
	ldr	x8, [x21]
LBB85_18:                               ; %bb23.i.us
                                        ;   Parent Loop BB85_11 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB85_20 Depth 3
	cbz	x8, LBB85_17
; %bb.19:                               ; %bb25.i.us.preheader
                                        ;   in Loop: Header=BB85_18 Depth=2
	mov	x2, #0                          ; =0x0
	mov	x9, x27
LBB85_20:                               ; %bb25.i.us
                                        ;   Parent Loop BB85_11 Depth=1
                                        ;     Parent Loop BB85_18 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	w10, [x9]
	cmp	w10, #2
	b.ne	LBB85_22
; %bb.21:                               ; %bb3.i25.i.us
                                        ;   in Loop: Header=BB85_20 Depth=3
	add	x9, x9, #272
	add	x2, x2, #1
	cmp	x8, x2
	b.ne	LBB85_20
	b	LBB85_17
LBB85_22:                               ; %bb25.i.us
                                        ;   in Loop: Header=BB85_18 Depth=2
	b.hs	LBB85_43
; %bb.23:                               ; %bb29.i.us
                                        ;   in Loop: Header=BB85_18 Depth=2
	sub	x26, x20, #1
	str	x26, [sp, #32]
	madd	x22, x20, x24, x25
	ldr	x3, [x22, #-256]!
	add	x0, sp, #304
	add	x4, x22, #8
	mov	x1, x19
	bl	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
	ldr	w8, [sp, #304]
	cbz	w8, LBB85_16
; %bb.24:                               ; %bb29.i.us
                                        ;   in Loop: Header=BB85_18 Depth=2
	cmp	w8, #1
	b.ne	LBB85_43
; %bb.25:                               ; %bb33.i.us
                                        ;   in Loop: Header=BB85_18 Depth=2
	add	x8, sp, #304
	add	x1, x8, #8
	mov	x0, x22
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	str	x20, [sp, #32]
	b	LBB85_17
LBB85_26:                               ; %bb23.preheader.i.split
                                        ;   in Loop: Header=BB85_11 Depth=1
	cbz	x8, LBB85_39
; %bb.27:                               ; %bb23.i.preheader
                                        ;   in Loop: Header=BB85_11 Depth=1
	mov	w26, #1                         ; =0x1
	b	LBB85_30
LBB85_28:                               ; %bb27.i
                                        ;   in Loop: Header=BB85_30 Depth=2
	mov	x26, x20
	cbz	x20, LBB85_9
LBB85_29:                               ; %bb23.ithread-pre-split
                                        ;   in Loop: Header=BB85_30 Depth=2
	ldr	x8, [x21]
LBB85_30:                               ; %bb23.i
                                        ;   Parent Loop BB85_11 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB85_32 Depth 3
	cbz	x8, LBB85_29
; %bb.31:                               ; %bb25.lr.ph.i
                                        ;   in Loop: Header=BB85_30 Depth=2
	mov	x9, #0                          ; =0x0
	ldr	x10, [sp, #40]
	eor	x10, x10, x23
	eor	x10, x10, x10, lsr #30
	mov	x11, #58809                     ; =0xe5b9
	movk	x11, #7396, lsl #16
	movk	x11, #18285, lsl #32
	movk	x11, #48984, lsl #48
	mul	x10, x10, x11
	eor	x10, x10, x10, lsr #27
	mov	x11, #4587                      ; =0x11eb
	movk	x11, #4913, lsl #16
	movk	x11, #18875, lsl #32
	movk	x11, #38096, lsl #48
	mul	x10, x10, x11
	eor	x10, x10, x10, lsr #31
	udiv	x11, x10, x8
	msub	x10, x11, x8, x10
	sub	x11, x8, x10
	neg	x13, x11
LBB85_32:                               ; %bb25.i
                                        ;   Parent Loop BB85_11 Depth=1
                                        ;     Parent Loop BB85_30 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x9, x11
	csel	x12, x10, x13, lo
	add	x14, x12, x9
	madd	x14, x14, x28, x21
	ldr	w14, [x14, #16]
	cmp	w14, #2
	b.ne	LBB85_34
; %bb.33:                               ; %bb3.i25.i
                                        ;   in Loop: Header=BB85_32 Depth=3
	add	x9, x9, #1
	cmp	x8, x9
	b.ne	LBB85_32
	b	LBB85_29
LBB85_34:                               ; %bb25.i
                                        ;   in Loop: Header=BB85_30 Depth=2
	b.hs	LBB85_43
; %bb.35:                               ; %bb29.i
                                        ;   in Loop: Header=BB85_30 Depth=2
	sub	x20, x26, #1
	str	x20, [sp, #32]
	madd	x22, x26, x24, x25
	ldr	x3, [x22, #-256]!
	add	x0, sp, #304
	add	x2, x12, x9
	add	x4, x22, #8
	mov	x1, x19
	bl	_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449
	ldr	w8, [sp, #304]
	cbz	w8, LBB85_28
; %bb.36:                               ; %bb29.i
                                        ;   in Loop: Header=BB85_30 Depth=2
	cmp	w8, #1
	b.ne	LBB85_43
; %bb.37:                               ; %bb33.i
                                        ;   in Loop: Header=BB85_30 Depth=2
	add	x8, sp, #304
	add	x1, x8, #8
	mov	x0, x22
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	str	x26, [sp, #32]
	b	LBB85_29
LBB85_38:                               ; %bb23.i.us.us
                                        ; =>This Inner Loop Header: Depth=1
	b	LBB85_38
LBB85_39:                               ; %bb23.i.us4
                                        ; =>This Inner Loop Header: Depth=1
	b	LBB85_39
LBB85_40:                               ; %bb13.i
	mov	x0, x26
	bl	_free
LBB85_41:                               ; %"wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07.body.exit"
	mov	w0, #0                          ; =0x0
LBB85_42:                               ; %"wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	add	sp, sp, #576
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB85_43:                               ; %invalid.tag.b12.i
	bl	_abort
LBB85_44:                               ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_slots_new$instance$8ac6e57475a1cbbb ; -- Begin function wf_slots_new$instance$8ac6e57475a1cbbb
	.p2align	2
_wf_slots_new$instance$8ac6e57475a1cbbb: ; @"wf_slots_new$instance$8ac6e57475a1cbbb"
; %bb.0:                                ; %entry
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0, #240]
	stp	q0, q0, [x0, #208]
	stp	q0, q0, [x0, #176]
	stp	q0, q0, [x0, #144]
	stp	q0, q0, [x0, #112]
	stp	q0, q0, [x0, #80]
	stp	q0, q0, [x0, #48]
	stp	q0, q0, [x0, #16]
	str	q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_is_available$instance$d7a1a90c27bba449 ; -- Begin function wf_std.collections.hash_map.hash_map_is_available$instance$d7a1a90c27bba449
	.p2align	2
_wf_std.collections.hash_map.hash_map_is_available$instance$d7a1a90c27bba449: ; @"wf_std.collections.hash_map.hash_map_is_available$instance$d7a1a90c27bba449"
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cmp	w8, #3
	b.hs	LBB87_2
; %bb.1:                                ; %switch.lookup
	mov	w9, #3                          ; =0x3
	lsr	w8, w9, w8
	and	w0, w8, #0x1
	ret
LBB87_2:                                ; %invalid.tag.b0
	bl	_abort
                                        ; -- End function
	.globl	_wf_take_back$instance$9985a87b1cb96650 ; -- Begin function wf_take_back$instance$9985a87b1cb96650
	.p2align	2
_wf_take_back$instance$9985a87b1cb96650: ; @"wf_take_back$instance$9985a87b1cb96650"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x9, [x8]
	sub	x10, x9, #1
	str	x10, [x8]
	mov	w10, #24                        ; =0x18
	madd	x8, x9, x10, x8
	ldur	w0, [x8, #-8]
	ldp	x1, x2, [x8]
	ret
                                        ; -- End function
	.globl	_wf_free_empty$instance$43608765810d87c7 ; -- Begin function wf_free_empty$instance$43608765810d87c7
	.p2align	2
_wf_free_empty$instance$43608765810d87c7: ; @"wf_free_empty$instance$43608765810d87c7"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	bl	_free
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_swap$instance$b45b69d9d0c6bbd0 ; -- Begin function wf_swap$instance$b45b69d9d0c6bbd0
	.p2align	2
_wf_swap$instance$b45b69d9d0c6bbd0:     ; @"wf_swap$instance$b45b69d9d0c6bbd0"
; %bb.0:                                ; %entry
	ldr	q0, [x0]
	str	q0, [sp, #-32]!
	ldr	x8, [x0, #16]
	str	x8, [sp, #16]
	ldr	x9, [x1, #16]
	ldr	q1, [x1]
	str	q1, [x0]
	str	x9, [x0, #16]
	str	q0, [x1]
	str	x8, [x1, #16]
	mov	w0, #0                          ; =0x0
	add	sp, sp, #32
	ret
                                        ; -- End function
	.globl	_wf_take_back$instance$d5bb00f00cd669fb ; -- Begin function wf_take_back$instance$d5bb00f00cd669fb
	.p2align	2
_wf_take_back$instance$d5bb00f00cd669fb: ; @"wf_take_back$instance$d5bb00f00cd669fb"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x8]
	sub	x10, x9, #1
	mov	w11, #272                       ; =0x110
	madd	x9, x9, x11, x8
	sub	x1, x9, #256
	str	x10, [x8]
	mov	w2, #272                        ; =0x110
	b	_memmove
                                        ; -- End function
	.globl	_wf_free_empty$instance$d692d011b23a4a18 ; -- Begin function wf_free_empty$instance$d692d011b23a4a18
	.p2align	2
_wf_free_empty$instance$d692d011b23a4a18: ; @"wf_free_empty$instance$d692d011b23a4a18"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	bl	_free
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_swap$instance$9eabc50a9cce2251 ; -- Begin function wf_swap$instance$9eabc50a9cce2251
	.p2align	2
_wf_swap$instance$9eabc50a9cce2251:     ; @"wf_swap$instance$9eabc50a9cce2251"
; %bb.0:                                ; %entry
	sub	sp, sp, #320
	stp	x28, x27, [sp, #272]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #288]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #304]            ; 16-byte Folded Spill
	mov	x19, x1
	mov	x20, x0
	mov	x0, sp
	mov	x1, x20
	mov	w2, #272                        ; =0x110
	bl	_memcpy
	mov	x0, x20
	mov	x1, x19
	mov	w2, #272                        ; =0x110
	bl	_memmove
	mov	x1, sp
	mov	x0, x19
	mov	w2, #272                        ; =0x110
	bl	_memcpy
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #304]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #288]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #272]            ; 16-byte Folded Reload
	add	sp, sp, #320
	ret
                                        ; -- End function
	.globl	_wf_grow$instance$b45b69d9d0c6bbd0 ; -- Begin function wf_grow$instance$b45b69d9d0c6bbd0
	.p2align	2
_wf_grow$instance$b45b69d9d0c6bbd0:     ; @"wf_grow$instance$b45b69d9d0c6bbd0"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x22, x1
	mov	x19, x0
	ldr	x20, [x0]
	ldr	x23, [x20]
	mov	w8, #24                         ; =0x18
	mov	x9, #16                         ; =0x10
	madd	x0, x1, x8, x9
	bl	_malloc
	cbz	x0, LBB94_2
; %bb.1:                                ; %window.block.ready.v2
	mov	x21, x0
	stp	x23, x22, [x0], #16
	add	x8, x23, x23, lsl #1
	lsl	x2, x8, #3
	add	x1, x20, #16
	bl	_memmove
	mov	x0, x20
	bl	_free
	str	x21, [x19]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB94_2:                                ; %window.block.oom.v2
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_place_back$instance$9985a87b1cb96650 ; -- Begin function wf_place_back$instance$9985a87b1cb96650
	.p2align	2
_wf_place_back$instance$9985a87b1cb96650: ; @"wf_place_back$instance$9985a87b1cb96650"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x9, [x8]
	mov	w10, #24                        ; =0x18
	madd	x10, x9, x10, x8
	ldr	x11, [x1, #16]
	ldr	q0, [x1]
	str	q0, [x10, #16]
	str	x11, [x10, #32]
	add	x9, x9, #1
	str	x9, [x8]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_swap$instance$43608765810d87c7 ; -- Begin function wf_swap$instance$43608765810d87c7
	.p2align	2
_wf_swap$instance$43608765810d87c7:     ; @"wf_swap$instance$43608765810d87c7"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x9, [x1]
	str	x9, [x0]
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_place_back$instance$a6542e06bf5acd99 ; -- Begin function wf_place_back$instance$a6542e06bf5acd99
	.p2align	2
_wf_place_back$instance$a6542e06bf5acd99: ; @"wf_place_back$instance$a6542e06bf5acd99"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	add	x9, x0, x8, lsl #4
	ldr	q0, [x1]
	stur	q0, [x9, #8]
	add	x8, x8, #1
	str	x8, [x0]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_take_back$instance$a6542e06bf5acd99 ; -- Begin function wf_take_back$instance$a6542e06bf5acd99
	.p2align	2
_wf_take_back$instance$a6542e06bf5acd99: ; @"wf_take_back$instance$a6542e06bf5acd99"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	sub	x8, x8, #1
	add	x9, x0, x8, lsl #4
	str	x8, [x0]
	ldp	x0, x1, [x9, #8]
	ret
                                        ; -- End function
	.globl	_wf_free_empty$instance$bb96e2f57d31495e ; -- Begin function wf_free_empty$instance$bb96e2f57d31495e
	.p2align	2
_wf_free_empty$instance$bb96e2f57d31495e: ; @"wf_free_empty$instance$bb96e2f57d31495e"
; %bb.0:                                ; %entry
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_grow$instance$9eabc50a9cce2251 ; -- Begin function wf_grow$instance$9eabc50a9cce2251
	.p2align	2
_wf_grow$instance$9eabc50a9cce2251:     ; @"wf_grow$instance$9eabc50a9cce2251"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x22, x1
	mov	x19, x0
	ldr	x20, [x0]
	ldr	x23, [x20]
	mov	w8, #272                        ; =0x110
	mov	x9, #16                         ; =0x10
	madd	x0, x1, x8, x9
	bl	_malloc
	cbz	x0, LBB100_2
; %bb.1:                                ; %window.block.ready.v2
	mov	x21, x0
	stp	x23, x22, [x0], #16
	add	x8, x23, x23, lsl #4
	lsl	x2, x8, #4
	add	x1, x20, #16
	bl	_memmove
	mov	x0, x20
	bl	_free
	str	x21, [x19]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB100_2:                               ; %window.block.oom.v2
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_place_back$instance$d5bb00f00cd669fb ; -- Begin function wf_place_back$instance$d5bb00f00cd669fb
	.p2align	2
_wf_place_back$instance$d5bb00f00cd669fb: ; @"wf_place_back$instance$d5bb00f00cd669fb"
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	ldr	x19, [x0]
	ldr	x20, [x19]
	mov	w8, #272                        ; =0x110
	madd	x8, x20, x8, x19
	add	x0, x8, #16
	mov	w2, #272                        ; =0x110
	bl	_memmove
	add	x8, x20, #1
	str	x8, [x19]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_swap$instance$d692d011b23a4a18 ; -- Begin function wf_swap$instance$d692d011b23a4a18
	.p2align	2
_wf_swap$instance$d692d011b23a4a18:     ; @"wf_swap$instance$d692d011b23a4a18"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x9, [x1]
	str	x9, [x0]
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_place_back$instance$c189ec082e7c2a1f ; -- Begin function wf_place_back$instance$c189ec082e7c2a1f
	.p2align	2
_wf_place_back$instance$c189ec082e7c2a1f: ; @"wf_place_back$instance$c189ec082e7c2a1f"
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	mov	x19, x0
	ldr	x20, [x0]
	mov	w8, #264                        ; =0x108
	madd	x8, x20, x8, x0
	add	x0, x8, #8
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	x8, x20, #1
	str	x8, [x19]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_take_back$instance$c189ec082e7c2a1f ; -- Begin function wf_take_back$instance$c189ec082e7c2a1f
	.p2align	2
_wf_take_back$instance$c189ec082e7c2a1f: ; @"wf_take_back$instance$c189ec082e7c2a1f"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	sub	x9, x8, #1
	mov	w10, #264                       ; =0x108
	madd	x8, x8, x10, x1
	sub	x8, x8, #256
	str	x9, [x1]
	mov	x1, x8
	mov	w2, #264                        ; =0x108
	b	_memcpy
                                        ; -- End function
	.globl	_wf_free_empty$instance$41f1fc367c8c34ad ; -- Begin function wf_free_empty$instance$41f1fc367c8c34ad
	.p2align	2
_wf_free_empty$instance$41f1fc367c8c34ad: ; @"wf_free_empty$instance$41f1fc367c8c34ad"
; %bb.0:                                ; %entry
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf__floor_run                  ; -- Begin function wf__floor_run
	.weak_definition	_wf__floor_run
	.p2align	2
_wf__floor_run:                         ; @wf__floor_run
	.cfi_startproc
; %bb.0:                                ; %entry
	b	_wf__main_body
	.cfi_endproc
                                        ; -- End function
	.globl	_wf__main_body                  ; -- Begin function wf__main_body
	.p2align	2
_wf__main_body:                         ; @wf__main_body
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	w0, #3                          ; =0x3
	mov	w1, #2                          ; =0x2
	mov	w2, #2                          ; =0x2
	mov	w3, #17                         ; =0x11
	mov	x5, #0                          ; =0x0
	mov	w4, #7                          ; =0x7
	bl	_wf_map_cost_library_trace$instance$c7c8cd11e7f079bd
	mov	w0, #3                          ; =0x3
	mov	w1, #2                          ; =0x2
	mov	w2, #2                          ; =0x2
	mov	w3, #17                         ; =0x11
	mov	w4, #3                          ; =0x3
	mov	w5, #1                          ; =0x1
	bl	_wf_map_cost_library_trace$instance$4250cb78d3f44027
	mov	x0, sp
	mov	w1, #0                          ; =0x0
	bl	_wf_std.process.exit_status
	mov	x0, sp
	bl	_wf__ordinary_exit_code
	and	w0, w0, #0xff
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_fixture_main                ; -- Begin function wf_fixture_main
	.p2align	2
_wf_fixture_main:                       ; @wf_fixture_main
	.cfi_startproc
; %bb.0:                                ; %entry
	b	_wf__floor_run
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__const
l_.wf_resource.heap:                    ; @.wf_resource.heap
	.ascii	"{\"resource\":\"heap\"}\n"

.subsections_via_symbols
