; Whitefoot conservative module
source_filename = "whitefoot"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-apple-darwin"

%wf.t.b5efdacbe94e5739 = type { i64, { i64, [1 x ptr] } }
%wf.t.ee6ca7dc0a065510 = type { i64, i1 }
%wf.t.84597570beb237fa = type { i64, i64, i64, i64 }
%wf.t.862971f7a971a883 = type { [32 x i64] }
%wf.t.88c85cf833d71e28 = type { i32, i32, i8, i32, i8, i32, i8, i32, i8, i32, i8, i32, i8, i32, i8, i32, i8, i32, i8, i32, i8, i32, i8, i32, i8, i32, i8, i32, i8, i32, i8, i32, i8, i32, i8, i32, i8, i32, i8, i32, i8, i32, i8, i32, i8, i32, i8, i32, i8, i32, i8, i32, i8, i32, i8, i32, i8 }
%wf.t.996089250604052e = type { i32, %wf.t.88c85cf833d71e28 }
%wf.t.f3380055fe20f353 = type { i32, i64 }
%wf.t.07ce75c387735f4b = type { i32, i64 }
%wf.t.3b1b6d56073edde7 = type { i32, %wf.t.88c85cf833d71e28 }
%wf.t.8656946ecebc34ec = type { { i128, i128 }, { i128, i128 }, { i128, i128 }, { i128, i128 }, { i128, i128 }, { i128, i128 } }
%wf.t.b7e1ed626c09888a = type { i32, i64, i8 }
%wf.t.7d7f918f7b4962fd = type { i32, i8, i8 }
%wf.t.050c23416549474d = type { i32, i64, %wf.t.88c85cf833d71e28 }
%wf.t.5b970ff2ad934046 = type { i32, i64, %wf.t.996089250604052e }
%wf.t.8e49cf34abe1c006 = type { i32, { i128, i128 }, i1 }
%wf.t.b80a9bfbd1f59cb4 = type { i32, i64, %wf.t.f3380055fe20f353 }
%wf.t.4ef4128edabf98be = type { i32, i64, i1 }
%wf.t.f60af608c1958040 = type { i32, i64, %wf.t.07ce75c387735f4b }
%wf.t.245242d1ce38c3e4 = type { i32, { i128, i128 }, i1 }
%wf.t.0559b7ce3d6da8f1 = type { i32, { i128, i128 }, %wf.t.88c85cf833d71e28 }
%wf.t.401891d75555d20e = type { i32, { i128, i128 }, %wf.t.88c85cf833d71e28 }
%wf.t.27caeb25122ac7c4 = type { i32, { i128, i128 }, %wf.t.88c85cf833d71e28 }
%wf.t.6df397eafd3120ad = type { i32, i8, %wf.t.3b1b6d56073edde7 }
%wf.t.8074de807c9b0e4e = type { %wf.t.6df397eafd3120ad, i64, i64 }
%wf.t.93559409a7432998 = type { i32, i8, %wf.t.88c85cf833d71e28 }
%wf.t.eb423fc38cfed56f = type { i32, i64, i64 }
%wf.t.2758c7c2b3b908fb = type { ptr, i64, %wf.t.b5efdacbe94e5739 }
%wf.t.ac5891a387b8aafe = type { i32, i1, %wf.t.09071440a409e980 }
%wf.t.09071440a409e980 = type { i64, i64 }
%wf.t.7748a5b0f0193f4a = type { ptr, i64, %wf.t.b5efdacbe94e5739 }
%wf.t.743755fb647946cb = type { i32, %wf.t.09071440a409e980 }
%wf.t.e04aead91f34a68f = type { i32, i64, %wf.t.862971f7a971a883 }
%wf.t.a5ea622fe32c85b6 = type { ptr, i64, %wf.t.b5efdacbe94e5739 }
%wf.t.9d321e1eb2ec1c03 = type { i32, i1, %wf.t.20dda3774c7510ec }
%wf.t.20dda3774c7510ec = type { i64, %wf.t.862971f7a971a883 }
%wf.t.05623e8a192b9069 = type { ptr, i64, %wf.t.b5efdacbe94e5739 }
%wf.t.e020a813ecac56e1 = type { i32, %wf.t.20dda3774c7510ec }

@.wf_resource.heap = private unnamed_addr constant [20 x i8] c"\7B\22\72\65\73\6F\75\72\63\65\22\3A\22\68\65\61\70\22\7D\0A", align 1
declare i64 @write(i32, ptr, i64)
declare ptr @__error()

define private i64 @wf_resource_write(ptr %bytes, i64 %length) #0 {
entry:
  br label %write
write:
  %written = call i64 @write(i32 2, ptr %bytes, i64 %length)
  %failed = icmp slt i64 %written, 0
  br i1 %failed, label %error, label %done
error:
  %errno = call ptr @__error()
  %code = load i32, ptr %errno, align 4
  %interrupted = icmp eq i32 %code, 4
  br i1 %interrupted, label %write, label %done
done:
  ret i64 %written
}

declare void @abort() noreturn
declare ptr @malloc(i64)
declare void @free(ptr)

define private void @wf_resource_record_abort(ptr %message, i64 %length) noreturn #0 {
entry:
  br label %write.loop
write.loop:
  %cursor = phi ptr [ %message, %entry ], [ %next, %write.more ]
  %remaining = phi i64 [ %length, %entry ], [ %left, %write.more ]
  %written = call i64 @wf_resource_write(ptr %cursor, i64 %remaining)
  %complete = icmp eq i64 %written, %remaining
  br i1 %complete, label %abort, label %write.incomplete
write.incomplete:
  %progress = icmp sgt i64 %written, 0
  br i1 %progress, label %write.more, label %abort
write.more:
  %next = getelementptr i8, ptr %cursor, i64 %written
  %left = sub i64 %remaining, %written
  br label %write.loop
abort:
  call void @abort()
  unreachable
}

define private void @wf_resource_abort() noreturn #0 {
entry:
  call void @wf_resource_record_abort(ptr @.wf_resource.heap, i64 20)
  unreachable
}

define private void @wf.drop.run.707f874ef98d2803({ i64, [1 x ptr] } %value) #0 {
entry:
  %storage = alloca { i64, [1 x ptr] }
  store { i64, [1 x ptr] } %value, ptr %storage
  %pointer = getelementptr inbounds { i64, [1 x ptr] }, ptr %storage, i64 0, i32 1, i64 0
  %capacity = add i64 1, 0
  %length = extractvalue { i64, [1 x ptr] } %value, 0
  %origin = add i64 0, 0
  br label %walk
walk:
  %index = phi i64 [ 0, %entry ], [ %next, %body ]
  %continue = icmp ult i64 %index, %length
  br i1 %continue, label %body, label %done
body:
  %raw = add i64 %origin, %index
  %over = icmp uge i64 %raw, %capacity
  %reduced = sub i64 %raw, %capacity
  %physical = select i1 %over, i64 %reduced, i64 %raw
  %element.pointer = getelementptr inbounds ptr, ptr %pointer, i64 %physical
  %element = load ptr, ptr %element.pointer
  call void @free(ptr %element)
  %next = add i64 %index, 1
  br label %walk
done:
  ret void
}

declare void @llvm.assume(i1)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1 immarg)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1 immarg)
declare i64 @llvm.cttz.i64(i64, i1)

define i64 @wf_hash_map.hash_map_control_fingerprint(i64 %v0) #0 {
entry:
  %v1 = select i1 true, i32 57, i32 57
  %t0 = zext i32 %v1 to i64
  %v2 = lshr i64 %v0, %t0
  ret i64 %v2
}

define i64 @wf_hash_map.hash_map_control_word(ptr noalias nonnull captures(none) dereferenceable(24) %v0, i64 %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.b5efdacbe94e5739, align 8
  %wf.slot.1 = alloca %wf.t.b5efdacbe94e5739, align 8
  %t0 = getelementptr inbounds %wf.t.b5efdacbe94e5739, ptr %v0, i32 0, i32 1
  %v2 = getelementptr i8, ptr %t0, i64 0
  %t2 = getelementptr inbounds { i64, [1 x ptr] }, ptr %v2, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v3 = add i64 %t1, 0
  %v4 = select i1 true, i64 0, i64 0
  %v5 = icmp eq i64 %v3, %v4
  switch i1 %v5, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v6 = phi ptr [ %v0, %bb3 ]
  %v7 = phi i64 [ %v1, %bb3 ]
  %t3 = getelementptr inbounds %wf.t.b5efdacbe94e5739, ptr %v6, i32 0, i32 1
  %v15 = getelementptr i8, ptr %t3, i64 0
  %v16 = select i1 true, i64 0, i64 0
  %t4.nonnegative = icmp sge i64 %v16, 0
  call void @llvm.assume(i1 %t4.nonnegative)
  %t4 = getelementptr inbounds { i64, [1 x ptr] }, ptr %v15, i64 0, i32 1, i64 %v16
  %v17 = getelementptr i8, ptr %t4, i64 0
  %v18 = getelementptr i8, ptr %v17, i64 0
  %t5 = load ptr, ptr %v18
  %t6 = getelementptr inbounds { i64, [0 x i64] }, ptr %t5, i32 0, i32 0
  %v19 = load i64, ptr %t6
  %v20 = icmp ult i64 %v7, %v19
  switch i1 %v20, label %invalid.tag.b1 [
    i1 1, label %bb8
    i1 0, label %bb9
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v8 = select i1 true, i64 0, i64 0
  %v9 = icmp eq i64 %v1, %v8
  switch i1 %v9, label %invalid.tag.b2 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b2:
  call void @abort()
  unreachable
bb3:
  br label %bb1
bb4:
  %v10 = phi ptr [ %v0, %bb6 ]
  %v11 = phi i64 [ %v1, %bb6 ]
  %v14 = select i1 true, i64 9259542123273814144, i64 9259542123273814144
  ret i64 %v14
bb5:
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.b5efdacbe94e5739, ptr null, i32 1) to i64), i1 false)
  %t7 = getelementptr inbounds %wf.t.b5efdacbe94e5739, ptr %wf.slot.0, i32 0, i32 0
  %v13 = load i64, ptr %t7
  ret i64 %v13
bb6:
  br label %bb4
bb7:
  %v21 = phi ptr [ %v6, %bb9 ]
  %v22 = phi i64 [ %v7, %bb9 ]
  %v23 = phi ptr [ %v17, %bb9 ]
  %v27 = getelementptr i8, ptr %v23, i64 0
  %t8 = load ptr, ptr %v27
  %t9 = getelementptr inbounds { i64, [0 x i64] }, ptr %t8, i32 0, i32 0
  %v28 = load i64, ptr %t9
  %v29 = icmp eq i64 %v22, %v28
  switch i1 %v29, label %invalid.tag.b7 [
    i1 1, label %bb11
    i1 0, label %bb12
  ]
invalid.tag.b7:
  call void @abort()
  unreachable
bb8:
  %v24 = getelementptr i8, ptr %v17, i64 0
  %t10 = load ptr, ptr %v24
  %t11 = getelementptr inbounds { i64, [0 x i64] }, ptr %t10, i64 0, i32 1, i64 %v7
  %v25 = getelementptr i8, ptr %t11, i64 0
  %v26 = load i64, ptr %v25
  ret i64 %v26
bb9:
  br label %bb7
bb10:
  %v30 = phi ptr [ %v21, %bb12 ]
  %v31 = phi i64 [ %v22, %bb12 ]
  %v32 = phi ptr [ %v23, %bb12 ]
  %v35 = select i1 true, i64 9259542123273814144, i64 9259542123273814144
  ret i64 %v35
bb11:
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v21, i64 ptrtoint (ptr getelementptr (%wf.t.b5efdacbe94e5739, ptr null, i32 1) to i64), i1 false)
  %t12 = getelementptr inbounds %wf.t.b5efdacbe94e5739, ptr %wf.slot.1, i32 0, i32 0
  %v34 = load i64, ptr %t12
  ret i64 %v34
bb12:
  br label %bb10
}

define i8 @wf_hash_map.hash_map_control_set(ptr noalias nonnull captures(none) dereferenceable(24) %v0, i64 %v1, i64 %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.b5efdacbe94e5739, align 8
  %wf.slot.1 = alloca %wf.t.b5efdacbe94e5739, align 8
  %v3 = select i1 true, i64 8, i64 8
  %v4 = udiv i64 %v1, %v3
  %v5 = select i1 true, i64 8, i64 8
  %v6 = urem i64 %v1, %v5
  %v7 = select i1 true, i64 8, i64 8
  %v8 = mul nuw i64 %v6, %v7
  %v9 = trunc i64 %v8 to i32
  %v10 = select i1 true, i64 255, i64 255
  %t0 = zext i32 %v9 to i64
  %v11 = shl i64 %v10, %t0
  %v12 = xor i64 %v11, -1
  %t1 = zext i32 %v9 to i64
  %v13 = shl i64 %v2, %t1
  %t2 = getelementptr inbounds %wf.t.b5efdacbe94e5739, ptr %v0, i32 0, i32 1
  %v14 = getelementptr i8, ptr %t2, i64 0
  %t4 = getelementptr inbounds { i64, [1 x ptr] }, ptr %v14, i32 0, i32 0
  %t3 = load i64, ptr %t4
  %v15 = add i64 %t3, 0
  %v16 = select i1 true, i64 0, i64 0
  %v17 = icmp eq i64 %v15, %v16
  switch i1 %v17, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v18 = phi ptr [ %v0, %bb3 ]
  %v19 = phi i64 [ %v1, %bb3 ]
  %v20 = phi i64 [ %v2, %bb3 ]
  %v21 = phi i64 [ %v4, %bb3 ]
  %v22 = phi i64 [ %v6, %bb3 ]
  %v23 = phi i64 [ %v8, %bb3 ]
  %v24 = phi i32 [ %v9, %bb3 ]
  %v25 = phi i64 [ %v11, %bb3 ]
  %v26 = phi i64 [ %v12, %bb3 ]
  %v27 = phi i64 [ %v13, %bb3 ]
  %t5 = getelementptr inbounds %wf.t.b5efdacbe94e5739, ptr %v18, i32 0, i32 1
  %v46 = getelementptr i8, ptr %t5, i64 0
  %v47 = select i1 true, i64 0, i64 0
  %t6.nonnegative = icmp sge i64 %v47, 0
  call void @llvm.assume(i1 %t6.nonnegative)
  %t6 = getelementptr inbounds { i64, [1 x ptr] }, ptr %v46, i64 0, i32 1, i64 %v47
  %v48 = getelementptr i8, ptr %t6, i64 0
  %v49 = getelementptr i8, ptr %v48, i64 0
  %t7 = load ptr, ptr %v49
  %t8 = getelementptr inbounds { i64, [0 x i64] }, ptr %t7, i32 0, i32 0
  %v50 = load i64, ptr %t8
  %v51 = icmp ult i64 %v21, %v50
  switch i1 %v51, label %invalid.tag.b1 [
    i1 1, label %bb8
    i1 0, label %bb9
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v28 = select i1 true, i64 0, i64 0
  %v29 = icmp eq i64 %v4, %v28
  switch i1 %v29, label %invalid.tag.b2 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b2:
  call void @abort()
  unreachable
bb3:
  br label %bb1
bb4:
  %v30 = phi ptr [ %v0, %bb5 ], [ %v0, %bb6 ]
  %v31 = phi i64 [ %v1, %bb5 ], [ %v1, %bb6 ]
  %v32 = phi i64 [ %v2, %bb5 ], [ %v2, %bb6 ]
  %v33 = phi i64 [ %v4, %bb5 ], [ %v4, %bb6 ]
  %v34 = phi i64 [ %v6, %bb5 ], [ %v6, %bb6 ]
  %v35 = phi i64 [ %v8, %bb5 ], [ %v8, %bb6 ]
  %v36 = phi i32 [ %v9, %bb5 ], [ %v9, %bb6 ]
  %v37 = phi i64 [ %v11, %bb5 ], [ %v11, %bb6 ]
  %v38 = phi i64 [ %v12, %bb5 ], [ %v12, %bb6 ]
  %v39 = phi i64 [ %v13, %bb5 ], [ %v13, %bb6 ]
  %v45 = select i1 true, i8 0, i8 0
  ret i8 %v45
bb5:
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.b5efdacbe94e5739, ptr null, i32 1) to i64), i1 false)
  %t9 = getelementptr inbounds %wf.t.b5efdacbe94e5739, ptr %wf.slot.0, i32 0, i32 0
  %v41 = load i64, ptr %t9
  %v42 = and i64 %v41, %v12
  %t10 = getelementptr inbounds %wf.t.b5efdacbe94e5739, ptr %v0, i32 0, i32 0
  %v43 = getelementptr i8, ptr %t10, i64 0
  %v44 = or i64 %v42, %v13
  store i64 %v44, ptr %v43
  br label %bb4
bb6:
  br label %bb4
bb7:
  %v52 = phi ptr [ %v18, %bb8 ], [ %v73, %bb10 ]
  %v53 = phi i64 [ %v19, %bb8 ], [ %v74, %bb10 ]
  %v54 = phi i64 [ %v20, %bb8 ], [ %v75, %bb10 ]
  %v55 = phi i64 [ %v21, %bb8 ], [ %v76, %bb10 ]
  %v56 = phi i64 [ %v22, %bb8 ], [ %v77, %bb10 ]
  %v57 = phi i64 [ %v23, %bb8 ], [ %v78, %bb10 ]
  %v58 = phi i32 [ %v24, %bb8 ], [ %v79, %bb10 ]
  %v59 = phi i64 [ %v25, %bb8 ], [ %v80, %bb10 ]
  %v60 = phi i64 [ %v26, %bb8 ], [ %v81, %bb10 ]
  %v61 = phi i64 [ %v27, %bb8 ], [ %v82, %bb10 ]
  %v62 = phi ptr [ %v48, %bb8 ], [ %v83, %bb10 ]
  %v89 = select i1 true, i8 0, i8 0
  ret i8 %v89
bb8:
  %v63 = getelementptr i8, ptr %v48, i64 0
  %t11 = load ptr, ptr %v63
  %t12 = getelementptr inbounds { i64, [0 x i64] }, ptr %t11, i64 0, i32 1, i64 %v21
  %v64 = getelementptr i8, ptr %t12, i64 0
  %v65 = load i64, ptr %v64
  %v66 = and i64 %v65, %v26
  %v67 = getelementptr i8, ptr %v48, i64 0
  %t13 = load ptr, ptr %v67
  %t14 = getelementptr inbounds { i64, [0 x i64] }, ptr %t13, i64 0, i32 1, i64 %v21
  %v68 = getelementptr i8, ptr %t14, i64 0
  %v69 = or i64 %v66, %v27
  store i64 %v69, ptr %v68
  br label %bb7
bb9:
  %v70 = getelementptr i8, ptr %v48, i64 0
  %t15 = load ptr, ptr %v70
  %t16 = getelementptr inbounds { i64, [0 x i64] }, ptr %t15, i32 0, i32 0
  %v71 = load i64, ptr %t16
  %v72 = icmp eq i64 %v21, %v71
  switch i1 %v72, label %invalid.tag.b9 [
    i1 1, label %bb11
    i1 0, label %bb12
  ]
invalid.tag.b9:
  call void @abort()
  unreachable
bb10:
  %v73 = phi ptr [ %v18, %bb11 ], [ %v18, %bb12 ]
  %v74 = phi i64 [ %v19, %bb11 ], [ %v19, %bb12 ]
  %v75 = phi i64 [ %v20, %bb11 ], [ %v20, %bb12 ]
  %v76 = phi i64 [ %v21, %bb11 ], [ %v21, %bb12 ]
  %v77 = phi i64 [ %v22, %bb11 ], [ %v22, %bb12 ]
  %v78 = phi i64 [ %v23, %bb11 ], [ %v23, %bb12 ]
  %v79 = phi i32 [ %v24, %bb11 ], [ %v24, %bb12 ]
  %v80 = phi i64 [ %v25, %bb11 ], [ %v25, %bb12 ]
  %v81 = phi i64 [ %v26, %bb11 ], [ %v26, %bb12 ]
  %v82 = phi i64 [ %v27, %bb11 ], [ %v27, %bb12 ]
  %v83 = phi ptr [ %v48, %bb11 ], [ %v48, %bb12 ]
  br label %bb7
bb11:
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v18, i64 ptrtoint (ptr getelementptr (%wf.t.b5efdacbe94e5739, ptr null, i32 1) to i64), i1 false)
  %t17 = getelementptr inbounds %wf.t.b5efdacbe94e5739, ptr %wf.slot.1, i32 0, i32 0
  %v85 = load i64, ptr %t17
  %v86 = and i64 %v85, %v26
  %t18 = getelementptr inbounds %wf.t.b5efdacbe94e5739, ptr %v18, i32 0, i32 0
  %v87 = getelementptr i8, ptr %t18, i64 0
  %v88 = or i64 %v86, %v27
  store i64 %v88, ptr %v87
  br label %bb10
bb12:
  br label %bb10
}

define i64 @wf_hash_map.hash_map_control_equal(i64 %v0, i64 %v1) #0 {
entry:
  %v2 = select i1 true, i64 72340172838076673, i64 72340172838076673
  %v3 = mul i64 %v1, %v2
  %v4 = xor i64 %v0, %v3
  %v5 = select i1 true, i64 9187201950435737471, i64 9187201950435737471
  %v6 = and i64 %v4, %v5
  %v7 = select i1 true, i64 9187201950435737471, i64 9187201950435737471
  %v8 = add i64 %v6, %v7
  %v9 = or i64 %v8, %v4
  %v10 = select i1 true, i64 9187201950435737471, i64 9187201950435737471
  %v11 = or i64 %v9, %v10
  %v12 = xor i64 %v11, -1
  %v13 = select i1 true, i64 9259542123273814144, i64 9259542123273814144
  %v14 = and i64 %v12, %v13
  ret i64 %v14
}

define i64 @wf_hash_map.hash_map_control_span(i64 %v0, i64 %v1, i64 %v2) #0 {
entry:
  %v3 = select i1 true, i64 8, i64 8
  %v4 = sub nuw i64 %v3, %v0
  %v5 = icmp ugt i64 %v4, %v1
  switch i1 %v5, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v6 = phi i64 [ %v0, %bb2 ], [ %v0, %bb3 ]
  %v7 = phi i64 [ %v1, %bb2 ], [ %v1, %bb3 ]
  %v8 = phi i64 [ %v2, %bb2 ], [ %v2, %bb3 ]
  %v9 = phi i64 [ %v1, %bb2 ], [ %v4, %bb3 ]
  %v10 = icmp ugt i64 %v9, %v8
  switch i1 %v10, label %invalid.tag.b1 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  br label %bb1
bb3:
  br label %bb1
bb4:
  %v11 = phi i64 [ %v6, %bb5 ], [ %v6, %bb6 ]
  %v12 = phi i64 [ %v7, %bb5 ], [ %v7, %bb6 ]
  %v13 = phi i64 [ %v8, %bb5 ], [ %v8, %bb6 ]
  %v14 = phi i64 [ %v8, %bb5 ], [ %v9, %bb6 ]
  ret i64 %v14
bb5:
  br label %bb4
bb6:
  br label %bb4
}

define i64 @wf_hash_map.hash_map_control_active(i64 %v0, i64 %v1) #0 {
entry:
  %v2 = select i1 true, i64 8, i64 8
  %v3 = mul nuw i64 %v1, %v2
  %v4 = trunc i64 %v3 to i32
  %v5 = select i1 true, i32 64, i32 64
  %v6 = sub nuw i32 %v5, %v4
  %v7 = select i1 true, i64 9259542123273814144, i64 9259542123273814144
  %t0 = zext i32 %v6 to i64
  %v8 = lshr i64 %v7, %t0
  %v9 = select i1 true, i64 8, i64 8
  %v10 = mul nuw i64 %v0, %v9
  %v11 = trunc i64 %v10 to i32
  %t1 = zext i32 %v11 to i64
  %v12 = shl i64 %v8, %t1
  ret i64 %v12
}

define i64 @wf_hash_map.hash_map_control_first(i64 %v0) #0 {
entry:
  %t0 = call i64 @llvm.cttz.i64(i64 %v0, i1 false)
  %v1 = trunc i64 %t0 to i32
  %v2 = select i1 true, i32 8, i32 8
  %v3 = udiv i32 %v1, %v2
  %v4 = zext i32 %v3 to i64
  ret i64 %v4
}

define i64 @wf_hash_map.hash_map_control_stop(i64 %v0, i64 %v1, i64 %v2) #0 {
entry:
  %v3 = select i1 true, i64 0, i64 0
  %v4 = icmp ugt i64 %v0, %v3
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v5 = phi i64 [ %v0, %bb3 ], [ %v10, %bb4 ]
  %v6 = phi i64 [ %v1, %bb3 ], [ %v11, %bb4 ]
  %v7 = phi i64 [ %v2, %bb3 ], [ %v12, %bb4 ]
  ret i64 %v7
bb2:
  %v8 = call i64 @wf_hash_map.hash_map_control_first(i64 %v0)
  %v9 = icmp uge i64 %v8, %v1
  switch i1 %v9, label %invalid.tag.b2 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b2:
  call void @abort()
  unreachable
bb3:
  br label %bb1
bb4:
  %v10 = phi i64 [ %v0, %bb6 ], [ %v16, %bb7 ]
  %v11 = phi i64 [ %v1, %bb6 ], [ %v17, %bb7 ]
  %v12 = phi i64 [ %v2, %bb6 ], [ %v18, %bb7 ]
  %v13 = phi i64 [ %v8, %bb6 ], [ %v19, %bb7 ]
  br label %bb1
bb5:
  %v14 = sub nuw i64 %v8, %v1
  %v15 = icmp ult i64 %v14, %v2
  switch i1 %v15, label %invalid.tag.b5 [
    i1 1, label %bb8
    i1 0, label %bb9
  ]
invalid.tag.b5:
  call void @abort()
  unreachable
bb6:
  br label %bb4
bb7:
  %v16 = phi i64 [ %v0, %bb9 ]
  %v17 = phi i64 [ %v1, %bb9 ]
  %v18 = phi i64 [ %v2, %bb9 ]
  %v19 = phi i64 [ %v8, %bb9 ]
  %v20 = phi i64 [ %v14, %bb9 ]
  br label %bb4
bb8:
  ret i64 %v14
bb9:
  br label %bb7
}

define i64 @wf_hash_map.hash_map_probe(i64 %v0, i64 %v1, i64 %v2) #0 {
entry:
  %v3 = sub nuw i64 %v2, %v0
  %v4 = icmp uge i64 %v1, %v3
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v5 = phi i64 [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb3 ]
  %v7 = phi i64 [ %v2, %bb3 ]
  %v8 = phi i64 [ %v3, %bb3 ]
  %v10 = add nuw i64 %v5, %v6
  ret i64 %v10
bb2:
  %v9 = sub nuw i64 %v1, %v3
  ret i64 %v9
bb3:
  br label %bb1
}

define void @wf_carrier_main(ptr %wf.result) #0 {
entry:
  call void @wf_main(ptr %wf.result)
  %v1 = select i1 true, i64 3, i64 3
  %v2 = select i1 true, i64 2, i64 2
  %v3 = select i1 true, i64 17, i64 17
  %v4 = call i64 @wf_map_cost_library_word_geometry(i64 %v1, i64 %v2, i64 %v3)
  %v5 = select i1 true, i64 3, i64 3
  %v6 = select i1 true, i64 2, i64 2
  %v7 = select i1 true, i64 17, i64 17
  %v8 = call i64 @wf_map_cost_library_record_geometry(i64 %v5, i64 %v6, i64 %v7)
  ret void
}

define i64 @wf_map_cost_mix(i64 %v0) #0 {
entry:
  %v1 = select i1 true, i32 30, i32 30
  %t0 = zext i32 %v1 to i64
  %v2 = lshr i64 %v0, %t0
  %v3 = xor i64 %v0, %v2
  %v4 = select i1 true, i64 13787848793156543929, i64 13787848793156543929
  %v5 = mul i64 %v3, %v4
  %v6 = select i1 true, i32 27, i32 27
  %t1 = zext i32 %v6 to i64
  %v7 = lshr i64 %v5, %t1
  %v8 = xor i64 %v5, %v7
  %v9 = select i1 true, i64 10723151780598845931, i64 10723151780598845931
  %v10 = mul i64 %v8, %v9
  %v11 = select i1 true, i32 31, i32 31
  %t2 = zext i32 %v11 to i64
  %v12 = lshr i64 %v10, %t2
  %v13 = xor i64 %v10, %v12
  ret i64 %v13
}

define i64 @wf_map_cost_hash(ptr noalias nonnull captures(none) dereferenceable(16) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.ee6ca7dc0a065510, align 8
  %wf.slot.1 = alloca %wf.t.ee6ca7dc0a065510, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.ee6ca7dc0a065510, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %wf.slot.0, i32 0, i32 1
  %v3 = load i1, ptr %t0
  switch i1 %v3, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v4 = phi ptr [ %v0, %bb3 ]
  %v5 = phi ptr [ %v1, %bb3 ]
  %v7 = load i64, ptr %v5
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v4, i64 ptrtoint (ptr getelementptr (%wf.t.ee6ca7dc0a065510, ptr null, i32 1) to i64), i1 false)
  %t1 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %wf.slot.1, i32 0, i32 0
  %v9 = load i64, ptr %t1
  %v10 = xor i64 %v7, %v9
  %v11 = call i64 @wf_map_cost_mix(i64 %v10)
  ret i64 %v11
bb2:
  %v6 = select i1 true, i64 0, i64 0
  ret i64 %v6
bb3:
  br label %bb1
}

define i1 @wf_map_cost_equal(ptr noalias nonnull captures(none) dereferenceable(16) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(8) %v2) #0 {
entry:
  %v3 = load i64, ptr %v1
  %v4 = load i64, ptr %v2
  %v5 = icmp eq i64 %v3, %v4
  ret i1 %v5
}

define i64 @wf_map_cost_key(i64 %v0) #0 {
entry:
  %v1 = select i1 true, i64 2, i64 2
  %v2 = mul i64 %v0, %v1
  %v3 = select i1 true, i64 1, i64 1
  %v4 = add i64 %v2, %v3
  ret i64 %v4
}

define i8 @wf_map_cost_ordered(ptr noalias nonnull captures(none) dereferenceable(32) %v0, i64 %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.84597570beb237fa, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %wf.slot.0, i32 0, i32 0
  %v3 = load i64, ptr %t0
  %v4 = select i1 true, i64 131, i64 131
  %v5 = mul i64 %v3, %v4
  %t1 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v0, i32 0, i32 0
  %v6 = getelementptr i8, ptr %t1, i64 0
  %v7 = add i64 %v5, %v1
  store i64 %v7, ptr %v6
  %v8 = select i1 true, i8 0, i8 0
  ret i8 %v8
}

define i8 @wf_map_cost_final(ptr noalias nonnull captures(none) dereferenceable(32) %v0, i64 %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.84597570beb237fa, align 8
  %wf.slot.1 = alloca %wf.t.84597570beb237fa, align 8
  %wf.slot.2 = alloca %wf.t.84597570beb237fa, align 8
  %t0 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v0, i32 0, i32 1
  %v2 = getelementptr i8, ptr %t0, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %t1 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %wf.slot.0, i32 0, i32 1
  %v4 = load i64, ptr %t1
  %v5 = add i64 %v4, %v1
  store i64 %v5, ptr %v2
  %v6 = call i64 @wf_map_cost_mix(i64 %v1)
  %t2 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v0, i32 0, i32 2
  %v7 = getelementptr i8, ptr %t2, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %t3 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %wf.slot.1, i32 0, i32 2
  %v9 = load i64, ptr %t3
  %v10 = xor i64 %v9, %v6
  store i64 %v10, ptr %v7
  %t4 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v0, i32 0, i32 3
  %v11 = getelementptr i8, ptr %t4, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %t5 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %wf.slot.2, i32 0, i32 3
  %v13 = load i64, ptr %t5
  %v14 = select i1 true, i64 1, i64 1
  %v15 = add i64 %v13, %v14
  store i64 %v15, ptr %v11
  %v16 = select i1 true, i8 0, i8 0
  ret i8 %v16
}

define i64 @wf_map_cost_finish(ptr %wf.arg.v0) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.84597570beb237fa, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v0, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %wf.slot.0, i32 0, i32 0
  %v1 = load i64, ptr %t0
  %v2 = call i64 @wf_map_cost_mix(i64 %v1)
  %t1 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %wf.slot.0, i32 0, i32 1
  %v3 = load i64, ptr %t1
  %v4 = call i64 @wf_map_cost_mix(i64 %v3)
  %v5 = xor i64 %v2, %v4
  %t2 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %wf.slot.0, i32 0, i32 2
  %v6 = load i64, ptr %t2
  %v7 = xor i64 %v5, %v6
  %t3 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %wf.slot.0, i32 0, i32 3
  %v8 = load i64, ptr %t3
  %v9 = select i1 true, i64 11400714819323198485, i64 11400714819323198485
  %v10 = mul i64 %v8, %v9
  %v11 = xor i64 %v7, %v10
  ret i64 %v11
}

define i64 @wf_map_cost_word_make(i64 %v0) #0 {
entry:
  ret i64 %v0
}

define i64 @wf_map_cost_word_content(i64 %v0, i64 %v1) #0 {
entry:
  %v2 = select i1 true, i64 131, i64 131
  %v3 = mul i64 %v0, %v2
  %v4 = add i64 %v3, %v1
  ret i64 %v4
}

define i64 @wf_map_cost_word_observe(ptr noalias nonnull captures(none) dereferenceable(32) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(8) %v2) #0 {
entry:
  %v3 = load i64, ptr %v2
  ret i64 %v3
}

define i64 @wf_map_cost_word_edit(ptr noalias nonnull captures(none) dereferenceable(32) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(8) %v2) #0 {
entry:
  %v3 = load i64, ptr %v2
  %v4 = select i1 true, i64 1, i64 1
  %v5 = add i64 %v3, %v4
  store i64 %v5, ptr %v2
  %v6 = load i64, ptr %v2
  ret i64 %v6
}

define i8 @wf_map_cost_word_consume(ptr noalias nonnull captures(none) dereferenceable(32) %v0, i64 %v1, i64 %v2) #0 {
entry:
  %v3 = call i64 @wf_map_cost_word_content(i64 %v1, i64 %v2)
  %v4 = call i8 @wf_map_cost_final(ptr %v0, i64 %v3)
  %v5 = select i1 true, i8 0, i8 0
  ret i8 %v5
}

define void @wf_map_cost_record_make(ptr %wf.result, i64 %v0) #0 {
entry:
  %wf.slot.0 = alloca [32 x i64], align 8
  %v3 = alloca [32 x i64], align 8
  %v1 = select i1 true, i64 0, i64 0
  call void @wf_array_filled$instance$581665c886d1d2c8(ptr %v3, i64 %v1)
  %v4 = select i1 true, i64 0, i64 0
  %v5 = select i1 true, i64 32, i64 32
  br label %bb1
bb1:
  %v6 = phi i64 [ %v0, %entry ], [ %v16, %bb5 ]
  %v7 = phi ptr [ %v3, %entry ], [ %v17, %bb5 ]
  %v8 = phi i64 [ %v4, %entry ], [ %v18, %bb5 ]
  %v9 = phi i64 [ %v5, %entry ], [ %v19, %bb5 ]
  %v10 = phi i64 [ %v4, %entry ], [ %v22, %bb5 ]
  %v13 = icmp ult i64 %v10, %v9
  switch i1 %v13, label %invalid.tag.b1 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %t0 = getelementptr inbounds [32 x i64], ptr %v7, i64 0, i64 %v10
  %v14 = getelementptr i8, ptr %t0, i64 0
  %v15 = add i64 %v6, %v10
  store i64 %v15, ptr %v14
  br label %bb5
bb3:
  br label %bb4
bb4:
  %v11 = phi i64 [ %v6, %bb3 ]
  %v12 = phi ptr [ %v7, %bb3 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v12, i64 ptrtoint (ptr getelementptr ([32 x i64], ptr null, i32 1) to i64), i1 false)
  store %wf.t.862971f7a971a883 zeroinitializer, ptr %wf.result
  %t1 = getelementptr inbounds %wf.t.862971f7a971a883, ptr %wf.result, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %t1, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr ([32 x i64], ptr null, i32 1) to i64), i1 false)
  ret void
bb5:
  %v16 = phi i64 [ %v6, %bb2 ]
  %v17 = phi ptr [ %v7, %bb2 ]
  %v18 = phi i64 [ %v8, %bb2 ]
  %v19 = phi i64 [ %v9, %bb2 ]
  %v20 = phi i64 [ %v10, %bb2 ]
  %v21 = select i1 true, i64 1, i64 1
  %v22 = add i64 %v20, %v21
  br label %bb1
}

define i64 @wf_map_cost_record_content(i64 %v0, ptr %wf.arg.v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.862971f7a971a883, align 8
  %v2 = alloca %wf.t.862971f7a971a883, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v1, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %v2, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %v3 = select i1 true, i64 0, i64 0
  %v4 = select i1 true, i64 32, i64 32
  br label %bb1
bb1:
  %v5 = phi i64 [ %v0, %entry ], [ %v21, %bb5 ]
  %v6 = phi ptr [ %v2, %entry ], [ %v22, %bb5 ]
  %v7 = phi i64 [ %v0, %entry ], [ %v23, %bb5 ]
  %v8 = phi i64 [ %v3, %entry ], [ %v24, %bb5 ]
  %v9 = phi i64 [ %v4, %entry ], [ %v25, %bb5 ]
  %v10 = phi i64 [ %v3, %entry ], [ %v28, %bb5 ]
  %v14 = icmp ult i64 %v10, %v9
  switch i1 %v14, label %invalid.tag.b1 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v15 = select i1 true, i64 131, i64 131
  %v16 = mul i64 %v7, %v15
  %t0 = getelementptr inbounds %wf.t.862971f7a971a883, ptr %v6, i32 0, i32 0
  %v17 = getelementptr i8, ptr %t0, i64 0
  %t1 = getelementptr inbounds [32 x i64], ptr %v17, i64 0, i64 %v10
  %v18 = getelementptr i8, ptr %t1, i64 0
  %v19 = load i64, ptr %v18
  %v20 = add i64 %v16, %v19
  br label %bb5
bb3:
  br label %bb4
bb4:
  %v11 = phi i64 [ %v5, %bb3 ]
  %v12 = phi ptr [ %v6, %bb3 ]
  %v13 = phi i64 [ %v7, %bb3 ]
  ; drop %v12
  ret i64 %v13
bb5:
  %v21 = phi i64 [ %v5, %bb2 ]
  %v22 = phi ptr [ %v6, %bb2 ]
  %v23 = phi i64 [ %v20, %bb2 ]
  %v24 = phi i64 [ %v8, %bb2 ]
  %v25 = phi i64 [ %v9, %bb2 ]
  %v26 = phi i64 [ %v10, %bb2 ]
  %v27 = select i1 true, i64 1, i64 1
  %v28 = add i64 %v26, %v27
  br label %bb1
}

define i64 @wf_map_cost_record_observe(ptr noalias nonnull captures(none) dereferenceable(32) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(256) %v2) #0 {
entry:
  %t0 = getelementptr inbounds %wf.t.862971f7a971a883, ptr %v2, i32 0, i32 0
  %v3 = getelementptr i8, ptr %t0, i64 0
  %v4 = select i1 true, i64 0, i64 0
  %t1 = getelementptr inbounds [32 x i64], ptr %v3, i64 0, i64 %v4
  %v5 = getelementptr i8, ptr %t1, i64 0
  %v6 = load i64, ptr %v5
  ret i64 %v6
}

define i64 @wf_map_cost_record_edit(ptr noalias nonnull captures(none) dereferenceable(32) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(256) %v2) #0 {
entry:
  %t0 = getelementptr inbounds %wf.t.862971f7a971a883, ptr %v2, i32 0, i32 0
  %v3 = getelementptr i8, ptr %t0, i64 0
  %v4 = select i1 true, i64 0, i64 0
  %t1 = getelementptr inbounds [32 x i64], ptr %v3, i64 0, i64 %v4
  %v5 = getelementptr i8, ptr %t1, i64 0
  %t2 = getelementptr inbounds %wf.t.862971f7a971a883, ptr %v2, i32 0, i32 0
  %v6 = getelementptr i8, ptr %t2, i64 0
  %v7 = select i1 true, i64 0, i64 0
  %t3 = getelementptr inbounds [32 x i64], ptr %v6, i64 0, i64 %v7
  %v8 = getelementptr i8, ptr %t3, i64 0
  %v9 = load i64, ptr %v8
  %v10 = select i1 true, i64 1, i64 1
  %v11 = add i64 %v9, %v10
  store i64 %v11, ptr %v5
  %t4 = getelementptr inbounds %wf.t.862971f7a971a883, ptr %v2, i32 0, i32 0
  %v12 = getelementptr i8, ptr %t4, i64 0
  %v13 = select i1 true, i64 0, i64 0
  %t5 = getelementptr inbounds [32 x i64], ptr %v12, i64 0, i64 %v13
  %v14 = getelementptr i8, ptr %t5, i64 0
  %v15 = load i64, ptr %v14
  ret i64 %v15
}

define i8 @wf_map_cost_record_consume(ptr noalias nonnull captures(none) dereferenceable(32) %v0, i64 %v1, ptr %wf.arg.v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.862971f7a971a883, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v2, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %v3 = call i64 @wf_map_cost_record_content(i64 %v1, ptr %wf.slot.0)
  %v4 = call i8 @wf_map_cost_final(ptr %v0, i64 %v3)
  %v5 = select i1 true, i8 0, i8 0
  ret i8 %v5
}

define i8 @wf_map_cost_lookup_result(ptr %wf.arg.v0, ptr noalias nonnull captures(none) dereferenceable(32) %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.b7e1ed626c09888a, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v0, i64 ptrtoint (ptr getelementptr (%wf.t.b7e1ed626c09888a, ptr null, i32 1) to i64), i1 false)
  %t0 = load %wf.t.b7e1ed626c09888a, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.b7e1ed626c09888a %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb2
    i32 1, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v3 = phi ptr [ %v1, %bb2 ], [ %v1, %bb3 ]
  %v11 = select i1 true, i8 0, i8 0
  ret i8 %v11
bb2:
  %t2 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.slot.0, i32 0, i32 1
  %v4 = load i64, ptr %t2
  %v5 = select i1 true, i64 1, i64 1
  %v6 = call i8 @wf_map_cost_ordered(ptr %v1, i64 %v5)
  %v7 = call i8 @wf_map_cost_ordered(ptr %v1, i64 %v4)
  br label %bb1
bb3:
  %t3 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.slot.0, i32 0, i32 2
  %v8 = load i8, ptr %t3
  %v9 = select i1 true, i64 0, i64 0
  %v10 = call i8 @wf_map_cost_ordered(ptr %v1, i64 %v9)
  br label %bb1
}

define i8 @wf_map_cost_rebuild_result(ptr %wf.arg.v0, ptr noalias nonnull captures(none) dereferenceable(32) %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.7d7f918f7b4962fd, align 4
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v0, i64 ptrtoint (ptr getelementptr (%wf.t.7d7f918f7b4962fd, ptr null, i32 1) to i64), i1 false)
  %t0 = load %wf.t.7d7f918f7b4962fd, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.7d7f918f7b4962fd %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb2
    i32 1, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v3 = phi ptr [ %v1, %bb2 ], [ %v1, %bb3 ]
  %v10 = select i1 true, i8 0, i8 0
  ret i8 %v10
bb2:
  %t2 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.slot.0, i32 0, i32 1
  %v4 = load i8, ptr %t2
  %v5 = select i1 true, i64 1, i64 1
  %v6 = call i8 @wf_map_cost_ordered(ptr %v1, i64 %v5)
  br label %bb1
bb3:
  %t3 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.slot.0, i32 0, i32 2
  %v7 = load i8, ptr %t3
  %v8 = select i1 true, i64 0, i64 0
  %v9 = call i8 @wf_map_cost_ordered(ptr %v1, i64 %v8)
  br label %bb1
}

define i64 @wf_map_cost_library_word_trace(i64 %v0, i64 %v1, i64 %v2, i64 %v3, i64 %v4, i64 %v5) #0 {
entry:
  %v6 = select i1 true, i64 8, i64 8
  %v7 = icmp eq i64 %v4, %v6
  switch i1 %v7, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v8 = phi i64 [ %v0, %bb3 ]
  %v9 = phi i64 [ %v1, %bb3 ]
  %v10 = phi i64 [ %v2, %bb3 ]
  %v11 = phi i64 [ %v3, %bb3 ]
  %v12 = phi i64 [ %v4, %bb3 ]
  %v13 = phi i64 [ %v5, %bb3 ]
  %v15 = call i64 @wf_map_cost_library_trace$instance$c7c8cd11e7f079bd(i64 %v8, i64 %v9, i64 %v10, i64 %v11, i64 %v12, i64 %v13)
  ret i64 %v15
bb2:
  %v14 = call i64 @wf_map_cost_library_policy$instance$c7c8cd11e7f079bd(i64 %v3, i64 %v5)
  ret i64 %v14
bb3:
  br label %bb1
}

define i64 @wf_map_cost_library_record_trace(i64 %v0, i64 %v1, i64 %v2, i64 %v3, i64 %v4, i64 %v5) #0 {
entry:
  %v6 = select i1 true, i64 8, i64 8
  %v7 = icmp eq i64 %v4, %v6
  switch i1 %v7, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v8 = phi i64 [ %v0, %bb3 ]
  %v9 = phi i64 [ %v1, %bb3 ]
  %v10 = phi i64 [ %v2, %bb3 ]
  %v11 = phi i64 [ %v3, %bb3 ]
  %v12 = phi i64 [ %v4, %bb3 ]
  %v13 = phi i64 [ %v5, %bb3 ]
  %v15 = call i64 @wf_map_cost_library_trace$instance$4250cb78d3f44027(i64 %v8, i64 %v9, i64 %v10, i64 %v11, i64 %v12, i64 %v13)
  ret i64 %v15
bb2:
  %v14 = call i64 @wf_map_cost_library_policy$instance$4250cb78d3f44027(i64 %v3, i64 %v5)
  ret i64 %v14
bb3:
  br label %bb1
}

define i64 @wf_map_cost_library_word_geometry(i64 %v0, i64 %v1, i64 %v2) #0 {
entry:
  %v3 = call i64 @wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd(i64 %v0, i64 %v1, i64 %v2)
  ret i64 %v3
}

define i64 @wf_map_cost_library_record_geometry(i64 %v0, i64 %v1, i64 %v2) #0 {
entry:
  %v3 = call i64 @wf_map_cost_library_geometry$instance$4250cb78d3f44027(i64 %v0, i64 %v1, i64 %v2)
  ret i64 %v3
}

define void @wf_main(ptr %wf.result) #0 {
entry:
  %v0 = select i1 true, i64 3, i64 3
  %v1 = select i1 true, i64 2, i64 2
  %v2 = select i1 true, i64 2, i64 2
  %v3 = select i1 true, i64 17, i64 17
  %v4 = select i1 true, i64 7, i64 7
  %v5 = select i1 true, i64 0, i64 0
  %v6 = call i64 @wf_map_cost_library_word_trace(i64 %v0, i64 %v1, i64 %v2, i64 %v3, i64 %v4, i64 %v5)
  %v7 = select i1 true, i64 3, i64 3
  %v8 = select i1 true, i64 2, i64 2
  %v9 = select i1 true, i64 2, i64 2
  %v10 = select i1 true, i64 17, i64 17
  %v11 = select i1 true, i64 3, i64 3
  %v12 = select i1 true, i64 1, i64 1
  %v13 = call i64 @wf_map_cost_library_record_trace(i64 %v7, i64 %v8, i64 %v9, i64 %v10, i64 %v11, i64 %v12)
  %v14 = select i1 true, i8 0, i8 0
  call void @wf_std.process.exit_status(ptr %wf.result, i8 %v14)
  ret void
}

declare void @wf_std.process.exit_status(ptr %wf.result, i8 %v0)

define void @wf_array_filled$instance$581665c886d1d2c8(ptr %wf.result, i64 %v0) #0 {
entry:
  %wf.slot.0 = alloca i64, align 8
  store i64 0, ptr %wf.slot.0
  br label %array.fill.head.v1
array.fill.head.v1:
  %t0 = load i64, ptr %wf.slot.0
  %t1 = icmp ult i64 %t0, 32
  br i1 %t1, label %array.fill.body.v1, label %array.fill.done.v1
array.fill.body.v1:
  %t2 = getelementptr inbounds [32 x i64], ptr %wf.result, i64 0, i64 %t0
  store i64 %v0, ptr %t2
  %t3 = add i64 %t0, 1
  store i64 %t3, ptr %wf.slot.0
  br label %array.fill.head.v1
array.fill.done.v1:
  ret void
}

define i64 @wf_map_cost_library_policy$instance$c7c8cd11e7f079bd(i64 %v0, i64 %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.ac5891a387b8aafe, align 8
  %wf.slot.1 = alloca %wf.t.ac5891a387b8aafe, align 8
  %wf.slot.2 = alloca %wf.t.ac5891a387b8aafe, align 8
  %wf.slot.3 = alloca %wf.t.2758c7c2b3b908fb, align 8
  %wf.slot.4 = alloca %wf.t.84597570beb237fa, align 8
  %v7 = alloca %wf.t.ee6ca7dc0a065510, align 8
  %v10 = alloca %wf.t.2758c7c2b3b908fb, align 8
  %v15 = alloca %wf.t.84597570beb237fa, align 8
  %v2 = select i1 true, i64 11400714819323198485, i64 11400714819323198485
  %v3 = xor i64 %v0, %v2
  %v4 = select i1 true, i64 0, i64 0
  %v5 = icmp ne i64 %v1, %v4
  store %wf.t.ee6ca7dc0a065510 zeroinitializer, ptr %v7
  %t0 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v7, i32 0, i32 0
  store i64 %v3, ptr %t0
  %t1 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v7, i32 0, i32 1
  store i1 %v5, ptr %t1
  %v8 = select i1 true, i64 3, i64 3
  call void @wf_hash_map.hash_map_new$instance$a62a753cf2b0b5ca(ptr %v10, i64 %v8)
  %v11 = select i1 true, i64 0, i64 0
  %v12 = select i1 true, i64 0, i64 0
  %v13 = select i1 true, i64 0, i64 0
  store %wf.t.84597570beb237fa zeroinitializer, ptr %v15
  %t2 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v15, i32 0, i32 0
  store i64 %v0, ptr %t2
  %t3 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v15, i32 0, i32 1
  store i64 %v11, ptr %t3
  %t4 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v15, i32 0, i32 2
  store i64 %v12, ptr %t4
  %t5 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v15, i32 0, i32 3
  store i64 %v13, ptr %t5
  %v16 = select i1 true, i64 0, i64 0
  %v17 = select i1 true, i64 3, i64 3
  br label %bb1
bb1:
  %v18 = phi i64 [ %v0, %entry ], [ %v41, %bb5 ]
  %v19 = phi i64 [ %v1, %entry ], [ %v42, %bb5 ]
  %v20 = phi i64 [ %v3, %entry ], [ %v43, %bb5 ]
  %v21 = phi i1 [ %v5, %entry ], [ %v44, %bb5 ]
  %v22 = phi ptr [ %v7, %entry ], [ %v45, %bb5 ]
  %v23 = phi ptr [ %v10, %entry ], [ %v46, %bb5 ]
  %v24 = phi ptr [ %v15, %entry ], [ %v47, %bb5 ]
  %v25 = phi i64 [ %v16, %entry ], [ %v48, %bb5 ]
  %v26 = phi i64 [ %v17, %entry ], [ %v49, %bb5 ]
  %v27 = phi i64 [ %v16, %entry ], [ %v52, %bb5 ]
  %v35 = icmp ult i64 %v27, %v26
  switch i1 %v35, label %invalid.tag.b1 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v36 = call i64 @wf_map_cost_key(i64 %v27)
  %v37 = add i64 %v18, %v27
  %v38 = call i64 @wf_map_cost_word_make(i64 %v37)
  call void @wf_hash_map.hash_map_put$instance$c7b22b9ef52855b6(ptr %wf.slot.0, ptr %v23, i64 %v36, i64 %v38, ptr %v22)
  %v40 = call i8 @wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd(ptr %wf.slot.0, ptr %v24)
  br label %bb5
bb3:
  br label %bb4
bb4:
  %v28 = phi i64 [ %v18, %bb3 ]
  %v29 = phi i64 [ %v19, %bb3 ]
  %v30 = phi i64 [ %v20, %bb3 ]
  %v31 = phi i1 [ %v21, %bb3 ]
  %v32 = phi ptr [ %v22, %bb3 ]
  %v33 = phi ptr [ %v23, %bb3 ]
  %v34 = phi ptr [ %v24, %bb3 ]
  %v53 = select i1 true, i64 10, i64 10
  %v54 = add i64 %v28, %v53
  %v55 = call i64 @wf_map_cost_word_make(i64 %v54)
  %v56 = select i1 true, i64 1, i64 1
  call void @wf_hash_map.hash_map_put$instance$c7b22b9ef52855b6(ptr %wf.slot.1, ptr %v33, i64 %v56, i64 %v55, ptr %v32)
  %v58 = call i8 @wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd(ptr %wf.slot.1, ptr %v34)
  %v59 = select i1 true, i64 20, i64 20
  %v60 = add i64 %v28, %v59
  %v61 = call i64 @wf_map_cost_word_make(i64 %v60)
  %v62 = select i1 true, i64 7, i64 7
  call void @wf_hash_map.hash_map_put$instance$c7b22b9ef52855b6(ptr %wf.slot.2, ptr %v33, i64 %v62, i64 %v61, ptr %v32)
  %v64 = call i8 @wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd(ptr %wf.slot.2, ptr %v34)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.3, ptr %v33, i64 ptrtoint (ptr getelementptr (%wf.t.2758c7c2b3b908fb, ptr null, i32 1) to i64), i1 false)
  %v66 = call i8 @wf_hash_map.hash_map_free$instance$5c6f40d0925a4760(ptr %wf.slot.3, ptr %v34)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.4, ptr %v34, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %v68 = call i64 @wf_map_cost_finish(ptr %wf.slot.4)
  ret i64 %v68
bb5:
  %v41 = phi i64 [ %v18, %bb2 ]
  %v42 = phi i64 [ %v19, %bb2 ]
  %v43 = phi i64 [ %v20, %bb2 ]
  %v44 = phi i1 [ %v21, %bb2 ]
  %v45 = phi ptr [ %v22, %bb2 ]
  %v46 = phi ptr [ %v23, %bb2 ]
  %v47 = phi ptr [ %v24, %bb2 ]
  %v48 = phi i64 [ %v25, %bb2 ]
  %v49 = phi i64 [ %v26, %bb2 ]
  %v50 = phi i64 [ %v27, %bb2 ]
  %v51 = select i1 true, i64 1, i64 1
  %v52 = add i64 %v50, %v51
  br label %bb1
}

define i64 @wf_map_cost_library_trace$instance$c7c8cd11e7f079bd(i64 %v0, i64 %v1, i64 %v2, i64 %v3, i64 %v4, i64 %v5) #0 {
entry:
  %wf.frame = alloca { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, align 8
  %wf.slot.0 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 0
  %wf.slot.1 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 1
  %wf.slot.2 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 2
  %wf.slot.3 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 3
  %wf.slot.4 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 4
  %wf.slot.5 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 5
  %wf.slot.6 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 6
  %wf.slot.7 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 7
  %wf.slot.8 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 8
  %wf.slot.9 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 9
  %wf.slot.10 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 10
  %wf.slot.11 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 11
  %wf.slot.12 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 12
  %wf.slot.13 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 13
  %wf.slot.14 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 14
  %wf.slot.15 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 15
  %wf.slot.16 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 16
  %wf.slot.17 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 17
  %wf.slot.18 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 18
  %wf.slot.19 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 19
  %wf.slot.20 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 20
  %v11 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 21
  %v13 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 22
  %v18 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 23
  %v192 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 24
  %v280 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 25
  %v607 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.743755fb647946cb, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.b7e1ed626c09888a, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.7748a5b0f0193f4a, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 26
  %v6 = select i1 true, i64 11400714819323198485, i64 11400714819323198485
  %v7 = xor i64 %v3, %v6
  %v8 = select i1 true, i64 0, i64 0
  %v9 = icmp ne i64 %v5, %v8
  store %wf.t.ee6ca7dc0a065510 zeroinitializer, ptr %v11
  %t0 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v11, i32 0, i32 0
  store i64 %v7, ptr %t0
  %t1 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v11, i32 0, i32 1
  store i1 %v9, ptr %t1
  call void @wf_hash_map.hash_map_new$instance$820b2044b97e0fbd(ptr %v13, i64 %v0)
  %v14 = select i1 true, i64 0, i64 0
  %v15 = select i1 true, i64 0, i64 0
  %v16 = select i1 true, i64 0, i64 0
  store %wf.t.84597570beb237fa zeroinitializer, ptr %v18
  %t2 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v18, i32 0, i32 0
  store i64 %v3, ptr %t2
  %t3 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v18, i32 0, i32 1
  store i64 %v14, ptr %t3
  %t4 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v18, i32 0, i32 2
  store i64 %v15, ptr %t4
  %t5 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v18, i32 0, i32 3
  store i64 %v16, ptr %t5
  %v19 = select i1 true, i64 0, i64 0
  br label %bb1
bb1:
  %v20 = phi i64 [ %v0, %entry ], [ %v96, %bb11 ]
  %v21 = phi i64 [ %v1, %entry ], [ %v97, %bb11 ]
  %v22 = phi i64 [ %v2, %entry ], [ %v98, %bb11 ]
  %v23 = phi i64 [ %v3, %entry ], [ %v99, %bb11 ]
  %v24 = phi i64 [ %v4, %entry ], [ %v100, %bb11 ]
  %v25 = phi i64 [ %v5, %entry ], [ %v101, %bb11 ]
  %v26 = phi i64 [ %v7, %entry ], [ %v102, %bb11 ]
  %v27 = phi i1 [ %v9, %entry ], [ %v103, %bb11 ]
  %v28 = phi ptr [ %v11, %entry ], [ %v104, %bb11 ]
  %v29 = phi ptr [ %v13, %entry ], [ %v105, %bb11 ]
  %v30 = phi ptr [ %v18, %entry ], [ %v106, %bb11 ]
  %v31 = phi i64 [ %v19, %entry ], [ %v107, %bb11 ]
  %v32 = phi i64 [ %v1, %entry ], [ %v108, %bb11 ]
  %v33 = phi i64 [ %v19, %entry ], [ %v111, %bb11 ]
  %v45 = icmp ult i64 %v33, %v32
  switch i1 %v45, label %invalid.tag.b1 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v46 = call i64 @wf_map_cost_key(i64 %v33)
  %v47 = add i64 %v23, %v33
  %v48 = call i64 @wf_map_cost_word_make(i64 %v47)
  call void @wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad(ptr %wf.slot.0, ptr %v29, i64 %v46, i64 %v48, ptr %v28)
  %t6 = load %wf.t.ac5891a387b8aafe, ptr %wf.slot.0
  %t7 = extractvalue %wf.t.ac5891a387b8aafe %t6, 0
  switch i32 %t7, label %invalid.tag.b2 [
    i32 0, label %bb6
    i32 1, label %bb7
  ]
invalid.tag.b2:
  call void @abort()
  unreachable
bb3:
  br label %bb4
bb4:
  %v34 = phi i64 [ %v20, %bb3 ]
  %v35 = phi i64 [ %v21, %bb3 ]
  %v36 = phi i64 [ %v22, %bb3 ]
  %v37 = phi i64 [ %v23, %bb3 ]
  %v38 = phi i64 [ %v24, %bb3 ]
  %v39 = phi i64 [ %v25, %bb3 ]
  %v40 = phi i64 [ %v26, %bb3 ]
  %v41 = phi i1 [ %v27, %bb3 ]
  %v42 = phi ptr [ %v28, %bb3 ]
  %v43 = phi ptr [ %v29, %bb3 ]
  %v44 = phi ptr [ %v30, %bb3 ]
  %v112 = select i1 true, i64 0, i64 0
  br label %bb12
bb5:
  %v50 = phi i64 [ %v20, %bb6 ], [ %v70, %bb8 ]
  %v51 = phi i64 [ %v21, %bb6 ], [ %v71, %bb8 ]
  %v52 = phi i64 [ %v22, %bb6 ], [ %v72, %bb8 ]
  %v53 = phi i64 [ %v23, %bb6 ], [ %v73, %bb8 ]
  %v54 = phi i64 [ %v24, %bb6 ], [ %v74, %bb8 ]
  %v55 = phi i64 [ %v25, %bb6 ], [ %v75, %bb8 ]
  %v56 = phi i64 [ %v26, %bb6 ], [ %v76, %bb8 ]
  %v57 = phi i1 [ %v27, %bb6 ], [ %v77, %bb8 ]
  %v58 = phi ptr [ %v28, %bb6 ], [ %v78, %bb8 ]
  %v59 = phi ptr [ %v29, %bb6 ], [ %v79, %bb8 ]
  %v60 = phi ptr [ %v30, %bb6 ], [ %v80, %bb8 ]
  %v61 = phi i64 [ %v33, %bb6 ], [ %v81, %bb8 ]
  %v62 = phi i64 [ %v46, %bb6 ], [ %v82, %bb8 ]
  %v63 = phi i64 [ %v47, %bb6 ], [ %v83, %bb8 ]
  %v64 = phi i64 [ %v48, %bb6 ], [ %v84, %bb8 ]
  br label %bb11
bb6:
  %v66 = select i1 true, i64 0, i64 0
  %v67 = call i8 @wf_map_cost_ordered(ptr %v30, i64 %v66)
  br label %bb5
bb7:
  %t8 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.slot.0, i32 0, i32 1
  %v68 = load i1, ptr %t8
  %t9 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.slot.0, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %t9, i64 ptrtoint (ptr getelementptr (%wf.t.09071440a409e980, ptr null, i32 1) to i64), i1 false)
  switch i1 %v68, label %invalid.tag.b7 [
    i1 0, label %bb9
    i1 1, label %bb10
  ]
invalid.tag.b7:
  call void @abort()
  unreachable
bb8:
  %v70 = phi i64 [ %v20, %bb9 ], [ %v20, %bb10 ]
  %v71 = phi i64 [ %v21, %bb9 ], [ %v21, %bb10 ]
  %v72 = phi i64 [ %v22, %bb9 ], [ %v22, %bb10 ]
  %v73 = phi i64 [ %v23, %bb9 ], [ %v23, %bb10 ]
  %v74 = phi i64 [ %v24, %bb9 ], [ %v24, %bb10 ]
  %v75 = phi i64 [ %v25, %bb9 ], [ %v25, %bb10 ]
  %v76 = phi i64 [ %v26, %bb9 ], [ %v26, %bb10 ]
  %v77 = phi i1 [ %v27, %bb9 ], [ %v27, %bb10 ]
  %v78 = phi ptr [ %v28, %bb9 ], [ %v28, %bb10 ]
  %v79 = phi ptr [ %v29, %bb9 ], [ %v29, %bb10 ]
  %v80 = phi ptr [ %v30, %bb9 ], [ %v30, %bb10 ]
  %v81 = phi i64 [ %v33, %bb9 ], [ %v33, %bb10 ]
  %v82 = phi i64 [ %v46, %bb9 ], [ %v46, %bb10 ]
  %v83 = phi i64 [ %v47, %bb9 ], [ %v47, %bb10 ]
  %v84 = phi i64 [ %v48, %bb9 ], [ %v48, %bb10 ]
  %v86 = phi i1 [ %v68, %bb9 ], [ %v68, %bb10 ]
  %t10 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.1, i32 0, i32 0
  %v92 = load i64, ptr %t10
  ; ownership-consuming projection
  %t11 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.1, i32 0, i32 1
  %v93 = load i64, ptr %t11
  ; ownership-consuming projection
  %v94 = call i64 @wf_map_cost_word_content(i64 %v92, i64 %v93)
  %v95 = call i8 @wf_map_cost_ordered(ptr %v80, i64 %v94)
  br label %bb5
bb9:
  %v88 = select i1 true, i64 1, i64 1
  %v89 = call i8 @wf_map_cost_ordered(ptr %v30, i64 %v88)
  br label %bb8
bb10:
  %v90 = select i1 true, i64 2, i64 2
  %v91 = call i8 @wf_map_cost_ordered(ptr %v30, i64 %v90)
  br label %bb8
bb11:
  %v96 = phi i64 [ %v50, %bb5 ]
  %v97 = phi i64 [ %v51, %bb5 ]
  %v98 = phi i64 [ %v52, %bb5 ]
  %v99 = phi i64 [ %v53, %bb5 ]
  %v100 = phi i64 [ %v54, %bb5 ]
  %v101 = phi i64 [ %v55, %bb5 ]
  %v102 = phi i64 [ %v56, %bb5 ]
  %v103 = phi i1 [ %v57, %bb5 ]
  %v104 = phi ptr [ %v58, %bb5 ]
  %v105 = phi ptr [ %v59, %bb5 ]
  %v106 = phi ptr [ %v60, %bb5 ]
  %v107 = phi i64 [ %v31, %bb5 ]
  %v108 = phi i64 [ %v32, %bb5 ]
  %v109 = phi i64 [ %v33, %bb5 ]
  %v110 = select i1 true, i64 1, i64 1
  %v111 = add i64 %v109, %v110
  br label %bb1
bb12:
  %v113 = phi i64 [ %v34, %bb4 ], [ %v947, %bb93 ]
  %v114 = phi i64 [ %v35, %bb4 ], [ %v948, %bb93 ]
  %v115 = phi i64 [ %v36, %bb4 ], [ %v949, %bb93 ]
  %v116 = phi i64 [ %v37, %bb4 ], [ %v950, %bb93 ]
  %v117 = phi i64 [ %v38, %bb4 ], [ %v951, %bb93 ]
  %v118 = phi i64 [ %v39, %bb4 ], [ %v952, %bb93 ]
  %v119 = phi i64 [ %v40, %bb4 ], [ %v953, %bb93 ]
  %v120 = phi i1 [ %v41, %bb4 ], [ %v954, %bb93 ]
  %v121 = phi ptr [ %v42, %bb4 ], [ %v955, %bb93 ]
  %v122 = phi ptr [ %v43, %bb4 ], [ %v956, %bb93 ]
  %v123 = phi ptr [ %v44, %bb4 ], [ %v957, %bb93 ]
  %v124 = phi i64 [ %v112, %bb4 ], [ %v958, %bb93 ]
  %v125 = phi i64 [ %v36, %bb4 ], [ %v959, %bb93 ]
  %v126 = phi i64 [ %v112, %bb4 ], [ %v962, %bb93 ]
  %v138 = icmp ult i64 %v126, %v125
  switch i1 %v138, label %invalid.tag.b12 [
    i1 1, label %bb13
    i1 0, label %bb14
  ]
invalid.tag.b12:
  call void @abort()
  unreachable
bb13:
  %v139 = select i1 true, i64 5, i64 5
  %v140 = icmp eq i64 %v117, %v139
  switch i1 %v140, label %invalid.tag.b13 [
    i1 1, label %bb17
    i1 0, label %bb18
  ]
invalid.tag.b13:
  call void @abort()
  unreachable
bb14:
  br label %bb15
bb15:
  %v127 = phi i64 [ %v113, %bb14 ]
  %v128 = phi i64 [ %v114, %bb14 ]
  %v129 = phi i64 [ %v115, %bb14 ]
  %v130 = phi i64 [ %v116, %bb14 ]
  %v131 = phi i64 [ %v117, %bb14 ]
  %v132 = phi i64 [ %v118, %bb14 ]
  %v133 = phi i64 [ %v119, %bb14 ]
  %v134 = phi i1 [ %v120, %bb14 ]
  %v135 = phi ptr [ %v121, %bb14 ]
  %v136 = phi ptr [ %v122, %bb14 ]
  %v137 = phi ptr [ %v123, %bb14 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.19, ptr %v136, i64 ptrtoint (ptr getelementptr (%wf.t.7748a5b0f0193f4a, ptr null, i32 1) to i64), i1 false)
  %v964 = call i8 @wf_hash_map.hash_map_free$instance$001ff12ace7d7c19(ptr %wf.slot.19, ptr %v137)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.20, ptr %v137, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %v966 = call i64 @wf_map_cost_finish(ptr %wf.slot.20)
  ret i64 %v966
bb16:
  %v141 = phi i64 [ %v322, %bb35 ], [ %v566, %bb61 ]
  %v142 = phi i64 [ %v323, %bb35 ], [ %v567, %bb61 ]
  %v143 = phi i64 [ %v324, %bb35 ], [ %v568, %bb61 ]
  %v144 = phi i64 [ %v325, %bb35 ], [ %v569, %bb61 ]
  %v145 = phi i64 [ %v326, %bb35 ], [ %v570, %bb61 ]
  %v146 = phi i64 [ %v327, %bb35 ], [ %v571, %bb61 ]
  %v147 = phi i64 [ %v328, %bb35 ], [ %v572, %bb61 ]
  %v148 = phi i1 [ %v329, %bb35 ], [ %v573, %bb61 ]
  %v149 = phi ptr [ %v330, %bb35 ], [ %v574, %bb61 ]
  %v150 = phi ptr [ %v331, %bb35 ], [ %v575, %bb61 ]
  %v151 = phi ptr [ %v332, %bb35 ], [ %v576, %bb61 ]
  %v152 = phi i64 [ %v333, %bb35 ], [ %v577, %bb61 ]
  br label %bb93
bb17:
  %v153 = select i1 true, i64 2, i64 2
  %v154 = udiv i64 %v114, %v153
  %v155 = sub nuw i64 %v114, %v154
  %v156 = select i1 true, i64 0, i64 0
  br label %bb19
bb18:
  %v430 = select i1 true, i64 4, i64 4
  %v431 = icmp eq i64 %v117, %v430
  %v432 = select i1 true, i64 9, i64 9
  %v433 = icmp eq i64 %v117, %v432
  %v434 = select i1 true, i64 10, i64 10
  %v435 = icmp eq i64 %v117, %v434
  %v436 = or i1 %v433, %v435
  %v437 = or i1 %v431, %v436
  switch i1 %v437, label %invalid.tag.b18 [
    i1 1, label %bb44
    i1 0, label %bb45
  ]
invalid.tag.b18:
  call void @abort()
  unreachable
bb19:
  %v157 = phi i64 [ %v113, %bb17 ], [ %v223, %bb26 ]
  %v158 = phi i64 [ %v114, %bb17 ], [ %v224, %bb26 ]
  %v159 = phi i64 [ %v115, %bb17 ], [ %v225, %bb26 ]
  %v160 = phi i64 [ %v116, %bb17 ], [ %v226, %bb26 ]
  %v161 = phi i64 [ %v117, %bb17 ], [ %v227, %bb26 ]
  %v162 = phi i64 [ %v118, %bb17 ], [ %v228, %bb26 ]
  %v163 = phi i64 [ %v119, %bb17 ], [ %v229, %bb26 ]
  %v164 = phi i1 [ %v120, %bb17 ], [ %v230, %bb26 ]
  %v165 = phi ptr [ %v121, %bb17 ], [ %v231, %bb26 ]
  %v166 = phi ptr [ %v122, %bb17 ], [ %v232, %bb26 ]
  %v167 = phi ptr [ %v123, %bb17 ], [ %v233, %bb26 ]
  %v168 = phi i64 [ %v126, %bb17 ], [ %v234, %bb26 ]
  %v169 = phi i64 [ %v154, %bb17 ], [ %v235, %bb26 ]
  %v170 = phi i64 [ %v155, %bb17 ], [ %v236, %bb26 ]
  %v171 = phi i64 [ %v156, %bb17 ], [ %v237, %bb26 ]
  %v172 = phi i64 [ %v155, %bb17 ], [ %v238, %bb26 ]
  %v173 = phi i64 [ %v156, %bb17 ], [ %v241, %bb26 ]
  %v188 = icmp ult i64 %v173, %v172
  switch i1 %v188, label %invalid.tag.b19 [
    i1 1, label %bb20
    i1 0, label %bb21
  ]
invalid.tag.b19:
  call void @abort()
  unreachable
bb20:
  %v189 = select i1 true, i64 2, i64 2
  %v190 = mul i64 %v173, %v189
  %v191 = call i64 @wf_map_cost_key(i64 %v190)
  store i64 %v191, ptr %v192
  %v193 = call %wf.t.743755fb647946cb @wf_hash_map.hash_map_remove$instance$fde7c6722a8b0dad(ptr %v166, ptr %v192, ptr %v165)
  store %wf.t.743755fb647946cb %v193, ptr %wf.slot.2
  %t12 = load %wf.t.743755fb647946cb, ptr %wf.slot.2
  %t13 = extractvalue %wf.t.743755fb647946cb %t12, 0
  switch i32 %t13, label %invalid.tag.b20 [
    i32 1, label %bb24
    i32 0, label %bb25
  ]
invalid.tag.b20:
  call void @abort()
  unreachable
bb21:
  br label %bb22
bb22:
  %v174 = phi i64 [ %v157, %bb21 ]
  %v175 = phi i64 [ %v158, %bb21 ]
  %v176 = phi i64 [ %v159, %bb21 ]
  %v177 = phi i64 [ %v160, %bb21 ]
  %v178 = phi i64 [ %v161, %bb21 ]
  %v179 = phi i64 [ %v162, %bb21 ]
  %v180 = phi i64 [ %v163, %bb21 ]
  %v181 = phi i1 [ %v164, %bb21 ]
  %v182 = phi ptr [ %v165, %bb21 ]
  %v183 = phi ptr [ %v166, %bb21 ]
  %v184 = phi ptr [ %v167, %bb21 ]
  %v185 = phi i64 [ %v168, %bb21 ]
  %v186 = phi i64 [ %v169, %bb21 ]
  %v187 = phi i64 [ %v170, %bb21 ]
  %v242 = call %wf.t.7d7f918f7b4962fd @wf_hash_map.hash_map_rehash$instance$fde7c6722a8b0dad(ptr %v183, ptr %v182)
  store %wf.t.7d7f918f7b4962fd %v242, ptr %wf.slot.5
  %v243 = call i8 @wf_map_cost_rebuild_result(ptr %wf.slot.5, ptr %v184)
  %v244 = select i1 true, i64 0, i64 0
  br label %bb27
bb23:
  %v194 = phi i64 [ %v157, %bb24 ], [ %v157, %bb25 ]
  %v195 = phi i64 [ %v158, %bb24 ], [ %v158, %bb25 ]
  %v196 = phi i64 [ %v159, %bb24 ], [ %v159, %bb25 ]
  %v197 = phi i64 [ %v160, %bb24 ], [ %v160, %bb25 ]
  %v198 = phi i64 [ %v161, %bb24 ], [ %v161, %bb25 ]
  %v199 = phi i64 [ %v162, %bb24 ], [ %v162, %bb25 ]
  %v200 = phi i64 [ %v163, %bb24 ], [ %v163, %bb25 ]
  %v201 = phi i1 [ %v164, %bb24 ], [ %v164, %bb25 ]
  %v202 = phi ptr [ %v165, %bb24 ], [ %v165, %bb25 ]
  %v203 = phi ptr [ %v166, %bb24 ], [ %v166, %bb25 ]
  %v204 = phi ptr [ %v167, %bb24 ], [ %v167, %bb25 ]
  %v205 = phi i64 [ %v168, %bb24 ], [ %v168, %bb25 ]
  %v206 = phi i64 [ %v169, %bb24 ], [ %v169, %bb25 ]
  %v207 = phi i64 [ %v170, %bb24 ], [ %v170, %bb25 ]
  %v208 = phi i64 [ %v173, %bb24 ], [ %v173, %bb25 ]
  %v209 = phi i64 [ %v190, %bb24 ], [ %v190, %bb25 ]
  %v210 = phi ptr [ %v192, %bb24 ], [ %v192, %bb25 ]
  %v221 = call %wf.t.b7e1ed626c09888a @wf_hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50(ptr %v203, ptr %v210, ptr %v202, ptr %v204)
  store %wf.t.b7e1ed626c09888a %v221, ptr %wf.slot.4
  %v222 = call i8 @wf_map_cost_lookup_result(ptr %wf.slot.4, ptr %v204)
  br label %bb26
bb24:
  %t14 = getelementptr inbounds %wf.t.743755fb647946cb, ptr %wf.slot.2, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.3, ptr %t14, i64 ptrtoint (ptr getelementptr (%wf.t.09071440a409e980, ptr null, i32 1) to i64), i1 false)
  %v213 = select i1 true, i64 1, i64 1
  %v214 = call i8 @wf_map_cost_ordered(ptr %v167, i64 %v213)
  %t15 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.3, i32 0, i32 0
  %v215 = load i64, ptr %t15
  ; ownership-consuming projection
  %t16 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.3, i32 0, i32 1
  %v216 = load i64, ptr %t16
  ; ownership-consuming projection
  %v217 = call i64 @wf_map_cost_word_content(i64 %v215, i64 %v216)
  %v218 = call i8 @wf_map_cost_ordered(ptr %v167, i64 %v217)
  br label %bb23
bb25:
  %v219 = select i1 true, i64 0, i64 0
  %v220 = call i8 @wf_map_cost_ordered(ptr %v167, i64 %v219)
  br label %bb23
bb26:
  %v223 = phi i64 [ %v194, %bb23 ]
  %v224 = phi i64 [ %v195, %bb23 ]
  %v225 = phi i64 [ %v196, %bb23 ]
  %v226 = phi i64 [ %v197, %bb23 ]
  %v227 = phi i64 [ %v198, %bb23 ]
  %v228 = phi i64 [ %v199, %bb23 ]
  %v229 = phi i64 [ %v200, %bb23 ]
  %v230 = phi i1 [ %v201, %bb23 ]
  %v231 = phi ptr [ %v202, %bb23 ]
  %v232 = phi ptr [ %v203, %bb23 ]
  %v233 = phi ptr [ %v204, %bb23 ]
  %v234 = phi i64 [ %v205, %bb23 ]
  %v235 = phi i64 [ %v206, %bb23 ]
  %v236 = phi i64 [ %v207, %bb23 ]
  %v237 = phi i64 [ %v171, %bb23 ]
  %v238 = phi i64 [ %v172, %bb23 ]
  %v239 = phi i64 [ %v173, %bb23 ]
  %v240 = select i1 true, i64 1, i64 1
  %v241 = add i64 %v239, %v240
  br label %bb19
bb27:
  %v245 = phi i64 [ %v174, %bb22 ], [ %v283, %bb31 ]
  %v246 = phi i64 [ %v175, %bb22 ], [ %v284, %bb31 ]
  %v247 = phi i64 [ %v176, %bb22 ], [ %v285, %bb31 ]
  %v248 = phi i64 [ %v177, %bb22 ], [ %v286, %bb31 ]
  %v249 = phi i64 [ %v178, %bb22 ], [ %v287, %bb31 ]
  %v250 = phi i64 [ %v179, %bb22 ], [ %v288, %bb31 ]
  %v251 = phi i64 [ %v180, %bb22 ], [ %v289, %bb31 ]
  %v252 = phi i1 [ %v181, %bb22 ], [ %v290, %bb31 ]
  %v253 = phi ptr [ %v182, %bb22 ], [ %v291, %bb31 ]
  %v254 = phi ptr [ %v183, %bb22 ], [ %v292, %bb31 ]
  %v255 = phi ptr [ %v184, %bb22 ], [ %v293, %bb31 ]
  %v256 = phi i64 [ %v185, %bb22 ], [ %v294, %bb31 ]
  %v257 = phi i64 [ %v186, %bb22 ], [ %v295, %bb31 ]
  %v258 = phi i64 [ %v187, %bb22 ], [ %v296, %bb31 ]
  %v260 = phi i64 [ %v244, %bb22 ], [ %v298, %bb31 ]
  %v261 = phi i64 [ %v175, %bb22 ], [ %v299, %bb31 ]
  %v262 = phi i64 [ %v244, %bb22 ], [ %v302, %bb31 ]
  %v278 = icmp ult i64 %v262, %v261
  switch i1 %v278, label %invalid.tag.b27 [
    i1 1, label %bb28
    i1 0, label %bb29
  ]
invalid.tag.b27:
  call void @abort()
  unreachable
bb28:
  %v279 = call i64 @wf_map_cost_key(i64 %v262)
  store i64 %v279, ptr %v280
  %v281 = call %wf.t.b7e1ed626c09888a @wf_hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50(ptr %v254, ptr %v280, ptr %v253, ptr %v255)
  store %wf.t.b7e1ed626c09888a %v281, ptr %wf.slot.6
  %v282 = call i8 @wf_map_cost_lookup_result(ptr %wf.slot.6, ptr %v255)
  br label %bb31
bb29:
  br label %bb30
bb30:
  %v263 = phi i64 [ %v245, %bb29 ]
  %v264 = phi i64 [ %v246, %bb29 ]
  %v265 = phi i64 [ %v247, %bb29 ]
  %v266 = phi i64 [ %v248, %bb29 ]
  %v267 = phi i64 [ %v249, %bb29 ]
  %v268 = phi i64 [ %v250, %bb29 ]
  %v269 = phi i64 [ %v251, %bb29 ]
  %v270 = phi i1 [ %v252, %bb29 ]
  %v271 = phi ptr [ %v253, %bb29 ]
  %v272 = phi ptr [ %v254, %bb29 ]
  %v273 = phi ptr [ %v255, %bb29 ]
  %v274 = phi i64 [ %v256, %bb29 ]
  %v275 = phi i64 [ %v257, %bb29 ]
  %v276 = phi i64 [ %v258, %bb29 ]
  %v303 = select i1 true, i64 0, i64 0
  br label %bb32
bb31:
  %v283 = phi i64 [ %v245, %bb28 ]
  %v284 = phi i64 [ %v246, %bb28 ]
  %v285 = phi i64 [ %v247, %bb28 ]
  %v286 = phi i64 [ %v248, %bb28 ]
  %v287 = phi i64 [ %v249, %bb28 ]
  %v288 = phi i64 [ %v250, %bb28 ]
  %v289 = phi i64 [ %v251, %bb28 ]
  %v290 = phi i1 [ %v252, %bb28 ]
  %v291 = phi ptr [ %v253, %bb28 ]
  %v292 = phi ptr [ %v254, %bb28 ]
  %v293 = phi ptr [ %v255, %bb28 ]
  %v294 = phi i64 [ %v256, %bb28 ]
  %v295 = phi i64 [ %v257, %bb28 ]
  %v296 = phi i64 [ %v258, %bb28 ]
  %v298 = phi i64 [ %v260, %bb28 ]
  %v299 = phi i64 [ %v261, %bb28 ]
  %v300 = phi i64 [ %v262, %bb28 ]
  %v301 = select i1 true, i64 1, i64 1
  %v302 = add i64 %v300, %v301
  br label %bb27
bb32:
  %v304 = phi i64 [ %v263, %bb30 ], [ %v410, %bb42 ]
  %v305 = phi i64 [ %v264, %bb30 ], [ %v411, %bb42 ]
  %v306 = phi i64 [ %v265, %bb30 ], [ %v412, %bb42 ]
  %v307 = phi i64 [ %v266, %bb30 ], [ %v413, %bb42 ]
  %v308 = phi i64 [ %v267, %bb30 ], [ %v414, %bb42 ]
  %v309 = phi i64 [ %v268, %bb30 ], [ %v415, %bb42 ]
  %v310 = phi i64 [ %v269, %bb30 ], [ %v416, %bb42 ]
  %v311 = phi i1 [ %v270, %bb30 ], [ %v417, %bb42 ]
  %v312 = phi ptr [ %v271, %bb30 ], [ %v418, %bb42 ]
  %v313 = phi ptr [ %v272, %bb30 ], [ %v419, %bb42 ]
  %v314 = phi ptr [ %v273, %bb30 ], [ %v420, %bb42 ]
  %v315 = phi i64 [ %v274, %bb30 ], [ %v421, %bb42 ]
  %v316 = phi i64 [ %v275, %bb30 ], [ %v422, %bb42 ]
  %v317 = phi i64 [ %v276, %bb30 ], [ %v423, %bb42 ]
  %v319 = phi i64 [ %v303, %bb30 ], [ %v425, %bb42 ]
  %v320 = phi i64 [ %v276, %bb30 ], [ %v426, %bb42 ]
  %v321 = phi i64 [ %v303, %bb30 ], [ %v429, %bb42 ]
  %v337 = icmp ult i64 %v321, %v320
  switch i1 %v337, label %invalid.tag.b32 [
    i1 1, label %bb33
    i1 0, label %bb34
  ]
invalid.tag.b32:
  call void @abort()
  unreachable
bb33:
  %v338 = select i1 true, i64 2, i64 2
  %v339 = mul i64 %v321, %v338
  %v340 = call i64 @wf_map_cost_key(i64 %v339)
  %v341 = select i1 true, i64 1, i64 1
  %v342 = add i64 %v315, %v341
  %v343 = mul i64 %v342, %v305
  %v344 = add i64 %v307, %v343
  %v345 = add i64 %v344, %v339
  %v346 = call i64 @wf_map_cost_word_make(i64 %v345)
  call void @wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad(ptr %wf.slot.7, ptr %v313, i64 %v340, i64 %v346, ptr %v312)
  %t17 = load %wf.t.ac5891a387b8aafe, ptr %wf.slot.7
  %t18 = extractvalue %wf.t.ac5891a387b8aafe %t17, 0
  switch i32 %t18, label %invalid.tag.b33 [
    i32 0, label %bb37
    i32 1, label %bb38
  ]
invalid.tag.b33:
  call void @abort()
  unreachable
bb34:
  br label %bb35
bb35:
  %v322 = phi i64 [ %v304, %bb34 ]
  %v323 = phi i64 [ %v305, %bb34 ]
  %v324 = phi i64 [ %v306, %bb34 ]
  %v325 = phi i64 [ %v307, %bb34 ]
  %v326 = phi i64 [ %v308, %bb34 ]
  %v327 = phi i64 [ %v309, %bb34 ]
  %v328 = phi i64 [ %v310, %bb34 ]
  %v329 = phi i1 [ %v311, %bb34 ]
  %v330 = phi ptr [ %v312, %bb34 ]
  %v331 = phi ptr [ %v313, %bb34 ]
  %v332 = phi ptr [ %v314, %bb34 ]
  %v333 = phi i64 [ %v315, %bb34 ]
  %v334 = phi i64 [ %v316, %bb34 ]
  %v335 = phi i64 [ %v317, %bb34 ]
  br label %bb16
bb36:
  %v348 = phi i64 [ %v304, %bb37 ], [ %v376, %bb39 ]
  %v349 = phi i64 [ %v305, %bb37 ], [ %v377, %bb39 ]
  %v350 = phi i64 [ %v306, %bb37 ], [ %v378, %bb39 ]
  %v351 = phi i64 [ %v307, %bb37 ], [ %v379, %bb39 ]
  %v352 = phi i64 [ %v308, %bb37 ], [ %v380, %bb39 ]
  %v353 = phi i64 [ %v309, %bb37 ], [ %v381, %bb39 ]
  %v354 = phi i64 [ %v310, %bb37 ], [ %v382, %bb39 ]
  %v355 = phi i1 [ %v311, %bb37 ], [ %v383, %bb39 ]
  %v356 = phi ptr [ %v312, %bb37 ], [ %v384, %bb39 ]
  %v357 = phi ptr [ %v313, %bb37 ], [ %v385, %bb39 ]
  %v358 = phi ptr [ %v314, %bb37 ], [ %v386, %bb39 ]
  %v359 = phi i64 [ %v315, %bb37 ], [ %v387, %bb39 ]
  %v360 = phi i64 [ %v316, %bb37 ], [ %v388, %bb39 ]
  %v361 = phi i64 [ %v317, %bb37 ], [ %v389, %bb39 ]
  %v363 = phi i64 [ %v321, %bb37 ], [ %v391, %bb39 ]
  %v364 = phi i64 [ %v339, %bb37 ], [ %v392, %bb39 ]
  %v365 = phi i64 [ %v340, %bb37 ], [ %v393, %bb39 ]
  %v366 = phi i64 [ %v342, %bb37 ], [ %v394, %bb39 ]
  %v367 = phi i64 [ %v343, %bb37 ], [ %v395, %bb39 ]
  %v368 = phi i64 [ %v344, %bb37 ], [ %v396, %bb39 ]
  %v369 = phi i64 [ %v345, %bb37 ], [ %v397, %bb39 ]
  %v370 = phi i64 [ %v346, %bb37 ], [ %v398, %bb39 ]
  br label %bb42
bb37:
  %v372 = select i1 true, i64 0, i64 0
  %v373 = call i8 @wf_map_cost_ordered(ptr %v314, i64 %v372)
  br label %bb36
bb38:
  %t19 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.slot.7, i32 0, i32 1
  %v374 = load i1, ptr %t19
  %t20 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.slot.7, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.8, ptr %t20, i64 ptrtoint (ptr getelementptr (%wf.t.09071440a409e980, ptr null, i32 1) to i64), i1 false)
  switch i1 %v374, label %invalid.tag.b38 [
    i1 0, label %bb40
    i1 1, label %bb41
  ]
invalid.tag.b38:
  call void @abort()
  unreachable
bb39:
  %v376 = phi i64 [ %v304, %bb40 ], [ %v304, %bb41 ]
  %v377 = phi i64 [ %v305, %bb40 ], [ %v305, %bb41 ]
  %v378 = phi i64 [ %v306, %bb40 ], [ %v306, %bb41 ]
  %v379 = phi i64 [ %v307, %bb40 ], [ %v307, %bb41 ]
  %v380 = phi i64 [ %v308, %bb40 ], [ %v308, %bb41 ]
  %v381 = phi i64 [ %v309, %bb40 ], [ %v309, %bb41 ]
  %v382 = phi i64 [ %v310, %bb40 ], [ %v310, %bb41 ]
  %v383 = phi i1 [ %v311, %bb40 ], [ %v311, %bb41 ]
  %v384 = phi ptr [ %v312, %bb40 ], [ %v312, %bb41 ]
  %v385 = phi ptr [ %v313, %bb40 ], [ %v313, %bb41 ]
  %v386 = phi ptr [ %v314, %bb40 ], [ %v314, %bb41 ]
  %v387 = phi i64 [ %v315, %bb40 ], [ %v315, %bb41 ]
  %v388 = phi i64 [ %v316, %bb40 ], [ %v316, %bb41 ]
  %v389 = phi i64 [ %v317, %bb40 ], [ %v317, %bb41 ]
  %v391 = phi i64 [ %v321, %bb40 ], [ %v321, %bb41 ]
  %v392 = phi i64 [ %v339, %bb40 ], [ %v339, %bb41 ]
  %v393 = phi i64 [ %v340, %bb40 ], [ %v340, %bb41 ]
  %v394 = phi i64 [ %v342, %bb40 ], [ %v342, %bb41 ]
  %v395 = phi i64 [ %v343, %bb40 ], [ %v343, %bb41 ]
  %v396 = phi i64 [ %v344, %bb40 ], [ %v344, %bb41 ]
  %v397 = phi i64 [ %v345, %bb40 ], [ %v345, %bb41 ]
  %v398 = phi i64 [ %v346, %bb40 ], [ %v346, %bb41 ]
  %v400 = phi i1 [ %v374, %bb40 ], [ %v374, %bb41 ]
  %t21 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.8, i32 0, i32 0
  %v406 = load i64, ptr %t21
  ; ownership-consuming projection
  %t22 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.8, i32 0, i32 1
  %v407 = load i64, ptr %t22
  ; ownership-consuming projection
  %v408 = call i64 @wf_map_cost_word_content(i64 %v406, i64 %v407)
  %v409 = call i8 @wf_map_cost_ordered(ptr %v386, i64 %v408)
  br label %bb36
bb40:
  %v402 = select i1 true, i64 1, i64 1
  %v403 = call i8 @wf_map_cost_ordered(ptr %v314, i64 %v402)
  br label %bb39
bb41:
  %v404 = select i1 true, i64 2, i64 2
  %v405 = call i8 @wf_map_cost_ordered(ptr %v314, i64 %v404)
  br label %bb39
bb42:
  %v410 = phi i64 [ %v348, %bb36 ]
  %v411 = phi i64 [ %v349, %bb36 ]
  %v412 = phi i64 [ %v350, %bb36 ]
  %v413 = phi i64 [ %v351, %bb36 ]
  %v414 = phi i64 [ %v352, %bb36 ]
  %v415 = phi i64 [ %v353, %bb36 ]
  %v416 = phi i64 [ %v354, %bb36 ]
  %v417 = phi i1 [ %v355, %bb36 ]
  %v418 = phi ptr [ %v356, %bb36 ]
  %v419 = phi ptr [ %v357, %bb36 ]
  %v420 = phi ptr [ %v358, %bb36 ]
  %v421 = phi i64 [ %v359, %bb36 ]
  %v422 = phi i64 [ %v360, %bb36 ]
  %v423 = phi i64 [ %v361, %bb36 ]
  %v425 = phi i64 [ %v319, %bb36 ]
  %v426 = phi i64 [ %v320, %bb36 ]
  %v427 = phi i64 [ %v321, %bb36 ]
  %v428 = select i1 true, i64 1, i64 1
  %v429 = add i64 %v427, %v428
  br label %bb32
bb43:
  %v438 = phi i64 [ %v113, %bb45 ], [ %v502, %bb52 ]
  %v439 = phi i64 [ %v114, %bb45 ], [ %v503, %bb52 ]
  %v440 = phi i64 [ %v115, %bb45 ], [ %v504, %bb52 ]
  %v441 = phi i64 [ %v116, %bb45 ], [ %v505, %bb52 ]
  %v442 = phi i64 [ %v117, %bb45 ], [ %v506, %bb52 ]
  %v443 = phi i64 [ %v118, %bb45 ], [ %v507, %bb52 ]
  %v444 = phi i64 [ %v119, %bb45 ], [ %v508, %bb52 ]
  %v445 = phi i1 [ %v120, %bb45 ], [ %v509, %bb52 ]
  %v446 = phi ptr [ %v121, %bb45 ], [ %v510, %bb52 ]
  %v447 = phi ptr [ %v122, %bb45 ], [ %v511, %bb52 ]
  %v448 = phi ptr [ %v123, %bb45 ], [ %v512, %bb52 ]
  %v449 = phi i64 [ %v126, %bb45 ], [ %v513, %bb52 ]
  %v450 = phi i1 [ %v431, %bb45 ], [ %v514, %bb52 ]
  %v451 = phi i1 [ %v433, %bb45 ], [ %v515, %bb52 ]
  %v452 = phi i1 [ %v435, %bb45 ], [ %v516, %bb52 ]
  %v453 = phi i1 [ %v436, %bb45 ], [ %v517, %bb52 ]
  %v454 = phi i1 [ %v437, %bb45 ], [ %v518, %bb52 ]
  %v545 = select i1 true, i64 0, i64 0
  br label %bb58
bb44:
  %v455 = select i1 true, i64 1, i64 1
  %v456 = select i1 true, i64 0, i64 0
  %v457 = icmp ne i64 %v113, %v456
  switch i1 %v457, label %invalid.tag.b44 [
    i1 1, label %bb47
    i1 0, label %bb48
  ]
invalid.tag.b44:
  call void @abort()
  unreachable
bb45:
  br label %bb43
bb46:
  %v458 = phi i64 [ %v113, %bb47 ], [ %v113, %bb48 ]
  %v459 = phi i64 [ %v114, %bb47 ], [ %v114, %bb48 ]
  %v460 = phi i64 [ %v115, %bb47 ], [ %v115, %bb48 ]
  %v461 = phi i64 [ %v116, %bb47 ], [ %v116, %bb48 ]
  %v462 = phi i64 [ %v117, %bb47 ], [ %v117, %bb48 ]
  %v463 = phi i64 [ %v118, %bb47 ], [ %v118, %bb48 ]
  %v464 = phi i64 [ %v119, %bb47 ], [ %v119, %bb48 ]
  %v465 = phi i1 [ %v120, %bb47 ], [ %v120, %bb48 ]
  %v466 = phi ptr [ %v121, %bb47 ], [ %v121, %bb48 ]
  %v467 = phi ptr [ %v122, %bb47 ], [ %v122, %bb48 ]
  %v468 = phi ptr [ %v123, %bb47 ], [ %v123, %bb48 ]
  %v469 = phi i64 [ %v126, %bb47 ], [ %v126, %bb48 ]
  %v470 = phi i1 [ %v431, %bb47 ], [ %v431, %bb48 ]
  %v471 = phi i1 [ %v433, %bb47 ], [ %v433, %bb48 ]
  %v472 = phi i1 [ %v435, %bb47 ], [ %v435, %bb48 ]
  %v473 = phi i1 [ %v436, %bb47 ], [ %v436, %bb48 ]
  %v474 = phi i1 [ %v437, %bb47 ], [ %v437, %bb48 ]
  %v475 = phi i64 [ %v477, %bb47 ], [ %v455, %bb48 ]
  %v478 = select i1 true, i64 10, i64 10
  %v479 = icmp eq i64 %v462, %v478
  switch i1 %v479, label %invalid.tag.b46 [
    i1 1, label %bb50
    i1 0, label %bb51
  ]
invalid.tag.b46:
  call void @abort()
  unreachable
bb47:
  %v476 = select i1 true, i64 2, i64 2
  %v477 = mul nuw i64 %v113, %v476
  br label %bb46
bb48:
  br label %bb46
bb49:
  %v480 = phi i64 [ %v458, %bb50 ], [ %v458, %bb51 ]
  %v481 = phi i64 [ %v459, %bb50 ], [ %v459, %bb51 ]
  %v482 = phi i64 [ %v460, %bb50 ], [ %v460, %bb51 ]
  %v483 = phi i64 [ %v461, %bb50 ], [ %v461, %bb51 ]
  %v484 = phi i64 [ %v462, %bb50 ], [ %v462, %bb51 ]
  %v485 = phi i64 [ %v463, %bb50 ], [ %v463, %bb51 ]
  %v486 = phi i64 [ %v464, %bb50 ], [ %v464, %bb51 ]
  %v487 = phi i1 [ %v465, %bb50 ], [ %v465, %bb51 ]
  %v488 = phi ptr [ %v466, %bb50 ], [ %v466, %bb51 ]
  %v489 = phi ptr [ %v467, %bb50 ], [ %v467, %bb51 ]
  %v490 = phi ptr [ %v468, %bb50 ], [ %v468, %bb51 ]
  %v491 = phi i64 [ %v469, %bb50 ], [ %v469, %bb51 ]
  %v492 = phi i1 [ %v470, %bb50 ], [ %v470, %bb51 ]
  %v493 = phi i1 [ %v471, %bb50 ], [ %v471, %bb51 ]
  %v494 = phi i1 [ %v472, %bb50 ], [ %v472, %bb51 ]
  %v495 = phi i1 [ %v473, %bb50 ], [ %v473, %bb51 ]
  %v496 = phi i1 [ %v474, %bb50 ], [ %v474, %bb51 ]
  %v497 = phi i64 [ %v475, %bb50 ], [ %v475, %bb51 ]
  switch i1 %v495, label %invalid.tag.b49 [
    i1 1, label %bb53
    i1 0, label %bb54
  ]
invalid.tag.b49:
  call void @abort()
  unreachable
bb50:
  %v498 = select i1 true, i64 1, i64 1
  %v499 = call i8 @wf_map_cost_ordered(ptr %v468, i64 %v498)
  br label %bb49
bb51:
  %v500 = call %wf.t.7d7f918f7b4962fd @wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad(ptr %v467, i64 %v475, ptr %v466)
  store %wf.t.7d7f918f7b4962fd %v500, ptr %wf.slot.9
  %v501 = call i8 @wf_map_cost_rebuild_result(ptr %wf.slot.9, ptr %v468)
  br label %bb49
bb52:
  %v502 = phi i64 [ %v480, %bb54 ], [ %v522, %bb55 ]
  %v503 = phi i64 [ %v481, %bb54 ], [ %v523, %bb55 ]
  %v504 = phi i64 [ %v482, %bb54 ], [ %v524, %bb55 ]
  %v505 = phi i64 [ %v483, %bb54 ], [ %v525, %bb55 ]
  %v506 = phi i64 [ %v484, %bb54 ], [ %v526, %bb55 ]
  %v507 = phi i64 [ %v485, %bb54 ], [ %v527, %bb55 ]
  %v508 = phi i64 [ %v486, %bb54 ], [ %v528, %bb55 ]
  %v509 = phi i1 [ %v487, %bb54 ], [ %v529, %bb55 ]
  %v510 = phi ptr [ %v488, %bb54 ], [ %v530, %bb55 ]
  %v511 = phi ptr [ %v489, %bb54 ], [ %v531, %bb55 ]
  %v512 = phi ptr [ %v490, %bb54 ], [ %v532, %bb55 ]
  %v513 = phi i64 [ %v491, %bb54 ], [ %v533, %bb55 ]
  %v514 = phi i1 [ %v492, %bb54 ], [ %v534, %bb55 ]
  %v515 = phi i1 [ %v493, %bb54 ], [ %v535, %bb55 ]
  %v516 = phi i1 [ %v494, %bb54 ], [ %v536, %bb55 ]
  %v517 = phi i1 [ %v495, %bb54 ], [ %v537, %bb55 ]
  %v518 = phi i1 [ %v496, %bb54 ], [ %v538, %bb55 ]
  %v519 = phi i64 [ %v497, %bb54 ], [ %v539, %bb55 ]
  br label %bb43
bb53:
  %v520 = call i64 @wf_hash_map.hash_map_capacity$instance$820b2044b97e0fbd(ptr %v489)
  %v521 = icmp uge i64 %v520, %v497
  switch i1 %v521, label %invalid.tag.b53 [
    i1 1, label %bb56
    i1 0, label %bb57
  ]
invalid.tag.b53:
  call void @abort()
  unreachable
bb54:
  br label %bb52
bb55:
  %v522 = phi i64 [ %v480, %bb56 ], [ %v480, %bb57 ]
  %v523 = phi i64 [ %v481, %bb56 ], [ %v481, %bb57 ]
  %v524 = phi i64 [ %v482, %bb56 ], [ %v482, %bb57 ]
  %v525 = phi i64 [ %v483, %bb56 ], [ %v483, %bb57 ]
  %v526 = phi i64 [ %v484, %bb56 ], [ %v484, %bb57 ]
  %v527 = phi i64 [ %v485, %bb56 ], [ %v485, %bb57 ]
  %v528 = phi i64 [ %v486, %bb56 ], [ %v486, %bb57 ]
  %v529 = phi i1 [ %v487, %bb56 ], [ %v487, %bb57 ]
  %v530 = phi ptr [ %v488, %bb56 ], [ %v488, %bb57 ]
  %v531 = phi ptr [ %v489, %bb56 ], [ %v489, %bb57 ]
  %v532 = phi ptr [ %v490, %bb56 ], [ %v490, %bb57 ]
  %v533 = phi i64 [ %v491, %bb56 ], [ %v491, %bb57 ]
  %v534 = phi i1 [ %v492, %bb56 ], [ %v492, %bb57 ]
  %v535 = phi i1 [ %v493, %bb56 ], [ %v493, %bb57 ]
  %v536 = phi i1 [ %v494, %bb56 ], [ %v494, %bb57 ]
  %v537 = phi i1 [ %v495, %bb56 ], [ %v495, %bb57 ]
  %v538 = phi i1 [ %v496, %bb56 ], [ %v496, %bb57 ]
  %v539 = phi i64 [ %v497, %bb56 ], [ %v497, %bb57 ]
  %v540 = phi i64 [ %v520, %bb56 ], [ %v520, %bb57 ]
  br label %bb52
bb56:
  %v541 = select i1 true, i64 1, i64 1
  %v542 = call i8 @wf_map_cost_ordered(ptr %v490, i64 %v541)
  br label %bb55
bb57:
  %v543 = select i1 true, i64 0, i64 0
  %v544 = call i8 @wf_map_cost_ordered(ptr %v490, i64 %v543)
  br label %bb55
bb58:
  %v546 = phi i64 [ %v438, %bb43 ], [ %v925, %bb92 ]
  %v547 = phi i64 [ %v439, %bb43 ], [ %v926, %bb92 ]
  %v548 = phi i64 [ %v440, %bb43 ], [ %v927, %bb92 ]
  %v549 = phi i64 [ %v441, %bb43 ], [ %v928, %bb92 ]
  %v550 = phi i64 [ %v442, %bb43 ], [ %v929, %bb92 ]
  %v551 = phi i64 [ %v443, %bb43 ], [ %v930, %bb92 ]
  %v552 = phi i64 [ %v444, %bb43 ], [ %v931, %bb92 ]
  %v553 = phi i1 [ %v445, %bb43 ], [ %v932, %bb92 ]
  %v554 = phi ptr [ %v446, %bb43 ], [ %v933, %bb92 ]
  %v555 = phi ptr [ %v447, %bb43 ], [ %v934, %bb92 ]
  %v556 = phi ptr [ %v448, %bb43 ], [ %v935, %bb92 ]
  %v557 = phi i64 [ %v449, %bb43 ], [ %v936, %bb92 ]
  %v558 = phi i1 [ %v450, %bb43 ], [ %v937, %bb92 ]
  %v559 = phi i1 [ %v451, %bb43 ], [ %v938, %bb92 ]
  %v560 = phi i1 [ %v452, %bb43 ], [ %v939, %bb92 ]
  %v561 = phi i1 [ %v453, %bb43 ], [ %v940, %bb92 ]
  %v562 = phi i1 [ %v454, %bb43 ], [ %v941, %bb92 ]
  %v563 = phi i64 [ %v545, %bb43 ], [ %v942, %bb92 ]
  %v564 = phi i64 [ %v439, %bb43 ], [ %v943, %bb92 ]
  %v565 = phi i64 [ %v545, %bb43 ], [ %v946, %bb92 ]
  %v583 = icmp ult i64 %v565, %v564
  switch i1 %v583, label %invalid.tag.b58 [
    i1 1, label %bb59
    i1 0, label %bb60
  ]
invalid.tag.b58:
  call void @abort()
  unreachable
bb59:
  %v584 = select i1 true, i64 1, i64 1
  %v585 = icmp eq i64 %v550, %v584
  switch i1 %v585, label %invalid.tag.b59 [
    i1 1, label %bb63
    i1 0, label %bb64
  ]
invalid.tag.b59:
  call void @abort()
  unreachable
bb60:
  br label %bb61
bb61:
  %v566 = phi i64 [ %v546, %bb60 ]
  %v567 = phi i64 [ %v547, %bb60 ]
  %v568 = phi i64 [ %v548, %bb60 ]
  %v569 = phi i64 [ %v549, %bb60 ]
  %v570 = phi i64 [ %v550, %bb60 ]
  %v571 = phi i64 [ %v551, %bb60 ]
  %v572 = phi i64 [ %v552, %bb60 ]
  %v573 = phi i1 [ %v553, %bb60 ]
  %v574 = phi ptr [ %v554, %bb60 ]
  %v575 = phi ptr [ %v555, %bb60 ]
  %v576 = phi ptr [ %v556, %bb60 ]
  %v577 = phi i64 [ %v557, %bb60 ]
  %v578 = phi i1 [ %v558, %bb60 ]
  %v579 = phi i1 [ %v559, %bb60 ]
  %v580 = phi i1 [ %v560, %bb60 ]
  %v581 = phi i1 [ %v561, %bb60 ]
  %v582 = phi i1 [ %v562, %bb60 ]
  br label %bb16
bb62:
  %v586 = phi i64 [ %v546, %bb63 ], [ %v546, %bb64 ]
  %v587 = phi i64 [ %v547, %bb63 ], [ %v547, %bb64 ]
  %v588 = phi i64 [ %v548, %bb63 ], [ %v548, %bb64 ]
  %v589 = phi i64 [ %v549, %bb63 ], [ %v549, %bb64 ]
  %v590 = phi i64 [ %v550, %bb63 ], [ %v550, %bb64 ]
  %v591 = phi i64 [ %v551, %bb63 ], [ %v551, %bb64 ]
  %v592 = phi i64 [ %v552, %bb63 ], [ %v552, %bb64 ]
  %v593 = phi i1 [ %v553, %bb63 ], [ %v553, %bb64 ]
  %v594 = phi ptr [ %v554, %bb63 ], [ %v554, %bb64 ]
  %v595 = phi ptr [ %v555, %bb63 ], [ %v555, %bb64 ]
  %v596 = phi ptr [ %v556, %bb63 ], [ %v556, %bb64 ]
  %v597 = phi i64 [ %v557, %bb63 ], [ %v557, %bb64 ]
  %v598 = phi i1 [ %v558, %bb63 ], [ %v558, %bb64 ]
  %v599 = phi i1 [ %v559, %bb63 ], [ %v559, %bb64 ]
  %v600 = phi i1 [ %v560, %bb63 ], [ %v560, %bb64 ]
  %v601 = phi i1 [ %v561, %bb63 ], [ %v561, %bb64 ]
  %v602 = phi i1 [ %v562, %bb63 ], [ %v562, %bb64 ]
  %v603 = phi i64 [ %v565, %bb63 ], [ %v565, %bb64 ]
  %v604 = phi i64 [ %v605, %bb63 ], [ %v565, %bb64 ]
  %v606 = call i64 @wf_map_cost_key(i64 %v604)
  store i64 %v606, ptr %v607
  %v608 = select i1 true, i64 0, i64 0
  %v609 = icmp eq i64 %v590, %v608
  %v610 = select i1 true, i64 1, i64 1
  %v611 = icmp eq i64 %v590, %v610
  %v612 = or i1 %v609, %v611
  %v613 = or i1 %v612, %v602
  switch i1 %v613, label %invalid.tag.b62 [
    i1 1, label %bb66
    i1 0, label %bb67
  ]
invalid.tag.b62:
  call void @abort()
  unreachable
bb63:
  %v605 = add i64 %v547, %v565
  br label %bb62
bb64:
  br label %bb62
bb65:
  %v614 = phi i64 [ %v586, %bb66 ], [ %v642, %bb68 ]
  %v615 = phi i64 [ %v587, %bb66 ], [ %v643, %bb68 ]
  %v616 = phi i64 [ %v588, %bb66 ], [ %v644, %bb68 ]
  %v617 = phi i64 [ %v589, %bb66 ], [ %v645, %bb68 ]
  %v618 = phi i64 [ %v590, %bb66 ], [ %v646, %bb68 ]
  %v619 = phi i64 [ %v591, %bb66 ], [ %v647, %bb68 ]
  %v620 = phi i64 [ %v592, %bb66 ], [ %v648, %bb68 ]
  %v621 = phi i1 [ %v593, %bb66 ], [ %v649, %bb68 ]
  %v622 = phi ptr [ %v594, %bb66 ], [ %v650, %bb68 ]
  %v623 = phi ptr [ %v595, %bb66 ], [ %v651, %bb68 ]
  %v624 = phi ptr [ %v596, %bb66 ], [ %v652, %bb68 ]
  %v625 = phi i64 [ %v597, %bb66 ], [ %v653, %bb68 ]
  %v626 = phi i1 [ %v598, %bb66 ], [ %v654, %bb68 ]
  %v627 = phi i1 [ %v599, %bb66 ], [ %v655, %bb68 ]
  %v628 = phi i1 [ %v600, %bb66 ], [ %v656, %bb68 ]
  %v629 = phi i1 [ %v601, %bb66 ], [ %v657, %bb68 ]
  %v630 = phi i1 [ %v602, %bb66 ], [ %v658, %bb68 ]
  %v631 = phi i64 [ %v603, %bb66 ], [ %v659, %bb68 ]
  %v632 = phi i64 [ %v604, %bb66 ], [ %v660, %bb68 ]
  %v633 = phi ptr [ %v607, %bb66 ], [ %v661, %bb68 ]
  %v634 = phi i1 [ %v609, %bb66 ], [ %v662, %bb68 ]
  %v635 = phi i1 [ %v611, %bb66 ], [ %v663, %bb68 ]
  %v636 = phi i1 [ %v612, %bb66 ], [ %v664, %bb68 ]
  %v637 = phi i1 [ %v613, %bb66 ], [ %v665, %bb68 ]
  br label %bb92
bb66:
  %v638 = call %wf.t.b7e1ed626c09888a @wf_hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50(ptr %v595, ptr %v607, ptr %v594, ptr %v596)
  store %wf.t.b7e1ed626c09888a %v638, ptr %wf.slot.10
  %v639 = call i8 @wf_map_cost_lookup_result(ptr %wf.slot.10, ptr %v596)
  br label %bb65
bb67:
  %v640 = select i1 true, i64 2, i64 2
  %v641 = icmp eq i64 %v590, %v640
  switch i1 %v641, label %invalid.tag.b67 [
    i1 1, label %bb69
    i1 0, label %bb70
  ]
invalid.tag.b67:
  call void @abort()
  unreachable
bb68:
  %v642 = phi i64 [ %v674, %bb71 ], [ %v750, %bb77 ]
  %v643 = phi i64 [ %v675, %bb71 ], [ %v751, %bb77 ]
  %v644 = phi i64 [ %v676, %bb71 ], [ %v752, %bb77 ]
  %v645 = phi i64 [ %v677, %bb71 ], [ %v753, %bb77 ]
  %v646 = phi i64 [ %v678, %bb71 ], [ %v754, %bb77 ]
  %v647 = phi i64 [ %v679, %bb71 ], [ %v755, %bb77 ]
  %v648 = phi i64 [ %v680, %bb71 ], [ %v756, %bb77 ]
  %v649 = phi i1 [ %v681, %bb71 ], [ %v757, %bb77 ]
  %v650 = phi ptr [ %v682, %bb71 ], [ %v758, %bb77 ]
  %v651 = phi ptr [ %v683, %bb71 ], [ %v759, %bb77 ]
  %v652 = phi ptr [ %v684, %bb71 ], [ %v760, %bb77 ]
  %v653 = phi i64 [ %v685, %bb71 ], [ %v761, %bb77 ]
  %v654 = phi i1 [ %v686, %bb71 ], [ %v762, %bb77 ]
  %v655 = phi i1 [ %v687, %bb71 ], [ %v763, %bb77 ]
  %v656 = phi i1 [ %v688, %bb71 ], [ %v764, %bb77 ]
  %v657 = phi i1 [ %v689, %bb71 ], [ %v765, %bb77 ]
  %v658 = phi i1 [ %v690, %bb71 ], [ %v766, %bb77 ]
  %v659 = phi i64 [ %v691, %bb71 ], [ %v767, %bb77 ]
  %v660 = phi i64 [ %v692, %bb71 ], [ %v768, %bb77 ]
  %v661 = phi ptr [ %v693, %bb71 ], [ %v769, %bb77 ]
  %v662 = phi i1 [ %v694, %bb71 ], [ %v770, %bb77 ]
  %v663 = phi i1 [ %v695, %bb71 ], [ %v771, %bb77 ]
  %v664 = phi i1 [ %v696, %bb71 ], [ %v772, %bb77 ]
  %v665 = phi i1 [ %v697, %bb71 ], [ %v773, %bb77 ]
  br label %bb65
bb69:
  %v666 = select i1 true, i64 1, i64 1
  %v667 = add i64 %v597, %v666
  %v668 = mul i64 %v667, %v587
  %v669 = add i64 %v589, %v668
  %v670 = add i64 %v669, %v603
  %v671 = call i64 @wf_map_cost_word_make(i64 %v670)
  %v672 = load i64, ptr %v607
  call void @wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad(ptr %wf.slot.11, ptr %v595, i64 %v672, i64 %v671, ptr %v594)
  %t23 = load %wf.t.ac5891a387b8aafe, ptr %wf.slot.11
  %t24 = extractvalue %wf.t.ac5891a387b8aafe %t23, 0
  switch i32 %t24, label %invalid.tag.b69 [
    i32 0, label %bb72
    i32 1, label %bb73
  ]
invalid.tag.b69:
  call void @abort()
  unreachable
bb70:
  %v748 = select i1 true, i64 3, i64 3
  %v749 = icmp eq i64 %v590, %v748
  switch i1 %v749, label %invalid.tag.b70 [
    i1 1, label %bb78
    i1 0, label %bb79
  ]
invalid.tag.b70:
  call void @abort()
  unreachable
bb71:
  %v674 = phi i64 [ %v586, %bb72 ], [ %v708, %bb74 ]
  %v675 = phi i64 [ %v587, %bb72 ], [ %v709, %bb74 ]
  %v676 = phi i64 [ %v588, %bb72 ], [ %v710, %bb74 ]
  %v677 = phi i64 [ %v589, %bb72 ], [ %v711, %bb74 ]
  %v678 = phi i64 [ %v590, %bb72 ], [ %v712, %bb74 ]
  %v679 = phi i64 [ %v591, %bb72 ], [ %v713, %bb74 ]
  %v680 = phi i64 [ %v592, %bb72 ], [ %v714, %bb74 ]
  %v681 = phi i1 [ %v593, %bb72 ], [ %v715, %bb74 ]
  %v682 = phi ptr [ %v594, %bb72 ], [ %v716, %bb74 ]
  %v683 = phi ptr [ %v595, %bb72 ], [ %v717, %bb74 ]
  %v684 = phi ptr [ %v596, %bb72 ], [ %v718, %bb74 ]
  %v685 = phi i64 [ %v597, %bb72 ], [ %v719, %bb74 ]
  %v686 = phi i1 [ %v598, %bb72 ], [ %v720, %bb74 ]
  %v687 = phi i1 [ %v599, %bb72 ], [ %v721, %bb74 ]
  %v688 = phi i1 [ %v600, %bb72 ], [ %v722, %bb74 ]
  %v689 = phi i1 [ %v601, %bb72 ], [ %v723, %bb74 ]
  %v690 = phi i1 [ %v602, %bb72 ], [ %v724, %bb74 ]
  %v691 = phi i64 [ %v603, %bb72 ], [ %v725, %bb74 ]
  %v692 = phi i64 [ %v604, %bb72 ], [ %v726, %bb74 ]
  %v693 = phi ptr [ %v607, %bb72 ], [ %v727, %bb74 ]
  %v694 = phi i1 [ %v609, %bb72 ], [ %v728, %bb74 ]
  %v695 = phi i1 [ %v611, %bb72 ], [ %v729, %bb74 ]
  %v696 = phi i1 [ %v612, %bb72 ], [ %v730, %bb74 ]
  %v697 = phi i1 [ %v613, %bb72 ], [ %v731, %bb74 ]
  %v698 = phi i64 [ %v667, %bb72 ], [ %v732, %bb74 ]
  %v699 = phi i64 [ %v668, %bb72 ], [ %v733, %bb74 ]
  %v700 = phi i64 [ %v669, %bb72 ], [ %v734, %bb74 ]
  %v701 = phi i64 [ %v670, %bb72 ], [ %v735, %bb74 ]
  %v702 = phi i64 [ %v671, %bb72 ], [ %v736, %bb74 ]
  br label %bb68
bb72:
  %v704 = select i1 true, i64 0, i64 0
  %v705 = call i8 @wf_map_cost_ordered(ptr %v596, i64 %v704)
  br label %bb71
bb73:
  %t25 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.slot.11, i32 0, i32 1
  %v706 = load i1, ptr %t25
  %t26 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.slot.11, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.12, ptr %t26, i64 ptrtoint (ptr getelementptr (%wf.t.09071440a409e980, ptr null, i32 1) to i64), i1 false)
  switch i1 %v706, label %invalid.tag.b73 [
    i1 0, label %bb75
    i1 1, label %bb76
  ]
invalid.tag.b73:
  call void @abort()
  unreachable
bb74:
  %v708 = phi i64 [ %v586, %bb75 ], [ %v586, %bb76 ]
  %v709 = phi i64 [ %v587, %bb75 ], [ %v587, %bb76 ]
  %v710 = phi i64 [ %v588, %bb75 ], [ %v588, %bb76 ]
  %v711 = phi i64 [ %v589, %bb75 ], [ %v589, %bb76 ]
  %v712 = phi i64 [ %v590, %bb75 ], [ %v590, %bb76 ]
  %v713 = phi i64 [ %v591, %bb75 ], [ %v591, %bb76 ]
  %v714 = phi i64 [ %v592, %bb75 ], [ %v592, %bb76 ]
  %v715 = phi i1 [ %v593, %bb75 ], [ %v593, %bb76 ]
  %v716 = phi ptr [ %v594, %bb75 ], [ %v594, %bb76 ]
  %v717 = phi ptr [ %v595, %bb75 ], [ %v595, %bb76 ]
  %v718 = phi ptr [ %v596, %bb75 ], [ %v596, %bb76 ]
  %v719 = phi i64 [ %v597, %bb75 ], [ %v597, %bb76 ]
  %v720 = phi i1 [ %v598, %bb75 ], [ %v598, %bb76 ]
  %v721 = phi i1 [ %v599, %bb75 ], [ %v599, %bb76 ]
  %v722 = phi i1 [ %v600, %bb75 ], [ %v600, %bb76 ]
  %v723 = phi i1 [ %v601, %bb75 ], [ %v601, %bb76 ]
  %v724 = phi i1 [ %v602, %bb75 ], [ %v602, %bb76 ]
  %v725 = phi i64 [ %v603, %bb75 ], [ %v603, %bb76 ]
  %v726 = phi i64 [ %v604, %bb75 ], [ %v604, %bb76 ]
  %v727 = phi ptr [ %v607, %bb75 ], [ %v607, %bb76 ]
  %v728 = phi i1 [ %v609, %bb75 ], [ %v609, %bb76 ]
  %v729 = phi i1 [ %v611, %bb75 ], [ %v611, %bb76 ]
  %v730 = phi i1 [ %v612, %bb75 ], [ %v612, %bb76 ]
  %v731 = phi i1 [ %v613, %bb75 ], [ %v613, %bb76 ]
  %v732 = phi i64 [ %v667, %bb75 ], [ %v667, %bb76 ]
  %v733 = phi i64 [ %v668, %bb75 ], [ %v668, %bb76 ]
  %v734 = phi i64 [ %v669, %bb75 ], [ %v669, %bb76 ]
  %v735 = phi i64 [ %v670, %bb75 ], [ %v670, %bb76 ]
  %v736 = phi i64 [ %v671, %bb75 ], [ %v671, %bb76 ]
  %v738 = phi i1 [ %v706, %bb75 ], [ %v706, %bb76 ]
  %t27 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.12, i32 0, i32 0
  %v744 = load i64, ptr %t27
  ; ownership-consuming projection
  %t28 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.12, i32 0, i32 1
  %v745 = load i64, ptr %t28
  ; ownership-consuming projection
  %v746 = call i64 @wf_map_cost_word_content(i64 %v744, i64 %v745)
  %v747 = call i8 @wf_map_cost_ordered(ptr %v718, i64 %v746)
  br label %bb71
bb75:
  %v740 = select i1 true, i64 1, i64 1
  %v741 = call i8 @wf_map_cost_ordered(ptr %v596, i64 %v740)
  br label %bb74
bb76:
  %v742 = select i1 true, i64 2, i64 2
  %v743 = call i8 @wf_map_cost_ordered(ptr %v596, i64 %v742)
  br label %bb74
bb77:
  %v750 = phi i64 [ %v819, %bb83 ], [ %v899, %bb89 ]
  %v751 = phi i64 [ %v820, %bb83 ], [ %v900, %bb89 ]
  %v752 = phi i64 [ %v821, %bb83 ], [ %v901, %bb89 ]
  %v753 = phi i64 [ %v822, %bb83 ], [ %v902, %bb89 ]
  %v754 = phi i64 [ %v823, %bb83 ], [ %v903, %bb89 ]
  %v755 = phi i64 [ %v824, %bb83 ], [ %v904, %bb89 ]
  %v756 = phi i64 [ %v825, %bb83 ], [ %v905, %bb89 ]
  %v757 = phi i1 [ %v826, %bb83 ], [ %v906, %bb89 ]
  %v758 = phi ptr [ %v827, %bb83 ], [ %v907, %bb89 ]
  %v759 = phi ptr [ %v828, %bb83 ], [ %v908, %bb89 ]
  %v760 = phi ptr [ %v829, %bb83 ], [ %v909, %bb89 ]
  %v761 = phi i64 [ %v830, %bb83 ], [ %v910, %bb89 ]
  %v762 = phi i1 [ %v831, %bb83 ], [ %v911, %bb89 ]
  %v763 = phi i1 [ %v832, %bb83 ], [ %v912, %bb89 ]
  %v764 = phi i1 [ %v833, %bb83 ], [ %v913, %bb89 ]
  %v765 = phi i1 [ %v834, %bb83 ], [ %v914, %bb89 ]
  %v766 = phi i1 [ %v835, %bb83 ], [ %v915, %bb89 ]
  %v767 = phi i64 [ %v836, %bb83 ], [ %v916, %bb89 ]
  %v768 = phi i64 [ %v837, %bb83 ], [ %v917, %bb89 ]
  %v769 = phi ptr [ %v838, %bb83 ], [ %v918, %bb89 ]
  %v770 = phi i1 [ %v839, %bb83 ], [ %v919, %bb89 ]
  %v771 = phi i1 [ %v840, %bb83 ], [ %v920, %bb89 ]
  %v772 = phi i1 [ %v841, %bb83 ], [ %v921, %bb89 ]
  %v773 = phi i1 [ %v842, %bb83 ], [ %v922, %bb89 ]
  br label %bb68
bb78:
  %v774 = call %wf.t.743755fb647946cb @wf_hash_map.hash_map_remove$instance$fde7c6722a8b0dad(ptr %v595, ptr %v607, ptr %v594)
  store %wf.t.743755fb647946cb %v774, ptr %wf.slot.13
  %t29 = load %wf.t.743755fb647946cb, ptr %wf.slot.13
  %t30 = extractvalue %wf.t.743755fb647946cb %t29, 0
  switch i32 %t30, label %invalid.tag.b78 [
    i32 1, label %bb81
    i32 0, label %bb82
  ]
invalid.tag.b78:
  call void @abort()
  unreachable
bb79:
  %v897 = select i1 true, i64 7, i64 7
  %v898 = icmp eq i64 %v590, %v897
  switch i1 %v898, label %invalid.tag.b79 [
    i1 1, label %bb90
    i1 0, label %bb91
  ]
invalid.tag.b79:
  call void @abort()
  unreachable
bb80:
  %v775 = phi i64 [ %v586, %bb81 ], [ %v586, %bb82 ]
  %v776 = phi i64 [ %v587, %bb81 ], [ %v587, %bb82 ]
  %v777 = phi i64 [ %v588, %bb81 ], [ %v588, %bb82 ]
  %v778 = phi i64 [ %v589, %bb81 ], [ %v589, %bb82 ]
  %v779 = phi i64 [ %v590, %bb81 ], [ %v590, %bb82 ]
  %v780 = phi i64 [ %v591, %bb81 ], [ %v591, %bb82 ]
  %v781 = phi i64 [ %v592, %bb81 ], [ %v592, %bb82 ]
  %v782 = phi i1 [ %v593, %bb81 ], [ %v593, %bb82 ]
  %v783 = phi ptr [ %v594, %bb81 ], [ %v594, %bb82 ]
  %v784 = phi ptr [ %v595, %bb81 ], [ %v595, %bb82 ]
  %v785 = phi ptr [ %v596, %bb81 ], [ %v596, %bb82 ]
  %v786 = phi i64 [ %v597, %bb81 ], [ %v597, %bb82 ]
  %v787 = phi i1 [ %v598, %bb81 ], [ %v598, %bb82 ]
  %v788 = phi i1 [ %v599, %bb81 ], [ %v599, %bb82 ]
  %v789 = phi i1 [ %v600, %bb81 ], [ %v600, %bb82 ]
  %v790 = phi i1 [ %v601, %bb81 ], [ %v601, %bb82 ]
  %v791 = phi i1 [ %v602, %bb81 ], [ %v602, %bb82 ]
  %v792 = phi i64 [ %v603, %bb81 ], [ %v603, %bb82 ]
  %v793 = phi i64 [ %v604, %bb81 ], [ %v604, %bb82 ]
  %v794 = phi ptr [ %v607, %bb81 ], [ %v607, %bb82 ]
  %v795 = phi i1 [ %v609, %bb81 ], [ %v609, %bb82 ]
  %v796 = phi i1 [ %v611, %bb81 ], [ %v611, %bb82 ]
  %v797 = phi i1 [ %v612, %bb81 ], [ %v612, %bb82 ]
  %v798 = phi i1 [ %v613, %bb81 ], [ %v613, %bb82 ]
  %v809 = call %wf.t.b7e1ed626c09888a @wf_hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50(ptr %v784, ptr %v794, ptr %v783, ptr %v785)
  store %wf.t.b7e1ed626c09888a %v809, ptr %wf.slot.15
  %v810 = call i8 @wf_map_cost_lookup_result(ptr %wf.slot.15, ptr %v785)
  %v811 = select i1 true, i64 1, i64 1
  %v812 = add i64 %v786, %v811
  %v813 = mul i64 %v812, %v776
  %v814 = add i64 %v778, %v813
  %v815 = add i64 %v814, %v792
  %v816 = call i64 @wf_map_cost_word_make(i64 %v815)
  %v817 = load i64, ptr %v794
  call void @wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad(ptr %wf.slot.16, ptr %v784, i64 %v817, i64 %v816, ptr %v783)
  %t31 = load %wf.t.ac5891a387b8aafe, ptr %wf.slot.16
  %t32 = extractvalue %wf.t.ac5891a387b8aafe %t31, 0
  switch i32 %t32, label %invalid.tag.b80 [
    i32 0, label %bb84
    i32 1, label %bb85
  ]
invalid.tag.b80:
  call void @abort()
  unreachable
bb81:
  %t33 = getelementptr inbounds %wf.t.743755fb647946cb, ptr %wf.slot.13, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.14, ptr %t33, i64 ptrtoint (ptr getelementptr (%wf.t.09071440a409e980, ptr null, i32 1) to i64), i1 false)
  %v801 = select i1 true, i64 1, i64 1
  %v802 = call i8 @wf_map_cost_ordered(ptr %v596, i64 %v801)
  %t34 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.14, i32 0, i32 0
  %v803 = load i64, ptr %t34
  ; ownership-consuming projection
  %t35 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.14, i32 0, i32 1
  %v804 = load i64, ptr %t35
  ; ownership-consuming projection
  %v805 = call i64 @wf_map_cost_word_content(i64 %v803, i64 %v804)
  %v806 = call i8 @wf_map_cost_ordered(ptr %v596, i64 %v805)
  br label %bb80
bb82:
  %v807 = select i1 true, i64 0, i64 0
  %v808 = call i8 @wf_map_cost_ordered(ptr %v596, i64 %v807)
  br label %bb80
bb83:
  %v819 = phi i64 [ %v775, %bb84 ], [ %v855, %bb86 ]
  %v820 = phi i64 [ %v776, %bb84 ], [ %v856, %bb86 ]
  %v821 = phi i64 [ %v777, %bb84 ], [ %v857, %bb86 ]
  %v822 = phi i64 [ %v778, %bb84 ], [ %v858, %bb86 ]
  %v823 = phi i64 [ %v779, %bb84 ], [ %v859, %bb86 ]
  %v824 = phi i64 [ %v780, %bb84 ], [ %v860, %bb86 ]
  %v825 = phi i64 [ %v781, %bb84 ], [ %v861, %bb86 ]
  %v826 = phi i1 [ %v782, %bb84 ], [ %v862, %bb86 ]
  %v827 = phi ptr [ %v783, %bb84 ], [ %v863, %bb86 ]
  %v828 = phi ptr [ %v784, %bb84 ], [ %v864, %bb86 ]
  %v829 = phi ptr [ %v785, %bb84 ], [ %v865, %bb86 ]
  %v830 = phi i64 [ %v786, %bb84 ], [ %v866, %bb86 ]
  %v831 = phi i1 [ %v787, %bb84 ], [ %v867, %bb86 ]
  %v832 = phi i1 [ %v788, %bb84 ], [ %v868, %bb86 ]
  %v833 = phi i1 [ %v789, %bb84 ], [ %v869, %bb86 ]
  %v834 = phi i1 [ %v790, %bb84 ], [ %v870, %bb86 ]
  %v835 = phi i1 [ %v791, %bb84 ], [ %v871, %bb86 ]
  %v836 = phi i64 [ %v792, %bb84 ], [ %v872, %bb86 ]
  %v837 = phi i64 [ %v793, %bb84 ], [ %v873, %bb86 ]
  %v838 = phi ptr [ %v794, %bb84 ], [ %v874, %bb86 ]
  %v839 = phi i1 [ %v795, %bb84 ], [ %v875, %bb86 ]
  %v840 = phi i1 [ %v796, %bb84 ], [ %v876, %bb86 ]
  %v841 = phi i1 [ %v797, %bb84 ], [ %v877, %bb86 ]
  %v842 = phi i1 [ %v798, %bb84 ], [ %v878, %bb86 ]
  %v845 = phi i64 [ %v812, %bb84 ], [ %v881, %bb86 ]
  %v846 = phi i64 [ %v813, %bb84 ], [ %v882, %bb86 ]
  %v847 = phi i64 [ %v814, %bb84 ], [ %v883, %bb86 ]
  %v848 = phi i64 [ %v815, %bb84 ], [ %v884, %bb86 ]
  %v849 = phi i64 [ %v816, %bb84 ], [ %v885, %bb86 ]
  br label %bb77
bb84:
  %v851 = select i1 true, i64 0, i64 0
  %v852 = call i8 @wf_map_cost_ordered(ptr %v785, i64 %v851)
  br label %bb83
bb85:
  %t36 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.slot.16, i32 0, i32 1
  %v853 = load i1, ptr %t36
  %t37 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.slot.16, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.17, ptr %t37, i64 ptrtoint (ptr getelementptr (%wf.t.09071440a409e980, ptr null, i32 1) to i64), i1 false)
  switch i1 %v853, label %invalid.tag.b85 [
    i1 0, label %bb87
    i1 1, label %bb88
  ]
invalid.tag.b85:
  call void @abort()
  unreachable
bb86:
  %v855 = phi i64 [ %v775, %bb87 ], [ %v775, %bb88 ]
  %v856 = phi i64 [ %v776, %bb87 ], [ %v776, %bb88 ]
  %v857 = phi i64 [ %v777, %bb87 ], [ %v777, %bb88 ]
  %v858 = phi i64 [ %v778, %bb87 ], [ %v778, %bb88 ]
  %v859 = phi i64 [ %v779, %bb87 ], [ %v779, %bb88 ]
  %v860 = phi i64 [ %v780, %bb87 ], [ %v780, %bb88 ]
  %v861 = phi i64 [ %v781, %bb87 ], [ %v781, %bb88 ]
  %v862 = phi i1 [ %v782, %bb87 ], [ %v782, %bb88 ]
  %v863 = phi ptr [ %v783, %bb87 ], [ %v783, %bb88 ]
  %v864 = phi ptr [ %v784, %bb87 ], [ %v784, %bb88 ]
  %v865 = phi ptr [ %v785, %bb87 ], [ %v785, %bb88 ]
  %v866 = phi i64 [ %v786, %bb87 ], [ %v786, %bb88 ]
  %v867 = phi i1 [ %v787, %bb87 ], [ %v787, %bb88 ]
  %v868 = phi i1 [ %v788, %bb87 ], [ %v788, %bb88 ]
  %v869 = phi i1 [ %v789, %bb87 ], [ %v789, %bb88 ]
  %v870 = phi i1 [ %v790, %bb87 ], [ %v790, %bb88 ]
  %v871 = phi i1 [ %v791, %bb87 ], [ %v791, %bb88 ]
  %v872 = phi i64 [ %v792, %bb87 ], [ %v792, %bb88 ]
  %v873 = phi i64 [ %v793, %bb87 ], [ %v793, %bb88 ]
  %v874 = phi ptr [ %v794, %bb87 ], [ %v794, %bb88 ]
  %v875 = phi i1 [ %v795, %bb87 ], [ %v795, %bb88 ]
  %v876 = phi i1 [ %v796, %bb87 ], [ %v796, %bb88 ]
  %v877 = phi i1 [ %v797, %bb87 ], [ %v797, %bb88 ]
  %v878 = phi i1 [ %v798, %bb87 ], [ %v798, %bb88 ]
  %v881 = phi i64 [ %v812, %bb87 ], [ %v812, %bb88 ]
  %v882 = phi i64 [ %v813, %bb87 ], [ %v813, %bb88 ]
  %v883 = phi i64 [ %v814, %bb87 ], [ %v814, %bb88 ]
  %v884 = phi i64 [ %v815, %bb87 ], [ %v815, %bb88 ]
  %v885 = phi i64 [ %v816, %bb87 ], [ %v816, %bb88 ]
  %v887 = phi i1 [ %v853, %bb87 ], [ %v853, %bb88 ]
  %t38 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.17, i32 0, i32 0
  %v893 = load i64, ptr %t38
  ; ownership-consuming projection
  %t39 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.17, i32 0, i32 1
  %v894 = load i64, ptr %t39
  ; ownership-consuming projection
  %v895 = call i64 @wf_map_cost_word_content(i64 %v893, i64 %v894)
  %v896 = call i8 @wf_map_cost_ordered(ptr %v865, i64 %v895)
  br label %bb83
bb87:
  %v889 = select i1 true, i64 1, i64 1
  %v890 = call i8 @wf_map_cost_ordered(ptr %v785, i64 %v889)
  br label %bb86
bb88:
  %v891 = select i1 true, i64 2, i64 2
  %v892 = call i8 @wf_map_cost_ordered(ptr %v785, i64 %v891)
  br label %bb86
bb89:
  %v899 = phi i64 [ %v586, %bb90 ], [ %v586, %bb91 ]
  %v900 = phi i64 [ %v587, %bb90 ], [ %v587, %bb91 ]
  %v901 = phi i64 [ %v588, %bb90 ], [ %v588, %bb91 ]
  %v902 = phi i64 [ %v589, %bb90 ], [ %v589, %bb91 ]
  %v903 = phi i64 [ %v590, %bb90 ], [ %v590, %bb91 ]
  %v904 = phi i64 [ %v591, %bb90 ], [ %v591, %bb91 ]
  %v905 = phi i64 [ %v592, %bb90 ], [ %v592, %bb91 ]
  %v906 = phi i1 [ %v593, %bb90 ], [ %v593, %bb91 ]
  %v907 = phi ptr [ %v594, %bb90 ], [ %v594, %bb91 ]
  %v908 = phi ptr [ %v595, %bb90 ], [ %v595, %bb91 ]
  %v909 = phi ptr [ %v596, %bb90 ], [ %v596, %bb91 ]
  %v910 = phi i64 [ %v597, %bb90 ], [ %v597, %bb91 ]
  %v911 = phi i1 [ %v598, %bb90 ], [ %v598, %bb91 ]
  %v912 = phi i1 [ %v599, %bb90 ], [ %v599, %bb91 ]
  %v913 = phi i1 [ %v600, %bb90 ], [ %v600, %bb91 ]
  %v914 = phi i1 [ %v601, %bb90 ], [ %v601, %bb91 ]
  %v915 = phi i1 [ %v602, %bb90 ], [ %v602, %bb91 ]
  %v916 = phi i64 [ %v603, %bb90 ], [ %v603, %bb91 ]
  %v917 = phi i64 [ %v604, %bb90 ], [ %v604, %bb91 ]
  %v918 = phi ptr [ %v607, %bb90 ], [ %v607, %bb91 ]
  %v919 = phi i1 [ %v609, %bb90 ], [ %v609, %bb91 ]
  %v920 = phi i1 [ %v611, %bb90 ], [ %v611, %bb91 ]
  %v921 = phi i1 [ %v612, %bb90 ], [ %v612, %bb91 ]
  %v922 = phi i1 [ %v613, %bb90 ], [ %v613, %bb91 ]
  br label %bb77
bb90:
  %v923 = call %wf.t.b7e1ed626c09888a @wf_hash_map.hash_map_edit$instance$25497bb333d90567(ptr %v595, ptr %v607, ptr %v594, ptr %v596)
  store %wf.t.b7e1ed626c09888a %v923, ptr %wf.slot.18
  %v924 = call i8 @wf_map_cost_lookup_result(ptr %wf.slot.18, ptr %v596)
  br label %bb89
bb91:
  br label %bb89
bb92:
  %v925 = phi i64 [ %v614, %bb65 ]
  %v926 = phi i64 [ %v615, %bb65 ]
  %v927 = phi i64 [ %v616, %bb65 ]
  %v928 = phi i64 [ %v617, %bb65 ]
  %v929 = phi i64 [ %v618, %bb65 ]
  %v930 = phi i64 [ %v619, %bb65 ]
  %v931 = phi i64 [ %v620, %bb65 ]
  %v932 = phi i1 [ %v621, %bb65 ]
  %v933 = phi ptr [ %v622, %bb65 ]
  %v934 = phi ptr [ %v623, %bb65 ]
  %v935 = phi ptr [ %v624, %bb65 ]
  %v936 = phi i64 [ %v625, %bb65 ]
  %v937 = phi i1 [ %v626, %bb65 ]
  %v938 = phi i1 [ %v627, %bb65 ]
  %v939 = phi i1 [ %v628, %bb65 ]
  %v940 = phi i1 [ %v629, %bb65 ]
  %v941 = phi i1 [ %v630, %bb65 ]
  %v942 = phi i64 [ %v563, %bb65 ]
  %v943 = phi i64 [ %v564, %bb65 ]
  %v944 = phi i64 [ %v565, %bb65 ]
  %v945 = select i1 true, i64 1, i64 1
  %v946 = add i64 %v944, %v945
  br label %bb58
bb93:
  %v947 = phi i64 [ %v141, %bb16 ]
  %v948 = phi i64 [ %v142, %bb16 ]
  %v949 = phi i64 [ %v143, %bb16 ]
  %v950 = phi i64 [ %v144, %bb16 ]
  %v951 = phi i64 [ %v145, %bb16 ]
  %v952 = phi i64 [ %v146, %bb16 ]
  %v953 = phi i64 [ %v147, %bb16 ]
  %v954 = phi i1 [ %v148, %bb16 ]
  %v955 = phi ptr [ %v149, %bb16 ]
  %v956 = phi ptr [ %v150, %bb16 ]
  %v957 = phi ptr [ %v151, %bb16 ]
  %v958 = phi i64 [ %v124, %bb16 ]
  %v959 = phi i64 [ %v125, %bb16 ]
  %v960 = phi i64 [ %v126, %bb16 ]
  %v961 = select i1 true, i64 1, i64 1
  %v962 = add i64 %v960, %v961
  br label %bb12
}

define i64 @wf_map_cost_library_policy$instance$4250cb78d3f44027(i64 %v0, i64 %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.1 = alloca %wf.t.9d321e1eb2ec1c03, align 8
  %wf.slot.2 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.3 = alloca %wf.t.9d321e1eb2ec1c03, align 8
  %wf.slot.4 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.5 = alloca %wf.t.9d321e1eb2ec1c03, align 8
  %wf.slot.6 = alloca %wf.t.a5ea622fe32c85b6, align 8
  %wf.slot.7 = alloca %wf.t.84597570beb237fa, align 8
  %v7 = alloca %wf.t.ee6ca7dc0a065510, align 8
  %v10 = alloca %wf.t.a5ea622fe32c85b6, align 8
  %v15 = alloca %wf.t.84597570beb237fa, align 8
  %v2 = select i1 true, i64 11400714819323198485, i64 11400714819323198485
  %v3 = xor i64 %v0, %v2
  %v4 = select i1 true, i64 0, i64 0
  %v5 = icmp ne i64 %v1, %v4
  store %wf.t.ee6ca7dc0a065510 zeroinitializer, ptr %v7
  %t0 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v7, i32 0, i32 0
  store i64 %v3, ptr %t0
  %t1 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v7, i32 0, i32 1
  store i1 %v5, ptr %t1
  %v8 = select i1 true, i64 3, i64 3
  call void @wf_hash_map.hash_map_new$instance$96033bf6ddb80743(ptr %v10, i64 %v8)
  %v11 = select i1 true, i64 0, i64 0
  %v12 = select i1 true, i64 0, i64 0
  %v13 = select i1 true, i64 0, i64 0
  store %wf.t.84597570beb237fa zeroinitializer, ptr %v15
  %t2 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v15, i32 0, i32 0
  store i64 %v0, ptr %t2
  %t3 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v15, i32 0, i32 1
  store i64 %v11, ptr %t3
  %t4 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v15, i32 0, i32 2
  store i64 %v12, ptr %t4
  %t5 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v15, i32 0, i32 3
  store i64 %v13, ptr %t5
  %v16 = select i1 true, i64 0, i64 0
  %v17 = select i1 true, i64 3, i64 3
  br label %bb1
bb1:
  %v18 = phi i64 [ %v0, %entry ], [ %v41, %bb5 ]
  %v19 = phi i64 [ %v1, %entry ], [ %v42, %bb5 ]
  %v20 = phi i64 [ %v3, %entry ], [ %v43, %bb5 ]
  %v21 = phi i1 [ %v5, %entry ], [ %v44, %bb5 ]
  %v22 = phi ptr [ %v7, %entry ], [ %v45, %bb5 ]
  %v23 = phi ptr [ %v10, %entry ], [ %v46, %bb5 ]
  %v24 = phi ptr [ %v15, %entry ], [ %v47, %bb5 ]
  %v25 = phi i64 [ %v16, %entry ], [ %v48, %bb5 ]
  %v26 = phi i64 [ %v17, %entry ], [ %v49, %bb5 ]
  %v27 = phi i64 [ %v16, %entry ], [ %v52, %bb5 ]
  %v35 = icmp ult i64 %v27, %v26
  switch i1 %v35, label %invalid.tag.b1 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v36 = call i64 @wf_map_cost_key(i64 %v27)
  %v37 = add i64 %v18, %v27
  call void @wf_map_cost_record_make(ptr %wf.slot.0, i64 %v37)
  call void @wf_hash_map.hash_map_put$instance$8d5197e2f00c3b07(ptr %wf.slot.1, ptr %v23, i64 %v36, ptr %wf.slot.0, ptr %v22)
  %v40 = call i8 @wf_map_cost_library_policy_result$instance$4250cb78d3f44027(ptr %wf.slot.1, ptr %v24)
  br label %bb5
bb3:
  br label %bb4
bb4:
  %v28 = phi i64 [ %v18, %bb3 ]
  %v29 = phi i64 [ %v19, %bb3 ]
  %v30 = phi i64 [ %v20, %bb3 ]
  %v31 = phi i1 [ %v21, %bb3 ]
  %v32 = phi ptr [ %v22, %bb3 ]
  %v33 = phi ptr [ %v23, %bb3 ]
  %v34 = phi ptr [ %v24, %bb3 ]
  %v53 = select i1 true, i64 10, i64 10
  %v54 = add i64 %v28, %v53
  call void @wf_map_cost_record_make(ptr %wf.slot.2, i64 %v54)
  %v56 = select i1 true, i64 1, i64 1
  call void @wf_hash_map.hash_map_put$instance$8d5197e2f00c3b07(ptr %wf.slot.3, ptr %v33, i64 %v56, ptr %wf.slot.2, ptr %v32)
  %v58 = call i8 @wf_map_cost_library_policy_result$instance$4250cb78d3f44027(ptr %wf.slot.3, ptr %v34)
  %v59 = select i1 true, i64 20, i64 20
  %v60 = add i64 %v28, %v59
  call void @wf_map_cost_record_make(ptr %wf.slot.4, i64 %v60)
  %v62 = select i1 true, i64 7, i64 7
  call void @wf_hash_map.hash_map_put$instance$8d5197e2f00c3b07(ptr %wf.slot.5, ptr %v33, i64 %v62, ptr %wf.slot.4, ptr %v32)
  %v64 = call i8 @wf_map_cost_library_policy_result$instance$4250cb78d3f44027(ptr %wf.slot.5, ptr %v34)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.6, ptr %v33, i64 ptrtoint (ptr getelementptr (%wf.t.a5ea622fe32c85b6, ptr null, i32 1) to i64), i1 false)
  %v66 = call i8 @wf_hash_map.hash_map_free$instance$72d84b2e6d0b7146(ptr %wf.slot.6, ptr %v34)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.7, ptr %v34, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %v68 = call i64 @wf_map_cost_finish(ptr %wf.slot.7)
  ret i64 %v68
bb5:
  %v41 = phi i64 [ %v18, %bb2 ]
  %v42 = phi i64 [ %v19, %bb2 ]
  %v43 = phi i64 [ %v20, %bb2 ]
  %v44 = phi i1 [ %v21, %bb2 ]
  %v45 = phi ptr [ %v22, %bb2 ]
  %v46 = phi ptr [ %v23, %bb2 ]
  %v47 = phi ptr [ %v24, %bb2 ]
  %v48 = phi i64 [ %v25, %bb2 ]
  %v49 = phi i64 [ %v26, %bb2 ]
  %v50 = phi i64 [ %v27, %bb2 ]
  %v51 = select i1 true, i64 1, i64 1
  %v52 = add i64 %v50, %v51
  br label %bb1
}

define i64 @wf_map_cost_library_trace$instance$4250cb78d3f44027(i64 %v0, i64 %v1, i64 %v2, i64 %v3, i64 %v4, i64 %v5) #0 {
entry:
  %wf.frame = alloca { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, align 8
  %wf.slot.0 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 0
  %wf.slot.1 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 1
  %wf.slot.2 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 2
  %wf.slot.3 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 3
  %wf.slot.4 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 4
  %wf.slot.5 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 5
  %wf.slot.6 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 6
  %wf.slot.7 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 7
  %wf.slot.8 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 8
  %wf.slot.9 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 9
  %wf.slot.10 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 10
  %wf.slot.11 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 11
  %wf.slot.12 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 12
  %wf.slot.13 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 13
  %wf.slot.14 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 14
  %wf.slot.15 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 15
  %wf.slot.16 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 16
  %wf.slot.17 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 17
  %wf.slot.18 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 18
  %wf.slot.19 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 19
  %wf.slot.20 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 20
  %wf.slot.21 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 21
  %wf.slot.22 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 22
  %wf.slot.23 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 23
  %wf.slot.24 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 24
  %wf.slot.25 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 25
  %wf.slot.26 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 26
  %wf.slot.27 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 27
  %wf.slot.28 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 28
  %wf.slot.29 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 29
  %wf.slot.30 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 30
  %v11 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 31
  %v13 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 32
  %v18 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 33
  %v192 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 34
  %v280 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 35
  %v607 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.e020a813ecac56e1, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.05623e8a192b9069, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 36
  %v6 = select i1 true, i64 11400714819323198485, i64 11400714819323198485
  %v7 = xor i64 %v3, %v6
  %v8 = select i1 true, i64 0, i64 0
  %v9 = icmp ne i64 %v5, %v8
  store %wf.t.ee6ca7dc0a065510 zeroinitializer, ptr %v11
  %t0 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v11, i32 0, i32 0
  store i64 %v7, ptr %t0
  %t1 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v11, i32 0, i32 1
  store i1 %v9, ptr %t1
  call void @wf_hash_map.hash_map_new$instance$0e108827ecbbe374(ptr %v13, i64 %v0)
  %v14 = select i1 true, i64 0, i64 0
  %v15 = select i1 true, i64 0, i64 0
  %v16 = select i1 true, i64 0, i64 0
  store %wf.t.84597570beb237fa zeroinitializer, ptr %v18
  %t2 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v18, i32 0, i32 0
  store i64 %v3, ptr %t2
  %t3 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v18, i32 0, i32 1
  store i64 %v14, ptr %t3
  %t4 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v18, i32 0, i32 2
  store i64 %v15, ptr %t4
  %t5 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v18, i32 0, i32 3
  store i64 %v16, ptr %t5
  %v19 = select i1 true, i64 0, i64 0
  br label %bb1
bb1:
  %v20 = phi i64 [ %v0, %entry ], [ %v96, %bb11 ]
  %v21 = phi i64 [ %v1, %entry ], [ %v97, %bb11 ]
  %v22 = phi i64 [ %v2, %entry ], [ %v98, %bb11 ]
  %v23 = phi i64 [ %v3, %entry ], [ %v99, %bb11 ]
  %v24 = phi i64 [ %v4, %entry ], [ %v100, %bb11 ]
  %v25 = phi i64 [ %v5, %entry ], [ %v101, %bb11 ]
  %v26 = phi i64 [ %v7, %entry ], [ %v102, %bb11 ]
  %v27 = phi i1 [ %v9, %entry ], [ %v103, %bb11 ]
  %v28 = phi ptr [ %v11, %entry ], [ %v104, %bb11 ]
  %v29 = phi ptr [ %v13, %entry ], [ %v105, %bb11 ]
  %v30 = phi ptr [ %v18, %entry ], [ %v106, %bb11 ]
  %v31 = phi i64 [ %v19, %entry ], [ %v107, %bb11 ]
  %v32 = phi i64 [ %v1, %entry ], [ %v108, %bb11 ]
  %v33 = phi i64 [ %v19, %entry ], [ %v111, %bb11 ]
  %v45 = icmp ult i64 %v33, %v32
  switch i1 %v45, label %invalid.tag.b1 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v46 = call i64 @wf_map_cost_key(i64 %v33)
  %v47 = add i64 %v23, %v33
  call void @wf_map_cost_record_make(ptr %wf.slot.0, i64 %v47)
  call void @wf_hash_map.hash_map_put$instance$28da32efc51c2b65(ptr %wf.slot.1, ptr %v29, i64 %v46, ptr %wf.slot.0, ptr %v28)
  %t6 = load %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.1
  %t7 = extractvalue %wf.t.9d321e1eb2ec1c03 %t6, 0
  switch i32 %t7, label %invalid.tag.b2 [
    i32 0, label %bb6
    i32 1, label %bb7
  ]
invalid.tag.b2:
  call void @abort()
  unreachable
bb3:
  br label %bb4
bb4:
  %v34 = phi i64 [ %v20, %bb3 ]
  %v35 = phi i64 [ %v21, %bb3 ]
  %v36 = phi i64 [ %v22, %bb3 ]
  %v37 = phi i64 [ %v23, %bb3 ]
  %v38 = phi i64 [ %v24, %bb3 ]
  %v39 = phi i64 [ %v25, %bb3 ]
  %v40 = phi i64 [ %v26, %bb3 ]
  %v41 = phi i1 [ %v27, %bb3 ]
  %v42 = phi ptr [ %v28, %bb3 ]
  %v43 = phi ptr [ %v29, %bb3 ]
  %v44 = phi ptr [ %v30, %bb3 ]
  %v112 = select i1 true, i64 0, i64 0
  br label %bb12
bb5:
  %v50 = phi i64 [ %v20, %bb6 ], [ %v70, %bb8 ]
  %v51 = phi i64 [ %v21, %bb6 ], [ %v71, %bb8 ]
  %v52 = phi i64 [ %v22, %bb6 ], [ %v72, %bb8 ]
  %v53 = phi i64 [ %v23, %bb6 ], [ %v73, %bb8 ]
  %v54 = phi i64 [ %v24, %bb6 ], [ %v74, %bb8 ]
  %v55 = phi i64 [ %v25, %bb6 ], [ %v75, %bb8 ]
  %v56 = phi i64 [ %v26, %bb6 ], [ %v76, %bb8 ]
  %v57 = phi i1 [ %v27, %bb6 ], [ %v77, %bb8 ]
  %v58 = phi ptr [ %v28, %bb6 ], [ %v78, %bb8 ]
  %v59 = phi ptr [ %v29, %bb6 ], [ %v79, %bb8 ]
  %v60 = phi ptr [ %v30, %bb6 ], [ %v80, %bb8 ]
  %v61 = phi i64 [ %v33, %bb6 ], [ %v81, %bb8 ]
  %v62 = phi i64 [ %v46, %bb6 ], [ %v82, %bb8 ]
  %v63 = phi i64 [ %v47, %bb6 ], [ %v83, %bb8 ]
  br label %bb11
bb6:
  %v66 = select i1 true, i64 0, i64 0
  %v67 = call i8 @wf_map_cost_ordered(ptr %v30, i64 %v66)
  br label %bb5
bb7:
  %t8 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.1, i32 0, i32 1
  %v68 = load i1, ptr %t8
  %t9 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.1, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %t9, i64 ptrtoint (ptr getelementptr (%wf.t.20dda3774c7510ec, ptr null, i32 1) to i64), i1 false)
  switch i1 %v68, label %invalid.tag.b7 [
    i1 0, label %bb9
    i1 1, label %bb10
  ]
invalid.tag.b7:
  call void @abort()
  unreachable
bb8:
  %v70 = phi i64 [ %v20, %bb9 ], [ %v20, %bb10 ]
  %v71 = phi i64 [ %v21, %bb9 ], [ %v21, %bb10 ]
  %v72 = phi i64 [ %v22, %bb9 ], [ %v22, %bb10 ]
  %v73 = phi i64 [ %v23, %bb9 ], [ %v23, %bb10 ]
  %v74 = phi i64 [ %v24, %bb9 ], [ %v24, %bb10 ]
  %v75 = phi i64 [ %v25, %bb9 ], [ %v25, %bb10 ]
  %v76 = phi i64 [ %v26, %bb9 ], [ %v26, %bb10 ]
  %v77 = phi i1 [ %v27, %bb9 ], [ %v27, %bb10 ]
  %v78 = phi ptr [ %v28, %bb9 ], [ %v28, %bb10 ]
  %v79 = phi ptr [ %v29, %bb9 ], [ %v29, %bb10 ]
  %v80 = phi ptr [ %v30, %bb9 ], [ %v30, %bb10 ]
  %v81 = phi i64 [ %v33, %bb9 ], [ %v33, %bb10 ]
  %v82 = phi i64 [ %v46, %bb9 ], [ %v46, %bb10 ]
  %v83 = phi i64 [ %v47, %bb9 ], [ %v47, %bb10 ]
  %v86 = phi i1 [ %v68, %bb9 ], [ %v68, %bb10 ]
  %t10 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.2, i32 0, i32 0
  %v92 = load i64, ptr %t10
  ; ownership-consuming projection
  %t11 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.2, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.3, ptr %t11, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %v94 = call i64 @wf_map_cost_record_content(i64 %v92, ptr %wf.slot.3)
  %v95 = call i8 @wf_map_cost_ordered(ptr %v80, i64 %v94)
  br label %bb5
bb9:
  %v88 = select i1 true, i64 1, i64 1
  %v89 = call i8 @wf_map_cost_ordered(ptr %v30, i64 %v88)
  br label %bb8
bb10:
  %v90 = select i1 true, i64 2, i64 2
  %v91 = call i8 @wf_map_cost_ordered(ptr %v30, i64 %v90)
  br label %bb8
bb11:
  %v96 = phi i64 [ %v50, %bb5 ]
  %v97 = phi i64 [ %v51, %bb5 ]
  %v98 = phi i64 [ %v52, %bb5 ]
  %v99 = phi i64 [ %v53, %bb5 ]
  %v100 = phi i64 [ %v54, %bb5 ]
  %v101 = phi i64 [ %v55, %bb5 ]
  %v102 = phi i64 [ %v56, %bb5 ]
  %v103 = phi i1 [ %v57, %bb5 ]
  %v104 = phi ptr [ %v58, %bb5 ]
  %v105 = phi ptr [ %v59, %bb5 ]
  %v106 = phi ptr [ %v60, %bb5 ]
  %v107 = phi i64 [ %v31, %bb5 ]
  %v108 = phi i64 [ %v32, %bb5 ]
  %v109 = phi i64 [ %v33, %bb5 ]
  %v110 = select i1 true, i64 1, i64 1
  %v111 = add i64 %v109, %v110
  br label %bb1
bb12:
  %v113 = phi i64 [ %v34, %bb4 ], [ %v947, %bb93 ]
  %v114 = phi i64 [ %v35, %bb4 ], [ %v948, %bb93 ]
  %v115 = phi i64 [ %v36, %bb4 ], [ %v949, %bb93 ]
  %v116 = phi i64 [ %v37, %bb4 ], [ %v950, %bb93 ]
  %v117 = phi i64 [ %v38, %bb4 ], [ %v951, %bb93 ]
  %v118 = phi i64 [ %v39, %bb4 ], [ %v952, %bb93 ]
  %v119 = phi i64 [ %v40, %bb4 ], [ %v953, %bb93 ]
  %v120 = phi i1 [ %v41, %bb4 ], [ %v954, %bb93 ]
  %v121 = phi ptr [ %v42, %bb4 ], [ %v955, %bb93 ]
  %v122 = phi ptr [ %v43, %bb4 ], [ %v956, %bb93 ]
  %v123 = phi ptr [ %v44, %bb4 ], [ %v957, %bb93 ]
  %v124 = phi i64 [ %v112, %bb4 ], [ %v958, %bb93 ]
  %v125 = phi i64 [ %v36, %bb4 ], [ %v959, %bb93 ]
  %v126 = phi i64 [ %v112, %bb4 ], [ %v962, %bb93 ]
  %v138 = icmp ult i64 %v126, %v125
  switch i1 %v138, label %invalid.tag.b12 [
    i1 1, label %bb13
    i1 0, label %bb14
  ]
invalid.tag.b12:
  call void @abort()
  unreachable
bb13:
  %v139 = select i1 true, i64 5, i64 5
  %v140 = icmp eq i64 %v117, %v139
  switch i1 %v140, label %invalid.tag.b13 [
    i1 1, label %bb17
    i1 0, label %bb18
  ]
invalid.tag.b13:
  call void @abort()
  unreachable
bb14:
  br label %bb15
bb15:
  %v127 = phi i64 [ %v113, %bb14 ]
  %v128 = phi i64 [ %v114, %bb14 ]
  %v129 = phi i64 [ %v115, %bb14 ]
  %v130 = phi i64 [ %v116, %bb14 ]
  %v131 = phi i64 [ %v117, %bb14 ]
  %v132 = phi i64 [ %v118, %bb14 ]
  %v133 = phi i64 [ %v119, %bb14 ]
  %v134 = phi i1 [ %v120, %bb14 ]
  %v135 = phi ptr [ %v121, %bb14 ]
  %v136 = phi ptr [ %v122, %bb14 ]
  %v137 = phi ptr [ %v123, %bb14 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.29, ptr %v136, i64 ptrtoint (ptr getelementptr (%wf.t.05623e8a192b9069, ptr null, i32 1) to i64), i1 false)
  %v964 = call i8 @wf_hash_map.hash_map_free$instance$d5f8785ab7665d71(ptr %wf.slot.29, ptr %v137)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.30, ptr %v137, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %v966 = call i64 @wf_map_cost_finish(ptr %wf.slot.30)
  ret i64 %v966
bb16:
  %v141 = phi i64 [ %v322, %bb35 ], [ %v566, %bb61 ]
  %v142 = phi i64 [ %v323, %bb35 ], [ %v567, %bb61 ]
  %v143 = phi i64 [ %v324, %bb35 ], [ %v568, %bb61 ]
  %v144 = phi i64 [ %v325, %bb35 ], [ %v569, %bb61 ]
  %v145 = phi i64 [ %v326, %bb35 ], [ %v570, %bb61 ]
  %v146 = phi i64 [ %v327, %bb35 ], [ %v571, %bb61 ]
  %v147 = phi i64 [ %v328, %bb35 ], [ %v572, %bb61 ]
  %v148 = phi i1 [ %v329, %bb35 ], [ %v573, %bb61 ]
  %v149 = phi ptr [ %v330, %bb35 ], [ %v574, %bb61 ]
  %v150 = phi ptr [ %v331, %bb35 ], [ %v575, %bb61 ]
  %v151 = phi ptr [ %v332, %bb35 ], [ %v576, %bb61 ]
  %v152 = phi i64 [ %v333, %bb35 ], [ %v577, %bb61 ]
  br label %bb93
bb17:
  %v153 = select i1 true, i64 2, i64 2
  %v154 = udiv i64 %v114, %v153
  %v155 = sub nuw i64 %v114, %v154
  %v156 = select i1 true, i64 0, i64 0
  br label %bb19
bb18:
  %v430 = select i1 true, i64 4, i64 4
  %v431 = icmp eq i64 %v117, %v430
  %v432 = select i1 true, i64 9, i64 9
  %v433 = icmp eq i64 %v117, %v432
  %v434 = select i1 true, i64 10, i64 10
  %v435 = icmp eq i64 %v117, %v434
  %v436 = or i1 %v433, %v435
  %v437 = or i1 %v431, %v436
  switch i1 %v437, label %invalid.tag.b18 [
    i1 1, label %bb44
    i1 0, label %bb45
  ]
invalid.tag.b18:
  call void @abort()
  unreachable
bb19:
  %v157 = phi i64 [ %v113, %bb17 ], [ %v223, %bb26 ]
  %v158 = phi i64 [ %v114, %bb17 ], [ %v224, %bb26 ]
  %v159 = phi i64 [ %v115, %bb17 ], [ %v225, %bb26 ]
  %v160 = phi i64 [ %v116, %bb17 ], [ %v226, %bb26 ]
  %v161 = phi i64 [ %v117, %bb17 ], [ %v227, %bb26 ]
  %v162 = phi i64 [ %v118, %bb17 ], [ %v228, %bb26 ]
  %v163 = phi i64 [ %v119, %bb17 ], [ %v229, %bb26 ]
  %v164 = phi i1 [ %v120, %bb17 ], [ %v230, %bb26 ]
  %v165 = phi ptr [ %v121, %bb17 ], [ %v231, %bb26 ]
  %v166 = phi ptr [ %v122, %bb17 ], [ %v232, %bb26 ]
  %v167 = phi ptr [ %v123, %bb17 ], [ %v233, %bb26 ]
  %v168 = phi i64 [ %v126, %bb17 ], [ %v234, %bb26 ]
  %v169 = phi i64 [ %v154, %bb17 ], [ %v235, %bb26 ]
  %v170 = phi i64 [ %v155, %bb17 ], [ %v236, %bb26 ]
  %v171 = phi i64 [ %v156, %bb17 ], [ %v237, %bb26 ]
  %v172 = phi i64 [ %v155, %bb17 ], [ %v238, %bb26 ]
  %v173 = phi i64 [ %v156, %bb17 ], [ %v241, %bb26 ]
  %v188 = icmp ult i64 %v173, %v172
  switch i1 %v188, label %invalid.tag.b19 [
    i1 1, label %bb20
    i1 0, label %bb21
  ]
invalid.tag.b19:
  call void @abort()
  unreachable
bb20:
  %v189 = select i1 true, i64 2, i64 2
  %v190 = mul i64 %v173, %v189
  %v191 = call i64 @wf_map_cost_key(i64 %v190)
  store i64 %v191, ptr %v192
  call void @wf_hash_map.hash_map_remove$instance$28da32efc51c2b65(ptr %wf.slot.4, ptr %v166, ptr %v192, ptr %v165)
  %t12 = load %wf.t.e020a813ecac56e1, ptr %wf.slot.4
  %t13 = extractvalue %wf.t.e020a813ecac56e1 %t12, 0
  switch i32 %t13, label %invalid.tag.b20 [
    i32 1, label %bb24
    i32 0, label %bb25
  ]
invalid.tag.b20:
  call void @abort()
  unreachable
bb21:
  br label %bb22
bb22:
  %v174 = phi i64 [ %v157, %bb21 ]
  %v175 = phi i64 [ %v158, %bb21 ]
  %v176 = phi i64 [ %v159, %bb21 ]
  %v177 = phi i64 [ %v160, %bb21 ]
  %v178 = phi i64 [ %v161, %bb21 ]
  %v179 = phi i64 [ %v162, %bb21 ]
  %v180 = phi i64 [ %v163, %bb21 ]
  %v181 = phi i1 [ %v164, %bb21 ]
  %v182 = phi ptr [ %v165, %bb21 ]
  %v183 = phi ptr [ %v166, %bb21 ]
  %v184 = phi ptr [ %v167, %bb21 ]
  %v185 = phi i64 [ %v168, %bb21 ]
  %v186 = phi i64 [ %v169, %bb21 ]
  %v187 = phi i64 [ %v170, %bb21 ]
  %v242 = call %wf.t.7d7f918f7b4962fd @wf_hash_map.hash_map_rehash$instance$28da32efc51c2b65(ptr %v183, ptr %v182)
  store %wf.t.7d7f918f7b4962fd %v242, ptr %wf.slot.8
  %v243 = call i8 @wf_map_cost_rebuild_result(ptr %wf.slot.8, ptr %v184)
  %v244 = select i1 true, i64 0, i64 0
  br label %bb27
bb23:
  %v194 = phi i64 [ %v157, %bb24 ], [ %v157, %bb25 ]
  %v195 = phi i64 [ %v158, %bb24 ], [ %v158, %bb25 ]
  %v196 = phi i64 [ %v159, %bb24 ], [ %v159, %bb25 ]
  %v197 = phi i64 [ %v160, %bb24 ], [ %v160, %bb25 ]
  %v198 = phi i64 [ %v161, %bb24 ], [ %v161, %bb25 ]
  %v199 = phi i64 [ %v162, %bb24 ], [ %v162, %bb25 ]
  %v200 = phi i64 [ %v163, %bb24 ], [ %v163, %bb25 ]
  %v201 = phi i1 [ %v164, %bb24 ], [ %v164, %bb25 ]
  %v202 = phi ptr [ %v165, %bb24 ], [ %v165, %bb25 ]
  %v203 = phi ptr [ %v166, %bb24 ], [ %v166, %bb25 ]
  %v204 = phi ptr [ %v167, %bb24 ], [ %v167, %bb25 ]
  %v205 = phi i64 [ %v168, %bb24 ], [ %v168, %bb25 ]
  %v206 = phi i64 [ %v169, %bb24 ], [ %v169, %bb25 ]
  %v207 = phi i64 [ %v170, %bb24 ], [ %v170, %bb25 ]
  %v208 = phi i64 [ %v173, %bb24 ], [ %v173, %bb25 ]
  %v209 = phi i64 [ %v190, %bb24 ], [ %v190, %bb25 ]
  %v210 = phi ptr [ %v192, %bb24 ], [ %v192, %bb25 ]
  %v221 = call %wf.t.b7e1ed626c09888a @wf_hash_map.hash_map_lookup$instance$000400fb603e42fe(ptr %v203, ptr %v210, ptr %v202, ptr %v204)
  store %wf.t.b7e1ed626c09888a %v221, ptr %wf.slot.7
  %v222 = call i8 @wf_map_cost_lookup_result(ptr %wf.slot.7, ptr %v204)
  br label %bb26
bb24:
  %t14 = getelementptr inbounds %wf.t.e020a813ecac56e1, ptr %wf.slot.4, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.5, ptr %t14, i64 ptrtoint (ptr getelementptr (%wf.t.20dda3774c7510ec, ptr null, i32 1) to i64), i1 false)
  %v213 = select i1 true, i64 1, i64 1
  %v214 = call i8 @wf_map_cost_ordered(ptr %v167, i64 %v213)
  %t15 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.5, i32 0, i32 0
  %v215 = load i64, ptr %t15
  ; ownership-consuming projection
  %t16 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.5, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.6, ptr %t16, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %v217 = call i64 @wf_map_cost_record_content(i64 %v215, ptr %wf.slot.6)
  %v218 = call i8 @wf_map_cost_ordered(ptr %v167, i64 %v217)
  br label %bb23
bb25:
  %v219 = select i1 true, i64 0, i64 0
  %v220 = call i8 @wf_map_cost_ordered(ptr %v167, i64 %v219)
  br label %bb23
bb26:
  %v223 = phi i64 [ %v194, %bb23 ]
  %v224 = phi i64 [ %v195, %bb23 ]
  %v225 = phi i64 [ %v196, %bb23 ]
  %v226 = phi i64 [ %v197, %bb23 ]
  %v227 = phi i64 [ %v198, %bb23 ]
  %v228 = phi i64 [ %v199, %bb23 ]
  %v229 = phi i64 [ %v200, %bb23 ]
  %v230 = phi i1 [ %v201, %bb23 ]
  %v231 = phi ptr [ %v202, %bb23 ]
  %v232 = phi ptr [ %v203, %bb23 ]
  %v233 = phi ptr [ %v204, %bb23 ]
  %v234 = phi i64 [ %v205, %bb23 ]
  %v235 = phi i64 [ %v206, %bb23 ]
  %v236 = phi i64 [ %v207, %bb23 ]
  %v237 = phi i64 [ %v171, %bb23 ]
  %v238 = phi i64 [ %v172, %bb23 ]
  %v239 = phi i64 [ %v173, %bb23 ]
  %v240 = select i1 true, i64 1, i64 1
  %v241 = add i64 %v239, %v240
  br label %bb19
bb27:
  %v245 = phi i64 [ %v174, %bb22 ], [ %v283, %bb31 ]
  %v246 = phi i64 [ %v175, %bb22 ], [ %v284, %bb31 ]
  %v247 = phi i64 [ %v176, %bb22 ], [ %v285, %bb31 ]
  %v248 = phi i64 [ %v177, %bb22 ], [ %v286, %bb31 ]
  %v249 = phi i64 [ %v178, %bb22 ], [ %v287, %bb31 ]
  %v250 = phi i64 [ %v179, %bb22 ], [ %v288, %bb31 ]
  %v251 = phi i64 [ %v180, %bb22 ], [ %v289, %bb31 ]
  %v252 = phi i1 [ %v181, %bb22 ], [ %v290, %bb31 ]
  %v253 = phi ptr [ %v182, %bb22 ], [ %v291, %bb31 ]
  %v254 = phi ptr [ %v183, %bb22 ], [ %v292, %bb31 ]
  %v255 = phi ptr [ %v184, %bb22 ], [ %v293, %bb31 ]
  %v256 = phi i64 [ %v185, %bb22 ], [ %v294, %bb31 ]
  %v257 = phi i64 [ %v186, %bb22 ], [ %v295, %bb31 ]
  %v258 = phi i64 [ %v187, %bb22 ], [ %v296, %bb31 ]
  %v260 = phi i64 [ %v244, %bb22 ], [ %v298, %bb31 ]
  %v261 = phi i64 [ %v175, %bb22 ], [ %v299, %bb31 ]
  %v262 = phi i64 [ %v244, %bb22 ], [ %v302, %bb31 ]
  %v278 = icmp ult i64 %v262, %v261
  switch i1 %v278, label %invalid.tag.b27 [
    i1 1, label %bb28
    i1 0, label %bb29
  ]
invalid.tag.b27:
  call void @abort()
  unreachable
bb28:
  %v279 = call i64 @wf_map_cost_key(i64 %v262)
  store i64 %v279, ptr %v280
  %v281 = call %wf.t.b7e1ed626c09888a @wf_hash_map.hash_map_lookup$instance$000400fb603e42fe(ptr %v254, ptr %v280, ptr %v253, ptr %v255)
  store %wf.t.b7e1ed626c09888a %v281, ptr %wf.slot.9
  %v282 = call i8 @wf_map_cost_lookup_result(ptr %wf.slot.9, ptr %v255)
  br label %bb31
bb29:
  br label %bb30
bb30:
  %v263 = phi i64 [ %v245, %bb29 ]
  %v264 = phi i64 [ %v246, %bb29 ]
  %v265 = phi i64 [ %v247, %bb29 ]
  %v266 = phi i64 [ %v248, %bb29 ]
  %v267 = phi i64 [ %v249, %bb29 ]
  %v268 = phi i64 [ %v250, %bb29 ]
  %v269 = phi i64 [ %v251, %bb29 ]
  %v270 = phi i1 [ %v252, %bb29 ]
  %v271 = phi ptr [ %v253, %bb29 ]
  %v272 = phi ptr [ %v254, %bb29 ]
  %v273 = phi ptr [ %v255, %bb29 ]
  %v274 = phi i64 [ %v256, %bb29 ]
  %v275 = phi i64 [ %v257, %bb29 ]
  %v276 = phi i64 [ %v258, %bb29 ]
  %v303 = select i1 true, i64 0, i64 0
  br label %bb32
bb31:
  %v283 = phi i64 [ %v245, %bb28 ]
  %v284 = phi i64 [ %v246, %bb28 ]
  %v285 = phi i64 [ %v247, %bb28 ]
  %v286 = phi i64 [ %v248, %bb28 ]
  %v287 = phi i64 [ %v249, %bb28 ]
  %v288 = phi i64 [ %v250, %bb28 ]
  %v289 = phi i64 [ %v251, %bb28 ]
  %v290 = phi i1 [ %v252, %bb28 ]
  %v291 = phi ptr [ %v253, %bb28 ]
  %v292 = phi ptr [ %v254, %bb28 ]
  %v293 = phi ptr [ %v255, %bb28 ]
  %v294 = phi i64 [ %v256, %bb28 ]
  %v295 = phi i64 [ %v257, %bb28 ]
  %v296 = phi i64 [ %v258, %bb28 ]
  %v298 = phi i64 [ %v260, %bb28 ]
  %v299 = phi i64 [ %v261, %bb28 ]
  %v300 = phi i64 [ %v262, %bb28 ]
  %v301 = select i1 true, i64 1, i64 1
  %v302 = add i64 %v300, %v301
  br label %bb27
bb32:
  %v304 = phi i64 [ %v263, %bb30 ], [ %v410, %bb42 ]
  %v305 = phi i64 [ %v264, %bb30 ], [ %v411, %bb42 ]
  %v306 = phi i64 [ %v265, %bb30 ], [ %v412, %bb42 ]
  %v307 = phi i64 [ %v266, %bb30 ], [ %v413, %bb42 ]
  %v308 = phi i64 [ %v267, %bb30 ], [ %v414, %bb42 ]
  %v309 = phi i64 [ %v268, %bb30 ], [ %v415, %bb42 ]
  %v310 = phi i64 [ %v269, %bb30 ], [ %v416, %bb42 ]
  %v311 = phi i1 [ %v270, %bb30 ], [ %v417, %bb42 ]
  %v312 = phi ptr [ %v271, %bb30 ], [ %v418, %bb42 ]
  %v313 = phi ptr [ %v272, %bb30 ], [ %v419, %bb42 ]
  %v314 = phi ptr [ %v273, %bb30 ], [ %v420, %bb42 ]
  %v315 = phi i64 [ %v274, %bb30 ], [ %v421, %bb42 ]
  %v316 = phi i64 [ %v275, %bb30 ], [ %v422, %bb42 ]
  %v317 = phi i64 [ %v276, %bb30 ], [ %v423, %bb42 ]
  %v319 = phi i64 [ %v303, %bb30 ], [ %v425, %bb42 ]
  %v320 = phi i64 [ %v276, %bb30 ], [ %v426, %bb42 ]
  %v321 = phi i64 [ %v303, %bb30 ], [ %v429, %bb42 ]
  %v337 = icmp ult i64 %v321, %v320
  switch i1 %v337, label %invalid.tag.b32 [
    i1 1, label %bb33
    i1 0, label %bb34
  ]
invalid.tag.b32:
  call void @abort()
  unreachable
bb33:
  %v338 = select i1 true, i64 2, i64 2
  %v339 = mul i64 %v321, %v338
  %v340 = call i64 @wf_map_cost_key(i64 %v339)
  %v341 = select i1 true, i64 1, i64 1
  %v342 = add i64 %v315, %v341
  %v343 = mul i64 %v342, %v305
  %v344 = add i64 %v307, %v343
  %v345 = add i64 %v344, %v339
  call void @wf_map_cost_record_make(ptr %wf.slot.10, i64 %v345)
  call void @wf_hash_map.hash_map_put$instance$28da32efc51c2b65(ptr %wf.slot.11, ptr %v313, i64 %v340, ptr %wf.slot.10, ptr %v312)
  %t17 = load %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.11
  %t18 = extractvalue %wf.t.9d321e1eb2ec1c03 %t17, 0
  switch i32 %t18, label %invalid.tag.b33 [
    i32 0, label %bb37
    i32 1, label %bb38
  ]
invalid.tag.b33:
  call void @abort()
  unreachable
bb34:
  br label %bb35
bb35:
  %v322 = phi i64 [ %v304, %bb34 ]
  %v323 = phi i64 [ %v305, %bb34 ]
  %v324 = phi i64 [ %v306, %bb34 ]
  %v325 = phi i64 [ %v307, %bb34 ]
  %v326 = phi i64 [ %v308, %bb34 ]
  %v327 = phi i64 [ %v309, %bb34 ]
  %v328 = phi i64 [ %v310, %bb34 ]
  %v329 = phi i1 [ %v311, %bb34 ]
  %v330 = phi ptr [ %v312, %bb34 ]
  %v331 = phi ptr [ %v313, %bb34 ]
  %v332 = phi ptr [ %v314, %bb34 ]
  %v333 = phi i64 [ %v315, %bb34 ]
  %v334 = phi i64 [ %v316, %bb34 ]
  %v335 = phi i64 [ %v317, %bb34 ]
  br label %bb16
bb36:
  %v348 = phi i64 [ %v304, %bb37 ], [ %v376, %bb39 ]
  %v349 = phi i64 [ %v305, %bb37 ], [ %v377, %bb39 ]
  %v350 = phi i64 [ %v306, %bb37 ], [ %v378, %bb39 ]
  %v351 = phi i64 [ %v307, %bb37 ], [ %v379, %bb39 ]
  %v352 = phi i64 [ %v308, %bb37 ], [ %v380, %bb39 ]
  %v353 = phi i64 [ %v309, %bb37 ], [ %v381, %bb39 ]
  %v354 = phi i64 [ %v310, %bb37 ], [ %v382, %bb39 ]
  %v355 = phi i1 [ %v311, %bb37 ], [ %v383, %bb39 ]
  %v356 = phi ptr [ %v312, %bb37 ], [ %v384, %bb39 ]
  %v357 = phi ptr [ %v313, %bb37 ], [ %v385, %bb39 ]
  %v358 = phi ptr [ %v314, %bb37 ], [ %v386, %bb39 ]
  %v359 = phi i64 [ %v315, %bb37 ], [ %v387, %bb39 ]
  %v360 = phi i64 [ %v316, %bb37 ], [ %v388, %bb39 ]
  %v361 = phi i64 [ %v317, %bb37 ], [ %v389, %bb39 ]
  %v363 = phi i64 [ %v321, %bb37 ], [ %v391, %bb39 ]
  %v364 = phi i64 [ %v339, %bb37 ], [ %v392, %bb39 ]
  %v365 = phi i64 [ %v340, %bb37 ], [ %v393, %bb39 ]
  %v366 = phi i64 [ %v342, %bb37 ], [ %v394, %bb39 ]
  %v367 = phi i64 [ %v343, %bb37 ], [ %v395, %bb39 ]
  %v368 = phi i64 [ %v344, %bb37 ], [ %v396, %bb39 ]
  %v369 = phi i64 [ %v345, %bb37 ], [ %v397, %bb39 ]
  br label %bb42
bb37:
  %v372 = select i1 true, i64 0, i64 0
  %v373 = call i8 @wf_map_cost_ordered(ptr %v314, i64 %v372)
  br label %bb36
bb38:
  %t19 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.11, i32 0, i32 1
  %v374 = load i1, ptr %t19
  %t20 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.11, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.12, ptr %t20, i64 ptrtoint (ptr getelementptr (%wf.t.20dda3774c7510ec, ptr null, i32 1) to i64), i1 false)
  switch i1 %v374, label %invalid.tag.b38 [
    i1 0, label %bb40
    i1 1, label %bb41
  ]
invalid.tag.b38:
  call void @abort()
  unreachable
bb39:
  %v376 = phi i64 [ %v304, %bb40 ], [ %v304, %bb41 ]
  %v377 = phi i64 [ %v305, %bb40 ], [ %v305, %bb41 ]
  %v378 = phi i64 [ %v306, %bb40 ], [ %v306, %bb41 ]
  %v379 = phi i64 [ %v307, %bb40 ], [ %v307, %bb41 ]
  %v380 = phi i64 [ %v308, %bb40 ], [ %v308, %bb41 ]
  %v381 = phi i64 [ %v309, %bb40 ], [ %v309, %bb41 ]
  %v382 = phi i64 [ %v310, %bb40 ], [ %v310, %bb41 ]
  %v383 = phi i1 [ %v311, %bb40 ], [ %v311, %bb41 ]
  %v384 = phi ptr [ %v312, %bb40 ], [ %v312, %bb41 ]
  %v385 = phi ptr [ %v313, %bb40 ], [ %v313, %bb41 ]
  %v386 = phi ptr [ %v314, %bb40 ], [ %v314, %bb41 ]
  %v387 = phi i64 [ %v315, %bb40 ], [ %v315, %bb41 ]
  %v388 = phi i64 [ %v316, %bb40 ], [ %v316, %bb41 ]
  %v389 = phi i64 [ %v317, %bb40 ], [ %v317, %bb41 ]
  %v391 = phi i64 [ %v321, %bb40 ], [ %v321, %bb41 ]
  %v392 = phi i64 [ %v339, %bb40 ], [ %v339, %bb41 ]
  %v393 = phi i64 [ %v340, %bb40 ], [ %v340, %bb41 ]
  %v394 = phi i64 [ %v342, %bb40 ], [ %v342, %bb41 ]
  %v395 = phi i64 [ %v343, %bb40 ], [ %v343, %bb41 ]
  %v396 = phi i64 [ %v344, %bb40 ], [ %v344, %bb41 ]
  %v397 = phi i64 [ %v345, %bb40 ], [ %v345, %bb41 ]
  %v400 = phi i1 [ %v374, %bb40 ], [ %v374, %bb41 ]
  %t21 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.12, i32 0, i32 0
  %v406 = load i64, ptr %t21
  ; ownership-consuming projection
  %t22 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.12, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.13, ptr %t22, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %v408 = call i64 @wf_map_cost_record_content(i64 %v406, ptr %wf.slot.13)
  %v409 = call i8 @wf_map_cost_ordered(ptr %v386, i64 %v408)
  br label %bb36
bb40:
  %v402 = select i1 true, i64 1, i64 1
  %v403 = call i8 @wf_map_cost_ordered(ptr %v314, i64 %v402)
  br label %bb39
bb41:
  %v404 = select i1 true, i64 2, i64 2
  %v405 = call i8 @wf_map_cost_ordered(ptr %v314, i64 %v404)
  br label %bb39
bb42:
  %v410 = phi i64 [ %v348, %bb36 ]
  %v411 = phi i64 [ %v349, %bb36 ]
  %v412 = phi i64 [ %v350, %bb36 ]
  %v413 = phi i64 [ %v351, %bb36 ]
  %v414 = phi i64 [ %v352, %bb36 ]
  %v415 = phi i64 [ %v353, %bb36 ]
  %v416 = phi i64 [ %v354, %bb36 ]
  %v417 = phi i1 [ %v355, %bb36 ]
  %v418 = phi ptr [ %v356, %bb36 ]
  %v419 = phi ptr [ %v357, %bb36 ]
  %v420 = phi ptr [ %v358, %bb36 ]
  %v421 = phi i64 [ %v359, %bb36 ]
  %v422 = phi i64 [ %v360, %bb36 ]
  %v423 = phi i64 [ %v361, %bb36 ]
  %v425 = phi i64 [ %v319, %bb36 ]
  %v426 = phi i64 [ %v320, %bb36 ]
  %v427 = phi i64 [ %v321, %bb36 ]
  %v428 = select i1 true, i64 1, i64 1
  %v429 = add i64 %v427, %v428
  br label %bb32
bb43:
  %v438 = phi i64 [ %v113, %bb45 ], [ %v502, %bb52 ]
  %v439 = phi i64 [ %v114, %bb45 ], [ %v503, %bb52 ]
  %v440 = phi i64 [ %v115, %bb45 ], [ %v504, %bb52 ]
  %v441 = phi i64 [ %v116, %bb45 ], [ %v505, %bb52 ]
  %v442 = phi i64 [ %v117, %bb45 ], [ %v506, %bb52 ]
  %v443 = phi i64 [ %v118, %bb45 ], [ %v507, %bb52 ]
  %v444 = phi i64 [ %v119, %bb45 ], [ %v508, %bb52 ]
  %v445 = phi i1 [ %v120, %bb45 ], [ %v509, %bb52 ]
  %v446 = phi ptr [ %v121, %bb45 ], [ %v510, %bb52 ]
  %v447 = phi ptr [ %v122, %bb45 ], [ %v511, %bb52 ]
  %v448 = phi ptr [ %v123, %bb45 ], [ %v512, %bb52 ]
  %v449 = phi i64 [ %v126, %bb45 ], [ %v513, %bb52 ]
  %v450 = phi i1 [ %v431, %bb45 ], [ %v514, %bb52 ]
  %v451 = phi i1 [ %v433, %bb45 ], [ %v515, %bb52 ]
  %v452 = phi i1 [ %v435, %bb45 ], [ %v516, %bb52 ]
  %v453 = phi i1 [ %v436, %bb45 ], [ %v517, %bb52 ]
  %v454 = phi i1 [ %v437, %bb45 ], [ %v518, %bb52 ]
  %v545 = select i1 true, i64 0, i64 0
  br label %bb58
bb44:
  %v455 = select i1 true, i64 1, i64 1
  %v456 = select i1 true, i64 0, i64 0
  %v457 = icmp ne i64 %v113, %v456
  switch i1 %v457, label %invalid.tag.b44 [
    i1 1, label %bb47
    i1 0, label %bb48
  ]
invalid.tag.b44:
  call void @abort()
  unreachable
bb45:
  br label %bb43
bb46:
  %v458 = phi i64 [ %v113, %bb47 ], [ %v113, %bb48 ]
  %v459 = phi i64 [ %v114, %bb47 ], [ %v114, %bb48 ]
  %v460 = phi i64 [ %v115, %bb47 ], [ %v115, %bb48 ]
  %v461 = phi i64 [ %v116, %bb47 ], [ %v116, %bb48 ]
  %v462 = phi i64 [ %v117, %bb47 ], [ %v117, %bb48 ]
  %v463 = phi i64 [ %v118, %bb47 ], [ %v118, %bb48 ]
  %v464 = phi i64 [ %v119, %bb47 ], [ %v119, %bb48 ]
  %v465 = phi i1 [ %v120, %bb47 ], [ %v120, %bb48 ]
  %v466 = phi ptr [ %v121, %bb47 ], [ %v121, %bb48 ]
  %v467 = phi ptr [ %v122, %bb47 ], [ %v122, %bb48 ]
  %v468 = phi ptr [ %v123, %bb47 ], [ %v123, %bb48 ]
  %v469 = phi i64 [ %v126, %bb47 ], [ %v126, %bb48 ]
  %v470 = phi i1 [ %v431, %bb47 ], [ %v431, %bb48 ]
  %v471 = phi i1 [ %v433, %bb47 ], [ %v433, %bb48 ]
  %v472 = phi i1 [ %v435, %bb47 ], [ %v435, %bb48 ]
  %v473 = phi i1 [ %v436, %bb47 ], [ %v436, %bb48 ]
  %v474 = phi i1 [ %v437, %bb47 ], [ %v437, %bb48 ]
  %v475 = phi i64 [ %v477, %bb47 ], [ %v455, %bb48 ]
  %v478 = select i1 true, i64 10, i64 10
  %v479 = icmp eq i64 %v462, %v478
  switch i1 %v479, label %invalid.tag.b46 [
    i1 1, label %bb50
    i1 0, label %bb51
  ]
invalid.tag.b46:
  call void @abort()
  unreachable
bb47:
  %v476 = select i1 true, i64 2, i64 2
  %v477 = mul nuw i64 %v113, %v476
  br label %bb46
bb48:
  br label %bb46
bb49:
  %v480 = phi i64 [ %v458, %bb50 ], [ %v458, %bb51 ]
  %v481 = phi i64 [ %v459, %bb50 ], [ %v459, %bb51 ]
  %v482 = phi i64 [ %v460, %bb50 ], [ %v460, %bb51 ]
  %v483 = phi i64 [ %v461, %bb50 ], [ %v461, %bb51 ]
  %v484 = phi i64 [ %v462, %bb50 ], [ %v462, %bb51 ]
  %v485 = phi i64 [ %v463, %bb50 ], [ %v463, %bb51 ]
  %v486 = phi i64 [ %v464, %bb50 ], [ %v464, %bb51 ]
  %v487 = phi i1 [ %v465, %bb50 ], [ %v465, %bb51 ]
  %v488 = phi ptr [ %v466, %bb50 ], [ %v466, %bb51 ]
  %v489 = phi ptr [ %v467, %bb50 ], [ %v467, %bb51 ]
  %v490 = phi ptr [ %v468, %bb50 ], [ %v468, %bb51 ]
  %v491 = phi i64 [ %v469, %bb50 ], [ %v469, %bb51 ]
  %v492 = phi i1 [ %v470, %bb50 ], [ %v470, %bb51 ]
  %v493 = phi i1 [ %v471, %bb50 ], [ %v471, %bb51 ]
  %v494 = phi i1 [ %v472, %bb50 ], [ %v472, %bb51 ]
  %v495 = phi i1 [ %v473, %bb50 ], [ %v473, %bb51 ]
  %v496 = phi i1 [ %v474, %bb50 ], [ %v474, %bb51 ]
  %v497 = phi i64 [ %v475, %bb50 ], [ %v475, %bb51 ]
  switch i1 %v495, label %invalid.tag.b49 [
    i1 1, label %bb53
    i1 0, label %bb54
  ]
invalid.tag.b49:
  call void @abort()
  unreachable
bb50:
  %v498 = select i1 true, i64 1, i64 1
  %v499 = call i8 @wf_map_cost_ordered(ptr %v468, i64 %v498)
  br label %bb49
bb51:
  %v500 = call %wf.t.7d7f918f7b4962fd @wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65(ptr %v467, i64 %v475, ptr %v466)
  store %wf.t.7d7f918f7b4962fd %v500, ptr %wf.slot.14
  %v501 = call i8 @wf_map_cost_rebuild_result(ptr %wf.slot.14, ptr %v468)
  br label %bb49
bb52:
  %v502 = phi i64 [ %v480, %bb54 ], [ %v522, %bb55 ]
  %v503 = phi i64 [ %v481, %bb54 ], [ %v523, %bb55 ]
  %v504 = phi i64 [ %v482, %bb54 ], [ %v524, %bb55 ]
  %v505 = phi i64 [ %v483, %bb54 ], [ %v525, %bb55 ]
  %v506 = phi i64 [ %v484, %bb54 ], [ %v526, %bb55 ]
  %v507 = phi i64 [ %v485, %bb54 ], [ %v527, %bb55 ]
  %v508 = phi i64 [ %v486, %bb54 ], [ %v528, %bb55 ]
  %v509 = phi i1 [ %v487, %bb54 ], [ %v529, %bb55 ]
  %v510 = phi ptr [ %v488, %bb54 ], [ %v530, %bb55 ]
  %v511 = phi ptr [ %v489, %bb54 ], [ %v531, %bb55 ]
  %v512 = phi ptr [ %v490, %bb54 ], [ %v532, %bb55 ]
  %v513 = phi i64 [ %v491, %bb54 ], [ %v533, %bb55 ]
  %v514 = phi i1 [ %v492, %bb54 ], [ %v534, %bb55 ]
  %v515 = phi i1 [ %v493, %bb54 ], [ %v535, %bb55 ]
  %v516 = phi i1 [ %v494, %bb54 ], [ %v536, %bb55 ]
  %v517 = phi i1 [ %v495, %bb54 ], [ %v537, %bb55 ]
  %v518 = phi i1 [ %v496, %bb54 ], [ %v538, %bb55 ]
  %v519 = phi i64 [ %v497, %bb54 ], [ %v539, %bb55 ]
  br label %bb43
bb53:
  %v520 = call i64 @wf_hash_map.hash_map_capacity$instance$0e108827ecbbe374(ptr %v489)
  %v521 = icmp uge i64 %v520, %v497
  switch i1 %v521, label %invalid.tag.b53 [
    i1 1, label %bb56
    i1 0, label %bb57
  ]
invalid.tag.b53:
  call void @abort()
  unreachable
bb54:
  br label %bb52
bb55:
  %v522 = phi i64 [ %v480, %bb56 ], [ %v480, %bb57 ]
  %v523 = phi i64 [ %v481, %bb56 ], [ %v481, %bb57 ]
  %v524 = phi i64 [ %v482, %bb56 ], [ %v482, %bb57 ]
  %v525 = phi i64 [ %v483, %bb56 ], [ %v483, %bb57 ]
  %v526 = phi i64 [ %v484, %bb56 ], [ %v484, %bb57 ]
  %v527 = phi i64 [ %v485, %bb56 ], [ %v485, %bb57 ]
  %v528 = phi i64 [ %v486, %bb56 ], [ %v486, %bb57 ]
  %v529 = phi i1 [ %v487, %bb56 ], [ %v487, %bb57 ]
  %v530 = phi ptr [ %v488, %bb56 ], [ %v488, %bb57 ]
  %v531 = phi ptr [ %v489, %bb56 ], [ %v489, %bb57 ]
  %v532 = phi ptr [ %v490, %bb56 ], [ %v490, %bb57 ]
  %v533 = phi i64 [ %v491, %bb56 ], [ %v491, %bb57 ]
  %v534 = phi i1 [ %v492, %bb56 ], [ %v492, %bb57 ]
  %v535 = phi i1 [ %v493, %bb56 ], [ %v493, %bb57 ]
  %v536 = phi i1 [ %v494, %bb56 ], [ %v494, %bb57 ]
  %v537 = phi i1 [ %v495, %bb56 ], [ %v495, %bb57 ]
  %v538 = phi i1 [ %v496, %bb56 ], [ %v496, %bb57 ]
  %v539 = phi i64 [ %v497, %bb56 ], [ %v497, %bb57 ]
  %v540 = phi i64 [ %v520, %bb56 ], [ %v520, %bb57 ]
  br label %bb52
bb56:
  %v541 = select i1 true, i64 1, i64 1
  %v542 = call i8 @wf_map_cost_ordered(ptr %v490, i64 %v541)
  br label %bb55
bb57:
  %v543 = select i1 true, i64 0, i64 0
  %v544 = call i8 @wf_map_cost_ordered(ptr %v490, i64 %v543)
  br label %bb55
bb58:
  %v546 = phi i64 [ %v438, %bb43 ], [ %v925, %bb92 ]
  %v547 = phi i64 [ %v439, %bb43 ], [ %v926, %bb92 ]
  %v548 = phi i64 [ %v440, %bb43 ], [ %v927, %bb92 ]
  %v549 = phi i64 [ %v441, %bb43 ], [ %v928, %bb92 ]
  %v550 = phi i64 [ %v442, %bb43 ], [ %v929, %bb92 ]
  %v551 = phi i64 [ %v443, %bb43 ], [ %v930, %bb92 ]
  %v552 = phi i64 [ %v444, %bb43 ], [ %v931, %bb92 ]
  %v553 = phi i1 [ %v445, %bb43 ], [ %v932, %bb92 ]
  %v554 = phi ptr [ %v446, %bb43 ], [ %v933, %bb92 ]
  %v555 = phi ptr [ %v447, %bb43 ], [ %v934, %bb92 ]
  %v556 = phi ptr [ %v448, %bb43 ], [ %v935, %bb92 ]
  %v557 = phi i64 [ %v449, %bb43 ], [ %v936, %bb92 ]
  %v558 = phi i1 [ %v450, %bb43 ], [ %v937, %bb92 ]
  %v559 = phi i1 [ %v451, %bb43 ], [ %v938, %bb92 ]
  %v560 = phi i1 [ %v452, %bb43 ], [ %v939, %bb92 ]
  %v561 = phi i1 [ %v453, %bb43 ], [ %v940, %bb92 ]
  %v562 = phi i1 [ %v454, %bb43 ], [ %v941, %bb92 ]
  %v563 = phi i64 [ %v545, %bb43 ], [ %v942, %bb92 ]
  %v564 = phi i64 [ %v439, %bb43 ], [ %v943, %bb92 ]
  %v565 = phi i64 [ %v545, %bb43 ], [ %v946, %bb92 ]
  %v583 = icmp ult i64 %v565, %v564
  switch i1 %v583, label %invalid.tag.b58 [
    i1 1, label %bb59
    i1 0, label %bb60
  ]
invalid.tag.b58:
  call void @abort()
  unreachable
bb59:
  %v584 = select i1 true, i64 1, i64 1
  %v585 = icmp eq i64 %v550, %v584
  switch i1 %v585, label %invalid.tag.b59 [
    i1 1, label %bb63
    i1 0, label %bb64
  ]
invalid.tag.b59:
  call void @abort()
  unreachable
bb60:
  br label %bb61
bb61:
  %v566 = phi i64 [ %v546, %bb60 ]
  %v567 = phi i64 [ %v547, %bb60 ]
  %v568 = phi i64 [ %v548, %bb60 ]
  %v569 = phi i64 [ %v549, %bb60 ]
  %v570 = phi i64 [ %v550, %bb60 ]
  %v571 = phi i64 [ %v551, %bb60 ]
  %v572 = phi i64 [ %v552, %bb60 ]
  %v573 = phi i1 [ %v553, %bb60 ]
  %v574 = phi ptr [ %v554, %bb60 ]
  %v575 = phi ptr [ %v555, %bb60 ]
  %v576 = phi ptr [ %v556, %bb60 ]
  %v577 = phi i64 [ %v557, %bb60 ]
  %v578 = phi i1 [ %v558, %bb60 ]
  %v579 = phi i1 [ %v559, %bb60 ]
  %v580 = phi i1 [ %v560, %bb60 ]
  %v581 = phi i1 [ %v561, %bb60 ]
  %v582 = phi i1 [ %v562, %bb60 ]
  br label %bb16
bb62:
  %v586 = phi i64 [ %v546, %bb63 ], [ %v546, %bb64 ]
  %v587 = phi i64 [ %v547, %bb63 ], [ %v547, %bb64 ]
  %v588 = phi i64 [ %v548, %bb63 ], [ %v548, %bb64 ]
  %v589 = phi i64 [ %v549, %bb63 ], [ %v549, %bb64 ]
  %v590 = phi i64 [ %v550, %bb63 ], [ %v550, %bb64 ]
  %v591 = phi i64 [ %v551, %bb63 ], [ %v551, %bb64 ]
  %v592 = phi i64 [ %v552, %bb63 ], [ %v552, %bb64 ]
  %v593 = phi i1 [ %v553, %bb63 ], [ %v553, %bb64 ]
  %v594 = phi ptr [ %v554, %bb63 ], [ %v554, %bb64 ]
  %v595 = phi ptr [ %v555, %bb63 ], [ %v555, %bb64 ]
  %v596 = phi ptr [ %v556, %bb63 ], [ %v556, %bb64 ]
  %v597 = phi i64 [ %v557, %bb63 ], [ %v557, %bb64 ]
  %v598 = phi i1 [ %v558, %bb63 ], [ %v558, %bb64 ]
  %v599 = phi i1 [ %v559, %bb63 ], [ %v559, %bb64 ]
  %v600 = phi i1 [ %v560, %bb63 ], [ %v560, %bb64 ]
  %v601 = phi i1 [ %v561, %bb63 ], [ %v561, %bb64 ]
  %v602 = phi i1 [ %v562, %bb63 ], [ %v562, %bb64 ]
  %v603 = phi i64 [ %v565, %bb63 ], [ %v565, %bb64 ]
  %v604 = phi i64 [ %v605, %bb63 ], [ %v565, %bb64 ]
  %v606 = call i64 @wf_map_cost_key(i64 %v604)
  store i64 %v606, ptr %v607
  %v608 = select i1 true, i64 0, i64 0
  %v609 = icmp eq i64 %v590, %v608
  %v610 = select i1 true, i64 1, i64 1
  %v611 = icmp eq i64 %v590, %v610
  %v612 = or i1 %v609, %v611
  %v613 = or i1 %v612, %v602
  switch i1 %v613, label %invalid.tag.b62 [
    i1 1, label %bb66
    i1 0, label %bb67
  ]
invalid.tag.b62:
  call void @abort()
  unreachable
bb63:
  %v605 = add i64 %v547, %v565
  br label %bb62
bb64:
  br label %bb62
bb65:
  %v614 = phi i64 [ %v586, %bb66 ], [ %v642, %bb68 ]
  %v615 = phi i64 [ %v587, %bb66 ], [ %v643, %bb68 ]
  %v616 = phi i64 [ %v588, %bb66 ], [ %v644, %bb68 ]
  %v617 = phi i64 [ %v589, %bb66 ], [ %v645, %bb68 ]
  %v618 = phi i64 [ %v590, %bb66 ], [ %v646, %bb68 ]
  %v619 = phi i64 [ %v591, %bb66 ], [ %v647, %bb68 ]
  %v620 = phi i64 [ %v592, %bb66 ], [ %v648, %bb68 ]
  %v621 = phi i1 [ %v593, %bb66 ], [ %v649, %bb68 ]
  %v622 = phi ptr [ %v594, %bb66 ], [ %v650, %bb68 ]
  %v623 = phi ptr [ %v595, %bb66 ], [ %v651, %bb68 ]
  %v624 = phi ptr [ %v596, %bb66 ], [ %v652, %bb68 ]
  %v625 = phi i64 [ %v597, %bb66 ], [ %v653, %bb68 ]
  %v626 = phi i1 [ %v598, %bb66 ], [ %v654, %bb68 ]
  %v627 = phi i1 [ %v599, %bb66 ], [ %v655, %bb68 ]
  %v628 = phi i1 [ %v600, %bb66 ], [ %v656, %bb68 ]
  %v629 = phi i1 [ %v601, %bb66 ], [ %v657, %bb68 ]
  %v630 = phi i1 [ %v602, %bb66 ], [ %v658, %bb68 ]
  %v631 = phi i64 [ %v603, %bb66 ], [ %v659, %bb68 ]
  %v632 = phi i64 [ %v604, %bb66 ], [ %v660, %bb68 ]
  %v633 = phi ptr [ %v607, %bb66 ], [ %v661, %bb68 ]
  %v634 = phi i1 [ %v609, %bb66 ], [ %v662, %bb68 ]
  %v635 = phi i1 [ %v611, %bb66 ], [ %v663, %bb68 ]
  %v636 = phi i1 [ %v612, %bb66 ], [ %v664, %bb68 ]
  %v637 = phi i1 [ %v613, %bb66 ], [ %v665, %bb68 ]
  br label %bb92
bb66:
  %v638 = call %wf.t.b7e1ed626c09888a @wf_hash_map.hash_map_lookup$instance$000400fb603e42fe(ptr %v595, ptr %v607, ptr %v594, ptr %v596)
  store %wf.t.b7e1ed626c09888a %v638, ptr %wf.slot.15
  %v639 = call i8 @wf_map_cost_lookup_result(ptr %wf.slot.15, ptr %v596)
  br label %bb65
bb67:
  %v640 = select i1 true, i64 2, i64 2
  %v641 = icmp eq i64 %v590, %v640
  switch i1 %v641, label %invalid.tag.b67 [
    i1 1, label %bb69
    i1 0, label %bb70
  ]
invalid.tag.b67:
  call void @abort()
  unreachable
bb68:
  %v642 = phi i64 [ %v674, %bb71 ], [ %v750, %bb77 ]
  %v643 = phi i64 [ %v675, %bb71 ], [ %v751, %bb77 ]
  %v644 = phi i64 [ %v676, %bb71 ], [ %v752, %bb77 ]
  %v645 = phi i64 [ %v677, %bb71 ], [ %v753, %bb77 ]
  %v646 = phi i64 [ %v678, %bb71 ], [ %v754, %bb77 ]
  %v647 = phi i64 [ %v679, %bb71 ], [ %v755, %bb77 ]
  %v648 = phi i64 [ %v680, %bb71 ], [ %v756, %bb77 ]
  %v649 = phi i1 [ %v681, %bb71 ], [ %v757, %bb77 ]
  %v650 = phi ptr [ %v682, %bb71 ], [ %v758, %bb77 ]
  %v651 = phi ptr [ %v683, %bb71 ], [ %v759, %bb77 ]
  %v652 = phi ptr [ %v684, %bb71 ], [ %v760, %bb77 ]
  %v653 = phi i64 [ %v685, %bb71 ], [ %v761, %bb77 ]
  %v654 = phi i1 [ %v686, %bb71 ], [ %v762, %bb77 ]
  %v655 = phi i1 [ %v687, %bb71 ], [ %v763, %bb77 ]
  %v656 = phi i1 [ %v688, %bb71 ], [ %v764, %bb77 ]
  %v657 = phi i1 [ %v689, %bb71 ], [ %v765, %bb77 ]
  %v658 = phi i1 [ %v690, %bb71 ], [ %v766, %bb77 ]
  %v659 = phi i64 [ %v691, %bb71 ], [ %v767, %bb77 ]
  %v660 = phi i64 [ %v692, %bb71 ], [ %v768, %bb77 ]
  %v661 = phi ptr [ %v693, %bb71 ], [ %v769, %bb77 ]
  %v662 = phi i1 [ %v694, %bb71 ], [ %v770, %bb77 ]
  %v663 = phi i1 [ %v695, %bb71 ], [ %v771, %bb77 ]
  %v664 = phi i1 [ %v696, %bb71 ], [ %v772, %bb77 ]
  %v665 = phi i1 [ %v697, %bb71 ], [ %v773, %bb77 ]
  br label %bb65
bb69:
  %v666 = select i1 true, i64 1, i64 1
  %v667 = add i64 %v597, %v666
  %v668 = mul i64 %v667, %v587
  %v669 = add i64 %v589, %v668
  %v670 = add i64 %v669, %v603
  call void @wf_map_cost_record_make(ptr %wf.slot.16, i64 %v670)
  %v672 = load i64, ptr %v607
  call void @wf_hash_map.hash_map_put$instance$28da32efc51c2b65(ptr %wf.slot.17, ptr %v595, i64 %v672, ptr %wf.slot.16, ptr %v594)
  %t23 = load %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.17
  %t24 = extractvalue %wf.t.9d321e1eb2ec1c03 %t23, 0
  switch i32 %t24, label %invalid.tag.b69 [
    i32 0, label %bb72
    i32 1, label %bb73
  ]
invalid.tag.b69:
  call void @abort()
  unreachable
bb70:
  %v748 = select i1 true, i64 3, i64 3
  %v749 = icmp eq i64 %v590, %v748
  switch i1 %v749, label %invalid.tag.b70 [
    i1 1, label %bb78
    i1 0, label %bb79
  ]
invalid.tag.b70:
  call void @abort()
  unreachable
bb71:
  %v674 = phi i64 [ %v586, %bb72 ], [ %v708, %bb74 ]
  %v675 = phi i64 [ %v587, %bb72 ], [ %v709, %bb74 ]
  %v676 = phi i64 [ %v588, %bb72 ], [ %v710, %bb74 ]
  %v677 = phi i64 [ %v589, %bb72 ], [ %v711, %bb74 ]
  %v678 = phi i64 [ %v590, %bb72 ], [ %v712, %bb74 ]
  %v679 = phi i64 [ %v591, %bb72 ], [ %v713, %bb74 ]
  %v680 = phi i64 [ %v592, %bb72 ], [ %v714, %bb74 ]
  %v681 = phi i1 [ %v593, %bb72 ], [ %v715, %bb74 ]
  %v682 = phi ptr [ %v594, %bb72 ], [ %v716, %bb74 ]
  %v683 = phi ptr [ %v595, %bb72 ], [ %v717, %bb74 ]
  %v684 = phi ptr [ %v596, %bb72 ], [ %v718, %bb74 ]
  %v685 = phi i64 [ %v597, %bb72 ], [ %v719, %bb74 ]
  %v686 = phi i1 [ %v598, %bb72 ], [ %v720, %bb74 ]
  %v687 = phi i1 [ %v599, %bb72 ], [ %v721, %bb74 ]
  %v688 = phi i1 [ %v600, %bb72 ], [ %v722, %bb74 ]
  %v689 = phi i1 [ %v601, %bb72 ], [ %v723, %bb74 ]
  %v690 = phi i1 [ %v602, %bb72 ], [ %v724, %bb74 ]
  %v691 = phi i64 [ %v603, %bb72 ], [ %v725, %bb74 ]
  %v692 = phi i64 [ %v604, %bb72 ], [ %v726, %bb74 ]
  %v693 = phi ptr [ %v607, %bb72 ], [ %v727, %bb74 ]
  %v694 = phi i1 [ %v609, %bb72 ], [ %v728, %bb74 ]
  %v695 = phi i1 [ %v611, %bb72 ], [ %v729, %bb74 ]
  %v696 = phi i1 [ %v612, %bb72 ], [ %v730, %bb74 ]
  %v697 = phi i1 [ %v613, %bb72 ], [ %v731, %bb74 ]
  %v698 = phi i64 [ %v667, %bb72 ], [ %v732, %bb74 ]
  %v699 = phi i64 [ %v668, %bb72 ], [ %v733, %bb74 ]
  %v700 = phi i64 [ %v669, %bb72 ], [ %v734, %bb74 ]
  %v701 = phi i64 [ %v670, %bb72 ], [ %v735, %bb74 ]
  br label %bb68
bb72:
  %v704 = select i1 true, i64 0, i64 0
  %v705 = call i8 @wf_map_cost_ordered(ptr %v596, i64 %v704)
  br label %bb71
bb73:
  %t25 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.17, i32 0, i32 1
  %v706 = load i1, ptr %t25
  %t26 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.17, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.18, ptr %t26, i64 ptrtoint (ptr getelementptr (%wf.t.20dda3774c7510ec, ptr null, i32 1) to i64), i1 false)
  switch i1 %v706, label %invalid.tag.b73 [
    i1 0, label %bb75
    i1 1, label %bb76
  ]
invalid.tag.b73:
  call void @abort()
  unreachable
bb74:
  %v708 = phi i64 [ %v586, %bb75 ], [ %v586, %bb76 ]
  %v709 = phi i64 [ %v587, %bb75 ], [ %v587, %bb76 ]
  %v710 = phi i64 [ %v588, %bb75 ], [ %v588, %bb76 ]
  %v711 = phi i64 [ %v589, %bb75 ], [ %v589, %bb76 ]
  %v712 = phi i64 [ %v590, %bb75 ], [ %v590, %bb76 ]
  %v713 = phi i64 [ %v591, %bb75 ], [ %v591, %bb76 ]
  %v714 = phi i64 [ %v592, %bb75 ], [ %v592, %bb76 ]
  %v715 = phi i1 [ %v593, %bb75 ], [ %v593, %bb76 ]
  %v716 = phi ptr [ %v594, %bb75 ], [ %v594, %bb76 ]
  %v717 = phi ptr [ %v595, %bb75 ], [ %v595, %bb76 ]
  %v718 = phi ptr [ %v596, %bb75 ], [ %v596, %bb76 ]
  %v719 = phi i64 [ %v597, %bb75 ], [ %v597, %bb76 ]
  %v720 = phi i1 [ %v598, %bb75 ], [ %v598, %bb76 ]
  %v721 = phi i1 [ %v599, %bb75 ], [ %v599, %bb76 ]
  %v722 = phi i1 [ %v600, %bb75 ], [ %v600, %bb76 ]
  %v723 = phi i1 [ %v601, %bb75 ], [ %v601, %bb76 ]
  %v724 = phi i1 [ %v602, %bb75 ], [ %v602, %bb76 ]
  %v725 = phi i64 [ %v603, %bb75 ], [ %v603, %bb76 ]
  %v726 = phi i64 [ %v604, %bb75 ], [ %v604, %bb76 ]
  %v727 = phi ptr [ %v607, %bb75 ], [ %v607, %bb76 ]
  %v728 = phi i1 [ %v609, %bb75 ], [ %v609, %bb76 ]
  %v729 = phi i1 [ %v611, %bb75 ], [ %v611, %bb76 ]
  %v730 = phi i1 [ %v612, %bb75 ], [ %v612, %bb76 ]
  %v731 = phi i1 [ %v613, %bb75 ], [ %v613, %bb76 ]
  %v732 = phi i64 [ %v667, %bb75 ], [ %v667, %bb76 ]
  %v733 = phi i64 [ %v668, %bb75 ], [ %v668, %bb76 ]
  %v734 = phi i64 [ %v669, %bb75 ], [ %v669, %bb76 ]
  %v735 = phi i64 [ %v670, %bb75 ], [ %v670, %bb76 ]
  %v738 = phi i1 [ %v706, %bb75 ], [ %v706, %bb76 ]
  %t27 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.18, i32 0, i32 0
  %v744 = load i64, ptr %t27
  ; ownership-consuming projection
  %t28 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.18, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.19, ptr %t28, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %v746 = call i64 @wf_map_cost_record_content(i64 %v744, ptr %wf.slot.19)
  %v747 = call i8 @wf_map_cost_ordered(ptr %v718, i64 %v746)
  br label %bb71
bb75:
  %v740 = select i1 true, i64 1, i64 1
  %v741 = call i8 @wf_map_cost_ordered(ptr %v596, i64 %v740)
  br label %bb74
bb76:
  %v742 = select i1 true, i64 2, i64 2
  %v743 = call i8 @wf_map_cost_ordered(ptr %v596, i64 %v742)
  br label %bb74
bb77:
  %v750 = phi i64 [ %v819, %bb83 ], [ %v899, %bb89 ]
  %v751 = phi i64 [ %v820, %bb83 ], [ %v900, %bb89 ]
  %v752 = phi i64 [ %v821, %bb83 ], [ %v901, %bb89 ]
  %v753 = phi i64 [ %v822, %bb83 ], [ %v902, %bb89 ]
  %v754 = phi i64 [ %v823, %bb83 ], [ %v903, %bb89 ]
  %v755 = phi i64 [ %v824, %bb83 ], [ %v904, %bb89 ]
  %v756 = phi i64 [ %v825, %bb83 ], [ %v905, %bb89 ]
  %v757 = phi i1 [ %v826, %bb83 ], [ %v906, %bb89 ]
  %v758 = phi ptr [ %v827, %bb83 ], [ %v907, %bb89 ]
  %v759 = phi ptr [ %v828, %bb83 ], [ %v908, %bb89 ]
  %v760 = phi ptr [ %v829, %bb83 ], [ %v909, %bb89 ]
  %v761 = phi i64 [ %v830, %bb83 ], [ %v910, %bb89 ]
  %v762 = phi i1 [ %v831, %bb83 ], [ %v911, %bb89 ]
  %v763 = phi i1 [ %v832, %bb83 ], [ %v912, %bb89 ]
  %v764 = phi i1 [ %v833, %bb83 ], [ %v913, %bb89 ]
  %v765 = phi i1 [ %v834, %bb83 ], [ %v914, %bb89 ]
  %v766 = phi i1 [ %v835, %bb83 ], [ %v915, %bb89 ]
  %v767 = phi i64 [ %v836, %bb83 ], [ %v916, %bb89 ]
  %v768 = phi i64 [ %v837, %bb83 ], [ %v917, %bb89 ]
  %v769 = phi ptr [ %v838, %bb83 ], [ %v918, %bb89 ]
  %v770 = phi i1 [ %v839, %bb83 ], [ %v919, %bb89 ]
  %v771 = phi i1 [ %v840, %bb83 ], [ %v920, %bb89 ]
  %v772 = phi i1 [ %v841, %bb83 ], [ %v921, %bb89 ]
  %v773 = phi i1 [ %v842, %bb83 ], [ %v922, %bb89 ]
  br label %bb68
bb78:
  call void @wf_hash_map.hash_map_remove$instance$28da32efc51c2b65(ptr %wf.slot.20, ptr %v595, ptr %v607, ptr %v594)
  %t29 = load %wf.t.e020a813ecac56e1, ptr %wf.slot.20
  %t30 = extractvalue %wf.t.e020a813ecac56e1 %t29, 0
  switch i32 %t30, label %invalid.tag.b78 [
    i32 1, label %bb81
    i32 0, label %bb82
  ]
invalid.tag.b78:
  call void @abort()
  unreachable
bb79:
  %v897 = select i1 true, i64 7, i64 7
  %v898 = icmp eq i64 %v590, %v897
  switch i1 %v898, label %invalid.tag.b79 [
    i1 1, label %bb90
    i1 0, label %bb91
  ]
invalid.tag.b79:
  call void @abort()
  unreachable
bb80:
  %v775 = phi i64 [ %v586, %bb81 ], [ %v586, %bb82 ]
  %v776 = phi i64 [ %v587, %bb81 ], [ %v587, %bb82 ]
  %v777 = phi i64 [ %v588, %bb81 ], [ %v588, %bb82 ]
  %v778 = phi i64 [ %v589, %bb81 ], [ %v589, %bb82 ]
  %v779 = phi i64 [ %v590, %bb81 ], [ %v590, %bb82 ]
  %v780 = phi i64 [ %v591, %bb81 ], [ %v591, %bb82 ]
  %v781 = phi i64 [ %v592, %bb81 ], [ %v592, %bb82 ]
  %v782 = phi i1 [ %v593, %bb81 ], [ %v593, %bb82 ]
  %v783 = phi ptr [ %v594, %bb81 ], [ %v594, %bb82 ]
  %v784 = phi ptr [ %v595, %bb81 ], [ %v595, %bb82 ]
  %v785 = phi ptr [ %v596, %bb81 ], [ %v596, %bb82 ]
  %v786 = phi i64 [ %v597, %bb81 ], [ %v597, %bb82 ]
  %v787 = phi i1 [ %v598, %bb81 ], [ %v598, %bb82 ]
  %v788 = phi i1 [ %v599, %bb81 ], [ %v599, %bb82 ]
  %v789 = phi i1 [ %v600, %bb81 ], [ %v600, %bb82 ]
  %v790 = phi i1 [ %v601, %bb81 ], [ %v601, %bb82 ]
  %v791 = phi i1 [ %v602, %bb81 ], [ %v602, %bb82 ]
  %v792 = phi i64 [ %v603, %bb81 ], [ %v603, %bb82 ]
  %v793 = phi i64 [ %v604, %bb81 ], [ %v604, %bb82 ]
  %v794 = phi ptr [ %v607, %bb81 ], [ %v607, %bb82 ]
  %v795 = phi i1 [ %v609, %bb81 ], [ %v609, %bb82 ]
  %v796 = phi i1 [ %v611, %bb81 ], [ %v611, %bb82 ]
  %v797 = phi i1 [ %v612, %bb81 ], [ %v612, %bb82 ]
  %v798 = phi i1 [ %v613, %bb81 ], [ %v613, %bb82 ]
  %v809 = call %wf.t.b7e1ed626c09888a @wf_hash_map.hash_map_lookup$instance$000400fb603e42fe(ptr %v784, ptr %v794, ptr %v783, ptr %v785)
  store %wf.t.b7e1ed626c09888a %v809, ptr %wf.slot.23
  %v810 = call i8 @wf_map_cost_lookup_result(ptr %wf.slot.23, ptr %v785)
  %v811 = select i1 true, i64 1, i64 1
  %v812 = add i64 %v786, %v811
  %v813 = mul i64 %v812, %v776
  %v814 = add i64 %v778, %v813
  %v815 = add i64 %v814, %v792
  call void @wf_map_cost_record_make(ptr %wf.slot.24, i64 %v815)
  %v817 = load i64, ptr %v794
  call void @wf_hash_map.hash_map_put$instance$28da32efc51c2b65(ptr %wf.slot.25, ptr %v784, i64 %v817, ptr %wf.slot.24, ptr %v783)
  %t31 = load %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.25
  %t32 = extractvalue %wf.t.9d321e1eb2ec1c03 %t31, 0
  switch i32 %t32, label %invalid.tag.b80 [
    i32 0, label %bb84
    i32 1, label %bb85
  ]
invalid.tag.b80:
  call void @abort()
  unreachable
bb81:
  %t33 = getelementptr inbounds %wf.t.e020a813ecac56e1, ptr %wf.slot.20, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.21, ptr %t33, i64 ptrtoint (ptr getelementptr (%wf.t.20dda3774c7510ec, ptr null, i32 1) to i64), i1 false)
  %v801 = select i1 true, i64 1, i64 1
  %v802 = call i8 @wf_map_cost_ordered(ptr %v596, i64 %v801)
  %t34 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.21, i32 0, i32 0
  %v803 = load i64, ptr %t34
  ; ownership-consuming projection
  %t35 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.21, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.22, ptr %t35, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %v805 = call i64 @wf_map_cost_record_content(i64 %v803, ptr %wf.slot.22)
  %v806 = call i8 @wf_map_cost_ordered(ptr %v596, i64 %v805)
  br label %bb80
bb82:
  %v807 = select i1 true, i64 0, i64 0
  %v808 = call i8 @wf_map_cost_ordered(ptr %v596, i64 %v807)
  br label %bb80
bb83:
  %v819 = phi i64 [ %v775, %bb84 ], [ %v855, %bb86 ]
  %v820 = phi i64 [ %v776, %bb84 ], [ %v856, %bb86 ]
  %v821 = phi i64 [ %v777, %bb84 ], [ %v857, %bb86 ]
  %v822 = phi i64 [ %v778, %bb84 ], [ %v858, %bb86 ]
  %v823 = phi i64 [ %v779, %bb84 ], [ %v859, %bb86 ]
  %v824 = phi i64 [ %v780, %bb84 ], [ %v860, %bb86 ]
  %v825 = phi i64 [ %v781, %bb84 ], [ %v861, %bb86 ]
  %v826 = phi i1 [ %v782, %bb84 ], [ %v862, %bb86 ]
  %v827 = phi ptr [ %v783, %bb84 ], [ %v863, %bb86 ]
  %v828 = phi ptr [ %v784, %bb84 ], [ %v864, %bb86 ]
  %v829 = phi ptr [ %v785, %bb84 ], [ %v865, %bb86 ]
  %v830 = phi i64 [ %v786, %bb84 ], [ %v866, %bb86 ]
  %v831 = phi i1 [ %v787, %bb84 ], [ %v867, %bb86 ]
  %v832 = phi i1 [ %v788, %bb84 ], [ %v868, %bb86 ]
  %v833 = phi i1 [ %v789, %bb84 ], [ %v869, %bb86 ]
  %v834 = phi i1 [ %v790, %bb84 ], [ %v870, %bb86 ]
  %v835 = phi i1 [ %v791, %bb84 ], [ %v871, %bb86 ]
  %v836 = phi i64 [ %v792, %bb84 ], [ %v872, %bb86 ]
  %v837 = phi i64 [ %v793, %bb84 ], [ %v873, %bb86 ]
  %v838 = phi ptr [ %v794, %bb84 ], [ %v874, %bb86 ]
  %v839 = phi i1 [ %v795, %bb84 ], [ %v875, %bb86 ]
  %v840 = phi i1 [ %v796, %bb84 ], [ %v876, %bb86 ]
  %v841 = phi i1 [ %v797, %bb84 ], [ %v877, %bb86 ]
  %v842 = phi i1 [ %v798, %bb84 ], [ %v878, %bb86 ]
  %v845 = phi i64 [ %v812, %bb84 ], [ %v881, %bb86 ]
  %v846 = phi i64 [ %v813, %bb84 ], [ %v882, %bb86 ]
  %v847 = phi i64 [ %v814, %bb84 ], [ %v883, %bb86 ]
  %v848 = phi i64 [ %v815, %bb84 ], [ %v884, %bb86 ]
  br label %bb77
bb84:
  %v851 = select i1 true, i64 0, i64 0
  %v852 = call i8 @wf_map_cost_ordered(ptr %v785, i64 %v851)
  br label %bb83
bb85:
  %t36 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.25, i32 0, i32 1
  %v853 = load i1, ptr %t36
  %t37 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.25, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.26, ptr %t37, i64 ptrtoint (ptr getelementptr (%wf.t.20dda3774c7510ec, ptr null, i32 1) to i64), i1 false)
  switch i1 %v853, label %invalid.tag.b85 [
    i1 0, label %bb87
    i1 1, label %bb88
  ]
invalid.tag.b85:
  call void @abort()
  unreachable
bb86:
  %v855 = phi i64 [ %v775, %bb87 ], [ %v775, %bb88 ]
  %v856 = phi i64 [ %v776, %bb87 ], [ %v776, %bb88 ]
  %v857 = phi i64 [ %v777, %bb87 ], [ %v777, %bb88 ]
  %v858 = phi i64 [ %v778, %bb87 ], [ %v778, %bb88 ]
  %v859 = phi i64 [ %v779, %bb87 ], [ %v779, %bb88 ]
  %v860 = phi i64 [ %v780, %bb87 ], [ %v780, %bb88 ]
  %v861 = phi i64 [ %v781, %bb87 ], [ %v781, %bb88 ]
  %v862 = phi i1 [ %v782, %bb87 ], [ %v782, %bb88 ]
  %v863 = phi ptr [ %v783, %bb87 ], [ %v783, %bb88 ]
  %v864 = phi ptr [ %v784, %bb87 ], [ %v784, %bb88 ]
  %v865 = phi ptr [ %v785, %bb87 ], [ %v785, %bb88 ]
  %v866 = phi i64 [ %v786, %bb87 ], [ %v786, %bb88 ]
  %v867 = phi i1 [ %v787, %bb87 ], [ %v787, %bb88 ]
  %v868 = phi i1 [ %v788, %bb87 ], [ %v788, %bb88 ]
  %v869 = phi i1 [ %v789, %bb87 ], [ %v789, %bb88 ]
  %v870 = phi i1 [ %v790, %bb87 ], [ %v790, %bb88 ]
  %v871 = phi i1 [ %v791, %bb87 ], [ %v791, %bb88 ]
  %v872 = phi i64 [ %v792, %bb87 ], [ %v792, %bb88 ]
  %v873 = phi i64 [ %v793, %bb87 ], [ %v793, %bb88 ]
  %v874 = phi ptr [ %v794, %bb87 ], [ %v794, %bb88 ]
  %v875 = phi i1 [ %v795, %bb87 ], [ %v795, %bb88 ]
  %v876 = phi i1 [ %v796, %bb87 ], [ %v796, %bb88 ]
  %v877 = phi i1 [ %v797, %bb87 ], [ %v797, %bb88 ]
  %v878 = phi i1 [ %v798, %bb87 ], [ %v798, %bb88 ]
  %v881 = phi i64 [ %v812, %bb87 ], [ %v812, %bb88 ]
  %v882 = phi i64 [ %v813, %bb87 ], [ %v813, %bb88 ]
  %v883 = phi i64 [ %v814, %bb87 ], [ %v814, %bb88 ]
  %v884 = phi i64 [ %v815, %bb87 ], [ %v815, %bb88 ]
  %v887 = phi i1 [ %v853, %bb87 ], [ %v853, %bb88 ]
  %t38 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.26, i32 0, i32 0
  %v893 = load i64, ptr %t38
  ; ownership-consuming projection
  %t39 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.26, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.27, ptr %t39, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %v895 = call i64 @wf_map_cost_record_content(i64 %v893, ptr %wf.slot.27)
  %v896 = call i8 @wf_map_cost_ordered(ptr %v865, i64 %v895)
  br label %bb83
bb87:
  %v889 = select i1 true, i64 1, i64 1
  %v890 = call i8 @wf_map_cost_ordered(ptr %v785, i64 %v889)
  br label %bb86
bb88:
  %v891 = select i1 true, i64 2, i64 2
  %v892 = call i8 @wf_map_cost_ordered(ptr %v785, i64 %v891)
  br label %bb86
bb89:
  %v899 = phi i64 [ %v586, %bb90 ], [ %v586, %bb91 ]
  %v900 = phi i64 [ %v587, %bb90 ], [ %v587, %bb91 ]
  %v901 = phi i64 [ %v588, %bb90 ], [ %v588, %bb91 ]
  %v902 = phi i64 [ %v589, %bb90 ], [ %v589, %bb91 ]
  %v903 = phi i64 [ %v590, %bb90 ], [ %v590, %bb91 ]
  %v904 = phi i64 [ %v591, %bb90 ], [ %v591, %bb91 ]
  %v905 = phi i64 [ %v592, %bb90 ], [ %v592, %bb91 ]
  %v906 = phi i1 [ %v593, %bb90 ], [ %v593, %bb91 ]
  %v907 = phi ptr [ %v594, %bb90 ], [ %v594, %bb91 ]
  %v908 = phi ptr [ %v595, %bb90 ], [ %v595, %bb91 ]
  %v909 = phi ptr [ %v596, %bb90 ], [ %v596, %bb91 ]
  %v910 = phi i64 [ %v597, %bb90 ], [ %v597, %bb91 ]
  %v911 = phi i1 [ %v598, %bb90 ], [ %v598, %bb91 ]
  %v912 = phi i1 [ %v599, %bb90 ], [ %v599, %bb91 ]
  %v913 = phi i1 [ %v600, %bb90 ], [ %v600, %bb91 ]
  %v914 = phi i1 [ %v601, %bb90 ], [ %v601, %bb91 ]
  %v915 = phi i1 [ %v602, %bb90 ], [ %v602, %bb91 ]
  %v916 = phi i64 [ %v603, %bb90 ], [ %v603, %bb91 ]
  %v917 = phi i64 [ %v604, %bb90 ], [ %v604, %bb91 ]
  %v918 = phi ptr [ %v607, %bb90 ], [ %v607, %bb91 ]
  %v919 = phi i1 [ %v609, %bb90 ], [ %v609, %bb91 ]
  %v920 = phi i1 [ %v611, %bb90 ], [ %v611, %bb91 ]
  %v921 = phi i1 [ %v612, %bb90 ], [ %v612, %bb91 ]
  %v922 = phi i1 [ %v613, %bb90 ], [ %v613, %bb91 ]
  br label %bb77
bb90:
  %v923 = call %wf.t.b7e1ed626c09888a @wf_hash_map.hash_map_edit$instance$ec3fd08e444cbe49(ptr %v595, ptr %v607, ptr %v594, ptr %v596)
  store %wf.t.b7e1ed626c09888a %v923, ptr %wf.slot.28
  %v924 = call i8 @wf_map_cost_lookup_result(ptr %wf.slot.28, ptr %v596)
  br label %bb89
bb91:
  br label %bb89
bb92:
  %v925 = phi i64 [ %v614, %bb65 ]
  %v926 = phi i64 [ %v615, %bb65 ]
  %v927 = phi i64 [ %v616, %bb65 ]
  %v928 = phi i64 [ %v617, %bb65 ]
  %v929 = phi i64 [ %v618, %bb65 ]
  %v930 = phi i64 [ %v619, %bb65 ]
  %v931 = phi i64 [ %v620, %bb65 ]
  %v932 = phi i1 [ %v621, %bb65 ]
  %v933 = phi ptr [ %v622, %bb65 ]
  %v934 = phi ptr [ %v623, %bb65 ]
  %v935 = phi ptr [ %v624, %bb65 ]
  %v936 = phi i64 [ %v625, %bb65 ]
  %v937 = phi i1 [ %v626, %bb65 ]
  %v938 = phi i1 [ %v627, %bb65 ]
  %v939 = phi i1 [ %v628, %bb65 ]
  %v940 = phi i1 [ %v629, %bb65 ]
  %v941 = phi i1 [ %v630, %bb65 ]
  %v942 = phi i64 [ %v563, %bb65 ]
  %v943 = phi i64 [ %v564, %bb65 ]
  %v944 = phi i64 [ %v565, %bb65 ]
  %v945 = select i1 true, i64 1, i64 1
  %v946 = add i64 %v944, %v945
  br label %bb58
bb93:
  %v947 = phi i64 [ %v141, %bb16 ]
  %v948 = phi i64 [ %v142, %bb16 ]
  %v949 = phi i64 [ %v143, %bb16 ]
  %v950 = phi i64 [ %v144, %bb16 ]
  %v951 = phi i64 [ %v145, %bb16 ]
  %v952 = phi i64 [ %v146, %bb16 ]
  %v953 = phi i64 [ %v147, %bb16 ]
  %v954 = phi i1 [ %v148, %bb16 ]
  %v955 = phi ptr [ %v149, %bb16 ]
  %v956 = phi ptr [ %v150, %bb16 ]
  %v957 = phi ptr [ %v151, %bb16 ]
  %v958 = phi i64 [ %v124, %bb16 ]
  %v959 = phi i64 [ %v125, %bb16 ]
  %v960 = phi i64 [ %v126, %bb16 ]
  %v961 = select i1 true, i64 1, i64 1
  %v962 = add i64 %v960, %v961
  br label %bb12
}

define i64 @wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd(i64 %v0, i64 %v1, i64 %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.ac5891a387b8aafe, align 8
  %wf.slot.1 = alloca %wf.t.7748a5b0f0193f4a, align 8
  %wf.slot.2 = alloca %wf.t.84597570beb237fa, align 8
  %v9 = alloca %wf.t.ee6ca7dc0a065510, align 8
  %v11 = alloca %wf.t.7748a5b0f0193f4a, align 8
  %v16 = alloca %wf.t.84597570beb237fa, align 8
  %v3 = select i1 true, i64 11400714819323198485, i64 11400714819323198485
  %v4 = xor i64 %v2, %v3
  %v5 = select i1 true, i64 0, i64 0
  %v6 = select i1 true, i64 0, i64 0
  %v7 = icmp ne i64 %v5, %v6
  store %wf.t.ee6ca7dc0a065510 zeroinitializer, ptr %v9
  %t0 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v9, i32 0, i32 0
  store i64 %v4, ptr %t0
  %t1 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v9, i32 0, i32 1
  store i1 %v7, ptr %t1
  call void @wf_hash_map.hash_map_new$instance$820b2044b97e0fbd(ptr %v11, i64 %v0)
  %v12 = select i1 true, i64 0, i64 0
  %v13 = select i1 true, i64 0, i64 0
  %v14 = select i1 true, i64 0, i64 0
  store %wf.t.84597570beb237fa zeroinitializer, ptr %v16
  %t2 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v16, i32 0, i32 0
  store i64 %v2, ptr %t2
  %t3 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v16, i32 0, i32 1
  store i64 %v12, ptr %t3
  %t4 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v16, i32 0, i32 2
  store i64 %v13, ptr %t4
  %t5 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v16, i32 0, i32 3
  store i64 %v14, ptr %t5
  %v17 = select i1 true, i64 0, i64 0
  br label %bb1
bb1:
  %v18 = phi i64 [ %v0, %entry ], [ %v43, %bb5 ]
  %v19 = phi i64 [ %v1, %entry ], [ %v44, %bb5 ]
  %v20 = phi i64 [ %v2, %entry ], [ %v45, %bb5 ]
  %v21 = phi i64 [ %v4, %entry ], [ %v46, %bb5 ]
  %v22 = phi i1 [ %v7, %entry ], [ %v47, %bb5 ]
  %v23 = phi ptr [ %v9, %entry ], [ %v48, %bb5 ]
  %v24 = phi ptr [ %v11, %entry ], [ %v49, %bb5 ]
  %v25 = phi ptr [ %v16, %entry ], [ %v50, %bb5 ]
  %v26 = phi i64 [ %v17, %entry ], [ %v51, %bb5 ]
  %v27 = phi i64 [ %v1, %entry ], [ %v52, %bb5 ]
  %v28 = phi i64 [ %v17, %entry ], [ %v55, %bb5 ]
  %v37 = icmp ult i64 %v28, %v27
  switch i1 %v37, label %invalid.tag.b1 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v38 = call i64 @wf_map_cost_key(i64 %v28)
  %v39 = add i64 %v20, %v28
  %v40 = call i64 @wf_map_cost_word_make(i64 %v39)
  call void @wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad(ptr %wf.slot.0, ptr %v24, i64 %v38, i64 %v40, ptr %v23)
  %v42 = call i8 @wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd(ptr %wf.slot.0, ptr %v25)
  br label %bb5
bb3:
  br label %bb4
bb4:
  %v29 = phi i64 [ %v18, %bb3 ]
  %v30 = phi i64 [ %v19, %bb3 ]
  %v31 = phi i64 [ %v20, %bb3 ]
  %v32 = phi i64 [ %v21, %bb3 ]
  %v33 = phi i1 [ %v22, %bb3 ]
  %v34 = phi ptr [ %v23, %bb3 ]
  %v35 = phi ptr [ %v24, %bb3 ]
  %v36 = phi ptr [ %v25, %bb3 ]
  %v56 = call i64 @wf_hash_map.hash_map_capacity$instance$820b2044b97e0fbd(ptr %v35)
  %v57 = call i64 @wf_hash_map.hash_map_len$instance$820b2044b97e0fbd(ptr %v35)
  %v58 = select i1 true, i64 4294967296, i64 4294967296
  %v59 = mul i64 %v56, %v58
  %v60 = add i64 %v59, %v57
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v35, i64 ptrtoint (ptr getelementptr (%wf.t.7748a5b0f0193f4a, ptr null, i32 1) to i64), i1 false)
  %v62 = call i8 @wf_hash_map.hash_map_free$instance$001ff12ace7d7c19(ptr %wf.slot.1, ptr %v36)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %v36, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %v64 = call i64 @wf_map_cost_finish(ptr %wf.slot.2)
  %v65 = xor i64 %v64, %v60
  ret i64 %v65
bb5:
  %v43 = phi i64 [ %v18, %bb2 ]
  %v44 = phi i64 [ %v19, %bb2 ]
  %v45 = phi i64 [ %v20, %bb2 ]
  %v46 = phi i64 [ %v21, %bb2 ]
  %v47 = phi i1 [ %v22, %bb2 ]
  %v48 = phi ptr [ %v23, %bb2 ]
  %v49 = phi ptr [ %v24, %bb2 ]
  %v50 = phi ptr [ %v25, %bb2 ]
  %v51 = phi i64 [ %v26, %bb2 ]
  %v52 = phi i64 [ %v27, %bb2 ]
  %v53 = phi i64 [ %v28, %bb2 ]
  %v54 = select i1 true, i64 1, i64 1
  %v55 = add i64 %v53, %v54
  br label %bb1
}

define i64 @wf_map_cost_library_geometry$instance$4250cb78d3f44027(i64 %v0, i64 %v1, i64 %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.1 = alloca %wf.t.9d321e1eb2ec1c03, align 8
  %wf.slot.2 = alloca %wf.t.05623e8a192b9069, align 8
  %wf.slot.3 = alloca %wf.t.84597570beb237fa, align 8
  %v9 = alloca %wf.t.ee6ca7dc0a065510, align 8
  %v11 = alloca %wf.t.05623e8a192b9069, align 8
  %v16 = alloca %wf.t.84597570beb237fa, align 8
  %v3 = select i1 true, i64 11400714819323198485, i64 11400714819323198485
  %v4 = xor i64 %v2, %v3
  %v5 = select i1 true, i64 0, i64 0
  %v6 = select i1 true, i64 0, i64 0
  %v7 = icmp ne i64 %v5, %v6
  store %wf.t.ee6ca7dc0a065510 zeroinitializer, ptr %v9
  %t0 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v9, i32 0, i32 0
  store i64 %v4, ptr %t0
  %t1 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v9, i32 0, i32 1
  store i1 %v7, ptr %t1
  call void @wf_hash_map.hash_map_new$instance$0e108827ecbbe374(ptr %v11, i64 %v0)
  %v12 = select i1 true, i64 0, i64 0
  %v13 = select i1 true, i64 0, i64 0
  %v14 = select i1 true, i64 0, i64 0
  store %wf.t.84597570beb237fa zeroinitializer, ptr %v16
  %t2 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v16, i32 0, i32 0
  store i64 %v2, ptr %t2
  %t3 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v16, i32 0, i32 1
  store i64 %v12, ptr %t3
  %t4 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v16, i32 0, i32 2
  store i64 %v13, ptr %t4
  %t5 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v16, i32 0, i32 3
  store i64 %v14, ptr %t5
  %v17 = select i1 true, i64 0, i64 0
  br label %bb1
bb1:
  %v18 = phi i64 [ %v0, %entry ], [ %v43, %bb5 ]
  %v19 = phi i64 [ %v1, %entry ], [ %v44, %bb5 ]
  %v20 = phi i64 [ %v2, %entry ], [ %v45, %bb5 ]
  %v21 = phi i64 [ %v4, %entry ], [ %v46, %bb5 ]
  %v22 = phi i1 [ %v7, %entry ], [ %v47, %bb5 ]
  %v23 = phi ptr [ %v9, %entry ], [ %v48, %bb5 ]
  %v24 = phi ptr [ %v11, %entry ], [ %v49, %bb5 ]
  %v25 = phi ptr [ %v16, %entry ], [ %v50, %bb5 ]
  %v26 = phi i64 [ %v17, %entry ], [ %v51, %bb5 ]
  %v27 = phi i64 [ %v1, %entry ], [ %v52, %bb5 ]
  %v28 = phi i64 [ %v17, %entry ], [ %v55, %bb5 ]
  %v37 = icmp ult i64 %v28, %v27
  switch i1 %v37, label %invalid.tag.b1 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v38 = call i64 @wf_map_cost_key(i64 %v28)
  %v39 = add i64 %v20, %v28
  call void @wf_map_cost_record_make(ptr %wf.slot.0, i64 %v39)
  call void @wf_hash_map.hash_map_put$instance$28da32efc51c2b65(ptr %wf.slot.1, ptr %v24, i64 %v38, ptr %wf.slot.0, ptr %v23)
  %v42 = call i8 @wf_map_cost_library_policy_result$instance$4250cb78d3f44027(ptr %wf.slot.1, ptr %v25)
  br label %bb5
bb3:
  br label %bb4
bb4:
  %v29 = phi i64 [ %v18, %bb3 ]
  %v30 = phi i64 [ %v19, %bb3 ]
  %v31 = phi i64 [ %v20, %bb3 ]
  %v32 = phi i64 [ %v21, %bb3 ]
  %v33 = phi i1 [ %v22, %bb3 ]
  %v34 = phi ptr [ %v23, %bb3 ]
  %v35 = phi ptr [ %v24, %bb3 ]
  %v36 = phi ptr [ %v25, %bb3 ]
  %v56 = call i64 @wf_hash_map.hash_map_capacity$instance$0e108827ecbbe374(ptr %v35)
  %v57 = call i64 @wf_hash_map.hash_map_len$instance$0e108827ecbbe374(ptr %v35)
  %v58 = select i1 true, i64 4294967296, i64 4294967296
  %v59 = mul i64 %v56, %v58
  %v60 = add i64 %v59, %v57
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %v35, i64 ptrtoint (ptr getelementptr (%wf.t.05623e8a192b9069, ptr null, i32 1) to i64), i1 false)
  %v62 = call i8 @wf_hash_map.hash_map_free$instance$d5f8785ab7665d71(ptr %wf.slot.2, ptr %v36)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.3, ptr %v36, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %v64 = call i64 @wf_map_cost_finish(ptr %wf.slot.3)
  %v65 = xor i64 %v64, %v60
  ret i64 %v65
bb5:
  %v43 = phi i64 [ %v18, %bb2 ]
  %v44 = phi i64 [ %v19, %bb2 ]
  %v45 = phi i64 [ %v20, %bb2 ]
  %v46 = phi i64 [ %v21, %bb2 ]
  %v47 = phi i1 [ %v22, %bb2 ]
  %v48 = phi ptr [ %v23, %bb2 ]
  %v49 = phi ptr [ %v24, %bb2 ]
  %v50 = phi ptr [ %v25, %bb2 ]
  %v51 = phi i64 [ %v26, %bb2 ]
  %v52 = phi i64 [ %v27, %bb2 ]
  %v53 = phi i64 [ %v28, %bb2 ]
  %v54 = select i1 true, i64 1, i64 1
  %v55 = add i64 %v53, %v54
  br label %bb1
}

define void @wf_hash_map.hash_map_new$instance$a62a753cf2b0b5ca(ptr %wf.result, i64 %v0) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.b5efdacbe94e5739, align 8
  %v2 = alloca ptr, align 8
  %v1 = call ptr @wf_box_slots_new$instance$087f541e70b769ea(i64 %v0)
  store ptr %v1, ptr %v2
  %v3 = call i8 @wf_hash_map.hash_map_extend$instance$a62a753cf2b0b5ca(ptr %v2, i64 %v0)
  %v4 = call %wf.t.b5efdacbe94e5739 @wf_hash_map.hash_map_controls_new$instance$c559014c068e16a3(i64 %v0)
  store %wf.t.b5efdacbe94e5739 %v4, ptr %wf.slot.0
  %v5 = load ptr, ptr %v2
  %v6 = select i1 true, i64 0, i64 0
  store %wf.t.2758c7c2b3b908fb zeroinitializer, ptr %wf.result
  %t0 = getelementptr inbounds %wf.t.2758c7c2b3b908fb, ptr %wf.result, i32 0, i32 0
  store ptr %v5, ptr %t0
  %t1 = getelementptr inbounds %wf.t.2758c7c2b3b908fb, ptr %wf.result, i32 0, i32 1
  store i64 %v6, ptr %t1
  %t2 = getelementptr inbounds %wf.t.2758c7c2b3b908fb, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t2, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.b5efdacbe94e5739, ptr null, i32 1) to i64), i1 false)
  ret void
}

define void @wf_hash_map.hash_map_put$instance$c7b22b9ef52855b6(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, i64 %v2, ptr noalias nonnull captures(none) dereferenceable(16) %v3) #0 {
entry:
  %wf.frame = alloca { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd }, align 8
  %wf.slot.0 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd }, ptr %wf.frame, i32 0, i32 0
  %wf.slot.1 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd }, ptr %wf.frame, i32 0, i32 1
  %wf.slot.2 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd }, ptr %wf.frame, i32 0, i32 2
  call void @wf_hash_map.hash_map_try_put$instance$c7b22b9ef52855b6(ptr %wf.slot.0, ptr %v0, i64 %v1, i64 %v2, ptr %v3)
  %t0 = load %wf.t.ac5891a387b8aafe, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.ac5891a387b8aafe %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb1
    i32 1, label %bb2
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  store %wf.t.ac5891a387b8aafe zeroinitializer, ptr %wf.result
  %t2 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t2
  ret void
bb2:
  %t3 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.slot.0, i32 0, i32 1
  %v6 = load i1, ptr %t3
  %t4 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.slot.0, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %t4, i64 ptrtoint (ptr getelementptr (%wf.t.09071440a409e980, ptr null, i32 1) to i64), i1 false)
  switch i1 %v6, label %invalid.tag.b2 [
    i1 0, label %bb3
    i1 1, label %bb4
  ]
invalid.tag.b2:
  call void @abort()
  unreachable
bb3:
  %v8 = or i1 0, 0
  store %wf.t.ac5891a387b8aafe zeroinitializer, ptr %wf.result
  %t5 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t5
  %t6 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 1
  store i1 %v8, ptr %t6
  %t7 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t7, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr (%wf.t.09071440a409e980, ptr null, i32 1) to i64), i1 false)
  ret void
bb4:
  %t8 = getelementptr inbounds %wf.t.2758c7c2b3b908fb, ptr %v0, i32 0, i32 0
  %v10 = getelementptr i8, ptr %t8, i64 0
  %v11 = getelementptr i8, ptr %v10, i64 0
  %t10 = load ptr, ptr %v11
  %t11 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t10, i32 0, i32 0
  %t9 = load i64, ptr %t11
  %v12 = add i64 %t9, 0
  %v13 = select i1 true, i64 3, i64 3
  %v14 = icmp uge i64 %v12, %v13
  switch i1 %v14, label %invalid.tag.b4 [
    i1 1, label %bb6
    i1 0, label %bb7
  ]
invalid.tag.b4:
  call void @abort()
  unreachable
bb5:
  %v15 = phi ptr [ %v0, %bb7 ]
  %v16 = phi i64 [ %v1, %bb7 ]
  %v17 = phi i64 [ %v2, %bb7 ]
  %v18 = phi ptr [ %v3, %bb7 ]
  %v20 = phi i1 [ %v6, %bb7 ]
  %v22 = phi i64 [ %v12, %bb7 ]
  %v25 = select i1 true, i64 3, i64 3
  %v26 = select i1 true, i64 0, i64 0
  %v27 = icmp eq i64 %v22, %v26
  switch i1 %v27, label %invalid.tag.b5 [
    i1 1, label %bb9
    i1 0, label %bb10
  ]
invalid.tag.b5:
  call void @abort()
  unreachable
bb6:
  %v23 = or i1 0, 1
  store %wf.t.ac5891a387b8aafe zeroinitializer, ptr %wf.result
  %t12 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t12
  %t13 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 1
  store i1 %v23, ptr %t13
  %t14 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr (%wf.t.09071440a409e980, ptr null, i32 1) to i64), i1 false)
  ret void
bb7:
  br label %bb5
bb8:
  %v28 = phi ptr [ %v15, %bb9 ], [ %v40, %bb11 ]
  %v29 = phi i64 [ %v16, %bb9 ], [ %v41, %bb11 ]
  %v30 = phi i64 [ %v17, %bb9 ], [ %v42, %bb11 ]
  %v31 = phi ptr [ %v18, %bb9 ], [ %v43, %bb11 ]
  %v33 = phi i1 [ %v20, %bb9 ], [ %v45, %bb11 ]
  %v35 = phi i64 [ %v22, %bb9 ], [ %v47, %bb11 ]
  %v36 = phi i64 [ %v37, %bb9 ], [ %v48, %bb11 ]
  %v62 = call %wf.t.7d7f918f7b4962fd @wf_hash_map.hash_map_reserve$instance$c7b22b9ef52855b6(ptr %v28, i64 %v36, ptr %v31)
  store %wf.t.7d7f918f7b4962fd %v62, ptr %wf.slot.2
  %t15 = load %wf.t.7d7f918f7b4962fd, ptr %wf.slot.2
  %t16 = extractvalue %wf.t.7d7f918f7b4962fd %t15, 0
  switch i32 %t16, label %invalid.tag.b8 [
    i32 0, label %bb17
    i32 1, label %bb18
  ]
invalid.tag.b8:
  call void @abort()
  unreachable
bb9:
  %v37 = select i1 true, i64 1, i64 1
  br label %bb8
bb10:
  %v38 = select i1 true, i64 9223372036854775807, i64 9223372036854775807
  %v39 = icmp ule i64 %v22, %v38
  switch i1 %v39, label %invalid.tag.b10 [
    i1 1, label %bb12
    i1 0, label %bb13
  ]
invalid.tag.b10:
  call void @abort()
  unreachable
bb11:
  %v40 = phi ptr [ %v15, %bb13 ], [ %v52, %bb14 ]
  %v41 = phi i64 [ %v16, %bb13 ], [ %v53, %bb14 ]
  %v42 = phi i64 [ %v17, %bb13 ], [ %v54, %bb14 ]
  %v43 = phi ptr [ %v18, %bb13 ], [ %v55, %bb14 ]
  %v45 = phi i1 [ %v20, %bb13 ], [ %v57, %bb14 ]
  %v47 = phi i64 [ %v22, %bb13 ], [ %v59, %bb14 ]
  %v48 = phi i64 [ %v25, %bb13 ], [ %v60, %bb14 ]
  br label %bb8
bb12:
  %v49 = add nuw i64 %v22, %v22
  %v50 = select i1 true, i64 3, i64 3
  %v51 = icmp ule i64 %v49, %v50
  switch i1 %v51, label %invalid.tag.b12 [
    i1 1, label %bb15
    i1 0, label %bb16
  ]
invalid.tag.b12:
  call void @abort()
  unreachable
bb13:
  br label %bb11
bb14:
  %v52 = phi ptr [ %v15, %bb15 ], [ %v15, %bb16 ]
  %v53 = phi i64 [ %v16, %bb15 ], [ %v16, %bb16 ]
  %v54 = phi i64 [ %v17, %bb15 ], [ %v17, %bb16 ]
  %v55 = phi ptr [ %v18, %bb15 ], [ %v18, %bb16 ]
  %v57 = phi i1 [ %v20, %bb15 ], [ %v20, %bb16 ]
  %v59 = phi i64 [ %v22, %bb15 ], [ %v22, %bb16 ]
  %v60 = phi i64 [ %v49, %bb15 ], [ %v25, %bb16 ]
  %v61 = phi i64 [ %v49, %bb15 ], [ %v49, %bb16 ]
  br label %bb11
bb15:
  br label %bb14
bb16:
  br label %bb14
bb17:
  %t17 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.slot.2, i32 0, i32 1
  %v63 = load i8, ptr %t17
  %t18 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.1, i32 0, i32 0
  %v64 = load i64, ptr %t18
  ; ownership-consuming projection
  %t19 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.1, i32 0, i32 1
  %v65 = load i64, ptr %t19
  ; ownership-consuming projection
  call void @wf_hash_map.hash_map_try_put$instance$c7b22b9ef52855b6(ptr %wf.result, ptr %v28, i64 %v64, i64 %v65, ptr %v31)
  ret void
bb18:
  %t20 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.slot.2, i32 0, i32 2
  %v67 = load i8, ptr %t20
  %v68 = or i1 0, 1
  store %wf.t.ac5891a387b8aafe zeroinitializer, ptr %wf.result
  %t21 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t21
  %t22 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 1
  store i1 %v68, ptr %t22
  %t23 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr (%wf.t.09071440a409e980, ptr null, i32 1) to i64), i1 false)
  ret void
}

define i8 @wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd(ptr %wf.arg.v0, ptr noalias nonnull captures(none) dereferenceable(32) %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.ac5891a387b8aafe, align 8
  %wf.slot.1 = alloca %wf.t.09071440a409e980, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v0, i64 ptrtoint (ptr getelementptr (%wf.t.ac5891a387b8aafe, ptr null, i32 1) to i64), i1 false)
  %t0 = load %wf.t.ac5891a387b8aafe, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.ac5891a387b8aafe %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb2
    i32 1, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v3 = phi ptr [ %v1, %bb2 ], [ %v9, %bb4 ]
  %v20 = select i1 true, i8 0, i8 0
  ret i8 %v20
bb2:
  %v4 = select i1 true, i64 0, i64 0
  %v5 = call i8 @wf_map_cost_ordered(ptr %v1, i64 %v4)
  br label %bb1
bb3:
  %t2 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.slot.0, i32 0, i32 1
  %v6 = load i1, ptr %t2
  %t3 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.slot.0, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %t3, i64 ptrtoint (ptr getelementptr (%wf.t.09071440a409e980, ptr null, i32 1) to i64), i1 false)
  switch i1 %v6, label %invalid.tag.b3 [
    i1 0, label %bb5
    i1 1, label %bb6
  ]
invalid.tag.b3:
  call void @abort()
  unreachable
bb4:
  %v9 = phi ptr [ %v1, %bb5 ], [ %v1, %bb6 ]
  %v10 = phi i1 [ %v6, %bb5 ], [ %v6, %bb6 ]
  %t4 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.1, i32 0, i32 0
  %v16 = load i64, ptr %t4
  ; ownership-consuming projection
  %t5 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.1, i32 0, i32 1
  %v17 = load i64, ptr %t5
  ; ownership-consuming projection
  %v18 = call i64 @wf_map_cost_word_content(i64 %v16, i64 %v17)
  %v19 = call i8 @wf_map_cost_ordered(ptr %v9, i64 %v18)
  br label %bb1
bb5:
  %v12 = select i1 true, i64 1, i64 1
  %v13 = call i8 @wf_map_cost_ordered(ptr %v1, i64 %v12)
  br label %bb4
bb6:
  %v14 = select i1 true, i64 2, i64 2
  %v15 = call i8 @wf_map_cost_ordered(ptr %v1, i64 %v14)
  br label %bb4
}

define i8 @wf_hash_map.hash_map_free$instance$5c6f40d0925a4760(ptr %wf.arg.v0, ptr noalias nonnull captures(none) dereferenceable(32) %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.2758c7c2b3b908fb, align 8
  %wf.slot.1 = alloca %wf.t.b5efdacbe94e5739, align 8
  %wf.slot.2 = alloca %wf.t.eb423fc38cfed56f, align 8
  %wf.slot.3 = alloca { i64, [1 x ptr] }, align 8
  %v3 = alloca ptr, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v0, i64 ptrtoint (ptr getelementptr (%wf.t.2758c7c2b3b908fb, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.2758c7c2b3b908fb, ptr %wf.slot.0, i32 0, i32 0
  %v2 = load ptr, ptr %t0
  ; ownership-consuming projection
  store ptr %v2, ptr %v3
  %t1 = getelementptr inbounds %wf.t.2758c7c2b3b908fb, ptr %wf.slot.0, i32 0, i32 1
  %v4 = load i64, ptr %t1
  ; ownership-consuming projection
  %t2 = getelementptr inbounds %wf.t.2758c7c2b3b908fb, ptr %wf.slot.0, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %t2, i64 ptrtoint (ptr getelementptr (%wf.t.b5efdacbe94e5739, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  br label %bb1
bb1:
  %v7 = phi ptr [ %v1, %entry ], [ %v28, %bb6 ]
  %v8 = phi ptr [ %v3, %entry ], [ %v29, %bb6 ]
  %v9 = phi i64 [ %v4, %entry ], [ %v30, %bb6 ]
  %v16 = getelementptr i8, ptr %v8, i64 0
  %t4 = load ptr, ptr %v16
  %t5 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t4, i32 0, i32 0
  %t3 = load i64, ptr %t5
  %v17 = add i64 %t3, 0
  %v18 = select i1 true, i64 0, i64 0
  %v19 = icmp eq i64 %v17, %v18
  switch i1 %v19, label %invalid.tag.b1 [
    i1 1, label %bb4
    i1 0, label %bb5
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v12 = phi ptr [ %v7, %bb4 ]
  %v13 = phi ptr [ %v8, %bb4 ]
  %v14 = phi i64 [ %v9, %bb4 ]
  %v36 = load ptr, ptr %v13
  %v37 = call i8 @wf_free_empty$instance$fd33b528f0517054(ptr %v36)
  %v38 = select i1 true, i8 0, i8 0
  %t6 = getelementptr inbounds %wf.t.b5efdacbe94e5739, ptr %wf.slot.1, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.3, ptr %t6, i64 ptrtoint (ptr getelementptr ({ i64, [1 x ptr] }, ptr null, i32 1) to i64), i1 false)
  %t7 = load { i64, [1 x ptr] }, ptr %wf.slot.3
  call void @wf.drop.run.707f874ef98d2803({ i64, [1 x ptr] } %t7)
  ; drop %v39
  ; drop %v15
  ret i8 %v38
bb3:
  %v21 = phi ptr [ %v7, %bb5 ]
  %v22 = phi ptr [ %v8, %bb5 ]
  %v23 = phi i64 [ %v9, %bb5 ]
  %v25 = getelementptr i8, ptr %v22, i64 0
  %v26 = call %wf.t.eb423fc38cfed56f @wf_take_back$instance$20364da1adbcdc5f(ptr %v25)
  store %wf.t.eb423fc38cfed56f %v26, ptr %wf.slot.2
  %t8 = load %wf.t.eb423fc38cfed56f, ptr %wf.slot.2
  %t9 = extractvalue %wf.t.eb423fc38cfed56f %t8, 0
  switch i32 %t9, label %invalid.tag.b3 [
    i32 2, label %bb7
    i32 0, label %bb8
    i32 1, label %bb9
  ]
invalid.tag.b3:
  call void @abort()
  unreachable
bb4:
  br label %bb2
bb5:
  br label %bb3
bb6:
  %v28 = phi ptr [ %v21, %bb7 ], [ %v21, %bb8 ], [ %v21, %bb9 ]
  %v29 = phi ptr [ %v22, %bb7 ], [ %v22, %bb8 ], [ %v22, %bb9 ]
  %v30 = phi i64 [ %v23, %bb7 ], [ %v23, %bb8 ], [ %v23, %bb9 ]
  br label %bb1
bb7:
  %t10 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %wf.slot.2, i32 0, i32 1
  %v33 = load i64, ptr %t10
  %t11 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %wf.slot.2, i32 0, i32 2
  %v34 = load i64, ptr %t11
  %v35 = call i8 @wf_map_cost_word_consume(ptr %v21, i64 %v33, i64 %v34)
  br label %bb6
bb8:
  br label %bb6
bb9:
  br label %bb6
}

define void @wf_hash_map.hash_map_new$instance$820b2044b97e0fbd(ptr %wf.result, i64 %v0) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.b5efdacbe94e5739, align 8
  %v2 = alloca ptr, align 8
  %v1 = call ptr @wf_box_slots_new$instance$087f541e70b769ea(i64 %v0)
  store ptr %v1, ptr %v2
  %v3 = call i8 @wf_hash_map.hash_map_extend$instance$820b2044b97e0fbd(ptr %v2, i64 %v0)
  %v4 = call %wf.t.b5efdacbe94e5739 @wf_hash_map.hash_map_controls_new$instance$fd5e04af5c7e1250(i64 %v0)
  store %wf.t.b5efdacbe94e5739 %v4, ptr %wf.slot.0
  %v5 = load ptr, ptr %v2
  %v6 = select i1 true, i64 0, i64 0
  store %wf.t.7748a5b0f0193f4a zeroinitializer, ptr %wf.result
  %t0 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %wf.result, i32 0, i32 0
  store ptr %v5, ptr %t0
  %t1 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %wf.result, i32 0, i32 1
  store i64 %v6, ptr %t1
  %t2 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t2, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.b5efdacbe94e5739, ptr null, i32 1) to i64), i1 false)
  ret void
}

define void @wf_hash_map.hash_map_put$instance$fde7c6722a8b0dad(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, i64 %v2, ptr noalias nonnull captures(none) dereferenceable(16) %v3) #0 {
entry:
  %wf.frame = alloca { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd }, align 8
  %wf.slot.0 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd }, ptr %wf.frame, i32 0, i32 0
  %wf.slot.1 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd }, ptr %wf.frame, i32 0, i32 1
  %wf.slot.2 = getelementptr inbounds { %wf.t.ac5891a387b8aafe, %wf.t.09071440a409e980, %wf.t.7d7f918f7b4962fd }, ptr %wf.frame, i32 0, i32 2
  call void @wf_hash_map.hash_map_try_put$instance$fde7c6722a8b0dad(ptr %wf.slot.0, ptr %v0, i64 %v1, i64 %v2, ptr %v3)
  %t0 = load %wf.t.ac5891a387b8aafe, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.ac5891a387b8aafe %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb1
    i32 1, label %bb2
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  store %wf.t.ac5891a387b8aafe zeroinitializer, ptr %wf.result
  %t2 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t2
  ret void
bb2:
  %t3 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.slot.0, i32 0, i32 1
  %v6 = load i1, ptr %t3
  %t4 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.slot.0, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %t4, i64 ptrtoint (ptr getelementptr (%wf.t.09071440a409e980, ptr null, i32 1) to i64), i1 false)
  switch i1 %v6, label %invalid.tag.b2 [
    i1 0, label %bb3
    i1 1, label %bb4
  ]
invalid.tag.b2:
  call void @abort()
  unreachable
bb3:
  %v8 = or i1 0, 0
  store %wf.t.ac5891a387b8aafe zeroinitializer, ptr %wf.result
  %t5 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t5
  %t6 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 1
  store i1 %v8, ptr %t6
  %t7 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t7, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr (%wf.t.09071440a409e980, ptr null, i32 1) to i64), i1 false)
  ret void
bb4:
  %t8 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v0, i32 0, i32 0
  %v10 = getelementptr i8, ptr %t8, i64 0
  %v11 = getelementptr i8, ptr %v10, i64 0
  %t10 = load ptr, ptr %v11
  %t11 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t10, i32 0, i32 0
  %t9 = load i64, ptr %t11
  %v12 = add i64 %t9, 0
  %v13 = select i1 true, i64 16384, i64 16384
  %v14 = icmp uge i64 %v12, %v13
  switch i1 %v14, label %invalid.tag.b4 [
    i1 1, label %bb6
    i1 0, label %bb7
  ]
invalid.tag.b4:
  call void @abort()
  unreachable
bb5:
  %v15 = phi ptr [ %v0, %bb7 ]
  %v16 = phi i64 [ %v1, %bb7 ]
  %v17 = phi i64 [ %v2, %bb7 ]
  %v18 = phi ptr [ %v3, %bb7 ]
  %v20 = phi i1 [ %v6, %bb7 ]
  %v22 = phi i64 [ %v12, %bb7 ]
  %v25 = select i1 true, i64 16384, i64 16384
  %v26 = select i1 true, i64 0, i64 0
  %v27 = icmp eq i64 %v22, %v26
  switch i1 %v27, label %invalid.tag.b5 [
    i1 1, label %bb9
    i1 0, label %bb10
  ]
invalid.tag.b5:
  call void @abort()
  unreachable
bb6:
  %v23 = or i1 0, 1
  store %wf.t.ac5891a387b8aafe zeroinitializer, ptr %wf.result
  %t12 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t12
  %t13 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 1
  store i1 %v23, ptr %t13
  %t14 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr (%wf.t.09071440a409e980, ptr null, i32 1) to i64), i1 false)
  ret void
bb7:
  br label %bb5
bb8:
  %v28 = phi ptr [ %v15, %bb9 ], [ %v40, %bb11 ]
  %v29 = phi i64 [ %v16, %bb9 ], [ %v41, %bb11 ]
  %v30 = phi i64 [ %v17, %bb9 ], [ %v42, %bb11 ]
  %v31 = phi ptr [ %v18, %bb9 ], [ %v43, %bb11 ]
  %v33 = phi i1 [ %v20, %bb9 ], [ %v45, %bb11 ]
  %v35 = phi i64 [ %v22, %bb9 ], [ %v47, %bb11 ]
  %v36 = phi i64 [ %v37, %bb9 ], [ %v48, %bb11 ]
  %v62 = call %wf.t.7d7f918f7b4962fd @wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad(ptr %v28, i64 %v36, ptr %v31)
  store %wf.t.7d7f918f7b4962fd %v62, ptr %wf.slot.2
  %t15 = load %wf.t.7d7f918f7b4962fd, ptr %wf.slot.2
  %t16 = extractvalue %wf.t.7d7f918f7b4962fd %t15, 0
  switch i32 %t16, label %invalid.tag.b8 [
    i32 0, label %bb17
    i32 1, label %bb18
  ]
invalid.tag.b8:
  call void @abort()
  unreachable
bb9:
  %v37 = select i1 true, i64 1, i64 1
  br label %bb8
bb10:
  %v38 = select i1 true, i64 9223372036854775807, i64 9223372036854775807
  %v39 = icmp ule i64 %v22, %v38
  switch i1 %v39, label %invalid.tag.b10 [
    i1 1, label %bb12
    i1 0, label %bb13
  ]
invalid.tag.b10:
  call void @abort()
  unreachable
bb11:
  %v40 = phi ptr [ %v15, %bb13 ], [ %v52, %bb14 ]
  %v41 = phi i64 [ %v16, %bb13 ], [ %v53, %bb14 ]
  %v42 = phi i64 [ %v17, %bb13 ], [ %v54, %bb14 ]
  %v43 = phi ptr [ %v18, %bb13 ], [ %v55, %bb14 ]
  %v45 = phi i1 [ %v20, %bb13 ], [ %v57, %bb14 ]
  %v47 = phi i64 [ %v22, %bb13 ], [ %v59, %bb14 ]
  %v48 = phi i64 [ %v25, %bb13 ], [ %v60, %bb14 ]
  br label %bb8
bb12:
  %v49 = add nuw i64 %v22, %v22
  %v50 = select i1 true, i64 16384, i64 16384
  %v51 = icmp ule i64 %v49, %v50
  switch i1 %v51, label %invalid.tag.b12 [
    i1 1, label %bb15
    i1 0, label %bb16
  ]
invalid.tag.b12:
  call void @abort()
  unreachable
bb13:
  br label %bb11
bb14:
  %v52 = phi ptr [ %v15, %bb15 ], [ %v15, %bb16 ]
  %v53 = phi i64 [ %v16, %bb15 ], [ %v16, %bb16 ]
  %v54 = phi i64 [ %v17, %bb15 ], [ %v17, %bb16 ]
  %v55 = phi ptr [ %v18, %bb15 ], [ %v18, %bb16 ]
  %v57 = phi i1 [ %v20, %bb15 ], [ %v20, %bb16 ]
  %v59 = phi i64 [ %v22, %bb15 ], [ %v22, %bb16 ]
  %v60 = phi i64 [ %v49, %bb15 ], [ %v25, %bb16 ]
  %v61 = phi i64 [ %v49, %bb15 ], [ %v49, %bb16 ]
  br label %bb11
bb15:
  br label %bb14
bb16:
  br label %bb14
bb17:
  %t17 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.slot.2, i32 0, i32 1
  %v63 = load i8, ptr %t17
  %t18 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.1, i32 0, i32 0
  %v64 = load i64, ptr %t18
  ; ownership-consuming projection
  %t19 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.1, i32 0, i32 1
  %v65 = load i64, ptr %t19
  ; ownership-consuming projection
  call void @wf_hash_map.hash_map_try_put$instance$fde7c6722a8b0dad(ptr %wf.result, ptr %v28, i64 %v64, i64 %v65, ptr %v31)
  ret void
bb18:
  %t20 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.slot.2, i32 0, i32 2
  %v67 = load i8, ptr %t20
  %v68 = or i1 0, 1
  store %wf.t.ac5891a387b8aafe zeroinitializer, ptr %wf.result
  %t21 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t21
  %t22 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 1
  store i1 %v68, ptr %t22
  %t23 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr (%wf.t.09071440a409e980, ptr null, i32 1) to i64), i1 false)
  ret void
}

define internal void @wf_hash_map.hash_map_remove$instance$fde7c6722a8b0dad.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.7748a5b0f0193f4a, align 8
  %wf.slot.1 = alloca %wf.t.b7e1ed626c09888a, align 8
  %wf.slot.2 = alloca %wf.t.eb423fc38cfed56f, align 8
  %wf.slot.3 = alloca %wf.t.09071440a409e980, align 8
  %v15 = alloca %wf.t.eb423fc38cfed56f, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.7748a5b0f0193f4a, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %wf.slot.0, i32 0, i32 1
  %v4 = load i64, ptr %t0
  %v5 = select i1 true, i64 0, i64 0
  %v6 = icmp eq i64 %v4, %v5
  switch i1 %v6, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v7 = phi ptr [ %v0, %bb3 ]
  %v8 = phi ptr [ %v1, %bb3 ]
  %v9 = phi ptr [ %v2, %bb3 ]
  %v10 = phi i64 [ %v4, %bb3 ]
  %v12 = call %wf.t.b7e1ed626c09888a @wf_hash_map.hash_map_find$instance$fde7c6722a8b0dad(ptr %v7, ptr %v8, ptr %v9)
  store %wf.t.b7e1ed626c09888a %v12, ptr %wf.slot.1
  %t1 = load %wf.t.b7e1ed626c09888a, ptr %wf.slot.1
  %t2 = extractvalue %wf.t.b7e1ed626c09888a %t1, 0
  switch i32 %t2, label %invalid.tag.b1 [
    i32 0, label %bb4
    i32 1, label %bb5
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  store %wf.t.743755fb647946cb zeroinitializer, ptr %wf.result
  %t3 = getelementptr inbounds %wf.t.743755fb647946cb, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t3
  ret void
bb3:
  br label %bb1
bb4:
  %t4 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.slot.1, i32 0, i32 1
  %v13 = load i64, ptr %t4
  store %wf.t.eb423fc38cfed56f zeroinitializer, ptr %v15
  %t5 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %v15, i32 0, i32 0
  store i32 1, ptr %t5
  %t6 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v7, i32 0, i32 0
  %v16 = getelementptr i8, ptr %t6, i64 0
  %v17 = getelementptr i8, ptr %v16, i64 0
  %t7 = load ptr, ptr %v17
  %t8.nonnegative = icmp sge i64 %v13, 0
  call void @llvm.assume(i1 %t8.nonnegative)
  %t8 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t7, i64 0, i32 2, i64 %v13
  %v18 = getelementptr i8, ptr %t8, i64 0
  %v19 = call i8 @wf_swap$instance$087f541e70b769ea(ptr %v18, ptr %v15)
  %t9 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v7, i32 0, i32 2
  %v20 = getelementptr i8, ptr %t9, i64 0
  %v21 = select i1 true, i64 254, i64 254
  %v22 = call i8 @wf_hash_map.hash_map_control_set(ptr %v20, i64 %v13, i64 %v21)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %v15, i64 ptrtoint (ptr getelementptr (%wf.t.eb423fc38cfed56f, ptr null, i32 1) to i64), i1 false)
  %t10 = load %wf.t.eb423fc38cfed56f, ptr %wf.slot.2
  %t11 = extractvalue %wf.t.eb423fc38cfed56f %t10, 0
  switch i32 %t11, label %invalid.tag.b4 [
    i32 2, label %bb6
    i32 0, label %bb7
    i32 1, label %bb8
  ]
invalid.tag.b4:
  call void @abort()
  unreachable
bb5:
  %t12 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.slot.1, i32 0, i32 2
  %v33 = load i8, ptr %t12
  store %wf.t.743755fb647946cb zeroinitializer, ptr %wf.result
  %t13 = getelementptr inbounds %wf.t.743755fb647946cb, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t13
  ret void
bb6:
  %t14 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %wf.slot.2, i32 0, i32 1
  %v24 = load i64, ptr %t14
  %t15 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %wf.slot.2, i32 0, i32 2
  %v25 = load i64, ptr %t15
  %t16 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v7, i32 0, i32 1
  %v26 = getelementptr i8, ptr %t16, i64 0
  %v27 = select i1 true, i64 1, i64 1
  %v28 = sub nuw i64 %v10, %v27
  store i64 %v28, ptr %v26
  store %wf.t.09071440a409e980 zeroinitializer, ptr %wf.slot.3
  %t17 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.3, i32 0, i32 0
  store i64 %v24, ptr %t17
  %t18 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.3, i32 0, i32 1
  store i64 %v25, ptr %t18
  store %wf.t.743755fb647946cb zeroinitializer, ptr %wf.result
  %t19 = getelementptr inbounds %wf.t.743755fb647946cb, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t19
  %t20 = getelementptr inbounds %wf.t.743755fb647946cb, ptr %wf.result, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t20, ptr %wf.slot.3, i64 ptrtoint (ptr getelementptr (%wf.t.09071440a409e980, ptr null, i32 1) to i64), i1 false)
  ret void
bb7:
  store %wf.t.743755fb647946cb zeroinitializer, ptr %wf.result
  %t21 = getelementptr inbounds %wf.t.743755fb647946cb, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t21
  ret void
bb8:
  store %wf.t.743755fb647946cb zeroinitializer, ptr %wf.result
  %t22 = getelementptr inbounds %wf.t.743755fb647946cb, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t22
  ret void
}

define %wf.t.743755fb647946cb @wf_hash_map.hash_map_remove$instance$fde7c6722a8b0dad(ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.result = alloca %wf.t.743755fb647946cb, align 8
  call void @wf_hash_map.hash_map_remove$instance$fde7c6722a8b0dad.body(ptr %wf.result, ptr %v0, ptr %v1, ptr %v2)
  %wf.returned = load %wf.t.743755fb647946cb, ptr %wf.result
  ret %wf.t.743755fb647946cb %wf.returned
}

define internal void @wf_hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2, ptr noalias nonnull captures(none) dereferenceable(32) %v3) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.b7e1ed626c09888a, align 8
  %wf.slot.1 = alloca %wf.t.eb423fc38cfed56f, align 8
  %v4 = call %wf.t.b7e1ed626c09888a @wf_hash_map.hash_map_find$instance$fde7c6722a8b0dad(ptr %v0, ptr %v1, ptr %v2)
  store %wf.t.b7e1ed626c09888a %v4, ptr %wf.slot.0
  %t0 = load %wf.t.b7e1ed626c09888a, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.b7e1ed626c09888a %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb1
    i32 1, label %bb2
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %t2 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.slot.0, i32 0, i32 1
  %v5 = load i64, ptr %t2
  %t3 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v0, i32 0, i32 0
  %v6 = getelementptr i8, ptr %t3, i64 0
  %v7 = getelementptr i8, ptr %v6, i64 0
  %t4 = load ptr, ptr %v7
  %t5.nonnegative = icmp sge i64 %v5, 0
  call void @llvm.assume(i1 %t5.nonnegative)
  %t5 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t4, i64 0, i32 2, i64 %v5
  %v8 = getelementptr i8, ptr %t5, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v8, i64 ptrtoint (ptr getelementptr (%wf.t.eb423fc38cfed56f, ptr null, i32 1) to i64), i1 false)
  %t6 = load %wf.t.eb423fc38cfed56f, ptr %wf.slot.1
  %t7 = extractvalue %wf.t.eb423fc38cfed56f %t6, 0
  switch i32 %t7, label %invalid.tag.b1 [
    i32 2, label %bb3
    i32 0, label %bb4
    i32 1, label %bb5
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %t8 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.slot.0, i32 0, i32 2
  %v18 = load i8, ptr %t8
  %v19 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t9 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t9
  %t10 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v19, ptr %t10
  ret void
bb3:
  %t11 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %v8, i32 0, i32 1
  %v10 = getelementptr i8, ptr %t11, i64 0
  %t12 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %v8, i32 0, i32 2
  %v11 = getelementptr i8, ptr %t12, i64 0
  %v12 = call i64 @wf_map_cost_word_observe(ptr %v3, ptr %v10, ptr %v11)
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t13 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t13
  %t14 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 1
  store i64 %v12, ptr %t14
  ret void
bb4:
  %v14 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t15 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t15
  %t16 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v14, ptr %t16
  ret void
bb5:
  %v16 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t17 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t17
  %t18 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v16, ptr %t18
  ret void
}

define %wf.t.b7e1ed626c09888a @wf_hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50(ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2, ptr noalias nonnull captures(none) dereferenceable(32) %v3) #0 {
entry:
  %wf.result = alloca %wf.t.b7e1ed626c09888a, align 8
  call void @wf_hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50.body(ptr %wf.result, ptr %v0, ptr %v1, ptr %v2, ptr %v3)
  %wf.returned = load %wf.t.b7e1ed626c09888a, ptr %wf.result
  ret %wf.t.b7e1ed626c09888a %wf.returned
}

define internal void @wf_hash_map.hash_map_rehash$instance$fde7c6722a8b0dad.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(16) %v1) #0 {
entry:
  %t0 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v0, i32 0, i32 0
  %v2 = getelementptr i8, ptr %t0, i64 0
  %v3 = getelementptr i8, ptr %v2, i64 0
  %t2 = load ptr, ptr %v3
  %t3 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t2, i32 0, i32 0
  %t1 = load i64, ptr %t3
  %v4 = add i64 %t1, 0
  %v5 = call %wf.t.7d7f918f7b4962fd @wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad(ptr %v0, i64 %v4, ptr %v1)
  store %wf.t.7d7f918f7b4962fd %v5, ptr %wf.result
  ret void
}

define %wf.t.7d7f918f7b4962fd @wf_hash_map.hash_map_rehash$instance$fde7c6722a8b0dad(ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(16) %v1) #0 {
entry:
  %wf.result = alloca %wf.t.7d7f918f7b4962fd, align 4
  call void @wf_hash_map.hash_map_rehash$instance$fde7c6722a8b0dad.body(ptr %wf.result, ptr %v0, ptr %v1)
  %wf.returned = load %wf.t.7d7f918f7b4962fd, ptr %wf.result
  ret %wf.t.7d7f918f7b4962fd %wf.returned
}

define internal void @wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %v3 = select i1 true, i64 16384, i64 16384
  %v4 = icmp ugt i64 %v1, %v3
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v5 = phi ptr [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb3 ]
  %v7 = phi ptr [ %v2, %bb3 ]
  %t0 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v5, i32 0, i32 0
  %v10 = getelementptr i8, ptr %t0, i64 0
  %v11 = getelementptr i8, ptr %v10, i64 0
  %t2 = load ptr, ptr %v11
  %t3 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t2, i32 0, i32 0
  %t1 = load i64, ptr %t3
  %v12 = add i64 %t1, 0
  %v13 = icmp ule i64 %v6, %v12
  switch i1 %v13, label %invalid.tag.b1 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v8 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t4 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t4
  %t5 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 2
  store i8 %v8, ptr %t5
  ret void
bb3:
  br label %bb1
bb4:
  %v14 = phi ptr [ %v5, %bb6 ]
  %v15 = phi i64 [ %v6, %bb6 ]
  %v16 = phi ptr [ %v7, %bb6 ]
  %v19 = call %wf.t.7d7f918f7b4962fd @wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad(ptr %v14, i64 %v15, ptr %v16)
  store %wf.t.7d7f918f7b4962fd %v19, ptr %wf.result
  ret void
bb5:
  %v17 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t6 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t6
  %t7 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 1
  store i8 %v17, ptr %t7
  ret void
bb6:
  br label %bb4
}

define %wf.t.7d7f918f7b4962fd @wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad(ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.result = alloca %wf.t.7d7f918f7b4962fd, align 4
  call void @wf_hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.body(ptr %wf.result, ptr %v0, i64 %v1, ptr %v2)
  %wf.returned = load %wf.t.7d7f918f7b4962fd, ptr %wf.result
  ret %wf.t.7d7f918f7b4962fd %wf.returned
}

define i64 @wf_hash_map.hash_map_capacity$instance$820b2044b97e0fbd(ptr noalias nonnull captures(none) dereferenceable(40) %v0) #0 {
entry:
  %t0 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v0, i32 0, i32 0
  %v1 = getelementptr i8, ptr %t0, i64 0
  %v2 = getelementptr i8, ptr %v1, i64 0
  %t2 = load ptr, ptr %v2
  %t3 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t2, i32 0, i32 0
  %t1 = load i64, ptr %t3
  %v3 = add i64 %t1, 0
  ret i64 %v3
}

define internal void @wf_hash_map.hash_map_edit$instance$25497bb333d90567.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2, ptr noalias nonnull captures(none) dereferenceable(32) %v3) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.b7e1ed626c09888a, align 8
  %wf.slot.1 = alloca %wf.t.eb423fc38cfed56f, align 8
  %v4 = call %wf.t.b7e1ed626c09888a @wf_hash_map.hash_map_find$instance$fde7c6722a8b0dad(ptr %v0, ptr %v1, ptr %v2)
  store %wf.t.b7e1ed626c09888a %v4, ptr %wf.slot.0
  %t0 = load %wf.t.b7e1ed626c09888a, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.b7e1ed626c09888a %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb1
    i32 1, label %bb2
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %t2 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.slot.0, i32 0, i32 1
  %v5 = load i64, ptr %t2
  %t3 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v0, i32 0, i32 0
  %v6 = getelementptr i8, ptr %t3, i64 0
  %v7 = getelementptr i8, ptr %v6, i64 0
  %t4 = load ptr, ptr %v7
  %t5.nonnegative = icmp sge i64 %v5, 0
  call void @llvm.assume(i1 %t5.nonnegative)
  %t5 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t4, i64 0, i32 2, i64 %v5
  %v8 = getelementptr i8, ptr %t5, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v8, i64 ptrtoint (ptr getelementptr (%wf.t.eb423fc38cfed56f, ptr null, i32 1) to i64), i1 false)
  %t6 = load %wf.t.eb423fc38cfed56f, ptr %wf.slot.1
  %t7 = extractvalue %wf.t.eb423fc38cfed56f %t6, 0
  switch i32 %t7, label %invalid.tag.b1 [
    i32 2, label %bb3
    i32 0, label %bb4
    i32 1, label %bb5
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %t8 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.slot.0, i32 0, i32 2
  %v18 = load i8, ptr %t8
  %v19 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t9 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t9
  %t10 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v19, ptr %t10
  ret void
bb3:
  %t11 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %v8, i32 0, i32 1
  %v10 = getelementptr i8, ptr %t11, i64 0
  %t12 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %v8, i32 0, i32 2
  %v11 = getelementptr i8, ptr %t12, i64 0
  %v12 = call i64 @wf_map_cost_word_edit(ptr %v3, ptr %v10, ptr %v11)
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t13 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t13
  %t14 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 1
  store i64 %v12, ptr %t14
  ret void
bb4:
  %v14 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t15 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t15
  %t16 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v14, ptr %t16
  ret void
bb5:
  %v16 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t17 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t17
  %t18 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v16, ptr %t18
  ret void
}

define %wf.t.b7e1ed626c09888a @wf_hash_map.hash_map_edit$instance$25497bb333d90567(ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2, ptr noalias nonnull captures(none) dereferenceable(32) %v3) #0 {
entry:
  %wf.result = alloca %wf.t.b7e1ed626c09888a, align 8
  call void @wf_hash_map.hash_map_edit$instance$25497bb333d90567.body(ptr %wf.result, ptr %v0, ptr %v1, ptr %v2, ptr %v3)
  %wf.returned = load %wf.t.b7e1ed626c09888a, ptr %wf.result
  ret %wf.t.b7e1ed626c09888a %wf.returned
}

define i8 @wf_hash_map.hash_map_free$instance$001ff12ace7d7c19(ptr %wf.arg.v0, ptr noalias nonnull captures(none) dereferenceable(32) %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.7748a5b0f0193f4a, align 8
  %wf.slot.1 = alloca %wf.t.b5efdacbe94e5739, align 8
  %wf.slot.2 = alloca %wf.t.eb423fc38cfed56f, align 8
  %wf.slot.3 = alloca { i64, [1 x ptr] }, align 8
  %v3 = alloca ptr, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v0, i64 ptrtoint (ptr getelementptr (%wf.t.7748a5b0f0193f4a, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %wf.slot.0, i32 0, i32 0
  %v2 = load ptr, ptr %t0
  ; ownership-consuming projection
  store ptr %v2, ptr %v3
  %t1 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %wf.slot.0, i32 0, i32 1
  %v4 = load i64, ptr %t1
  ; ownership-consuming projection
  %t2 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %wf.slot.0, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %t2, i64 ptrtoint (ptr getelementptr (%wf.t.b5efdacbe94e5739, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  br label %bb1
bb1:
  %v7 = phi ptr [ %v1, %entry ], [ %v28, %bb6 ]
  %v8 = phi ptr [ %v3, %entry ], [ %v29, %bb6 ]
  %v9 = phi i64 [ %v4, %entry ], [ %v30, %bb6 ]
  %v16 = getelementptr i8, ptr %v8, i64 0
  %t4 = load ptr, ptr %v16
  %t5 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t4, i32 0, i32 0
  %t3 = load i64, ptr %t5
  %v17 = add i64 %t3, 0
  %v18 = select i1 true, i64 0, i64 0
  %v19 = icmp eq i64 %v17, %v18
  switch i1 %v19, label %invalid.tag.b1 [
    i1 1, label %bb4
    i1 0, label %bb5
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v12 = phi ptr [ %v7, %bb4 ]
  %v13 = phi ptr [ %v8, %bb4 ]
  %v14 = phi i64 [ %v9, %bb4 ]
  %v36 = load ptr, ptr %v13
  %v37 = call i8 @wf_free_empty$instance$fd33b528f0517054(ptr %v36)
  %v38 = select i1 true, i8 0, i8 0
  %t6 = getelementptr inbounds %wf.t.b5efdacbe94e5739, ptr %wf.slot.1, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.3, ptr %t6, i64 ptrtoint (ptr getelementptr ({ i64, [1 x ptr] }, ptr null, i32 1) to i64), i1 false)
  %t7 = load { i64, [1 x ptr] }, ptr %wf.slot.3
  call void @wf.drop.run.707f874ef98d2803({ i64, [1 x ptr] } %t7)
  ; drop %v39
  ; drop %v15
  ret i8 %v38
bb3:
  %v21 = phi ptr [ %v7, %bb5 ]
  %v22 = phi ptr [ %v8, %bb5 ]
  %v23 = phi i64 [ %v9, %bb5 ]
  %v25 = getelementptr i8, ptr %v22, i64 0
  %v26 = call %wf.t.eb423fc38cfed56f @wf_take_back$instance$20364da1adbcdc5f(ptr %v25)
  store %wf.t.eb423fc38cfed56f %v26, ptr %wf.slot.2
  %t8 = load %wf.t.eb423fc38cfed56f, ptr %wf.slot.2
  %t9 = extractvalue %wf.t.eb423fc38cfed56f %t8, 0
  switch i32 %t9, label %invalid.tag.b3 [
    i32 2, label %bb7
    i32 0, label %bb8
    i32 1, label %bb9
  ]
invalid.tag.b3:
  call void @abort()
  unreachable
bb4:
  br label %bb2
bb5:
  br label %bb3
bb6:
  %v28 = phi ptr [ %v21, %bb7 ], [ %v21, %bb8 ], [ %v21, %bb9 ]
  %v29 = phi ptr [ %v22, %bb7 ], [ %v22, %bb8 ], [ %v22, %bb9 ]
  %v30 = phi i64 [ %v23, %bb7 ], [ %v23, %bb8 ], [ %v23, %bb9 ]
  br label %bb1
bb7:
  %t10 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %wf.slot.2, i32 0, i32 1
  %v33 = load i64, ptr %t10
  %t11 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %wf.slot.2, i32 0, i32 2
  %v34 = load i64, ptr %t11
  %v35 = call i8 @wf_map_cost_word_consume(ptr %v21, i64 %v33, i64 %v34)
  br label %bb6
bb8:
  br label %bb6
bb9:
  br label %bb6
}

define void @wf_hash_map.hash_map_new$instance$96033bf6ddb80743(ptr %wf.result, i64 %v0) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.b5efdacbe94e5739, align 8
  %v2 = alloca ptr, align 8
  %v1 = call ptr @wf_box_slots_new$instance$b1cfa6e689dc9e10(i64 %v0)
  store ptr %v1, ptr %v2
  %v3 = call i8 @wf_hash_map.hash_map_extend$instance$96033bf6ddb80743(ptr %v2, i64 %v0)
  %v4 = call %wf.t.b5efdacbe94e5739 @wf_hash_map.hash_map_controls_new$instance$c559014c068e16a3(i64 %v0)
  store %wf.t.b5efdacbe94e5739 %v4, ptr %wf.slot.0
  %v5 = load ptr, ptr %v2
  %v6 = select i1 true, i64 0, i64 0
  store %wf.t.a5ea622fe32c85b6 zeroinitializer, ptr %wf.result
  %t0 = getelementptr inbounds %wf.t.a5ea622fe32c85b6, ptr %wf.result, i32 0, i32 0
  store ptr %v5, ptr %t0
  %t1 = getelementptr inbounds %wf.t.a5ea622fe32c85b6, ptr %wf.result, i32 0, i32 1
  store i64 %v6, ptr %t1
  %t2 = getelementptr inbounds %wf.t.a5ea622fe32c85b6, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t2, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.b5efdacbe94e5739, ptr null, i32 1) to i64), i1 false)
  ret void
}

define void @wf_hash_map.hash_map_put$instance$8d5197e2f00c3b07(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr %wf.arg.v2, ptr noalias nonnull captures(none) dereferenceable(16) %v3) #0 {
entry:
  %wf.frame = alloca { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.7d7f918f7b4962fd, %wf.t.862971f7a971a883 }, align 8
  %wf.slot.0 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.7d7f918f7b4962fd, %wf.t.862971f7a971a883 }, ptr %wf.frame, i32 0, i32 0
  %wf.slot.1 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.7d7f918f7b4962fd, %wf.t.862971f7a971a883 }, ptr %wf.frame, i32 0, i32 1
  %wf.slot.2 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.7d7f918f7b4962fd, %wf.t.862971f7a971a883 }, ptr %wf.frame, i32 0, i32 2
  %wf.slot.3 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.7d7f918f7b4962fd, %wf.t.862971f7a971a883 }, ptr %wf.frame, i32 0, i32 3
  %wf.slot.4 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.7d7f918f7b4962fd, %wf.t.862971f7a971a883 }, ptr %wf.frame, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v2, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  call void @wf_hash_map.hash_map_try_put$instance$8d5197e2f00c3b07(ptr %wf.slot.1, ptr %v0, i64 %v1, ptr %wf.slot.0, ptr %v3)
  %t0 = load %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.1
  %t1 = extractvalue %wf.t.9d321e1eb2ec1c03 %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb1
    i32 1, label %bb2
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  store %wf.t.9d321e1eb2ec1c03 zeroinitializer, ptr %wf.result
  %t2 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t2
  ret void
bb2:
  %t3 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.1, i32 0, i32 1
  %v6 = load i1, ptr %t3
  %t4 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.1, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %t4, i64 ptrtoint (ptr getelementptr (%wf.t.20dda3774c7510ec, ptr null, i32 1) to i64), i1 false)
  switch i1 %v6, label %invalid.tag.b2 [
    i1 0, label %bb3
    i1 1, label %bb4
  ]
invalid.tag.b2:
  call void @abort()
  unreachable
bb3:
  %v8 = or i1 0, 0
  store %wf.t.9d321e1eb2ec1c03 zeroinitializer, ptr %wf.result
  %t5 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t5
  %t6 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 1
  store i1 %v8, ptr %t6
  %t7 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t7, ptr %wf.slot.2, i64 ptrtoint (ptr getelementptr (%wf.t.20dda3774c7510ec, ptr null, i32 1) to i64), i1 false)
  ret void
bb4:
  %t8 = getelementptr inbounds %wf.t.a5ea622fe32c85b6, ptr %v0, i32 0, i32 0
  %v10 = getelementptr i8, ptr %t8, i64 0
  %v11 = getelementptr i8, ptr %v10, i64 0
  %t10 = load ptr, ptr %v11
  %t11 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t10, i32 0, i32 0
  %t9 = load i64, ptr %t11
  %v12 = add i64 %t9, 0
  %v13 = select i1 true, i64 3, i64 3
  %v14 = icmp uge i64 %v12, %v13
  switch i1 %v14, label %invalid.tag.b4 [
    i1 1, label %bb6
    i1 0, label %bb7
  ]
invalid.tag.b4:
  call void @abort()
  unreachable
bb5:
  %v15 = phi ptr [ %v0, %bb7 ]
  %v16 = phi i64 [ %v1, %bb7 ]
  %v18 = phi ptr [ %v3, %bb7 ]
  %v20 = phi i1 [ %v6, %bb7 ]
  %v22 = phi i64 [ %v12, %bb7 ]
  %v25 = select i1 true, i64 3, i64 3
  %v26 = select i1 true, i64 0, i64 0
  %v27 = icmp eq i64 %v22, %v26
  switch i1 %v27, label %invalid.tag.b5 [
    i1 1, label %bb9
    i1 0, label %bb10
  ]
invalid.tag.b5:
  call void @abort()
  unreachable
bb6:
  %v23 = or i1 0, 1
  store %wf.t.9d321e1eb2ec1c03 zeroinitializer, ptr %wf.result
  %t12 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t12
  %t13 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 1
  store i1 %v23, ptr %t13
  %t14 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %wf.slot.2, i64 ptrtoint (ptr getelementptr (%wf.t.20dda3774c7510ec, ptr null, i32 1) to i64), i1 false)
  ret void
bb7:
  br label %bb5
bb8:
  %v28 = phi ptr [ %v15, %bb9 ], [ %v40, %bb11 ]
  %v29 = phi i64 [ %v16, %bb9 ], [ %v41, %bb11 ]
  %v31 = phi ptr [ %v18, %bb9 ], [ %v43, %bb11 ]
  %v33 = phi i1 [ %v20, %bb9 ], [ %v45, %bb11 ]
  %v35 = phi i64 [ %v22, %bb9 ], [ %v47, %bb11 ]
  %v36 = phi i64 [ %v37, %bb9 ], [ %v48, %bb11 ]
  %v62 = call %wf.t.7d7f918f7b4962fd @wf_hash_map.hash_map_reserve$instance$8d5197e2f00c3b07(ptr %v28, i64 %v36, ptr %v31)
  store %wf.t.7d7f918f7b4962fd %v62, ptr %wf.slot.3
  %t15 = load %wf.t.7d7f918f7b4962fd, ptr %wf.slot.3
  %t16 = extractvalue %wf.t.7d7f918f7b4962fd %t15, 0
  switch i32 %t16, label %invalid.tag.b8 [
    i32 0, label %bb17
    i32 1, label %bb18
  ]
invalid.tag.b8:
  call void @abort()
  unreachable
bb9:
  %v37 = select i1 true, i64 1, i64 1
  br label %bb8
bb10:
  %v38 = select i1 true, i64 9223372036854775807, i64 9223372036854775807
  %v39 = icmp ule i64 %v22, %v38
  switch i1 %v39, label %invalid.tag.b10 [
    i1 1, label %bb12
    i1 0, label %bb13
  ]
invalid.tag.b10:
  call void @abort()
  unreachable
bb11:
  %v40 = phi ptr [ %v15, %bb13 ], [ %v52, %bb14 ]
  %v41 = phi i64 [ %v16, %bb13 ], [ %v53, %bb14 ]
  %v43 = phi ptr [ %v18, %bb13 ], [ %v55, %bb14 ]
  %v45 = phi i1 [ %v20, %bb13 ], [ %v57, %bb14 ]
  %v47 = phi i64 [ %v22, %bb13 ], [ %v59, %bb14 ]
  %v48 = phi i64 [ %v25, %bb13 ], [ %v60, %bb14 ]
  br label %bb8
bb12:
  %v49 = add nuw i64 %v22, %v22
  %v50 = select i1 true, i64 3, i64 3
  %v51 = icmp ule i64 %v49, %v50
  switch i1 %v51, label %invalid.tag.b12 [
    i1 1, label %bb15
    i1 0, label %bb16
  ]
invalid.tag.b12:
  call void @abort()
  unreachable
bb13:
  br label %bb11
bb14:
  %v52 = phi ptr [ %v15, %bb15 ], [ %v15, %bb16 ]
  %v53 = phi i64 [ %v16, %bb15 ], [ %v16, %bb16 ]
  %v55 = phi ptr [ %v18, %bb15 ], [ %v18, %bb16 ]
  %v57 = phi i1 [ %v20, %bb15 ], [ %v20, %bb16 ]
  %v59 = phi i64 [ %v22, %bb15 ], [ %v22, %bb16 ]
  %v60 = phi i64 [ %v49, %bb15 ], [ %v25, %bb16 ]
  %v61 = phi i64 [ %v49, %bb15 ], [ %v49, %bb16 ]
  br label %bb11
bb15:
  br label %bb14
bb16:
  br label %bb14
bb17:
  %t17 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.slot.3, i32 0, i32 1
  %v63 = load i8, ptr %t17
  %t18 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.2, i32 0, i32 0
  %v64 = load i64, ptr %t18
  ; ownership-consuming projection
  %t19 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.2, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.4, ptr %t19, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  call void @wf_hash_map.hash_map_try_put$instance$8d5197e2f00c3b07(ptr %wf.result, ptr %v28, i64 %v64, ptr %wf.slot.4, ptr %v31)
  ret void
bb18:
  %t20 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.slot.3, i32 0, i32 2
  %v67 = load i8, ptr %t20
  %v68 = or i1 0, 1
  store %wf.t.9d321e1eb2ec1c03 zeroinitializer, ptr %wf.result
  %t21 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t21
  %t22 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 1
  store i1 %v68, ptr %t22
  %t23 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %wf.slot.2, i64 ptrtoint (ptr getelementptr (%wf.t.20dda3774c7510ec, ptr null, i32 1) to i64), i1 false)
  ret void
}

define i8 @wf_map_cost_library_policy_result$instance$4250cb78d3f44027(ptr %wf.arg.v0, ptr noalias nonnull captures(none) dereferenceable(32) %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.9d321e1eb2ec1c03, align 8
  %wf.slot.1 = alloca %wf.t.20dda3774c7510ec, align 8
  %wf.slot.2 = alloca %wf.t.862971f7a971a883, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v0, i64 ptrtoint (ptr getelementptr (%wf.t.9d321e1eb2ec1c03, ptr null, i32 1) to i64), i1 false)
  %t0 = load %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.9d321e1eb2ec1c03 %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb2
    i32 1, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v3 = phi ptr [ %v1, %bb2 ], [ %v9, %bb4 ]
  %v20 = select i1 true, i8 0, i8 0
  ret i8 %v20
bb2:
  %v4 = select i1 true, i64 0, i64 0
  %v5 = call i8 @wf_map_cost_ordered(ptr %v1, i64 %v4)
  br label %bb1
bb3:
  %t2 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.0, i32 0, i32 1
  %v6 = load i1, ptr %t2
  %t3 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.0, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %t3, i64 ptrtoint (ptr getelementptr (%wf.t.20dda3774c7510ec, ptr null, i32 1) to i64), i1 false)
  switch i1 %v6, label %invalid.tag.b3 [
    i1 0, label %bb5
    i1 1, label %bb6
  ]
invalid.tag.b3:
  call void @abort()
  unreachable
bb4:
  %v9 = phi ptr [ %v1, %bb5 ], [ %v1, %bb6 ]
  %v10 = phi i1 [ %v6, %bb5 ], [ %v6, %bb6 ]
  %t4 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.1, i32 0, i32 0
  %v16 = load i64, ptr %t4
  ; ownership-consuming projection
  %t5 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.1, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %t5, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %v18 = call i64 @wf_map_cost_record_content(i64 %v16, ptr %wf.slot.2)
  %v19 = call i8 @wf_map_cost_ordered(ptr %v9, i64 %v18)
  br label %bb1
bb5:
  %v12 = select i1 true, i64 1, i64 1
  %v13 = call i8 @wf_map_cost_ordered(ptr %v1, i64 %v12)
  br label %bb4
bb6:
  %v14 = select i1 true, i64 2, i64 2
  %v15 = call i8 @wf_map_cost_ordered(ptr %v1, i64 %v14)
  br label %bb4
}

define i8 @wf_hash_map.hash_map_free$instance$72d84b2e6d0b7146(ptr %wf.arg.v0, ptr noalias nonnull captures(none) dereferenceable(32) %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.a5ea622fe32c85b6, align 8
  %wf.slot.1 = alloca %wf.t.b5efdacbe94e5739, align 8
  %wf.slot.2 = alloca %wf.t.e04aead91f34a68f, align 8
  %wf.slot.3 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.4 = alloca { i64, [1 x ptr] }, align 8
  %v3 = alloca ptr, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v0, i64 ptrtoint (ptr getelementptr (%wf.t.a5ea622fe32c85b6, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.a5ea622fe32c85b6, ptr %wf.slot.0, i32 0, i32 0
  %v2 = load ptr, ptr %t0
  ; ownership-consuming projection
  store ptr %v2, ptr %v3
  %t1 = getelementptr inbounds %wf.t.a5ea622fe32c85b6, ptr %wf.slot.0, i32 0, i32 1
  %v4 = load i64, ptr %t1
  ; ownership-consuming projection
  %t2 = getelementptr inbounds %wf.t.a5ea622fe32c85b6, ptr %wf.slot.0, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %t2, i64 ptrtoint (ptr getelementptr (%wf.t.b5efdacbe94e5739, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  br label %bb1
bb1:
  %v7 = phi ptr [ %v1, %entry ], [ %v28, %bb6 ]
  %v8 = phi ptr [ %v3, %entry ], [ %v29, %bb6 ]
  %v9 = phi i64 [ %v4, %entry ], [ %v30, %bb6 ]
  %v16 = getelementptr i8, ptr %v8, i64 0
  %t4 = load ptr, ptr %v16
  %t5 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t4, i32 0, i32 0
  %t3 = load i64, ptr %t5
  %v17 = add i64 %t3, 0
  %v18 = select i1 true, i64 0, i64 0
  %v19 = icmp eq i64 %v17, %v18
  switch i1 %v19, label %invalid.tag.b1 [
    i1 1, label %bb4
    i1 0, label %bb5
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v12 = phi ptr [ %v7, %bb4 ]
  %v13 = phi ptr [ %v8, %bb4 ]
  %v14 = phi i64 [ %v9, %bb4 ]
  %v36 = load ptr, ptr %v13
  %v37 = call i8 @wf_free_empty$instance$1b41cffa653e924b(ptr %v36)
  %v38 = select i1 true, i8 0, i8 0
  %t6 = getelementptr inbounds %wf.t.b5efdacbe94e5739, ptr %wf.slot.1, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.4, ptr %t6, i64 ptrtoint (ptr getelementptr ({ i64, [1 x ptr] }, ptr null, i32 1) to i64), i1 false)
  %t7 = load { i64, [1 x ptr] }, ptr %wf.slot.4
  call void @wf.drop.run.707f874ef98d2803({ i64, [1 x ptr] } %t7)
  ; drop %v39
  ; drop %v15
  ret i8 %v38
bb3:
  %v21 = phi ptr [ %v7, %bb5 ]
  %v22 = phi ptr [ %v8, %bb5 ]
  %v23 = phi i64 [ %v9, %bb5 ]
  %v25 = getelementptr i8, ptr %v22, i64 0
  call void @wf_take_back$instance$2af1311599ac146a(ptr %wf.slot.2, ptr %v25)
  %t8 = load %wf.t.e04aead91f34a68f, ptr %wf.slot.2
  %t9 = extractvalue %wf.t.e04aead91f34a68f %t8, 0
  switch i32 %t9, label %invalid.tag.b3 [
    i32 2, label %bb7
    i32 0, label %bb8
    i32 1, label %bb9
  ]
invalid.tag.b3:
  call void @abort()
  unreachable
bb4:
  br label %bb2
bb5:
  br label %bb3
bb6:
  %v28 = phi ptr [ %v21, %bb7 ], [ %v21, %bb8 ], [ %v21, %bb9 ]
  %v29 = phi ptr [ %v22, %bb7 ], [ %v22, %bb8 ], [ %v22, %bb9 ]
  %v30 = phi i64 [ %v23, %bb7 ], [ %v23, %bb8 ], [ %v23, %bb9 ]
  br label %bb1
bb7:
  %t10 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %wf.slot.2, i32 0, i32 1
  %v33 = load i64, ptr %t10
  %t11 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %wf.slot.2, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.3, ptr %t11, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %v35 = call i8 @wf_map_cost_record_consume(ptr %v21, i64 %v33, ptr %wf.slot.3)
  br label %bb6
bb8:
  br label %bb6
bb9:
  br label %bb6
}

define void @wf_hash_map.hash_map_new$instance$0e108827ecbbe374(ptr %wf.result, i64 %v0) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.b5efdacbe94e5739, align 8
  %v2 = alloca ptr, align 8
  %v1 = call ptr @wf_box_slots_new$instance$b1cfa6e689dc9e10(i64 %v0)
  store ptr %v1, ptr %v2
  %v3 = call i8 @wf_hash_map.hash_map_extend$instance$0e108827ecbbe374(ptr %v2, i64 %v0)
  %v4 = call %wf.t.b5efdacbe94e5739 @wf_hash_map.hash_map_controls_new$instance$fd5e04af5c7e1250(i64 %v0)
  store %wf.t.b5efdacbe94e5739 %v4, ptr %wf.slot.0
  %v5 = load ptr, ptr %v2
  %v6 = select i1 true, i64 0, i64 0
  store %wf.t.05623e8a192b9069 zeroinitializer, ptr %wf.result
  %t0 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %wf.result, i32 0, i32 0
  store ptr %v5, ptr %t0
  %t1 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %wf.result, i32 0, i32 1
  store i64 %v6, ptr %t1
  %t2 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t2, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.b5efdacbe94e5739, ptr null, i32 1) to i64), i1 false)
  ret void
}

define void @wf_hash_map.hash_map_put$instance$28da32efc51c2b65(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr %wf.arg.v2, ptr noalias nonnull captures(none) dereferenceable(16) %v3) #0 {
entry:
  %wf.frame = alloca { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.7d7f918f7b4962fd, %wf.t.862971f7a971a883 }, align 8
  %wf.slot.0 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.7d7f918f7b4962fd, %wf.t.862971f7a971a883 }, ptr %wf.frame, i32 0, i32 0
  %wf.slot.1 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.7d7f918f7b4962fd, %wf.t.862971f7a971a883 }, ptr %wf.frame, i32 0, i32 1
  %wf.slot.2 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.7d7f918f7b4962fd, %wf.t.862971f7a971a883 }, ptr %wf.frame, i32 0, i32 2
  %wf.slot.3 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.7d7f918f7b4962fd, %wf.t.862971f7a971a883 }, ptr %wf.frame, i32 0, i32 3
  %wf.slot.4 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.9d321e1eb2ec1c03, %wf.t.20dda3774c7510ec, %wf.t.7d7f918f7b4962fd, %wf.t.862971f7a971a883 }, ptr %wf.frame, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v2, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  call void @wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65(ptr %wf.slot.1, ptr %v0, i64 %v1, ptr %wf.slot.0, ptr %v3)
  %t0 = load %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.1
  %t1 = extractvalue %wf.t.9d321e1eb2ec1c03 %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb1
    i32 1, label %bb2
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  store %wf.t.9d321e1eb2ec1c03 zeroinitializer, ptr %wf.result
  %t2 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t2
  ret void
bb2:
  %t3 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.1, i32 0, i32 1
  %v6 = load i1, ptr %t3
  %t4 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.1, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %t4, i64 ptrtoint (ptr getelementptr (%wf.t.20dda3774c7510ec, ptr null, i32 1) to i64), i1 false)
  switch i1 %v6, label %invalid.tag.b2 [
    i1 0, label %bb3
    i1 1, label %bb4
  ]
invalid.tag.b2:
  call void @abort()
  unreachable
bb3:
  %v8 = or i1 0, 0
  store %wf.t.9d321e1eb2ec1c03 zeroinitializer, ptr %wf.result
  %t5 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t5
  %t6 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 1
  store i1 %v8, ptr %t6
  %t7 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t7, ptr %wf.slot.2, i64 ptrtoint (ptr getelementptr (%wf.t.20dda3774c7510ec, ptr null, i32 1) to i64), i1 false)
  ret void
bb4:
  %t8 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v0, i32 0, i32 0
  %v10 = getelementptr i8, ptr %t8, i64 0
  %v11 = getelementptr i8, ptr %v10, i64 0
  %t10 = load ptr, ptr %v11
  %t11 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t10, i32 0, i32 0
  %t9 = load i64, ptr %t11
  %v12 = add i64 %t9, 0
  %v13 = select i1 true, i64 16384, i64 16384
  %v14 = icmp uge i64 %v12, %v13
  switch i1 %v14, label %invalid.tag.b4 [
    i1 1, label %bb6
    i1 0, label %bb7
  ]
invalid.tag.b4:
  call void @abort()
  unreachable
bb5:
  %v15 = phi ptr [ %v0, %bb7 ]
  %v16 = phi i64 [ %v1, %bb7 ]
  %v18 = phi ptr [ %v3, %bb7 ]
  %v20 = phi i1 [ %v6, %bb7 ]
  %v22 = phi i64 [ %v12, %bb7 ]
  %v25 = select i1 true, i64 16384, i64 16384
  %v26 = select i1 true, i64 0, i64 0
  %v27 = icmp eq i64 %v22, %v26
  switch i1 %v27, label %invalid.tag.b5 [
    i1 1, label %bb9
    i1 0, label %bb10
  ]
invalid.tag.b5:
  call void @abort()
  unreachable
bb6:
  %v23 = or i1 0, 1
  store %wf.t.9d321e1eb2ec1c03 zeroinitializer, ptr %wf.result
  %t12 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t12
  %t13 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 1
  store i1 %v23, ptr %t13
  %t14 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %wf.slot.2, i64 ptrtoint (ptr getelementptr (%wf.t.20dda3774c7510ec, ptr null, i32 1) to i64), i1 false)
  ret void
bb7:
  br label %bb5
bb8:
  %v28 = phi ptr [ %v15, %bb9 ], [ %v40, %bb11 ]
  %v29 = phi i64 [ %v16, %bb9 ], [ %v41, %bb11 ]
  %v31 = phi ptr [ %v18, %bb9 ], [ %v43, %bb11 ]
  %v33 = phi i1 [ %v20, %bb9 ], [ %v45, %bb11 ]
  %v35 = phi i64 [ %v22, %bb9 ], [ %v47, %bb11 ]
  %v36 = phi i64 [ %v37, %bb9 ], [ %v48, %bb11 ]
  %v62 = call %wf.t.7d7f918f7b4962fd @wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65(ptr %v28, i64 %v36, ptr %v31)
  store %wf.t.7d7f918f7b4962fd %v62, ptr %wf.slot.3
  %t15 = load %wf.t.7d7f918f7b4962fd, ptr %wf.slot.3
  %t16 = extractvalue %wf.t.7d7f918f7b4962fd %t15, 0
  switch i32 %t16, label %invalid.tag.b8 [
    i32 0, label %bb17
    i32 1, label %bb18
  ]
invalid.tag.b8:
  call void @abort()
  unreachable
bb9:
  %v37 = select i1 true, i64 1, i64 1
  br label %bb8
bb10:
  %v38 = select i1 true, i64 9223372036854775807, i64 9223372036854775807
  %v39 = icmp ule i64 %v22, %v38
  switch i1 %v39, label %invalid.tag.b10 [
    i1 1, label %bb12
    i1 0, label %bb13
  ]
invalid.tag.b10:
  call void @abort()
  unreachable
bb11:
  %v40 = phi ptr [ %v15, %bb13 ], [ %v52, %bb14 ]
  %v41 = phi i64 [ %v16, %bb13 ], [ %v53, %bb14 ]
  %v43 = phi ptr [ %v18, %bb13 ], [ %v55, %bb14 ]
  %v45 = phi i1 [ %v20, %bb13 ], [ %v57, %bb14 ]
  %v47 = phi i64 [ %v22, %bb13 ], [ %v59, %bb14 ]
  %v48 = phi i64 [ %v25, %bb13 ], [ %v60, %bb14 ]
  br label %bb8
bb12:
  %v49 = add nuw i64 %v22, %v22
  %v50 = select i1 true, i64 16384, i64 16384
  %v51 = icmp ule i64 %v49, %v50
  switch i1 %v51, label %invalid.tag.b12 [
    i1 1, label %bb15
    i1 0, label %bb16
  ]
invalid.tag.b12:
  call void @abort()
  unreachable
bb13:
  br label %bb11
bb14:
  %v52 = phi ptr [ %v15, %bb15 ], [ %v15, %bb16 ]
  %v53 = phi i64 [ %v16, %bb15 ], [ %v16, %bb16 ]
  %v55 = phi ptr [ %v18, %bb15 ], [ %v18, %bb16 ]
  %v57 = phi i1 [ %v20, %bb15 ], [ %v20, %bb16 ]
  %v59 = phi i64 [ %v22, %bb15 ], [ %v22, %bb16 ]
  %v60 = phi i64 [ %v49, %bb15 ], [ %v25, %bb16 ]
  %v61 = phi i64 [ %v49, %bb15 ], [ %v49, %bb16 ]
  br label %bb11
bb15:
  br label %bb14
bb16:
  br label %bb14
bb17:
  %t17 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.slot.3, i32 0, i32 1
  %v63 = load i8, ptr %t17
  %t18 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.2, i32 0, i32 0
  %v64 = load i64, ptr %t18
  ; ownership-consuming projection
  %t19 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.2, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.4, ptr %t19, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  call void @wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65(ptr %wf.result, ptr %v28, i64 %v64, ptr %wf.slot.4, ptr %v31)
  ret void
bb18:
  %t20 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.slot.3, i32 0, i32 2
  %v67 = load i8, ptr %t20
  %v68 = or i1 0, 1
  store %wf.t.9d321e1eb2ec1c03 zeroinitializer, ptr %wf.result
  %t21 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t21
  %t22 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 1
  store i1 %v68, ptr %t22
  %t23 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %wf.slot.2, i64 ptrtoint (ptr getelementptr (%wf.t.20dda3774c7510ec, ptr null, i32 1) to i64), i1 false)
  ret void
}

define void @wf_hash_map.hash_map_remove$instance$28da32efc51c2b65(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.05623e8a192b9069, align 8
  %wf.slot.1 = alloca %wf.t.b7e1ed626c09888a, align 8
  %wf.slot.2 = alloca %wf.t.e04aead91f34a68f, align 8
  %wf.slot.3 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.4 = alloca %wf.t.20dda3774c7510ec, align 8
  %v15 = alloca %wf.t.e04aead91f34a68f, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.05623e8a192b9069, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %wf.slot.0, i32 0, i32 1
  %v4 = load i64, ptr %t0
  %v5 = select i1 true, i64 0, i64 0
  %v6 = icmp eq i64 %v4, %v5
  switch i1 %v6, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v7 = phi ptr [ %v0, %bb3 ]
  %v8 = phi ptr [ %v1, %bb3 ]
  %v9 = phi ptr [ %v2, %bb3 ]
  %v10 = phi i64 [ %v4, %bb3 ]
  %v12 = call %wf.t.b7e1ed626c09888a @wf_hash_map.hash_map_find$instance$28da32efc51c2b65(ptr %v7, ptr %v8, ptr %v9)
  store %wf.t.b7e1ed626c09888a %v12, ptr %wf.slot.1
  %t1 = load %wf.t.b7e1ed626c09888a, ptr %wf.slot.1
  %t2 = extractvalue %wf.t.b7e1ed626c09888a %t1, 0
  switch i32 %t2, label %invalid.tag.b1 [
    i32 0, label %bb4
    i32 1, label %bb5
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  store %wf.t.e020a813ecac56e1 zeroinitializer, ptr %wf.result
  %t3 = getelementptr inbounds %wf.t.e020a813ecac56e1, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t3
  ret void
bb3:
  br label %bb1
bb4:
  %t4 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.slot.1, i32 0, i32 1
  %v13 = load i64, ptr %t4
  store %wf.t.e04aead91f34a68f zeroinitializer, ptr %v15
  %t5 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %v15, i32 0, i32 0
  store i32 1, ptr %t5
  %t6 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v7, i32 0, i32 0
  %v16 = getelementptr i8, ptr %t6, i64 0
  %v17 = getelementptr i8, ptr %v16, i64 0
  %t7 = load ptr, ptr %v17
  %t8.nonnegative = icmp sge i64 %v13, 0
  call void @llvm.assume(i1 %t8.nonnegative)
  %t8 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t7, i64 0, i32 2, i64 %v13
  %v18 = getelementptr i8, ptr %t8, i64 0
  %v19 = call i8 @wf_swap$instance$b1cfa6e689dc9e10(ptr %v18, ptr %v15)
  %t9 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v7, i32 0, i32 2
  %v20 = getelementptr i8, ptr %t9, i64 0
  %v21 = select i1 true, i64 254, i64 254
  %v22 = call i8 @wf_hash_map.hash_map_control_set(ptr %v20, i64 %v13, i64 %v21)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %v15, i64 ptrtoint (ptr getelementptr (%wf.t.e04aead91f34a68f, ptr null, i32 1) to i64), i1 false)
  %t10 = load %wf.t.e04aead91f34a68f, ptr %wf.slot.2
  %t11 = extractvalue %wf.t.e04aead91f34a68f %t10, 0
  switch i32 %t11, label %invalid.tag.b4 [
    i32 2, label %bb6
    i32 0, label %bb7
    i32 1, label %bb8
  ]
invalid.tag.b4:
  call void @abort()
  unreachable
bb5:
  %t12 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.slot.1, i32 0, i32 2
  %v33 = load i8, ptr %t12
  store %wf.t.e020a813ecac56e1 zeroinitializer, ptr %wf.result
  %t13 = getelementptr inbounds %wf.t.e020a813ecac56e1, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t13
  ret void
bb6:
  %t14 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %wf.slot.2, i32 0, i32 1
  %v24 = load i64, ptr %t14
  %t15 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %wf.slot.2, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.3, ptr %t15, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %t16 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v7, i32 0, i32 1
  %v26 = getelementptr i8, ptr %t16, i64 0
  %v27 = select i1 true, i64 1, i64 1
  %v28 = sub nuw i64 %v10, %v27
  store i64 %v28, ptr %v26
  store %wf.t.20dda3774c7510ec zeroinitializer, ptr %wf.slot.4
  %t17 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.4, i32 0, i32 0
  store i64 %v24, ptr %t17
  %t18 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.4, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %wf.slot.3, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  store %wf.t.e020a813ecac56e1 zeroinitializer, ptr %wf.result
  %t19 = getelementptr inbounds %wf.t.e020a813ecac56e1, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t19
  %t20 = getelementptr inbounds %wf.t.e020a813ecac56e1, ptr %wf.result, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t20, ptr %wf.slot.4, i64 ptrtoint (ptr getelementptr (%wf.t.20dda3774c7510ec, ptr null, i32 1) to i64), i1 false)
  ret void
bb7:
  store %wf.t.e020a813ecac56e1 zeroinitializer, ptr %wf.result
  %t21 = getelementptr inbounds %wf.t.e020a813ecac56e1, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t21
  ret void
bb8:
  store %wf.t.e020a813ecac56e1 zeroinitializer, ptr %wf.result
  %t22 = getelementptr inbounds %wf.t.e020a813ecac56e1, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t22
  ret void
}

define internal void @wf_hash_map.hash_map_lookup$instance$000400fb603e42fe.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2, ptr noalias nonnull captures(none) dereferenceable(32) %v3) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.b7e1ed626c09888a, align 8
  %wf.slot.1 = alloca %wf.t.e04aead91f34a68f, align 8
  %v4 = call %wf.t.b7e1ed626c09888a @wf_hash_map.hash_map_find$instance$28da32efc51c2b65(ptr %v0, ptr %v1, ptr %v2)
  store %wf.t.b7e1ed626c09888a %v4, ptr %wf.slot.0
  %t0 = load %wf.t.b7e1ed626c09888a, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.b7e1ed626c09888a %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb1
    i32 1, label %bb2
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %t2 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.slot.0, i32 0, i32 1
  %v5 = load i64, ptr %t2
  %t3 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v0, i32 0, i32 0
  %v6 = getelementptr i8, ptr %t3, i64 0
  %v7 = getelementptr i8, ptr %v6, i64 0
  %t4 = load ptr, ptr %v7
  %t5.nonnegative = icmp sge i64 %v5, 0
  call void @llvm.assume(i1 %t5.nonnegative)
  %t5 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t4, i64 0, i32 2, i64 %v5
  %v8 = getelementptr i8, ptr %t5, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v8, i64 ptrtoint (ptr getelementptr (%wf.t.e04aead91f34a68f, ptr null, i32 1) to i64), i1 false)
  %t6 = load %wf.t.e04aead91f34a68f, ptr %wf.slot.1
  %t7 = extractvalue %wf.t.e04aead91f34a68f %t6, 0
  switch i32 %t7, label %invalid.tag.b1 [
    i32 2, label %bb3
    i32 0, label %bb4
    i32 1, label %bb5
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %t8 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.slot.0, i32 0, i32 2
  %v18 = load i8, ptr %t8
  %v19 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t9 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t9
  %t10 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v19, ptr %t10
  ret void
bb3:
  %t11 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %v8, i32 0, i32 1
  %v10 = getelementptr i8, ptr %t11, i64 0
  %t12 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %v8, i32 0, i32 2
  %v11 = getelementptr i8, ptr %t12, i64 0
  %v12 = call i64 @wf_map_cost_record_observe(ptr %v3, ptr %v10, ptr %v11)
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t13 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t13
  %t14 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 1
  store i64 %v12, ptr %t14
  ret void
bb4:
  %v14 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t15 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t15
  %t16 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v14, ptr %t16
  ret void
bb5:
  %v16 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t17 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t17
  %t18 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v16, ptr %t18
  ret void
}

define %wf.t.b7e1ed626c09888a @wf_hash_map.hash_map_lookup$instance$000400fb603e42fe(ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2, ptr noalias nonnull captures(none) dereferenceable(32) %v3) #0 {
entry:
  %wf.result = alloca %wf.t.b7e1ed626c09888a, align 8
  call void @wf_hash_map.hash_map_lookup$instance$000400fb603e42fe.body(ptr %wf.result, ptr %v0, ptr %v1, ptr %v2, ptr %v3)
  %wf.returned = load %wf.t.b7e1ed626c09888a, ptr %wf.result
  ret %wf.t.b7e1ed626c09888a %wf.returned
}

define internal void @wf_hash_map.hash_map_rehash$instance$28da32efc51c2b65.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(16) %v1) #0 {
entry:
  %t0 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v0, i32 0, i32 0
  %v2 = getelementptr i8, ptr %t0, i64 0
  %v3 = getelementptr i8, ptr %v2, i64 0
  %t2 = load ptr, ptr %v3
  %t3 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t2, i32 0, i32 0
  %t1 = load i64, ptr %t3
  %v4 = add i64 %t1, 0
  %v5 = call %wf.t.7d7f918f7b4962fd @wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65(ptr %v0, i64 %v4, ptr %v1)
  store %wf.t.7d7f918f7b4962fd %v5, ptr %wf.result
  ret void
}

define %wf.t.7d7f918f7b4962fd @wf_hash_map.hash_map_rehash$instance$28da32efc51c2b65(ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(16) %v1) #0 {
entry:
  %wf.result = alloca %wf.t.7d7f918f7b4962fd, align 4
  call void @wf_hash_map.hash_map_rehash$instance$28da32efc51c2b65.body(ptr %wf.result, ptr %v0, ptr %v1)
  %wf.returned = load %wf.t.7d7f918f7b4962fd, ptr %wf.result
  ret %wf.t.7d7f918f7b4962fd %wf.returned
}

define internal void @wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %v3 = select i1 true, i64 16384, i64 16384
  %v4 = icmp ugt i64 %v1, %v3
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v5 = phi ptr [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb3 ]
  %v7 = phi ptr [ %v2, %bb3 ]
  %t0 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v5, i32 0, i32 0
  %v10 = getelementptr i8, ptr %t0, i64 0
  %v11 = getelementptr i8, ptr %v10, i64 0
  %t2 = load ptr, ptr %v11
  %t3 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t2, i32 0, i32 0
  %t1 = load i64, ptr %t3
  %v12 = add i64 %t1, 0
  %v13 = icmp ule i64 %v6, %v12
  switch i1 %v13, label %invalid.tag.b1 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v8 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t4 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t4
  %t5 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 2
  store i8 %v8, ptr %t5
  ret void
bb3:
  br label %bb1
bb4:
  %v14 = phi ptr [ %v5, %bb6 ]
  %v15 = phi i64 [ %v6, %bb6 ]
  %v16 = phi ptr [ %v7, %bb6 ]
  %v19 = call %wf.t.7d7f918f7b4962fd @wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65(ptr %v14, i64 %v15, ptr %v16)
  store %wf.t.7d7f918f7b4962fd %v19, ptr %wf.result
  ret void
bb5:
  %v17 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t6 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t6
  %t7 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 1
  store i8 %v17, ptr %t7
  ret void
bb6:
  br label %bb4
}

define %wf.t.7d7f918f7b4962fd @wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65(ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.result = alloca %wf.t.7d7f918f7b4962fd, align 4
  call void @wf_hash_map.hash_map_reserve$instance$28da32efc51c2b65.body(ptr %wf.result, ptr %v0, i64 %v1, ptr %v2)
  %wf.returned = load %wf.t.7d7f918f7b4962fd, ptr %wf.result
  ret %wf.t.7d7f918f7b4962fd %wf.returned
}

define i64 @wf_hash_map.hash_map_capacity$instance$0e108827ecbbe374(ptr noalias nonnull captures(none) dereferenceable(40) %v0) #0 {
entry:
  %t0 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v0, i32 0, i32 0
  %v1 = getelementptr i8, ptr %t0, i64 0
  %v2 = getelementptr i8, ptr %v1, i64 0
  %t2 = load ptr, ptr %v2
  %t3 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t2, i32 0, i32 0
  %t1 = load i64, ptr %t3
  %v3 = add i64 %t1, 0
  ret i64 %v3
}

define internal void @wf_hash_map.hash_map_edit$instance$ec3fd08e444cbe49.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2, ptr noalias nonnull captures(none) dereferenceable(32) %v3) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.b7e1ed626c09888a, align 8
  %wf.slot.1 = alloca %wf.t.e04aead91f34a68f, align 8
  %v4 = call %wf.t.b7e1ed626c09888a @wf_hash_map.hash_map_find$instance$28da32efc51c2b65(ptr %v0, ptr %v1, ptr %v2)
  store %wf.t.b7e1ed626c09888a %v4, ptr %wf.slot.0
  %t0 = load %wf.t.b7e1ed626c09888a, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.b7e1ed626c09888a %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb1
    i32 1, label %bb2
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %t2 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.slot.0, i32 0, i32 1
  %v5 = load i64, ptr %t2
  %t3 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v0, i32 0, i32 0
  %v6 = getelementptr i8, ptr %t3, i64 0
  %v7 = getelementptr i8, ptr %v6, i64 0
  %t4 = load ptr, ptr %v7
  %t5.nonnegative = icmp sge i64 %v5, 0
  call void @llvm.assume(i1 %t5.nonnegative)
  %t5 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t4, i64 0, i32 2, i64 %v5
  %v8 = getelementptr i8, ptr %t5, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v8, i64 ptrtoint (ptr getelementptr (%wf.t.e04aead91f34a68f, ptr null, i32 1) to i64), i1 false)
  %t6 = load %wf.t.e04aead91f34a68f, ptr %wf.slot.1
  %t7 = extractvalue %wf.t.e04aead91f34a68f %t6, 0
  switch i32 %t7, label %invalid.tag.b1 [
    i32 2, label %bb3
    i32 0, label %bb4
    i32 1, label %bb5
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %t8 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.slot.0, i32 0, i32 2
  %v18 = load i8, ptr %t8
  %v19 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t9 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t9
  %t10 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v19, ptr %t10
  ret void
bb3:
  %t11 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %v8, i32 0, i32 1
  %v10 = getelementptr i8, ptr %t11, i64 0
  %t12 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %v8, i32 0, i32 2
  %v11 = getelementptr i8, ptr %t12, i64 0
  %v12 = call i64 @wf_map_cost_record_edit(ptr %v3, ptr %v10, ptr %v11)
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t13 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t13
  %t14 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 1
  store i64 %v12, ptr %t14
  ret void
bb4:
  %v14 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t15 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t15
  %t16 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v14, ptr %t16
  ret void
bb5:
  %v16 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t17 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t17
  %t18 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v16, ptr %t18
  ret void
}

define %wf.t.b7e1ed626c09888a @wf_hash_map.hash_map_edit$instance$ec3fd08e444cbe49(ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2, ptr noalias nonnull captures(none) dereferenceable(32) %v3) #0 {
entry:
  %wf.result = alloca %wf.t.b7e1ed626c09888a, align 8
  call void @wf_hash_map.hash_map_edit$instance$ec3fd08e444cbe49.body(ptr %wf.result, ptr %v0, ptr %v1, ptr %v2, ptr %v3)
  %wf.returned = load %wf.t.b7e1ed626c09888a, ptr %wf.result
  ret %wf.t.b7e1ed626c09888a %wf.returned
}

define i8 @wf_hash_map.hash_map_free$instance$d5f8785ab7665d71(ptr %wf.arg.v0, ptr noalias nonnull captures(none) dereferenceable(32) %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.05623e8a192b9069, align 8
  %wf.slot.1 = alloca %wf.t.b5efdacbe94e5739, align 8
  %wf.slot.2 = alloca %wf.t.e04aead91f34a68f, align 8
  %wf.slot.3 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.4 = alloca { i64, [1 x ptr] }, align 8
  %v3 = alloca ptr, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v0, i64 ptrtoint (ptr getelementptr (%wf.t.05623e8a192b9069, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %wf.slot.0, i32 0, i32 0
  %v2 = load ptr, ptr %t0
  ; ownership-consuming projection
  store ptr %v2, ptr %v3
  %t1 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %wf.slot.0, i32 0, i32 1
  %v4 = load i64, ptr %t1
  ; ownership-consuming projection
  %t2 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %wf.slot.0, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %t2, i64 ptrtoint (ptr getelementptr (%wf.t.b5efdacbe94e5739, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  br label %bb1
bb1:
  %v7 = phi ptr [ %v1, %entry ], [ %v28, %bb6 ]
  %v8 = phi ptr [ %v3, %entry ], [ %v29, %bb6 ]
  %v9 = phi i64 [ %v4, %entry ], [ %v30, %bb6 ]
  %v16 = getelementptr i8, ptr %v8, i64 0
  %t4 = load ptr, ptr %v16
  %t5 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t4, i32 0, i32 0
  %t3 = load i64, ptr %t5
  %v17 = add i64 %t3, 0
  %v18 = select i1 true, i64 0, i64 0
  %v19 = icmp eq i64 %v17, %v18
  switch i1 %v19, label %invalid.tag.b1 [
    i1 1, label %bb4
    i1 0, label %bb5
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v12 = phi ptr [ %v7, %bb4 ]
  %v13 = phi ptr [ %v8, %bb4 ]
  %v14 = phi i64 [ %v9, %bb4 ]
  %v36 = load ptr, ptr %v13
  %v37 = call i8 @wf_free_empty$instance$1b41cffa653e924b(ptr %v36)
  %v38 = select i1 true, i8 0, i8 0
  %t6 = getelementptr inbounds %wf.t.b5efdacbe94e5739, ptr %wf.slot.1, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.4, ptr %t6, i64 ptrtoint (ptr getelementptr ({ i64, [1 x ptr] }, ptr null, i32 1) to i64), i1 false)
  %t7 = load { i64, [1 x ptr] }, ptr %wf.slot.4
  call void @wf.drop.run.707f874ef98d2803({ i64, [1 x ptr] } %t7)
  ; drop %v39
  ; drop %v15
  ret i8 %v38
bb3:
  %v21 = phi ptr [ %v7, %bb5 ]
  %v22 = phi ptr [ %v8, %bb5 ]
  %v23 = phi i64 [ %v9, %bb5 ]
  %v25 = getelementptr i8, ptr %v22, i64 0
  call void @wf_take_back$instance$2af1311599ac146a(ptr %wf.slot.2, ptr %v25)
  %t8 = load %wf.t.e04aead91f34a68f, ptr %wf.slot.2
  %t9 = extractvalue %wf.t.e04aead91f34a68f %t8, 0
  switch i32 %t9, label %invalid.tag.b3 [
    i32 2, label %bb7
    i32 0, label %bb8
    i32 1, label %bb9
  ]
invalid.tag.b3:
  call void @abort()
  unreachable
bb4:
  br label %bb2
bb5:
  br label %bb3
bb6:
  %v28 = phi ptr [ %v21, %bb7 ], [ %v21, %bb8 ], [ %v21, %bb9 ]
  %v29 = phi ptr [ %v22, %bb7 ], [ %v22, %bb8 ], [ %v22, %bb9 ]
  %v30 = phi i64 [ %v23, %bb7 ], [ %v23, %bb8 ], [ %v23, %bb9 ]
  br label %bb1
bb7:
  %t10 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %wf.slot.2, i32 0, i32 1
  %v33 = load i64, ptr %t10
  %t11 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %wf.slot.2, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.3, ptr %t11, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %v35 = call i8 @wf_map_cost_record_consume(ptr %v21, i64 %v33, ptr %wf.slot.3)
  br label %bb6
bb8:
  br label %bb6
bb9:
  br label %bb6
}

define i64 @wf_hash_map.hash_map_len$instance$820b2044b97e0fbd(ptr noalias nonnull captures(none) dereferenceable(40) %v0) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.7748a5b0f0193f4a, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.7748a5b0f0193f4a, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %wf.slot.0, i32 0, i32 1
  %v2 = load i64, ptr %t0
  ret i64 %v2
}

define i64 @wf_hash_map.hash_map_len$instance$0e108827ecbbe374(ptr noalias nonnull captures(none) dereferenceable(40) %v0) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.05623e8a192b9069, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.05623e8a192b9069, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %wf.slot.0, i32 0, i32 1
  %v2 = load i64, ptr %t0
  ret i64 %v2
}

define ptr @wf_box_slots_new$instance$087f541e70b769ea(i64 %v0) #0 {
entry:
  %t0 = mul nuw i64 %v0, ptrtoint (ptr getelementptr (%wf.t.eb423fc38cfed56f, ptr null, i64 1) to i64)
  %t1 = add nuw i64 %t0, ptrtoint (ptr getelementptr ({ i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr null, i64 0, i32 2) to i64)
  %v1 = call ptr @malloc(i64 %t1)
  %t2 = icmp ne ptr %v1, null
  br i1 %t2, label %window.block.ready.v1, label %window.block.oom.v1
window.block.oom.v1:
  call void @wf_resource_abort()
  unreachable
window.block.ready.v1:
  %t3 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %v1, i32 0, i32 0
  store i64 0, ptr %t3
  %t4 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %v1, i32 0, i32 1
  store i64 %v0, ptr %t4
  ret ptr %v1
}

define i8 @wf_hash_map.hash_map_extend$instance$a62a753cf2b0b5ca(ptr noalias nonnull captures(none) dereferenceable(8) %v0, i64 %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.eb423fc38cfed56f, align 8
  %v2 = getelementptr i8, ptr %v0, i64 0
  %t1 = load ptr, ptr %v2
  %t2 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t1, i32 0, i32 1
  %t0 = load i64, ptr %t2
  %v3 = add i64 %t0, 0
  %v4 = icmp ult i64 %v3, %v1
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v5 = phi ptr [ %v0, %bb2 ], [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb2 ], [ %v1, %bb3 ]
  %v8 = getelementptr i8, ptr %v5, i64 0
  %t4 = load ptr, ptr %v8
  %t5 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t4, i32 0, i32 0
  %t3 = load i64, ptr %t5
  %v9 = add i64 %t3, 0
  br label %bb4
bb2:
  %v7 = call i8 @wf_grow$instance$087f541e70b769ea(ptr %v0, i64 %v1)
  br label %bb1
bb3:
  br label %bb1
bb4:
  %v10 = phi ptr [ %v5, %bb1 ], [ %v23, %bb8 ]
  %v11 = phi i64 [ %v6, %bb1 ], [ %v24, %bb8 ]
  %v12 = phi i64 [ %v9, %bb1 ], [ %v25, %bb8 ]
  %v13 = phi i64 [ %v9, %bb1 ], [ %v26, %bb8 ]
  %v14 = phi i64 [ %v6, %bb1 ], [ %v27, %bb8 ]
  %v15 = phi i64 [ %v9, %bb1 ], [ %v30, %bb8 ]
  %v19 = icmp ult i64 %v15, %v14
  switch i1 %v19, label %invalid.tag.b4 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b4:
  call void @abort()
  unreachable
bb5:
  store %wf.t.eb423fc38cfed56f zeroinitializer, ptr %wf.slot.0
  %t6 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %wf.slot.0, i32 0, i32 0
  store i32 0, ptr %t6
  %v21 = getelementptr i8, ptr %v10, i64 0
  %v22 = call i8 @wf_place_back$instance$20364da1adbcdc5f(ptr %v21, ptr %wf.slot.0)
  br label %bb8
bb6:
  br label %bb7
bb7:
  %v16 = phi ptr [ %v10, %bb6 ]
  %v17 = phi i64 [ %v11, %bb6 ]
  %v18 = phi i64 [ %v12, %bb6 ]
  %v31 = select i1 true, i8 0, i8 0
  ret i8 %v31
bb8:
  %v23 = phi ptr [ %v10, %bb5 ]
  %v24 = phi i64 [ %v11, %bb5 ]
  %v25 = phi i64 [ %v12, %bb5 ]
  %v26 = phi i64 [ %v13, %bb5 ]
  %v27 = phi i64 [ %v14, %bb5 ]
  %v28 = phi i64 [ %v15, %bb5 ]
  %v29 = select i1 true, i64 1, i64 1
  %v30 = add i64 %v28, %v29
  br label %bb4
}

define internal void @wf_hash_map.hash_map_controls_new$instance$c559014c068e16a3.body(ptr %wf.result, i64 %v0) #0 {
entry:
  %wf.slot.0 = alloca { i64, [1 x ptr] }, align 8
  %v3 = alloca { i64, [1 x ptr] }, align 8
  %v1 = select i1 true, i64 9259542123273814144, i64 9259542123273814144
  %v2 = call { i64, [1 x ptr] } @wf_slots_new$instance$bc7a70143afe699c()
  store { i64, [1 x ptr] } %v2, ptr %v3
  %v4 = select i1 true, i64 8, i64 8
  %v5 = icmp ugt i64 %v0, %v4
  switch i1 %v5, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v6 = phi i64 [ %v0, %bb2 ], [ %v0, %bb3 ]
  %v7 = phi i64 [ %v1, %bb2 ], [ %v1, %bb3 ]
  %v8 = phi ptr [ %v3, %bb2 ], [ %v3, %bb3 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v8, i64 ptrtoint (ptr getelementptr ({ i64, [1 x ptr] }, ptr null, i32 1) to i64), i1 false)
  store %wf.t.b5efdacbe94e5739 zeroinitializer, ptr %wf.result
  %t0 = getelementptr inbounds %wf.t.b5efdacbe94e5739, ptr %wf.result, i32 0, i32 0
  store i64 %v7, ptr %t0
  %t1 = getelementptr inbounds %wf.t.b5efdacbe94e5739, ptr %wf.result, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr ({ i64, [1 x ptr] }, ptr null, i32 1) to i64), i1 false)
  ret void
bb2:
  %v9 = select i1 true, i64 8, i64 8
  %v10 = udiv i64 %v0, %v9
  %v11 = call ptr @wf_box_array_filled$instance$e194368921a477a7(i64 %v10, i64 %v1)
  %v12 = call i8 @wf_place_back$instance$38dd27730d5cd43b(ptr %v3, ptr %v11)
  br label %bb1
bb3:
  br label %bb1
}

define %wf.t.b5efdacbe94e5739 @wf_hash_map.hash_map_controls_new$instance$c559014c068e16a3(i64 %v0) #0 {
entry:
  %wf.result = alloca %wf.t.b5efdacbe94e5739, align 8
  call void @wf_hash_map.hash_map_controls_new$instance$c559014c068e16a3.body(ptr %wf.result, i64 %v0)
  %wf.returned = load %wf.t.b5efdacbe94e5739, ptr %wf.result
  ret %wf.t.b5efdacbe94e5739 %wf.returned
}

define void @wf_hash_map.hash_map_try_put$instance$c7b22b9ef52855b6(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, i64 %v2, ptr noalias nonnull captures(none) dereferenceable(16) %v3) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.2758c7c2b3b908fb, align 8
  %wf.slot.1 = alloca %wf.t.09071440a409e980, align 8
  %v4 = alloca i64, align 8
  %v568 = alloca %wf.t.ac5891a387b8aafe, align 8
  store i64 %v1, ptr %v4
  %v5 = call i64 @wf_map_cost_hash(ptr %v3, ptr %v4)
  %v6 = call i64 @wf_hash_map.hash_map_control_fingerprint(i64 %v5)
  %t0 = getelementptr inbounds %wf.t.2758c7c2b3b908fb, ptr %v0, i32 0, i32 0
  %v7 = getelementptr i8, ptr %t0, i64 0
  %v8 = getelementptr i8, ptr %v7, i64 0
  %t2 = load ptr, ptr %v8
  %t3 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t2, i32 0, i32 0
  %t1 = load i64, ptr %t3
  %v9 = add i64 %t1, 0
  %v10 = select i1 true, i64 0, i64 0
  %v11 = icmp ugt i64 %v9, %v10
  switch i1 %v11, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v12 = phi ptr [ %v0, %bb3 ], [ %v35, %bb7 ]
  %v13 = phi ptr [ %v4, %bb3 ], [ %v36, %bb7 ]
  %v14 = phi i64 [ %v2, %bb3 ], [ %v37, %bb7 ]
  %v15 = phi ptr [ %v3, %bb3 ], [ %v38, %bb7 ]
  %v16 = phi i64 [ %v5, %bb3 ], [ %v39, %bb7 ]
  %v17 = phi i64 [ %v6, %bb3 ], [ %v40, %bb7 ]
  %v18 = phi i64 [ %v9, %bb3 ], [ %v41, %bb7 ]
  %v19 = phi i64 [ %v9, %bb3 ], [ %v42, %bb7 ]
  %v543 = icmp ult i64 %v19, %v18
  switch i1 %v543, label %invalid.tag.b1 [
    i1 1, label %bb56
    i1 0, label %bb57
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v20 = urem i64 %v5, %v9
  %v21 = select i1 true, i64 0, i64 0
  br label %bb4
bb3:
  br label %bb1
bb4:
  %v22 = phi ptr [ %v0, %bb2 ], [ %v528, %bb54 ]
  %v23 = phi ptr [ %v4, %bb2 ], [ %v529, %bb54 ]
  %v24 = phi i64 [ %v2, %bb2 ], [ %v530, %bb54 ]
  %v25 = phi ptr [ %v3, %bb2 ], [ %v531, %bb54 ]
  %v26 = phi i64 [ %v5, %bb2 ], [ %v532, %bb54 ]
  %v27 = phi i64 [ %v6, %bb2 ], [ %v533, %bb54 ]
  %v28 = phi i64 [ %v9, %bb2 ], [ %v534, %bb54 ]
  %v29 = phi i64 [ %v9, %bb2 ], [ %v535, %bb54 ]
  %v30 = phi i64 [ %v20, %bb2 ], [ %v536, %bb54 ]
  %v31 = phi i64 [ %v9, %bb2 ], [ %v537, %bb54 ]
  %v32 = phi i64 [ %v21, %bb2 ], [ %v538, %bb54 ]
  %v33 = phi i64 [ %v9, %bb2 ], [ %v539, %bb54 ]
  %v34 = phi i64 [ %v21, %bb2 ], [ %v542, %bb54 ]
  %v45 = icmp ult i64 %v34, %v33
  switch i1 %v45, label %invalid.tag.b4 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b4:
  call void @abort()
  unreachable
bb5:
  %v46 = select i1 true, i64 0, i64 0
  %v47 = icmp eq i64 %v31, %v46
  switch i1 %v47, label %invalid.tag.b5 [
    i1 1, label %bb9
    i1 0, label %bb10
  ]
invalid.tag.b5:
  call void @abort()
  unreachable
bb6:
  br label %bb7
bb7:
  %v35 = phi ptr [ %v22, %bb6 ], [ %v22, %bb9 ], [ %v219, %bb49 ]
  %v36 = phi ptr [ %v23, %bb6 ], [ %v23, %bb9 ], [ %v220, %bb49 ]
  %v37 = phi i64 [ %v24, %bb6 ], [ %v24, %bb9 ], [ %v221, %bb49 ]
  %v38 = phi ptr [ %v25, %bb6 ], [ %v25, %bb9 ], [ %v222, %bb49 ]
  %v39 = phi i64 [ %v26, %bb6 ], [ %v26, %bb9 ], [ %v223, %bb49 ]
  %v40 = phi i64 [ %v27, %bb6 ], [ %v27, %bb9 ], [ %v224, %bb49 ]
  %v41 = phi i64 [ %v28, %bb6 ], [ %v28, %bb9 ], [ %v225, %bb49 ]
  %v42 = phi i64 [ %v29, %bb6 ], [ %v29, %bb9 ], [ %v226, %bb49 ]
  %v43 = phi i64 [ %v30, %bb6 ], [ %v30, %bb9 ], [ %v227, %bb49 ]
  %v44 = phi i64 [ %v31, %bb6 ], [ %v31, %bb9 ], [ %v228, %bb49 ]
  br label %bb1
bb8:
  %v48 = phi ptr [ %v22, %bb10 ]
  %v49 = phi ptr [ %v23, %bb10 ]
  %v50 = phi i64 [ %v24, %bb10 ]
  %v51 = phi ptr [ %v25, %bb10 ]
  %v52 = phi i64 [ %v26, %bb10 ]
  %v53 = phi i64 [ %v27, %bb10 ]
  %v54 = phi i64 [ %v28, %bb10 ]
  %v55 = phi i64 [ %v29, %bb10 ]
  %v56 = phi i64 [ %v30, %bb10 ]
  %v57 = phi i64 [ %v31, %bb10 ]
  %v58 = phi i64 [ %v34, %bb10 ]
  %v59 = select i1 true, i64 8, i64 8
  %v60 = urem i64 %v56, %v59
  %v61 = sub nuw i64 %v54, %v56
  %v62 = call i64 @wf_hash_map.hash_map_control_span(i64 %v60, i64 %v61, i64 %v57)
  %v63 = select i1 true, i64 8, i64 8
  %v64 = udiv i64 %v56, %v63
  %t4 = getelementptr inbounds %wf.t.2758c7c2b3b908fb, ptr %v48, i32 0, i32 2
  %v65 = getelementptr i8, ptr %t4, i64 0
  %v66 = call i64 @wf_hash_map.hash_map_control_word(ptr %v65, i64 %v64)
  %v67 = call i64 @wf_hash_map.hash_map_control_active(i64 %v60, i64 %v62)
  %v68 = call i64 @wf_hash_map.hash_map_control_equal(i64 %v66, i64 %v53)
  %v69 = and i64 %v68, %v67
  %v70 = select i1 true, i64 128, i64 128
  %v71 = call i64 @wf_hash_map.hash_map_control_equal(i64 %v66, i64 %v70)
  %v72 = and i64 %v71, %v67
  %v73 = select i1 true, i64 254, i64 254
  %v74 = call i64 @wf_hash_map.hash_map_control_equal(i64 %v66, i64 %v73)
  %v75 = and i64 %v74, %v67
  %v76 = or i64 %v72, %v75
  %v77 = call i64 @wf_hash_map.hash_map_control_stop(i64 %v72, i64 %v60, i64 %v62)
  %v78 = icmp eq i64 %v55, %v54
  switch i1 %v78, label %invalid.tag.b8 [
    i1 1, label %bb12
    i1 0, label %bb13
  ]
invalid.tag.b8:
  call void @abort()
  unreachable
bb9:
  br label %bb7
bb10:
  br label %bb8
bb11:
  %v79 = phi ptr [ %v48, %bb13 ], [ %v106, %bb14 ]
  %v80 = phi ptr [ %v49, %bb13 ], [ %v107, %bb14 ]
  %v81 = phi i64 [ %v50, %bb13 ], [ %v108, %bb14 ]
  %v82 = phi ptr [ %v51, %bb13 ], [ %v109, %bb14 ]
  %v83 = phi i64 [ %v52, %bb13 ], [ %v110, %bb14 ]
  %v84 = phi i64 [ %v53, %bb13 ], [ %v111, %bb14 ]
  %v85 = phi i64 [ %v54, %bb13 ], [ %v112, %bb14 ]
  %v86 = phi i64 [ %v55, %bb13 ], [ %v113, %bb14 ]
  %v87 = phi i64 [ %v56, %bb13 ], [ %v114, %bb14 ]
  %v88 = phi i64 [ %v57, %bb13 ], [ %v115, %bb14 ]
  %v89 = phi i64 [ %v58, %bb13 ], [ %v116, %bb14 ]
  %v90 = phi i64 [ %v60, %bb13 ], [ %v117, %bb14 ]
  %v91 = phi i64 [ %v61, %bb13 ], [ %v118, %bb14 ]
  %v92 = phi i64 [ %v62, %bb13 ], [ %v119, %bb14 ]
  %v93 = phi i64 [ %v64, %bb13 ], [ %v120, %bb14 ]
  %v94 = phi i64 [ %v66, %bb13 ], [ %v121, %bb14 ]
  %v95 = phi i64 [ %v67, %bb13 ], [ %v122, %bb14 ]
  %v96 = phi i64 [ %v68, %bb13 ], [ %v123, %bb14 ]
  %v97 = phi i64 [ %v69, %bb13 ], [ %v124, %bb14 ]
  %v98 = phi i64 [ %v71, %bb13 ], [ %v125, %bb14 ]
  %v99 = phi i64 [ %v72, %bb13 ], [ %v126, %bb14 ]
  %v100 = phi i64 [ %v74, %bb13 ], [ %v127, %bb14 ]
  %v101 = phi i64 [ %v75, %bb13 ], [ %v128, %bb14 ]
  %v102 = phi i64 [ %v76, %bb13 ], [ %v129, %bb14 ]
  %v103 = phi i64 [ %v77, %bb13 ], [ %v130, %bb14 ]
  %v189 = select i1 true, i64 0, i64 0
  %v190 = select i1 true, i64 8, i64 8
  br label %bb23
bb12:
  %v104 = select i1 true, i64 0, i64 0
  %v105 = icmp ugt i64 %v76, %v104
  switch i1 %v105, label %invalid.tag.b12 [
    i1 1, label %bb15
    i1 0, label %bb16
  ]
invalid.tag.b12:
  call void @abort()
  unreachable
bb13:
  br label %bb11
bb14:
  %v106 = phi ptr [ %v48, %bb16 ], [ %v133, %bb17 ]
  %v107 = phi ptr [ %v49, %bb16 ], [ %v134, %bb17 ]
  %v108 = phi i64 [ %v50, %bb16 ], [ %v135, %bb17 ]
  %v109 = phi ptr [ %v51, %bb16 ], [ %v136, %bb17 ]
  %v110 = phi i64 [ %v52, %bb16 ], [ %v137, %bb17 ]
  %v111 = phi i64 [ %v53, %bb16 ], [ %v138, %bb17 ]
  %v112 = phi i64 [ %v54, %bb16 ], [ %v139, %bb17 ]
  %v113 = phi i64 [ %v55, %bb16 ], [ %v140, %bb17 ]
  %v114 = phi i64 [ %v56, %bb16 ], [ %v141, %bb17 ]
  %v115 = phi i64 [ %v57, %bb16 ], [ %v142, %bb17 ]
  %v116 = phi i64 [ %v58, %bb16 ], [ %v143, %bb17 ]
  %v117 = phi i64 [ %v60, %bb16 ], [ %v144, %bb17 ]
  %v118 = phi i64 [ %v61, %bb16 ], [ %v145, %bb17 ]
  %v119 = phi i64 [ %v62, %bb16 ], [ %v146, %bb17 ]
  %v120 = phi i64 [ %v64, %bb16 ], [ %v147, %bb17 ]
  %v121 = phi i64 [ %v66, %bb16 ], [ %v148, %bb17 ]
  %v122 = phi i64 [ %v67, %bb16 ], [ %v149, %bb17 ]
  %v123 = phi i64 [ %v68, %bb16 ], [ %v150, %bb17 ]
  %v124 = phi i64 [ %v69, %bb16 ], [ %v151, %bb17 ]
  %v125 = phi i64 [ %v71, %bb16 ], [ %v152, %bb17 ]
  %v126 = phi i64 [ %v72, %bb16 ], [ %v153, %bb17 ]
  %v127 = phi i64 [ %v74, %bb16 ], [ %v154, %bb17 ]
  %v128 = phi i64 [ %v75, %bb16 ], [ %v155, %bb17 ]
  %v129 = phi i64 [ %v76, %bb16 ], [ %v156, %bb17 ]
  %v130 = phi i64 [ %v77, %bb16 ], [ %v157, %bb17 ]
  br label %bb11
bb15:
  %v131 = call i64 @wf_hash_map.hash_map_control_first(i64 %v76)
  %v132 = icmp uge i64 %v131, %v60
  switch i1 %v132, label %invalid.tag.b15 [
    i1 1, label %bb18
    i1 0, label %bb19
  ]
invalid.tag.b15:
  call void @abort()
  unreachable
bb16:
  br label %bb14
bb17:
  %v133 = phi ptr [ %v48, %bb19 ], [ %v161, %bb20 ]
  %v134 = phi ptr [ %v49, %bb19 ], [ %v162, %bb20 ]
  %v135 = phi i64 [ %v50, %bb19 ], [ %v163, %bb20 ]
  %v136 = phi ptr [ %v51, %bb19 ], [ %v164, %bb20 ]
  %v137 = phi i64 [ %v52, %bb19 ], [ %v165, %bb20 ]
  %v138 = phi i64 [ %v53, %bb19 ], [ %v166, %bb20 ]
  %v139 = phi i64 [ %v54, %bb19 ], [ %v167, %bb20 ]
  %v140 = phi i64 [ %v55, %bb19 ], [ %v168, %bb20 ]
  %v141 = phi i64 [ %v56, %bb19 ], [ %v169, %bb20 ]
  %v142 = phi i64 [ %v57, %bb19 ], [ %v170, %bb20 ]
  %v143 = phi i64 [ %v58, %bb19 ], [ %v171, %bb20 ]
  %v144 = phi i64 [ %v60, %bb19 ], [ %v172, %bb20 ]
  %v145 = phi i64 [ %v61, %bb19 ], [ %v173, %bb20 ]
  %v146 = phi i64 [ %v62, %bb19 ], [ %v174, %bb20 ]
  %v147 = phi i64 [ %v64, %bb19 ], [ %v175, %bb20 ]
  %v148 = phi i64 [ %v66, %bb19 ], [ %v176, %bb20 ]
  %v149 = phi i64 [ %v67, %bb19 ], [ %v177, %bb20 ]
  %v150 = phi i64 [ %v68, %bb19 ], [ %v178, %bb20 ]
  %v151 = phi i64 [ %v69, %bb19 ], [ %v179, %bb20 ]
  %v152 = phi i64 [ %v71, %bb19 ], [ %v180, %bb20 ]
  %v153 = phi i64 [ %v72, %bb19 ], [ %v181, %bb20 ]
  %v154 = phi i64 [ %v74, %bb19 ], [ %v182, %bb20 ]
  %v155 = phi i64 [ %v75, %bb19 ], [ %v183, %bb20 ]
  %v156 = phi i64 [ %v76, %bb19 ], [ %v184, %bb20 ]
  %v157 = phi i64 [ %v77, %bb19 ], [ %v185, %bb20 ]
  %v158 = phi i64 [ %v131, %bb19 ], [ %v186, %bb20 ]
  br label %bb14
bb18:
  %v159 = sub nuw i64 %v131, %v60
  %v160 = icmp ult i64 %v159, %v62
  switch i1 %v160, label %invalid.tag.b18 [
    i1 1, label %bb21
    i1 0, label %bb22
  ]
invalid.tag.b18:
  call void @abort()
  unreachable
bb19:
  br label %bb17
bb20:
  %v161 = phi ptr [ %v48, %bb21 ], [ %v48, %bb22 ]
  %v162 = phi ptr [ %v49, %bb21 ], [ %v49, %bb22 ]
  %v163 = phi i64 [ %v50, %bb21 ], [ %v50, %bb22 ]
  %v164 = phi ptr [ %v51, %bb21 ], [ %v51, %bb22 ]
  %v165 = phi i64 [ %v52, %bb21 ], [ %v52, %bb22 ]
  %v166 = phi i64 [ %v53, %bb21 ], [ %v53, %bb22 ]
  %v167 = phi i64 [ %v54, %bb21 ], [ %v54, %bb22 ]
  %v168 = phi i64 [ %v188, %bb21 ], [ %v55, %bb22 ]
  %v169 = phi i64 [ %v56, %bb21 ], [ %v56, %bb22 ]
  %v170 = phi i64 [ %v57, %bb21 ], [ %v57, %bb22 ]
  %v171 = phi i64 [ %v58, %bb21 ], [ %v58, %bb22 ]
  %v172 = phi i64 [ %v60, %bb21 ], [ %v60, %bb22 ]
  %v173 = phi i64 [ %v61, %bb21 ], [ %v61, %bb22 ]
  %v174 = phi i64 [ %v62, %bb21 ], [ %v62, %bb22 ]
  %v175 = phi i64 [ %v64, %bb21 ], [ %v64, %bb22 ]
  %v176 = phi i64 [ %v66, %bb21 ], [ %v66, %bb22 ]
  %v177 = phi i64 [ %v67, %bb21 ], [ %v67, %bb22 ]
  %v178 = phi i64 [ %v68, %bb21 ], [ %v68, %bb22 ]
  %v179 = phi i64 [ %v69, %bb21 ], [ %v69, %bb22 ]
  %v180 = phi i64 [ %v71, %bb21 ], [ %v71, %bb22 ]
  %v181 = phi i64 [ %v72, %bb21 ], [ %v72, %bb22 ]
  %v182 = phi i64 [ %v74, %bb21 ], [ %v74, %bb22 ]
  %v183 = phi i64 [ %v75, %bb21 ], [ %v75, %bb22 ]
  %v184 = phi i64 [ %v76, %bb21 ], [ %v76, %bb22 ]
  %v185 = phi i64 [ %v77, %bb21 ], [ %v77, %bb22 ]
  %v186 = phi i64 [ %v131, %bb21 ], [ %v131, %bb22 ]
  %v187 = phi i64 [ %v159, %bb21 ], [ %v159, %bb22 ]
  br label %bb17
bb21:
  %v188 = add nuw i64 %v56, %v159
  br label %bb20
bb22:
  br label %bb20
bb23:
  %v191 = phi ptr [ %v79, %bb11 ], [ %v442, %bb47 ]
  %v192 = phi ptr [ %v80, %bb11 ], [ %v443, %bb47 ]
  %v193 = phi i64 [ %v81, %bb11 ], [ %v444, %bb47 ]
  %v194 = phi ptr [ %v82, %bb11 ], [ %v445, %bb47 ]
  %v195 = phi i64 [ %v83, %bb11 ], [ %v446, %bb47 ]
  %v196 = phi i64 [ %v84, %bb11 ], [ %v447, %bb47 ]
  %v197 = phi i64 [ %v85, %bb11 ], [ %v448, %bb47 ]
  %v198 = phi i64 [ %v86, %bb11 ], [ %v449, %bb47 ]
  %v199 = phi i64 [ %v87, %bb11 ], [ %v450, %bb47 ]
  %v200 = phi i64 [ %v88, %bb11 ], [ %v451, %bb47 ]
  %v201 = phi i64 [ %v89, %bb11 ], [ %v452, %bb47 ]
  %v202 = phi i64 [ %v90, %bb11 ], [ %v453, %bb47 ]
  %v203 = phi i64 [ %v91, %bb11 ], [ %v454, %bb47 ]
  %v204 = phi i64 [ %v92, %bb11 ], [ %v455, %bb47 ]
  %v205 = phi i64 [ %v93, %bb11 ], [ %v456, %bb47 ]
  %v206 = phi i64 [ %v94, %bb11 ], [ %v457, %bb47 ]
  %v207 = phi i64 [ %v95, %bb11 ], [ %v458, %bb47 ]
  %v208 = phi i64 [ %v96, %bb11 ], [ %v459, %bb47 ]
  %v209 = phi i64 [ %v97, %bb11 ], [ %v460, %bb47 ]
  %v210 = phi i64 [ %v98, %bb11 ], [ %v461, %bb47 ]
  %v211 = phi i64 [ %v99, %bb11 ], [ %v462, %bb47 ]
  %v212 = phi i64 [ %v100, %bb11 ], [ %v463, %bb47 ]
  %v213 = phi i64 [ %v101, %bb11 ], [ %v464, %bb47 ]
  %v214 = phi i64 [ %v102, %bb11 ], [ %v465, %bb47 ]
  %v215 = phi i64 [ %v103, %bb11 ], [ %v466, %bb47 ]
  %v216 = phi i64 [ %v189, %bb11 ], [ %v467, %bb47 ]
  %v217 = phi i64 [ %v190, %bb11 ], [ %v468, %bb47 ]
  %v218 = phi i64 [ %v189, %bb11 ], [ %v471, %bb47 ]
  %v244 = icmp ult i64 %v218, %v217
  switch i1 %v244, label %invalid.tag.b23 [
    i1 1, label %bb24
    i1 0, label %bb25
  ]
invalid.tag.b23:
  call void @abort()
  unreachable
bb24:
  %v245 = select i1 true, i64 0, i64 0
  %v246 = icmp eq i64 %v209, %v245
  switch i1 %v246, label %invalid.tag.b24 [
    i1 1, label %bb28
    i1 0, label %bb29
  ]
invalid.tag.b24:
  call void @abort()
  unreachable
bb25:
  br label %bb26
bb26:
  %v219 = phi ptr [ %v191, %bb25 ], [ %v191, %bb28 ], [ %v379, %bb41 ]
  %v220 = phi ptr [ %v192, %bb25 ], [ %v192, %bb28 ], [ %v380, %bb41 ]
  %v221 = phi i64 [ %v193, %bb25 ], [ %v193, %bb28 ], [ %v381, %bb41 ]
  %v222 = phi ptr [ %v194, %bb25 ], [ %v194, %bb28 ], [ %v382, %bb41 ]
  %v223 = phi i64 [ %v195, %bb25 ], [ %v195, %bb28 ], [ %v383, %bb41 ]
  %v224 = phi i64 [ %v196, %bb25 ], [ %v196, %bb28 ], [ %v384, %bb41 ]
  %v225 = phi i64 [ %v197, %bb25 ], [ %v197, %bb28 ], [ %v385, %bb41 ]
  %v226 = phi i64 [ %v198, %bb25 ], [ %v198, %bb28 ], [ %v386, %bb41 ]
  %v227 = phi i64 [ %v199, %bb25 ], [ %v199, %bb28 ], [ %v387, %bb41 ]
  %v228 = phi i64 [ %v200, %bb25 ], [ %v200, %bb28 ], [ %v388, %bb41 ]
  %v229 = phi i64 [ %v201, %bb25 ], [ %v201, %bb28 ], [ %v389, %bb41 ]
  %v230 = phi i64 [ %v202, %bb25 ], [ %v202, %bb28 ], [ %v390, %bb41 ]
  %v231 = phi i64 [ %v203, %bb25 ], [ %v203, %bb28 ], [ %v391, %bb41 ]
  %v232 = phi i64 [ %v204, %bb25 ], [ %v204, %bb28 ], [ %v392, %bb41 ]
  %v233 = phi i64 [ %v205, %bb25 ], [ %v205, %bb28 ], [ %v393, %bb41 ]
  %v234 = phi i64 [ %v206, %bb25 ], [ %v206, %bb28 ], [ %v394, %bb41 ]
  %v235 = phi i64 [ %v207, %bb25 ], [ %v207, %bb28 ], [ %v395, %bb41 ]
  %v236 = phi i64 [ %v208, %bb25 ], [ %v208, %bb28 ], [ %v396, %bb41 ]
  %v237 = phi i64 [ %v209, %bb25 ], [ %v209, %bb28 ], [ %v397, %bb41 ]
  %v238 = phi i64 [ %v210, %bb25 ], [ %v210, %bb28 ], [ %v398, %bb41 ]
  %v239 = phi i64 [ %v211, %bb25 ], [ %v211, %bb28 ], [ %v399, %bb41 ]
  %v240 = phi i64 [ %v212, %bb25 ], [ %v212, %bb28 ], [ %v400, %bb41 ]
  %v241 = phi i64 [ %v213, %bb25 ], [ %v213, %bb28 ], [ %v401, %bb41 ]
  %v242 = phi i64 [ %v214, %bb25 ], [ %v214, %bb28 ], [ %v402, %bb41 ]
  %v243 = phi i64 [ %v215, %bb25 ], [ %v215, %bb28 ], [ %v407, %bb41 ]
  %v472 = icmp ult i64 %v243, %v232
  switch i1 %v472, label %invalid.tag.b26 [
    i1 1, label %bb49
    i1 0, label %bb50
  ]
invalid.tag.b26:
  call void @abort()
  unreachable
bb27:
  %v247 = phi ptr [ %v191, %bb29 ]
  %v248 = phi ptr [ %v192, %bb29 ]
  %v249 = phi i64 [ %v193, %bb29 ]
  %v250 = phi ptr [ %v194, %bb29 ]
  %v251 = phi i64 [ %v195, %bb29 ]
  %v252 = phi i64 [ %v196, %bb29 ]
  %v253 = phi i64 [ %v197, %bb29 ]
  %v254 = phi i64 [ %v198, %bb29 ]
  %v255 = phi i64 [ %v199, %bb29 ]
  %v256 = phi i64 [ %v200, %bb29 ]
  %v257 = phi i64 [ %v201, %bb29 ]
  %v258 = phi i64 [ %v202, %bb29 ]
  %v259 = phi i64 [ %v203, %bb29 ]
  %v260 = phi i64 [ %v204, %bb29 ]
  %v261 = phi i64 [ %v205, %bb29 ]
  %v262 = phi i64 [ %v206, %bb29 ]
  %v263 = phi i64 [ %v207, %bb29 ]
  %v264 = phi i64 [ %v208, %bb29 ]
  %v265 = phi i64 [ %v209, %bb29 ]
  %v266 = phi i64 [ %v210, %bb29 ]
  %v267 = phi i64 [ %v211, %bb29 ]
  %v268 = phi i64 [ %v212, %bb29 ]
  %v269 = phi i64 [ %v213, %bb29 ]
  %v270 = phi i64 [ %v214, %bb29 ]
  %v271 = phi i64 [ %v215, %bb29 ]
  %v272 = phi i64 [ %v218, %bb29 ]
  %v273 = call i64 @wf_hash_map.hash_map_control_first(i64 %v265)
  %v274 = select i1 true, i64 1, i64 1
  %v275 = sub nuw i64 %v265, %v274
  %v276 = and i64 %v265, %v275
  %v277 = icmp uge i64 %v273, %v258
  switch i1 %v277, label %invalid.tag.b27 [
    i1 1, label %bb31
    i1 0, label %bb32
  ]
invalid.tag.b27:
  call void @abort()
  unreachable
bb28:
  br label %bb26
bb29:
  br label %bb27
bb30:
  %v278 = phi ptr [ %v247, %bb32 ], [ %v308, %bb33 ]
  %v279 = phi ptr [ %v248, %bb32 ], [ %v309, %bb33 ]
  %v280 = phi i64 [ %v249, %bb32 ], [ %v310, %bb33 ]
  %v281 = phi ptr [ %v250, %bb32 ], [ %v311, %bb33 ]
  %v282 = phi i64 [ %v251, %bb32 ], [ %v312, %bb33 ]
  %v283 = phi i64 [ %v252, %bb32 ], [ %v313, %bb33 ]
  %v284 = phi i64 [ %v253, %bb32 ], [ %v314, %bb33 ]
  %v285 = phi i64 [ %v254, %bb32 ], [ %v315, %bb33 ]
  %v286 = phi i64 [ %v255, %bb32 ], [ %v316, %bb33 ]
  %v287 = phi i64 [ %v256, %bb32 ], [ %v317, %bb33 ]
  %v288 = phi i64 [ %v257, %bb32 ], [ %v318, %bb33 ]
  %v289 = phi i64 [ %v258, %bb32 ], [ %v319, %bb33 ]
  %v290 = phi i64 [ %v259, %bb32 ], [ %v320, %bb33 ]
  %v291 = phi i64 [ %v260, %bb32 ], [ %v321, %bb33 ]
  %v292 = phi i64 [ %v261, %bb32 ], [ %v322, %bb33 ]
  %v293 = phi i64 [ %v262, %bb32 ], [ %v323, %bb33 ]
  %v294 = phi i64 [ %v263, %bb32 ], [ %v324, %bb33 ]
  %v295 = phi i64 [ %v264, %bb32 ], [ %v325, %bb33 ]
  %v296 = phi i64 [ %v276, %bb32 ], [ %v326, %bb33 ]
  %v297 = phi i64 [ %v266, %bb32 ], [ %v327, %bb33 ]
  %v298 = phi i64 [ %v267, %bb32 ], [ %v328, %bb33 ]
  %v299 = phi i64 [ %v268, %bb32 ], [ %v329, %bb33 ]
  %v300 = phi i64 [ %v269, %bb32 ], [ %v330, %bb33 ]
  %v301 = phi i64 [ %v270, %bb32 ], [ %v331, %bb33 ]
  %v302 = phi i64 [ %v271, %bb32 ], [ %v332, %bb33 ]
  %v303 = phi i64 [ %v272, %bb32 ], [ %v333, %bb33 ]
  %v304 = phi i64 [ %v273, %bb32 ], [ %v334, %bb33 ]
  %v305 = phi i64 [ %v275, %bb32 ], [ %v335, %bb33 ]
  br label %bb47
bb31:
  %v306 = sub nuw i64 %v273, %v258
  %v307 = icmp ult i64 %v306, %v271
  switch i1 %v307, label %invalid.tag.b31 [
    i1 1, label %bb34
    i1 0, label %bb35
  ]
invalid.tag.b31:
  call void @abort()
  unreachable
bb32:
  br label %bb30
bb33:
  %v308 = phi ptr [ %v247, %bb35 ], [ %v342, %bb36 ]
  %v309 = phi ptr [ %v248, %bb35 ], [ %v343, %bb36 ]
  %v310 = phi i64 [ %v249, %bb35 ], [ %v344, %bb36 ]
  %v311 = phi ptr [ %v250, %bb35 ], [ %v345, %bb36 ]
  %v312 = phi i64 [ %v251, %bb35 ], [ %v346, %bb36 ]
  %v313 = phi i64 [ %v252, %bb35 ], [ %v347, %bb36 ]
  %v314 = phi i64 [ %v253, %bb35 ], [ %v348, %bb36 ]
  %v315 = phi i64 [ %v254, %bb35 ], [ %v349, %bb36 ]
  %v316 = phi i64 [ %v255, %bb35 ], [ %v350, %bb36 ]
  %v317 = phi i64 [ %v256, %bb35 ], [ %v351, %bb36 ]
  %v318 = phi i64 [ %v257, %bb35 ], [ %v352, %bb36 ]
  %v319 = phi i64 [ %v258, %bb35 ], [ %v353, %bb36 ]
  %v320 = phi i64 [ %v259, %bb35 ], [ %v354, %bb36 ]
  %v321 = phi i64 [ %v260, %bb35 ], [ %v355, %bb36 ]
  %v322 = phi i64 [ %v261, %bb35 ], [ %v356, %bb36 ]
  %v323 = phi i64 [ %v262, %bb35 ], [ %v357, %bb36 ]
  %v324 = phi i64 [ %v263, %bb35 ], [ %v358, %bb36 ]
  %v325 = phi i64 [ %v264, %bb35 ], [ %v359, %bb36 ]
  %v326 = phi i64 [ %v276, %bb35 ], [ %v360, %bb36 ]
  %v327 = phi i64 [ %v266, %bb35 ], [ %v361, %bb36 ]
  %v328 = phi i64 [ %v267, %bb35 ], [ %v362, %bb36 ]
  %v329 = phi i64 [ %v268, %bb35 ], [ %v363, %bb36 ]
  %v330 = phi i64 [ %v269, %bb35 ], [ %v364, %bb36 ]
  %v331 = phi i64 [ %v270, %bb35 ], [ %v365, %bb36 ]
  %v332 = phi i64 [ %v271, %bb35 ], [ %v366, %bb36 ]
  %v333 = phi i64 [ %v272, %bb35 ], [ %v367, %bb36 ]
  %v334 = phi i64 [ %v273, %bb35 ], [ %v368, %bb36 ]
  %v335 = phi i64 [ %v275, %bb35 ], [ %v369, %bb36 ]
  %v336 = phi i64 [ %v306, %bb35 ], [ %v370, %bb36 ]
  br label %bb30
bb34:
  %v337 = add nuw i64 %v255, %v306
  %t5 = getelementptr inbounds %wf.t.2758c7c2b3b908fb, ptr %v247, i32 0, i32 0
  %v338 = getelementptr i8, ptr %t5, i64 0
  %v339 = getelementptr i8, ptr %v338, i64 0
  %t6 = load ptr, ptr %v339
  %t7.nonnegative = icmp sge i64 %v337, 0
  call void @llvm.assume(i1 %t7.nonnegative)
  %t7 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t6, i64 0, i32 2, i64 %v337
  %v340 = getelementptr i8, ptr %t7, i64 0
  %v341 = call i32 @wf_hash_map.hash_map_action$instance$fc5e3cb62bdf3601(ptr %v340, ptr %v248, ptr %v250)
  switch i32 %v341, label %invalid.tag.b34 [
    i32 3, label %bb37
    i32 0, label %bb38
    i32 1, label %bb39
    i32 2, label %bb40
  ]
invalid.tag.b34:
  call void @abort()
  unreachable
bb35:
  br label %bb33
bb36:
  %v342 = phi ptr [ %v247, %bb40 ], [ %v411, %bb44 ]
  %v343 = phi ptr [ %v248, %bb40 ], [ %v412, %bb44 ]
  %v344 = phi i64 [ %v249, %bb40 ], [ %v413, %bb44 ]
  %v345 = phi ptr [ %v250, %bb40 ], [ %v414, %bb44 ]
  %v346 = phi i64 [ %v251, %bb40 ], [ %v415, %bb44 ]
  %v347 = phi i64 [ %v252, %bb40 ], [ %v416, %bb44 ]
  %v348 = phi i64 [ %v253, %bb40 ], [ %v417, %bb44 ]
  %v349 = phi i64 [ %v254, %bb40 ], [ %v418, %bb44 ]
  %v350 = phi i64 [ %v255, %bb40 ], [ %v419, %bb44 ]
  %v351 = phi i64 [ %v256, %bb40 ], [ %v420, %bb44 ]
  %v352 = phi i64 [ %v257, %bb40 ], [ %v421, %bb44 ]
  %v353 = phi i64 [ %v258, %bb40 ], [ %v422, %bb44 ]
  %v354 = phi i64 [ %v259, %bb40 ], [ %v423, %bb44 ]
  %v355 = phi i64 [ %v260, %bb40 ], [ %v424, %bb44 ]
  %v356 = phi i64 [ %v261, %bb40 ], [ %v425, %bb44 ]
  %v357 = phi i64 [ %v262, %bb40 ], [ %v426, %bb44 ]
  %v358 = phi i64 [ %v263, %bb40 ], [ %v427, %bb44 ]
  %v359 = phi i64 [ %v264, %bb40 ], [ %v428, %bb44 ]
  %v360 = phi i64 [ %v276, %bb40 ], [ %v429, %bb44 ]
  %v361 = phi i64 [ %v266, %bb40 ], [ %v430, %bb44 ]
  %v362 = phi i64 [ %v267, %bb40 ], [ %v431, %bb44 ]
  %v363 = phi i64 [ %v268, %bb40 ], [ %v432, %bb44 ]
  %v364 = phi i64 [ %v269, %bb40 ], [ %v433, %bb44 ]
  %v365 = phi i64 [ %v270, %bb40 ], [ %v434, %bb44 ]
  %v366 = phi i64 [ %v271, %bb40 ], [ %v435, %bb44 ]
  %v367 = phi i64 [ %v272, %bb40 ], [ %v436, %bb44 ]
  %v368 = phi i64 [ %v273, %bb40 ], [ %v437, %bb44 ]
  %v369 = phi i64 [ %v275, %bb40 ], [ %v438, %bb44 ]
  %v370 = phi i64 [ %v306, %bb40 ], [ %v439, %bb44 ]
  %v371 = phi i64 [ %v337, %bb40 ], [ %v440, %bb44 ]
  %v372 = phi i32 [ %v341, %bb40 ], [ %v441, %bb44 ]
  br label %bb33
bb37:
  %t8 = getelementptr inbounds %wf.t.2758c7c2b3b908fb, ptr %v247, i32 0, i32 0
  %v373 = getelementptr i8, ptr %t8, i64 0
  %v374 = load i64, ptr %v248
  call void @wf_hash_map.hash_map_exchange$instance$0ed342445dd803f3(ptr %wf.result, ptr %v373, i64 %v337, i64 %v374, i64 %v249)
  %t9 = getelementptr inbounds %wf.t.2758c7c2b3b908fb, ptr %v247, i32 0, i32 2
  %v376 = getelementptr i8, ptr %t9, i64 0
  %v377 = call i8 @wf_hash_map.hash_map_control_set(ptr %v376, i64 %v337, i64 %v252)
  ret void
bb38:
  %v378 = icmp eq i64 %v254, %v253
  switch i1 %v378, label %invalid.tag.b38 [
    i1 1, label %bb42
    i1 0, label %bb43
  ]
invalid.tag.b38:
  call void @abort()
  unreachable
bb39:
  %v410 = icmp eq i64 %v254, %v253
  switch i1 %v410, label %invalid.tag.b39 [
    i1 1, label %bb45
    i1 0, label %bb46
  ]
invalid.tag.b39:
  call void @abort()
  unreachable
bb40:
  br label %bb36
bb41:
  %v379 = phi ptr [ %v247, %bb42 ], [ %v247, %bb43 ]
  %v380 = phi ptr [ %v248, %bb42 ], [ %v248, %bb43 ]
  %v381 = phi i64 [ %v249, %bb42 ], [ %v249, %bb43 ]
  %v382 = phi ptr [ %v250, %bb42 ], [ %v250, %bb43 ]
  %v383 = phi i64 [ %v251, %bb42 ], [ %v251, %bb43 ]
  %v384 = phi i64 [ %v252, %bb42 ], [ %v252, %bb43 ]
  %v385 = phi i64 [ %v253, %bb42 ], [ %v253, %bb43 ]
  %v386 = phi i64 [ %v337, %bb42 ], [ %v254, %bb43 ]
  %v387 = phi i64 [ %v255, %bb42 ], [ %v255, %bb43 ]
  %v388 = phi i64 [ %v256, %bb42 ], [ %v256, %bb43 ]
  %v389 = phi i64 [ %v257, %bb42 ], [ %v257, %bb43 ]
  %v390 = phi i64 [ %v258, %bb42 ], [ %v258, %bb43 ]
  %v391 = phi i64 [ %v259, %bb42 ], [ %v259, %bb43 ]
  %v392 = phi i64 [ %v260, %bb42 ], [ %v260, %bb43 ]
  %v393 = phi i64 [ %v261, %bb42 ], [ %v261, %bb43 ]
  %v394 = phi i64 [ %v262, %bb42 ], [ %v262, %bb43 ]
  %v395 = phi i64 [ %v263, %bb42 ], [ %v263, %bb43 ]
  %v396 = phi i64 [ %v264, %bb42 ], [ %v264, %bb43 ]
  %v397 = phi i64 [ %v276, %bb42 ], [ %v276, %bb43 ]
  %v398 = phi i64 [ %v266, %bb42 ], [ %v266, %bb43 ]
  %v399 = phi i64 [ %v267, %bb42 ], [ %v267, %bb43 ]
  %v400 = phi i64 [ %v268, %bb42 ], [ %v268, %bb43 ]
  %v401 = phi i64 [ %v269, %bb42 ], [ %v269, %bb43 ]
  %v402 = phi i64 [ %v270, %bb42 ], [ %v270, %bb43 ]
  %v403 = phi i64 [ %v271, %bb42 ], [ %v271, %bb43 ]
  %v404 = phi i64 [ %v272, %bb42 ], [ %v272, %bb43 ]
  %v405 = phi i64 [ %v273, %bb42 ], [ %v273, %bb43 ]
  %v406 = phi i64 [ %v275, %bb42 ], [ %v275, %bb43 ]
  %v407 = phi i64 [ %v306, %bb42 ], [ %v306, %bb43 ]
  %v408 = phi i64 [ %v337, %bb42 ], [ %v337, %bb43 ]
  %v409 = phi i32 [ %v341, %bb42 ], [ %v341, %bb43 ]
  br label %bb26
bb42:
  br label %bb41
bb43:
  br label %bb41
bb44:
  %v411 = phi ptr [ %v247, %bb45 ], [ %v247, %bb46 ]
  %v412 = phi ptr [ %v248, %bb45 ], [ %v248, %bb46 ]
  %v413 = phi i64 [ %v249, %bb45 ], [ %v249, %bb46 ]
  %v414 = phi ptr [ %v250, %bb45 ], [ %v250, %bb46 ]
  %v415 = phi i64 [ %v251, %bb45 ], [ %v251, %bb46 ]
  %v416 = phi i64 [ %v252, %bb45 ], [ %v252, %bb46 ]
  %v417 = phi i64 [ %v253, %bb45 ], [ %v253, %bb46 ]
  %v418 = phi i64 [ %v337, %bb45 ], [ %v254, %bb46 ]
  %v419 = phi i64 [ %v255, %bb45 ], [ %v255, %bb46 ]
  %v420 = phi i64 [ %v256, %bb45 ], [ %v256, %bb46 ]
  %v421 = phi i64 [ %v257, %bb45 ], [ %v257, %bb46 ]
  %v422 = phi i64 [ %v258, %bb45 ], [ %v258, %bb46 ]
  %v423 = phi i64 [ %v259, %bb45 ], [ %v259, %bb46 ]
  %v424 = phi i64 [ %v260, %bb45 ], [ %v260, %bb46 ]
  %v425 = phi i64 [ %v261, %bb45 ], [ %v261, %bb46 ]
  %v426 = phi i64 [ %v262, %bb45 ], [ %v262, %bb46 ]
  %v427 = phi i64 [ %v263, %bb45 ], [ %v263, %bb46 ]
  %v428 = phi i64 [ %v264, %bb45 ], [ %v264, %bb46 ]
  %v429 = phi i64 [ %v276, %bb45 ], [ %v276, %bb46 ]
  %v430 = phi i64 [ %v266, %bb45 ], [ %v266, %bb46 ]
  %v431 = phi i64 [ %v267, %bb45 ], [ %v267, %bb46 ]
  %v432 = phi i64 [ %v268, %bb45 ], [ %v268, %bb46 ]
  %v433 = phi i64 [ %v269, %bb45 ], [ %v269, %bb46 ]
  %v434 = phi i64 [ %v270, %bb45 ], [ %v270, %bb46 ]
  %v435 = phi i64 [ %v271, %bb45 ], [ %v271, %bb46 ]
  %v436 = phi i64 [ %v272, %bb45 ], [ %v272, %bb46 ]
  %v437 = phi i64 [ %v273, %bb45 ], [ %v273, %bb46 ]
  %v438 = phi i64 [ %v275, %bb45 ], [ %v275, %bb46 ]
  %v439 = phi i64 [ %v306, %bb45 ], [ %v306, %bb46 ]
  %v440 = phi i64 [ %v337, %bb45 ], [ %v337, %bb46 ]
  %v441 = phi i32 [ %v341, %bb45 ], [ %v341, %bb46 ]
  br label %bb36
bb45:
  br label %bb44
bb46:
  br label %bb44
bb47:
  %v442 = phi ptr [ %v278, %bb30 ]
  %v443 = phi ptr [ %v279, %bb30 ]
  %v444 = phi i64 [ %v280, %bb30 ]
  %v445 = phi ptr [ %v281, %bb30 ]
  %v446 = phi i64 [ %v282, %bb30 ]
  %v447 = phi i64 [ %v283, %bb30 ]
  %v448 = phi i64 [ %v284, %bb30 ]
  %v449 = phi i64 [ %v285, %bb30 ]
  %v450 = phi i64 [ %v286, %bb30 ]
  %v451 = phi i64 [ %v287, %bb30 ]
  %v452 = phi i64 [ %v288, %bb30 ]
  %v453 = phi i64 [ %v289, %bb30 ]
  %v454 = phi i64 [ %v290, %bb30 ]
  %v455 = phi i64 [ %v291, %bb30 ]
  %v456 = phi i64 [ %v292, %bb30 ]
  %v457 = phi i64 [ %v293, %bb30 ]
  %v458 = phi i64 [ %v294, %bb30 ]
  %v459 = phi i64 [ %v295, %bb30 ]
  %v460 = phi i64 [ %v296, %bb30 ]
  %v461 = phi i64 [ %v297, %bb30 ]
  %v462 = phi i64 [ %v298, %bb30 ]
  %v463 = phi i64 [ %v299, %bb30 ]
  %v464 = phi i64 [ %v300, %bb30 ]
  %v465 = phi i64 [ %v301, %bb30 ]
  %v466 = phi i64 [ %v302, %bb30 ]
  %v467 = phi i64 [ %v216, %bb30 ]
  %v468 = phi i64 [ %v217, %bb30 ]
  %v469 = phi i64 [ %v218, %bb30 ]
  %v470 = select i1 true, i64 1, i64 1
  %v471 = add i64 %v469, %v470
  br label %bb23
bb48:
  %v473 = phi ptr [ %v219, %bb50 ]
  %v474 = phi ptr [ %v220, %bb50 ]
  %v475 = phi i64 [ %v221, %bb50 ]
  %v476 = phi ptr [ %v222, %bb50 ]
  %v477 = phi i64 [ %v223, %bb50 ]
  %v478 = phi i64 [ %v224, %bb50 ]
  %v479 = phi i64 [ %v225, %bb50 ]
  %v480 = phi i64 [ %v226, %bb50 ]
  %v481 = phi i64 [ %v227, %bb50 ]
  %v482 = phi i64 [ %v228, %bb50 ]
  %v483 = phi i64 [ %v229, %bb50 ]
  %v484 = phi i64 [ %v230, %bb50 ]
  %v485 = phi i64 [ %v231, %bb50 ]
  %v486 = phi i64 [ %v232, %bb50 ]
  %v487 = phi i64 [ %v233, %bb50 ]
  %v488 = phi i64 [ %v234, %bb50 ]
  %v489 = phi i64 [ %v235, %bb50 ]
  %v490 = phi i64 [ %v236, %bb50 ]
  %v491 = phi i64 [ %v237, %bb50 ]
  %v492 = phi i64 [ %v238, %bb50 ]
  %v493 = phi i64 [ %v239, %bb50 ]
  %v494 = phi i64 [ %v240, %bb50 ]
  %v495 = phi i64 [ %v241, %bb50 ]
  %v496 = phi i64 [ %v242, %bb50 ]
  %v497 = phi i64 [ %v243, %bb50 ]
  %v498 = sub nuw i64 %v482, %v486
  %v499 = add nuw i64 %v481, %v486
  %v500 = icmp ult i64 %v499, %v479
  switch i1 %v500, label %invalid.tag.b48 [
    i1 1, label %bb52
    i1 0, label %bb53
  ]
invalid.tag.b48:
  call void @abort()
  unreachable
bb49:
  br label %bb7
bb50:
  br label %bb48
bb51:
  %v501 = phi ptr [ %v473, %bb52 ], [ %v473, %bb53 ]
  %v502 = phi ptr [ %v474, %bb52 ], [ %v474, %bb53 ]
  %v503 = phi i64 [ %v475, %bb52 ], [ %v475, %bb53 ]
  %v504 = phi ptr [ %v476, %bb52 ], [ %v476, %bb53 ]
  %v505 = phi i64 [ %v477, %bb52 ], [ %v477, %bb53 ]
  %v506 = phi i64 [ %v478, %bb52 ], [ %v478, %bb53 ]
  %v507 = phi i64 [ %v479, %bb52 ], [ %v479, %bb53 ]
  %v508 = phi i64 [ %v480, %bb52 ], [ %v480, %bb53 ]
  %v509 = phi i64 [ %v499, %bb52 ], [ %v527, %bb53 ]
  %v510 = phi i64 [ %v498, %bb52 ], [ %v498, %bb53 ]
  %v511 = phi i64 [ %v483, %bb52 ], [ %v483, %bb53 ]
  %v512 = phi i64 [ %v484, %bb52 ], [ %v484, %bb53 ]
  %v513 = phi i64 [ %v485, %bb52 ], [ %v485, %bb53 ]
  %v514 = phi i64 [ %v486, %bb52 ], [ %v486, %bb53 ]
  %v515 = phi i64 [ %v487, %bb52 ], [ %v487, %bb53 ]
  %v516 = phi i64 [ %v488, %bb52 ], [ %v488, %bb53 ]
  %v517 = phi i64 [ %v489, %bb52 ], [ %v489, %bb53 ]
  %v518 = phi i64 [ %v490, %bb52 ], [ %v490, %bb53 ]
  %v519 = phi i64 [ %v491, %bb52 ], [ %v491, %bb53 ]
  %v520 = phi i64 [ %v492, %bb52 ], [ %v492, %bb53 ]
  %v521 = phi i64 [ %v493, %bb52 ], [ %v493, %bb53 ]
  %v522 = phi i64 [ %v494, %bb52 ], [ %v494, %bb53 ]
  %v523 = phi i64 [ %v495, %bb52 ], [ %v495, %bb53 ]
  %v524 = phi i64 [ %v496, %bb52 ], [ %v496, %bb53 ]
  %v525 = phi i64 [ %v497, %bb52 ], [ %v497, %bb53 ]
  %v526 = phi i64 [ %v499, %bb52 ], [ %v499, %bb53 ]
  br label %bb54
bb52:
  br label %bb51
bb53:
  %v527 = select i1 true, i64 0, i64 0
  br label %bb51
bb54:
  %v528 = phi ptr [ %v501, %bb51 ]
  %v529 = phi ptr [ %v502, %bb51 ]
  %v530 = phi i64 [ %v503, %bb51 ]
  %v531 = phi ptr [ %v504, %bb51 ]
  %v532 = phi i64 [ %v505, %bb51 ]
  %v533 = phi i64 [ %v506, %bb51 ]
  %v534 = phi i64 [ %v507, %bb51 ]
  %v535 = phi i64 [ %v508, %bb51 ]
  %v536 = phi i64 [ %v509, %bb51 ]
  %v537 = phi i64 [ %v510, %bb51 ]
  %v538 = phi i64 [ %v32, %bb51 ]
  %v539 = phi i64 [ %v33, %bb51 ]
  %v540 = phi i64 [ %v34, %bb51 ]
  %v541 = select i1 true, i64 1, i64 1
  %v542 = add i64 %v540, %v541
  br label %bb4
bb55:
  %v544 = phi ptr [ %v12, %bb57 ], [ %v556, %bb58 ]
  %v545 = phi ptr [ %v13, %bb57 ], [ %v557, %bb58 ]
  %v546 = phi i64 [ %v14, %bb57 ], [ %v558, %bb58 ]
  %v547 = phi ptr [ %v15, %bb57 ], [ %v559, %bb58 ]
  %v548 = phi i64 [ %v16, %bb57 ], [ %v560, %bb58 ]
  %v549 = phi i64 [ %v17, %bb57 ], [ %v561, %bb58 ]
  %v550 = phi i64 [ %v18, %bb57 ], [ %v562, %bb58 ]
  %v551 = phi i64 [ %v19, %bb57 ], [ %v563, %bb58 ]
  %v587 = load i64, ptr %v545
  store %wf.t.09071440a409e980 zeroinitializer, ptr %wf.slot.1
  %t10 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.1, i32 0, i32 0
  store i64 %v587, ptr %t10
  %t11 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.1, i32 0, i32 1
  store i64 %v546, ptr %t11
  %v589 = or i1 0, 1
  store %wf.t.ac5891a387b8aafe zeroinitializer, ptr %wf.result
  %t12 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t12
  %t13 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 1
  store i1 %v589, ptr %t13
  %t14 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr (%wf.t.09071440a409e980, ptr null, i32 1) to i64), i1 false)
  ret void
bb56:
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v12, i64 ptrtoint (ptr getelementptr (%wf.t.2758c7c2b3b908fb, ptr null, i32 1) to i64), i1 false)
  %t15 = getelementptr inbounds %wf.t.2758c7c2b3b908fb, ptr %wf.slot.0, i32 0, i32 1
  %v553 = load i64, ptr %t15
  %v554 = select i1 true, i64 3, i64 3
  %v555 = icmp ult i64 %v553, %v554
  switch i1 %v555, label %invalid.tag.b56 [
    i1 1, label %bb59
    i1 0, label %bb60
  ]
invalid.tag.b56:
  call void @abort()
  unreachable
bb57:
  br label %bb55
bb58:
  %v556 = phi ptr [ %v12, %bb60 ]
  %v557 = phi ptr [ %v13, %bb60 ]
  %v558 = phi i64 [ %v14, %bb60 ]
  %v559 = phi ptr [ %v15, %bb60 ]
  %v560 = phi i64 [ %v16, %bb60 ]
  %v561 = phi i64 [ %v17, %bb60 ]
  %v562 = phi i64 [ %v18, %bb60 ]
  %v563 = phi i64 [ %v19, %bb60 ]
  %v564 = phi i64 [ %v553, %bb60 ]
  br label %bb55
bb59:
  %t16 = getelementptr inbounds %wf.t.2758c7c2b3b908fb, ptr %v12, i32 0, i32 0
  %v565 = getelementptr i8, ptr %t16, i64 0
  %v566 = load i64, ptr %v13
  call void @wf_hash_map.hash_map_exchange$instance$0ed342445dd803f3(ptr %v568, ptr %v565, i64 %v19, i64 %v566, i64 %v14)
  %t17 = getelementptr inbounds %wf.t.2758c7c2b3b908fb, ptr %v12, i32 0, i32 2
  %v569 = getelementptr i8, ptr %t17, i64 0
  %v570 = call i8 @wf_hash_map.hash_map_control_set(ptr %v569, i64 %v19, i64 %v17)
  %v571 = call i1 @wf_hash_map.hash_map_control_inserted$instance$0ed342445dd803f3(ptr %v568)
  switch i1 %v571, label %invalid.tag.b59 [
    i1 1, label %bb62
    i1 0, label %bb63
  ]
invalid.tag.b59:
  call void @abort()
  unreachable
bb60:
  br label %bb58
bb61:
  %v572 = phi ptr [ %v12, %bb62 ], [ %v12, %bb63 ]
  %v573 = phi ptr [ %v13, %bb62 ], [ %v13, %bb63 ]
  %v574 = phi i64 [ %v14, %bb62 ], [ %v14, %bb63 ]
  %v575 = phi ptr [ %v15, %bb62 ], [ %v15, %bb63 ]
  %v576 = phi i64 [ %v16, %bb62 ], [ %v16, %bb63 ]
  %v577 = phi i64 [ %v17, %bb62 ], [ %v17, %bb63 ]
  %v578 = phi i64 [ %v18, %bb62 ], [ %v18, %bb63 ]
  %v579 = phi i64 [ %v19, %bb62 ], [ %v19, %bb63 ]
  %v580 = phi i64 [ %v553, %bb62 ], [ %v553, %bb63 ]
  %v581 = phi ptr [ %v568, %bb62 ], [ %v568, %bb63 ]
  %v582 = phi i1 [ %v571, %bb62 ], [ %v571, %bb63 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.result, ptr %v581, i64 ptrtoint (ptr getelementptr (%wf.t.ac5891a387b8aafe, ptr null, i32 1) to i64), i1 false)
  ret void
bb62:
  %t18 = getelementptr inbounds %wf.t.2758c7c2b3b908fb, ptr %v12, i32 0, i32 1
  %v583 = getelementptr i8, ptr %t18, i64 0
  %v584 = select i1 true, i64 1, i64 1
  %v585 = add nuw i64 %v553, %v584
  store i64 %v585, ptr %v583
  br label %bb61
bb63:
  br label %bb61
}

define internal void @wf_hash_map.hash_map_reserve$instance$c7b22b9ef52855b6.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %v3 = select i1 true, i64 3, i64 3
  %v4 = icmp ugt i64 %v1, %v3
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v5 = phi ptr [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb3 ]
  %v7 = phi ptr [ %v2, %bb3 ]
  %t0 = getelementptr inbounds %wf.t.2758c7c2b3b908fb, ptr %v5, i32 0, i32 0
  %v10 = getelementptr i8, ptr %t0, i64 0
  %v11 = getelementptr i8, ptr %v10, i64 0
  %t2 = load ptr, ptr %v11
  %t3 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t2, i32 0, i32 0
  %t1 = load i64, ptr %t3
  %v12 = add i64 %t1, 0
  %v13 = icmp ule i64 %v6, %v12
  switch i1 %v13, label %invalid.tag.b1 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v8 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t4 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t4
  %t5 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 2
  store i8 %v8, ptr %t5
  ret void
bb3:
  br label %bb1
bb4:
  %v14 = phi ptr [ %v5, %bb6 ]
  %v15 = phi i64 [ %v6, %bb6 ]
  %v16 = phi ptr [ %v7, %bb6 ]
  %v19 = call %wf.t.7d7f918f7b4962fd @wf_hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6(ptr %v14, i64 %v15, ptr %v16)
  store %wf.t.7d7f918f7b4962fd %v19, ptr %wf.result
  ret void
bb5:
  %v17 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t6 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t6
  %t7 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 1
  store i8 %v17, ptr %t7
  ret void
bb6:
  br label %bb4
}

define %wf.t.7d7f918f7b4962fd @wf_hash_map.hash_map_reserve$instance$c7b22b9ef52855b6(ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.result = alloca %wf.t.7d7f918f7b4962fd, align 4
  call void @wf_hash_map.hash_map_reserve$instance$c7b22b9ef52855b6.body(ptr %wf.result, ptr %v0, i64 %v1, ptr %v2)
  %wf.returned = load %wf.t.7d7f918f7b4962fd, ptr %wf.result
  ret %wf.t.7d7f918f7b4962fd %wf.returned
}

define i8 @wf_hash_map.hash_map_extend$instance$820b2044b97e0fbd(ptr noalias nonnull captures(none) dereferenceable(8) %v0, i64 %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.eb423fc38cfed56f, align 8
  %v2 = getelementptr i8, ptr %v0, i64 0
  %t1 = load ptr, ptr %v2
  %t2 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t1, i32 0, i32 1
  %t0 = load i64, ptr %t2
  %v3 = add i64 %t0, 0
  %v4 = icmp ult i64 %v3, %v1
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v5 = phi ptr [ %v0, %bb2 ], [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb2 ], [ %v1, %bb3 ]
  %v8 = getelementptr i8, ptr %v5, i64 0
  %t4 = load ptr, ptr %v8
  %t5 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t4, i32 0, i32 0
  %t3 = load i64, ptr %t5
  %v9 = add i64 %t3, 0
  br label %bb4
bb2:
  %v7 = call i8 @wf_grow$instance$087f541e70b769ea(ptr %v0, i64 %v1)
  br label %bb1
bb3:
  br label %bb1
bb4:
  %v10 = phi ptr [ %v5, %bb1 ], [ %v23, %bb8 ]
  %v11 = phi i64 [ %v6, %bb1 ], [ %v24, %bb8 ]
  %v12 = phi i64 [ %v9, %bb1 ], [ %v25, %bb8 ]
  %v13 = phi i64 [ %v9, %bb1 ], [ %v26, %bb8 ]
  %v14 = phi i64 [ %v6, %bb1 ], [ %v27, %bb8 ]
  %v15 = phi i64 [ %v9, %bb1 ], [ %v30, %bb8 ]
  %v19 = icmp ult i64 %v15, %v14
  switch i1 %v19, label %invalid.tag.b4 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b4:
  call void @abort()
  unreachable
bb5:
  store %wf.t.eb423fc38cfed56f zeroinitializer, ptr %wf.slot.0
  %t6 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %wf.slot.0, i32 0, i32 0
  store i32 0, ptr %t6
  %v21 = getelementptr i8, ptr %v10, i64 0
  %v22 = call i8 @wf_place_back$instance$20364da1adbcdc5f(ptr %v21, ptr %wf.slot.0)
  br label %bb8
bb6:
  br label %bb7
bb7:
  %v16 = phi ptr [ %v10, %bb6 ]
  %v17 = phi i64 [ %v11, %bb6 ]
  %v18 = phi i64 [ %v12, %bb6 ]
  %v31 = select i1 true, i8 0, i8 0
  ret i8 %v31
bb8:
  %v23 = phi ptr [ %v10, %bb5 ]
  %v24 = phi i64 [ %v11, %bb5 ]
  %v25 = phi i64 [ %v12, %bb5 ]
  %v26 = phi i64 [ %v13, %bb5 ]
  %v27 = phi i64 [ %v14, %bb5 ]
  %v28 = phi i64 [ %v15, %bb5 ]
  %v29 = select i1 true, i64 1, i64 1
  %v30 = add i64 %v28, %v29
  br label %bb4
}

define internal void @wf_hash_map.hash_map_controls_new$instance$fd5e04af5c7e1250.body(ptr %wf.result, i64 %v0) #0 {
entry:
  %wf.slot.0 = alloca { i64, [1 x ptr] }, align 8
  %v3 = alloca { i64, [1 x ptr] }, align 8
  %v1 = select i1 true, i64 9259542123273814144, i64 9259542123273814144
  %v2 = call { i64, [1 x ptr] } @wf_slots_new$instance$bc7a70143afe699c()
  store { i64, [1 x ptr] } %v2, ptr %v3
  %v4 = select i1 true, i64 8, i64 8
  %v5 = icmp ugt i64 %v0, %v4
  switch i1 %v5, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v6 = phi i64 [ %v0, %bb2 ], [ %v0, %bb3 ]
  %v7 = phi i64 [ %v1, %bb2 ], [ %v1, %bb3 ]
  %v8 = phi ptr [ %v3, %bb2 ], [ %v3, %bb3 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v8, i64 ptrtoint (ptr getelementptr ({ i64, [1 x ptr] }, ptr null, i32 1) to i64), i1 false)
  store %wf.t.b5efdacbe94e5739 zeroinitializer, ptr %wf.result
  %t0 = getelementptr inbounds %wf.t.b5efdacbe94e5739, ptr %wf.result, i32 0, i32 0
  store i64 %v7, ptr %t0
  %t1 = getelementptr inbounds %wf.t.b5efdacbe94e5739, ptr %wf.result, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr ({ i64, [1 x ptr] }, ptr null, i32 1) to i64), i1 false)
  ret void
bb2:
  %v9 = select i1 true, i64 8, i64 8
  %v10 = udiv i64 %v0, %v9
  %v11 = call ptr @wf_box_array_filled$instance$e194368921a477a7(i64 %v10, i64 %v1)
  %v12 = call i8 @wf_place_back$instance$38dd27730d5cd43b(ptr %v3, ptr %v11)
  br label %bb1
bb3:
  br label %bb1
}

define %wf.t.b5efdacbe94e5739 @wf_hash_map.hash_map_controls_new$instance$fd5e04af5c7e1250(i64 %v0) #0 {
entry:
  %wf.result = alloca %wf.t.b5efdacbe94e5739, align 8
  call void @wf_hash_map.hash_map_controls_new$instance$fd5e04af5c7e1250.body(ptr %wf.result, i64 %v0)
  %wf.returned = load %wf.t.b5efdacbe94e5739, ptr %wf.result
  ret %wf.t.b5efdacbe94e5739 %wf.returned
}

define void @wf_hash_map.hash_map_try_put$instance$fde7c6722a8b0dad(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, i64 %v2, ptr noalias nonnull captures(none) dereferenceable(16) %v3) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.7748a5b0f0193f4a, align 8
  %wf.slot.1 = alloca %wf.t.09071440a409e980, align 8
  %v4 = alloca i64, align 8
  %v568 = alloca %wf.t.ac5891a387b8aafe, align 8
  store i64 %v1, ptr %v4
  %v5 = call i64 @wf_map_cost_hash(ptr %v3, ptr %v4)
  %v6 = call i64 @wf_hash_map.hash_map_control_fingerprint(i64 %v5)
  %t0 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v0, i32 0, i32 0
  %v7 = getelementptr i8, ptr %t0, i64 0
  %v8 = getelementptr i8, ptr %v7, i64 0
  %t2 = load ptr, ptr %v8
  %t3 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t2, i32 0, i32 0
  %t1 = load i64, ptr %t3
  %v9 = add i64 %t1, 0
  %v10 = select i1 true, i64 0, i64 0
  %v11 = icmp ugt i64 %v9, %v10
  switch i1 %v11, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v12 = phi ptr [ %v0, %bb3 ], [ %v35, %bb7 ]
  %v13 = phi ptr [ %v4, %bb3 ], [ %v36, %bb7 ]
  %v14 = phi i64 [ %v2, %bb3 ], [ %v37, %bb7 ]
  %v15 = phi ptr [ %v3, %bb3 ], [ %v38, %bb7 ]
  %v16 = phi i64 [ %v5, %bb3 ], [ %v39, %bb7 ]
  %v17 = phi i64 [ %v6, %bb3 ], [ %v40, %bb7 ]
  %v18 = phi i64 [ %v9, %bb3 ], [ %v41, %bb7 ]
  %v19 = phi i64 [ %v9, %bb3 ], [ %v42, %bb7 ]
  %v543 = icmp ult i64 %v19, %v18
  switch i1 %v543, label %invalid.tag.b1 [
    i1 1, label %bb56
    i1 0, label %bb57
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v20 = urem i64 %v5, %v9
  %v21 = select i1 true, i64 0, i64 0
  br label %bb4
bb3:
  br label %bb1
bb4:
  %v22 = phi ptr [ %v0, %bb2 ], [ %v528, %bb54 ]
  %v23 = phi ptr [ %v4, %bb2 ], [ %v529, %bb54 ]
  %v24 = phi i64 [ %v2, %bb2 ], [ %v530, %bb54 ]
  %v25 = phi ptr [ %v3, %bb2 ], [ %v531, %bb54 ]
  %v26 = phi i64 [ %v5, %bb2 ], [ %v532, %bb54 ]
  %v27 = phi i64 [ %v6, %bb2 ], [ %v533, %bb54 ]
  %v28 = phi i64 [ %v9, %bb2 ], [ %v534, %bb54 ]
  %v29 = phi i64 [ %v9, %bb2 ], [ %v535, %bb54 ]
  %v30 = phi i64 [ %v20, %bb2 ], [ %v536, %bb54 ]
  %v31 = phi i64 [ %v9, %bb2 ], [ %v537, %bb54 ]
  %v32 = phi i64 [ %v21, %bb2 ], [ %v538, %bb54 ]
  %v33 = phi i64 [ %v9, %bb2 ], [ %v539, %bb54 ]
  %v34 = phi i64 [ %v21, %bb2 ], [ %v542, %bb54 ]
  %v45 = icmp ult i64 %v34, %v33
  switch i1 %v45, label %invalid.tag.b4 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b4:
  call void @abort()
  unreachable
bb5:
  %v46 = select i1 true, i64 0, i64 0
  %v47 = icmp eq i64 %v31, %v46
  switch i1 %v47, label %invalid.tag.b5 [
    i1 1, label %bb9
    i1 0, label %bb10
  ]
invalid.tag.b5:
  call void @abort()
  unreachable
bb6:
  br label %bb7
bb7:
  %v35 = phi ptr [ %v22, %bb6 ], [ %v22, %bb9 ], [ %v219, %bb49 ]
  %v36 = phi ptr [ %v23, %bb6 ], [ %v23, %bb9 ], [ %v220, %bb49 ]
  %v37 = phi i64 [ %v24, %bb6 ], [ %v24, %bb9 ], [ %v221, %bb49 ]
  %v38 = phi ptr [ %v25, %bb6 ], [ %v25, %bb9 ], [ %v222, %bb49 ]
  %v39 = phi i64 [ %v26, %bb6 ], [ %v26, %bb9 ], [ %v223, %bb49 ]
  %v40 = phi i64 [ %v27, %bb6 ], [ %v27, %bb9 ], [ %v224, %bb49 ]
  %v41 = phi i64 [ %v28, %bb6 ], [ %v28, %bb9 ], [ %v225, %bb49 ]
  %v42 = phi i64 [ %v29, %bb6 ], [ %v29, %bb9 ], [ %v226, %bb49 ]
  %v43 = phi i64 [ %v30, %bb6 ], [ %v30, %bb9 ], [ %v227, %bb49 ]
  %v44 = phi i64 [ %v31, %bb6 ], [ %v31, %bb9 ], [ %v228, %bb49 ]
  br label %bb1
bb8:
  %v48 = phi ptr [ %v22, %bb10 ]
  %v49 = phi ptr [ %v23, %bb10 ]
  %v50 = phi i64 [ %v24, %bb10 ]
  %v51 = phi ptr [ %v25, %bb10 ]
  %v52 = phi i64 [ %v26, %bb10 ]
  %v53 = phi i64 [ %v27, %bb10 ]
  %v54 = phi i64 [ %v28, %bb10 ]
  %v55 = phi i64 [ %v29, %bb10 ]
  %v56 = phi i64 [ %v30, %bb10 ]
  %v57 = phi i64 [ %v31, %bb10 ]
  %v58 = phi i64 [ %v34, %bb10 ]
  %v59 = select i1 true, i64 8, i64 8
  %v60 = urem i64 %v56, %v59
  %v61 = sub nuw i64 %v54, %v56
  %v62 = call i64 @wf_hash_map.hash_map_control_span(i64 %v60, i64 %v61, i64 %v57)
  %v63 = select i1 true, i64 8, i64 8
  %v64 = udiv i64 %v56, %v63
  %t4 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v48, i32 0, i32 2
  %v65 = getelementptr i8, ptr %t4, i64 0
  %v66 = call i64 @wf_hash_map.hash_map_control_word(ptr %v65, i64 %v64)
  %v67 = call i64 @wf_hash_map.hash_map_control_active(i64 %v60, i64 %v62)
  %v68 = call i64 @wf_hash_map.hash_map_control_equal(i64 %v66, i64 %v53)
  %v69 = and i64 %v68, %v67
  %v70 = select i1 true, i64 128, i64 128
  %v71 = call i64 @wf_hash_map.hash_map_control_equal(i64 %v66, i64 %v70)
  %v72 = and i64 %v71, %v67
  %v73 = select i1 true, i64 254, i64 254
  %v74 = call i64 @wf_hash_map.hash_map_control_equal(i64 %v66, i64 %v73)
  %v75 = and i64 %v74, %v67
  %v76 = or i64 %v72, %v75
  %v77 = call i64 @wf_hash_map.hash_map_control_stop(i64 %v72, i64 %v60, i64 %v62)
  %v78 = icmp eq i64 %v55, %v54
  switch i1 %v78, label %invalid.tag.b8 [
    i1 1, label %bb12
    i1 0, label %bb13
  ]
invalid.tag.b8:
  call void @abort()
  unreachable
bb9:
  br label %bb7
bb10:
  br label %bb8
bb11:
  %v79 = phi ptr [ %v48, %bb13 ], [ %v106, %bb14 ]
  %v80 = phi ptr [ %v49, %bb13 ], [ %v107, %bb14 ]
  %v81 = phi i64 [ %v50, %bb13 ], [ %v108, %bb14 ]
  %v82 = phi ptr [ %v51, %bb13 ], [ %v109, %bb14 ]
  %v83 = phi i64 [ %v52, %bb13 ], [ %v110, %bb14 ]
  %v84 = phi i64 [ %v53, %bb13 ], [ %v111, %bb14 ]
  %v85 = phi i64 [ %v54, %bb13 ], [ %v112, %bb14 ]
  %v86 = phi i64 [ %v55, %bb13 ], [ %v113, %bb14 ]
  %v87 = phi i64 [ %v56, %bb13 ], [ %v114, %bb14 ]
  %v88 = phi i64 [ %v57, %bb13 ], [ %v115, %bb14 ]
  %v89 = phi i64 [ %v58, %bb13 ], [ %v116, %bb14 ]
  %v90 = phi i64 [ %v60, %bb13 ], [ %v117, %bb14 ]
  %v91 = phi i64 [ %v61, %bb13 ], [ %v118, %bb14 ]
  %v92 = phi i64 [ %v62, %bb13 ], [ %v119, %bb14 ]
  %v93 = phi i64 [ %v64, %bb13 ], [ %v120, %bb14 ]
  %v94 = phi i64 [ %v66, %bb13 ], [ %v121, %bb14 ]
  %v95 = phi i64 [ %v67, %bb13 ], [ %v122, %bb14 ]
  %v96 = phi i64 [ %v68, %bb13 ], [ %v123, %bb14 ]
  %v97 = phi i64 [ %v69, %bb13 ], [ %v124, %bb14 ]
  %v98 = phi i64 [ %v71, %bb13 ], [ %v125, %bb14 ]
  %v99 = phi i64 [ %v72, %bb13 ], [ %v126, %bb14 ]
  %v100 = phi i64 [ %v74, %bb13 ], [ %v127, %bb14 ]
  %v101 = phi i64 [ %v75, %bb13 ], [ %v128, %bb14 ]
  %v102 = phi i64 [ %v76, %bb13 ], [ %v129, %bb14 ]
  %v103 = phi i64 [ %v77, %bb13 ], [ %v130, %bb14 ]
  %v189 = select i1 true, i64 0, i64 0
  %v190 = select i1 true, i64 8, i64 8
  br label %bb23
bb12:
  %v104 = select i1 true, i64 0, i64 0
  %v105 = icmp ugt i64 %v76, %v104
  switch i1 %v105, label %invalid.tag.b12 [
    i1 1, label %bb15
    i1 0, label %bb16
  ]
invalid.tag.b12:
  call void @abort()
  unreachable
bb13:
  br label %bb11
bb14:
  %v106 = phi ptr [ %v48, %bb16 ], [ %v133, %bb17 ]
  %v107 = phi ptr [ %v49, %bb16 ], [ %v134, %bb17 ]
  %v108 = phi i64 [ %v50, %bb16 ], [ %v135, %bb17 ]
  %v109 = phi ptr [ %v51, %bb16 ], [ %v136, %bb17 ]
  %v110 = phi i64 [ %v52, %bb16 ], [ %v137, %bb17 ]
  %v111 = phi i64 [ %v53, %bb16 ], [ %v138, %bb17 ]
  %v112 = phi i64 [ %v54, %bb16 ], [ %v139, %bb17 ]
  %v113 = phi i64 [ %v55, %bb16 ], [ %v140, %bb17 ]
  %v114 = phi i64 [ %v56, %bb16 ], [ %v141, %bb17 ]
  %v115 = phi i64 [ %v57, %bb16 ], [ %v142, %bb17 ]
  %v116 = phi i64 [ %v58, %bb16 ], [ %v143, %bb17 ]
  %v117 = phi i64 [ %v60, %bb16 ], [ %v144, %bb17 ]
  %v118 = phi i64 [ %v61, %bb16 ], [ %v145, %bb17 ]
  %v119 = phi i64 [ %v62, %bb16 ], [ %v146, %bb17 ]
  %v120 = phi i64 [ %v64, %bb16 ], [ %v147, %bb17 ]
  %v121 = phi i64 [ %v66, %bb16 ], [ %v148, %bb17 ]
  %v122 = phi i64 [ %v67, %bb16 ], [ %v149, %bb17 ]
  %v123 = phi i64 [ %v68, %bb16 ], [ %v150, %bb17 ]
  %v124 = phi i64 [ %v69, %bb16 ], [ %v151, %bb17 ]
  %v125 = phi i64 [ %v71, %bb16 ], [ %v152, %bb17 ]
  %v126 = phi i64 [ %v72, %bb16 ], [ %v153, %bb17 ]
  %v127 = phi i64 [ %v74, %bb16 ], [ %v154, %bb17 ]
  %v128 = phi i64 [ %v75, %bb16 ], [ %v155, %bb17 ]
  %v129 = phi i64 [ %v76, %bb16 ], [ %v156, %bb17 ]
  %v130 = phi i64 [ %v77, %bb16 ], [ %v157, %bb17 ]
  br label %bb11
bb15:
  %v131 = call i64 @wf_hash_map.hash_map_control_first(i64 %v76)
  %v132 = icmp uge i64 %v131, %v60
  switch i1 %v132, label %invalid.tag.b15 [
    i1 1, label %bb18
    i1 0, label %bb19
  ]
invalid.tag.b15:
  call void @abort()
  unreachable
bb16:
  br label %bb14
bb17:
  %v133 = phi ptr [ %v48, %bb19 ], [ %v161, %bb20 ]
  %v134 = phi ptr [ %v49, %bb19 ], [ %v162, %bb20 ]
  %v135 = phi i64 [ %v50, %bb19 ], [ %v163, %bb20 ]
  %v136 = phi ptr [ %v51, %bb19 ], [ %v164, %bb20 ]
  %v137 = phi i64 [ %v52, %bb19 ], [ %v165, %bb20 ]
  %v138 = phi i64 [ %v53, %bb19 ], [ %v166, %bb20 ]
  %v139 = phi i64 [ %v54, %bb19 ], [ %v167, %bb20 ]
  %v140 = phi i64 [ %v55, %bb19 ], [ %v168, %bb20 ]
  %v141 = phi i64 [ %v56, %bb19 ], [ %v169, %bb20 ]
  %v142 = phi i64 [ %v57, %bb19 ], [ %v170, %bb20 ]
  %v143 = phi i64 [ %v58, %bb19 ], [ %v171, %bb20 ]
  %v144 = phi i64 [ %v60, %bb19 ], [ %v172, %bb20 ]
  %v145 = phi i64 [ %v61, %bb19 ], [ %v173, %bb20 ]
  %v146 = phi i64 [ %v62, %bb19 ], [ %v174, %bb20 ]
  %v147 = phi i64 [ %v64, %bb19 ], [ %v175, %bb20 ]
  %v148 = phi i64 [ %v66, %bb19 ], [ %v176, %bb20 ]
  %v149 = phi i64 [ %v67, %bb19 ], [ %v177, %bb20 ]
  %v150 = phi i64 [ %v68, %bb19 ], [ %v178, %bb20 ]
  %v151 = phi i64 [ %v69, %bb19 ], [ %v179, %bb20 ]
  %v152 = phi i64 [ %v71, %bb19 ], [ %v180, %bb20 ]
  %v153 = phi i64 [ %v72, %bb19 ], [ %v181, %bb20 ]
  %v154 = phi i64 [ %v74, %bb19 ], [ %v182, %bb20 ]
  %v155 = phi i64 [ %v75, %bb19 ], [ %v183, %bb20 ]
  %v156 = phi i64 [ %v76, %bb19 ], [ %v184, %bb20 ]
  %v157 = phi i64 [ %v77, %bb19 ], [ %v185, %bb20 ]
  %v158 = phi i64 [ %v131, %bb19 ], [ %v186, %bb20 ]
  br label %bb14
bb18:
  %v159 = sub nuw i64 %v131, %v60
  %v160 = icmp ult i64 %v159, %v62
  switch i1 %v160, label %invalid.tag.b18 [
    i1 1, label %bb21
    i1 0, label %bb22
  ]
invalid.tag.b18:
  call void @abort()
  unreachable
bb19:
  br label %bb17
bb20:
  %v161 = phi ptr [ %v48, %bb21 ], [ %v48, %bb22 ]
  %v162 = phi ptr [ %v49, %bb21 ], [ %v49, %bb22 ]
  %v163 = phi i64 [ %v50, %bb21 ], [ %v50, %bb22 ]
  %v164 = phi ptr [ %v51, %bb21 ], [ %v51, %bb22 ]
  %v165 = phi i64 [ %v52, %bb21 ], [ %v52, %bb22 ]
  %v166 = phi i64 [ %v53, %bb21 ], [ %v53, %bb22 ]
  %v167 = phi i64 [ %v54, %bb21 ], [ %v54, %bb22 ]
  %v168 = phi i64 [ %v188, %bb21 ], [ %v55, %bb22 ]
  %v169 = phi i64 [ %v56, %bb21 ], [ %v56, %bb22 ]
  %v170 = phi i64 [ %v57, %bb21 ], [ %v57, %bb22 ]
  %v171 = phi i64 [ %v58, %bb21 ], [ %v58, %bb22 ]
  %v172 = phi i64 [ %v60, %bb21 ], [ %v60, %bb22 ]
  %v173 = phi i64 [ %v61, %bb21 ], [ %v61, %bb22 ]
  %v174 = phi i64 [ %v62, %bb21 ], [ %v62, %bb22 ]
  %v175 = phi i64 [ %v64, %bb21 ], [ %v64, %bb22 ]
  %v176 = phi i64 [ %v66, %bb21 ], [ %v66, %bb22 ]
  %v177 = phi i64 [ %v67, %bb21 ], [ %v67, %bb22 ]
  %v178 = phi i64 [ %v68, %bb21 ], [ %v68, %bb22 ]
  %v179 = phi i64 [ %v69, %bb21 ], [ %v69, %bb22 ]
  %v180 = phi i64 [ %v71, %bb21 ], [ %v71, %bb22 ]
  %v181 = phi i64 [ %v72, %bb21 ], [ %v72, %bb22 ]
  %v182 = phi i64 [ %v74, %bb21 ], [ %v74, %bb22 ]
  %v183 = phi i64 [ %v75, %bb21 ], [ %v75, %bb22 ]
  %v184 = phi i64 [ %v76, %bb21 ], [ %v76, %bb22 ]
  %v185 = phi i64 [ %v77, %bb21 ], [ %v77, %bb22 ]
  %v186 = phi i64 [ %v131, %bb21 ], [ %v131, %bb22 ]
  %v187 = phi i64 [ %v159, %bb21 ], [ %v159, %bb22 ]
  br label %bb17
bb21:
  %v188 = add nuw i64 %v56, %v159
  br label %bb20
bb22:
  br label %bb20
bb23:
  %v191 = phi ptr [ %v79, %bb11 ], [ %v442, %bb47 ]
  %v192 = phi ptr [ %v80, %bb11 ], [ %v443, %bb47 ]
  %v193 = phi i64 [ %v81, %bb11 ], [ %v444, %bb47 ]
  %v194 = phi ptr [ %v82, %bb11 ], [ %v445, %bb47 ]
  %v195 = phi i64 [ %v83, %bb11 ], [ %v446, %bb47 ]
  %v196 = phi i64 [ %v84, %bb11 ], [ %v447, %bb47 ]
  %v197 = phi i64 [ %v85, %bb11 ], [ %v448, %bb47 ]
  %v198 = phi i64 [ %v86, %bb11 ], [ %v449, %bb47 ]
  %v199 = phi i64 [ %v87, %bb11 ], [ %v450, %bb47 ]
  %v200 = phi i64 [ %v88, %bb11 ], [ %v451, %bb47 ]
  %v201 = phi i64 [ %v89, %bb11 ], [ %v452, %bb47 ]
  %v202 = phi i64 [ %v90, %bb11 ], [ %v453, %bb47 ]
  %v203 = phi i64 [ %v91, %bb11 ], [ %v454, %bb47 ]
  %v204 = phi i64 [ %v92, %bb11 ], [ %v455, %bb47 ]
  %v205 = phi i64 [ %v93, %bb11 ], [ %v456, %bb47 ]
  %v206 = phi i64 [ %v94, %bb11 ], [ %v457, %bb47 ]
  %v207 = phi i64 [ %v95, %bb11 ], [ %v458, %bb47 ]
  %v208 = phi i64 [ %v96, %bb11 ], [ %v459, %bb47 ]
  %v209 = phi i64 [ %v97, %bb11 ], [ %v460, %bb47 ]
  %v210 = phi i64 [ %v98, %bb11 ], [ %v461, %bb47 ]
  %v211 = phi i64 [ %v99, %bb11 ], [ %v462, %bb47 ]
  %v212 = phi i64 [ %v100, %bb11 ], [ %v463, %bb47 ]
  %v213 = phi i64 [ %v101, %bb11 ], [ %v464, %bb47 ]
  %v214 = phi i64 [ %v102, %bb11 ], [ %v465, %bb47 ]
  %v215 = phi i64 [ %v103, %bb11 ], [ %v466, %bb47 ]
  %v216 = phi i64 [ %v189, %bb11 ], [ %v467, %bb47 ]
  %v217 = phi i64 [ %v190, %bb11 ], [ %v468, %bb47 ]
  %v218 = phi i64 [ %v189, %bb11 ], [ %v471, %bb47 ]
  %v244 = icmp ult i64 %v218, %v217
  switch i1 %v244, label %invalid.tag.b23 [
    i1 1, label %bb24
    i1 0, label %bb25
  ]
invalid.tag.b23:
  call void @abort()
  unreachable
bb24:
  %v245 = select i1 true, i64 0, i64 0
  %v246 = icmp eq i64 %v209, %v245
  switch i1 %v246, label %invalid.tag.b24 [
    i1 1, label %bb28
    i1 0, label %bb29
  ]
invalid.tag.b24:
  call void @abort()
  unreachable
bb25:
  br label %bb26
bb26:
  %v219 = phi ptr [ %v191, %bb25 ], [ %v191, %bb28 ], [ %v379, %bb41 ]
  %v220 = phi ptr [ %v192, %bb25 ], [ %v192, %bb28 ], [ %v380, %bb41 ]
  %v221 = phi i64 [ %v193, %bb25 ], [ %v193, %bb28 ], [ %v381, %bb41 ]
  %v222 = phi ptr [ %v194, %bb25 ], [ %v194, %bb28 ], [ %v382, %bb41 ]
  %v223 = phi i64 [ %v195, %bb25 ], [ %v195, %bb28 ], [ %v383, %bb41 ]
  %v224 = phi i64 [ %v196, %bb25 ], [ %v196, %bb28 ], [ %v384, %bb41 ]
  %v225 = phi i64 [ %v197, %bb25 ], [ %v197, %bb28 ], [ %v385, %bb41 ]
  %v226 = phi i64 [ %v198, %bb25 ], [ %v198, %bb28 ], [ %v386, %bb41 ]
  %v227 = phi i64 [ %v199, %bb25 ], [ %v199, %bb28 ], [ %v387, %bb41 ]
  %v228 = phi i64 [ %v200, %bb25 ], [ %v200, %bb28 ], [ %v388, %bb41 ]
  %v229 = phi i64 [ %v201, %bb25 ], [ %v201, %bb28 ], [ %v389, %bb41 ]
  %v230 = phi i64 [ %v202, %bb25 ], [ %v202, %bb28 ], [ %v390, %bb41 ]
  %v231 = phi i64 [ %v203, %bb25 ], [ %v203, %bb28 ], [ %v391, %bb41 ]
  %v232 = phi i64 [ %v204, %bb25 ], [ %v204, %bb28 ], [ %v392, %bb41 ]
  %v233 = phi i64 [ %v205, %bb25 ], [ %v205, %bb28 ], [ %v393, %bb41 ]
  %v234 = phi i64 [ %v206, %bb25 ], [ %v206, %bb28 ], [ %v394, %bb41 ]
  %v235 = phi i64 [ %v207, %bb25 ], [ %v207, %bb28 ], [ %v395, %bb41 ]
  %v236 = phi i64 [ %v208, %bb25 ], [ %v208, %bb28 ], [ %v396, %bb41 ]
  %v237 = phi i64 [ %v209, %bb25 ], [ %v209, %bb28 ], [ %v397, %bb41 ]
  %v238 = phi i64 [ %v210, %bb25 ], [ %v210, %bb28 ], [ %v398, %bb41 ]
  %v239 = phi i64 [ %v211, %bb25 ], [ %v211, %bb28 ], [ %v399, %bb41 ]
  %v240 = phi i64 [ %v212, %bb25 ], [ %v212, %bb28 ], [ %v400, %bb41 ]
  %v241 = phi i64 [ %v213, %bb25 ], [ %v213, %bb28 ], [ %v401, %bb41 ]
  %v242 = phi i64 [ %v214, %bb25 ], [ %v214, %bb28 ], [ %v402, %bb41 ]
  %v243 = phi i64 [ %v215, %bb25 ], [ %v215, %bb28 ], [ %v407, %bb41 ]
  %v472 = icmp ult i64 %v243, %v232
  switch i1 %v472, label %invalid.tag.b26 [
    i1 1, label %bb49
    i1 0, label %bb50
  ]
invalid.tag.b26:
  call void @abort()
  unreachable
bb27:
  %v247 = phi ptr [ %v191, %bb29 ]
  %v248 = phi ptr [ %v192, %bb29 ]
  %v249 = phi i64 [ %v193, %bb29 ]
  %v250 = phi ptr [ %v194, %bb29 ]
  %v251 = phi i64 [ %v195, %bb29 ]
  %v252 = phi i64 [ %v196, %bb29 ]
  %v253 = phi i64 [ %v197, %bb29 ]
  %v254 = phi i64 [ %v198, %bb29 ]
  %v255 = phi i64 [ %v199, %bb29 ]
  %v256 = phi i64 [ %v200, %bb29 ]
  %v257 = phi i64 [ %v201, %bb29 ]
  %v258 = phi i64 [ %v202, %bb29 ]
  %v259 = phi i64 [ %v203, %bb29 ]
  %v260 = phi i64 [ %v204, %bb29 ]
  %v261 = phi i64 [ %v205, %bb29 ]
  %v262 = phi i64 [ %v206, %bb29 ]
  %v263 = phi i64 [ %v207, %bb29 ]
  %v264 = phi i64 [ %v208, %bb29 ]
  %v265 = phi i64 [ %v209, %bb29 ]
  %v266 = phi i64 [ %v210, %bb29 ]
  %v267 = phi i64 [ %v211, %bb29 ]
  %v268 = phi i64 [ %v212, %bb29 ]
  %v269 = phi i64 [ %v213, %bb29 ]
  %v270 = phi i64 [ %v214, %bb29 ]
  %v271 = phi i64 [ %v215, %bb29 ]
  %v272 = phi i64 [ %v218, %bb29 ]
  %v273 = call i64 @wf_hash_map.hash_map_control_first(i64 %v265)
  %v274 = select i1 true, i64 1, i64 1
  %v275 = sub nuw i64 %v265, %v274
  %v276 = and i64 %v265, %v275
  %v277 = icmp uge i64 %v273, %v258
  switch i1 %v277, label %invalid.tag.b27 [
    i1 1, label %bb31
    i1 0, label %bb32
  ]
invalid.tag.b27:
  call void @abort()
  unreachable
bb28:
  br label %bb26
bb29:
  br label %bb27
bb30:
  %v278 = phi ptr [ %v247, %bb32 ], [ %v308, %bb33 ]
  %v279 = phi ptr [ %v248, %bb32 ], [ %v309, %bb33 ]
  %v280 = phi i64 [ %v249, %bb32 ], [ %v310, %bb33 ]
  %v281 = phi ptr [ %v250, %bb32 ], [ %v311, %bb33 ]
  %v282 = phi i64 [ %v251, %bb32 ], [ %v312, %bb33 ]
  %v283 = phi i64 [ %v252, %bb32 ], [ %v313, %bb33 ]
  %v284 = phi i64 [ %v253, %bb32 ], [ %v314, %bb33 ]
  %v285 = phi i64 [ %v254, %bb32 ], [ %v315, %bb33 ]
  %v286 = phi i64 [ %v255, %bb32 ], [ %v316, %bb33 ]
  %v287 = phi i64 [ %v256, %bb32 ], [ %v317, %bb33 ]
  %v288 = phi i64 [ %v257, %bb32 ], [ %v318, %bb33 ]
  %v289 = phi i64 [ %v258, %bb32 ], [ %v319, %bb33 ]
  %v290 = phi i64 [ %v259, %bb32 ], [ %v320, %bb33 ]
  %v291 = phi i64 [ %v260, %bb32 ], [ %v321, %bb33 ]
  %v292 = phi i64 [ %v261, %bb32 ], [ %v322, %bb33 ]
  %v293 = phi i64 [ %v262, %bb32 ], [ %v323, %bb33 ]
  %v294 = phi i64 [ %v263, %bb32 ], [ %v324, %bb33 ]
  %v295 = phi i64 [ %v264, %bb32 ], [ %v325, %bb33 ]
  %v296 = phi i64 [ %v276, %bb32 ], [ %v326, %bb33 ]
  %v297 = phi i64 [ %v266, %bb32 ], [ %v327, %bb33 ]
  %v298 = phi i64 [ %v267, %bb32 ], [ %v328, %bb33 ]
  %v299 = phi i64 [ %v268, %bb32 ], [ %v329, %bb33 ]
  %v300 = phi i64 [ %v269, %bb32 ], [ %v330, %bb33 ]
  %v301 = phi i64 [ %v270, %bb32 ], [ %v331, %bb33 ]
  %v302 = phi i64 [ %v271, %bb32 ], [ %v332, %bb33 ]
  %v303 = phi i64 [ %v272, %bb32 ], [ %v333, %bb33 ]
  %v304 = phi i64 [ %v273, %bb32 ], [ %v334, %bb33 ]
  %v305 = phi i64 [ %v275, %bb32 ], [ %v335, %bb33 ]
  br label %bb47
bb31:
  %v306 = sub nuw i64 %v273, %v258
  %v307 = icmp ult i64 %v306, %v271
  switch i1 %v307, label %invalid.tag.b31 [
    i1 1, label %bb34
    i1 0, label %bb35
  ]
invalid.tag.b31:
  call void @abort()
  unreachable
bb32:
  br label %bb30
bb33:
  %v308 = phi ptr [ %v247, %bb35 ], [ %v342, %bb36 ]
  %v309 = phi ptr [ %v248, %bb35 ], [ %v343, %bb36 ]
  %v310 = phi i64 [ %v249, %bb35 ], [ %v344, %bb36 ]
  %v311 = phi ptr [ %v250, %bb35 ], [ %v345, %bb36 ]
  %v312 = phi i64 [ %v251, %bb35 ], [ %v346, %bb36 ]
  %v313 = phi i64 [ %v252, %bb35 ], [ %v347, %bb36 ]
  %v314 = phi i64 [ %v253, %bb35 ], [ %v348, %bb36 ]
  %v315 = phi i64 [ %v254, %bb35 ], [ %v349, %bb36 ]
  %v316 = phi i64 [ %v255, %bb35 ], [ %v350, %bb36 ]
  %v317 = phi i64 [ %v256, %bb35 ], [ %v351, %bb36 ]
  %v318 = phi i64 [ %v257, %bb35 ], [ %v352, %bb36 ]
  %v319 = phi i64 [ %v258, %bb35 ], [ %v353, %bb36 ]
  %v320 = phi i64 [ %v259, %bb35 ], [ %v354, %bb36 ]
  %v321 = phi i64 [ %v260, %bb35 ], [ %v355, %bb36 ]
  %v322 = phi i64 [ %v261, %bb35 ], [ %v356, %bb36 ]
  %v323 = phi i64 [ %v262, %bb35 ], [ %v357, %bb36 ]
  %v324 = phi i64 [ %v263, %bb35 ], [ %v358, %bb36 ]
  %v325 = phi i64 [ %v264, %bb35 ], [ %v359, %bb36 ]
  %v326 = phi i64 [ %v276, %bb35 ], [ %v360, %bb36 ]
  %v327 = phi i64 [ %v266, %bb35 ], [ %v361, %bb36 ]
  %v328 = phi i64 [ %v267, %bb35 ], [ %v362, %bb36 ]
  %v329 = phi i64 [ %v268, %bb35 ], [ %v363, %bb36 ]
  %v330 = phi i64 [ %v269, %bb35 ], [ %v364, %bb36 ]
  %v331 = phi i64 [ %v270, %bb35 ], [ %v365, %bb36 ]
  %v332 = phi i64 [ %v271, %bb35 ], [ %v366, %bb36 ]
  %v333 = phi i64 [ %v272, %bb35 ], [ %v367, %bb36 ]
  %v334 = phi i64 [ %v273, %bb35 ], [ %v368, %bb36 ]
  %v335 = phi i64 [ %v275, %bb35 ], [ %v369, %bb36 ]
  %v336 = phi i64 [ %v306, %bb35 ], [ %v370, %bb36 ]
  br label %bb30
bb34:
  %v337 = add nuw i64 %v255, %v306
  %t5 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v247, i32 0, i32 0
  %v338 = getelementptr i8, ptr %t5, i64 0
  %v339 = getelementptr i8, ptr %v338, i64 0
  %t6 = load ptr, ptr %v339
  %t7.nonnegative = icmp sge i64 %v337, 0
  call void @llvm.assume(i1 %t7.nonnegative)
  %t7 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t6, i64 0, i32 2, i64 %v337
  %v340 = getelementptr i8, ptr %t7, i64 0
  %v341 = call i32 @wf_hash_map.hash_map_action$instance$fc5e3cb62bdf3601(ptr %v340, ptr %v248, ptr %v250)
  switch i32 %v341, label %invalid.tag.b34 [
    i32 3, label %bb37
    i32 0, label %bb38
    i32 1, label %bb39
    i32 2, label %bb40
  ]
invalid.tag.b34:
  call void @abort()
  unreachable
bb35:
  br label %bb33
bb36:
  %v342 = phi ptr [ %v247, %bb40 ], [ %v411, %bb44 ]
  %v343 = phi ptr [ %v248, %bb40 ], [ %v412, %bb44 ]
  %v344 = phi i64 [ %v249, %bb40 ], [ %v413, %bb44 ]
  %v345 = phi ptr [ %v250, %bb40 ], [ %v414, %bb44 ]
  %v346 = phi i64 [ %v251, %bb40 ], [ %v415, %bb44 ]
  %v347 = phi i64 [ %v252, %bb40 ], [ %v416, %bb44 ]
  %v348 = phi i64 [ %v253, %bb40 ], [ %v417, %bb44 ]
  %v349 = phi i64 [ %v254, %bb40 ], [ %v418, %bb44 ]
  %v350 = phi i64 [ %v255, %bb40 ], [ %v419, %bb44 ]
  %v351 = phi i64 [ %v256, %bb40 ], [ %v420, %bb44 ]
  %v352 = phi i64 [ %v257, %bb40 ], [ %v421, %bb44 ]
  %v353 = phi i64 [ %v258, %bb40 ], [ %v422, %bb44 ]
  %v354 = phi i64 [ %v259, %bb40 ], [ %v423, %bb44 ]
  %v355 = phi i64 [ %v260, %bb40 ], [ %v424, %bb44 ]
  %v356 = phi i64 [ %v261, %bb40 ], [ %v425, %bb44 ]
  %v357 = phi i64 [ %v262, %bb40 ], [ %v426, %bb44 ]
  %v358 = phi i64 [ %v263, %bb40 ], [ %v427, %bb44 ]
  %v359 = phi i64 [ %v264, %bb40 ], [ %v428, %bb44 ]
  %v360 = phi i64 [ %v276, %bb40 ], [ %v429, %bb44 ]
  %v361 = phi i64 [ %v266, %bb40 ], [ %v430, %bb44 ]
  %v362 = phi i64 [ %v267, %bb40 ], [ %v431, %bb44 ]
  %v363 = phi i64 [ %v268, %bb40 ], [ %v432, %bb44 ]
  %v364 = phi i64 [ %v269, %bb40 ], [ %v433, %bb44 ]
  %v365 = phi i64 [ %v270, %bb40 ], [ %v434, %bb44 ]
  %v366 = phi i64 [ %v271, %bb40 ], [ %v435, %bb44 ]
  %v367 = phi i64 [ %v272, %bb40 ], [ %v436, %bb44 ]
  %v368 = phi i64 [ %v273, %bb40 ], [ %v437, %bb44 ]
  %v369 = phi i64 [ %v275, %bb40 ], [ %v438, %bb44 ]
  %v370 = phi i64 [ %v306, %bb40 ], [ %v439, %bb44 ]
  %v371 = phi i64 [ %v337, %bb40 ], [ %v440, %bb44 ]
  %v372 = phi i32 [ %v341, %bb40 ], [ %v441, %bb44 ]
  br label %bb33
bb37:
  %t8 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v247, i32 0, i32 0
  %v373 = getelementptr i8, ptr %t8, i64 0
  %v374 = load i64, ptr %v248
  call void @wf_hash_map.hash_map_exchange$instance$0ed342445dd803f3(ptr %wf.result, ptr %v373, i64 %v337, i64 %v374, i64 %v249)
  %t9 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v247, i32 0, i32 2
  %v376 = getelementptr i8, ptr %t9, i64 0
  %v377 = call i8 @wf_hash_map.hash_map_control_set(ptr %v376, i64 %v337, i64 %v252)
  ret void
bb38:
  %v378 = icmp eq i64 %v254, %v253
  switch i1 %v378, label %invalid.tag.b38 [
    i1 1, label %bb42
    i1 0, label %bb43
  ]
invalid.tag.b38:
  call void @abort()
  unreachable
bb39:
  %v410 = icmp eq i64 %v254, %v253
  switch i1 %v410, label %invalid.tag.b39 [
    i1 1, label %bb45
    i1 0, label %bb46
  ]
invalid.tag.b39:
  call void @abort()
  unreachable
bb40:
  br label %bb36
bb41:
  %v379 = phi ptr [ %v247, %bb42 ], [ %v247, %bb43 ]
  %v380 = phi ptr [ %v248, %bb42 ], [ %v248, %bb43 ]
  %v381 = phi i64 [ %v249, %bb42 ], [ %v249, %bb43 ]
  %v382 = phi ptr [ %v250, %bb42 ], [ %v250, %bb43 ]
  %v383 = phi i64 [ %v251, %bb42 ], [ %v251, %bb43 ]
  %v384 = phi i64 [ %v252, %bb42 ], [ %v252, %bb43 ]
  %v385 = phi i64 [ %v253, %bb42 ], [ %v253, %bb43 ]
  %v386 = phi i64 [ %v337, %bb42 ], [ %v254, %bb43 ]
  %v387 = phi i64 [ %v255, %bb42 ], [ %v255, %bb43 ]
  %v388 = phi i64 [ %v256, %bb42 ], [ %v256, %bb43 ]
  %v389 = phi i64 [ %v257, %bb42 ], [ %v257, %bb43 ]
  %v390 = phi i64 [ %v258, %bb42 ], [ %v258, %bb43 ]
  %v391 = phi i64 [ %v259, %bb42 ], [ %v259, %bb43 ]
  %v392 = phi i64 [ %v260, %bb42 ], [ %v260, %bb43 ]
  %v393 = phi i64 [ %v261, %bb42 ], [ %v261, %bb43 ]
  %v394 = phi i64 [ %v262, %bb42 ], [ %v262, %bb43 ]
  %v395 = phi i64 [ %v263, %bb42 ], [ %v263, %bb43 ]
  %v396 = phi i64 [ %v264, %bb42 ], [ %v264, %bb43 ]
  %v397 = phi i64 [ %v276, %bb42 ], [ %v276, %bb43 ]
  %v398 = phi i64 [ %v266, %bb42 ], [ %v266, %bb43 ]
  %v399 = phi i64 [ %v267, %bb42 ], [ %v267, %bb43 ]
  %v400 = phi i64 [ %v268, %bb42 ], [ %v268, %bb43 ]
  %v401 = phi i64 [ %v269, %bb42 ], [ %v269, %bb43 ]
  %v402 = phi i64 [ %v270, %bb42 ], [ %v270, %bb43 ]
  %v403 = phi i64 [ %v271, %bb42 ], [ %v271, %bb43 ]
  %v404 = phi i64 [ %v272, %bb42 ], [ %v272, %bb43 ]
  %v405 = phi i64 [ %v273, %bb42 ], [ %v273, %bb43 ]
  %v406 = phi i64 [ %v275, %bb42 ], [ %v275, %bb43 ]
  %v407 = phi i64 [ %v306, %bb42 ], [ %v306, %bb43 ]
  %v408 = phi i64 [ %v337, %bb42 ], [ %v337, %bb43 ]
  %v409 = phi i32 [ %v341, %bb42 ], [ %v341, %bb43 ]
  br label %bb26
bb42:
  br label %bb41
bb43:
  br label %bb41
bb44:
  %v411 = phi ptr [ %v247, %bb45 ], [ %v247, %bb46 ]
  %v412 = phi ptr [ %v248, %bb45 ], [ %v248, %bb46 ]
  %v413 = phi i64 [ %v249, %bb45 ], [ %v249, %bb46 ]
  %v414 = phi ptr [ %v250, %bb45 ], [ %v250, %bb46 ]
  %v415 = phi i64 [ %v251, %bb45 ], [ %v251, %bb46 ]
  %v416 = phi i64 [ %v252, %bb45 ], [ %v252, %bb46 ]
  %v417 = phi i64 [ %v253, %bb45 ], [ %v253, %bb46 ]
  %v418 = phi i64 [ %v337, %bb45 ], [ %v254, %bb46 ]
  %v419 = phi i64 [ %v255, %bb45 ], [ %v255, %bb46 ]
  %v420 = phi i64 [ %v256, %bb45 ], [ %v256, %bb46 ]
  %v421 = phi i64 [ %v257, %bb45 ], [ %v257, %bb46 ]
  %v422 = phi i64 [ %v258, %bb45 ], [ %v258, %bb46 ]
  %v423 = phi i64 [ %v259, %bb45 ], [ %v259, %bb46 ]
  %v424 = phi i64 [ %v260, %bb45 ], [ %v260, %bb46 ]
  %v425 = phi i64 [ %v261, %bb45 ], [ %v261, %bb46 ]
  %v426 = phi i64 [ %v262, %bb45 ], [ %v262, %bb46 ]
  %v427 = phi i64 [ %v263, %bb45 ], [ %v263, %bb46 ]
  %v428 = phi i64 [ %v264, %bb45 ], [ %v264, %bb46 ]
  %v429 = phi i64 [ %v276, %bb45 ], [ %v276, %bb46 ]
  %v430 = phi i64 [ %v266, %bb45 ], [ %v266, %bb46 ]
  %v431 = phi i64 [ %v267, %bb45 ], [ %v267, %bb46 ]
  %v432 = phi i64 [ %v268, %bb45 ], [ %v268, %bb46 ]
  %v433 = phi i64 [ %v269, %bb45 ], [ %v269, %bb46 ]
  %v434 = phi i64 [ %v270, %bb45 ], [ %v270, %bb46 ]
  %v435 = phi i64 [ %v271, %bb45 ], [ %v271, %bb46 ]
  %v436 = phi i64 [ %v272, %bb45 ], [ %v272, %bb46 ]
  %v437 = phi i64 [ %v273, %bb45 ], [ %v273, %bb46 ]
  %v438 = phi i64 [ %v275, %bb45 ], [ %v275, %bb46 ]
  %v439 = phi i64 [ %v306, %bb45 ], [ %v306, %bb46 ]
  %v440 = phi i64 [ %v337, %bb45 ], [ %v337, %bb46 ]
  %v441 = phi i32 [ %v341, %bb45 ], [ %v341, %bb46 ]
  br label %bb36
bb45:
  br label %bb44
bb46:
  br label %bb44
bb47:
  %v442 = phi ptr [ %v278, %bb30 ]
  %v443 = phi ptr [ %v279, %bb30 ]
  %v444 = phi i64 [ %v280, %bb30 ]
  %v445 = phi ptr [ %v281, %bb30 ]
  %v446 = phi i64 [ %v282, %bb30 ]
  %v447 = phi i64 [ %v283, %bb30 ]
  %v448 = phi i64 [ %v284, %bb30 ]
  %v449 = phi i64 [ %v285, %bb30 ]
  %v450 = phi i64 [ %v286, %bb30 ]
  %v451 = phi i64 [ %v287, %bb30 ]
  %v452 = phi i64 [ %v288, %bb30 ]
  %v453 = phi i64 [ %v289, %bb30 ]
  %v454 = phi i64 [ %v290, %bb30 ]
  %v455 = phi i64 [ %v291, %bb30 ]
  %v456 = phi i64 [ %v292, %bb30 ]
  %v457 = phi i64 [ %v293, %bb30 ]
  %v458 = phi i64 [ %v294, %bb30 ]
  %v459 = phi i64 [ %v295, %bb30 ]
  %v460 = phi i64 [ %v296, %bb30 ]
  %v461 = phi i64 [ %v297, %bb30 ]
  %v462 = phi i64 [ %v298, %bb30 ]
  %v463 = phi i64 [ %v299, %bb30 ]
  %v464 = phi i64 [ %v300, %bb30 ]
  %v465 = phi i64 [ %v301, %bb30 ]
  %v466 = phi i64 [ %v302, %bb30 ]
  %v467 = phi i64 [ %v216, %bb30 ]
  %v468 = phi i64 [ %v217, %bb30 ]
  %v469 = phi i64 [ %v218, %bb30 ]
  %v470 = select i1 true, i64 1, i64 1
  %v471 = add i64 %v469, %v470
  br label %bb23
bb48:
  %v473 = phi ptr [ %v219, %bb50 ]
  %v474 = phi ptr [ %v220, %bb50 ]
  %v475 = phi i64 [ %v221, %bb50 ]
  %v476 = phi ptr [ %v222, %bb50 ]
  %v477 = phi i64 [ %v223, %bb50 ]
  %v478 = phi i64 [ %v224, %bb50 ]
  %v479 = phi i64 [ %v225, %bb50 ]
  %v480 = phi i64 [ %v226, %bb50 ]
  %v481 = phi i64 [ %v227, %bb50 ]
  %v482 = phi i64 [ %v228, %bb50 ]
  %v483 = phi i64 [ %v229, %bb50 ]
  %v484 = phi i64 [ %v230, %bb50 ]
  %v485 = phi i64 [ %v231, %bb50 ]
  %v486 = phi i64 [ %v232, %bb50 ]
  %v487 = phi i64 [ %v233, %bb50 ]
  %v488 = phi i64 [ %v234, %bb50 ]
  %v489 = phi i64 [ %v235, %bb50 ]
  %v490 = phi i64 [ %v236, %bb50 ]
  %v491 = phi i64 [ %v237, %bb50 ]
  %v492 = phi i64 [ %v238, %bb50 ]
  %v493 = phi i64 [ %v239, %bb50 ]
  %v494 = phi i64 [ %v240, %bb50 ]
  %v495 = phi i64 [ %v241, %bb50 ]
  %v496 = phi i64 [ %v242, %bb50 ]
  %v497 = phi i64 [ %v243, %bb50 ]
  %v498 = sub nuw i64 %v482, %v486
  %v499 = add nuw i64 %v481, %v486
  %v500 = icmp ult i64 %v499, %v479
  switch i1 %v500, label %invalid.tag.b48 [
    i1 1, label %bb52
    i1 0, label %bb53
  ]
invalid.tag.b48:
  call void @abort()
  unreachable
bb49:
  br label %bb7
bb50:
  br label %bb48
bb51:
  %v501 = phi ptr [ %v473, %bb52 ], [ %v473, %bb53 ]
  %v502 = phi ptr [ %v474, %bb52 ], [ %v474, %bb53 ]
  %v503 = phi i64 [ %v475, %bb52 ], [ %v475, %bb53 ]
  %v504 = phi ptr [ %v476, %bb52 ], [ %v476, %bb53 ]
  %v505 = phi i64 [ %v477, %bb52 ], [ %v477, %bb53 ]
  %v506 = phi i64 [ %v478, %bb52 ], [ %v478, %bb53 ]
  %v507 = phi i64 [ %v479, %bb52 ], [ %v479, %bb53 ]
  %v508 = phi i64 [ %v480, %bb52 ], [ %v480, %bb53 ]
  %v509 = phi i64 [ %v499, %bb52 ], [ %v527, %bb53 ]
  %v510 = phi i64 [ %v498, %bb52 ], [ %v498, %bb53 ]
  %v511 = phi i64 [ %v483, %bb52 ], [ %v483, %bb53 ]
  %v512 = phi i64 [ %v484, %bb52 ], [ %v484, %bb53 ]
  %v513 = phi i64 [ %v485, %bb52 ], [ %v485, %bb53 ]
  %v514 = phi i64 [ %v486, %bb52 ], [ %v486, %bb53 ]
  %v515 = phi i64 [ %v487, %bb52 ], [ %v487, %bb53 ]
  %v516 = phi i64 [ %v488, %bb52 ], [ %v488, %bb53 ]
  %v517 = phi i64 [ %v489, %bb52 ], [ %v489, %bb53 ]
  %v518 = phi i64 [ %v490, %bb52 ], [ %v490, %bb53 ]
  %v519 = phi i64 [ %v491, %bb52 ], [ %v491, %bb53 ]
  %v520 = phi i64 [ %v492, %bb52 ], [ %v492, %bb53 ]
  %v521 = phi i64 [ %v493, %bb52 ], [ %v493, %bb53 ]
  %v522 = phi i64 [ %v494, %bb52 ], [ %v494, %bb53 ]
  %v523 = phi i64 [ %v495, %bb52 ], [ %v495, %bb53 ]
  %v524 = phi i64 [ %v496, %bb52 ], [ %v496, %bb53 ]
  %v525 = phi i64 [ %v497, %bb52 ], [ %v497, %bb53 ]
  %v526 = phi i64 [ %v499, %bb52 ], [ %v499, %bb53 ]
  br label %bb54
bb52:
  br label %bb51
bb53:
  %v527 = select i1 true, i64 0, i64 0
  br label %bb51
bb54:
  %v528 = phi ptr [ %v501, %bb51 ]
  %v529 = phi ptr [ %v502, %bb51 ]
  %v530 = phi i64 [ %v503, %bb51 ]
  %v531 = phi ptr [ %v504, %bb51 ]
  %v532 = phi i64 [ %v505, %bb51 ]
  %v533 = phi i64 [ %v506, %bb51 ]
  %v534 = phi i64 [ %v507, %bb51 ]
  %v535 = phi i64 [ %v508, %bb51 ]
  %v536 = phi i64 [ %v509, %bb51 ]
  %v537 = phi i64 [ %v510, %bb51 ]
  %v538 = phi i64 [ %v32, %bb51 ]
  %v539 = phi i64 [ %v33, %bb51 ]
  %v540 = phi i64 [ %v34, %bb51 ]
  %v541 = select i1 true, i64 1, i64 1
  %v542 = add i64 %v540, %v541
  br label %bb4
bb55:
  %v544 = phi ptr [ %v12, %bb57 ], [ %v556, %bb58 ]
  %v545 = phi ptr [ %v13, %bb57 ], [ %v557, %bb58 ]
  %v546 = phi i64 [ %v14, %bb57 ], [ %v558, %bb58 ]
  %v547 = phi ptr [ %v15, %bb57 ], [ %v559, %bb58 ]
  %v548 = phi i64 [ %v16, %bb57 ], [ %v560, %bb58 ]
  %v549 = phi i64 [ %v17, %bb57 ], [ %v561, %bb58 ]
  %v550 = phi i64 [ %v18, %bb57 ], [ %v562, %bb58 ]
  %v551 = phi i64 [ %v19, %bb57 ], [ %v563, %bb58 ]
  %v587 = load i64, ptr %v545
  store %wf.t.09071440a409e980 zeroinitializer, ptr %wf.slot.1
  %t10 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.1, i32 0, i32 0
  store i64 %v587, ptr %t10
  %t11 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.1, i32 0, i32 1
  store i64 %v546, ptr %t11
  %v589 = or i1 0, 1
  store %wf.t.ac5891a387b8aafe zeroinitializer, ptr %wf.result
  %t12 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t12
  %t13 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 1
  store i1 %v589, ptr %t13
  %t14 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr (%wf.t.09071440a409e980, ptr null, i32 1) to i64), i1 false)
  ret void
bb56:
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v12, i64 ptrtoint (ptr getelementptr (%wf.t.7748a5b0f0193f4a, ptr null, i32 1) to i64), i1 false)
  %t15 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %wf.slot.0, i32 0, i32 1
  %v553 = load i64, ptr %t15
  %v554 = select i1 true, i64 16384, i64 16384
  %v555 = icmp ult i64 %v553, %v554
  switch i1 %v555, label %invalid.tag.b56 [
    i1 1, label %bb59
    i1 0, label %bb60
  ]
invalid.tag.b56:
  call void @abort()
  unreachable
bb57:
  br label %bb55
bb58:
  %v556 = phi ptr [ %v12, %bb60 ]
  %v557 = phi ptr [ %v13, %bb60 ]
  %v558 = phi i64 [ %v14, %bb60 ]
  %v559 = phi ptr [ %v15, %bb60 ]
  %v560 = phi i64 [ %v16, %bb60 ]
  %v561 = phi i64 [ %v17, %bb60 ]
  %v562 = phi i64 [ %v18, %bb60 ]
  %v563 = phi i64 [ %v19, %bb60 ]
  %v564 = phi i64 [ %v553, %bb60 ]
  br label %bb55
bb59:
  %t16 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v12, i32 0, i32 0
  %v565 = getelementptr i8, ptr %t16, i64 0
  %v566 = load i64, ptr %v13
  call void @wf_hash_map.hash_map_exchange$instance$0ed342445dd803f3(ptr %v568, ptr %v565, i64 %v19, i64 %v566, i64 %v14)
  %t17 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v12, i32 0, i32 2
  %v569 = getelementptr i8, ptr %t17, i64 0
  %v570 = call i8 @wf_hash_map.hash_map_control_set(ptr %v569, i64 %v19, i64 %v17)
  %v571 = call i1 @wf_hash_map.hash_map_control_inserted$instance$0ed342445dd803f3(ptr %v568)
  switch i1 %v571, label %invalid.tag.b59 [
    i1 1, label %bb62
    i1 0, label %bb63
  ]
invalid.tag.b59:
  call void @abort()
  unreachable
bb60:
  br label %bb58
bb61:
  %v572 = phi ptr [ %v12, %bb62 ], [ %v12, %bb63 ]
  %v573 = phi ptr [ %v13, %bb62 ], [ %v13, %bb63 ]
  %v574 = phi i64 [ %v14, %bb62 ], [ %v14, %bb63 ]
  %v575 = phi ptr [ %v15, %bb62 ], [ %v15, %bb63 ]
  %v576 = phi i64 [ %v16, %bb62 ], [ %v16, %bb63 ]
  %v577 = phi i64 [ %v17, %bb62 ], [ %v17, %bb63 ]
  %v578 = phi i64 [ %v18, %bb62 ], [ %v18, %bb63 ]
  %v579 = phi i64 [ %v19, %bb62 ], [ %v19, %bb63 ]
  %v580 = phi i64 [ %v553, %bb62 ], [ %v553, %bb63 ]
  %v581 = phi ptr [ %v568, %bb62 ], [ %v568, %bb63 ]
  %v582 = phi i1 [ %v571, %bb62 ], [ %v571, %bb63 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.result, ptr %v581, i64 ptrtoint (ptr getelementptr (%wf.t.ac5891a387b8aafe, ptr null, i32 1) to i64), i1 false)
  ret void
bb62:
  %t18 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v12, i32 0, i32 1
  %v583 = getelementptr i8, ptr %t18, i64 0
  %v584 = select i1 true, i64 1, i64 1
  %v585 = add nuw i64 %v553, %v584
  store i64 %v585, ptr %v583
  br label %bb61
bb63:
  br label %bb61
}

define internal void @wf_hash_map.hash_map_find$instance$fde7c6722a8b0dad.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.eb423fc38cfed56f, align 8
  %v3 = call i64 @wf_map_cost_hash(ptr %v2, ptr %v1)
  %t0 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v0, i32 0, i32 0
  %v4 = getelementptr i8, ptr %t0, i64 0
  %v5 = getelementptr i8, ptr %v4, i64 0
  %t2 = load ptr, ptr %v5
  %t3 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t2, i32 0, i32 0
  %t1 = load i64, ptr %t3
  %v6 = add i64 %t1, 0
  %v7 = select i1 true, i64 0, i64 0
  %v8 = icmp eq i64 %v6, %v7
  switch i1 %v8, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v9 = phi ptr [ %v0, %bb3 ]
  %v10 = phi ptr [ %v1, %bb3 ]
  %v11 = phi ptr [ %v2, %bb3 ]
  %v12 = phi i64 [ %v3, %bb3 ]
  %v13 = phi i64 [ %v6, %bb3 ]
  %v16 = call i64 @wf_hash_map.hash_map_control_fingerprint(i64 %v12)
  %v17 = urem i64 %v12, %v13
  %v18 = select i1 true, i64 0, i64 0
  br label %bb4
bb2:
  %v14 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t4 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t4
  %t5 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v14, ptr %t5
  ret void
bb3:
  br label %bb1
bb4:
  %v19 = phi ptr [ %v9, %bb1 ], [ %v327, %bb38 ]
  %v20 = phi ptr [ %v10, %bb1 ], [ %v328, %bb38 ]
  %v21 = phi ptr [ %v11, %bb1 ], [ %v329, %bb38 ]
  %v22 = phi i64 [ %v12, %bb1 ], [ %v330, %bb38 ]
  %v23 = phi i64 [ %v13, %bb1 ], [ %v331, %bb38 ]
  %v24 = phi i64 [ %v16, %bb1 ], [ %v332, %bb38 ]
  %v25 = phi i64 [ %v17, %bb1 ], [ %v333, %bb38 ]
  %v26 = phi i64 [ %v13, %bb1 ], [ %v334, %bb38 ]
  %v27 = phi i64 [ %v18, %bb1 ], [ %v335, %bb38 ]
  %v28 = phi i64 [ %v13, %bb1 ], [ %v336, %bb38 ]
  %v29 = phi i64 [ %v18, %bb1 ], [ %v339, %bb38 ]
  %v38 = icmp ult i64 %v29, %v28
  switch i1 %v38, label %invalid.tag.b4 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b4:
  call void @abort()
  unreachable
bb5:
  %v39 = select i1 true, i64 0, i64 0
  %v40 = icmp eq i64 %v26, %v39
  switch i1 %v40, label %invalid.tag.b5 [
    i1 1, label %bb9
    i1 0, label %bb10
  ]
invalid.tag.b5:
  call void @abort()
  unreachable
bb6:
  br label %bb7
bb7:
  %v30 = phi ptr [ %v19, %bb6 ], [ %v19, %bb9 ]
  %v31 = phi ptr [ %v20, %bb6 ], [ %v20, %bb9 ]
  %v32 = phi ptr [ %v21, %bb6 ], [ %v21, %bb9 ]
  %v33 = phi i64 [ %v22, %bb6 ], [ %v22, %bb9 ]
  %v34 = phi i64 [ %v23, %bb6 ], [ %v23, %bb9 ]
  %v35 = phi i64 [ %v24, %bb6 ], [ %v24, %bb9 ]
  %v36 = phi i64 [ %v25, %bb6 ], [ %v25, %bb9 ]
  %v37 = phi i64 [ %v26, %bb6 ], [ %v26, %bb9 ]
  %v340 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t6 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t6
  %t7 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v340, ptr %t7
  ret void
bb8:
  %v41 = phi ptr [ %v19, %bb10 ]
  %v42 = phi ptr [ %v20, %bb10 ]
  %v43 = phi ptr [ %v21, %bb10 ]
  %v44 = phi i64 [ %v22, %bb10 ]
  %v45 = phi i64 [ %v23, %bb10 ]
  %v46 = phi i64 [ %v24, %bb10 ]
  %v47 = phi i64 [ %v25, %bb10 ]
  %v48 = phi i64 [ %v26, %bb10 ]
  %v49 = phi i64 [ %v29, %bb10 ]
  %v50 = select i1 true, i64 8, i64 8
  %v51 = urem i64 %v47, %v50
  %v52 = sub nuw i64 %v45, %v47
  %v53 = call i64 @wf_hash_map.hash_map_control_span(i64 %v51, i64 %v52, i64 %v48)
  %v54 = select i1 true, i64 8, i64 8
  %v55 = udiv i64 %v47, %v54
  %t8 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v41, i32 0, i32 2
  %v56 = getelementptr i8, ptr %t8, i64 0
  %v57 = call i64 @wf_hash_map.hash_map_control_word(ptr %v56, i64 %v55)
  %v58 = call i64 @wf_hash_map.hash_map_control_active(i64 %v51, i64 %v53)
  %v59 = call i64 @wf_hash_map.hash_map_control_equal(i64 %v57, i64 %v46)
  %v60 = and i64 %v59, %v58
  %v61 = select i1 true, i64 128, i64 128
  %v62 = call i64 @wf_hash_map.hash_map_control_equal(i64 %v57, i64 %v61)
  %v63 = and i64 %v62, %v58
  %v64 = call i64 @wf_hash_map.hash_map_control_stop(i64 %v63, i64 %v51, i64 %v53)
  %v65 = select i1 true, i64 0, i64 0
  %v66 = select i1 true, i64 8, i64 8
  br label %bb11
bb9:
  br label %bb7
bb10:
  br label %bb8
bb11:
  %v67 = phi ptr [ %v41, %bb8 ], [ %v254, %bb31 ]
  %v68 = phi ptr [ %v42, %bb8 ], [ %v255, %bb31 ]
  %v69 = phi ptr [ %v43, %bb8 ], [ %v256, %bb31 ]
  %v70 = phi i64 [ %v44, %bb8 ], [ %v257, %bb31 ]
  %v71 = phi i64 [ %v45, %bb8 ], [ %v258, %bb31 ]
  %v72 = phi i64 [ %v46, %bb8 ], [ %v259, %bb31 ]
  %v73 = phi i64 [ %v47, %bb8 ], [ %v260, %bb31 ]
  %v74 = phi i64 [ %v48, %bb8 ], [ %v261, %bb31 ]
  %v75 = phi i64 [ %v49, %bb8 ], [ %v262, %bb31 ]
  %v76 = phi i64 [ %v51, %bb8 ], [ %v263, %bb31 ]
  %v77 = phi i64 [ %v52, %bb8 ], [ %v264, %bb31 ]
  %v78 = phi i64 [ %v53, %bb8 ], [ %v265, %bb31 ]
  %v79 = phi i64 [ %v55, %bb8 ], [ %v266, %bb31 ]
  %v80 = phi i64 [ %v57, %bb8 ], [ %v267, %bb31 ]
  %v81 = phi i64 [ %v58, %bb8 ], [ %v268, %bb31 ]
  %v82 = phi i64 [ %v59, %bb8 ], [ %v269, %bb31 ]
  %v83 = phi i64 [ %v60, %bb8 ], [ %v270, %bb31 ]
  %v84 = phi i64 [ %v62, %bb8 ], [ %v271, %bb31 ]
  %v85 = phi i64 [ %v63, %bb8 ], [ %v272, %bb31 ]
  %v86 = phi i64 [ %v64, %bb8 ], [ %v273, %bb31 ]
  %v87 = phi i64 [ %v65, %bb8 ], [ %v274, %bb31 ]
  %v88 = phi i64 [ %v66, %bb8 ], [ %v275, %bb31 ]
  %v89 = phi i64 [ %v65, %bb8 ], [ %v278, %bb31 ]
  %v110 = icmp ult i64 %v89, %v88
  switch i1 %v110, label %invalid.tag.b11 [
    i1 1, label %bb12
    i1 0, label %bb13
  ]
invalid.tag.b11:
  call void @abort()
  unreachable
bb12:
  %v111 = select i1 true, i64 0, i64 0
  %v112 = icmp eq i64 %v83, %v111
  switch i1 %v112, label %invalid.tag.b12 [
    i1 1, label %bb16
    i1 0, label %bb17
  ]
invalid.tag.b12:
  call void @abort()
  unreachable
bb13:
  br label %bb14
bb14:
  %v90 = phi ptr [ %v67, %bb13 ], [ %v67, %bb16 ]
  %v91 = phi ptr [ %v68, %bb13 ], [ %v68, %bb16 ]
  %v92 = phi ptr [ %v69, %bb13 ], [ %v69, %bb16 ]
  %v93 = phi i64 [ %v70, %bb13 ], [ %v70, %bb16 ]
  %v94 = phi i64 [ %v71, %bb13 ], [ %v71, %bb16 ]
  %v95 = phi i64 [ %v72, %bb13 ], [ %v72, %bb16 ]
  %v96 = phi i64 [ %v73, %bb13 ], [ %v73, %bb16 ]
  %v97 = phi i64 [ %v74, %bb13 ], [ %v74, %bb16 ]
  %v98 = phi i64 [ %v75, %bb13 ], [ %v75, %bb16 ]
  %v99 = phi i64 [ %v76, %bb13 ], [ %v76, %bb16 ]
  %v100 = phi i64 [ %v77, %bb13 ], [ %v77, %bb16 ]
  %v101 = phi i64 [ %v78, %bb13 ], [ %v78, %bb16 ]
  %v102 = phi i64 [ %v79, %bb13 ], [ %v79, %bb16 ]
  %v103 = phi i64 [ %v80, %bb13 ], [ %v80, %bb16 ]
  %v104 = phi i64 [ %v81, %bb13 ], [ %v81, %bb16 ]
  %v105 = phi i64 [ %v82, %bb13 ], [ %v82, %bb16 ]
  %v106 = phi i64 [ %v83, %bb13 ], [ %v83, %bb16 ]
  %v107 = phi i64 [ %v84, %bb13 ], [ %v84, %bb16 ]
  %v108 = phi i64 [ %v85, %bb13 ], [ %v85, %bb16 ]
  %v109 = phi i64 [ %v86, %bb13 ], [ %v86, %bb16 ]
  %v279 = icmp ult i64 %v109, %v101
  switch i1 %v279, label %invalid.tag.b14 [
    i1 1, label %bb33
    i1 0, label %bb34
  ]
invalid.tag.b14:
  call void @abort()
  unreachable
bb15:
  %v113 = phi ptr [ %v67, %bb17 ]
  %v114 = phi ptr [ %v68, %bb17 ]
  %v115 = phi ptr [ %v69, %bb17 ]
  %v116 = phi i64 [ %v70, %bb17 ]
  %v117 = phi i64 [ %v71, %bb17 ]
  %v118 = phi i64 [ %v72, %bb17 ]
  %v119 = phi i64 [ %v73, %bb17 ]
  %v120 = phi i64 [ %v74, %bb17 ]
  %v121 = phi i64 [ %v75, %bb17 ]
  %v122 = phi i64 [ %v76, %bb17 ]
  %v123 = phi i64 [ %v77, %bb17 ]
  %v124 = phi i64 [ %v78, %bb17 ]
  %v125 = phi i64 [ %v79, %bb17 ]
  %v126 = phi i64 [ %v80, %bb17 ]
  %v127 = phi i64 [ %v81, %bb17 ]
  %v128 = phi i64 [ %v82, %bb17 ]
  %v129 = phi i64 [ %v83, %bb17 ]
  %v130 = phi i64 [ %v84, %bb17 ]
  %v131 = phi i64 [ %v85, %bb17 ]
  %v132 = phi i64 [ %v86, %bb17 ]
  %v133 = phi i64 [ %v89, %bb17 ]
  %v134 = call i64 @wf_hash_map.hash_map_control_first(i64 %v129)
  %v135 = select i1 true, i64 1, i64 1
  %v136 = sub nuw i64 %v129, %v135
  %v137 = and i64 %v129, %v136
  %v138 = icmp uge i64 %v134, %v122
  switch i1 %v138, label %invalid.tag.b15 [
    i1 1, label %bb19
    i1 0, label %bb20
  ]
invalid.tag.b15:
  call void @abort()
  unreachable
bb16:
  br label %bb14
bb17:
  br label %bb15
bb18:
  %v139 = phi ptr [ %v113, %bb20 ], [ %v164, %bb21 ]
  %v140 = phi ptr [ %v114, %bb20 ], [ %v165, %bb21 ]
  %v141 = phi ptr [ %v115, %bb20 ], [ %v166, %bb21 ]
  %v142 = phi i64 [ %v116, %bb20 ], [ %v167, %bb21 ]
  %v143 = phi i64 [ %v117, %bb20 ], [ %v168, %bb21 ]
  %v144 = phi i64 [ %v118, %bb20 ], [ %v169, %bb21 ]
  %v145 = phi i64 [ %v119, %bb20 ], [ %v170, %bb21 ]
  %v146 = phi i64 [ %v120, %bb20 ], [ %v171, %bb21 ]
  %v147 = phi i64 [ %v121, %bb20 ], [ %v172, %bb21 ]
  %v148 = phi i64 [ %v122, %bb20 ], [ %v173, %bb21 ]
  %v149 = phi i64 [ %v123, %bb20 ], [ %v174, %bb21 ]
  %v150 = phi i64 [ %v124, %bb20 ], [ %v175, %bb21 ]
  %v151 = phi i64 [ %v125, %bb20 ], [ %v176, %bb21 ]
  %v152 = phi i64 [ %v126, %bb20 ], [ %v177, %bb21 ]
  %v153 = phi i64 [ %v127, %bb20 ], [ %v178, %bb21 ]
  %v154 = phi i64 [ %v128, %bb20 ], [ %v179, %bb21 ]
  %v155 = phi i64 [ %v137, %bb20 ], [ %v180, %bb21 ]
  %v156 = phi i64 [ %v130, %bb20 ], [ %v181, %bb21 ]
  %v157 = phi i64 [ %v131, %bb20 ], [ %v182, %bb21 ]
  %v158 = phi i64 [ %v132, %bb20 ], [ %v183, %bb21 ]
  %v159 = phi i64 [ %v133, %bb20 ], [ %v184, %bb21 ]
  %v160 = phi i64 [ %v134, %bb20 ], [ %v185, %bb21 ]
  %v161 = phi i64 [ %v136, %bb20 ], [ %v186, %bb21 ]
  br label %bb31
bb19:
  %v162 = sub nuw i64 %v134, %v122
  %v163 = icmp ult i64 %v162, %v132
  switch i1 %v163, label %invalid.tag.b19 [
    i1 1, label %bb22
    i1 0, label %bb23
  ]
invalid.tag.b19:
  call void @abort()
  unreachable
bb20:
  br label %bb18
bb21:
  %v164 = phi ptr [ %v113, %bb23 ], [ %v193, %bb24 ]
  %v165 = phi ptr [ %v114, %bb23 ], [ %v194, %bb24 ]
  %v166 = phi ptr [ %v115, %bb23 ], [ %v195, %bb24 ]
  %v167 = phi i64 [ %v116, %bb23 ], [ %v196, %bb24 ]
  %v168 = phi i64 [ %v117, %bb23 ], [ %v197, %bb24 ]
  %v169 = phi i64 [ %v118, %bb23 ], [ %v198, %bb24 ]
  %v170 = phi i64 [ %v119, %bb23 ], [ %v199, %bb24 ]
  %v171 = phi i64 [ %v120, %bb23 ], [ %v200, %bb24 ]
  %v172 = phi i64 [ %v121, %bb23 ], [ %v201, %bb24 ]
  %v173 = phi i64 [ %v122, %bb23 ], [ %v202, %bb24 ]
  %v174 = phi i64 [ %v123, %bb23 ], [ %v203, %bb24 ]
  %v175 = phi i64 [ %v124, %bb23 ], [ %v204, %bb24 ]
  %v176 = phi i64 [ %v125, %bb23 ], [ %v205, %bb24 ]
  %v177 = phi i64 [ %v126, %bb23 ], [ %v206, %bb24 ]
  %v178 = phi i64 [ %v127, %bb23 ], [ %v207, %bb24 ]
  %v179 = phi i64 [ %v128, %bb23 ], [ %v208, %bb24 ]
  %v180 = phi i64 [ %v137, %bb23 ], [ %v209, %bb24 ]
  %v181 = phi i64 [ %v130, %bb23 ], [ %v210, %bb24 ]
  %v182 = phi i64 [ %v131, %bb23 ], [ %v211, %bb24 ]
  %v183 = phi i64 [ %v132, %bb23 ], [ %v212, %bb24 ]
  %v184 = phi i64 [ %v133, %bb23 ], [ %v213, %bb24 ]
  %v185 = phi i64 [ %v134, %bb23 ], [ %v214, %bb24 ]
  %v186 = phi i64 [ %v136, %bb23 ], [ %v215, %bb24 ]
  %v187 = phi i64 [ %v162, %bb23 ], [ %v216, %bb24 ]
  br label %bb18
bb22:
  %v188 = add nuw i64 %v119, %v162
  %t9 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v113, i32 0, i32 0
  %v189 = getelementptr i8, ptr %t9, i64 0
  %v190 = getelementptr i8, ptr %v189, i64 0
  %t10 = load ptr, ptr %v190
  %t11.nonnegative = icmp sge i64 %v188, 0
  call void @llvm.assume(i1 %t11.nonnegative)
  %t11 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t10, i64 0, i32 2, i64 %v188
  %v191 = getelementptr i8, ptr %t11, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v191, i64 ptrtoint (ptr getelementptr (%wf.t.eb423fc38cfed56f, ptr null, i32 1) to i64), i1 false)
  %t12 = load %wf.t.eb423fc38cfed56f, ptr %wf.slot.0
  %t13 = extractvalue %wf.t.eb423fc38cfed56f %t12, 0
  switch i32 %t13, label %invalid.tag.b22 [
    i32 2, label %bb25
    i32 0, label %bb26
    i32 1, label %bb27
  ]
invalid.tag.b22:
  call void @abort()
  unreachable
bb23:
  br label %bb21
bb24:
  %v193 = phi ptr [ %v113, %bb27 ], [ %v222, %bb28 ]
  %v194 = phi ptr [ %v114, %bb27 ], [ %v223, %bb28 ]
  %v195 = phi ptr [ %v115, %bb27 ], [ %v224, %bb28 ]
  %v196 = phi i64 [ %v116, %bb27 ], [ %v225, %bb28 ]
  %v197 = phi i64 [ %v117, %bb27 ], [ %v226, %bb28 ]
  %v198 = phi i64 [ %v118, %bb27 ], [ %v227, %bb28 ]
  %v199 = phi i64 [ %v119, %bb27 ], [ %v228, %bb28 ]
  %v200 = phi i64 [ %v120, %bb27 ], [ %v229, %bb28 ]
  %v201 = phi i64 [ %v121, %bb27 ], [ %v230, %bb28 ]
  %v202 = phi i64 [ %v122, %bb27 ], [ %v231, %bb28 ]
  %v203 = phi i64 [ %v123, %bb27 ], [ %v232, %bb28 ]
  %v204 = phi i64 [ %v124, %bb27 ], [ %v233, %bb28 ]
  %v205 = phi i64 [ %v125, %bb27 ], [ %v234, %bb28 ]
  %v206 = phi i64 [ %v126, %bb27 ], [ %v235, %bb28 ]
  %v207 = phi i64 [ %v127, %bb27 ], [ %v236, %bb28 ]
  %v208 = phi i64 [ %v128, %bb27 ], [ %v237, %bb28 ]
  %v209 = phi i64 [ %v137, %bb27 ], [ %v238, %bb28 ]
  %v210 = phi i64 [ %v130, %bb27 ], [ %v239, %bb28 ]
  %v211 = phi i64 [ %v131, %bb27 ], [ %v240, %bb28 ]
  %v212 = phi i64 [ %v132, %bb27 ], [ %v241, %bb28 ]
  %v213 = phi i64 [ %v133, %bb27 ], [ %v242, %bb28 ]
  %v214 = phi i64 [ %v134, %bb27 ], [ %v243, %bb28 ]
  %v215 = phi i64 [ %v136, %bb27 ], [ %v244, %bb28 ]
  %v216 = phi i64 [ %v162, %bb27 ], [ %v245, %bb28 ]
  %v217 = phi i64 [ %v188, %bb27 ], [ %v246, %bb28 ]
  %v218 = phi ptr [ %v191, %bb27 ], [ %v247, %bb28 ]
  br label %bb21
bb25:
  %t14 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %v191, i32 0, i32 1
  %v219 = getelementptr i8, ptr %t14, i64 0
  %t15 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %v191, i32 0, i32 2
  %v220 = getelementptr i8, ptr %t15, i64 0
  %v221 = call i1 @wf_map_cost_equal(ptr %v115, ptr %v219, ptr %v114)
  switch i1 %v221, label %invalid.tag.b25 [
    i1 1, label %bb29
    i1 0, label %bb30
  ]
invalid.tag.b25:
  call void @abort()
  unreachable
bb26:
  %v252 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t16 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t16
  %t17 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v252, ptr %t17
  ret void
bb27:
  br label %bb24
bb28:
  %v222 = phi ptr [ %v113, %bb30 ]
  %v223 = phi ptr [ %v114, %bb30 ]
  %v224 = phi ptr [ %v115, %bb30 ]
  %v225 = phi i64 [ %v116, %bb30 ]
  %v226 = phi i64 [ %v117, %bb30 ]
  %v227 = phi i64 [ %v118, %bb30 ]
  %v228 = phi i64 [ %v119, %bb30 ]
  %v229 = phi i64 [ %v120, %bb30 ]
  %v230 = phi i64 [ %v121, %bb30 ]
  %v231 = phi i64 [ %v122, %bb30 ]
  %v232 = phi i64 [ %v123, %bb30 ]
  %v233 = phi i64 [ %v124, %bb30 ]
  %v234 = phi i64 [ %v125, %bb30 ]
  %v235 = phi i64 [ %v126, %bb30 ]
  %v236 = phi i64 [ %v127, %bb30 ]
  %v237 = phi i64 [ %v128, %bb30 ]
  %v238 = phi i64 [ %v137, %bb30 ]
  %v239 = phi i64 [ %v130, %bb30 ]
  %v240 = phi i64 [ %v131, %bb30 ]
  %v241 = phi i64 [ %v132, %bb30 ]
  %v242 = phi i64 [ %v133, %bb30 ]
  %v243 = phi i64 [ %v134, %bb30 ]
  %v244 = phi i64 [ %v136, %bb30 ]
  %v245 = phi i64 [ %v162, %bb30 ]
  %v246 = phi i64 [ %v188, %bb30 ]
  %v247 = phi ptr [ %v191, %bb30 ]
  %v248 = phi ptr [ %v219, %bb30 ]
  %v249 = phi ptr [ %v220, %bb30 ]
  %v250 = phi i1 [ %v221, %bb30 ]
  br label %bb24
bb29:
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t18 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t18
  %t19 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 1
  store i64 %v188, ptr %t19
  ret void
bb30:
  br label %bb28
bb31:
  %v254 = phi ptr [ %v139, %bb18 ]
  %v255 = phi ptr [ %v140, %bb18 ]
  %v256 = phi ptr [ %v141, %bb18 ]
  %v257 = phi i64 [ %v142, %bb18 ]
  %v258 = phi i64 [ %v143, %bb18 ]
  %v259 = phi i64 [ %v144, %bb18 ]
  %v260 = phi i64 [ %v145, %bb18 ]
  %v261 = phi i64 [ %v146, %bb18 ]
  %v262 = phi i64 [ %v147, %bb18 ]
  %v263 = phi i64 [ %v148, %bb18 ]
  %v264 = phi i64 [ %v149, %bb18 ]
  %v265 = phi i64 [ %v150, %bb18 ]
  %v266 = phi i64 [ %v151, %bb18 ]
  %v267 = phi i64 [ %v152, %bb18 ]
  %v268 = phi i64 [ %v153, %bb18 ]
  %v269 = phi i64 [ %v154, %bb18 ]
  %v270 = phi i64 [ %v155, %bb18 ]
  %v271 = phi i64 [ %v156, %bb18 ]
  %v272 = phi i64 [ %v157, %bb18 ]
  %v273 = phi i64 [ %v158, %bb18 ]
  %v274 = phi i64 [ %v87, %bb18 ]
  %v275 = phi i64 [ %v88, %bb18 ]
  %v276 = phi i64 [ %v89, %bb18 ]
  %v277 = select i1 true, i64 1, i64 1
  %v278 = add i64 %v276, %v277
  br label %bb11
bb32:
  %v280 = phi ptr [ %v90, %bb34 ]
  %v281 = phi ptr [ %v91, %bb34 ]
  %v282 = phi ptr [ %v92, %bb34 ]
  %v283 = phi i64 [ %v93, %bb34 ]
  %v284 = phi i64 [ %v94, %bb34 ]
  %v285 = phi i64 [ %v95, %bb34 ]
  %v286 = phi i64 [ %v96, %bb34 ]
  %v287 = phi i64 [ %v97, %bb34 ]
  %v288 = phi i64 [ %v98, %bb34 ]
  %v289 = phi i64 [ %v99, %bb34 ]
  %v290 = phi i64 [ %v100, %bb34 ]
  %v291 = phi i64 [ %v101, %bb34 ]
  %v292 = phi i64 [ %v102, %bb34 ]
  %v293 = phi i64 [ %v103, %bb34 ]
  %v294 = phi i64 [ %v104, %bb34 ]
  %v295 = phi i64 [ %v105, %bb34 ]
  %v296 = phi i64 [ %v106, %bb34 ]
  %v297 = phi i64 [ %v107, %bb34 ]
  %v298 = phi i64 [ %v108, %bb34 ]
  %v299 = phi i64 [ %v109, %bb34 ]
  %v302 = sub nuw i64 %v287, %v291
  %v303 = add nuw i64 %v286, %v291
  %v304 = icmp ult i64 %v303, %v284
  switch i1 %v304, label %invalid.tag.b32 [
    i1 1, label %bb36
    i1 0, label %bb37
  ]
invalid.tag.b32:
  call void @abort()
  unreachable
bb33:
  %v300 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t20 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t20
  %t21 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v300, ptr %t21
  ret void
bb34:
  br label %bb32
bb35:
  %v305 = phi ptr [ %v280, %bb36 ], [ %v280, %bb37 ]
  %v306 = phi ptr [ %v281, %bb36 ], [ %v281, %bb37 ]
  %v307 = phi ptr [ %v282, %bb36 ], [ %v282, %bb37 ]
  %v308 = phi i64 [ %v283, %bb36 ], [ %v283, %bb37 ]
  %v309 = phi i64 [ %v284, %bb36 ], [ %v284, %bb37 ]
  %v310 = phi i64 [ %v285, %bb36 ], [ %v285, %bb37 ]
  %v311 = phi i64 [ %v303, %bb36 ], [ %v326, %bb37 ]
  %v312 = phi i64 [ %v302, %bb36 ], [ %v302, %bb37 ]
  %v313 = phi i64 [ %v288, %bb36 ], [ %v288, %bb37 ]
  %v314 = phi i64 [ %v289, %bb36 ], [ %v289, %bb37 ]
  %v315 = phi i64 [ %v290, %bb36 ], [ %v290, %bb37 ]
  %v316 = phi i64 [ %v291, %bb36 ], [ %v291, %bb37 ]
  %v317 = phi i64 [ %v292, %bb36 ], [ %v292, %bb37 ]
  %v318 = phi i64 [ %v293, %bb36 ], [ %v293, %bb37 ]
  %v319 = phi i64 [ %v294, %bb36 ], [ %v294, %bb37 ]
  %v320 = phi i64 [ %v295, %bb36 ], [ %v295, %bb37 ]
  %v321 = phi i64 [ %v296, %bb36 ], [ %v296, %bb37 ]
  %v322 = phi i64 [ %v297, %bb36 ], [ %v297, %bb37 ]
  %v323 = phi i64 [ %v298, %bb36 ], [ %v298, %bb37 ]
  %v324 = phi i64 [ %v299, %bb36 ], [ %v299, %bb37 ]
  %v325 = phi i64 [ %v303, %bb36 ], [ %v303, %bb37 ]
  br label %bb38
bb36:
  br label %bb35
bb37:
  %v326 = select i1 true, i64 0, i64 0
  br label %bb35
bb38:
  %v327 = phi ptr [ %v305, %bb35 ]
  %v328 = phi ptr [ %v306, %bb35 ]
  %v329 = phi ptr [ %v307, %bb35 ]
  %v330 = phi i64 [ %v308, %bb35 ]
  %v331 = phi i64 [ %v309, %bb35 ]
  %v332 = phi i64 [ %v310, %bb35 ]
  %v333 = phi i64 [ %v311, %bb35 ]
  %v334 = phi i64 [ %v312, %bb35 ]
  %v335 = phi i64 [ %v27, %bb35 ]
  %v336 = phi i64 [ %v28, %bb35 ]
  %v337 = phi i64 [ %v29, %bb35 ]
  %v338 = select i1 true, i64 1, i64 1
  %v339 = add i64 %v337, %v338
  br label %bb4
}

define %wf.t.b7e1ed626c09888a @wf_hash_map.hash_map_find$instance$fde7c6722a8b0dad(ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.result = alloca %wf.t.b7e1ed626c09888a, align 8
  call void @wf_hash_map.hash_map_find$instance$fde7c6722a8b0dad.body(ptr %wf.result, ptr %v0, ptr %v1, ptr %v2)
  %wf.returned = load %wf.t.b7e1ed626c09888a, ptr %wf.result
  ret %wf.t.b7e1ed626c09888a %wf.returned
}

define internal void @wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.eb423fc38cfed56f, align 8
  %wf.slot.1 = alloca { i64, [1 x %wf.t.09071440a409e980] }, align 8
  %wf.slot.2 = alloca %wf.t.09071440a409e980, align 8
  %wf.slot.3 = alloca %wf.t.09071440a409e980, align 8
  %wf.slot.4 = alloca %wf.t.ac5891a387b8aafe, align 8
  %wf.slot.5 = alloca %wf.t.09071440a409e980, align 8
  %wf.slot.6 = alloca { i64, [1 x %wf.t.09071440a409e980] }, align 8
  %v29 = alloca ptr, align 8
  %v32 = alloca %wf.t.b5efdacbe94e5739, align 8
  %v71 = alloca { i64, [1 x %wf.t.09071440a409e980] }, align 8
  %v3 = select i1 true, i64 16384, i64 16384
  %v4 = icmp ugt i64 %v1, %v3
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v5 = phi ptr [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb3 ]
  %v7 = phi ptr [ %v2, %bb3 ]
  %t0 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v5, i32 0, i32 0
  %v10 = getelementptr i8, ptr %t0, i64 0
  %v11 = getelementptr i8, ptr %v10, i64 0
  %t2 = load ptr, ptr %v11
  %t3 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t2, i32 0, i32 0
  %t1 = load i64, ptr %t3
  %v12 = add i64 %t1, 0
  %v13 = icmp ult i64 %v6, %v12
  switch i1 %v13, label %invalid.tag.b1 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v8 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t4 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t4
  %t5 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 2
  store i8 %v8, ptr %t5
  ret void
bb3:
  br label %bb1
bb4:
  %v14 = phi ptr [ %v5, %bb6 ]
  %v15 = phi i64 [ %v6, %bb6 ]
  %v16 = phi ptr [ %v7, %bb6 ]
  %v17 = phi i64 [ %v12, %bb6 ]
  %v20 = select i1 true, i64 0, i64 0
  %v21 = icmp eq i64 %v15, %v20
  switch i1 %v21, label %invalid.tag.b4 [
    i1 1, label %bb8
    i1 0, label %bb9
  ]
invalid.tag.b4:
  call void @abort()
  unreachable
bb5:
  %v18 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t6 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t6
  %t7 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 2
  store i8 %v18, ptr %t7
  ret void
bb6:
  br label %bb4
bb7:
  %v22 = phi ptr [ %v14, %bb9 ]
  %v23 = phi i64 [ %v15, %bb9 ]
  %v24 = phi ptr [ %v16, %bb9 ]
  %v25 = phi i64 [ %v17, %bb9 ]
  %v28 = call ptr @wf_box_slots_new$instance$087f541e70b769ea(i64 %v23)
  store ptr %v28, ptr %v29
  %v30 = call i8 @wf_hash_map.hash_map_extend$instance$820b2044b97e0fbd(ptr %v29, i64 %v23)
  %v31 = call %wf.t.b5efdacbe94e5739 @wf_hash_map.hash_map_controls_new$instance$fd5e04af5c7e1250(i64 %v23)
  store %wf.t.b5efdacbe94e5739 %v31, ptr %v32
  %t8 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v22, i32 0, i32 0
  %v33 = getelementptr i8, ptr %t8, i64 0
  %v34 = call i8 @wf_swap$instance$fd33b528f0517054(ptr %v33, ptr %v29)
  %t9 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v22, i32 0, i32 2
  %v35 = getelementptr i8, ptr %t9, i64 0
  %v36 = call i8 @wf_swap$instance$d89c7f330eeb5a04(ptr %v35, ptr %v32)
  br label %bb10
bb8:
  %v26 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t10 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t10
  %t11 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 1
  store i8 %v26, ptr %t11
  ret void
bb9:
  br label %bb7
bb10:
  %v37 = phi ptr [ %v22, %bb7 ], [ %v61, %bb15 ]
  %v38 = phi i64 [ %v23, %bb7 ], [ %v62, %bb15 ]
  %v39 = phi ptr [ %v24, %bb7 ], [ %v63, %bb15 ]
  %v40 = phi i64 [ %v25, %bb7 ], [ %v64, %bb15 ]
  %v41 = phi ptr [ %v29, %bb7 ], [ %v65, %bb15 ]
  %v42 = phi ptr [ %v32, %bb7 ], [ %v66, %bb15 ]
  %v49 = getelementptr i8, ptr %v41, i64 0
  %t13 = load ptr, ptr %v49
  %t14 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t13, i32 0, i32 0
  %t12 = load i64, ptr %t14
  %v50 = add i64 %t12, 0
  %v51 = select i1 true, i64 0, i64 0
  %v52 = icmp eq i64 %v50, %v51
  switch i1 %v52, label %invalid.tag.b10 [
    i1 1, label %bb13
    i1 0, label %bb14
  ]
invalid.tag.b10:
  call void @abort()
  unreachable
bb11:
  %v43 = phi ptr [ %v37, %bb13 ]
  %v44 = phi i64 [ %v38, %bb13 ]
  %v45 = phi ptr [ %v39, %bb13 ]
  %v46 = phi i64 [ %v40, %bb13 ]
  %v47 = phi ptr [ %v41, %bb13 ]
  %v48 = phi ptr [ %v42, %bb13 ]
  %v224 = load ptr, ptr %v47
  %v225 = call i8 @wf_free_empty$instance$fd33b528f0517054(ptr %v224)
  %v226 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t15 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t15
  %t16 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 1
  store i8 %v226, ptr %t16
  %t17 = getelementptr inbounds %wf.t.b5efdacbe94e5739, ptr %v48, i32 0, i32 1
  %v228 = getelementptr i8, ptr %t17, i64 0
  %t18 = load { i64, [1 x ptr] }, ptr %v228
  call void @wf.drop.run.707f874ef98d2803({ i64, [1 x ptr] } %t18)
  ; drop %v228
  ; drop %v48
  ret void
bb12:
  %v53 = phi ptr [ %v37, %bb14 ]
  %v54 = phi i64 [ %v38, %bb14 ]
  %v55 = phi ptr [ %v39, %bb14 ]
  %v56 = phi i64 [ %v40, %bb14 ]
  %v57 = phi ptr [ %v41, %bb14 ]
  %v58 = phi ptr [ %v42, %bb14 ]
  %v59 = getelementptr i8, ptr %v57, i64 0
  %v60 = call %wf.t.eb423fc38cfed56f @wf_take_back$instance$20364da1adbcdc5f(ptr %v59)
  store %wf.t.eb423fc38cfed56f %v60, ptr %wf.slot.0
  %t19 = load %wf.t.eb423fc38cfed56f, ptr %wf.slot.0
  %t20 = extractvalue %wf.t.eb423fc38cfed56f %t19, 0
  switch i32 %t20, label %invalid.tag.b12 [
    i32 0, label %bb16
    i32 1, label %bb17
    i32 2, label %bb18
  ]
invalid.tag.b12:
  call void @abort()
  unreachable
bb13:
  br label %bb11
bb14:
  br label %bb12
bb15:
  %v61 = phi ptr [ %v53, %bb16 ], [ %v53, %bb17 ], [ %v85, %bb20 ]
  %v62 = phi i64 [ %v54, %bb16 ], [ %v54, %bb17 ], [ %v86, %bb20 ]
  %v63 = phi ptr [ %v55, %bb16 ], [ %v55, %bb17 ], [ %v87, %bb20 ]
  %v64 = phi i64 [ %v56, %bb16 ], [ %v56, %bb17 ], [ %v88, %bb20 ]
  %v65 = phi ptr [ %v57, %bb16 ], [ %v57, %bb17 ], [ %v89, %bb20 ]
  %v66 = phi ptr [ %v58, %bb16 ], [ %v58, %bb17 ], [ %v90, %bb20 ]
  br label %bb10
bb16:
  br label %bb15
bb17:
  br label %bb15
bb18:
  %t21 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %wf.slot.0, i32 0, i32 1
  %v68 = load i64, ptr %t21
  %t22 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %wf.slot.0, i32 0, i32 2
  %v69 = load i64, ptr %t22
  %v70 = call { i64, [1 x %wf.t.09071440a409e980] } @wf_slots_new$instance$f6f95306140971d3()
  store { i64, [1 x %wf.t.09071440a409e980] } %v70, ptr %wf.slot.1
  call void @llvm.memmove.p0.p0.i64(ptr %v71, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr ({ i64, [1 x %wf.t.09071440a409e980] }, ptr null, i32 1) to i64), i1 false)
  store %wf.t.09071440a409e980 zeroinitializer, ptr %wf.slot.2
  %t23 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.2, i32 0, i32 0
  store i64 %v68, ptr %t23
  %t24 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.2, i32 0, i32 1
  store i64 %v69, ptr %t24
  %v73 = call i8 @wf_place_back$instance$22267f8259e51fb5(ptr %v71, ptr %wf.slot.2)
  br label %bb19
bb19:
  %v74 = phi ptr [ %v53, %bb18 ], [ %v134, %bb27 ]
  %v75 = phi i64 [ %v54, %bb18 ], [ %v135, %bb27 ]
  %v76 = phi ptr [ %v55, %bb18 ], [ %v136, %bb27 ]
  %v77 = phi i64 [ %v56, %bb18 ], [ %v137, %bb27 ]
  %v78 = phi ptr [ %v57, %bb18 ], [ %v138, %bb27 ]
  %v79 = phi ptr [ %v58, %bb18 ], [ %v139, %bb27 ]
  %v81 = phi i64 [ %v68, %bb18 ], [ %v141, %bb27 ]
  %v82 = phi i64 [ %v69, %bb18 ], [ %v142, %bb27 ]
  %v83 = phi ptr [ %v71, %bb18 ], [ %v143, %bb27 ]
  %t26 = getelementptr inbounds { i64, [1 x %wf.t.09071440a409e980] }, ptr %v83, i32 0, i32 0
  %t25 = load i64, ptr %t26
  %v96 = add i64 %t25, 0
  %v97 = select i1 true, i64 0, i64 0
  %v98 = icmp eq i64 %v96, %v97
  switch i1 %v98, label %invalid.tag.b19 [
    i1 1, label %bb22
    i1 0, label %bb23
  ]
invalid.tag.b19:
  call void @abort()
  unreachable
bb20:
  %v85 = phi ptr [ %v74, %bb22 ]
  %v86 = phi i64 [ %v75, %bb22 ]
  %v87 = phi ptr [ %v76, %bb22 ]
  %v88 = phi i64 [ %v77, %bb22 ]
  %v89 = phi ptr [ %v78, %bb22 ]
  %v90 = phi ptr [ %v79, %bb22 ]
  %v92 = phi i64 [ %v81, %bb22 ]
  %v93 = phi i64 [ %v82, %bb22 ]
  %v94 = phi ptr [ %v83, %bb22 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.6, ptr %v94, i64 ptrtoint (ptr getelementptr ({ i64, [1 x %wf.t.09071440a409e980] }, ptr null, i32 1) to i64), i1 false)
  %v223 = call i8 @wf_free_empty$instance$b7fb76652ce23509(ptr %wf.slot.6)
  br label %bb15
bb21:
  %v99 = phi ptr [ %v74, %bb23 ]
  %v100 = phi i64 [ %v75, %bb23 ]
  %v101 = phi ptr [ %v76, %bb23 ]
  %v102 = phi i64 [ %v77, %bb23 ]
  %v103 = phi ptr [ %v78, %bb23 ]
  %v104 = phi ptr [ %v79, %bb23 ]
  %v106 = phi i64 [ %v81, %bb23 ]
  %v107 = phi i64 [ %v82, %bb23 ]
  %v108 = phi ptr [ %v83, %bb23 ]
  %v110 = select i1 true, i64 0, i64 0
  %t27.nonnegative = icmp sge i64 %v110, 0
  call void @llvm.assume(i1 %t27.nonnegative)
  %t27 = getelementptr inbounds { i64, [1 x %wf.t.09071440a409e980] }, ptr %v108, i64 0, i32 1, i64 %v110
  %v111 = getelementptr i8, ptr %t27, i64 0
  %t28 = getelementptr inbounds %wf.t.09071440a409e980, ptr %v111, i32 0, i32 0
  %v112 = getelementptr i8, ptr %t28, i64 0
  %v113 = call i64 @wf_map_cost_hash(ptr %v101, ptr %v112)
  %t29 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v99, i32 0, i32 0
  %v114 = getelementptr i8, ptr %t29, i64 0
  %v115 = getelementptr i8, ptr %v114, i64 0
  %t31 = load ptr, ptr %v115
  %t32 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t31, i32 0, i32 0
  %t30 = load i64, ptr %t32
  %v116 = add i64 %t30, 0
  %v117 = select i1 true, i64 0, i64 0
  br label %bb24
bb22:
  br label %bb20
bb23:
  br label %bb21
bb24:
  %v118 = phi ptr [ %v99, %bb21 ], [ %v204, %bb34 ]
  %v119 = phi i64 [ %v100, %bb21 ], [ %v205, %bb34 ]
  %v120 = phi ptr [ %v101, %bb21 ], [ %v206, %bb34 ]
  %v121 = phi i64 [ %v102, %bb21 ], [ %v207, %bb34 ]
  %v122 = phi ptr [ %v103, %bb21 ], [ %v208, %bb34 ]
  %v123 = phi ptr [ %v104, %bb21 ], [ %v209, %bb34 ]
  %v125 = phi i64 [ %v106, %bb21 ], [ %v211, %bb34 ]
  %v126 = phi i64 [ %v107, %bb21 ], [ %v212, %bb34 ]
  %v127 = phi ptr [ %v108, %bb21 ], [ %v213, %bb34 ]
  %v129 = phi i64 [ %v113, %bb21 ], [ %v215, %bb34 ]
  %v130 = phi i64 [ %v116, %bb21 ], [ %v216, %bb34 ]
  %v131 = phi i64 [ %v117, %bb21 ], [ %v217, %bb34 ]
  %v132 = phi i64 [ %v116, %bb21 ], [ %v218, %bb34 ]
  %v133 = phi i64 [ %v117, %bb21 ], [ %v221, %bb34 ]
  %v147 = icmp ult i64 %v133, %v132
  switch i1 %v147, label %invalid.tag.b24 [
    i1 1, label %bb25
    i1 0, label %bb26
  ]
invalid.tag.b24:
  call void @abort()
  unreachable
bb25:
  %v148 = urem i64 %v129, %v130
  %v149 = call i64 @wf_hash_map.hash_map_probe(i64 %v148, i64 %v133, i64 %v130)
  %t33 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v118, i32 0, i32 0
  %v150 = getelementptr i8, ptr %t33, i64 0
  %v151 = getelementptr i8, ptr %v150, i64 0
  %t34 = load ptr, ptr %v151
  %t35.nonnegative = icmp sge i64 %v149, 0
  call void @llvm.assume(i1 %t35.nonnegative)
  %t35 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t34, i64 0, i32 2, i64 %v149
  %v152 = getelementptr i8, ptr %t35, i64 0
  %v153 = call i1 @wf_hash_map.hash_map_is_available$instance$0ed342445dd803f3(ptr %v152)
  switch i1 %v153, label %invalid.tag.b25 [
    i1 1, label %bb29
    i1 0, label %bb30
  ]
invalid.tag.b25:
  call void @abort()
  unreachable
bb26:
  br label %bb27
bb27:
  %v134 = phi ptr [ %v118, %bb26 ], [ %v179, %bb31 ]
  %v135 = phi i64 [ %v119, %bb26 ], [ %v180, %bb31 ]
  %v136 = phi ptr [ %v120, %bb26 ], [ %v181, %bb31 ]
  %v137 = phi i64 [ %v121, %bb26 ], [ %v182, %bb31 ]
  %v138 = phi ptr [ %v122, %bb26 ], [ %v183, %bb31 ]
  %v139 = phi ptr [ %v123, %bb26 ], [ %v184, %bb31 ]
  %v141 = phi i64 [ %v125, %bb26 ], [ %v186, %bb31 ]
  %v142 = phi i64 [ %v126, %bb26 ], [ %v187, %bb31 ]
  %v143 = phi ptr [ %v127, %bb26 ], [ %v188, %bb31 ]
  %v145 = phi i64 [ %v129, %bb26 ], [ %v190, %bb31 ]
  %v146 = phi i64 [ %v130, %bb26 ], [ %v191, %bb31 ]
  br label %bb19
bb28:
  %v154 = phi ptr [ %v118, %bb30 ]
  %v155 = phi i64 [ %v119, %bb30 ]
  %v156 = phi ptr [ %v120, %bb30 ]
  %v157 = phi i64 [ %v121, %bb30 ]
  %v158 = phi ptr [ %v122, %bb30 ]
  %v159 = phi ptr [ %v123, %bb30 ]
  %v161 = phi i64 [ %v125, %bb30 ]
  %v162 = phi i64 [ %v126, %bb30 ]
  %v163 = phi ptr [ %v127, %bb30 ]
  %v165 = phi i64 [ %v129, %bb30 ]
  %v166 = phi i64 [ %v130, %bb30 ]
  %v167 = phi i64 [ %v133, %bb30 ]
  %v168 = phi i64 [ %v148, %bb30 ]
  %v169 = phi i64 [ %v149, %bb30 ]
  %v170 = phi i1 [ %v153, %bb30 ]
  br label %bb34
bb29:
  %v171 = call %wf.t.09071440a409e980 @wf_take_back$instance$22267f8259e51fb5(ptr %v127)
  store %wf.t.09071440a409e980 %v171, ptr %wf.slot.3
  %t36 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.3, i32 0, i32 0
  %v172 = load i64, ptr %t36
  ; ownership-consuming projection
  %t37 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.3, i32 0, i32 1
  %v173 = load i64, ptr %t37
  ; ownership-consuming projection
  %t38 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v118, i32 0, i32 0
  %v174 = getelementptr i8, ptr %t38, i64 0
  call void @wf_hash_map.hash_map_exchange$instance$0ed342445dd803f3(ptr %wf.slot.4, ptr %v174, i64 %v149, i64 %v172, i64 %v173)
  %v176 = call i64 @wf_hash_map.hash_map_control_fingerprint(i64 %v129)
  %t39 = getelementptr inbounds %wf.t.7748a5b0f0193f4a, ptr %v118, i32 0, i32 2
  %v177 = getelementptr i8, ptr %t39, i64 0
  %v178 = call i8 @wf_hash_map.hash_map_control_set(ptr %v177, i64 %v149, i64 %v176)
  %t40 = load %wf.t.ac5891a387b8aafe, ptr %wf.slot.4
  %t41 = extractvalue %wf.t.ac5891a387b8aafe %t40, 0
  switch i32 %t41, label %invalid.tag.b29 [
    i32 0, label %bb32
    i32 1, label %bb33
  ]
invalid.tag.b29:
  call void @abort()
  unreachable
bb30:
  br label %bb28
bb31:
  %v179 = phi ptr [ %v118, %bb32 ], [ %v118, %bb33 ]
  %v180 = phi i64 [ %v119, %bb32 ], [ %v119, %bb33 ]
  %v181 = phi ptr [ %v120, %bb32 ], [ %v120, %bb33 ]
  %v182 = phi i64 [ %v121, %bb32 ], [ %v121, %bb33 ]
  %v183 = phi ptr [ %v122, %bb32 ], [ %v122, %bb33 ]
  %v184 = phi ptr [ %v123, %bb32 ], [ %v123, %bb33 ]
  %v186 = phi i64 [ %v125, %bb32 ], [ %v125, %bb33 ]
  %v187 = phi i64 [ %v126, %bb32 ], [ %v126, %bb33 ]
  %v188 = phi ptr [ %v127, %bb32 ], [ %v127, %bb33 ]
  %v190 = phi i64 [ %v129, %bb32 ], [ %v129, %bb33 ]
  %v191 = phi i64 [ %v130, %bb32 ], [ %v130, %bb33 ]
  %v192 = phi i64 [ %v133, %bb32 ], [ %v133, %bb33 ]
  %v193 = phi i64 [ %v148, %bb32 ], [ %v148, %bb33 ]
  %v194 = phi i64 [ %v149, %bb32 ], [ %v149, %bb33 ]
  %v195 = phi i1 [ %v153, %bb32 ], [ %v153, %bb33 ]
  %v197 = phi i64 [ %v172, %bb32 ], [ %v172, %bb33 ]
  %v198 = phi i64 [ %v173, %bb32 ], [ %v173, %bb33 ]
  %v200 = phi i64 [ %v176, %bb32 ], [ %v176, %bb33 ]
  br label %bb27
bb32:
  br label %bb31
bb33:
  %t42 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.slot.4, i32 0, i32 1
  %v201 = load i1, ptr %t42
  %t43 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.slot.4, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.5, ptr %t43, i64 ptrtoint (ptr getelementptr (%wf.t.09071440a409e980, ptr null, i32 1) to i64), i1 false)
  %v203 = call i8 @wf_place_back$instance$22267f8259e51fb5(ptr %v127, ptr %wf.slot.5)
  br label %bb31
bb34:
  %v204 = phi ptr [ %v154, %bb28 ]
  %v205 = phi i64 [ %v155, %bb28 ]
  %v206 = phi ptr [ %v156, %bb28 ]
  %v207 = phi i64 [ %v157, %bb28 ]
  %v208 = phi ptr [ %v158, %bb28 ]
  %v209 = phi ptr [ %v159, %bb28 ]
  %v211 = phi i64 [ %v161, %bb28 ]
  %v212 = phi i64 [ %v162, %bb28 ]
  %v213 = phi ptr [ %v163, %bb28 ]
  %v215 = phi i64 [ %v165, %bb28 ]
  %v216 = phi i64 [ %v166, %bb28 ]
  %v217 = phi i64 [ %v131, %bb28 ]
  %v218 = phi i64 [ %v132, %bb28 ]
  %v219 = phi i64 [ %v133, %bb28 ]
  %v220 = select i1 true, i64 1, i64 1
  %v221 = add i64 %v219, %v220
  br label %bb24
}

define %wf.t.7d7f918f7b4962fd @wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad(ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.result = alloca %wf.t.7d7f918f7b4962fd, align 4
  call void @wf_hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad.body(ptr %wf.result, ptr %v0, i64 %v1, ptr %v2)
  %wf.returned = load %wf.t.7d7f918f7b4962fd, ptr %wf.result
  ret %wf.t.7d7f918f7b4962fd %wf.returned
}

define ptr @wf_box_slots_new$instance$b1cfa6e689dc9e10(i64 %v0) #0 {
entry:
  %t0 = mul nuw i64 %v0, ptrtoint (ptr getelementptr (%wf.t.e04aead91f34a68f, ptr null, i64 1) to i64)
  %t1 = add nuw i64 %t0, ptrtoint (ptr getelementptr ({ i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr null, i64 0, i32 2) to i64)
  %v1 = call ptr @malloc(i64 %t1)
  %t2 = icmp ne ptr %v1, null
  br i1 %t2, label %window.block.ready.v1, label %window.block.oom.v1
window.block.oom.v1:
  call void @wf_resource_abort()
  unreachable
window.block.ready.v1:
  %t3 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %v1, i32 0, i32 0
  store i64 0, ptr %t3
  %t4 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %v1, i32 0, i32 1
  store i64 %v0, ptr %t4
  ret ptr %v1
}

define i8 @wf_hash_map.hash_map_extend$instance$96033bf6ddb80743(ptr noalias nonnull captures(none) dereferenceable(8) %v0, i64 %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.e04aead91f34a68f, align 8
  %v2 = getelementptr i8, ptr %v0, i64 0
  %t1 = load ptr, ptr %v2
  %t2 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t1, i32 0, i32 1
  %t0 = load i64, ptr %t2
  %v3 = add i64 %t0, 0
  %v4 = icmp ult i64 %v3, %v1
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v5 = phi ptr [ %v0, %bb2 ], [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb2 ], [ %v1, %bb3 ]
  %v8 = getelementptr i8, ptr %v5, i64 0
  %t4 = load ptr, ptr %v8
  %t5 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t4, i32 0, i32 0
  %t3 = load i64, ptr %t5
  %v9 = add i64 %t3, 0
  br label %bb4
bb2:
  %v7 = call i8 @wf_grow$instance$b1cfa6e689dc9e10(ptr %v0, i64 %v1)
  br label %bb1
bb3:
  br label %bb1
bb4:
  %v10 = phi ptr [ %v5, %bb1 ], [ %v23, %bb8 ]
  %v11 = phi i64 [ %v6, %bb1 ], [ %v24, %bb8 ]
  %v12 = phi i64 [ %v9, %bb1 ], [ %v25, %bb8 ]
  %v13 = phi i64 [ %v9, %bb1 ], [ %v26, %bb8 ]
  %v14 = phi i64 [ %v6, %bb1 ], [ %v27, %bb8 ]
  %v15 = phi i64 [ %v9, %bb1 ], [ %v30, %bb8 ]
  %v19 = icmp ult i64 %v15, %v14
  switch i1 %v19, label %invalid.tag.b4 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b4:
  call void @abort()
  unreachable
bb5:
  store %wf.t.e04aead91f34a68f zeroinitializer, ptr %wf.slot.0
  %t6 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %wf.slot.0, i32 0, i32 0
  store i32 0, ptr %t6
  %v21 = getelementptr i8, ptr %v10, i64 0
  %v22 = call i8 @wf_place_back$instance$2af1311599ac146a(ptr %v21, ptr %wf.slot.0)
  br label %bb8
bb6:
  br label %bb7
bb7:
  %v16 = phi ptr [ %v10, %bb6 ]
  %v17 = phi i64 [ %v11, %bb6 ]
  %v18 = phi i64 [ %v12, %bb6 ]
  %v31 = select i1 true, i8 0, i8 0
  ret i8 %v31
bb8:
  %v23 = phi ptr [ %v10, %bb5 ]
  %v24 = phi i64 [ %v11, %bb5 ]
  %v25 = phi i64 [ %v12, %bb5 ]
  %v26 = phi i64 [ %v13, %bb5 ]
  %v27 = phi i64 [ %v14, %bb5 ]
  %v28 = phi i64 [ %v15, %bb5 ]
  %v29 = select i1 true, i64 1, i64 1
  %v30 = add i64 %v28, %v29
  br label %bb4
}

define void @wf_hash_map.hash_map_try_put$instance$8d5197e2f00c3b07(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr %wf.arg.v2, ptr noalias nonnull captures(none) dereferenceable(16) %v3) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.1 = alloca %wf.t.a5ea622fe32c85b6, align 8
  %wf.slot.2 = alloca %wf.t.20dda3774c7510ec, align 8
  %v4 = alloca i64, align 8
  %v568 = alloca %wf.t.9d321e1eb2ec1c03, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v2, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  store i64 %v1, ptr %v4
  %v5 = call i64 @wf_map_cost_hash(ptr %v3, ptr %v4)
  %v6 = call i64 @wf_hash_map.hash_map_control_fingerprint(i64 %v5)
  %t0 = getelementptr inbounds %wf.t.a5ea622fe32c85b6, ptr %v0, i32 0, i32 0
  %v7 = getelementptr i8, ptr %t0, i64 0
  %v8 = getelementptr i8, ptr %v7, i64 0
  %t2 = load ptr, ptr %v8
  %t3 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t2, i32 0, i32 0
  %t1 = load i64, ptr %t3
  %v9 = add i64 %t1, 0
  %v10 = select i1 true, i64 0, i64 0
  %v11 = icmp ugt i64 %v9, %v10
  switch i1 %v11, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v12 = phi ptr [ %v0, %bb3 ], [ %v35, %bb7 ]
  %v13 = phi ptr [ %v4, %bb3 ], [ %v36, %bb7 ]
  %v15 = phi ptr [ %v3, %bb3 ], [ %v38, %bb7 ]
  %v16 = phi i64 [ %v5, %bb3 ], [ %v39, %bb7 ]
  %v17 = phi i64 [ %v6, %bb3 ], [ %v40, %bb7 ]
  %v18 = phi i64 [ %v9, %bb3 ], [ %v41, %bb7 ]
  %v19 = phi i64 [ %v9, %bb3 ], [ %v42, %bb7 ]
  %v543 = icmp ult i64 %v19, %v18
  switch i1 %v543, label %invalid.tag.b1 [
    i1 1, label %bb56
    i1 0, label %bb57
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v20 = urem i64 %v5, %v9
  %v21 = select i1 true, i64 0, i64 0
  br label %bb4
bb3:
  br label %bb1
bb4:
  %v22 = phi ptr [ %v0, %bb2 ], [ %v528, %bb54 ]
  %v23 = phi ptr [ %v4, %bb2 ], [ %v529, %bb54 ]
  %v25 = phi ptr [ %v3, %bb2 ], [ %v531, %bb54 ]
  %v26 = phi i64 [ %v5, %bb2 ], [ %v532, %bb54 ]
  %v27 = phi i64 [ %v6, %bb2 ], [ %v533, %bb54 ]
  %v28 = phi i64 [ %v9, %bb2 ], [ %v534, %bb54 ]
  %v29 = phi i64 [ %v9, %bb2 ], [ %v535, %bb54 ]
  %v30 = phi i64 [ %v20, %bb2 ], [ %v536, %bb54 ]
  %v31 = phi i64 [ %v9, %bb2 ], [ %v537, %bb54 ]
  %v32 = phi i64 [ %v21, %bb2 ], [ %v538, %bb54 ]
  %v33 = phi i64 [ %v9, %bb2 ], [ %v539, %bb54 ]
  %v34 = phi i64 [ %v21, %bb2 ], [ %v542, %bb54 ]
  %v45 = icmp ult i64 %v34, %v33
  switch i1 %v45, label %invalid.tag.b4 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b4:
  call void @abort()
  unreachable
bb5:
  %v46 = select i1 true, i64 0, i64 0
  %v47 = icmp eq i64 %v31, %v46
  switch i1 %v47, label %invalid.tag.b5 [
    i1 1, label %bb9
    i1 0, label %bb10
  ]
invalid.tag.b5:
  call void @abort()
  unreachable
bb6:
  br label %bb7
bb7:
  %v35 = phi ptr [ %v22, %bb6 ], [ %v22, %bb9 ], [ %v219, %bb49 ]
  %v36 = phi ptr [ %v23, %bb6 ], [ %v23, %bb9 ], [ %v220, %bb49 ]
  %v38 = phi ptr [ %v25, %bb6 ], [ %v25, %bb9 ], [ %v222, %bb49 ]
  %v39 = phi i64 [ %v26, %bb6 ], [ %v26, %bb9 ], [ %v223, %bb49 ]
  %v40 = phi i64 [ %v27, %bb6 ], [ %v27, %bb9 ], [ %v224, %bb49 ]
  %v41 = phi i64 [ %v28, %bb6 ], [ %v28, %bb9 ], [ %v225, %bb49 ]
  %v42 = phi i64 [ %v29, %bb6 ], [ %v29, %bb9 ], [ %v226, %bb49 ]
  %v43 = phi i64 [ %v30, %bb6 ], [ %v30, %bb9 ], [ %v227, %bb49 ]
  %v44 = phi i64 [ %v31, %bb6 ], [ %v31, %bb9 ], [ %v228, %bb49 ]
  br label %bb1
bb8:
  %v48 = phi ptr [ %v22, %bb10 ]
  %v49 = phi ptr [ %v23, %bb10 ]
  %v51 = phi ptr [ %v25, %bb10 ]
  %v52 = phi i64 [ %v26, %bb10 ]
  %v53 = phi i64 [ %v27, %bb10 ]
  %v54 = phi i64 [ %v28, %bb10 ]
  %v55 = phi i64 [ %v29, %bb10 ]
  %v56 = phi i64 [ %v30, %bb10 ]
  %v57 = phi i64 [ %v31, %bb10 ]
  %v58 = phi i64 [ %v34, %bb10 ]
  %v59 = select i1 true, i64 8, i64 8
  %v60 = urem i64 %v56, %v59
  %v61 = sub nuw i64 %v54, %v56
  %v62 = call i64 @wf_hash_map.hash_map_control_span(i64 %v60, i64 %v61, i64 %v57)
  %v63 = select i1 true, i64 8, i64 8
  %v64 = udiv i64 %v56, %v63
  %t4 = getelementptr inbounds %wf.t.a5ea622fe32c85b6, ptr %v48, i32 0, i32 2
  %v65 = getelementptr i8, ptr %t4, i64 0
  %v66 = call i64 @wf_hash_map.hash_map_control_word(ptr %v65, i64 %v64)
  %v67 = call i64 @wf_hash_map.hash_map_control_active(i64 %v60, i64 %v62)
  %v68 = call i64 @wf_hash_map.hash_map_control_equal(i64 %v66, i64 %v53)
  %v69 = and i64 %v68, %v67
  %v70 = select i1 true, i64 128, i64 128
  %v71 = call i64 @wf_hash_map.hash_map_control_equal(i64 %v66, i64 %v70)
  %v72 = and i64 %v71, %v67
  %v73 = select i1 true, i64 254, i64 254
  %v74 = call i64 @wf_hash_map.hash_map_control_equal(i64 %v66, i64 %v73)
  %v75 = and i64 %v74, %v67
  %v76 = or i64 %v72, %v75
  %v77 = call i64 @wf_hash_map.hash_map_control_stop(i64 %v72, i64 %v60, i64 %v62)
  %v78 = icmp eq i64 %v55, %v54
  switch i1 %v78, label %invalid.tag.b8 [
    i1 1, label %bb12
    i1 0, label %bb13
  ]
invalid.tag.b8:
  call void @abort()
  unreachable
bb9:
  br label %bb7
bb10:
  br label %bb8
bb11:
  %v79 = phi ptr [ %v48, %bb13 ], [ %v106, %bb14 ]
  %v80 = phi ptr [ %v49, %bb13 ], [ %v107, %bb14 ]
  %v82 = phi ptr [ %v51, %bb13 ], [ %v109, %bb14 ]
  %v83 = phi i64 [ %v52, %bb13 ], [ %v110, %bb14 ]
  %v84 = phi i64 [ %v53, %bb13 ], [ %v111, %bb14 ]
  %v85 = phi i64 [ %v54, %bb13 ], [ %v112, %bb14 ]
  %v86 = phi i64 [ %v55, %bb13 ], [ %v113, %bb14 ]
  %v87 = phi i64 [ %v56, %bb13 ], [ %v114, %bb14 ]
  %v88 = phi i64 [ %v57, %bb13 ], [ %v115, %bb14 ]
  %v89 = phi i64 [ %v58, %bb13 ], [ %v116, %bb14 ]
  %v90 = phi i64 [ %v60, %bb13 ], [ %v117, %bb14 ]
  %v91 = phi i64 [ %v61, %bb13 ], [ %v118, %bb14 ]
  %v92 = phi i64 [ %v62, %bb13 ], [ %v119, %bb14 ]
  %v93 = phi i64 [ %v64, %bb13 ], [ %v120, %bb14 ]
  %v94 = phi i64 [ %v66, %bb13 ], [ %v121, %bb14 ]
  %v95 = phi i64 [ %v67, %bb13 ], [ %v122, %bb14 ]
  %v96 = phi i64 [ %v68, %bb13 ], [ %v123, %bb14 ]
  %v97 = phi i64 [ %v69, %bb13 ], [ %v124, %bb14 ]
  %v98 = phi i64 [ %v71, %bb13 ], [ %v125, %bb14 ]
  %v99 = phi i64 [ %v72, %bb13 ], [ %v126, %bb14 ]
  %v100 = phi i64 [ %v74, %bb13 ], [ %v127, %bb14 ]
  %v101 = phi i64 [ %v75, %bb13 ], [ %v128, %bb14 ]
  %v102 = phi i64 [ %v76, %bb13 ], [ %v129, %bb14 ]
  %v103 = phi i64 [ %v77, %bb13 ], [ %v130, %bb14 ]
  %v189 = select i1 true, i64 0, i64 0
  %v190 = select i1 true, i64 8, i64 8
  br label %bb23
bb12:
  %v104 = select i1 true, i64 0, i64 0
  %v105 = icmp ugt i64 %v76, %v104
  switch i1 %v105, label %invalid.tag.b12 [
    i1 1, label %bb15
    i1 0, label %bb16
  ]
invalid.tag.b12:
  call void @abort()
  unreachable
bb13:
  br label %bb11
bb14:
  %v106 = phi ptr [ %v48, %bb16 ], [ %v133, %bb17 ]
  %v107 = phi ptr [ %v49, %bb16 ], [ %v134, %bb17 ]
  %v109 = phi ptr [ %v51, %bb16 ], [ %v136, %bb17 ]
  %v110 = phi i64 [ %v52, %bb16 ], [ %v137, %bb17 ]
  %v111 = phi i64 [ %v53, %bb16 ], [ %v138, %bb17 ]
  %v112 = phi i64 [ %v54, %bb16 ], [ %v139, %bb17 ]
  %v113 = phi i64 [ %v55, %bb16 ], [ %v140, %bb17 ]
  %v114 = phi i64 [ %v56, %bb16 ], [ %v141, %bb17 ]
  %v115 = phi i64 [ %v57, %bb16 ], [ %v142, %bb17 ]
  %v116 = phi i64 [ %v58, %bb16 ], [ %v143, %bb17 ]
  %v117 = phi i64 [ %v60, %bb16 ], [ %v144, %bb17 ]
  %v118 = phi i64 [ %v61, %bb16 ], [ %v145, %bb17 ]
  %v119 = phi i64 [ %v62, %bb16 ], [ %v146, %bb17 ]
  %v120 = phi i64 [ %v64, %bb16 ], [ %v147, %bb17 ]
  %v121 = phi i64 [ %v66, %bb16 ], [ %v148, %bb17 ]
  %v122 = phi i64 [ %v67, %bb16 ], [ %v149, %bb17 ]
  %v123 = phi i64 [ %v68, %bb16 ], [ %v150, %bb17 ]
  %v124 = phi i64 [ %v69, %bb16 ], [ %v151, %bb17 ]
  %v125 = phi i64 [ %v71, %bb16 ], [ %v152, %bb17 ]
  %v126 = phi i64 [ %v72, %bb16 ], [ %v153, %bb17 ]
  %v127 = phi i64 [ %v74, %bb16 ], [ %v154, %bb17 ]
  %v128 = phi i64 [ %v75, %bb16 ], [ %v155, %bb17 ]
  %v129 = phi i64 [ %v76, %bb16 ], [ %v156, %bb17 ]
  %v130 = phi i64 [ %v77, %bb16 ], [ %v157, %bb17 ]
  br label %bb11
bb15:
  %v131 = call i64 @wf_hash_map.hash_map_control_first(i64 %v76)
  %v132 = icmp uge i64 %v131, %v60
  switch i1 %v132, label %invalid.tag.b15 [
    i1 1, label %bb18
    i1 0, label %bb19
  ]
invalid.tag.b15:
  call void @abort()
  unreachable
bb16:
  br label %bb14
bb17:
  %v133 = phi ptr [ %v48, %bb19 ], [ %v161, %bb20 ]
  %v134 = phi ptr [ %v49, %bb19 ], [ %v162, %bb20 ]
  %v136 = phi ptr [ %v51, %bb19 ], [ %v164, %bb20 ]
  %v137 = phi i64 [ %v52, %bb19 ], [ %v165, %bb20 ]
  %v138 = phi i64 [ %v53, %bb19 ], [ %v166, %bb20 ]
  %v139 = phi i64 [ %v54, %bb19 ], [ %v167, %bb20 ]
  %v140 = phi i64 [ %v55, %bb19 ], [ %v168, %bb20 ]
  %v141 = phi i64 [ %v56, %bb19 ], [ %v169, %bb20 ]
  %v142 = phi i64 [ %v57, %bb19 ], [ %v170, %bb20 ]
  %v143 = phi i64 [ %v58, %bb19 ], [ %v171, %bb20 ]
  %v144 = phi i64 [ %v60, %bb19 ], [ %v172, %bb20 ]
  %v145 = phi i64 [ %v61, %bb19 ], [ %v173, %bb20 ]
  %v146 = phi i64 [ %v62, %bb19 ], [ %v174, %bb20 ]
  %v147 = phi i64 [ %v64, %bb19 ], [ %v175, %bb20 ]
  %v148 = phi i64 [ %v66, %bb19 ], [ %v176, %bb20 ]
  %v149 = phi i64 [ %v67, %bb19 ], [ %v177, %bb20 ]
  %v150 = phi i64 [ %v68, %bb19 ], [ %v178, %bb20 ]
  %v151 = phi i64 [ %v69, %bb19 ], [ %v179, %bb20 ]
  %v152 = phi i64 [ %v71, %bb19 ], [ %v180, %bb20 ]
  %v153 = phi i64 [ %v72, %bb19 ], [ %v181, %bb20 ]
  %v154 = phi i64 [ %v74, %bb19 ], [ %v182, %bb20 ]
  %v155 = phi i64 [ %v75, %bb19 ], [ %v183, %bb20 ]
  %v156 = phi i64 [ %v76, %bb19 ], [ %v184, %bb20 ]
  %v157 = phi i64 [ %v77, %bb19 ], [ %v185, %bb20 ]
  %v158 = phi i64 [ %v131, %bb19 ], [ %v186, %bb20 ]
  br label %bb14
bb18:
  %v159 = sub nuw i64 %v131, %v60
  %v160 = icmp ult i64 %v159, %v62
  switch i1 %v160, label %invalid.tag.b18 [
    i1 1, label %bb21
    i1 0, label %bb22
  ]
invalid.tag.b18:
  call void @abort()
  unreachable
bb19:
  br label %bb17
bb20:
  %v161 = phi ptr [ %v48, %bb21 ], [ %v48, %bb22 ]
  %v162 = phi ptr [ %v49, %bb21 ], [ %v49, %bb22 ]
  %v164 = phi ptr [ %v51, %bb21 ], [ %v51, %bb22 ]
  %v165 = phi i64 [ %v52, %bb21 ], [ %v52, %bb22 ]
  %v166 = phi i64 [ %v53, %bb21 ], [ %v53, %bb22 ]
  %v167 = phi i64 [ %v54, %bb21 ], [ %v54, %bb22 ]
  %v168 = phi i64 [ %v188, %bb21 ], [ %v55, %bb22 ]
  %v169 = phi i64 [ %v56, %bb21 ], [ %v56, %bb22 ]
  %v170 = phi i64 [ %v57, %bb21 ], [ %v57, %bb22 ]
  %v171 = phi i64 [ %v58, %bb21 ], [ %v58, %bb22 ]
  %v172 = phi i64 [ %v60, %bb21 ], [ %v60, %bb22 ]
  %v173 = phi i64 [ %v61, %bb21 ], [ %v61, %bb22 ]
  %v174 = phi i64 [ %v62, %bb21 ], [ %v62, %bb22 ]
  %v175 = phi i64 [ %v64, %bb21 ], [ %v64, %bb22 ]
  %v176 = phi i64 [ %v66, %bb21 ], [ %v66, %bb22 ]
  %v177 = phi i64 [ %v67, %bb21 ], [ %v67, %bb22 ]
  %v178 = phi i64 [ %v68, %bb21 ], [ %v68, %bb22 ]
  %v179 = phi i64 [ %v69, %bb21 ], [ %v69, %bb22 ]
  %v180 = phi i64 [ %v71, %bb21 ], [ %v71, %bb22 ]
  %v181 = phi i64 [ %v72, %bb21 ], [ %v72, %bb22 ]
  %v182 = phi i64 [ %v74, %bb21 ], [ %v74, %bb22 ]
  %v183 = phi i64 [ %v75, %bb21 ], [ %v75, %bb22 ]
  %v184 = phi i64 [ %v76, %bb21 ], [ %v76, %bb22 ]
  %v185 = phi i64 [ %v77, %bb21 ], [ %v77, %bb22 ]
  %v186 = phi i64 [ %v131, %bb21 ], [ %v131, %bb22 ]
  %v187 = phi i64 [ %v159, %bb21 ], [ %v159, %bb22 ]
  br label %bb17
bb21:
  %v188 = add nuw i64 %v56, %v159
  br label %bb20
bb22:
  br label %bb20
bb23:
  %v191 = phi ptr [ %v79, %bb11 ], [ %v442, %bb47 ]
  %v192 = phi ptr [ %v80, %bb11 ], [ %v443, %bb47 ]
  %v194 = phi ptr [ %v82, %bb11 ], [ %v445, %bb47 ]
  %v195 = phi i64 [ %v83, %bb11 ], [ %v446, %bb47 ]
  %v196 = phi i64 [ %v84, %bb11 ], [ %v447, %bb47 ]
  %v197 = phi i64 [ %v85, %bb11 ], [ %v448, %bb47 ]
  %v198 = phi i64 [ %v86, %bb11 ], [ %v449, %bb47 ]
  %v199 = phi i64 [ %v87, %bb11 ], [ %v450, %bb47 ]
  %v200 = phi i64 [ %v88, %bb11 ], [ %v451, %bb47 ]
  %v201 = phi i64 [ %v89, %bb11 ], [ %v452, %bb47 ]
  %v202 = phi i64 [ %v90, %bb11 ], [ %v453, %bb47 ]
  %v203 = phi i64 [ %v91, %bb11 ], [ %v454, %bb47 ]
  %v204 = phi i64 [ %v92, %bb11 ], [ %v455, %bb47 ]
  %v205 = phi i64 [ %v93, %bb11 ], [ %v456, %bb47 ]
  %v206 = phi i64 [ %v94, %bb11 ], [ %v457, %bb47 ]
  %v207 = phi i64 [ %v95, %bb11 ], [ %v458, %bb47 ]
  %v208 = phi i64 [ %v96, %bb11 ], [ %v459, %bb47 ]
  %v209 = phi i64 [ %v97, %bb11 ], [ %v460, %bb47 ]
  %v210 = phi i64 [ %v98, %bb11 ], [ %v461, %bb47 ]
  %v211 = phi i64 [ %v99, %bb11 ], [ %v462, %bb47 ]
  %v212 = phi i64 [ %v100, %bb11 ], [ %v463, %bb47 ]
  %v213 = phi i64 [ %v101, %bb11 ], [ %v464, %bb47 ]
  %v214 = phi i64 [ %v102, %bb11 ], [ %v465, %bb47 ]
  %v215 = phi i64 [ %v103, %bb11 ], [ %v466, %bb47 ]
  %v216 = phi i64 [ %v189, %bb11 ], [ %v467, %bb47 ]
  %v217 = phi i64 [ %v190, %bb11 ], [ %v468, %bb47 ]
  %v218 = phi i64 [ %v189, %bb11 ], [ %v471, %bb47 ]
  %v244 = icmp ult i64 %v218, %v217
  switch i1 %v244, label %invalid.tag.b23 [
    i1 1, label %bb24
    i1 0, label %bb25
  ]
invalid.tag.b23:
  call void @abort()
  unreachable
bb24:
  %v245 = select i1 true, i64 0, i64 0
  %v246 = icmp eq i64 %v209, %v245
  switch i1 %v246, label %invalid.tag.b24 [
    i1 1, label %bb28
    i1 0, label %bb29
  ]
invalid.tag.b24:
  call void @abort()
  unreachable
bb25:
  br label %bb26
bb26:
  %v219 = phi ptr [ %v191, %bb25 ], [ %v191, %bb28 ], [ %v379, %bb41 ]
  %v220 = phi ptr [ %v192, %bb25 ], [ %v192, %bb28 ], [ %v380, %bb41 ]
  %v222 = phi ptr [ %v194, %bb25 ], [ %v194, %bb28 ], [ %v382, %bb41 ]
  %v223 = phi i64 [ %v195, %bb25 ], [ %v195, %bb28 ], [ %v383, %bb41 ]
  %v224 = phi i64 [ %v196, %bb25 ], [ %v196, %bb28 ], [ %v384, %bb41 ]
  %v225 = phi i64 [ %v197, %bb25 ], [ %v197, %bb28 ], [ %v385, %bb41 ]
  %v226 = phi i64 [ %v198, %bb25 ], [ %v198, %bb28 ], [ %v386, %bb41 ]
  %v227 = phi i64 [ %v199, %bb25 ], [ %v199, %bb28 ], [ %v387, %bb41 ]
  %v228 = phi i64 [ %v200, %bb25 ], [ %v200, %bb28 ], [ %v388, %bb41 ]
  %v229 = phi i64 [ %v201, %bb25 ], [ %v201, %bb28 ], [ %v389, %bb41 ]
  %v230 = phi i64 [ %v202, %bb25 ], [ %v202, %bb28 ], [ %v390, %bb41 ]
  %v231 = phi i64 [ %v203, %bb25 ], [ %v203, %bb28 ], [ %v391, %bb41 ]
  %v232 = phi i64 [ %v204, %bb25 ], [ %v204, %bb28 ], [ %v392, %bb41 ]
  %v233 = phi i64 [ %v205, %bb25 ], [ %v205, %bb28 ], [ %v393, %bb41 ]
  %v234 = phi i64 [ %v206, %bb25 ], [ %v206, %bb28 ], [ %v394, %bb41 ]
  %v235 = phi i64 [ %v207, %bb25 ], [ %v207, %bb28 ], [ %v395, %bb41 ]
  %v236 = phi i64 [ %v208, %bb25 ], [ %v208, %bb28 ], [ %v396, %bb41 ]
  %v237 = phi i64 [ %v209, %bb25 ], [ %v209, %bb28 ], [ %v397, %bb41 ]
  %v238 = phi i64 [ %v210, %bb25 ], [ %v210, %bb28 ], [ %v398, %bb41 ]
  %v239 = phi i64 [ %v211, %bb25 ], [ %v211, %bb28 ], [ %v399, %bb41 ]
  %v240 = phi i64 [ %v212, %bb25 ], [ %v212, %bb28 ], [ %v400, %bb41 ]
  %v241 = phi i64 [ %v213, %bb25 ], [ %v213, %bb28 ], [ %v401, %bb41 ]
  %v242 = phi i64 [ %v214, %bb25 ], [ %v214, %bb28 ], [ %v402, %bb41 ]
  %v243 = phi i64 [ %v215, %bb25 ], [ %v215, %bb28 ], [ %v407, %bb41 ]
  %v472 = icmp ult i64 %v243, %v232
  switch i1 %v472, label %invalid.tag.b26 [
    i1 1, label %bb49
    i1 0, label %bb50
  ]
invalid.tag.b26:
  call void @abort()
  unreachable
bb27:
  %v247 = phi ptr [ %v191, %bb29 ]
  %v248 = phi ptr [ %v192, %bb29 ]
  %v250 = phi ptr [ %v194, %bb29 ]
  %v251 = phi i64 [ %v195, %bb29 ]
  %v252 = phi i64 [ %v196, %bb29 ]
  %v253 = phi i64 [ %v197, %bb29 ]
  %v254 = phi i64 [ %v198, %bb29 ]
  %v255 = phi i64 [ %v199, %bb29 ]
  %v256 = phi i64 [ %v200, %bb29 ]
  %v257 = phi i64 [ %v201, %bb29 ]
  %v258 = phi i64 [ %v202, %bb29 ]
  %v259 = phi i64 [ %v203, %bb29 ]
  %v260 = phi i64 [ %v204, %bb29 ]
  %v261 = phi i64 [ %v205, %bb29 ]
  %v262 = phi i64 [ %v206, %bb29 ]
  %v263 = phi i64 [ %v207, %bb29 ]
  %v264 = phi i64 [ %v208, %bb29 ]
  %v265 = phi i64 [ %v209, %bb29 ]
  %v266 = phi i64 [ %v210, %bb29 ]
  %v267 = phi i64 [ %v211, %bb29 ]
  %v268 = phi i64 [ %v212, %bb29 ]
  %v269 = phi i64 [ %v213, %bb29 ]
  %v270 = phi i64 [ %v214, %bb29 ]
  %v271 = phi i64 [ %v215, %bb29 ]
  %v272 = phi i64 [ %v218, %bb29 ]
  %v273 = call i64 @wf_hash_map.hash_map_control_first(i64 %v265)
  %v274 = select i1 true, i64 1, i64 1
  %v275 = sub nuw i64 %v265, %v274
  %v276 = and i64 %v265, %v275
  %v277 = icmp uge i64 %v273, %v258
  switch i1 %v277, label %invalid.tag.b27 [
    i1 1, label %bb31
    i1 0, label %bb32
  ]
invalid.tag.b27:
  call void @abort()
  unreachable
bb28:
  br label %bb26
bb29:
  br label %bb27
bb30:
  %v278 = phi ptr [ %v247, %bb32 ], [ %v308, %bb33 ]
  %v279 = phi ptr [ %v248, %bb32 ], [ %v309, %bb33 ]
  %v281 = phi ptr [ %v250, %bb32 ], [ %v311, %bb33 ]
  %v282 = phi i64 [ %v251, %bb32 ], [ %v312, %bb33 ]
  %v283 = phi i64 [ %v252, %bb32 ], [ %v313, %bb33 ]
  %v284 = phi i64 [ %v253, %bb32 ], [ %v314, %bb33 ]
  %v285 = phi i64 [ %v254, %bb32 ], [ %v315, %bb33 ]
  %v286 = phi i64 [ %v255, %bb32 ], [ %v316, %bb33 ]
  %v287 = phi i64 [ %v256, %bb32 ], [ %v317, %bb33 ]
  %v288 = phi i64 [ %v257, %bb32 ], [ %v318, %bb33 ]
  %v289 = phi i64 [ %v258, %bb32 ], [ %v319, %bb33 ]
  %v290 = phi i64 [ %v259, %bb32 ], [ %v320, %bb33 ]
  %v291 = phi i64 [ %v260, %bb32 ], [ %v321, %bb33 ]
  %v292 = phi i64 [ %v261, %bb32 ], [ %v322, %bb33 ]
  %v293 = phi i64 [ %v262, %bb32 ], [ %v323, %bb33 ]
  %v294 = phi i64 [ %v263, %bb32 ], [ %v324, %bb33 ]
  %v295 = phi i64 [ %v264, %bb32 ], [ %v325, %bb33 ]
  %v296 = phi i64 [ %v276, %bb32 ], [ %v326, %bb33 ]
  %v297 = phi i64 [ %v266, %bb32 ], [ %v327, %bb33 ]
  %v298 = phi i64 [ %v267, %bb32 ], [ %v328, %bb33 ]
  %v299 = phi i64 [ %v268, %bb32 ], [ %v329, %bb33 ]
  %v300 = phi i64 [ %v269, %bb32 ], [ %v330, %bb33 ]
  %v301 = phi i64 [ %v270, %bb32 ], [ %v331, %bb33 ]
  %v302 = phi i64 [ %v271, %bb32 ], [ %v332, %bb33 ]
  %v303 = phi i64 [ %v272, %bb32 ], [ %v333, %bb33 ]
  %v304 = phi i64 [ %v273, %bb32 ], [ %v334, %bb33 ]
  %v305 = phi i64 [ %v275, %bb32 ], [ %v335, %bb33 ]
  br label %bb47
bb31:
  %v306 = sub nuw i64 %v273, %v258
  %v307 = icmp ult i64 %v306, %v271
  switch i1 %v307, label %invalid.tag.b31 [
    i1 1, label %bb34
    i1 0, label %bb35
  ]
invalid.tag.b31:
  call void @abort()
  unreachable
bb32:
  br label %bb30
bb33:
  %v308 = phi ptr [ %v247, %bb35 ], [ %v342, %bb36 ]
  %v309 = phi ptr [ %v248, %bb35 ], [ %v343, %bb36 ]
  %v311 = phi ptr [ %v250, %bb35 ], [ %v345, %bb36 ]
  %v312 = phi i64 [ %v251, %bb35 ], [ %v346, %bb36 ]
  %v313 = phi i64 [ %v252, %bb35 ], [ %v347, %bb36 ]
  %v314 = phi i64 [ %v253, %bb35 ], [ %v348, %bb36 ]
  %v315 = phi i64 [ %v254, %bb35 ], [ %v349, %bb36 ]
  %v316 = phi i64 [ %v255, %bb35 ], [ %v350, %bb36 ]
  %v317 = phi i64 [ %v256, %bb35 ], [ %v351, %bb36 ]
  %v318 = phi i64 [ %v257, %bb35 ], [ %v352, %bb36 ]
  %v319 = phi i64 [ %v258, %bb35 ], [ %v353, %bb36 ]
  %v320 = phi i64 [ %v259, %bb35 ], [ %v354, %bb36 ]
  %v321 = phi i64 [ %v260, %bb35 ], [ %v355, %bb36 ]
  %v322 = phi i64 [ %v261, %bb35 ], [ %v356, %bb36 ]
  %v323 = phi i64 [ %v262, %bb35 ], [ %v357, %bb36 ]
  %v324 = phi i64 [ %v263, %bb35 ], [ %v358, %bb36 ]
  %v325 = phi i64 [ %v264, %bb35 ], [ %v359, %bb36 ]
  %v326 = phi i64 [ %v276, %bb35 ], [ %v360, %bb36 ]
  %v327 = phi i64 [ %v266, %bb35 ], [ %v361, %bb36 ]
  %v328 = phi i64 [ %v267, %bb35 ], [ %v362, %bb36 ]
  %v329 = phi i64 [ %v268, %bb35 ], [ %v363, %bb36 ]
  %v330 = phi i64 [ %v269, %bb35 ], [ %v364, %bb36 ]
  %v331 = phi i64 [ %v270, %bb35 ], [ %v365, %bb36 ]
  %v332 = phi i64 [ %v271, %bb35 ], [ %v366, %bb36 ]
  %v333 = phi i64 [ %v272, %bb35 ], [ %v367, %bb36 ]
  %v334 = phi i64 [ %v273, %bb35 ], [ %v368, %bb36 ]
  %v335 = phi i64 [ %v275, %bb35 ], [ %v369, %bb36 ]
  %v336 = phi i64 [ %v306, %bb35 ], [ %v370, %bb36 ]
  br label %bb30
bb34:
  %v337 = add nuw i64 %v255, %v306
  %t5 = getelementptr inbounds %wf.t.a5ea622fe32c85b6, ptr %v247, i32 0, i32 0
  %v338 = getelementptr i8, ptr %t5, i64 0
  %v339 = getelementptr i8, ptr %v338, i64 0
  %t6 = load ptr, ptr %v339
  %t7.nonnegative = icmp sge i64 %v337, 0
  call void @llvm.assume(i1 %t7.nonnegative)
  %t7 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t6, i64 0, i32 2, i64 %v337
  %v340 = getelementptr i8, ptr %t7, i64 0
  %v341 = call i32 @wf_hash_map.hash_map_action$instance$c6df3d8464f8cde0(ptr %v340, ptr %v248, ptr %v250)
  switch i32 %v341, label %invalid.tag.b34 [
    i32 3, label %bb37
    i32 0, label %bb38
    i32 1, label %bb39
    i32 2, label %bb40
  ]
invalid.tag.b34:
  call void @abort()
  unreachable
bb35:
  br label %bb33
bb36:
  %v342 = phi ptr [ %v247, %bb40 ], [ %v411, %bb44 ]
  %v343 = phi ptr [ %v248, %bb40 ], [ %v412, %bb44 ]
  %v345 = phi ptr [ %v250, %bb40 ], [ %v414, %bb44 ]
  %v346 = phi i64 [ %v251, %bb40 ], [ %v415, %bb44 ]
  %v347 = phi i64 [ %v252, %bb40 ], [ %v416, %bb44 ]
  %v348 = phi i64 [ %v253, %bb40 ], [ %v417, %bb44 ]
  %v349 = phi i64 [ %v254, %bb40 ], [ %v418, %bb44 ]
  %v350 = phi i64 [ %v255, %bb40 ], [ %v419, %bb44 ]
  %v351 = phi i64 [ %v256, %bb40 ], [ %v420, %bb44 ]
  %v352 = phi i64 [ %v257, %bb40 ], [ %v421, %bb44 ]
  %v353 = phi i64 [ %v258, %bb40 ], [ %v422, %bb44 ]
  %v354 = phi i64 [ %v259, %bb40 ], [ %v423, %bb44 ]
  %v355 = phi i64 [ %v260, %bb40 ], [ %v424, %bb44 ]
  %v356 = phi i64 [ %v261, %bb40 ], [ %v425, %bb44 ]
  %v357 = phi i64 [ %v262, %bb40 ], [ %v426, %bb44 ]
  %v358 = phi i64 [ %v263, %bb40 ], [ %v427, %bb44 ]
  %v359 = phi i64 [ %v264, %bb40 ], [ %v428, %bb44 ]
  %v360 = phi i64 [ %v276, %bb40 ], [ %v429, %bb44 ]
  %v361 = phi i64 [ %v266, %bb40 ], [ %v430, %bb44 ]
  %v362 = phi i64 [ %v267, %bb40 ], [ %v431, %bb44 ]
  %v363 = phi i64 [ %v268, %bb40 ], [ %v432, %bb44 ]
  %v364 = phi i64 [ %v269, %bb40 ], [ %v433, %bb44 ]
  %v365 = phi i64 [ %v270, %bb40 ], [ %v434, %bb44 ]
  %v366 = phi i64 [ %v271, %bb40 ], [ %v435, %bb44 ]
  %v367 = phi i64 [ %v272, %bb40 ], [ %v436, %bb44 ]
  %v368 = phi i64 [ %v273, %bb40 ], [ %v437, %bb44 ]
  %v369 = phi i64 [ %v275, %bb40 ], [ %v438, %bb44 ]
  %v370 = phi i64 [ %v306, %bb40 ], [ %v439, %bb44 ]
  %v371 = phi i64 [ %v337, %bb40 ], [ %v440, %bb44 ]
  %v372 = phi i32 [ %v341, %bb40 ], [ %v441, %bb44 ]
  br label %bb33
bb37:
  %t8 = getelementptr inbounds %wf.t.a5ea622fe32c85b6, ptr %v247, i32 0, i32 0
  %v373 = getelementptr i8, ptr %t8, i64 0
  %v374 = load i64, ptr %v248
  call void @wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449(ptr %wf.result, ptr %v373, i64 %v337, i64 %v374, ptr %wf.slot.0)
  %t9 = getelementptr inbounds %wf.t.a5ea622fe32c85b6, ptr %v247, i32 0, i32 2
  %v376 = getelementptr i8, ptr %t9, i64 0
  %v377 = call i8 @wf_hash_map.hash_map_control_set(ptr %v376, i64 %v337, i64 %v252)
  ret void
bb38:
  %v378 = icmp eq i64 %v254, %v253
  switch i1 %v378, label %invalid.tag.b38 [
    i1 1, label %bb42
    i1 0, label %bb43
  ]
invalid.tag.b38:
  call void @abort()
  unreachable
bb39:
  %v410 = icmp eq i64 %v254, %v253
  switch i1 %v410, label %invalid.tag.b39 [
    i1 1, label %bb45
    i1 0, label %bb46
  ]
invalid.tag.b39:
  call void @abort()
  unreachable
bb40:
  br label %bb36
bb41:
  %v379 = phi ptr [ %v247, %bb42 ], [ %v247, %bb43 ]
  %v380 = phi ptr [ %v248, %bb42 ], [ %v248, %bb43 ]
  %v382 = phi ptr [ %v250, %bb42 ], [ %v250, %bb43 ]
  %v383 = phi i64 [ %v251, %bb42 ], [ %v251, %bb43 ]
  %v384 = phi i64 [ %v252, %bb42 ], [ %v252, %bb43 ]
  %v385 = phi i64 [ %v253, %bb42 ], [ %v253, %bb43 ]
  %v386 = phi i64 [ %v337, %bb42 ], [ %v254, %bb43 ]
  %v387 = phi i64 [ %v255, %bb42 ], [ %v255, %bb43 ]
  %v388 = phi i64 [ %v256, %bb42 ], [ %v256, %bb43 ]
  %v389 = phi i64 [ %v257, %bb42 ], [ %v257, %bb43 ]
  %v390 = phi i64 [ %v258, %bb42 ], [ %v258, %bb43 ]
  %v391 = phi i64 [ %v259, %bb42 ], [ %v259, %bb43 ]
  %v392 = phi i64 [ %v260, %bb42 ], [ %v260, %bb43 ]
  %v393 = phi i64 [ %v261, %bb42 ], [ %v261, %bb43 ]
  %v394 = phi i64 [ %v262, %bb42 ], [ %v262, %bb43 ]
  %v395 = phi i64 [ %v263, %bb42 ], [ %v263, %bb43 ]
  %v396 = phi i64 [ %v264, %bb42 ], [ %v264, %bb43 ]
  %v397 = phi i64 [ %v276, %bb42 ], [ %v276, %bb43 ]
  %v398 = phi i64 [ %v266, %bb42 ], [ %v266, %bb43 ]
  %v399 = phi i64 [ %v267, %bb42 ], [ %v267, %bb43 ]
  %v400 = phi i64 [ %v268, %bb42 ], [ %v268, %bb43 ]
  %v401 = phi i64 [ %v269, %bb42 ], [ %v269, %bb43 ]
  %v402 = phi i64 [ %v270, %bb42 ], [ %v270, %bb43 ]
  %v403 = phi i64 [ %v271, %bb42 ], [ %v271, %bb43 ]
  %v404 = phi i64 [ %v272, %bb42 ], [ %v272, %bb43 ]
  %v405 = phi i64 [ %v273, %bb42 ], [ %v273, %bb43 ]
  %v406 = phi i64 [ %v275, %bb42 ], [ %v275, %bb43 ]
  %v407 = phi i64 [ %v306, %bb42 ], [ %v306, %bb43 ]
  %v408 = phi i64 [ %v337, %bb42 ], [ %v337, %bb43 ]
  %v409 = phi i32 [ %v341, %bb42 ], [ %v341, %bb43 ]
  br label %bb26
bb42:
  br label %bb41
bb43:
  br label %bb41
bb44:
  %v411 = phi ptr [ %v247, %bb45 ], [ %v247, %bb46 ]
  %v412 = phi ptr [ %v248, %bb45 ], [ %v248, %bb46 ]
  %v414 = phi ptr [ %v250, %bb45 ], [ %v250, %bb46 ]
  %v415 = phi i64 [ %v251, %bb45 ], [ %v251, %bb46 ]
  %v416 = phi i64 [ %v252, %bb45 ], [ %v252, %bb46 ]
  %v417 = phi i64 [ %v253, %bb45 ], [ %v253, %bb46 ]
  %v418 = phi i64 [ %v337, %bb45 ], [ %v254, %bb46 ]
  %v419 = phi i64 [ %v255, %bb45 ], [ %v255, %bb46 ]
  %v420 = phi i64 [ %v256, %bb45 ], [ %v256, %bb46 ]
  %v421 = phi i64 [ %v257, %bb45 ], [ %v257, %bb46 ]
  %v422 = phi i64 [ %v258, %bb45 ], [ %v258, %bb46 ]
  %v423 = phi i64 [ %v259, %bb45 ], [ %v259, %bb46 ]
  %v424 = phi i64 [ %v260, %bb45 ], [ %v260, %bb46 ]
  %v425 = phi i64 [ %v261, %bb45 ], [ %v261, %bb46 ]
  %v426 = phi i64 [ %v262, %bb45 ], [ %v262, %bb46 ]
  %v427 = phi i64 [ %v263, %bb45 ], [ %v263, %bb46 ]
  %v428 = phi i64 [ %v264, %bb45 ], [ %v264, %bb46 ]
  %v429 = phi i64 [ %v276, %bb45 ], [ %v276, %bb46 ]
  %v430 = phi i64 [ %v266, %bb45 ], [ %v266, %bb46 ]
  %v431 = phi i64 [ %v267, %bb45 ], [ %v267, %bb46 ]
  %v432 = phi i64 [ %v268, %bb45 ], [ %v268, %bb46 ]
  %v433 = phi i64 [ %v269, %bb45 ], [ %v269, %bb46 ]
  %v434 = phi i64 [ %v270, %bb45 ], [ %v270, %bb46 ]
  %v435 = phi i64 [ %v271, %bb45 ], [ %v271, %bb46 ]
  %v436 = phi i64 [ %v272, %bb45 ], [ %v272, %bb46 ]
  %v437 = phi i64 [ %v273, %bb45 ], [ %v273, %bb46 ]
  %v438 = phi i64 [ %v275, %bb45 ], [ %v275, %bb46 ]
  %v439 = phi i64 [ %v306, %bb45 ], [ %v306, %bb46 ]
  %v440 = phi i64 [ %v337, %bb45 ], [ %v337, %bb46 ]
  %v441 = phi i32 [ %v341, %bb45 ], [ %v341, %bb46 ]
  br label %bb36
bb45:
  br label %bb44
bb46:
  br label %bb44
bb47:
  %v442 = phi ptr [ %v278, %bb30 ]
  %v443 = phi ptr [ %v279, %bb30 ]
  %v445 = phi ptr [ %v281, %bb30 ]
  %v446 = phi i64 [ %v282, %bb30 ]
  %v447 = phi i64 [ %v283, %bb30 ]
  %v448 = phi i64 [ %v284, %bb30 ]
  %v449 = phi i64 [ %v285, %bb30 ]
  %v450 = phi i64 [ %v286, %bb30 ]
  %v451 = phi i64 [ %v287, %bb30 ]
  %v452 = phi i64 [ %v288, %bb30 ]
  %v453 = phi i64 [ %v289, %bb30 ]
  %v454 = phi i64 [ %v290, %bb30 ]
  %v455 = phi i64 [ %v291, %bb30 ]
  %v456 = phi i64 [ %v292, %bb30 ]
  %v457 = phi i64 [ %v293, %bb30 ]
  %v458 = phi i64 [ %v294, %bb30 ]
  %v459 = phi i64 [ %v295, %bb30 ]
  %v460 = phi i64 [ %v296, %bb30 ]
  %v461 = phi i64 [ %v297, %bb30 ]
  %v462 = phi i64 [ %v298, %bb30 ]
  %v463 = phi i64 [ %v299, %bb30 ]
  %v464 = phi i64 [ %v300, %bb30 ]
  %v465 = phi i64 [ %v301, %bb30 ]
  %v466 = phi i64 [ %v302, %bb30 ]
  %v467 = phi i64 [ %v216, %bb30 ]
  %v468 = phi i64 [ %v217, %bb30 ]
  %v469 = phi i64 [ %v218, %bb30 ]
  %v470 = select i1 true, i64 1, i64 1
  %v471 = add i64 %v469, %v470
  br label %bb23
bb48:
  %v473 = phi ptr [ %v219, %bb50 ]
  %v474 = phi ptr [ %v220, %bb50 ]
  %v476 = phi ptr [ %v222, %bb50 ]
  %v477 = phi i64 [ %v223, %bb50 ]
  %v478 = phi i64 [ %v224, %bb50 ]
  %v479 = phi i64 [ %v225, %bb50 ]
  %v480 = phi i64 [ %v226, %bb50 ]
  %v481 = phi i64 [ %v227, %bb50 ]
  %v482 = phi i64 [ %v228, %bb50 ]
  %v483 = phi i64 [ %v229, %bb50 ]
  %v484 = phi i64 [ %v230, %bb50 ]
  %v485 = phi i64 [ %v231, %bb50 ]
  %v486 = phi i64 [ %v232, %bb50 ]
  %v487 = phi i64 [ %v233, %bb50 ]
  %v488 = phi i64 [ %v234, %bb50 ]
  %v489 = phi i64 [ %v235, %bb50 ]
  %v490 = phi i64 [ %v236, %bb50 ]
  %v491 = phi i64 [ %v237, %bb50 ]
  %v492 = phi i64 [ %v238, %bb50 ]
  %v493 = phi i64 [ %v239, %bb50 ]
  %v494 = phi i64 [ %v240, %bb50 ]
  %v495 = phi i64 [ %v241, %bb50 ]
  %v496 = phi i64 [ %v242, %bb50 ]
  %v497 = phi i64 [ %v243, %bb50 ]
  %v498 = sub nuw i64 %v482, %v486
  %v499 = add nuw i64 %v481, %v486
  %v500 = icmp ult i64 %v499, %v479
  switch i1 %v500, label %invalid.tag.b48 [
    i1 1, label %bb52
    i1 0, label %bb53
  ]
invalid.tag.b48:
  call void @abort()
  unreachable
bb49:
  br label %bb7
bb50:
  br label %bb48
bb51:
  %v501 = phi ptr [ %v473, %bb52 ], [ %v473, %bb53 ]
  %v502 = phi ptr [ %v474, %bb52 ], [ %v474, %bb53 ]
  %v504 = phi ptr [ %v476, %bb52 ], [ %v476, %bb53 ]
  %v505 = phi i64 [ %v477, %bb52 ], [ %v477, %bb53 ]
  %v506 = phi i64 [ %v478, %bb52 ], [ %v478, %bb53 ]
  %v507 = phi i64 [ %v479, %bb52 ], [ %v479, %bb53 ]
  %v508 = phi i64 [ %v480, %bb52 ], [ %v480, %bb53 ]
  %v509 = phi i64 [ %v499, %bb52 ], [ %v527, %bb53 ]
  %v510 = phi i64 [ %v498, %bb52 ], [ %v498, %bb53 ]
  %v511 = phi i64 [ %v483, %bb52 ], [ %v483, %bb53 ]
  %v512 = phi i64 [ %v484, %bb52 ], [ %v484, %bb53 ]
  %v513 = phi i64 [ %v485, %bb52 ], [ %v485, %bb53 ]
  %v514 = phi i64 [ %v486, %bb52 ], [ %v486, %bb53 ]
  %v515 = phi i64 [ %v487, %bb52 ], [ %v487, %bb53 ]
  %v516 = phi i64 [ %v488, %bb52 ], [ %v488, %bb53 ]
  %v517 = phi i64 [ %v489, %bb52 ], [ %v489, %bb53 ]
  %v518 = phi i64 [ %v490, %bb52 ], [ %v490, %bb53 ]
  %v519 = phi i64 [ %v491, %bb52 ], [ %v491, %bb53 ]
  %v520 = phi i64 [ %v492, %bb52 ], [ %v492, %bb53 ]
  %v521 = phi i64 [ %v493, %bb52 ], [ %v493, %bb53 ]
  %v522 = phi i64 [ %v494, %bb52 ], [ %v494, %bb53 ]
  %v523 = phi i64 [ %v495, %bb52 ], [ %v495, %bb53 ]
  %v524 = phi i64 [ %v496, %bb52 ], [ %v496, %bb53 ]
  %v525 = phi i64 [ %v497, %bb52 ], [ %v497, %bb53 ]
  %v526 = phi i64 [ %v499, %bb52 ], [ %v499, %bb53 ]
  br label %bb54
bb52:
  br label %bb51
bb53:
  %v527 = select i1 true, i64 0, i64 0
  br label %bb51
bb54:
  %v528 = phi ptr [ %v501, %bb51 ]
  %v529 = phi ptr [ %v502, %bb51 ]
  %v531 = phi ptr [ %v504, %bb51 ]
  %v532 = phi i64 [ %v505, %bb51 ]
  %v533 = phi i64 [ %v506, %bb51 ]
  %v534 = phi i64 [ %v507, %bb51 ]
  %v535 = phi i64 [ %v508, %bb51 ]
  %v536 = phi i64 [ %v509, %bb51 ]
  %v537 = phi i64 [ %v510, %bb51 ]
  %v538 = phi i64 [ %v32, %bb51 ]
  %v539 = phi i64 [ %v33, %bb51 ]
  %v540 = phi i64 [ %v34, %bb51 ]
  %v541 = select i1 true, i64 1, i64 1
  %v542 = add i64 %v540, %v541
  br label %bb4
bb55:
  %v544 = phi ptr [ %v12, %bb57 ], [ %v556, %bb58 ]
  %v545 = phi ptr [ %v13, %bb57 ], [ %v557, %bb58 ]
  %v547 = phi ptr [ %v15, %bb57 ], [ %v559, %bb58 ]
  %v548 = phi i64 [ %v16, %bb57 ], [ %v560, %bb58 ]
  %v549 = phi i64 [ %v17, %bb57 ], [ %v561, %bb58 ]
  %v550 = phi i64 [ %v18, %bb57 ], [ %v562, %bb58 ]
  %v551 = phi i64 [ %v19, %bb57 ], [ %v563, %bb58 ]
  %v587 = load i64, ptr %v545
  store %wf.t.20dda3774c7510ec zeroinitializer, ptr %wf.slot.2
  %t10 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.2, i32 0, i32 0
  store i64 %v587, ptr %t10
  %t11 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.2, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t11, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %v589 = or i1 0, 1
  store %wf.t.9d321e1eb2ec1c03 zeroinitializer, ptr %wf.result
  %t12 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t12
  %t13 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 1
  store i1 %v589, ptr %t13
  %t14 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %wf.slot.2, i64 ptrtoint (ptr getelementptr (%wf.t.20dda3774c7510ec, ptr null, i32 1) to i64), i1 false)
  ret void
bb56:
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v12, i64 ptrtoint (ptr getelementptr (%wf.t.a5ea622fe32c85b6, ptr null, i32 1) to i64), i1 false)
  %t15 = getelementptr inbounds %wf.t.a5ea622fe32c85b6, ptr %wf.slot.1, i32 0, i32 1
  %v553 = load i64, ptr %t15
  %v554 = select i1 true, i64 3, i64 3
  %v555 = icmp ult i64 %v553, %v554
  switch i1 %v555, label %invalid.tag.b56 [
    i1 1, label %bb59
    i1 0, label %bb60
  ]
invalid.tag.b56:
  call void @abort()
  unreachable
bb57:
  br label %bb55
bb58:
  %v556 = phi ptr [ %v12, %bb60 ]
  %v557 = phi ptr [ %v13, %bb60 ]
  %v559 = phi ptr [ %v15, %bb60 ]
  %v560 = phi i64 [ %v16, %bb60 ]
  %v561 = phi i64 [ %v17, %bb60 ]
  %v562 = phi i64 [ %v18, %bb60 ]
  %v563 = phi i64 [ %v19, %bb60 ]
  %v564 = phi i64 [ %v553, %bb60 ]
  br label %bb55
bb59:
  %t16 = getelementptr inbounds %wf.t.a5ea622fe32c85b6, ptr %v12, i32 0, i32 0
  %v565 = getelementptr i8, ptr %t16, i64 0
  %v566 = load i64, ptr %v13
  call void @wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449(ptr %v568, ptr %v565, i64 %v19, i64 %v566, ptr %wf.slot.0)
  %t17 = getelementptr inbounds %wf.t.a5ea622fe32c85b6, ptr %v12, i32 0, i32 2
  %v569 = getelementptr i8, ptr %t17, i64 0
  %v570 = call i8 @wf_hash_map.hash_map_control_set(ptr %v569, i64 %v19, i64 %v17)
  %v571 = call i1 @wf_hash_map.hash_map_control_inserted$instance$d7a1a90c27bba449(ptr %v568)
  switch i1 %v571, label %invalid.tag.b59 [
    i1 1, label %bb62
    i1 0, label %bb63
  ]
invalid.tag.b59:
  call void @abort()
  unreachable
bb60:
  br label %bb58
bb61:
  %v572 = phi ptr [ %v12, %bb62 ], [ %v12, %bb63 ]
  %v573 = phi ptr [ %v13, %bb62 ], [ %v13, %bb63 ]
  %v575 = phi ptr [ %v15, %bb62 ], [ %v15, %bb63 ]
  %v576 = phi i64 [ %v16, %bb62 ], [ %v16, %bb63 ]
  %v577 = phi i64 [ %v17, %bb62 ], [ %v17, %bb63 ]
  %v578 = phi i64 [ %v18, %bb62 ], [ %v18, %bb63 ]
  %v579 = phi i64 [ %v19, %bb62 ], [ %v19, %bb63 ]
  %v580 = phi i64 [ %v553, %bb62 ], [ %v553, %bb63 ]
  %v581 = phi ptr [ %v568, %bb62 ], [ %v568, %bb63 ]
  %v582 = phi i1 [ %v571, %bb62 ], [ %v571, %bb63 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.result, ptr %v581, i64 ptrtoint (ptr getelementptr (%wf.t.9d321e1eb2ec1c03, ptr null, i32 1) to i64), i1 false)
  ret void
bb62:
  %t18 = getelementptr inbounds %wf.t.a5ea622fe32c85b6, ptr %v12, i32 0, i32 1
  %v583 = getelementptr i8, ptr %t18, i64 0
  %v584 = select i1 true, i64 1, i64 1
  %v585 = add nuw i64 %v553, %v584
  store i64 %v585, ptr %v583
  br label %bb61
bb63:
  br label %bb61
}

define internal void @wf_hash_map.hash_map_reserve$instance$8d5197e2f00c3b07.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %v3 = select i1 true, i64 3, i64 3
  %v4 = icmp ugt i64 %v1, %v3
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v5 = phi ptr [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb3 ]
  %v7 = phi ptr [ %v2, %bb3 ]
  %t0 = getelementptr inbounds %wf.t.a5ea622fe32c85b6, ptr %v5, i32 0, i32 0
  %v10 = getelementptr i8, ptr %t0, i64 0
  %v11 = getelementptr i8, ptr %v10, i64 0
  %t2 = load ptr, ptr %v11
  %t3 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t2, i32 0, i32 0
  %t1 = load i64, ptr %t3
  %v12 = add i64 %t1, 0
  %v13 = icmp ule i64 %v6, %v12
  switch i1 %v13, label %invalid.tag.b1 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v8 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t4 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t4
  %t5 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 2
  store i8 %v8, ptr %t5
  ret void
bb3:
  br label %bb1
bb4:
  %v14 = phi ptr [ %v5, %bb6 ]
  %v15 = phi i64 [ %v6, %bb6 ]
  %v16 = phi ptr [ %v7, %bb6 ]
  %v19 = call %wf.t.7d7f918f7b4962fd @wf_hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07(ptr %v14, i64 %v15, ptr %v16)
  store %wf.t.7d7f918f7b4962fd %v19, ptr %wf.result
  ret void
bb5:
  %v17 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t6 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t6
  %t7 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 1
  store i8 %v17, ptr %t7
  ret void
bb6:
  br label %bb4
}

define %wf.t.7d7f918f7b4962fd @wf_hash_map.hash_map_reserve$instance$8d5197e2f00c3b07(ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.result = alloca %wf.t.7d7f918f7b4962fd, align 4
  call void @wf_hash_map.hash_map_reserve$instance$8d5197e2f00c3b07.body(ptr %wf.result, ptr %v0, i64 %v1, ptr %v2)
  %wf.returned = load %wf.t.7d7f918f7b4962fd, ptr %wf.result
  ret %wf.t.7d7f918f7b4962fd %wf.returned
}

define i8 @wf_hash_map.hash_map_extend$instance$0e108827ecbbe374(ptr noalias nonnull captures(none) dereferenceable(8) %v0, i64 %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.e04aead91f34a68f, align 8
  %v2 = getelementptr i8, ptr %v0, i64 0
  %t1 = load ptr, ptr %v2
  %t2 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t1, i32 0, i32 1
  %t0 = load i64, ptr %t2
  %v3 = add i64 %t0, 0
  %v4 = icmp ult i64 %v3, %v1
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v5 = phi ptr [ %v0, %bb2 ], [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb2 ], [ %v1, %bb3 ]
  %v8 = getelementptr i8, ptr %v5, i64 0
  %t4 = load ptr, ptr %v8
  %t5 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t4, i32 0, i32 0
  %t3 = load i64, ptr %t5
  %v9 = add i64 %t3, 0
  br label %bb4
bb2:
  %v7 = call i8 @wf_grow$instance$b1cfa6e689dc9e10(ptr %v0, i64 %v1)
  br label %bb1
bb3:
  br label %bb1
bb4:
  %v10 = phi ptr [ %v5, %bb1 ], [ %v23, %bb8 ]
  %v11 = phi i64 [ %v6, %bb1 ], [ %v24, %bb8 ]
  %v12 = phi i64 [ %v9, %bb1 ], [ %v25, %bb8 ]
  %v13 = phi i64 [ %v9, %bb1 ], [ %v26, %bb8 ]
  %v14 = phi i64 [ %v6, %bb1 ], [ %v27, %bb8 ]
  %v15 = phi i64 [ %v9, %bb1 ], [ %v30, %bb8 ]
  %v19 = icmp ult i64 %v15, %v14
  switch i1 %v19, label %invalid.tag.b4 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b4:
  call void @abort()
  unreachable
bb5:
  store %wf.t.e04aead91f34a68f zeroinitializer, ptr %wf.slot.0
  %t6 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %wf.slot.0, i32 0, i32 0
  store i32 0, ptr %t6
  %v21 = getelementptr i8, ptr %v10, i64 0
  %v22 = call i8 @wf_place_back$instance$2af1311599ac146a(ptr %v21, ptr %wf.slot.0)
  br label %bb8
bb6:
  br label %bb7
bb7:
  %v16 = phi ptr [ %v10, %bb6 ]
  %v17 = phi i64 [ %v11, %bb6 ]
  %v18 = phi i64 [ %v12, %bb6 ]
  %v31 = select i1 true, i8 0, i8 0
  ret i8 %v31
bb8:
  %v23 = phi ptr [ %v10, %bb5 ]
  %v24 = phi i64 [ %v11, %bb5 ]
  %v25 = phi i64 [ %v12, %bb5 ]
  %v26 = phi i64 [ %v13, %bb5 ]
  %v27 = phi i64 [ %v14, %bb5 ]
  %v28 = phi i64 [ %v15, %bb5 ]
  %v29 = select i1 true, i64 1, i64 1
  %v30 = add i64 %v28, %v29
  br label %bb4
}

define void @wf_hash_map.hash_map_try_put$instance$28da32efc51c2b65(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr %wf.arg.v2, ptr noalias nonnull captures(none) dereferenceable(16) %v3) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.1 = alloca %wf.t.05623e8a192b9069, align 8
  %wf.slot.2 = alloca %wf.t.20dda3774c7510ec, align 8
  %v4 = alloca i64, align 8
  %v568 = alloca %wf.t.9d321e1eb2ec1c03, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v2, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  store i64 %v1, ptr %v4
  %v5 = call i64 @wf_map_cost_hash(ptr %v3, ptr %v4)
  %v6 = call i64 @wf_hash_map.hash_map_control_fingerprint(i64 %v5)
  %t0 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v0, i32 0, i32 0
  %v7 = getelementptr i8, ptr %t0, i64 0
  %v8 = getelementptr i8, ptr %v7, i64 0
  %t2 = load ptr, ptr %v8
  %t3 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t2, i32 0, i32 0
  %t1 = load i64, ptr %t3
  %v9 = add i64 %t1, 0
  %v10 = select i1 true, i64 0, i64 0
  %v11 = icmp ugt i64 %v9, %v10
  switch i1 %v11, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v12 = phi ptr [ %v0, %bb3 ], [ %v35, %bb7 ]
  %v13 = phi ptr [ %v4, %bb3 ], [ %v36, %bb7 ]
  %v15 = phi ptr [ %v3, %bb3 ], [ %v38, %bb7 ]
  %v16 = phi i64 [ %v5, %bb3 ], [ %v39, %bb7 ]
  %v17 = phi i64 [ %v6, %bb3 ], [ %v40, %bb7 ]
  %v18 = phi i64 [ %v9, %bb3 ], [ %v41, %bb7 ]
  %v19 = phi i64 [ %v9, %bb3 ], [ %v42, %bb7 ]
  %v543 = icmp ult i64 %v19, %v18
  switch i1 %v543, label %invalid.tag.b1 [
    i1 1, label %bb56
    i1 0, label %bb57
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v20 = urem i64 %v5, %v9
  %v21 = select i1 true, i64 0, i64 0
  br label %bb4
bb3:
  br label %bb1
bb4:
  %v22 = phi ptr [ %v0, %bb2 ], [ %v528, %bb54 ]
  %v23 = phi ptr [ %v4, %bb2 ], [ %v529, %bb54 ]
  %v25 = phi ptr [ %v3, %bb2 ], [ %v531, %bb54 ]
  %v26 = phi i64 [ %v5, %bb2 ], [ %v532, %bb54 ]
  %v27 = phi i64 [ %v6, %bb2 ], [ %v533, %bb54 ]
  %v28 = phi i64 [ %v9, %bb2 ], [ %v534, %bb54 ]
  %v29 = phi i64 [ %v9, %bb2 ], [ %v535, %bb54 ]
  %v30 = phi i64 [ %v20, %bb2 ], [ %v536, %bb54 ]
  %v31 = phi i64 [ %v9, %bb2 ], [ %v537, %bb54 ]
  %v32 = phi i64 [ %v21, %bb2 ], [ %v538, %bb54 ]
  %v33 = phi i64 [ %v9, %bb2 ], [ %v539, %bb54 ]
  %v34 = phi i64 [ %v21, %bb2 ], [ %v542, %bb54 ]
  %v45 = icmp ult i64 %v34, %v33
  switch i1 %v45, label %invalid.tag.b4 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b4:
  call void @abort()
  unreachable
bb5:
  %v46 = select i1 true, i64 0, i64 0
  %v47 = icmp eq i64 %v31, %v46
  switch i1 %v47, label %invalid.tag.b5 [
    i1 1, label %bb9
    i1 0, label %bb10
  ]
invalid.tag.b5:
  call void @abort()
  unreachable
bb6:
  br label %bb7
bb7:
  %v35 = phi ptr [ %v22, %bb6 ], [ %v22, %bb9 ], [ %v219, %bb49 ]
  %v36 = phi ptr [ %v23, %bb6 ], [ %v23, %bb9 ], [ %v220, %bb49 ]
  %v38 = phi ptr [ %v25, %bb6 ], [ %v25, %bb9 ], [ %v222, %bb49 ]
  %v39 = phi i64 [ %v26, %bb6 ], [ %v26, %bb9 ], [ %v223, %bb49 ]
  %v40 = phi i64 [ %v27, %bb6 ], [ %v27, %bb9 ], [ %v224, %bb49 ]
  %v41 = phi i64 [ %v28, %bb6 ], [ %v28, %bb9 ], [ %v225, %bb49 ]
  %v42 = phi i64 [ %v29, %bb6 ], [ %v29, %bb9 ], [ %v226, %bb49 ]
  %v43 = phi i64 [ %v30, %bb6 ], [ %v30, %bb9 ], [ %v227, %bb49 ]
  %v44 = phi i64 [ %v31, %bb6 ], [ %v31, %bb9 ], [ %v228, %bb49 ]
  br label %bb1
bb8:
  %v48 = phi ptr [ %v22, %bb10 ]
  %v49 = phi ptr [ %v23, %bb10 ]
  %v51 = phi ptr [ %v25, %bb10 ]
  %v52 = phi i64 [ %v26, %bb10 ]
  %v53 = phi i64 [ %v27, %bb10 ]
  %v54 = phi i64 [ %v28, %bb10 ]
  %v55 = phi i64 [ %v29, %bb10 ]
  %v56 = phi i64 [ %v30, %bb10 ]
  %v57 = phi i64 [ %v31, %bb10 ]
  %v58 = phi i64 [ %v34, %bb10 ]
  %v59 = select i1 true, i64 8, i64 8
  %v60 = urem i64 %v56, %v59
  %v61 = sub nuw i64 %v54, %v56
  %v62 = call i64 @wf_hash_map.hash_map_control_span(i64 %v60, i64 %v61, i64 %v57)
  %v63 = select i1 true, i64 8, i64 8
  %v64 = udiv i64 %v56, %v63
  %t4 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v48, i32 0, i32 2
  %v65 = getelementptr i8, ptr %t4, i64 0
  %v66 = call i64 @wf_hash_map.hash_map_control_word(ptr %v65, i64 %v64)
  %v67 = call i64 @wf_hash_map.hash_map_control_active(i64 %v60, i64 %v62)
  %v68 = call i64 @wf_hash_map.hash_map_control_equal(i64 %v66, i64 %v53)
  %v69 = and i64 %v68, %v67
  %v70 = select i1 true, i64 128, i64 128
  %v71 = call i64 @wf_hash_map.hash_map_control_equal(i64 %v66, i64 %v70)
  %v72 = and i64 %v71, %v67
  %v73 = select i1 true, i64 254, i64 254
  %v74 = call i64 @wf_hash_map.hash_map_control_equal(i64 %v66, i64 %v73)
  %v75 = and i64 %v74, %v67
  %v76 = or i64 %v72, %v75
  %v77 = call i64 @wf_hash_map.hash_map_control_stop(i64 %v72, i64 %v60, i64 %v62)
  %v78 = icmp eq i64 %v55, %v54
  switch i1 %v78, label %invalid.tag.b8 [
    i1 1, label %bb12
    i1 0, label %bb13
  ]
invalid.tag.b8:
  call void @abort()
  unreachable
bb9:
  br label %bb7
bb10:
  br label %bb8
bb11:
  %v79 = phi ptr [ %v48, %bb13 ], [ %v106, %bb14 ]
  %v80 = phi ptr [ %v49, %bb13 ], [ %v107, %bb14 ]
  %v82 = phi ptr [ %v51, %bb13 ], [ %v109, %bb14 ]
  %v83 = phi i64 [ %v52, %bb13 ], [ %v110, %bb14 ]
  %v84 = phi i64 [ %v53, %bb13 ], [ %v111, %bb14 ]
  %v85 = phi i64 [ %v54, %bb13 ], [ %v112, %bb14 ]
  %v86 = phi i64 [ %v55, %bb13 ], [ %v113, %bb14 ]
  %v87 = phi i64 [ %v56, %bb13 ], [ %v114, %bb14 ]
  %v88 = phi i64 [ %v57, %bb13 ], [ %v115, %bb14 ]
  %v89 = phi i64 [ %v58, %bb13 ], [ %v116, %bb14 ]
  %v90 = phi i64 [ %v60, %bb13 ], [ %v117, %bb14 ]
  %v91 = phi i64 [ %v61, %bb13 ], [ %v118, %bb14 ]
  %v92 = phi i64 [ %v62, %bb13 ], [ %v119, %bb14 ]
  %v93 = phi i64 [ %v64, %bb13 ], [ %v120, %bb14 ]
  %v94 = phi i64 [ %v66, %bb13 ], [ %v121, %bb14 ]
  %v95 = phi i64 [ %v67, %bb13 ], [ %v122, %bb14 ]
  %v96 = phi i64 [ %v68, %bb13 ], [ %v123, %bb14 ]
  %v97 = phi i64 [ %v69, %bb13 ], [ %v124, %bb14 ]
  %v98 = phi i64 [ %v71, %bb13 ], [ %v125, %bb14 ]
  %v99 = phi i64 [ %v72, %bb13 ], [ %v126, %bb14 ]
  %v100 = phi i64 [ %v74, %bb13 ], [ %v127, %bb14 ]
  %v101 = phi i64 [ %v75, %bb13 ], [ %v128, %bb14 ]
  %v102 = phi i64 [ %v76, %bb13 ], [ %v129, %bb14 ]
  %v103 = phi i64 [ %v77, %bb13 ], [ %v130, %bb14 ]
  %v189 = select i1 true, i64 0, i64 0
  %v190 = select i1 true, i64 8, i64 8
  br label %bb23
bb12:
  %v104 = select i1 true, i64 0, i64 0
  %v105 = icmp ugt i64 %v76, %v104
  switch i1 %v105, label %invalid.tag.b12 [
    i1 1, label %bb15
    i1 0, label %bb16
  ]
invalid.tag.b12:
  call void @abort()
  unreachable
bb13:
  br label %bb11
bb14:
  %v106 = phi ptr [ %v48, %bb16 ], [ %v133, %bb17 ]
  %v107 = phi ptr [ %v49, %bb16 ], [ %v134, %bb17 ]
  %v109 = phi ptr [ %v51, %bb16 ], [ %v136, %bb17 ]
  %v110 = phi i64 [ %v52, %bb16 ], [ %v137, %bb17 ]
  %v111 = phi i64 [ %v53, %bb16 ], [ %v138, %bb17 ]
  %v112 = phi i64 [ %v54, %bb16 ], [ %v139, %bb17 ]
  %v113 = phi i64 [ %v55, %bb16 ], [ %v140, %bb17 ]
  %v114 = phi i64 [ %v56, %bb16 ], [ %v141, %bb17 ]
  %v115 = phi i64 [ %v57, %bb16 ], [ %v142, %bb17 ]
  %v116 = phi i64 [ %v58, %bb16 ], [ %v143, %bb17 ]
  %v117 = phi i64 [ %v60, %bb16 ], [ %v144, %bb17 ]
  %v118 = phi i64 [ %v61, %bb16 ], [ %v145, %bb17 ]
  %v119 = phi i64 [ %v62, %bb16 ], [ %v146, %bb17 ]
  %v120 = phi i64 [ %v64, %bb16 ], [ %v147, %bb17 ]
  %v121 = phi i64 [ %v66, %bb16 ], [ %v148, %bb17 ]
  %v122 = phi i64 [ %v67, %bb16 ], [ %v149, %bb17 ]
  %v123 = phi i64 [ %v68, %bb16 ], [ %v150, %bb17 ]
  %v124 = phi i64 [ %v69, %bb16 ], [ %v151, %bb17 ]
  %v125 = phi i64 [ %v71, %bb16 ], [ %v152, %bb17 ]
  %v126 = phi i64 [ %v72, %bb16 ], [ %v153, %bb17 ]
  %v127 = phi i64 [ %v74, %bb16 ], [ %v154, %bb17 ]
  %v128 = phi i64 [ %v75, %bb16 ], [ %v155, %bb17 ]
  %v129 = phi i64 [ %v76, %bb16 ], [ %v156, %bb17 ]
  %v130 = phi i64 [ %v77, %bb16 ], [ %v157, %bb17 ]
  br label %bb11
bb15:
  %v131 = call i64 @wf_hash_map.hash_map_control_first(i64 %v76)
  %v132 = icmp uge i64 %v131, %v60
  switch i1 %v132, label %invalid.tag.b15 [
    i1 1, label %bb18
    i1 0, label %bb19
  ]
invalid.tag.b15:
  call void @abort()
  unreachable
bb16:
  br label %bb14
bb17:
  %v133 = phi ptr [ %v48, %bb19 ], [ %v161, %bb20 ]
  %v134 = phi ptr [ %v49, %bb19 ], [ %v162, %bb20 ]
  %v136 = phi ptr [ %v51, %bb19 ], [ %v164, %bb20 ]
  %v137 = phi i64 [ %v52, %bb19 ], [ %v165, %bb20 ]
  %v138 = phi i64 [ %v53, %bb19 ], [ %v166, %bb20 ]
  %v139 = phi i64 [ %v54, %bb19 ], [ %v167, %bb20 ]
  %v140 = phi i64 [ %v55, %bb19 ], [ %v168, %bb20 ]
  %v141 = phi i64 [ %v56, %bb19 ], [ %v169, %bb20 ]
  %v142 = phi i64 [ %v57, %bb19 ], [ %v170, %bb20 ]
  %v143 = phi i64 [ %v58, %bb19 ], [ %v171, %bb20 ]
  %v144 = phi i64 [ %v60, %bb19 ], [ %v172, %bb20 ]
  %v145 = phi i64 [ %v61, %bb19 ], [ %v173, %bb20 ]
  %v146 = phi i64 [ %v62, %bb19 ], [ %v174, %bb20 ]
  %v147 = phi i64 [ %v64, %bb19 ], [ %v175, %bb20 ]
  %v148 = phi i64 [ %v66, %bb19 ], [ %v176, %bb20 ]
  %v149 = phi i64 [ %v67, %bb19 ], [ %v177, %bb20 ]
  %v150 = phi i64 [ %v68, %bb19 ], [ %v178, %bb20 ]
  %v151 = phi i64 [ %v69, %bb19 ], [ %v179, %bb20 ]
  %v152 = phi i64 [ %v71, %bb19 ], [ %v180, %bb20 ]
  %v153 = phi i64 [ %v72, %bb19 ], [ %v181, %bb20 ]
  %v154 = phi i64 [ %v74, %bb19 ], [ %v182, %bb20 ]
  %v155 = phi i64 [ %v75, %bb19 ], [ %v183, %bb20 ]
  %v156 = phi i64 [ %v76, %bb19 ], [ %v184, %bb20 ]
  %v157 = phi i64 [ %v77, %bb19 ], [ %v185, %bb20 ]
  %v158 = phi i64 [ %v131, %bb19 ], [ %v186, %bb20 ]
  br label %bb14
bb18:
  %v159 = sub nuw i64 %v131, %v60
  %v160 = icmp ult i64 %v159, %v62
  switch i1 %v160, label %invalid.tag.b18 [
    i1 1, label %bb21
    i1 0, label %bb22
  ]
invalid.tag.b18:
  call void @abort()
  unreachable
bb19:
  br label %bb17
bb20:
  %v161 = phi ptr [ %v48, %bb21 ], [ %v48, %bb22 ]
  %v162 = phi ptr [ %v49, %bb21 ], [ %v49, %bb22 ]
  %v164 = phi ptr [ %v51, %bb21 ], [ %v51, %bb22 ]
  %v165 = phi i64 [ %v52, %bb21 ], [ %v52, %bb22 ]
  %v166 = phi i64 [ %v53, %bb21 ], [ %v53, %bb22 ]
  %v167 = phi i64 [ %v54, %bb21 ], [ %v54, %bb22 ]
  %v168 = phi i64 [ %v188, %bb21 ], [ %v55, %bb22 ]
  %v169 = phi i64 [ %v56, %bb21 ], [ %v56, %bb22 ]
  %v170 = phi i64 [ %v57, %bb21 ], [ %v57, %bb22 ]
  %v171 = phi i64 [ %v58, %bb21 ], [ %v58, %bb22 ]
  %v172 = phi i64 [ %v60, %bb21 ], [ %v60, %bb22 ]
  %v173 = phi i64 [ %v61, %bb21 ], [ %v61, %bb22 ]
  %v174 = phi i64 [ %v62, %bb21 ], [ %v62, %bb22 ]
  %v175 = phi i64 [ %v64, %bb21 ], [ %v64, %bb22 ]
  %v176 = phi i64 [ %v66, %bb21 ], [ %v66, %bb22 ]
  %v177 = phi i64 [ %v67, %bb21 ], [ %v67, %bb22 ]
  %v178 = phi i64 [ %v68, %bb21 ], [ %v68, %bb22 ]
  %v179 = phi i64 [ %v69, %bb21 ], [ %v69, %bb22 ]
  %v180 = phi i64 [ %v71, %bb21 ], [ %v71, %bb22 ]
  %v181 = phi i64 [ %v72, %bb21 ], [ %v72, %bb22 ]
  %v182 = phi i64 [ %v74, %bb21 ], [ %v74, %bb22 ]
  %v183 = phi i64 [ %v75, %bb21 ], [ %v75, %bb22 ]
  %v184 = phi i64 [ %v76, %bb21 ], [ %v76, %bb22 ]
  %v185 = phi i64 [ %v77, %bb21 ], [ %v77, %bb22 ]
  %v186 = phi i64 [ %v131, %bb21 ], [ %v131, %bb22 ]
  %v187 = phi i64 [ %v159, %bb21 ], [ %v159, %bb22 ]
  br label %bb17
bb21:
  %v188 = add nuw i64 %v56, %v159
  br label %bb20
bb22:
  br label %bb20
bb23:
  %v191 = phi ptr [ %v79, %bb11 ], [ %v442, %bb47 ]
  %v192 = phi ptr [ %v80, %bb11 ], [ %v443, %bb47 ]
  %v194 = phi ptr [ %v82, %bb11 ], [ %v445, %bb47 ]
  %v195 = phi i64 [ %v83, %bb11 ], [ %v446, %bb47 ]
  %v196 = phi i64 [ %v84, %bb11 ], [ %v447, %bb47 ]
  %v197 = phi i64 [ %v85, %bb11 ], [ %v448, %bb47 ]
  %v198 = phi i64 [ %v86, %bb11 ], [ %v449, %bb47 ]
  %v199 = phi i64 [ %v87, %bb11 ], [ %v450, %bb47 ]
  %v200 = phi i64 [ %v88, %bb11 ], [ %v451, %bb47 ]
  %v201 = phi i64 [ %v89, %bb11 ], [ %v452, %bb47 ]
  %v202 = phi i64 [ %v90, %bb11 ], [ %v453, %bb47 ]
  %v203 = phi i64 [ %v91, %bb11 ], [ %v454, %bb47 ]
  %v204 = phi i64 [ %v92, %bb11 ], [ %v455, %bb47 ]
  %v205 = phi i64 [ %v93, %bb11 ], [ %v456, %bb47 ]
  %v206 = phi i64 [ %v94, %bb11 ], [ %v457, %bb47 ]
  %v207 = phi i64 [ %v95, %bb11 ], [ %v458, %bb47 ]
  %v208 = phi i64 [ %v96, %bb11 ], [ %v459, %bb47 ]
  %v209 = phi i64 [ %v97, %bb11 ], [ %v460, %bb47 ]
  %v210 = phi i64 [ %v98, %bb11 ], [ %v461, %bb47 ]
  %v211 = phi i64 [ %v99, %bb11 ], [ %v462, %bb47 ]
  %v212 = phi i64 [ %v100, %bb11 ], [ %v463, %bb47 ]
  %v213 = phi i64 [ %v101, %bb11 ], [ %v464, %bb47 ]
  %v214 = phi i64 [ %v102, %bb11 ], [ %v465, %bb47 ]
  %v215 = phi i64 [ %v103, %bb11 ], [ %v466, %bb47 ]
  %v216 = phi i64 [ %v189, %bb11 ], [ %v467, %bb47 ]
  %v217 = phi i64 [ %v190, %bb11 ], [ %v468, %bb47 ]
  %v218 = phi i64 [ %v189, %bb11 ], [ %v471, %bb47 ]
  %v244 = icmp ult i64 %v218, %v217
  switch i1 %v244, label %invalid.tag.b23 [
    i1 1, label %bb24
    i1 0, label %bb25
  ]
invalid.tag.b23:
  call void @abort()
  unreachable
bb24:
  %v245 = select i1 true, i64 0, i64 0
  %v246 = icmp eq i64 %v209, %v245
  switch i1 %v246, label %invalid.tag.b24 [
    i1 1, label %bb28
    i1 0, label %bb29
  ]
invalid.tag.b24:
  call void @abort()
  unreachable
bb25:
  br label %bb26
bb26:
  %v219 = phi ptr [ %v191, %bb25 ], [ %v191, %bb28 ], [ %v379, %bb41 ]
  %v220 = phi ptr [ %v192, %bb25 ], [ %v192, %bb28 ], [ %v380, %bb41 ]
  %v222 = phi ptr [ %v194, %bb25 ], [ %v194, %bb28 ], [ %v382, %bb41 ]
  %v223 = phi i64 [ %v195, %bb25 ], [ %v195, %bb28 ], [ %v383, %bb41 ]
  %v224 = phi i64 [ %v196, %bb25 ], [ %v196, %bb28 ], [ %v384, %bb41 ]
  %v225 = phi i64 [ %v197, %bb25 ], [ %v197, %bb28 ], [ %v385, %bb41 ]
  %v226 = phi i64 [ %v198, %bb25 ], [ %v198, %bb28 ], [ %v386, %bb41 ]
  %v227 = phi i64 [ %v199, %bb25 ], [ %v199, %bb28 ], [ %v387, %bb41 ]
  %v228 = phi i64 [ %v200, %bb25 ], [ %v200, %bb28 ], [ %v388, %bb41 ]
  %v229 = phi i64 [ %v201, %bb25 ], [ %v201, %bb28 ], [ %v389, %bb41 ]
  %v230 = phi i64 [ %v202, %bb25 ], [ %v202, %bb28 ], [ %v390, %bb41 ]
  %v231 = phi i64 [ %v203, %bb25 ], [ %v203, %bb28 ], [ %v391, %bb41 ]
  %v232 = phi i64 [ %v204, %bb25 ], [ %v204, %bb28 ], [ %v392, %bb41 ]
  %v233 = phi i64 [ %v205, %bb25 ], [ %v205, %bb28 ], [ %v393, %bb41 ]
  %v234 = phi i64 [ %v206, %bb25 ], [ %v206, %bb28 ], [ %v394, %bb41 ]
  %v235 = phi i64 [ %v207, %bb25 ], [ %v207, %bb28 ], [ %v395, %bb41 ]
  %v236 = phi i64 [ %v208, %bb25 ], [ %v208, %bb28 ], [ %v396, %bb41 ]
  %v237 = phi i64 [ %v209, %bb25 ], [ %v209, %bb28 ], [ %v397, %bb41 ]
  %v238 = phi i64 [ %v210, %bb25 ], [ %v210, %bb28 ], [ %v398, %bb41 ]
  %v239 = phi i64 [ %v211, %bb25 ], [ %v211, %bb28 ], [ %v399, %bb41 ]
  %v240 = phi i64 [ %v212, %bb25 ], [ %v212, %bb28 ], [ %v400, %bb41 ]
  %v241 = phi i64 [ %v213, %bb25 ], [ %v213, %bb28 ], [ %v401, %bb41 ]
  %v242 = phi i64 [ %v214, %bb25 ], [ %v214, %bb28 ], [ %v402, %bb41 ]
  %v243 = phi i64 [ %v215, %bb25 ], [ %v215, %bb28 ], [ %v407, %bb41 ]
  %v472 = icmp ult i64 %v243, %v232
  switch i1 %v472, label %invalid.tag.b26 [
    i1 1, label %bb49
    i1 0, label %bb50
  ]
invalid.tag.b26:
  call void @abort()
  unreachable
bb27:
  %v247 = phi ptr [ %v191, %bb29 ]
  %v248 = phi ptr [ %v192, %bb29 ]
  %v250 = phi ptr [ %v194, %bb29 ]
  %v251 = phi i64 [ %v195, %bb29 ]
  %v252 = phi i64 [ %v196, %bb29 ]
  %v253 = phi i64 [ %v197, %bb29 ]
  %v254 = phi i64 [ %v198, %bb29 ]
  %v255 = phi i64 [ %v199, %bb29 ]
  %v256 = phi i64 [ %v200, %bb29 ]
  %v257 = phi i64 [ %v201, %bb29 ]
  %v258 = phi i64 [ %v202, %bb29 ]
  %v259 = phi i64 [ %v203, %bb29 ]
  %v260 = phi i64 [ %v204, %bb29 ]
  %v261 = phi i64 [ %v205, %bb29 ]
  %v262 = phi i64 [ %v206, %bb29 ]
  %v263 = phi i64 [ %v207, %bb29 ]
  %v264 = phi i64 [ %v208, %bb29 ]
  %v265 = phi i64 [ %v209, %bb29 ]
  %v266 = phi i64 [ %v210, %bb29 ]
  %v267 = phi i64 [ %v211, %bb29 ]
  %v268 = phi i64 [ %v212, %bb29 ]
  %v269 = phi i64 [ %v213, %bb29 ]
  %v270 = phi i64 [ %v214, %bb29 ]
  %v271 = phi i64 [ %v215, %bb29 ]
  %v272 = phi i64 [ %v218, %bb29 ]
  %v273 = call i64 @wf_hash_map.hash_map_control_first(i64 %v265)
  %v274 = select i1 true, i64 1, i64 1
  %v275 = sub nuw i64 %v265, %v274
  %v276 = and i64 %v265, %v275
  %v277 = icmp uge i64 %v273, %v258
  switch i1 %v277, label %invalid.tag.b27 [
    i1 1, label %bb31
    i1 0, label %bb32
  ]
invalid.tag.b27:
  call void @abort()
  unreachable
bb28:
  br label %bb26
bb29:
  br label %bb27
bb30:
  %v278 = phi ptr [ %v247, %bb32 ], [ %v308, %bb33 ]
  %v279 = phi ptr [ %v248, %bb32 ], [ %v309, %bb33 ]
  %v281 = phi ptr [ %v250, %bb32 ], [ %v311, %bb33 ]
  %v282 = phi i64 [ %v251, %bb32 ], [ %v312, %bb33 ]
  %v283 = phi i64 [ %v252, %bb32 ], [ %v313, %bb33 ]
  %v284 = phi i64 [ %v253, %bb32 ], [ %v314, %bb33 ]
  %v285 = phi i64 [ %v254, %bb32 ], [ %v315, %bb33 ]
  %v286 = phi i64 [ %v255, %bb32 ], [ %v316, %bb33 ]
  %v287 = phi i64 [ %v256, %bb32 ], [ %v317, %bb33 ]
  %v288 = phi i64 [ %v257, %bb32 ], [ %v318, %bb33 ]
  %v289 = phi i64 [ %v258, %bb32 ], [ %v319, %bb33 ]
  %v290 = phi i64 [ %v259, %bb32 ], [ %v320, %bb33 ]
  %v291 = phi i64 [ %v260, %bb32 ], [ %v321, %bb33 ]
  %v292 = phi i64 [ %v261, %bb32 ], [ %v322, %bb33 ]
  %v293 = phi i64 [ %v262, %bb32 ], [ %v323, %bb33 ]
  %v294 = phi i64 [ %v263, %bb32 ], [ %v324, %bb33 ]
  %v295 = phi i64 [ %v264, %bb32 ], [ %v325, %bb33 ]
  %v296 = phi i64 [ %v276, %bb32 ], [ %v326, %bb33 ]
  %v297 = phi i64 [ %v266, %bb32 ], [ %v327, %bb33 ]
  %v298 = phi i64 [ %v267, %bb32 ], [ %v328, %bb33 ]
  %v299 = phi i64 [ %v268, %bb32 ], [ %v329, %bb33 ]
  %v300 = phi i64 [ %v269, %bb32 ], [ %v330, %bb33 ]
  %v301 = phi i64 [ %v270, %bb32 ], [ %v331, %bb33 ]
  %v302 = phi i64 [ %v271, %bb32 ], [ %v332, %bb33 ]
  %v303 = phi i64 [ %v272, %bb32 ], [ %v333, %bb33 ]
  %v304 = phi i64 [ %v273, %bb32 ], [ %v334, %bb33 ]
  %v305 = phi i64 [ %v275, %bb32 ], [ %v335, %bb33 ]
  br label %bb47
bb31:
  %v306 = sub nuw i64 %v273, %v258
  %v307 = icmp ult i64 %v306, %v271
  switch i1 %v307, label %invalid.tag.b31 [
    i1 1, label %bb34
    i1 0, label %bb35
  ]
invalid.tag.b31:
  call void @abort()
  unreachable
bb32:
  br label %bb30
bb33:
  %v308 = phi ptr [ %v247, %bb35 ], [ %v342, %bb36 ]
  %v309 = phi ptr [ %v248, %bb35 ], [ %v343, %bb36 ]
  %v311 = phi ptr [ %v250, %bb35 ], [ %v345, %bb36 ]
  %v312 = phi i64 [ %v251, %bb35 ], [ %v346, %bb36 ]
  %v313 = phi i64 [ %v252, %bb35 ], [ %v347, %bb36 ]
  %v314 = phi i64 [ %v253, %bb35 ], [ %v348, %bb36 ]
  %v315 = phi i64 [ %v254, %bb35 ], [ %v349, %bb36 ]
  %v316 = phi i64 [ %v255, %bb35 ], [ %v350, %bb36 ]
  %v317 = phi i64 [ %v256, %bb35 ], [ %v351, %bb36 ]
  %v318 = phi i64 [ %v257, %bb35 ], [ %v352, %bb36 ]
  %v319 = phi i64 [ %v258, %bb35 ], [ %v353, %bb36 ]
  %v320 = phi i64 [ %v259, %bb35 ], [ %v354, %bb36 ]
  %v321 = phi i64 [ %v260, %bb35 ], [ %v355, %bb36 ]
  %v322 = phi i64 [ %v261, %bb35 ], [ %v356, %bb36 ]
  %v323 = phi i64 [ %v262, %bb35 ], [ %v357, %bb36 ]
  %v324 = phi i64 [ %v263, %bb35 ], [ %v358, %bb36 ]
  %v325 = phi i64 [ %v264, %bb35 ], [ %v359, %bb36 ]
  %v326 = phi i64 [ %v276, %bb35 ], [ %v360, %bb36 ]
  %v327 = phi i64 [ %v266, %bb35 ], [ %v361, %bb36 ]
  %v328 = phi i64 [ %v267, %bb35 ], [ %v362, %bb36 ]
  %v329 = phi i64 [ %v268, %bb35 ], [ %v363, %bb36 ]
  %v330 = phi i64 [ %v269, %bb35 ], [ %v364, %bb36 ]
  %v331 = phi i64 [ %v270, %bb35 ], [ %v365, %bb36 ]
  %v332 = phi i64 [ %v271, %bb35 ], [ %v366, %bb36 ]
  %v333 = phi i64 [ %v272, %bb35 ], [ %v367, %bb36 ]
  %v334 = phi i64 [ %v273, %bb35 ], [ %v368, %bb36 ]
  %v335 = phi i64 [ %v275, %bb35 ], [ %v369, %bb36 ]
  %v336 = phi i64 [ %v306, %bb35 ], [ %v370, %bb36 ]
  br label %bb30
bb34:
  %v337 = add nuw i64 %v255, %v306
  %t5 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v247, i32 0, i32 0
  %v338 = getelementptr i8, ptr %t5, i64 0
  %v339 = getelementptr i8, ptr %v338, i64 0
  %t6 = load ptr, ptr %v339
  %t7.nonnegative = icmp sge i64 %v337, 0
  call void @llvm.assume(i1 %t7.nonnegative)
  %t7 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t6, i64 0, i32 2, i64 %v337
  %v340 = getelementptr i8, ptr %t7, i64 0
  %v341 = call i32 @wf_hash_map.hash_map_action$instance$c6df3d8464f8cde0(ptr %v340, ptr %v248, ptr %v250)
  switch i32 %v341, label %invalid.tag.b34 [
    i32 3, label %bb37
    i32 0, label %bb38
    i32 1, label %bb39
    i32 2, label %bb40
  ]
invalid.tag.b34:
  call void @abort()
  unreachable
bb35:
  br label %bb33
bb36:
  %v342 = phi ptr [ %v247, %bb40 ], [ %v411, %bb44 ]
  %v343 = phi ptr [ %v248, %bb40 ], [ %v412, %bb44 ]
  %v345 = phi ptr [ %v250, %bb40 ], [ %v414, %bb44 ]
  %v346 = phi i64 [ %v251, %bb40 ], [ %v415, %bb44 ]
  %v347 = phi i64 [ %v252, %bb40 ], [ %v416, %bb44 ]
  %v348 = phi i64 [ %v253, %bb40 ], [ %v417, %bb44 ]
  %v349 = phi i64 [ %v254, %bb40 ], [ %v418, %bb44 ]
  %v350 = phi i64 [ %v255, %bb40 ], [ %v419, %bb44 ]
  %v351 = phi i64 [ %v256, %bb40 ], [ %v420, %bb44 ]
  %v352 = phi i64 [ %v257, %bb40 ], [ %v421, %bb44 ]
  %v353 = phi i64 [ %v258, %bb40 ], [ %v422, %bb44 ]
  %v354 = phi i64 [ %v259, %bb40 ], [ %v423, %bb44 ]
  %v355 = phi i64 [ %v260, %bb40 ], [ %v424, %bb44 ]
  %v356 = phi i64 [ %v261, %bb40 ], [ %v425, %bb44 ]
  %v357 = phi i64 [ %v262, %bb40 ], [ %v426, %bb44 ]
  %v358 = phi i64 [ %v263, %bb40 ], [ %v427, %bb44 ]
  %v359 = phi i64 [ %v264, %bb40 ], [ %v428, %bb44 ]
  %v360 = phi i64 [ %v276, %bb40 ], [ %v429, %bb44 ]
  %v361 = phi i64 [ %v266, %bb40 ], [ %v430, %bb44 ]
  %v362 = phi i64 [ %v267, %bb40 ], [ %v431, %bb44 ]
  %v363 = phi i64 [ %v268, %bb40 ], [ %v432, %bb44 ]
  %v364 = phi i64 [ %v269, %bb40 ], [ %v433, %bb44 ]
  %v365 = phi i64 [ %v270, %bb40 ], [ %v434, %bb44 ]
  %v366 = phi i64 [ %v271, %bb40 ], [ %v435, %bb44 ]
  %v367 = phi i64 [ %v272, %bb40 ], [ %v436, %bb44 ]
  %v368 = phi i64 [ %v273, %bb40 ], [ %v437, %bb44 ]
  %v369 = phi i64 [ %v275, %bb40 ], [ %v438, %bb44 ]
  %v370 = phi i64 [ %v306, %bb40 ], [ %v439, %bb44 ]
  %v371 = phi i64 [ %v337, %bb40 ], [ %v440, %bb44 ]
  %v372 = phi i32 [ %v341, %bb40 ], [ %v441, %bb44 ]
  br label %bb33
bb37:
  %t8 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v247, i32 0, i32 0
  %v373 = getelementptr i8, ptr %t8, i64 0
  %v374 = load i64, ptr %v248
  call void @wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449(ptr %wf.result, ptr %v373, i64 %v337, i64 %v374, ptr %wf.slot.0)
  %t9 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v247, i32 0, i32 2
  %v376 = getelementptr i8, ptr %t9, i64 0
  %v377 = call i8 @wf_hash_map.hash_map_control_set(ptr %v376, i64 %v337, i64 %v252)
  ret void
bb38:
  %v378 = icmp eq i64 %v254, %v253
  switch i1 %v378, label %invalid.tag.b38 [
    i1 1, label %bb42
    i1 0, label %bb43
  ]
invalid.tag.b38:
  call void @abort()
  unreachable
bb39:
  %v410 = icmp eq i64 %v254, %v253
  switch i1 %v410, label %invalid.tag.b39 [
    i1 1, label %bb45
    i1 0, label %bb46
  ]
invalid.tag.b39:
  call void @abort()
  unreachable
bb40:
  br label %bb36
bb41:
  %v379 = phi ptr [ %v247, %bb42 ], [ %v247, %bb43 ]
  %v380 = phi ptr [ %v248, %bb42 ], [ %v248, %bb43 ]
  %v382 = phi ptr [ %v250, %bb42 ], [ %v250, %bb43 ]
  %v383 = phi i64 [ %v251, %bb42 ], [ %v251, %bb43 ]
  %v384 = phi i64 [ %v252, %bb42 ], [ %v252, %bb43 ]
  %v385 = phi i64 [ %v253, %bb42 ], [ %v253, %bb43 ]
  %v386 = phi i64 [ %v337, %bb42 ], [ %v254, %bb43 ]
  %v387 = phi i64 [ %v255, %bb42 ], [ %v255, %bb43 ]
  %v388 = phi i64 [ %v256, %bb42 ], [ %v256, %bb43 ]
  %v389 = phi i64 [ %v257, %bb42 ], [ %v257, %bb43 ]
  %v390 = phi i64 [ %v258, %bb42 ], [ %v258, %bb43 ]
  %v391 = phi i64 [ %v259, %bb42 ], [ %v259, %bb43 ]
  %v392 = phi i64 [ %v260, %bb42 ], [ %v260, %bb43 ]
  %v393 = phi i64 [ %v261, %bb42 ], [ %v261, %bb43 ]
  %v394 = phi i64 [ %v262, %bb42 ], [ %v262, %bb43 ]
  %v395 = phi i64 [ %v263, %bb42 ], [ %v263, %bb43 ]
  %v396 = phi i64 [ %v264, %bb42 ], [ %v264, %bb43 ]
  %v397 = phi i64 [ %v276, %bb42 ], [ %v276, %bb43 ]
  %v398 = phi i64 [ %v266, %bb42 ], [ %v266, %bb43 ]
  %v399 = phi i64 [ %v267, %bb42 ], [ %v267, %bb43 ]
  %v400 = phi i64 [ %v268, %bb42 ], [ %v268, %bb43 ]
  %v401 = phi i64 [ %v269, %bb42 ], [ %v269, %bb43 ]
  %v402 = phi i64 [ %v270, %bb42 ], [ %v270, %bb43 ]
  %v403 = phi i64 [ %v271, %bb42 ], [ %v271, %bb43 ]
  %v404 = phi i64 [ %v272, %bb42 ], [ %v272, %bb43 ]
  %v405 = phi i64 [ %v273, %bb42 ], [ %v273, %bb43 ]
  %v406 = phi i64 [ %v275, %bb42 ], [ %v275, %bb43 ]
  %v407 = phi i64 [ %v306, %bb42 ], [ %v306, %bb43 ]
  %v408 = phi i64 [ %v337, %bb42 ], [ %v337, %bb43 ]
  %v409 = phi i32 [ %v341, %bb42 ], [ %v341, %bb43 ]
  br label %bb26
bb42:
  br label %bb41
bb43:
  br label %bb41
bb44:
  %v411 = phi ptr [ %v247, %bb45 ], [ %v247, %bb46 ]
  %v412 = phi ptr [ %v248, %bb45 ], [ %v248, %bb46 ]
  %v414 = phi ptr [ %v250, %bb45 ], [ %v250, %bb46 ]
  %v415 = phi i64 [ %v251, %bb45 ], [ %v251, %bb46 ]
  %v416 = phi i64 [ %v252, %bb45 ], [ %v252, %bb46 ]
  %v417 = phi i64 [ %v253, %bb45 ], [ %v253, %bb46 ]
  %v418 = phi i64 [ %v337, %bb45 ], [ %v254, %bb46 ]
  %v419 = phi i64 [ %v255, %bb45 ], [ %v255, %bb46 ]
  %v420 = phi i64 [ %v256, %bb45 ], [ %v256, %bb46 ]
  %v421 = phi i64 [ %v257, %bb45 ], [ %v257, %bb46 ]
  %v422 = phi i64 [ %v258, %bb45 ], [ %v258, %bb46 ]
  %v423 = phi i64 [ %v259, %bb45 ], [ %v259, %bb46 ]
  %v424 = phi i64 [ %v260, %bb45 ], [ %v260, %bb46 ]
  %v425 = phi i64 [ %v261, %bb45 ], [ %v261, %bb46 ]
  %v426 = phi i64 [ %v262, %bb45 ], [ %v262, %bb46 ]
  %v427 = phi i64 [ %v263, %bb45 ], [ %v263, %bb46 ]
  %v428 = phi i64 [ %v264, %bb45 ], [ %v264, %bb46 ]
  %v429 = phi i64 [ %v276, %bb45 ], [ %v276, %bb46 ]
  %v430 = phi i64 [ %v266, %bb45 ], [ %v266, %bb46 ]
  %v431 = phi i64 [ %v267, %bb45 ], [ %v267, %bb46 ]
  %v432 = phi i64 [ %v268, %bb45 ], [ %v268, %bb46 ]
  %v433 = phi i64 [ %v269, %bb45 ], [ %v269, %bb46 ]
  %v434 = phi i64 [ %v270, %bb45 ], [ %v270, %bb46 ]
  %v435 = phi i64 [ %v271, %bb45 ], [ %v271, %bb46 ]
  %v436 = phi i64 [ %v272, %bb45 ], [ %v272, %bb46 ]
  %v437 = phi i64 [ %v273, %bb45 ], [ %v273, %bb46 ]
  %v438 = phi i64 [ %v275, %bb45 ], [ %v275, %bb46 ]
  %v439 = phi i64 [ %v306, %bb45 ], [ %v306, %bb46 ]
  %v440 = phi i64 [ %v337, %bb45 ], [ %v337, %bb46 ]
  %v441 = phi i32 [ %v341, %bb45 ], [ %v341, %bb46 ]
  br label %bb36
bb45:
  br label %bb44
bb46:
  br label %bb44
bb47:
  %v442 = phi ptr [ %v278, %bb30 ]
  %v443 = phi ptr [ %v279, %bb30 ]
  %v445 = phi ptr [ %v281, %bb30 ]
  %v446 = phi i64 [ %v282, %bb30 ]
  %v447 = phi i64 [ %v283, %bb30 ]
  %v448 = phi i64 [ %v284, %bb30 ]
  %v449 = phi i64 [ %v285, %bb30 ]
  %v450 = phi i64 [ %v286, %bb30 ]
  %v451 = phi i64 [ %v287, %bb30 ]
  %v452 = phi i64 [ %v288, %bb30 ]
  %v453 = phi i64 [ %v289, %bb30 ]
  %v454 = phi i64 [ %v290, %bb30 ]
  %v455 = phi i64 [ %v291, %bb30 ]
  %v456 = phi i64 [ %v292, %bb30 ]
  %v457 = phi i64 [ %v293, %bb30 ]
  %v458 = phi i64 [ %v294, %bb30 ]
  %v459 = phi i64 [ %v295, %bb30 ]
  %v460 = phi i64 [ %v296, %bb30 ]
  %v461 = phi i64 [ %v297, %bb30 ]
  %v462 = phi i64 [ %v298, %bb30 ]
  %v463 = phi i64 [ %v299, %bb30 ]
  %v464 = phi i64 [ %v300, %bb30 ]
  %v465 = phi i64 [ %v301, %bb30 ]
  %v466 = phi i64 [ %v302, %bb30 ]
  %v467 = phi i64 [ %v216, %bb30 ]
  %v468 = phi i64 [ %v217, %bb30 ]
  %v469 = phi i64 [ %v218, %bb30 ]
  %v470 = select i1 true, i64 1, i64 1
  %v471 = add i64 %v469, %v470
  br label %bb23
bb48:
  %v473 = phi ptr [ %v219, %bb50 ]
  %v474 = phi ptr [ %v220, %bb50 ]
  %v476 = phi ptr [ %v222, %bb50 ]
  %v477 = phi i64 [ %v223, %bb50 ]
  %v478 = phi i64 [ %v224, %bb50 ]
  %v479 = phi i64 [ %v225, %bb50 ]
  %v480 = phi i64 [ %v226, %bb50 ]
  %v481 = phi i64 [ %v227, %bb50 ]
  %v482 = phi i64 [ %v228, %bb50 ]
  %v483 = phi i64 [ %v229, %bb50 ]
  %v484 = phi i64 [ %v230, %bb50 ]
  %v485 = phi i64 [ %v231, %bb50 ]
  %v486 = phi i64 [ %v232, %bb50 ]
  %v487 = phi i64 [ %v233, %bb50 ]
  %v488 = phi i64 [ %v234, %bb50 ]
  %v489 = phi i64 [ %v235, %bb50 ]
  %v490 = phi i64 [ %v236, %bb50 ]
  %v491 = phi i64 [ %v237, %bb50 ]
  %v492 = phi i64 [ %v238, %bb50 ]
  %v493 = phi i64 [ %v239, %bb50 ]
  %v494 = phi i64 [ %v240, %bb50 ]
  %v495 = phi i64 [ %v241, %bb50 ]
  %v496 = phi i64 [ %v242, %bb50 ]
  %v497 = phi i64 [ %v243, %bb50 ]
  %v498 = sub nuw i64 %v482, %v486
  %v499 = add nuw i64 %v481, %v486
  %v500 = icmp ult i64 %v499, %v479
  switch i1 %v500, label %invalid.tag.b48 [
    i1 1, label %bb52
    i1 0, label %bb53
  ]
invalid.tag.b48:
  call void @abort()
  unreachable
bb49:
  br label %bb7
bb50:
  br label %bb48
bb51:
  %v501 = phi ptr [ %v473, %bb52 ], [ %v473, %bb53 ]
  %v502 = phi ptr [ %v474, %bb52 ], [ %v474, %bb53 ]
  %v504 = phi ptr [ %v476, %bb52 ], [ %v476, %bb53 ]
  %v505 = phi i64 [ %v477, %bb52 ], [ %v477, %bb53 ]
  %v506 = phi i64 [ %v478, %bb52 ], [ %v478, %bb53 ]
  %v507 = phi i64 [ %v479, %bb52 ], [ %v479, %bb53 ]
  %v508 = phi i64 [ %v480, %bb52 ], [ %v480, %bb53 ]
  %v509 = phi i64 [ %v499, %bb52 ], [ %v527, %bb53 ]
  %v510 = phi i64 [ %v498, %bb52 ], [ %v498, %bb53 ]
  %v511 = phi i64 [ %v483, %bb52 ], [ %v483, %bb53 ]
  %v512 = phi i64 [ %v484, %bb52 ], [ %v484, %bb53 ]
  %v513 = phi i64 [ %v485, %bb52 ], [ %v485, %bb53 ]
  %v514 = phi i64 [ %v486, %bb52 ], [ %v486, %bb53 ]
  %v515 = phi i64 [ %v487, %bb52 ], [ %v487, %bb53 ]
  %v516 = phi i64 [ %v488, %bb52 ], [ %v488, %bb53 ]
  %v517 = phi i64 [ %v489, %bb52 ], [ %v489, %bb53 ]
  %v518 = phi i64 [ %v490, %bb52 ], [ %v490, %bb53 ]
  %v519 = phi i64 [ %v491, %bb52 ], [ %v491, %bb53 ]
  %v520 = phi i64 [ %v492, %bb52 ], [ %v492, %bb53 ]
  %v521 = phi i64 [ %v493, %bb52 ], [ %v493, %bb53 ]
  %v522 = phi i64 [ %v494, %bb52 ], [ %v494, %bb53 ]
  %v523 = phi i64 [ %v495, %bb52 ], [ %v495, %bb53 ]
  %v524 = phi i64 [ %v496, %bb52 ], [ %v496, %bb53 ]
  %v525 = phi i64 [ %v497, %bb52 ], [ %v497, %bb53 ]
  %v526 = phi i64 [ %v499, %bb52 ], [ %v499, %bb53 ]
  br label %bb54
bb52:
  br label %bb51
bb53:
  %v527 = select i1 true, i64 0, i64 0
  br label %bb51
bb54:
  %v528 = phi ptr [ %v501, %bb51 ]
  %v529 = phi ptr [ %v502, %bb51 ]
  %v531 = phi ptr [ %v504, %bb51 ]
  %v532 = phi i64 [ %v505, %bb51 ]
  %v533 = phi i64 [ %v506, %bb51 ]
  %v534 = phi i64 [ %v507, %bb51 ]
  %v535 = phi i64 [ %v508, %bb51 ]
  %v536 = phi i64 [ %v509, %bb51 ]
  %v537 = phi i64 [ %v510, %bb51 ]
  %v538 = phi i64 [ %v32, %bb51 ]
  %v539 = phi i64 [ %v33, %bb51 ]
  %v540 = phi i64 [ %v34, %bb51 ]
  %v541 = select i1 true, i64 1, i64 1
  %v542 = add i64 %v540, %v541
  br label %bb4
bb55:
  %v544 = phi ptr [ %v12, %bb57 ], [ %v556, %bb58 ]
  %v545 = phi ptr [ %v13, %bb57 ], [ %v557, %bb58 ]
  %v547 = phi ptr [ %v15, %bb57 ], [ %v559, %bb58 ]
  %v548 = phi i64 [ %v16, %bb57 ], [ %v560, %bb58 ]
  %v549 = phi i64 [ %v17, %bb57 ], [ %v561, %bb58 ]
  %v550 = phi i64 [ %v18, %bb57 ], [ %v562, %bb58 ]
  %v551 = phi i64 [ %v19, %bb57 ], [ %v563, %bb58 ]
  %v587 = load i64, ptr %v545
  store %wf.t.20dda3774c7510ec zeroinitializer, ptr %wf.slot.2
  %t10 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.2, i32 0, i32 0
  store i64 %v587, ptr %t10
  %t11 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.2, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t11, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %v589 = or i1 0, 1
  store %wf.t.9d321e1eb2ec1c03 zeroinitializer, ptr %wf.result
  %t12 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t12
  %t13 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 1
  store i1 %v589, ptr %t13
  %t14 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %wf.slot.2, i64 ptrtoint (ptr getelementptr (%wf.t.20dda3774c7510ec, ptr null, i32 1) to i64), i1 false)
  ret void
bb56:
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v12, i64 ptrtoint (ptr getelementptr (%wf.t.05623e8a192b9069, ptr null, i32 1) to i64), i1 false)
  %t15 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %wf.slot.1, i32 0, i32 1
  %v553 = load i64, ptr %t15
  %v554 = select i1 true, i64 16384, i64 16384
  %v555 = icmp ult i64 %v553, %v554
  switch i1 %v555, label %invalid.tag.b56 [
    i1 1, label %bb59
    i1 0, label %bb60
  ]
invalid.tag.b56:
  call void @abort()
  unreachable
bb57:
  br label %bb55
bb58:
  %v556 = phi ptr [ %v12, %bb60 ]
  %v557 = phi ptr [ %v13, %bb60 ]
  %v559 = phi ptr [ %v15, %bb60 ]
  %v560 = phi i64 [ %v16, %bb60 ]
  %v561 = phi i64 [ %v17, %bb60 ]
  %v562 = phi i64 [ %v18, %bb60 ]
  %v563 = phi i64 [ %v19, %bb60 ]
  %v564 = phi i64 [ %v553, %bb60 ]
  br label %bb55
bb59:
  %t16 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v12, i32 0, i32 0
  %v565 = getelementptr i8, ptr %t16, i64 0
  %v566 = load i64, ptr %v13
  call void @wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449(ptr %v568, ptr %v565, i64 %v19, i64 %v566, ptr %wf.slot.0)
  %t17 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v12, i32 0, i32 2
  %v569 = getelementptr i8, ptr %t17, i64 0
  %v570 = call i8 @wf_hash_map.hash_map_control_set(ptr %v569, i64 %v19, i64 %v17)
  %v571 = call i1 @wf_hash_map.hash_map_control_inserted$instance$d7a1a90c27bba449(ptr %v568)
  switch i1 %v571, label %invalid.tag.b59 [
    i1 1, label %bb62
    i1 0, label %bb63
  ]
invalid.tag.b59:
  call void @abort()
  unreachable
bb60:
  br label %bb58
bb61:
  %v572 = phi ptr [ %v12, %bb62 ], [ %v12, %bb63 ]
  %v573 = phi ptr [ %v13, %bb62 ], [ %v13, %bb63 ]
  %v575 = phi ptr [ %v15, %bb62 ], [ %v15, %bb63 ]
  %v576 = phi i64 [ %v16, %bb62 ], [ %v16, %bb63 ]
  %v577 = phi i64 [ %v17, %bb62 ], [ %v17, %bb63 ]
  %v578 = phi i64 [ %v18, %bb62 ], [ %v18, %bb63 ]
  %v579 = phi i64 [ %v19, %bb62 ], [ %v19, %bb63 ]
  %v580 = phi i64 [ %v553, %bb62 ], [ %v553, %bb63 ]
  %v581 = phi ptr [ %v568, %bb62 ], [ %v568, %bb63 ]
  %v582 = phi i1 [ %v571, %bb62 ], [ %v571, %bb63 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.result, ptr %v581, i64 ptrtoint (ptr getelementptr (%wf.t.9d321e1eb2ec1c03, ptr null, i32 1) to i64), i1 false)
  ret void
bb62:
  %t18 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v12, i32 0, i32 1
  %v583 = getelementptr i8, ptr %t18, i64 0
  %v584 = select i1 true, i64 1, i64 1
  %v585 = add nuw i64 %v553, %v584
  store i64 %v585, ptr %v583
  br label %bb61
bb63:
  br label %bb61
}

define internal void @wf_hash_map.hash_map_find$instance$28da32efc51c2b65.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.e04aead91f34a68f, align 8
  %v3 = call i64 @wf_map_cost_hash(ptr %v2, ptr %v1)
  %t0 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v0, i32 0, i32 0
  %v4 = getelementptr i8, ptr %t0, i64 0
  %v5 = getelementptr i8, ptr %v4, i64 0
  %t2 = load ptr, ptr %v5
  %t3 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t2, i32 0, i32 0
  %t1 = load i64, ptr %t3
  %v6 = add i64 %t1, 0
  %v7 = select i1 true, i64 0, i64 0
  %v8 = icmp eq i64 %v6, %v7
  switch i1 %v8, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v9 = phi ptr [ %v0, %bb3 ]
  %v10 = phi ptr [ %v1, %bb3 ]
  %v11 = phi ptr [ %v2, %bb3 ]
  %v12 = phi i64 [ %v3, %bb3 ]
  %v13 = phi i64 [ %v6, %bb3 ]
  %v16 = call i64 @wf_hash_map.hash_map_control_fingerprint(i64 %v12)
  %v17 = urem i64 %v12, %v13
  %v18 = select i1 true, i64 0, i64 0
  br label %bb4
bb2:
  %v14 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t4 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t4
  %t5 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v14, ptr %t5
  ret void
bb3:
  br label %bb1
bb4:
  %v19 = phi ptr [ %v9, %bb1 ], [ %v327, %bb38 ]
  %v20 = phi ptr [ %v10, %bb1 ], [ %v328, %bb38 ]
  %v21 = phi ptr [ %v11, %bb1 ], [ %v329, %bb38 ]
  %v22 = phi i64 [ %v12, %bb1 ], [ %v330, %bb38 ]
  %v23 = phi i64 [ %v13, %bb1 ], [ %v331, %bb38 ]
  %v24 = phi i64 [ %v16, %bb1 ], [ %v332, %bb38 ]
  %v25 = phi i64 [ %v17, %bb1 ], [ %v333, %bb38 ]
  %v26 = phi i64 [ %v13, %bb1 ], [ %v334, %bb38 ]
  %v27 = phi i64 [ %v18, %bb1 ], [ %v335, %bb38 ]
  %v28 = phi i64 [ %v13, %bb1 ], [ %v336, %bb38 ]
  %v29 = phi i64 [ %v18, %bb1 ], [ %v339, %bb38 ]
  %v38 = icmp ult i64 %v29, %v28
  switch i1 %v38, label %invalid.tag.b4 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b4:
  call void @abort()
  unreachable
bb5:
  %v39 = select i1 true, i64 0, i64 0
  %v40 = icmp eq i64 %v26, %v39
  switch i1 %v40, label %invalid.tag.b5 [
    i1 1, label %bb9
    i1 0, label %bb10
  ]
invalid.tag.b5:
  call void @abort()
  unreachable
bb6:
  br label %bb7
bb7:
  %v30 = phi ptr [ %v19, %bb6 ], [ %v19, %bb9 ]
  %v31 = phi ptr [ %v20, %bb6 ], [ %v20, %bb9 ]
  %v32 = phi ptr [ %v21, %bb6 ], [ %v21, %bb9 ]
  %v33 = phi i64 [ %v22, %bb6 ], [ %v22, %bb9 ]
  %v34 = phi i64 [ %v23, %bb6 ], [ %v23, %bb9 ]
  %v35 = phi i64 [ %v24, %bb6 ], [ %v24, %bb9 ]
  %v36 = phi i64 [ %v25, %bb6 ], [ %v25, %bb9 ]
  %v37 = phi i64 [ %v26, %bb6 ], [ %v26, %bb9 ]
  %v340 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t6 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t6
  %t7 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v340, ptr %t7
  ret void
bb8:
  %v41 = phi ptr [ %v19, %bb10 ]
  %v42 = phi ptr [ %v20, %bb10 ]
  %v43 = phi ptr [ %v21, %bb10 ]
  %v44 = phi i64 [ %v22, %bb10 ]
  %v45 = phi i64 [ %v23, %bb10 ]
  %v46 = phi i64 [ %v24, %bb10 ]
  %v47 = phi i64 [ %v25, %bb10 ]
  %v48 = phi i64 [ %v26, %bb10 ]
  %v49 = phi i64 [ %v29, %bb10 ]
  %v50 = select i1 true, i64 8, i64 8
  %v51 = urem i64 %v47, %v50
  %v52 = sub nuw i64 %v45, %v47
  %v53 = call i64 @wf_hash_map.hash_map_control_span(i64 %v51, i64 %v52, i64 %v48)
  %v54 = select i1 true, i64 8, i64 8
  %v55 = udiv i64 %v47, %v54
  %t8 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v41, i32 0, i32 2
  %v56 = getelementptr i8, ptr %t8, i64 0
  %v57 = call i64 @wf_hash_map.hash_map_control_word(ptr %v56, i64 %v55)
  %v58 = call i64 @wf_hash_map.hash_map_control_active(i64 %v51, i64 %v53)
  %v59 = call i64 @wf_hash_map.hash_map_control_equal(i64 %v57, i64 %v46)
  %v60 = and i64 %v59, %v58
  %v61 = select i1 true, i64 128, i64 128
  %v62 = call i64 @wf_hash_map.hash_map_control_equal(i64 %v57, i64 %v61)
  %v63 = and i64 %v62, %v58
  %v64 = call i64 @wf_hash_map.hash_map_control_stop(i64 %v63, i64 %v51, i64 %v53)
  %v65 = select i1 true, i64 0, i64 0
  %v66 = select i1 true, i64 8, i64 8
  br label %bb11
bb9:
  br label %bb7
bb10:
  br label %bb8
bb11:
  %v67 = phi ptr [ %v41, %bb8 ], [ %v254, %bb31 ]
  %v68 = phi ptr [ %v42, %bb8 ], [ %v255, %bb31 ]
  %v69 = phi ptr [ %v43, %bb8 ], [ %v256, %bb31 ]
  %v70 = phi i64 [ %v44, %bb8 ], [ %v257, %bb31 ]
  %v71 = phi i64 [ %v45, %bb8 ], [ %v258, %bb31 ]
  %v72 = phi i64 [ %v46, %bb8 ], [ %v259, %bb31 ]
  %v73 = phi i64 [ %v47, %bb8 ], [ %v260, %bb31 ]
  %v74 = phi i64 [ %v48, %bb8 ], [ %v261, %bb31 ]
  %v75 = phi i64 [ %v49, %bb8 ], [ %v262, %bb31 ]
  %v76 = phi i64 [ %v51, %bb8 ], [ %v263, %bb31 ]
  %v77 = phi i64 [ %v52, %bb8 ], [ %v264, %bb31 ]
  %v78 = phi i64 [ %v53, %bb8 ], [ %v265, %bb31 ]
  %v79 = phi i64 [ %v55, %bb8 ], [ %v266, %bb31 ]
  %v80 = phi i64 [ %v57, %bb8 ], [ %v267, %bb31 ]
  %v81 = phi i64 [ %v58, %bb8 ], [ %v268, %bb31 ]
  %v82 = phi i64 [ %v59, %bb8 ], [ %v269, %bb31 ]
  %v83 = phi i64 [ %v60, %bb8 ], [ %v270, %bb31 ]
  %v84 = phi i64 [ %v62, %bb8 ], [ %v271, %bb31 ]
  %v85 = phi i64 [ %v63, %bb8 ], [ %v272, %bb31 ]
  %v86 = phi i64 [ %v64, %bb8 ], [ %v273, %bb31 ]
  %v87 = phi i64 [ %v65, %bb8 ], [ %v274, %bb31 ]
  %v88 = phi i64 [ %v66, %bb8 ], [ %v275, %bb31 ]
  %v89 = phi i64 [ %v65, %bb8 ], [ %v278, %bb31 ]
  %v110 = icmp ult i64 %v89, %v88
  switch i1 %v110, label %invalid.tag.b11 [
    i1 1, label %bb12
    i1 0, label %bb13
  ]
invalid.tag.b11:
  call void @abort()
  unreachable
bb12:
  %v111 = select i1 true, i64 0, i64 0
  %v112 = icmp eq i64 %v83, %v111
  switch i1 %v112, label %invalid.tag.b12 [
    i1 1, label %bb16
    i1 0, label %bb17
  ]
invalid.tag.b12:
  call void @abort()
  unreachable
bb13:
  br label %bb14
bb14:
  %v90 = phi ptr [ %v67, %bb13 ], [ %v67, %bb16 ]
  %v91 = phi ptr [ %v68, %bb13 ], [ %v68, %bb16 ]
  %v92 = phi ptr [ %v69, %bb13 ], [ %v69, %bb16 ]
  %v93 = phi i64 [ %v70, %bb13 ], [ %v70, %bb16 ]
  %v94 = phi i64 [ %v71, %bb13 ], [ %v71, %bb16 ]
  %v95 = phi i64 [ %v72, %bb13 ], [ %v72, %bb16 ]
  %v96 = phi i64 [ %v73, %bb13 ], [ %v73, %bb16 ]
  %v97 = phi i64 [ %v74, %bb13 ], [ %v74, %bb16 ]
  %v98 = phi i64 [ %v75, %bb13 ], [ %v75, %bb16 ]
  %v99 = phi i64 [ %v76, %bb13 ], [ %v76, %bb16 ]
  %v100 = phi i64 [ %v77, %bb13 ], [ %v77, %bb16 ]
  %v101 = phi i64 [ %v78, %bb13 ], [ %v78, %bb16 ]
  %v102 = phi i64 [ %v79, %bb13 ], [ %v79, %bb16 ]
  %v103 = phi i64 [ %v80, %bb13 ], [ %v80, %bb16 ]
  %v104 = phi i64 [ %v81, %bb13 ], [ %v81, %bb16 ]
  %v105 = phi i64 [ %v82, %bb13 ], [ %v82, %bb16 ]
  %v106 = phi i64 [ %v83, %bb13 ], [ %v83, %bb16 ]
  %v107 = phi i64 [ %v84, %bb13 ], [ %v84, %bb16 ]
  %v108 = phi i64 [ %v85, %bb13 ], [ %v85, %bb16 ]
  %v109 = phi i64 [ %v86, %bb13 ], [ %v86, %bb16 ]
  %v279 = icmp ult i64 %v109, %v101
  switch i1 %v279, label %invalid.tag.b14 [
    i1 1, label %bb33
    i1 0, label %bb34
  ]
invalid.tag.b14:
  call void @abort()
  unreachable
bb15:
  %v113 = phi ptr [ %v67, %bb17 ]
  %v114 = phi ptr [ %v68, %bb17 ]
  %v115 = phi ptr [ %v69, %bb17 ]
  %v116 = phi i64 [ %v70, %bb17 ]
  %v117 = phi i64 [ %v71, %bb17 ]
  %v118 = phi i64 [ %v72, %bb17 ]
  %v119 = phi i64 [ %v73, %bb17 ]
  %v120 = phi i64 [ %v74, %bb17 ]
  %v121 = phi i64 [ %v75, %bb17 ]
  %v122 = phi i64 [ %v76, %bb17 ]
  %v123 = phi i64 [ %v77, %bb17 ]
  %v124 = phi i64 [ %v78, %bb17 ]
  %v125 = phi i64 [ %v79, %bb17 ]
  %v126 = phi i64 [ %v80, %bb17 ]
  %v127 = phi i64 [ %v81, %bb17 ]
  %v128 = phi i64 [ %v82, %bb17 ]
  %v129 = phi i64 [ %v83, %bb17 ]
  %v130 = phi i64 [ %v84, %bb17 ]
  %v131 = phi i64 [ %v85, %bb17 ]
  %v132 = phi i64 [ %v86, %bb17 ]
  %v133 = phi i64 [ %v89, %bb17 ]
  %v134 = call i64 @wf_hash_map.hash_map_control_first(i64 %v129)
  %v135 = select i1 true, i64 1, i64 1
  %v136 = sub nuw i64 %v129, %v135
  %v137 = and i64 %v129, %v136
  %v138 = icmp uge i64 %v134, %v122
  switch i1 %v138, label %invalid.tag.b15 [
    i1 1, label %bb19
    i1 0, label %bb20
  ]
invalid.tag.b15:
  call void @abort()
  unreachable
bb16:
  br label %bb14
bb17:
  br label %bb15
bb18:
  %v139 = phi ptr [ %v113, %bb20 ], [ %v164, %bb21 ]
  %v140 = phi ptr [ %v114, %bb20 ], [ %v165, %bb21 ]
  %v141 = phi ptr [ %v115, %bb20 ], [ %v166, %bb21 ]
  %v142 = phi i64 [ %v116, %bb20 ], [ %v167, %bb21 ]
  %v143 = phi i64 [ %v117, %bb20 ], [ %v168, %bb21 ]
  %v144 = phi i64 [ %v118, %bb20 ], [ %v169, %bb21 ]
  %v145 = phi i64 [ %v119, %bb20 ], [ %v170, %bb21 ]
  %v146 = phi i64 [ %v120, %bb20 ], [ %v171, %bb21 ]
  %v147 = phi i64 [ %v121, %bb20 ], [ %v172, %bb21 ]
  %v148 = phi i64 [ %v122, %bb20 ], [ %v173, %bb21 ]
  %v149 = phi i64 [ %v123, %bb20 ], [ %v174, %bb21 ]
  %v150 = phi i64 [ %v124, %bb20 ], [ %v175, %bb21 ]
  %v151 = phi i64 [ %v125, %bb20 ], [ %v176, %bb21 ]
  %v152 = phi i64 [ %v126, %bb20 ], [ %v177, %bb21 ]
  %v153 = phi i64 [ %v127, %bb20 ], [ %v178, %bb21 ]
  %v154 = phi i64 [ %v128, %bb20 ], [ %v179, %bb21 ]
  %v155 = phi i64 [ %v137, %bb20 ], [ %v180, %bb21 ]
  %v156 = phi i64 [ %v130, %bb20 ], [ %v181, %bb21 ]
  %v157 = phi i64 [ %v131, %bb20 ], [ %v182, %bb21 ]
  %v158 = phi i64 [ %v132, %bb20 ], [ %v183, %bb21 ]
  %v159 = phi i64 [ %v133, %bb20 ], [ %v184, %bb21 ]
  %v160 = phi i64 [ %v134, %bb20 ], [ %v185, %bb21 ]
  %v161 = phi i64 [ %v136, %bb20 ], [ %v186, %bb21 ]
  br label %bb31
bb19:
  %v162 = sub nuw i64 %v134, %v122
  %v163 = icmp ult i64 %v162, %v132
  switch i1 %v163, label %invalid.tag.b19 [
    i1 1, label %bb22
    i1 0, label %bb23
  ]
invalid.tag.b19:
  call void @abort()
  unreachable
bb20:
  br label %bb18
bb21:
  %v164 = phi ptr [ %v113, %bb23 ], [ %v193, %bb24 ]
  %v165 = phi ptr [ %v114, %bb23 ], [ %v194, %bb24 ]
  %v166 = phi ptr [ %v115, %bb23 ], [ %v195, %bb24 ]
  %v167 = phi i64 [ %v116, %bb23 ], [ %v196, %bb24 ]
  %v168 = phi i64 [ %v117, %bb23 ], [ %v197, %bb24 ]
  %v169 = phi i64 [ %v118, %bb23 ], [ %v198, %bb24 ]
  %v170 = phi i64 [ %v119, %bb23 ], [ %v199, %bb24 ]
  %v171 = phi i64 [ %v120, %bb23 ], [ %v200, %bb24 ]
  %v172 = phi i64 [ %v121, %bb23 ], [ %v201, %bb24 ]
  %v173 = phi i64 [ %v122, %bb23 ], [ %v202, %bb24 ]
  %v174 = phi i64 [ %v123, %bb23 ], [ %v203, %bb24 ]
  %v175 = phi i64 [ %v124, %bb23 ], [ %v204, %bb24 ]
  %v176 = phi i64 [ %v125, %bb23 ], [ %v205, %bb24 ]
  %v177 = phi i64 [ %v126, %bb23 ], [ %v206, %bb24 ]
  %v178 = phi i64 [ %v127, %bb23 ], [ %v207, %bb24 ]
  %v179 = phi i64 [ %v128, %bb23 ], [ %v208, %bb24 ]
  %v180 = phi i64 [ %v137, %bb23 ], [ %v209, %bb24 ]
  %v181 = phi i64 [ %v130, %bb23 ], [ %v210, %bb24 ]
  %v182 = phi i64 [ %v131, %bb23 ], [ %v211, %bb24 ]
  %v183 = phi i64 [ %v132, %bb23 ], [ %v212, %bb24 ]
  %v184 = phi i64 [ %v133, %bb23 ], [ %v213, %bb24 ]
  %v185 = phi i64 [ %v134, %bb23 ], [ %v214, %bb24 ]
  %v186 = phi i64 [ %v136, %bb23 ], [ %v215, %bb24 ]
  %v187 = phi i64 [ %v162, %bb23 ], [ %v216, %bb24 ]
  br label %bb18
bb22:
  %v188 = add nuw i64 %v119, %v162
  %t9 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v113, i32 0, i32 0
  %v189 = getelementptr i8, ptr %t9, i64 0
  %v190 = getelementptr i8, ptr %v189, i64 0
  %t10 = load ptr, ptr %v190
  %t11.nonnegative = icmp sge i64 %v188, 0
  call void @llvm.assume(i1 %t11.nonnegative)
  %t11 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t10, i64 0, i32 2, i64 %v188
  %v191 = getelementptr i8, ptr %t11, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v191, i64 ptrtoint (ptr getelementptr (%wf.t.e04aead91f34a68f, ptr null, i32 1) to i64), i1 false)
  %t12 = load %wf.t.e04aead91f34a68f, ptr %wf.slot.0
  %t13 = extractvalue %wf.t.e04aead91f34a68f %t12, 0
  switch i32 %t13, label %invalid.tag.b22 [
    i32 2, label %bb25
    i32 0, label %bb26
    i32 1, label %bb27
  ]
invalid.tag.b22:
  call void @abort()
  unreachable
bb23:
  br label %bb21
bb24:
  %v193 = phi ptr [ %v113, %bb27 ], [ %v222, %bb28 ]
  %v194 = phi ptr [ %v114, %bb27 ], [ %v223, %bb28 ]
  %v195 = phi ptr [ %v115, %bb27 ], [ %v224, %bb28 ]
  %v196 = phi i64 [ %v116, %bb27 ], [ %v225, %bb28 ]
  %v197 = phi i64 [ %v117, %bb27 ], [ %v226, %bb28 ]
  %v198 = phi i64 [ %v118, %bb27 ], [ %v227, %bb28 ]
  %v199 = phi i64 [ %v119, %bb27 ], [ %v228, %bb28 ]
  %v200 = phi i64 [ %v120, %bb27 ], [ %v229, %bb28 ]
  %v201 = phi i64 [ %v121, %bb27 ], [ %v230, %bb28 ]
  %v202 = phi i64 [ %v122, %bb27 ], [ %v231, %bb28 ]
  %v203 = phi i64 [ %v123, %bb27 ], [ %v232, %bb28 ]
  %v204 = phi i64 [ %v124, %bb27 ], [ %v233, %bb28 ]
  %v205 = phi i64 [ %v125, %bb27 ], [ %v234, %bb28 ]
  %v206 = phi i64 [ %v126, %bb27 ], [ %v235, %bb28 ]
  %v207 = phi i64 [ %v127, %bb27 ], [ %v236, %bb28 ]
  %v208 = phi i64 [ %v128, %bb27 ], [ %v237, %bb28 ]
  %v209 = phi i64 [ %v137, %bb27 ], [ %v238, %bb28 ]
  %v210 = phi i64 [ %v130, %bb27 ], [ %v239, %bb28 ]
  %v211 = phi i64 [ %v131, %bb27 ], [ %v240, %bb28 ]
  %v212 = phi i64 [ %v132, %bb27 ], [ %v241, %bb28 ]
  %v213 = phi i64 [ %v133, %bb27 ], [ %v242, %bb28 ]
  %v214 = phi i64 [ %v134, %bb27 ], [ %v243, %bb28 ]
  %v215 = phi i64 [ %v136, %bb27 ], [ %v244, %bb28 ]
  %v216 = phi i64 [ %v162, %bb27 ], [ %v245, %bb28 ]
  %v217 = phi i64 [ %v188, %bb27 ], [ %v246, %bb28 ]
  %v218 = phi ptr [ %v191, %bb27 ], [ %v247, %bb28 ]
  br label %bb21
bb25:
  %t14 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %v191, i32 0, i32 1
  %v219 = getelementptr i8, ptr %t14, i64 0
  %t15 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %v191, i32 0, i32 2
  %v220 = getelementptr i8, ptr %t15, i64 0
  %v221 = call i1 @wf_map_cost_equal(ptr %v115, ptr %v219, ptr %v114)
  switch i1 %v221, label %invalid.tag.b25 [
    i1 1, label %bb29
    i1 0, label %bb30
  ]
invalid.tag.b25:
  call void @abort()
  unreachable
bb26:
  %v252 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t16 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t16
  %t17 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v252, ptr %t17
  ret void
bb27:
  br label %bb24
bb28:
  %v222 = phi ptr [ %v113, %bb30 ]
  %v223 = phi ptr [ %v114, %bb30 ]
  %v224 = phi ptr [ %v115, %bb30 ]
  %v225 = phi i64 [ %v116, %bb30 ]
  %v226 = phi i64 [ %v117, %bb30 ]
  %v227 = phi i64 [ %v118, %bb30 ]
  %v228 = phi i64 [ %v119, %bb30 ]
  %v229 = phi i64 [ %v120, %bb30 ]
  %v230 = phi i64 [ %v121, %bb30 ]
  %v231 = phi i64 [ %v122, %bb30 ]
  %v232 = phi i64 [ %v123, %bb30 ]
  %v233 = phi i64 [ %v124, %bb30 ]
  %v234 = phi i64 [ %v125, %bb30 ]
  %v235 = phi i64 [ %v126, %bb30 ]
  %v236 = phi i64 [ %v127, %bb30 ]
  %v237 = phi i64 [ %v128, %bb30 ]
  %v238 = phi i64 [ %v137, %bb30 ]
  %v239 = phi i64 [ %v130, %bb30 ]
  %v240 = phi i64 [ %v131, %bb30 ]
  %v241 = phi i64 [ %v132, %bb30 ]
  %v242 = phi i64 [ %v133, %bb30 ]
  %v243 = phi i64 [ %v134, %bb30 ]
  %v244 = phi i64 [ %v136, %bb30 ]
  %v245 = phi i64 [ %v162, %bb30 ]
  %v246 = phi i64 [ %v188, %bb30 ]
  %v247 = phi ptr [ %v191, %bb30 ]
  %v248 = phi ptr [ %v219, %bb30 ]
  %v249 = phi ptr [ %v220, %bb30 ]
  %v250 = phi i1 [ %v221, %bb30 ]
  br label %bb24
bb29:
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t18 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t18
  %t19 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 1
  store i64 %v188, ptr %t19
  ret void
bb30:
  br label %bb28
bb31:
  %v254 = phi ptr [ %v139, %bb18 ]
  %v255 = phi ptr [ %v140, %bb18 ]
  %v256 = phi ptr [ %v141, %bb18 ]
  %v257 = phi i64 [ %v142, %bb18 ]
  %v258 = phi i64 [ %v143, %bb18 ]
  %v259 = phi i64 [ %v144, %bb18 ]
  %v260 = phi i64 [ %v145, %bb18 ]
  %v261 = phi i64 [ %v146, %bb18 ]
  %v262 = phi i64 [ %v147, %bb18 ]
  %v263 = phi i64 [ %v148, %bb18 ]
  %v264 = phi i64 [ %v149, %bb18 ]
  %v265 = phi i64 [ %v150, %bb18 ]
  %v266 = phi i64 [ %v151, %bb18 ]
  %v267 = phi i64 [ %v152, %bb18 ]
  %v268 = phi i64 [ %v153, %bb18 ]
  %v269 = phi i64 [ %v154, %bb18 ]
  %v270 = phi i64 [ %v155, %bb18 ]
  %v271 = phi i64 [ %v156, %bb18 ]
  %v272 = phi i64 [ %v157, %bb18 ]
  %v273 = phi i64 [ %v158, %bb18 ]
  %v274 = phi i64 [ %v87, %bb18 ]
  %v275 = phi i64 [ %v88, %bb18 ]
  %v276 = phi i64 [ %v89, %bb18 ]
  %v277 = select i1 true, i64 1, i64 1
  %v278 = add i64 %v276, %v277
  br label %bb11
bb32:
  %v280 = phi ptr [ %v90, %bb34 ]
  %v281 = phi ptr [ %v91, %bb34 ]
  %v282 = phi ptr [ %v92, %bb34 ]
  %v283 = phi i64 [ %v93, %bb34 ]
  %v284 = phi i64 [ %v94, %bb34 ]
  %v285 = phi i64 [ %v95, %bb34 ]
  %v286 = phi i64 [ %v96, %bb34 ]
  %v287 = phi i64 [ %v97, %bb34 ]
  %v288 = phi i64 [ %v98, %bb34 ]
  %v289 = phi i64 [ %v99, %bb34 ]
  %v290 = phi i64 [ %v100, %bb34 ]
  %v291 = phi i64 [ %v101, %bb34 ]
  %v292 = phi i64 [ %v102, %bb34 ]
  %v293 = phi i64 [ %v103, %bb34 ]
  %v294 = phi i64 [ %v104, %bb34 ]
  %v295 = phi i64 [ %v105, %bb34 ]
  %v296 = phi i64 [ %v106, %bb34 ]
  %v297 = phi i64 [ %v107, %bb34 ]
  %v298 = phi i64 [ %v108, %bb34 ]
  %v299 = phi i64 [ %v109, %bb34 ]
  %v302 = sub nuw i64 %v287, %v291
  %v303 = add nuw i64 %v286, %v291
  %v304 = icmp ult i64 %v303, %v284
  switch i1 %v304, label %invalid.tag.b32 [
    i1 1, label %bb36
    i1 0, label %bb37
  ]
invalid.tag.b32:
  call void @abort()
  unreachable
bb33:
  %v300 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t20 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t20
  %t21 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v300, ptr %t21
  ret void
bb34:
  br label %bb32
bb35:
  %v305 = phi ptr [ %v280, %bb36 ], [ %v280, %bb37 ]
  %v306 = phi ptr [ %v281, %bb36 ], [ %v281, %bb37 ]
  %v307 = phi ptr [ %v282, %bb36 ], [ %v282, %bb37 ]
  %v308 = phi i64 [ %v283, %bb36 ], [ %v283, %bb37 ]
  %v309 = phi i64 [ %v284, %bb36 ], [ %v284, %bb37 ]
  %v310 = phi i64 [ %v285, %bb36 ], [ %v285, %bb37 ]
  %v311 = phi i64 [ %v303, %bb36 ], [ %v326, %bb37 ]
  %v312 = phi i64 [ %v302, %bb36 ], [ %v302, %bb37 ]
  %v313 = phi i64 [ %v288, %bb36 ], [ %v288, %bb37 ]
  %v314 = phi i64 [ %v289, %bb36 ], [ %v289, %bb37 ]
  %v315 = phi i64 [ %v290, %bb36 ], [ %v290, %bb37 ]
  %v316 = phi i64 [ %v291, %bb36 ], [ %v291, %bb37 ]
  %v317 = phi i64 [ %v292, %bb36 ], [ %v292, %bb37 ]
  %v318 = phi i64 [ %v293, %bb36 ], [ %v293, %bb37 ]
  %v319 = phi i64 [ %v294, %bb36 ], [ %v294, %bb37 ]
  %v320 = phi i64 [ %v295, %bb36 ], [ %v295, %bb37 ]
  %v321 = phi i64 [ %v296, %bb36 ], [ %v296, %bb37 ]
  %v322 = phi i64 [ %v297, %bb36 ], [ %v297, %bb37 ]
  %v323 = phi i64 [ %v298, %bb36 ], [ %v298, %bb37 ]
  %v324 = phi i64 [ %v299, %bb36 ], [ %v299, %bb37 ]
  %v325 = phi i64 [ %v303, %bb36 ], [ %v303, %bb37 ]
  br label %bb38
bb36:
  br label %bb35
bb37:
  %v326 = select i1 true, i64 0, i64 0
  br label %bb35
bb38:
  %v327 = phi ptr [ %v305, %bb35 ]
  %v328 = phi ptr [ %v306, %bb35 ]
  %v329 = phi ptr [ %v307, %bb35 ]
  %v330 = phi i64 [ %v308, %bb35 ]
  %v331 = phi i64 [ %v309, %bb35 ]
  %v332 = phi i64 [ %v310, %bb35 ]
  %v333 = phi i64 [ %v311, %bb35 ]
  %v334 = phi i64 [ %v312, %bb35 ]
  %v335 = phi i64 [ %v27, %bb35 ]
  %v336 = phi i64 [ %v28, %bb35 ]
  %v337 = phi i64 [ %v29, %bb35 ]
  %v338 = select i1 true, i64 1, i64 1
  %v339 = add i64 %v337, %v338
  br label %bb4
}

define %wf.t.b7e1ed626c09888a @wf_hash_map.hash_map_find$instance$28da32efc51c2b65(ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.result = alloca %wf.t.b7e1ed626c09888a, align 8
  call void @wf_hash_map.hash_map_find$instance$28da32efc51c2b65.body(ptr %wf.result, ptr %v0, ptr %v1, ptr %v2)
  %wf.returned = load %wf.t.b7e1ed626c09888a, ptr %wf.result
  ret %wf.t.b7e1ed626c09888a %wf.returned
}

define internal void @wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.e04aead91f34a68f, align 8
  %wf.slot.1 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.2 = alloca { i64, [1 x %wf.t.20dda3774c7510ec] }, align 8
  %wf.slot.3 = alloca %wf.t.20dda3774c7510ec, align 8
  %wf.slot.4 = alloca %wf.t.20dda3774c7510ec, align 8
  %wf.slot.5 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.6 = alloca %wf.t.9d321e1eb2ec1c03, align 8
  %wf.slot.7 = alloca %wf.t.20dda3774c7510ec, align 8
  %wf.slot.8 = alloca { i64, [1 x %wf.t.20dda3774c7510ec] }, align 8
  %v29 = alloca ptr, align 8
  %v32 = alloca %wf.t.b5efdacbe94e5739, align 8
  %v71 = alloca { i64, [1 x %wf.t.20dda3774c7510ec] }, align 8
  %v3 = select i1 true, i64 16384, i64 16384
  %v4 = icmp ugt i64 %v1, %v3
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v5 = phi ptr [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb3 ]
  %v7 = phi ptr [ %v2, %bb3 ]
  %t0 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v5, i32 0, i32 0
  %v10 = getelementptr i8, ptr %t0, i64 0
  %v11 = getelementptr i8, ptr %v10, i64 0
  %t2 = load ptr, ptr %v11
  %t3 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t2, i32 0, i32 0
  %t1 = load i64, ptr %t3
  %v12 = add i64 %t1, 0
  %v13 = icmp ult i64 %v6, %v12
  switch i1 %v13, label %invalid.tag.b1 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v8 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t4 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t4
  %t5 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 2
  store i8 %v8, ptr %t5
  ret void
bb3:
  br label %bb1
bb4:
  %v14 = phi ptr [ %v5, %bb6 ]
  %v15 = phi i64 [ %v6, %bb6 ]
  %v16 = phi ptr [ %v7, %bb6 ]
  %v17 = phi i64 [ %v12, %bb6 ]
  %v20 = select i1 true, i64 0, i64 0
  %v21 = icmp eq i64 %v15, %v20
  switch i1 %v21, label %invalid.tag.b4 [
    i1 1, label %bb8
    i1 0, label %bb9
  ]
invalid.tag.b4:
  call void @abort()
  unreachable
bb5:
  %v18 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t6 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t6
  %t7 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 2
  store i8 %v18, ptr %t7
  ret void
bb6:
  br label %bb4
bb7:
  %v22 = phi ptr [ %v14, %bb9 ]
  %v23 = phi i64 [ %v15, %bb9 ]
  %v24 = phi ptr [ %v16, %bb9 ]
  %v25 = phi i64 [ %v17, %bb9 ]
  %v28 = call ptr @wf_box_slots_new$instance$b1cfa6e689dc9e10(i64 %v23)
  store ptr %v28, ptr %v29
  %v30 = call i8 @wf_hash_map.hash_map_extend$instance$0e108827ecbbe374(ptr %v29, i64 %v23)
  %v31 = call %wf.t.b5efdacbe94e5739 @wf_hash_map.hash_map_controls_new$instance$fd5e04af5c7e1250(i64 %v23)
  store %wf.t.b5efdacbe94e5739 %v31, ptr %v32
  %t8 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v22, i32 0, i32 0
  %v33 = getelementptr i8, ptr %t8, i64 0
  %v34 = call i8 @wf_swap$instance$1b41cffa653e924b(ptr %v33, ptr %v29)
  %t9 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v22, i32 0, i32 2
  %v35 = getelementptr i8, ptr %t9, i64 0
  %v36 = call i8 @wf_swap$instance$d89c7f330eeb5a04(ptr %v35, ptr %v32)
  br label %bb10
bb8:
  %v26 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t10 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t10
  %t11 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 1
  store i8 %v26, ptr %t11
  ret void
bb9:
  br label %bb7
bb10:
  %v37 = phi ptr [ %v22, %bb7 ], [ %v61, %bb15 ]
  %v38 = phi i64 [ %v23, %bb7 ], [ %v62, %bb15 ]
  %v39 = phi ptr [ %v24, %bb7 ], [ %v63, %bb15 ]
  %v40 = phi i64 [ %v25, %bb7 ], [ %v64, %bb15 ]
  %v41 = phi ptr [ %v29, %bb7 ], [ %v65, %bb15 ]
  %v42 = phi ptr [ %v32, %bb7 ], [ %v66, %bb15 ]
  %v49 = getelementptr i8, ptr %v41, i64 0
  %t13 = load ptr, ptr %v49
  %t14 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t13, i32 0, i32 0
  %t12 = load i64, ptr %t14
  %v50 = add i64 %t12, 0
  %v51 = select i1 true, i64 0, i64 0
  %v52 = icmp eq i64 %v50, %v51
  switch i1 %v52, label %invalid.tag.b10 [
    i1 1, label %bb13
    i1 0, label %bb14
  ]
invalid.tag.b10:
  call void @abort()
  unreachable
bb11:
  %v43 = phi ptr [ %v37, %bb13 ]
  %v44 = phi i64 [ %v38, %bb13 ]
  %v45 = phi ptr [ %v39, %bb13 ]
  %v46 = phi i64 [ %v40, %bb13 ]
  %v47 = phi ptr [ %v41, %bb13 ]
  %v48 = phi ptr [ %v42, %bb13 ]
  %v224 = load ptr, ptr %v47
  %v225 = call i8 @wf_free_empty$instance$1b41cffa653e924b(ptr %v224)
  %v226 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t15 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t15
  %t16 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 1
  store i8 %v226, ptr %t16
  %t17 = getelementptr inbounds %wf.t.b5efdacbe94e5739, ptr %v48, i32 0, i32 1
  %v228 = getelementptr i8, ptr %t17, i64 0
  %t18 = load { i64, [1 x ptr] }, ptr %v228
  call void @wf.drop.run.707f874ef98d2803({ i64, [1 x ptr] } %t18)
  ; drop %v228
  ; drop %v48
  ret void
bb12:
  %v53 = phi ptr [ %v37, %bb14 ]
  %v54 = phi i64 [ %v38, %bb14 ]
  %v55 = phi ptr [ %v39, %bb14 ]
  %v56 = phi i64 [ %v40, %bb14 ]
  %v57 = phi ptr [ %v41, %bb14 ]
  %v58 = phi ptr [ %v42, %bb14 ]
  %v59 = getelementptr i8, ptr %v57, i64 0
  call void @wf_take_back$instance$2af1311599ac146a(ptr %wf.slot.0, ptr %v59)
  %t19 = load %wf.t.e04aead91f34a68f, ptr %wf.slot.0
  %t20 = extractvalue %wf.t.e04aead91f34a68f %t19, 0
  switch i32 %t20, label %invalid.tag.b12 [
    i32 0, label %bb16
    i32 1, label %bb17
    i32 2, label %bb18
  ]
invalid.tag.b12:
  call void @abort()
  unreachable
bb13:
  br label %bb11
bb14:
  br label %bb12
bb15:
  %v61 = phi ptr [ %v53, %bb16 ], [ %v53, %bb17 ], [ %v85, %bb20 ]
  %v62 = phi i64 [ %v54, %bb16 ], [ %v54, %bb17 ], [ %v86, %bb20 ]
  %v63 = phi ptr [ %v55, %bb16 ], [ %v55, %bb17 ], [ %v87, %bb20 ]
  %v64 = phi i64 [ %v56, %bb16 ], [ %v56, %bb17 ], [ %v88, %bb20 ]
  %v65 = phi ptr [ %v57, %bb16 ], [ %v57, %bb17 ], [ %v89, %bb20 ]
  %v66 = phi ptr [ %v58, %bb16 ], [ %v58, %bb17 ], [ %v90, %bb20 ]
  br label %bb10
bb16:
  br label %bb15
bb17:
  br label %bb15
bb18:
  %t21 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %wf.slot.0, i32 0, i32 1
  %v68 = load i64, ptr %t21
  %t22 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %wf.slot.0, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %t22, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  call void @wf_slots_new$instance$7445cefb96d3b406(ptr %wf.slot.2)
  call void @llvm.memmove.p0.p0.i64(ptr %v71, ptr %wf.slot.2, i64 ptrtoint (ptr getelementptr ({ i64, [1 x %wf.t.20dda3774c7510ec] }, ptr null, i32 1) to i64), i1 false)
  store %wf.t.20dda3774c7510ec zeroinitializer, ptr %wf.slot.3
  %t23 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.3, i32 0, i32 0
  store i64 %v68, ptr %t23
  %t24 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.3, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %v73 = call i8 @wf_place_back$instance$48adfc37250fbcc6(ptr %v71, ptr %wf.slot.3)
  br label %bb19
bb19:
  %v74 = phi ptr [ %v53, %bb18 ], [ %v134, %bb27 ]
  %v75 = phi i64 [ %v54, %bb18 ], [ %v135, %bb27 ]
  %v76 = phi ptr [ %v55, %bb18 ], [ %v136, %bb27 ]
  %v77 = phi i64 [ %v56, %bb18 ], [ %v137, %bb27 ]
  %v78 = phi ptr [ %v57, %bb18 ], [ %v138, %bb27 ]
  %v79 = phi ptr [ %v58, %bb18 ], [ %v139, %bb27 ]
  %v81 = phi i64 [ %v68, %bb18 ], [ %v141, %bb27 ]
  %v83 = phi ptr [ %v71, %bb18 ], [ %v143, %bb27 ]
  %t26 = getelementptr inbounds { i64, [1 x %wf.t.20dda3774c7510ec] }, ptr %v83, i32 0, i32 0
  %t25 = load i64, ptr %t26
  %v96 = add i64 %t25, 0
  %v97 = select i1 true, i64 0, i64 0
  %v98 = icmp eq i64 %v96, %v97
  switch i1 %v98, label %invalid.tag.b19 [
    i1 1, label %bb22
    i1 0, label %bb23
  ]
invalid.tag.b19:
  call void @abort()
  unreachable
bb20:
  %v85 = phi ptr [ %v74, %bb22 ]
  %v86 = phi i64 [ %v75, %bb22 ]
  %v87 = phi ptr [ %v76, %bb22 ]
  %v88 = phi i64 [ %v77, %bb22 ]
  %v89 = phi ptr [ %v78, %bb22 ]
  %v90 = phi ptr [ %v79, %bb22 ]
  %v92 = phi i64 [ %v81, %bb22 ]
  %v94 = phi ptr [ %v83, %bb22 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.8, ptr %v94, i64 ptrtoint (ptr getelementptr ({ i64, [1 x %wf.t.20dda3774c7510ec] }, ptr null, i32 1) to i64), i1 false)
  %v223 = call i8 @wf_free_empty$instance$d97c759d7de32f56(ptr %wf.slot.8)
  br label %bb15
bb21:
  %v99 = phi ptr [ %v74, %bb23 ]
  %v100 = phi i64 [ %v75, %bb23 ]
  %v101 = phi ptr [ %v76, %bb23 ]
  %v102 = phi i64 [ %v77, %bb23 ]
  %v103 = phi ptr [ %v78, %bb23 ]
  %v104 = phi ptr [ %v79, %bb23 ]
  %v106 = phi i64 [ %v81, %bb23 ]
  %v108 = phi ptr [ %v83, %bb23 ]
  %v110 = select i1 true, i64 0, i64 0
  %t27.nonnegative = icmp sge i64 %v110, 0
  call void @llvm.assume(i1 %t27.nonnegative)
  %t27 = getelementptr inbounds { i64, [1 x %wf.t.20dda3774c7510ec] }, ptr %v108, i64 0, i32 1, i64 %v110
  %v111 = getelementptr i8, ptr %t27, i64 0
  %t28 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %v111, i32 0, i32 0
  %v112 = getelementptr i8, ptr %t28, i64 0
  %v113 = call i64 @wf_map_cost_hash(ptr %v101, ptr %v112)
  %t29 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v99, i32 0, i32 0
  %v114 = getelementptr i8, ptr %t29, i64 0
  %v115 = getelementptr i8, ptr %v114, i64 0
  %t31 = load ptr, ptr %v115
  %t32 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t31, i32 0, i32 0
  %t30 = load i64, ptr %t32
  %v116 = add i64 %t30, 0
  %v117 = select i1 true, i64 0, i64 0
  br label %bb24
bb22:
  br label %bb20
bb23:
  br label %bb21
bb24:
  %v118 = phi ptr [ %v99, %bb21 ], [ %v204, %bb34 ]
  %v119 = phi i64 [ %v100, %bb21 ], [ %v205, %bb34 ]
  %v120 = phi ptr [ %v101, %bb21 ], [ %v206, %bb34 ]
  %v121 = phi i64 [ %v102, %bb21 ], [ %v207, %bb34 ]
  %v122 = phi ptr [ %v103, %bb21 ], [ %v208, %bb34 ]
  %v123 = phi ptr [ %v104, %bb21 ], [ %v209, %bb34 ]
  %v125 = phi i64 [ %v106, %bb21 ], [ %v211, %bb34 ]
  %v127 = phi ptr [ %v108, %bb21 ], [ %v213, %bb34 ]
  %v129 = phi i64 [ %v113, %bb21 ], [ %v215, %bb34 ]
  %v130 = phi i64 [ %v116, %bb21 ], [ %v216, %bb34 ]
  %v131 = phi i64 [ %v117, %bb21 ], [ %v217, %bb34 ]
  %v132 = phi i64 [ %v116, %bb21 ], [ %v218, %bb34 ]
  %v133 = phi i64 [ %v117, %bb21 ], [ %v221, %bb34 ]
  %v147 = icmp ult i64 %v133, %v132
  switch i1 %v147, label %invalid.tag.b24 [
    i1 1, label %bb25
    i1 0, label %bb26
  ]
invalid.tag.b24:
  call void @abort()
  unreachable
bb25:
  %v148 = urem i64 %v129, %v130
  %v149 = call i64 @wf_hash_map.hash_map_probe(i64 %v148, i64 %v133, i64 %v130)
  %t33 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v118, i32 0, i32 0
  %v150 = getelementptr i8, ptr %t33, i64 0
  %v151 = getelementptr i8, ptr %v150, i64 0
  %t34 = load ptr, ptr %v151
  %t35.nonnegative = icmp sge i64 %v149, 0
  call void @llvm.assume(i1 %t35.nonnegative)
  %t35 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t34, i64 0, i32 2, i64 %v149
  %v152 = getelementptr i8, ptr %t35, i64 0
  %v153 = call i1 @wf_hash_map.hash_map_is_available$instance$d7a1a90c27bba449(ptr %v152)
  switch i1 %v153, label %invalid.tag.b25 [
    i1 1, label %bb29
    i1 0, label %bb30
  ]
invalid.tag.b25:
  call void @abort()
  unreachable
bb26:
  br label %bb27
bb27:
  %v134 = phi ptr [ %v118, %bb26 ], [ %v179, %bb31 ]
  %v135 = phi i64 [ %v119, %bb26 ], [ %v180, %bb31 ]
  %v136 = phi ptr [ %v120, %bb26 ], [ %v181, %bb31 ]
  %v137 = phi i64 [ %v121, %bb26 ], [ %v182, %bb31 ]
  %v138 = phi ptr [ %v122, %bb26 ], [ %v183, %bb31 ]
  %v139 = phi ptr [ %v123, %bb26 ], [ %v184, %bb31 ]
  %v141 = phi i64 [ %v125, %bb26 ], [ %v186, %bb31 ]
  %v143 = phi ptr [ %v127, %bb26 ], [ %v188, %bb31 ]
  %v145 = phi i64 [ %v129, %bb26 ], [ %v190, %bb31 ]
  %v146 = phi i64 [ %v130, %bb26 ], [ %v191, %bb31 ]
  br label %bb19
bb28:
  %v154 = phi ptr [ %v118, %bb30 ]
  %v155 = phi i64 [ %v119, %bb30 ]
  %v156 = phi ptr [ %v120, %bb30 ]
  %v157 = phi i64 [ %v121, %bb30 ]
  %v158 = phi ptr [ %v122, %bb30 ]
  %v159 = phi ptr [ %v123, %bb30 ]
  %v161 = phi i64 [ %v125, %bb30 ]
  %v163 = phi ptr [ %v127, %bb30 ]
  %v165 = phi i64 [ %v129, %bb30 ]
  %v166 = phi i64 [ %v130, %bb30 ]
  %v167 = phi i64 [ %v133, %bb30 ]
  %v168 = phi i64 [ %v148, %bb30 ]
  %v169 = phi i64 [ %v149, %bb30 ]
  %v170 = phi i1 [ %v153, %bb30 ]
  br label %bb34
bb29:
  call void @wf_take_back$instance$48adfc37250fbcc6(ptr %wf.slot.4, ptr %v127)
  %t36 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.4, i32 0, i32 0
  %v172 = load i64, ptr %t36
  ; ownership-consuming projection
  %t37 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.4, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.5, ptr %t37, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %t38 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v118, i32 0, i32 0
  %v174 = getelementptr i8, ptr %t38, i64 0
  call void @wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449(ptr %wf.slot.6, ptr %v174, i64 %v149, i64 %v172, ptr %wf.slot.5)
  %v176 = call i64 @wf_hash_map.hash_map_control_fingerprint(i64 %v129)
  %t39 = getelementptr inbounds %wf.t.05623e8a192b9069, ptr %v118, i32 0, i32 2
  %v177 = getelementptr i8, ptr %t39, i64 0
  %v178 = call i8 @wf_hash_map.hash_map_control_set(ptr %v177, i64 %v149, i64 %v176)
  %t40 = load %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.6
  %t41 = extractvalue %wf.t.9d321e1eb2ec1c03 %t40, 0
  switch i32 %t41, label %invalid.tag.b29 [
    i32 0, label %bb32
    i32 1, label %bb33
  ]
invalid.tag.b29:
  call void @abort()
  unreachable
bb30:
  br label %bb28
bb31:
  %v179 = phi ptr [ %v118, %bb32 ], [ %v118, %bb33 ]
  %v180 = phi i64 [ %v119, %bb32 ], [ %v119, %bb33 ]
  %v181 = phi ptr [ %v120, %bb32 ], [ %v120, %bb33 ]
  %v182 = phi i64 [ %v121, %bb32 ], [ %v121, %bb33 ]
  %v183 = phi ptr [ %v122, %bb32 ], [ %v122, %bb33 ]
  %v184 = phi ptr [ %v123, %bb32 ], [ %v123, %bb33 ]
  %v186 = phi i64 [ %v125, %bb32 ], [ %v125, %bb33 ]
  %v188 = phi ptr [ %v127, %bb32 ], [ %v127, %bb33 ]
  %v190 = phi i64 [ %v129, %bb32 ], [ %v129, %bb33 ]
  %v191 = phi i64 [ %v130, %bb32 ], [ %v130, %bb33 ]
  %v192 = phi i64 [ %v133, %bb32 ], [ %v133, %bb33 ]
  %v193 = phi i64 [ %v148, %bb32 ], [ %v148, %bb33 ]
  %v194 = phi i64 [ %v149, %bb32 ], [ %v149, %bb33 ]
  %v195 = phi i1 [ %v153, %bb32 ], [ %v153, %bb33 ]
  %v197 = phi i64 [ %v172, %bb32 ], [ %v172, %bb33 ]
  %v200 = phi i64 [ %v176, %bb32 ], [ %v176, %bb33 ]
  br label %bb27
bb32:
  br label %bb31
bb33:
  %t42 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.6, i32 0, i32 1
  %v201 = load i1, ptr %t42
  %t43 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.6, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.7, ptr %t43, i64 ptrtoint (ptr getelementptr (%wf.t.20dda3774c7510ec, ptr null, i32 1) to i64), i1 false)
  %v203 = call i8 @wf_place_back$instance$48adfc37250fbcc6(ptr %v127, ptr %wf.slot.7)
  br label %bb31
bb34:
  %v204 = phi ptr [ %v154, %bb28 ]
  %v205 = phi i64 [ %v155, %bb28 ]
  %v206 = phi ptr [ %v156, %bb28 ]
  %v207 = phi i64 [ %v157, %bb28 ]
  %v208 = phi ptr [ %v158, %bb28 ]
  %v209 = phi ptr [ %v159, %bb28 ]
  %v211 = phi i64 [ %v161, %bb28 ]
  %v213 = phi ptr [ %v163, %bb28 ]
  %v215 = phi i64 [ %v165, %bb28 ]
  %v216 = phi i64 [ %v166, %bb28 ]
  %v217 = phi i64 [ %v131, %bb28 ]
  %v218 = phi i64 [ %v132, %bb28 ]
  %v219 = phi i64 [ %v133, %bb28 ]
  %v220 = select i1 true, i64 1, i64 1
  %v221 = add i64 %v219, %v220
  br label %bb24
}

define %wf.t.7d7f918f7b4962fd @wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65(ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.result = alloca %wf.t.7d7f918f7b4962fd, align 4
  call void @wf_hash_map.hash_map_rebuild$instance$28da32efc51c2b65.body(ptr %wf.result, ptr %v0, i64 %v1, ptr %v2)
  %wf.returned = load %wf.t.7d7f918f7b4962fd, ptr %wf.result
  ret %wf.t.7d7f918f7b4962fd %wf.returned
}

define internal void @wf_slots_new$instance$bc7a70143afe699c.body(ptr %wf.result) #0 {
entry:
  store { i64, [1 x ptr] } zeroinitializer, ptr %wf.result
  ret void
}

define { i64, [1 x ptr] } @wf_slots_new$instance$bc7a70143afe699c() #0 {
entry:
  %wf.result = alloca { i64, [1 x ptr] }, align 8
  call void @wf_slots_new$instance$bc7a70143afe699c.body(ptr %wf.result)
  %wf.returned = load { i64, [1 x ptr] }, ptr %wf.result
  ret { i64, [1 x ptr] } %wf.returned
}

define ptr @wf_box_array_filled$instance$e194368921a477a7(i64 %v0, i64 %v1) #0 {
entry:
  %t0 = mul nuw i64 %v0, ptrtoint (ptr getelementptr (i64, ptr null, i64 1) to i64)
  %t1 = add nuw i64 %t0, ptrtoint (ptr getelementptr ({ i64, [0 x i64] }, ptr null, i64 0, i32 1) to i64)
  br label %buffer.fill.allocate.v2
buffer.fill.allocate.v2:
  %v2 = call ptr @malloc(i64 %t1)
  %t2 = icmp ne ptr %v2, null
  br i1 %t2, label %buffer.fill.init.v2, label %buffer.fill.oom.v2
buffer.fill.oom.v2:
  call void @wf_resource_abort()
  unreachable
buffer.fill.init.v2:
  %t3 = getelementptr inbounds { i64, [0 x i64] }, ptr %v2, i32 0, i32 0
  store i64 %v0, ptr %t3
  br label %buffer.fill.head.v2
buffer.fill.head.v2:
  %t4 = phi i64 [ 0, %buffer.fill.init.v2 ], [ %t6, %buffer.fill.body.v2 ]
  %t5 = icmp ult i64 %t4, %v0
  br i1 %t5, label %buffer.fill.body.v2, label %buffer.fill.done.v2
buffer.fill.body.v2:
  %t7 = getelementptr inbounds { i64, [0 x i64] }, ptr %v2, i64 0, i32 1, i64 %t4
  store i64 %v1, ptr %t7
  %t6 = add i64 %t4, 1
  br label %buffer.fill.head.v2
buffer.fill.done.v2:
  ret ptr %v2
}

define i32 @wf_hash_map.hash_map_action$instance$fc5e3cb62bdf3601(ptr noalias nonnull captures(none) dereferenceable(24) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.eb423fc38cfed56f, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.eb423fc38cfed56f, ptr null, i32 1) to i64), i1 false)
  %t0 = load %wf.t.eb423fc38cfed56f, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.eb423fc38cfed56f %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb1
    i32 1, label %bb2
    i32 2, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v4 = or i32 0, 0
  ret i32 %v4
bb2:
  %v5 = or i32 0, 1
  ret i32 %v5
bb3:
  %t2 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %v0, i32 0, i32 1
  %v6 = getelementptr i8, ptr %t2, i64 0
  %t3 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %v0, i32 0, i32 2
  %v7 = getelementptr i8, ptr %t3, i64 0
  %v8 = call i1 @wf_map_cost_equal(ptr %v2, ptr %v6, ptr %v1)
  switch i1 %v8, label %invalid.tag.b3 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b3:
  call void @abort()
  unreachable
bb4:
  %v9 = phi ptr [ %v0, %bb6 ]
  %v10 = phi ptr [ %v1, %bb6 ]
  %v11 = phi ptr [ %v2, %bb6 ]
  %v12 = phi ptr [ %v6, %bb6 ]
  %v13 = phi ptr [ %v7, %bb6 ]
  %v14 = phi i1 [ %v8, %bb6 ]
  %v16 = or i32 0, 2
  ret i32 %v16
bb5:
  %v15 = or i32 0, 3
  ret i32 %v15
bb6:
  br label %bb4
}

define void @wf_hash_map.hash_map_exchange$instance$0ed342445dd803f3(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(8) %v0, i64 %v1, i64 %v2, i64 %v3) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.eb423fc38cfed56f, align 8
  %wf.slot.1 = alloca %wf.t.09071440a409e980, align 8
  %v5 = alloca %wf.t.eb423fc38cfed56f, align 8
  store %wf.t.eb423fc38cfed56f zeroinitializer, ptr %v5
  %t0 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %v5, i32 0, i32 0
  store i32 2, ptr %t0
  %t1 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %v5, i32 0, i32 1
  store i64 %v2, ptr %t1
  %t2 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %v5, i32 0, i32 2
  store i64 %v3, ptr %t2
  %v6 = getelementptr i8, ptr %v0, i64 0
  %t3 = load ptr, ptr %v6
  %t4.nonnegative = icmp sge i64 %v1, 0
  call void @llvm.assume(i1 %t4.nonnegative)
  %t4 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t3, i64 0, i32 2, i64 %v1
  %v7 = getelementptr i8, ptr %t4, i64 0
  %v8 = call i8 @wf_swap$instance$087f541e70b769ea(ptr %v7, ptr %v5)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v5, i64 ptrtoint (ptr getelementptr (%wf.t.eb423fc38cfed56f, ptr null, i32 1) to i64), i1 false)
  %t5 = load %wf.t.eb423fc38cfed56f, ptr %wf.slot.0
  %t6 = extractvalue %wf.t.eb423fc38cfed56f %t5, 0
  switch i32 %t6, label %invalid.tag.b0 [
    i32 0, label %bb1
    i32 1, label %bb2
    i32 2, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  store %wf.t.ac5891a387b8aafe zeroinitializer, ptr %wf.result
  %t7 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t7
  ret void
bb2:
  store %wf.t.ac5891a387b8aafe zeroinitializer, ptr %wf.result
  %t8 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t8
  ret void
bb3:
  %t9 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %wf.slot.0, i32 0, i32 1
  %v12 = load i64, ptr %t9
  %t10 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %wf.slot.0, i32 0, i32 2
  %v13 = load i64, ptr %t10
  store %wf.t.09071440a409e980 zeroinitializer, ptr %wf.slot.1
  %t11 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.1, i32 0, i32 0
  store i64 %v12, ptr %t11
  %t12 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.1, i32 0, i32 1
  store i64 %v13, ptr %t12
  %v15 = or i1 0, 0
  store %wf.t.ac5891a387b8aafe zeroinitializer, ptr %wf.result
  %t13 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t13
  %t14 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 1
  store i1 %v15, ptr %t14
  %t15 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr (%wf.t.09071440a409e980, ptr null, i32 1) to i64), i1 false)
  ret void
}

define i1 @wf_hash_map.hash_map_control_inserted$instance$0ed342445dd803f3(ptr noalias nonnull captures(none) dereferenceable(24) %v0) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.ac5891a387b8aafe, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.ac5891a387b8aafe, ptr null, i32 1) to i64), i1 false)
  %t0 = load %wf.t.ac5891a387b8aafe, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.ac5891a387b8aafe %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb1
    i32 1, label %bb2
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v2 = select i1 true, i1 1, i1 1
  ret i1 %v2
bb2:
  %t2 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %v0, i32 0, i32 1
  %v3 = getelementptr i8, ptr %t2, i64 0
  %t3 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %v0, i32 0, i32 2
  %v4 = getelementptr i8, ptr %t3, i64 0
  %v5 = select i1 true, i1 0, i1 0
  ret i1 %v5
}

define internal void @wf_hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.eb423fc38cfed56f, align 8
  %wf.slot.1 = alloca { i64, [1 x %wf.t.09071440a409e980] }, align 8
  %wf.slot.2 = alloca %wf.t.09071440a409e980, align 8
  %wf.slot.3 = alloca %wf.t.09071440a409e980, align 8
  %wf.slot.4 = alloca %wf.t.ac5891a387b8aafe, align 8
  %wf.slot.5 = alloca %wf.t.09071440a409e980, align 8
  %wf.slot.6 = alloca { i64, [1 x %wf.t.09071440a409e980] }, align 8
  %v29 = alloca ptr, align 8
  %v32 = alloca %wf.t.b5efdacbe94e5739, align 8
  %v71 = alloca { i64, [1 x %wf.t.09071440a409e980] }, align 8
  %v3 = select i1 true, i64 3, i64 3
  %v4 = icmp ugt i64 %v1, %v3
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v5 = phi ptr [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb3 ]
  %v7 = phi ptr [ %v2, %bb3 ]
  %t0 = getelementptr inbounds %wf.t.2758c7c2b3b908fb, ptr %v5, i32 0, i32 0
  %v10 = getelementptr i8, ptr %t0, i64 0
  %v11 = getelementptr i8, ptr %v10, i64 0
  %t2 = load ptr, ptr %v11
  %t3 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t2, i32 0, i32 0
  %t1 = load i64, ptr %t3
  %v12 = add i64 %t1, 0
  %v13 = icmp ult i64 %v6, %v12
  switch i1 %v13, label %invalid.tag.b1 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v8 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t4 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t4
  %t5 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 2
  store i8 %v8, ptr %t5
  ret void
bb3:
  br label %bb1
bb4:
  %v14 = phi ptr [ %v5, %bb6 ]
  %v15 = phi i64 [ %v6, %bb6 ]
  %v16 = phi ptr [ %v7, %bb6 ]
  %v17 = phi i64 [ %v12, %bb6 ]
  %v20 = select i1 true, i64 0, i64 0
  %v21 = icmp eq i64 %v15, %v20
  switch i1 %v21, label %invalid.tag.b4 [
    i1 1, label %bb8
    i1 0, label %bb9
  ]
invalid.tag.b4:
  call void @abort()
  unreachable
bb5:
  %v18 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t6 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t6
  %t7 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 2
  store i8 %v18, ptr %t7
  ret void
bb6:
  br label %bb4
bb7:
  %v22 = phi ptr [ %v14, %bb9 ]
  %v23 = phi i64 [ %v15, %bb9 ]
  %v24 = phi ptr [ %v16, %bb9 ]
  %v25 = phi i64 [ %v17, %bb9 ]
  %v28 = call ptr @wf_box_slots_new$instance$087f541e70b769ea(i64 %v23)
  store ptr %v28, ptr %v29
  %v30 = call i8 @wf_hash_map.hash_map_extend$instance$a62a753cf2b0b5ca(ptr %v29, i64 %v23)
  %v31 = call %wf.t.b5efdacbe94e5739 @wf_hash_map.hash_map_controls_new$instance$c559014c068e16a3(i64 %v23)
  store %wf.t.b5efdacbe94e5739 %v31, ptr %v32
  %t8 = getelementptr inbounds %wf.t.2758c7c2b3b908fb, ptr %v22, i32 0, i32 0
  %v33 = getelementptr i8, ptr %t8, i64 0
  %v34 = call i8 @wf_swap$instance$fd33b528f0517054(ptr %v33, ptr %v29)
  %t9 = getelementptr inbounds %wf.t.2758c7c2b3b908fb, ptr %v22, i32 0, i32 2
  %v35 = getelementptr i8, ptr %t9, i64 0
  %v36 = call i8 @wf_swap$instance$d89c7f330eeb5a04(ptr %v35, ptr %v32)
  br label %bb10
bb8:
  %v26 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t10 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t10
  %t11 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 1
  store i8 %v26, ptr %t11
  ret void
bb9:
  br label %bb7
bb10:
  %v37 = phi ptr [ %v22, %bb7 ], [ %v61, %bb15 ]
  %v38 = phi i64 [ %v23, %bb7 ], [ %v62, %bb15 ]
  %v39 = phi ptr [ %v24, %bb7 ], [ %v63, %bb15 ]
  %v40 = phi i64 [ %v25, %bb7 ], [ %v64, %bb15 ]
  %v41 = phi ptr [ %v29, %bb7 ], [ %v65, %bb15 ]
  %v42 = phi ptr [ %v32, %bb7 ], [ %v66, %bb15 ]
  %v49 = getelementptr i8, ptr %v41, i64 0
  %t13 = load ptr, ptr %v49
  %t14 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t13, i32 0, i32 0
  %t12 = load i64, ptr %t14
  %v50 = add i64 %t12, 0
  %v51 = select i1 true, i64 0, i64 0
  %v52 = icmp eq i64 %v50, %v51
  switch i1 %v52, label %invalid.tag.b10 [
    i1 1, label %bb13
    i1 0, label %bb14
  ]
invalid.tag.b10:
  call void @abort()
  unreachable
bb11:
  %v43 = phi ptr [ %v37, %bb13 ]
  %v44 = phi i64 [ %v38, %bb13 ]
  %v45 = phi ptr [ %v39, %bb13 ]
  %v46 = phi i64 [ %v40, %bb13 ]
  %v47 = phi ptr [ %v41, %bb13 ]
  %v48 = phi ptr [ %v42, %bb13 ]
  %v224 = load ptr, ptr %v47
  %v225 = call i8 @wf_free_empty$instance$fd33b528f0517054(ptr %v224)
  %v226 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t15 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t15
  %t16 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 1
  store i8 %v226, ptr %t16
  %t17 = getelementptr inbounds %wf.t.b5efdacbe94e5739, ptr %v48, i32 0, i32 1
  %v228 = getelementptr i8, ptr %t17, i64 0
  %t18 = load { i64, [1 x ptr] }, ptr %v228
  call void @wf.drop.run.707f874ef98d2803({ i64, [1 x ptr] } %t18)
  ; drop %v228
  ; drop %v48
  ret void
bb12:
  %v53 = phi ptr [ %v37, %bb14 ]
  %v54 = phi i64 [ %v38, %bb14 ]
  %v55 = phi ptr [ %v39, %bb14 ]
  %v56 = phi i64 [ %v40, %bb14 ]
  %v57 = phi ptr [ %v41, %bb14 ]
  %v58 = phi ptr [ %v42, %bb14 ]
  %v59 = getelementptr i8, ptr %v57, i64 0
  %v60 = call %wf.t.eb423fc38cfed56f @wf_take_back$instance$20364da1adbcdc5f(ptr %v59)
  store %wf.t.eb423fc38cfed56f %v60, ptr %wf.slot.0
  %t19 = load %wf.t.eb423fc38cfed56f, ptr %wf.slot.0
  %t20 = extractvalue %wf.t.eb423fc38cfed56f %t19, 0
  switch i32 %t20, label %invalid.tag.b12 [
    i32 0, label %bb16
    i32 1, label %bb17
    i32 2, label %bb18
  ]
invalid.tag.b12:
  call void @abort()
  unreachable
bb13:
  br label %bb11
bb14:
  br label %bb12
bb15:
  %v61 = phi ptr [ %v53, %bb16 ], [ %v53, %bb17 ], [ %v85, %bb20 ]
  %v62 = phi i64 [ %v54, %bb16 ], [ %v54, %bb17 ], [ %v86, %bb20 ]
  %v63 = phi ptr [ %v55, %bb16 ], [ %v55, %bb17 ], [ %v87, %bb20 ]
  %v64 = phi i64 [ %v56, %bb16 ], [ %v56, %bb17 ], [ %v88, %bb20 ]
  %v65 = phi ptr [ %v57, %bb16 ], [ %v57, %bb17 ], [ %v89, %bb20 ]
  %v66 = phi ptr [ %v58, %bb16 ], [ %v58, %bb17 ], [ %v90, %bb20 ]
  br label %bb10
bb16:
  br label %bb15
bb17:
  br label %bb15
bb18:
  %t21 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %wf.slot.0, i32 0, i32 1
  %v68 = load i64, ptr %t21
  %t22 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %wf.slot.0, i32 0, i32 2
  %v69 = load i64, ptr %t22
  %v70 = call { i64, [1 x %wf.t.09071440a409e980] } @wf_slots_new$instance$f6f95306140971d3()
  store { i64, [1 x %wf.t.09071440a409e980] } %v70, ptr %wf.slot.1
  call void @llvm.memmove.p0.p0.i64(ptr %v71, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr ({ i64, [1 x %wf.t.09071440a409e980] }, ptr null, i32 1) to i64), i1 false)
  store %wf.t.09071440a409e980 zeroinitializer, ptr %wf.slot.2
  %t23 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.2, i32 0, i32 0
  store i64 %v68, ptr %t23
  %t24 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.2, i32 0, i32 1
  store i64 %v69, ptr %t24
  %v73 = call i8 @wf_place_back$instance$22267f8259e51fb5(ptr %v71, ptr %wf.slot.2)
  br label %bb19
bb19:
  %v74 = phi ptr [ %v53, %bb18 ], [ %v134, %bb27 ]
  %v75 = phi i64 [ %v54, %bb18 ], [ %v135, %bb27 ]
  %v76 = phi ptr [ %v55, %bb18 ], [ %v136, %bb27 ]
  %v77 = phi i64 [ %v56, %bb18 ], [ %v137, %bb27 ]
  %v78 = phi ptr [ %v57, %bb18 ], [ %v138, %bb27 ]
  %v79 = phi ptr [ %v58, %bb18 ], [ %v139, %bb27 ]
  %v81 = phi i64 [ %v68, %bb18 ], [ %v141, %bb27 ]
  %v82 = phi i64 [ %v69, %bb18 ], [ %v142, %bb27 ]
  %v83 = phi ptr [ %v71, %bb18 ], [ %v143, %bb27 ]
  %t26 = getelementptr inbounds { i64, [1 x %wf.t.09071440a409e980] }, ptr %v83, i32 0, i32 0
  %t25 = load i64, ptr %t26
  %v96 = add i64 %t25, 0
  %v97 = select i1 true, i64 0, i64 0
  %v98 = icmp eq i64 %v96, %v97
  switch i1 %v98, label %invalid.tag.b19 [
    i1 1, label %bb22
    i1 0, label %bb23
  ]
invalid.tag.b19:
  call void @abort()
  unreachable
bb20:
  %v85 = phi ptr [ %v74, %bb22 ]
  %v86 = phi i64 [ %v75, %bb22 ]
  %v87 = phi ptr [ %v76, %bb22 ]
  %v88 = phi i64 [ %v77, %bb22 ]
  %v89 = phi ptr [ %v78, %bb22 ]
  %v90 = phi ptr [ %v79, %bb22 ]
  %v92 = phi i64 [ %v81, %bb22 ]
  %v93 = phi i64 [ %v82, %bb22 ]
  %v94 = phi ptr [ %v83, %bb22 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.6, ptr %v94, i64 ptrtoint (ptr getelementptr ({ i64, [1 x %wf.t.09071440a409e980] }, ptr null, i32 1) to i64), i1 false)
  %v223 = call i8 @wf_free_empty$instance$b7fb76652ce23509(ptr %wf.slot.6)
  br label %bb15
bb21:
  %v99 = phi ptr [ %v74, %bb23 ]
  %v100 = phi i64 [ %v75, %bb23 ]
  %v101 = phi ptr [ %v76, %bb23 ]
  %v102 = phi i64 [ %v77, %bb23 ]
  %v103 = phi ptr [ %v78, %bb23 ]
  %v104 = phi ptr [ %v79, %bb23 ]
  %v106 = phi i64 [ %v81, %bb23 ]
  %v107 = phi i64 [ %v82, %bb23 ]
  %v108 = phi ptr [ %v83, %bb23 ]
  %v110 = select i1 true, i64 0, i64 0
  %t27.nonnegative = icmp sge i64 %v110, 0
  call void @llvm.assume(i1 %t27.nonnegative)
  %t27 = getelementptr inbounds { i64, [1 x %wf.t.09071440a409e980] }, ptr %v108, i64 0, i32 1, i64 %v110
  %v111 = getelementptr i8, ptr %t27, i64 0
  %t28 = getelementptr inbounds %wf.t.09071440a409e980, ptr %v111, i32 0, i32 0
  %v112 = getelementptr i8, ptr %t28, i64 0
  %v113 = call i64 @wf_map_cost_hash(ptr %v101, ptr %v112)
  %t29 = getelementptr inbounds %wf.t.2758c7c2b3b908fb, ptr %v99, i32 0, i32 0
  %v114 = getelementptr i8, ptr %t29, i64 0
  %v115 = getelementptr i8, ptr %v114, i64 0
  %t31 = load ptr, ptr %v115
  %t32 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t31, i32 0, i32 0
  %t30 = load i64, ptr %t32
  %v116 = add i64 %t30, 0
  %v117 = select i1 true, i64 0, i64 0
  br label %bb24
bb22:
  br label %bb20
bb23:
  br label %bb21
bb24:
  %v118 = phi ptr [ %v99, %bb21 ], [ %v204, %bb34 ]
  %v119 = phi i64 [ %v100, %bb21 ], [ %v205, %bb34 ]
  %v120 = phi ptr [ %v101, %bb21 ], [ %v206, %bb34 ]
  %v121 = phi i64 [ %v102, %bb21 ], [ %v207, %bb34 ]
  %v122 = phi ptr [ %v103, %bb21 ], [ %v208, %bb34 ]
  %v123 = phi ptr [ %v104, %bb21 ], [ %v209, %bb34 ]
  %v125 = phi i64 [ %v106, %bb21 ], [ %v211, %bb34 ]
  %v126 = phi i64 [ %v107, %bb21 ], [ %v212, %bb34 ]
  %v127 = phi ptr [ %v108, %bb21 ], [ %v213, %bb34 ]
  %v129 = phi i64 [ %v113, %bb21 ], [ %v215, %bb34 ]
  %v130 = phi i64 [ %v116, %bb21 ], [ %v216, %bb34 ]
  %v131 = phi i64 [ %v117, %bb21 ], [ %v217, %bb34 ]
  %v132 = phi i64 [ %v116, %bb21 ], [ %v218, %bb34 ]
  %v133 = phi i64 [ %v117, %bb21 ], [ %v221, %bb34 ]
  %v147 = icmp ult i64 %v133, %v132
  switch i1 %v147, label %invalid.tag.b24 [
    i1 1, label %bb25
    i1 0, label %bb26
  ]
invalid.tag.b24:
  call void @abort()
  unreachable
bb25:
  %v148 = urem i64 %v129, %v130
  %v149 = call i64 @wf_hash_map.hash_map_probe(i64 %v148, i64 %v133, i64 %v130)
  %t33 = getelementptr inbounds %wf.t.2758c7c2b3b908fb, ptr %v118, i32 0, i32 0
  %v150 = getelementptr i8, ptr %t33, i64 0
  %v151 = getelementptr i8, ptr %v150, i64 0
  %t34 = load ptr, ptr %v151
  %t35.nonnegative = icmp sge i64 %v149, 0
  call void @llvm.assume(i1 %t35.nonnegative)
  %t35 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t34, i64 0, i32 2, i64 %v149
  %v152 = getelementptr i8, ptr %t35, i64 0
  %v153 = call i1 @wf_hash_map.hash_map_is_available$instance$0ed342445dd803f3(ptr %v152)
  switch i1 %v153, label %invalid.tag.b25 [
    i1 1, label %bb29
    i1 0, label %bb30
  ]
invalid.tag.b25:
  call void @abort()
  unreachable
bb26:
  br label %bb27
bb27:
  %v134 = phi ptr [ %v118, %bb26 ], [ %v179, %bb31 ]
  %v135 = phi i64 [ %v119, %bb26 ], [ %v180, %bb31 ]
  %v136 = phi ptr [ %v120, %bb26 ], [ %v181, %bb31 ]
  %v137 = phi i64 [ %v121, %bb26 ], [ %v182, %bb31 ]
  %v138 = phi ptr [ %v122, %bb26 ], [ %v183, %bb31 ]
  %v139 = phi ptr [ %v123, %bb26 ], [ %v184, %bb31 ]
  %v141 = phi i64 [ %v125, %bb26 ], [ %v186, %bb31 ]
  %v142 = phi i64 [ %v126, %bb26 ], [ %v187, %bb31 ]
  %v143 = phi ptr [ %v127, %bb26 ], [ %v188, %bb31 ]
  %v145 = phi i64 [ %v129, %bb26 ], [ %v190, %bb31 ]
  %v146 = phi i64 [ %v130, %bb26 ], [ %v191, %bb31 ]
  br label %bb19
bb28:
  %v154 = phi ptr [ %v118, %bb30 ]
  %v155 = phi i64 [ %v119, %bb30 ]
  %v156 = phi ptr [ %v120, %bb30 ]
  %v157 = phi i64 [ %v121, %bb30 ]
  %v158 = phi ptr [ %v122, %bb30 ]
  %v159 = phi ptr [ %v123, %bb30 ]
  %v161 = phi i64 [ %v125, %bb30 ]
  %v162 = phi i64 [ %v126, %bb30 ]
  %v163 = phi ptr [ %v127, %bb30 ]
  %v165 = phi i64 [ %v129, %bb30 ]
  %v166 = phi i64 [ %v130, %bb30 ]
  %v167 = phi i64 [ %v133, %bb30 ]
  %v168 = phi i64 [ %v148, %bb30 ]
  %v169 = phi i64 [ %v149, %bb30 ]
  %v170 = phi i1 [ %v153, %bb30 ]
  br label %bb34
bb29:
  %v171 = call %wf.t.09071440a409e980 @wf_take_back$instance$22267f8259e51fb5(ptr %v127)
  store %wf.t.09071440a409e980 %v171, ptr %wf.slot.3
  %t36 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.3, i32 0, i32 0
  %v172 = load i64, ptr %t36
  ; ownership-consuming projection
  %t37 = getelementptr inbounds %wf.t.09071440a409e980, ptr %wf.slot.3, i32 0, i32 1
  %v173 = load i64, ptr %t37
  ; ownership-consuming projection
  %t38 = getelementptr inbounds %wf.t.2758c7c2b3b908fb, ptr %v118, i32 0, i32 0
  %v174 = getelementptr i8, ptr %t38, i64 0
  call void @wf_hash_map.hash_map_exchange$instance$0ed342445dd803f3(ptr %wf.slot.4, ptr %v174, i64 %v149, i64 %v172, i64 %v173)
  %v176 = call i64 @wf_hash_map.hash_map_control_fingerprint(i64 %v129)
  %t39 = getelementptr inbounds %wf.t.2758c7c2b3b908fb, ptr %v118, i32 0, i32 2
  %v177 = getelementptr i8, ptr %t39, i64 0
  %v178 = call i8 @wf_hash_map.hash_map_control_set(ptr %v177, i64 %v149, i64 %v176)
  %t40 = load %wf.t.ac5891a387b8aafe, ptr %wf.slot.4
  %t41 = extractvalue %wf.t.ac5891a387b8aafe %t40, 0
  switch i32 %t41, label %invalid.tag.b29 [
    i32 0, label %bb32
    i32 1, label %bb33
  ]
invalid.tag.b29:
  call void @abort()
  unreachable
bb30:
  br label %bb28
bb31:
  %v179 = phi ptr [ %v118, %bb32 ], [ %v118, %bb33 ]
  %v180 = phi i64 [ %v119, %bb32 ], [ %v119, %bb33 ]
  %v181 = phi ptr [ %v120, %bb32 ], [ %v120, %bb33 ]
  %v182 = phi i64 [ %v121, %bb32 ], [ %v121, %bb33 ]
  %v183 = phi ptr [ %v122, %bb32 ], [ %v122, %bb33 ]
  %v184 = phi ptr [ %v123, %bb32 ], [ %v123, %bb33 ]
  %v186 = phi i64 [ %v125, %bb32 ], [ %v125, %bb33 ]
  %v187 = phi i64 [ %v126, %bb32 ], [ %v126, %bb33 ]
  %v188 = phi ptr [ %v127, %bb32 ], [ %v127, %bb33 ]
  %v190 = phi i64 [ %v129, %bb32 ], [ %v129, %bb33 ]
  %v191 = phi i64 [ %v130, %bb32 ], [ %v130, %bb33 ]
  %v192 = phi i64 [ %v133, %bb32 ], [ %v133, %bb33 ]
  %v193 = phi i64 [ %v148, %bb32 ], [ %v148, %bb33 ]
  %v194 = phi i64 [ %v149, %bb32 ], [ %v149, %bb33 ]
  %v195 = phi i1 [ %v153, %bb32 ], [ %v153, %bb33 ]
  %v197 = phi i64 [ %v172, %bb32 ], [ %v172, %bb33 ]
  %v198 = phi i64 [ %v173, %bb32 ], [ %v173, %bb33 ]
  %v200 = phi i64 [ %v176, %bb32 ], [ %v176, %bb33 ]
  br label %bb27
bb32:
  br label %bb31
bb33:
  %t42 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.slot.4, i32 0, i32 1
  %v201 = load i1, ptr %t42
  %t43 = getelementptr inbounds %wf.t.ac5891a387b8aafe, ptr %wf.slot.4, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.5, ptr %t43, i64 ptrtoint (ptr getelementptr (%wf.t.09071440a409e980, ptr null, i32 1) to i64), i1 false)
  %v203 = call i8 @wf_place_back$instance$22267f8259e51fb5(ptr %v127, ptr %wf.slot.5)
  br label %bb31
bb34:
  %v204 = phi ptr [ %v154, %bb28 ]
  %v205 = phi i64 [ %v155, %bb28 ]
  %v206 = phi ptr [ %v156, %bb28 ]
  %v207 = phi i64 [ %v157, %bb28 ]
  %v208 = phi ptr [ %v158, %bb28 ]
  %v209 = phi ptr [ %v159, %bb28 ]
  %v211 = phi i64 [ %v161, %bb28 ]
  %v212 = phi i64 [ %v162, %bb28 ]
  %v213 = phi ptr [ %v163, %bb28 ]
  %v215 = phi i64 [ %v165, %bb28 ]
  %v216 = phi i64 [ %v166, %bb28 ]
  %v217 = phi i64 [ %v131, %bb28 ]
  %v218 = phi i64 [ %v132, %bb28 ]
  %v219 = phi i64 [ %v133, %bb28 ]
  %v220 = select i1 true, i64 1, i64 1
  %v221 = add i64 %v219, %v220
  br label %bb24
}

define %wf.t.7d7f918f7b4962fd @wf_hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6(ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.result = alloca %wf.t.7d7f918f7b4962fd, align 4
  call void @wf_hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6.body(ptr %wf.result, ptr %v0, i64 %v1, ptr %v2)
  %wf.returned = load %wf.t.7d7f918f7b4962fd, ptr %wf.result
  ret %wf.t.7d7f918f7b4962fd %wf.returned
}

define internal void @wf_slots_new$instance$f6f95306140971d3.body(ptr %wf.result) #0 {
entry:
  store { i64, [1 x %wf.t.09071440a409e980] } zeroinitializer, ptr %wf.result
  ret void
}

define { i64, [1 x %wf.t.09071440a409e980] } @wf_slots_new$instance$f6f95306140971d3() #0 {
entry:
  %wf.result = alloca { i64, [1 x %wf.t.09071440a409e980] }, align 8
  call void @wf_slots_new$instance$f6f95306140971d3.body(ptr %wf.result)
  %wf.returned = load { i64, [1 x %wf.t.09071440a409e980] }, ptr %wf.result
  ret { i64, [1 x %wf.t.09071440a409e980] } %wf.returned
}

define i1 @wf_hash_map.hash_map_is_available$instance$0ed342445dd803f3(ptr noalias nonnull captures(none) dereferenceable(24) %v0) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.eb423fc38cfed56f, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.eb423fc38cfed56f, ptr null, i32 1) to i64), i1 false)
  %t0 = load %wf.t.eb423fc38cfed56f, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.eb423fc38cfed56f %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb1
    i32 1, label %bb2
    i32 2, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v2 = select i1 true, i1 1, i1 1
  ret i1 %v2
bb2:
  %v3 = select i1 true, i1 1, i1 1
  ret i1 %v3
bb3:
  %t2 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %v0, i32 0, i32 1
  %v4 = getelementptr i8, ptr %t2, i64 0
  %t3 = getelementptr inbounds %wf.t.eb423fc38cfed56f, ptr %v0, i32 0, i32 2
  %v5 = getelementptr i8, ptr %t3, i64 0
  %v6 = select i1 true, i1 0, i1 0
  ret i1 %v6
}

define i32 @wf_hash_map.hash_map_action$instance$c6df3d8464f8cde0(ptr noalias nonnull captures(none) dereferenceable(272) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.e04aead91f34a68f, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.e04aead91f34a68f, ptr null, i32 1) to i64), i1 false)
  %t0 = load %wf.t.e04aead91f34a68f, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.e04aead91f34a68f %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb1
    i32 1, label %bb2
    i32 2, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v4 = or i32 0, 0
  ret i32 %v4
bb2:
  %v5 = or i32 0, 1
  ret i32 %v5
bb3:
  %t2 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %v0, i32 0, i32 1
  %v6 = getelementptr i8, ptr %t2, i64 0
  %t3 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %v0, i32 0, i32 2
  %v7 = getelementptr i8, ptr %t3, i64 0
  %v8 = call i1 @wf_map_cost_equal(ptr %v2, ptr %v6, ptr %v1)
  switch i1 %v8, label %invalid.tag.b3 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b3:
  call void @abort()
  unreachable
bb4:
  %v9 = phi ptr [ %v0, %bb6 ]
  %v10 = phi ptr [ %v1, %bb6 ]
  %v11 = phi ptr [ %v2, %bb6 ]
  %v12 = phi ptr [ %v6, %bb6 ]
  %v13 = phi ptr [ %v7, %bb6 ]
  %v14 = phi i1 [ %v8, %bb6 ]
  %v16 = or i32 0, 2
  ret i32 %v16
bb5:
  %v15 = or i32 0, 3
  ret i32 %v15
bb6:
  br label %bb4
}

define void @wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(8) %v0, i64 %v1, i64 %v2, ptr %wf.arg.v3) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.1 = alloca %wf.t.e04aead91f34a68f, align 8
  %wf.slot.2 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.3 = alloca %wf.t.20dda3774c7510ec, align 8
  %v5 = alloca %wf.t.e04aead91f34a68f, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v3, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  store %wf.t.e04aead91f34a68f zeroinitializer, ptr %v5
  %t0 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %v5, i32 0, i32 0
  store i32 2, ptr %t0
  %t1 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %v5, i32 0, i32 1
  store i64 %v2, ptr %t1
  %t2 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %v5, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t2, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %v6 = getelementptr i8, ptr %v0, i64 0
  %t3 = load ptr, ptr %v6
  %t4.nonnegative = icmp sge i64 %v1, 0
  call void @llvm.assume(i1 %t4.nonnegative)
  %t4 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t3, i64 0, i32 2, i64 %v1
  %v7 = getelementptr i8, ptr %t4, i64 0
  %v8 = call i8 @wf_swap$instance$b1cfa6e689dc9e10(ptr %v7, ptr %v5)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v5, i64 ptrtoint (ptr getelementptr (%wf.t.e04aead91f34a68f, ptr null, i32 1) to i64), i1 false)
  %t5 = load %wf.t.e04aead91f34a68f, ptr %wf.slot.1
  %t6 = extractvalue %wf.t.e04aead91f34a68f %t5, 0
  switch i32 %t6, label %invalid.tag.b0 [
    i32 0, label %bb1
    i32 1, label %bb2
    i32 2, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  store %wf.t.9d321e1eb2ec1c03 zeroinitializer, ptr %wf.result
  %t7 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t7
  ret void
bb2:
  store %wf.t.9d321e1eb2ec1c03 zeroinitializer, ptr %wf.result
  %t8 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t8
  ret void
bb3:
  %t9 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %wf.slot.1, i32 0, i32 1
  %v12 = load i64, ptr %t9
  %t10 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %wf.slot.1, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %t10, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  store %wf.t.20dda3774c7510ec zeroinitializer, ptr %wf.slot.3
  %t11 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.3, i32 0, i32 0
  store i64 %v12, ptr %t11
  %t12 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.3, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t12, ptr %wf.slot.2, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %v15 = or i1 0, 0
  store %wf.t.9d321e1eb2ec1c03 zeroinitializer, ptr %wf.result
  %t13 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t13
  %t14 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 1
  store i1 %v15, ptr %t14
  %t15 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %wf.slot.3, i64 ptrtoint (ptr getelementptr (%wf.t.20dda3774c7510ec, ptr null, i32 1) to i64), i1 false)
  ret void
}

define i1 @wf_hash_map.hash_map_control_inserted$instance$d7a1a90c27bba449(ptr noalias nonnull captures(none) dereferenceable(272) %v0) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.9d321e1eb2ec1c03, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.9d321e1eb2ec1c03, ptr null, i32 1) to i64), i1 false)
  %t0 = load %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.9d321e1eb2ec1c03 %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb1
    i32 1, label %bb2
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v2 = select i1 true, i1 1, i1 1
  ret i1 %v2
bb2:
  %t2 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %v0, i32 0, i32 1
  %v3 = getelementptr i8, ptr %t2, i64 0
  %t3 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %v0, i32 0, i32 2
  %v4 = getelementptr i8, ptr %t3, i64 0
  %v5 = select i1 true, i1 0, i1 0
  ret i1 %v5
}

define internal void @wf_hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.e04aead91f34a68f, align 8
  %wf.slot.1 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.2 = alloca { i64, [1 x %wf.t.20dda3774c7510ec] }, align 8
  %wf.slot.3 = alloca %wf.t.20dda3774c7510ec, align 8
  %wf.slot.4 = alloca %wf.t.20dda3774c7510ec, align 8
  %wf.slot.5 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.6 = alloca %wf.t.9d321e1eb2ec1c03, align 8
  %wf.slot.7 = alloca %wf.t.20dda3774c7510ec, align 8
  %wf.slot.8 = alloca { i64, [1 x %wf.t.20dda3774c7510ec] }, align 8
  %v29 = alloca ptr, align 8
  %v32 = alloca %wf.t.b5efdacbe94e5739, align 8
  %v71 = alloca { i64, [1 x %wf.t.20dda3774c7510ec] }, align 8
  %v3 = select i1 true, i64 3, i64 3
  %v4 = icmp ugt i64 %v1, %v3
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v5 = phi ptr [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb3 ]
  %v7 = phi ptr [ %v2, %bb3 ]
  %t0 = getelementptr inbounds %wf.t.a5ea622fe32c85b6, ptr %v5, i32 0, i32 0
  %v10 = getelementptr i8, ptr %t0, i64 0
  %v11 = getelementptr i8, ptr %v10, i64 0
  %t2 = load ptr, ptr %v11
  %t3 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t2, i32 0, i32 0
  %t1 = load i64, ptr %t3
  %v12 = add i64 %t1, 0
  %v13 = icmp ult i64 %v6, %v12
  switch i1 %v13, label %invalid.tag.b1 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b1:
  call void @abort()
  unreachable
bb2:
  %v8 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t4 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t4
  %t5 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 2
  store i8 %v8, ptr %t5
  ret void
bb3:
  br label %bb1
bb4:
  %v14 = phi ptr [ %v5, %bb6 ]
  %v15 = phi i64 [ %v6, %bb6 ]
  %v16 = phi ptr [ %v7, %bb6 ]
  %v17 = phi i64 [ %v12, %bb6 ]
  %v20 = select i1 true, i64 0, i64 0
  %v21 = icmp eq i64 %v15, %v20
  switch i1 %v21, label %invalid.tag.b4 [
    i1 1, label %bb8
    i1 0, label %bb9
  ]
invalid.tag.b4:
  call void @abort()
  unreachable
bb5:
  %v18 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t6 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t6
  %t7 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 2
  store i8 %v18, ptr %t7
  ret void
bb6:
  br label %bb4
bb7:
  %v22 = phi ptr [ %v14, %bb9 ]
  %v23 = phi i64 [ %v15, %bb9 ]
  %v24 = phi ptr [ %v16, %bb9 ]
  %v25 = phi i64 [ %v17, %bb9 ]
  %v28 = call ptr @wf_box_slots_new$instance$b1cfa6e689dc9e10(i64 %v23)
  store ptr %v28, ptr %v29
  %v30 = call i8 @wf_hash_map.hash_map_extend$instance$96033bf6ddb80743(ptr %v29, i64 %v23)
  %v31 = call %wf.t.b5efdacbe94e5739 @wf_hash_map.hash_map_controls_new$instance$c559014c068e16a3(i64 %v23)
  store %wf.t.b5efdacbe94e5739 %v31, ptr %v32
  %t8 = getelementptr inbounds %wf.t.a5ea622fe32c85b6, ptr %v22, i32 0, i32 0
  %v33 = getelementptr i8, ptr %t8, i64 0
  %v34 = call i8 @wf_swap$instance$1b41cffa653e924b(ptr %v33, ptr %v29)
  %t9 = getelementptr inbounds %wf.t.a5ea622fe32c85b6, ptr %v22, i32 0, i32 2
  %v35 = getelementptr i8, ptr %t9, i64 0
  %v36 = call i8 @wf_swap$instance$d89c7f330eeb5a04(ptr %v35, ptr %v32)
  br label %bb10
bb8:
  %v26 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t10 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t10
  %t11 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 1
  store i8 %v26, ptr %t11
  ret void
bb9:
  br label %bb7
bb10:
  %v37 = phi ptr [ %v22, %bb7 ], [ %v61, %bb15 ]
  %v38 = phi i64 [ %v23, %bb7 ], [ %v62, %bb15 ]
  %v39 = phi ptr [ %v24, %bb7 ], [ %v63, %bb15 ]
  %v40 = phi i64 [ %v25, %bb7 ], [ %v64, %bb15 ]
  %v41 = phi ptr [ %v29, %bb7 ], [ %v65, %bb15 ]
  %v42 = phi ptr [ %v32, %bb7 ], [ %v66, %bb15 ]
  %v49 = getelementptr i8, ptr %v41, i64 0
  %t13 = load ptr, ptr %v49
  %t14 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t13, i32 0, i32 0
  %t12 = load i64, ptr %t14
  %v50 = add i64 %t12, 0
  %v51 = select i1 true, i64 0, i64 0
  %v52 = icmp eq i64 %v50, %v51
  switch i1 %v52, label %invalid.tag.b10 [
    i1 1, label %bb13
    i1 0, label %bb14
  ]
invalid.tag.b10:
  call void @abort()
  unreachable
bb11:
  %v43 = phi ptr [ %v37, %bb13 ]
  %v44 = phi i64 [ %v38, %bb13 ]
  %v45 = phi ptr [ %v39, %bb13 ]
  %v46 = phi i64 [ %v40, %bb13 ]
  %v47 = phi ptr [ %v41, %bb13 ]
  %v48 = phi ptr [ %v42, %bb13 ]
  %v224 = load ptr, ptr %v47
  %v225 = call i8 @wf_free_empty$instance$1b41cffa653e924b(ptr %v224)
  %v226 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t15 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t15
  %t16 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 1
  store i8 %v226, ptr %t16
  %t17 = getelementptr inbounds %wf.t.b5efdacbe94e5739, ptr %v48, i32 0, i32 1
  %v228 = getelementptr i8, ptr %t17, i64 0
  %t18 = load { i64, [1 x ptr] }, ptr %v228
  call void @wf.drop.run.707f874ef98d2803({ i64, [1 x ptr] } %t18)
  ; drop %v228
  ; drop %v48
  ret void
bb12:
  %v53 = phi ptr [ %v37, %bb14 ]
  %v54 = phi i64 [ %v38, %bb14 ]
  %v55 = phi ptr [ %v39, %bb14 ]
  %v56 = phi i64 [ %v40, %bb14 ]
  %v57 = phi ptr [ %v41, %bb14 ]
  %v58 = phi ptr [ %v42, %bb14 ]
  %v59 = getelementptr i8, ptr %v57, i64 0
  call void @wf_take_back$instance$2af1311599ac146a(ptr %wf.slot.0, ptr %v59)
  %t19 = load %wf.t.e04aead91f34a68f, ptr %wf.slot.0
  %t20 = extractvalue %wf.t.e04aead91f34a68f %t19, 0
  switch i32 %t20, label %invalid.tag.b12 [
    i32 0, label %bb16
    i32 1, label %bb17
    i32 2, label %bb18
  ]
invalid.tag.b12:
  call void @abort()
  unreachable
bb13:
  br label %bb11
bb14:
  br label %bb12
bb15:
  %v61 = phi ptr [ %v53, %bb16 ], [ %v53, %bb17 ], [ %v85, %bb20 ]
  %v62 = phi i64 [ %v54, %bb16 ], [ %v54, %bb17 ], [ %v86, %bb20 ]
  %v63 = phi ptr [ %v55, %bb16 ], [ %v55, %bb17 ], [ %v87, %bb20 ]
  %v64 = phi i64 [ %v56, %bb16 ], [ %v56, %bb17 ], [ %v88, %bb20 ]
  %v65 = phi ptr [ %v57, %bb16 ], [ %v57, %bb17 ], [ %v89, %bb20 ]
  %v66 = phi ptr [ %v58, %bb16 ], [ %v58, %bb17 ], [ %v90, %bb20 ]
  br label %bb10
bb16:
  br label %bb15
bb17:
  br label %bb15
bb18:
  %t21 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %wf.slot.0, i32 0, i32 1
  %v68 = load i64, ptr %t21
  %t22 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %wf.slot.0, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %t22, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  call void @wf_slots_new$instance$7445cefb96d3b406(ptr %wf.slot.2)
  call void @llvm.memmove.p0.p0.i64(ptr %v71, ptr %wf.slot.2, i64 ptrtoint (ptr getelementptr ({ i64, [1 x %wf.t.20dda3774c7510ec] }, ptr null, i32 1) to i64), i1 false)
  store %wf.t.20dda3774c7510ec zeroinitializer, ptr %wf.slot.3
  %t23 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.3, i32 0, i32 0
  store i64 %v68, ptr %t23
  %t24 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.3, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %v73 = call i8 @wf_place_back$instance$48adfc37250fbcc6(ptr %v71, ptr %wf.slot.3)
  br label %bb19
bb19:
  %v74 = phi ptr [ %v53, %bb18 ], [ %v134, %bb27 ]
  %v75 = phi i64 [ %v54, %bb18 ], [ %v135, %bb27 ]
  %v76 = phi ptr [ %v55, %bb18 ], [ %v136, %bb27 ]
  %v77 = phi i64 [ %v56, %bb18 ], [ %v137, %bb27 ]
  %v78 = phi ptr [ %v57, %bb18 ], [ %v138, %bb27 ]
  %v79 = phi ptr [ %v58, %bb18 ], [ %v139, %bb27 ]
  %v81 = phi i64 [ %v68, %bb18 ], [ %v141, %bb27 ]
  %v83 = phi ptr [ %v71, %bb18 ], [ %v143, %bb27 ]
  %t26 = getelementptr inbounds { i64, [1 x %wf.t.20dda3774c7510ec] }, ptr %v83, i32 0, i32 0
  %t25 = load i64, ptr %t26
  %v96 = add i64 %t25, 0
  %v97 = select i1 true, i64 0, i64 0
  %v98 = icmp eq i64 %v96, %v97
  switch i1 %v98, label %invalid.tag.b19 [
    i1 1, label %bb22
    i1 0, label %bb23
  ]
invalid.tag.b19:
  call void @abort()
  unreachable
bb20:
  %v85 = phi ptr [ %v74, %bb22 ]
  %v86 = phi i64 [ %v75, %bb22 ]
  %v87 = phi ptr [ %v76, %bb22 ]
  %v88 = phi i64 [ %v77, %bb22 ]
  %v89 = phi ptr [ %v78, %bb22 ]
  %v90 = phi ptr [ %v79, %bb22 ]
  %v92 = phi i64 [ %v81, %bb22 ]
  %v94 = phi ptr [ %v83, %bb22 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.8, ptr %v94, i64 ptrtoint (ptr getelementptr ({ i64, [1 x %wf.t.20dda3774c7510ec] }, ptr null, i32 1) to i64), i1 false)
  %v223 = call i8 @wf_free_empty$instance$d97c759d7de32f56(ptr %wf.slot.8)
  br label %bb15
bb21:
  %v99 = phi ptr [ %v74, %bb23 ]
  %v100 = phi i64 [ %v75, %bb23 ]
  %v101 = phi ptr [ %v76, %bb23 ]
  %v102 = phi i64 [ %v77, %bb23 ]
  %v103 = phi ptr [ %v78, %bb23 ]
  %v104 = phi ptr [ %v79, %bb23 ]
  %v106 = phi i64 [ %v81, %bb23 ]
  %v108 = phi ptr [ %v83, %bb23 ]
  %v110 = select i1 true, i64 0, i64 0
  %t27.nonnegative = icmp sge i64 %v110, 0
  call void @llvm.assume(i1 %t27.nonnegative)
  %t27 = getelementptr inbounds { i64, [1 x %wf.t.20dda3774c7510ec] }, ptr %v108, i64 0, i32 1, i64 %v110
  %v111 = getelementptr i8, ptr %t27, i64 0
  %t28 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %v111, i32 0, i32 0
  %v112 = getelementptr i8, ptr %t28, i64 0
  %v113 = call i64 @wf_map_cost_hash(ptr %v101, ptr %v112)
  %t29 = getelementptr inbounds %wf.t.a5ea622fe32c85b6, ptr %v99, i32 0, i32 0
  %v114 = getelementptr i8, ptr %t29, i64 0
  %v115 = getelementptr i8, ptr %v114, i64 0
  %t31 = load ptr, ptr %v115
  %t32 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t31, i32 0, i32 0
  %t30 = load i64, ptr %t32
  %v116 = add i64 %t30, 0
  %v117 = select i1 true, i64 0, i64 0
  br label %bb24
bb22:
  br label %bb20
bb23:
  br label %bb21
bb24:
  %v118 = phi ptr [ %v99, %bb21 ], [ %v204, %bb34 ]
  %v119 = phi i64 [ %v100, %bb21 ], [ %v205, %bb34 ]
  %v120 = phi ptr [ %v101, %bb21 ], [ %v206, %bb34 ]
  %v121 = phi i64 [ %v102, %bb21 ], [ %v207, %bb34 ]
  %v122 = phi ptr [ %v103, %bb21 ], [ %v208, %bb34 ]
  %v123 = phi ptr [ %v104, %bb21 ], [ %v209, %bb34 ]
  %v125 = phi i64 [ %v106, %bb21 ], [ %v211, %bb34 ]
  %v127 = phi ptr [ %v108, %bb21 ], [ %v213, %bb34 ]
  %v129 = phi i64 [ %v113, %bb21 ], [ %v215, %bb34 ]
  %v130 = phi i64 [ %v116, %bb21 ], [ %v216, %bb34 ]
  %v131 = phi i64 [ %v117, %bb21 ], [ %v217, %bb34 ]
  %v132 = phi i64 [ %v116, %bb21 ], [ %v218, %bb34 ]
  %v133 = phi i64 [ %v117, %bb21 ], [ %v221, %bb34 ]
  %v147 = icmp ult i64 %v133, %v132
  switch i1 %v147, label %invalid.tag.b24 [
    i1 1, label %bb25
    i1 0, label %bb26
  ]
invalid.tag.b24:
  call void @abort()
  unreachable
bb25:
  %v148 = urem i64 %v129, %v130
  %v149 = call i64 @wf_hash_map.hash_map_probe(i64 %v148, i64 %v133, i64 %v130)
  %t33 = getelementptr inbounds %wf.t.a5ea622fe32c85b6, ptr %v118, i32 0, i32 0
  %v150 = getelementptr i8, ptr %t33, i64 0
  %v151 = getelementptr i8, ptr %v150, i64 0
  %t34 = load ptr, ptr %v151
  %t35.nonnegative = icmp sge i64 %v149, 0
  call void @llvm.assume(i1 %t35.nonnegative)
  %t35 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t34, i64 0, i32 2, i64 %v149
  %v152 = getelementptr i8, ptr %t35, i64 0
  %v153 = call i1 @wf_hash_map.hash_map_is_available$instance$d7a1a90c27bba449(ptr %v152)
  switch i1 %v153, label %invalid.tag.b25 [
    i1 1, label %bb29
    i1 0, label %bb30
  ]
invalid.tag.b25:
  call void @abort()
  unreachable
bb26:
  br label %bb27
bb27:
  %v134 = phi ptr [ %v118, %bb26 ], [ %v179, %bb31 ]
  %v135 = phi i64 [ %v119, %bb26 ], [ %v180, %bb31 ]
  %v136 = phi ptr [ %v120, %bb26 ], [ %v181, %bb31 ]
  %v137 = phi i64 [ %v121, %bb26 ], [ %v182, %bb31 ]
  %v138 = phi ptr [ %v122, %bb26 ], [ %v183, %bb31 ]
  %v139 = phi ptr [ %v123, %bb26 ], [ %v184, %bb31 ]
  %v141 = phi i64 [ %v125, %bb26 ], [ %v186, %bb31 ]
  %v143 = phi ptr [ %v127, %bb26 ], [ %v188, %bb31 ]
  %v145 = phi i64 [ %v129, %bb26 ], [ %v190, %bb31 ]
  %v146 = phi i64 [ %v130, %bb26 ], [ %v191, %bb31 ]
  br label %bb19
bb28:
  %v154 = phi ptr [ %v118, %bb30 ]
  %v155 = phi i64 [ %v119, %bb30 ]
  %v156 = phi ptr [ %v120, %bb30 ]
  %v157 = phi i64 [ %v121, %bb30 ]
  %v158 = phi ptr [ %v122, %bb30 ]
  %v159 = phi ptr [ %v123, %bb30 ]
  %v161 = phi i64 [ %v125, %bb30 ]
  %v163 = phi ptr [ %v127, %bb30 ]
  %v165 = phi i64 [ %v129, %bb30 ]
  %v166 = phi i64 [ %v130, %bb30 ]
  %v167 = phi i64 [ %v133, %bb30 ]
  %v168 = phi i64 [ %v148, %bb30 ]
  %v169 = phi i64 [ %v149, %bb30 ]
  %v170 = phi i1 [ %v153, %bb30 ]
  br label %bb34
bb29:
  call void @wf_take_back$instance$48adfc37250fbcc6(ptr %wf.slot.4, ptr %v127)
  %t36 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.4, i32 0, i32 0
  %v172 = load i64, ptr %t36
  ; ownership-consuming projection
  %t37 = getelementptr inbounds %wf.t.20dda3774c7510ec, ptr %wf.slot.4, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.5, ptr %t37, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %t38 = getelementptr inbounds %wf.t.a5ea622fe32c85b6, ptr %v118, i32 0, i32 0
  %v174 = getelementptr i8, ptr %t38, i64 0
  call void @wf_hash_map.hash_map_exchange$instance$d7a1a90c27bba449(ptr %wf.slot.6, ptr %v174, i64 %v149, i64 %v172, ptr %wf.slot.5)
  %v176 = call i64 @wf_hash_map.hash_map_control_fingerprint(i64 %v129)
  %t39 = getelementptr inbounds %wf.t.a5ea622fe32c85b6, ptr %v118, i32 0, i32 2
  %v177 = getelementptr i8, ptr %t39, i64 0
  %v178 = call i8 @wf_hash_map.hash_map_control_set(ptr %v177, i64 %v149, i64 %v176)
  %t40 = load %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.6
  %t41 = extractvalue %wf.t.9d321e1eb2ec1c03 %t40, 0
  switch i32 %t41, label %invalid.tag.b29 [
    i32 0, label %bb32
    i32 1, label %bb33
  ]
invalid.tag.b29:
  call void @abort()
  unreachable
bb30:
  br label %bb28
bb31:
  %v179 = phi ptr [ %v118, %bb32 ], [ %v118, %bb33 ]
  %v180 = phi i64 [ %v119, %bb32 ], [ %v119, %bb33 ]
  %v181 = phi ptr [ %v120, %bb32 ], [ %v120, %bb33 ]
  %v182 = phi i64 [ %v121, %bb32 ], [ %v121, %bb33 ]
  %v183 = phi ptr [ %v122, %bb32 ], [ %v122, %bb33 ]
  %v184 = phi ptr [ %v123, %bb32 ], [ %v123, %bb33 ]
  %v186 = phi i64 [ %v125, %bb32 ], [ %v125, %bb33 ]
  %v188 = phi ptr [ %v127, %bb32 ], [ %v127, %bb33 ]
  %v190 = phi i64 [ %v129, %bb32 ], [ %v129, %bb33 ]
  %v191 = phi i64 [ %v130, %bb32 ], [ %v130, %bb33 ]
  %v192 = phi i64 [ %v133, %bb32 ], [ %v133, %bb33 ]
  %v193 = phi i64 [ %v148, %bb32 ], [ %v148, %bb33 ]
  %v194 = phi i64 [ %v149, %bb32 ], [ %v149, %bb33 ]
  %v195 = phi i1 [ %v153, %bb32 ], [ %v153, %bb33 ]
  %v197 = phi i64 [ %v172, %bb32 ], [ %v172, %bb33 ]
  %v200 = phi i64 [ %v176, %bb32 ], [ %v176, %bb33 ]
  br label %bb27
bb32:
  br label %bb31
bb33:
  %t42 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.6, i32 0, i32 1
  %v201 = load i1, ptr %t42
  %t43 = getelementptr inbounds %wf.t.9d321e1eb2ec1c03, ptr %wf.slot.6, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.7, ptr %t43, i64 ptrtoint (ptr getelementptr (%wf.t.20dda3774c7510ec, ptr null, i32 1) to i64), i1 false)
  %v203 = call i8 @wf_place_back$instance$48adfc37250fbcc6(ptr %v127, ptr %wf.slot.7)
  br label %bb31
bb34:
  %v204 = phi ptr [ %v154, %bb28 ]
  %v205 = phi i64 [ %v155, %bb28 ]
  %v206 = phi ptr [ %v156, %bb28 ]
  %v207 = phi i64 [ %v157, %bb28 ]
  %v208 = phi ptr [ %v158, %bb28 ]
  %v209 = phi ptr [ %v159, %bb28 ]
  %v211 = phi i64 [ %v161, %bb28 ]
  %v213 = phi ptr [ %v163, %bb28 ]
  %v215 = phi i64 [ %v165, %bb28 ]
  %v216 = phi i64 [ %v166, %bb28 ]
  %v217 = phi i64 [ %v131, %bb28 ]
  %v218 = phi i64 [ %v132, %bb28 ]
  %v219 = phi i64 [ %v133, %bb28 ]
  %v220 = select i1 true, i64 1, i64 1
  %v221 = add i64 %v219, %v220
  br label %bb24
}

define %wf.t.7d7f918f7b4962fd @wf_hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07(ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.result = alloca %wf.t.7d7f918f7b4962fd, align 4
  call void @wf_hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07.body(ptr %wf.result, ptr %v0, i64 %v1, ptr %v2)
  %wf.returned = load %wf.t.7d7f918f7b4962fd, ptr %wf.result
  ret %wf.t.7d7f918f7b4962fd %wf.returned
}

define void @wf_slots_new$instance$7445cefb96d3b406(ptr %wf.result) #0 {
entry:
  store { i64, [1 x %wf.t.20dda3774c7510ec] } zeroinitializer, ptr %wf.result
  ret void
}

define i1 @wf_hash_map.hash_map_is_available$instance$d7a1a90c27bba449(ptr noalias nonnull captures(none) dereferenceable(272) %v0) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.e04aead91f34a68f, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.e04aead91f34a68f, ptr null, i32 1) to i64), i1 false)
  %t0 = load %wf.t.e04aead91f34a68f, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.e04aead91f34a68f %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb1
    i32 1, label %bb2
    i32 2, label %bb3
  ]
invalid.tag.b0:
  call void @abort()
  unreachable
bb1:
  %v2 = select i1 true, i1 1, i1 1
  ret i1 %v2
bb2:
  %v3 = select i1 true, i1 1, i1 1
  ret i1 %v3
bb3:
  %t2 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %v0, i32 0, i32 1
  %v4 = getelementptr i8, ptr %t2, i64 0
  %t3 = getelementptr inbounds %wf.t.e04aead91f34a68f, ptr %v0, i32 0, i32 2
  %v5 = getelementptr i8, ptr %t3, i64 0
  %v6 = select i1 true, i1 0, i1 0
  ret i1 %v6
}

define internal void @wf_take_back$instance$20364da1adbcdc5f.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(8) %v0) #0 {
entry:
  %t1 = load ptr, ptr %v0
  %t2 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t1, i32 0, i32 0
  %t0 = load i64, ptr %t2
  %t3 = sub i64 %t0, 1
  %t4 = load ptr, ptr %v0
  %t5.nonnegative = icmp sge i64 %t3, 0
  call void @llvm.assume(i1 %t5.nonnegative)
  %t5 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t4, i64 0, i32 2, i64 %t3
  %t7 = load ptr, ptr %v0
  %t8 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t7, i32 0, i32 0
  %t6 = load i64, ptr %t8
  %t9 = sub i64 %t6, 1
  %t10 = load ptr, ptr %v0
  %t11 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t10, i32 0, i32 0
  store i64 %t9, ptr %t11
  call void @llvm.memmove.p0.p0.i64(ptr %wf.result, ptr %t5, i64 ptrtoint (ptr getelementptr (%wf.t.eb423fc38cfed56f, ptr null, i32 1) to i64), i1 false)
  ret void
}

define %wf.t.eb423fc38cfed56f @wf_take_back$instance$20364da1adbcdc5f(ptr noalias nonnull captures(none) dereferenceable(8) %v0) #0 {
entry:
  %wf.result = alloca %wf.t.eb423fc38cfed56f, align 8
  call void @wf_take_back$instance$20364da1adbcdc5f.body(ptr %wf.result, ptr %v0)
  %wf.returned = load %wf.t.eb423fc38cfed56f, ptr %wf.result
  ret %wf.t.eb423fc38cfed56f %wf.returned
}

define i8 @wf_free_empty$instance$fd33b528f0517054(ptr %v0) #0 {
entry:
  call void @free(ptr %v0)
  %v1 = select i1 true, i8 0, i8 0
  %v2 = select i1 true, i8 0, i8 0
  ret i8 %v2
}

define i8 @wf_swap$instance$087f541e70b769ea(ptr nonnull captures(none) dereferenceable(24) %v0, ptr nonnull captures(none) dereferenceable(24) %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.eb423fc38cfed56f, align 8
  %wf.slot.1 = alloca %wf.t.eb423fc38cfed56f, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.eb423fc38cfed56f, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %wf.slot.1, ptr %v1, i64 ptrtoint (ptr getelementptr (%wf.t.eb423fc38cfed56f, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %v0, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr (%wf.t.eb423fc38cfed56f, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %v1, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.eb423fc38cfed56f, ptr null, i32 1) to i64), i1 false)
  %v4 = select i1 true, i8 0, i8 0
  ret i8 %v4
}

define void @wf_take_back$instance$2af1311599ac146a(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(8) %v0) #0 {
entry:
  %t1 = load ptr, ptr %v0
  %t2 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t1, i32 0, i32 0
  %t0 = load i64, ptr %t2
  %t3 = sub i64 %t0, 1
  %t4 = load ptr, ptr %v0
  %t5.nonnegative = icmp sge i64 %t3, 0
  call void @llvm.assume(i1 %t5.nonnegative)
  %t5 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t4, i64 0, i32 2, i64 %t3
  %t7 = load ptr, ptr %v0
  %t8 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t7, i32 0, i32 0
  %t6 = load i64, ptr %t8
  %t9 = sub i64 %t6, 1
  %t10 = load ptr, ptr %v0
  %t11 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t10, i32 0, i32 0
  store i64 %t9, ptr %t11
  call void @llvm.memmove.p0.p0.i64(ptr %wf.result, ptr %t5, i64 ptrtoint (ptr getelementptr (%wf.t.e04aead91f34a68f, ptr null, i32 1) to i64), i1 false)
  ret void
}

define i8 @wf_free_empty$instance$1b41cffa653e924b(ptr %v0) #0 {
entry:
  call void @free(ptr %v0)
  %v1 = select i1 true, i8 0, i8 0
  %v2 = select i1 true, i8 0, i8 0
  ret i8 %v2
}

define i8 @wf_swap$instance$b1cfa6e689dc9e10(ptr nonnull captures(none) dereferenceable(272) %v0, ptr nonnull captures(none) dereferenceable(272) %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.e04aead91f34a68f, align 8
  %wf.slot.1 = alloca %wf.t.e04aead91f34a68f, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.e04aead91f34a68f, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %wf.slot.1, ptr %v1, i64 ptrtoint (ptr getelementptr (%wf.t.e04aead91f34a68f, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %v0, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr (%wf.t.e04aead91f34a68f, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %v1, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.e04aead91f34a68f, ptr null, i32 1) to i64), i1 false)
  %v4 = select i1 true, i8 0, i8 0
  ret i8 %v4
}

define i8 @wf_grow$instance$087f541e70b769ea(ptr noalias nonnull captures(none) dereferenceable(8) %v0, i64 %v1) #0 {
entry:
  %t0 = load ptr, ptr %v0
  %t1 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t0, i32 0, i32 0
  %t2 = load i64, ptr %t1
  %t3 = mul nuw i64 %v1, ptrtoint (ptr getelementptr (%wf.t.eb423fc38cfed56f, ptr null, i64 1) to i64)
  %t4 = add nuw i64 %t3, ptrtoint (ptr getelementptr ({ i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr null, i64 0, i32 2) to i64)
  %t5 = call ptr @malloc(i64 %t4)
  %t6 = icmp ne ptr %t5, null
  br i1 %t6, label %window.block.ready.v2, label %window.block.oom.v2
window.block.oom.v2:
  call void @wf_resource_abort()
  unreachable
window.block.ready.v2:
  %t7 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t5, i32 0, i32 0
  store i64 %t2, ptr %t7
  %t8 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t5, i32 0, i32 1
  store i64 %v1, ptr %t8
  %t9 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t0, i64 0, i32 2, i64 0
  %t10 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t5, i64 0, i32 2, i64 0
  %t11 = mul nuw i64 %t2, ptrtoint (ptr getelementptr (%wf.t.eb423fc38cfed56f, ptr null, i64 1) to i64)
  call void @llvm.memmove.p0.p0.i64(ptr %t10, ptr %t9, i64 %t11, i1 false)
  call void @free(ptr %t0)
  store ptr %t5, ptr %v0
  %v2 = select i1 true, i8 0, i8 0
  %v3 = select i1 true, i8 0, i8 0
  ret i8 %v3
}

define i8 @wf_place_back$instance$20364da1adbcdc5f(ptr noalias nonnull captures(none) dereferenceable(8) %v0, ptr %wf.arg.v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.eb423fc38cfed56f, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v1, i64 ptrtoint (ptr getelementptr (%wf.t.eb423fc38cfed56f, ptr null, i32 1) to i64), i1 false)
  %t1 = load ptr, ptr %v0
  %t2 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t1, i32 0, i32 0
  %t0 = load i64, ptr %t2
  %t3 = load ptr, ptr %v0
  %t4.nonnegative = icmp sge i64 %t0, 0
  call void @llvm.assume(i1 %t4.nonnegative)
  %t4 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t3, i64 0, i32 2, i64 %t0
  call void @llvm.memmove.p0.p0.i64(ptr %t4, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.eb423fc38cfed56f, ptr null, i32 1) to i64), i1 false)
  %t6 = load ptr, ptr %v0
  %t7 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t6, i32 0, i32 0
  %t5 = load i64, ptr %t7
  %t8 = add i64 %t5, 1
  %t9 = load ptr, ptr %v0
  %t10 = getelementptr inbounds { i64, i64, [0 x %wf.t.eb423fc38cfed56f] }, ptr %t9, i32 0, i32 0
  store i64 %t8, ptr %t10
  %v2 = select i1 true, i8 0, i8 0
  ret i8 %v2
}

define i8 @wf_place_back$instance$38dd27730d5cd43b(ptr noalias nonnull captures(none) dereferenceable(16) %v0, ptr %v1) #0 {
entry:
  %t1 = getelementptr inbounds { i64, [1 x ptr] }, ptr %v0, i32 0, i32 0
  %t0 = load i64, ptr %t1
  %t2.nonnegative = icmp sge i64 %t0, 0
  call void @llvm.assume(i1 %t2.nonnegative)
  %t2 = getelementptr inbounds { i64, [1 x ptr] }, ptr %v0, i64 0, i32 1, i64 %t0
  store ptr %v1, ptr %t2
  %t4 = getelementptr inbounds { i64, [1 x ptr] }, ptr %v0, i32 0, i32 0
  %t3 = load i64, ptr %t4
  %t5 = add i64 %t3, 1
  %t6 = getelementptr inbounds { i64, [1 x ptr] }, ptr %v0, i32 0, i32 0
  store i64 %t5, ptr %t6
  %v2 = select i1 true, i8 0, i8 0
  ret i8 %v2
}

define i8 @wf_swap$instance$fd33b528f0517054(ptr nonnull captures(none) dereferenceable(8) %v0, ptr nonnull captures(none) dereferenceable(8) %v1) #0 {
entry:
  %v2 = load ptr, ptr %v0
  %v3 = load ptr, ptr %v1
  store ptr %v3, ptr %v0
  store ptr %v2, ptr %v1
  %v4 = select i1 true, i8 0, i8 0
  ret i8 %v4
}

define i8 @wf_swap$instance$d89c7f330eeb5a04(ptr nonnull captures(none) dereferenceable(24) %v0, ptr nonnull captures(none) dereferenceable(24) %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.b5efdacbe94e5739, align 8
  %wf.slot.1 = alloca %wf.t.b5efdacbe94e5739, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.b5efdacbe94e5739, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %wf.slot.1, ptr %v1, i64 ptrtoint (ptr getelementptr (%wf.t.b5efdacbe94e5739, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %v0, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr (%wf.t.b5efdacbe94e5739, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %v1, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.b5efdacbe94e5739, ptr null, i32 1) to i64), i1 false)
  %v4 = select i1 true, i8 0, i8 0
  ret i8 %v4
}

define i8 @wf_place_back$instance$22267f8259e51fb5(ptr noalias nonnull captures(none) dereferenceable(24) %v0, ptr %wf.arg.v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.09071440a409e980, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v1, i64 ptrtoint (ptr getelementptr (%wf.t.09071440a409e980, ptr null, i32 1) to i64), i1 false)
  %t1 = getelementptr inbounds { i64, [1 x %wf.t.09071440a409e980] }, ptr %v0, i32 0, i32 0
  %t0 = load i64, ptr %t1
  %t2.nonnegative = icmp sge i64 %t0, 0
  call void @llvm.assume(i1 %t2.nonnegative)
  %t2 = getelementptr inbounds { i64, [1 x %wf.t.09071440a409e980] }, ptr %v0, i64 0, i32 1, i64 %t0
  call void @llvm.memmove.p0.p0.i64(ptr %t2, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.09071440a409e980, ptr null, i32 1) to i64), i1 false)
  %t4 = getelementptr inbounds { i64, [1 x %wf.t.09071440a409e980] }, ptr %v0, i32 0, i32 0
  %t3 = load i64, ptr %t4
  %t5 = add i64 %t3, 1
  %t6 = getelementptr inbounds { i64, [1 x %wf.t.09071440a409e980] }, ptr %v0, i32 0, i32 0
  store i64 %t5, ptr %t6
  %v2 = select i1 true, i8 0, i8 0
  ret i8 %v2
}

define internal void @wf_take_back$instance$22267f8259e51fb5.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(24) %v0) #0 {
entry:
  %t1 = getelementptr inbounds { i64, [1 x %wf.t.09071440a409e980] }, ptr %v0, i32 0, i32 0
  %t0 = load i64, ptr %t1
  %t2 = sub i64 %t0, 1
  %t3.nonnegative = icmp sge i64 %t2, 0
  call void @llvm.assume(i1 %t3.nonnegative)
  %t3 = getelementptr inbounds { i64, [1 x %wf.t.09071440a409e980] }, ptr %v0, i64 0, i32 1, i64 %t2
  %t5 = getelementptr inbounds { i64, [1 x %wf.t.09071440a409e980] }, ptr %v0, i32 0, i32 0
  %t4 = load i64, ptr %t5
  %t6 = sub i64 %t4, 1
  %t7 = getelementptr inbounds { i64, [1 x %wf.t.09071440a409e980] }, ptr %v0, i32 0, i32 0
  store i64 %t6, ptr %t7
  call void @llvm.memmove.p0.p0.i64(ptr %wf.result, ptr %t3, i64 ptrtoint (ptr getelementptr (%wf.t.09071440a409e980, ptr null, i32 1) to i64), i1 false)
  ret void
}

define %wf.t.09071440a409e980 @wf_take_back$instance$22267f8259e51fb5(ptr noalias nonnull captures(none) dereferenceable(24) %v0) #0 {
entry:
  %wf.result = alloca %wf.t.09071440a409e980, align 8
  call void @wf_take_back$instance$22267f8259e51fb5.body(ptr %wf.result, ptr %v0)
  %wf.returned = load %wf.t.09071440a409e980, ptr %wf.result
  ret %wf.t.09071440a409e980 %wf.returned
}

define i8 @wf_free_empty$instance$b7fb76652ce23509(ptr %wf.arg.v0) #0 {
entry:
  %wf.slot.0 = alloca { i64, [1 x %wf.t.09071440a409e980] }, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v0, i64 ptrtoint (ptr getelementptr ({ i64, [1 x %wf.t.09071440a409e980] }, ptr null, i32 1) to i64), i1 false)
  %v1 = select i1 true, i8 0, i8 0
  ret i8 %v1
}

define i8 @wf_grow$instance$b1cfa6e689dc9e10(ptr noalias nonnull captures(none) dereferenceable(8) %v0, i64 %v1) #0 {
entry:
  %t0 = load ptr, ptr %v0
  %t1 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t0, i32 0, i32 0
  %t2 = load i64, ptr %t1
  %t3 = mul nuw i64 %v1, ptrtoint (ptr getelementptr (%wf.t.e04aead91f34a68f, ptr null, i64 1) to i64)
  %t4 = add nuw i64 %t3, ptrtoint (ptr getelementptr ({ i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr null, i64 0, i32 2) to i64)
  %t5 = call ptr @malloc(i64 %t4)
  %t6 = icmp ne ptr %t5, null
  br i1 %t6, label %window.block.ready.v2, label %window.block.oom.v2
window.block.oom.v2:
  call void @wf_resource_abort()
  unreachable
window.block.ready.v2:
  %t7 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t5, i32 0, i32 0
  store i64 %t2, ptr %t7
  %t8 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t5, i32 0, i32 1
  store i64 %v1, ptr %t8
  %t9 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t0, i64 0, i32 2, i64 0
  %t10 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t5, i64 0, i32 2, i64 0
  %t11 = mul nuw i64 %t2, ptrtoint (ptr getelementptr (%wf.t.e04aead91f34a68f, ptr null, i64 1) to i64)
  call void @llvm.memmove.p0.p0.i64(ptr %t10, ptr %t9, i64 %t11, i1 false)
  call void @free(ptr %t0)
  store ptr %t5, ptr %v0
  %v2 = select i1 true, i8 0, i8 0
  %v3 = select i1 true, i8 0, i8 0
  ret i8 %v3
}

define i8 @wf_place_back$instance$2af1311599ac146a(ptr noalias nonnull captures(none) dereferenceable(8) %v0, ptr %wf.arg.v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.e04aead91f34a68f, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v1, i64 ptrtoint (ptr getelementptr (%wf.t.e04aead91f34a68f, ptr null, i32 1) to i64), i1 false)
  %t1 = load ptr, ptr %v0
  %t2 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t1, i32 0, i32 0
  %t0 = load i64, ptr %t2
  %t3 = load ptr, ptr %v0
  %t4.nonnegative = icmp sge i64 %t0, 0
  call void @llvm.assume(i1 %t4.nonnegative)
  %t4 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t3, i64 0, i32 2, i64 %t0
  call void @llvm.memmove.p0.p0.i64(ptr %t4, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.e04aead91f34a68f, ptr null, i32 1) to i64), i1 false)
  %t6 = load ptr, ptr %v0
  %t7 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t6, i32 0, i32 0
  %t5 = load i64, ptr %t7
  %t8 = add i64 %t5, 1
  %t9 = load ptr, ptr %v0
  %t10 = getelementptr inbounds { i64, i64, [0 x %wf.t.e04aead91f34a68f] }, ptr %t9, i32 0, i32 0
  store i64 %t8, ptr %t10
  %v2 = select i1 true, i8 0, i8 0
  ret i8 %v2
}

define i8 @wf_swap$instance$1b41cffa653e924b(ptr nonnull captures(none) dereferenceable(8) %v0, ptr nonnull captures(none) dereferenceable(8) %v1) #0 {
entry:
  %v2 = load ptr, ptr %v0
  %v3 = load ptr, ptr %v1
  store ptr %v3, ptr %v0
  store ptr %v2, ptr %v1
  %v4 = select i1 true, i8 0, i8 0
  ret i8 %v4
}

define i8 @wf_place_back$instance$48adfc37250fbcc6(ptr noalias nonnull captures(none) dereferenceable(272) %v0, ptr %wf.arg.v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.20dda3774c7510ec, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v1, i64 ptrtoint (ptr getelementptr (%wf.t.20dda3774c7510ec, ptr null, i32 1) to i64), i1 false)
  %t1 = getelementptr inbounds { i64, [1 x %wf.t.20dda3774c7510ec] }, ptr %v0, i32 0, i32 0
  %t0 = load i64, ptr %t1
  %t2.nonnegative = icmp sge i64 %t0, 0
  call void @llvm.assume(i1 %t2.nonnegative)
  %t2 = getelementptr inbounds { i64, [1 x %wf.t.20dda3774c7510ec] }, ptr %v0, i64 0, i32 1, i64 %t0
  call void @llvm.memmove.p0.p0.i64(ptr %t2, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.20dda3774c7510ec, ptr null, i32 1) to i64), i1 false)
  %t4 = getelementptr inbounds { i64, [1 x %wf.t.20dda3774c7510ec] }, ptr %v0, i32 0, i32 0
  %t3 = load i64, ptr %t4
  %t5 = add i64 %t3, 1
  %t6 = getelementptr inbounds { i64, [1 x %wf.t.20dda3774c7510ec] }, ptr %v0, i32 0, i32 0
  store i64 %t5, ptr %t6
  %v2 = select i1 true, i8 0, i8 0
  ret i8 %v2
}

define void @wf_take_back$instance$48adfc37250fbcc6(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(272) %v0) #0 {
entry:
  %t1 = getelementptr inbounds { i64, [1 x %wf.t.20dda3774c7510ec] }, ptr %v0, i32 0, i32 0
  %t0 = load i64, ptr %t1
  %t2 = sub i64 %t0, 1
  %t3.nonnegative = icmp sge i64 %t2, 0
  call void @llvm.assume(i1 %t3.nonnegative)
  %t3 = getelementptr inbounds { i64, [1 x %wf.t.20dda3774c7510ec] }, ptr %v0, i64 0, i32 1, i64 %t2
  %t5 = getelementptr inbounds { i64, [1 x %wf.t.20dda3774c7510ec] }, ptr %v0, i32 0, i32 0
  %t4 = load i64, ptr %t5
  %t6 = sub i64 %t4, 1
  %t7 = getelementptr inbounds { i64, [1 x %wf.t.20dda3774c7510ec] }, ptr %v0, i32 0, i32 0
  store i64 %t6, ptr %t7
  call void @llvm.memmove.p0.p0.i64(ptr %wf.result, ptr %t3, i64 ptrtoint (ptr getelementptr (%wf.t.20dda3774c7510ec, ptr null, i32 1) to i64), i1 false)
  ret void
}

define i8 @wf_free_empty$instance$d97c759d7de32f56(ptr %wf.arg.v0) #0 {
entry:
  %wf.slot.0 = alloca { i64, [1 x %wf.t.20dda3774c7510ec] }, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v0, i64 ptrtoint (ptr getelementptr ({ i64, [1 x %wf.t.20dda3774c7510ec] }, ptr null, i32 1) to i64), i1 false)
  %v1 = select i1 true, i8 0, i8 0
  ret i8 %v1
}


attributes #0 = { "probe-stack"="__chkstk_darwin" }
define weak i32 @wf__floor_run(i32 %argc, ptr %argv) #0 {
entry:
  %status = call i32 @wf__main_body(i32 %argc, ptr %argv) noinline
  ret i32 %status
}


declare i8 @wf__ordinary_exit_code(ptr)

define i32 @wf__main_body(i32 %argc, ptr %argv) #0 {
entry:
  %status = alloca { i128, i128 }, align 16
  call void @"wf_carrier_main"(ptr %status)
  %code = call i8 @wf__ordinary_exit_code(ptr %status)
  %exit = zext i8 %code to i32
  ret i32 %exit
}

define i32 @main(i32 %argc, ptr %argv) #0 {
entry:
  %status = call i32 @wf__floor_run(i32 %argc, ptr %argv)
  ret i32 %status
}
