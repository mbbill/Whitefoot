"""One-shot compiler-independent arithmetic oracle for this scratch candidate.

It checks the packed expression against eight independent byte comparisons.
It does not establish acceptance or native correctness of the WF source.
Retire it with this experiment's scratch preparation.
"""
MASK = (1 << 64) - 1
LOW = 0x7f7f7f7f7f7f7f7f
HIGH = 0x8080808080808080
REPEAT = 0x0101010101010101
CODES = (0, 1, 127, 128, 254)


def packed(word, code):
    different = word ^ ((code * REPEAT) & MASK)
    lower = different & LOW
    nonzero = (lower + LOW) & MASK
    return (~(nonzero | different | LOW)) & HIGH


def expected(word, code):
    answer = 0
    for lane in range(8):
        if ((word >> (lane * 8)) & 255) == code:
            answer |= 128 << (lane * 8)
    return answer


checks = 0
for background in (0, 1, 127, 128, 254, 255):
    base = background * REPEAT
    for lane in range(8):
        other = base & ~(255 << (lane * 8))
        for byte in range(256):
            word = other | (byte << (lane * 8))
            for code in range(256):
                assert packed(word, code) == expected(word, code), (word, code)
                checks += 1

for lane in range(7):
    # All 65,536 adjacent-byte patterns expose any possible carry interaction.
    for pair in range(65536):
        word = pair << (lane * 8)
        for code in CODES:
            assert packed(word, code) == expected(word, code), (word, code)
            checks += 1

# Meaningful faults: dropping the original-byte high-bit term confuses 0x80
# with zero; subtraction-based zero detection admits a neighboring false bit.
wrong_high = (~((((0x80 & LOW) + LOW) & MASK) | LOW)) & HIGH
assert wrong_high != expected(0x80, 0)
wrong_borrow = ((0x0100 - REPEAT) & MASK) & (~0x0100) & HIGH
assert wrong_borrow != expected(0x0100, 0)
print(f"packed-mask independent byte comparisons: {checks}; both fault controls rejected")
