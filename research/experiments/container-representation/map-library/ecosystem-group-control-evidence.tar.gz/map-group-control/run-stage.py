from pathlib import Path
from datetime import datetime, timezone
import json, subprocess, sys, time
root=Path("/private/tmp/whitefoot-container-library-complete")
scratch=Path("/private/tmp/whitefoot-map-group-control-7abd6bb")
label=sys.argv[1]
argv=sys.argv[2:]
log=scratch/"logs"/(label+".log")
if log.exists():raise SystemExit("Refusing to overwrite stage log: "+str(log))
started=datetime.now(timezone.utc).isoformat();before=time.monotonic()
with log.open("w") as out:
 result=subprocess.run(argv,cwd=root,stdout=out,stderr=subprocess.STDOUT)
record={"label":label,"argv":argv,"cwd":str(root),"started_utc":started,"ended_utc":datetime.now(timezone.utc).isoformat(),"wall_seconds":time.monotonic()-before,"exit_code":result.returncode,"log":str(log)}
with (scratch/"stages.jsonl").open("a") as out:out.write(json.dumps(record)+"\n")
print(json.dumps(record),flush=True)
print(log.read_text()[-18000:],flush=True)
raise SystemExit(result.returncode)
