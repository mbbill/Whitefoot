"""One-shot native-body comparison; delete with the Map carrier preparation.
Includes instructions, callee symbols, CFI and per-function constant pools.
Only explicit nominal symbol mapping and assembler-local numbering differ.
"""
from pathlib import Path
import difflib,json,re,sys,hashlib
root=Path('/private/tmp/whitefoot-map-group-control-7abd6bb/native')
a=(root/'original.s').read_text(); b=(root/'baseline.s').read_text()
names=json.loads((root/'baseline-raw-qualification.json').read_text())['symbol_renaming']
names={k[1:]:v[1:] for k,v in names.items()}
pattern=re.compile(r'^[^\n]*; -- Begin function (\S+)\n.*?^\s*; -- End function[^\n]*\n',re.M|re.S)
def functions(text):
 return {m.group(1):m.group() for m in pattern.finditer(text)}
old,new=functions(a),functions(b)
def canonical(text,rename):
 lines=[line.split(';',1)[0].strip() for line in text.splitlines()]
 text='\n'.join(x for x in lines if x)
 if rename:
  for first,second in sorted(names.items(),key=lambda x:len(x[0]),reverse=True):
   text=re.sub(r'(?<![A-Za-z0-9.$])'+re.escape(first)+r'(?![A-Za-z0-9_.$])',lambda m:second,text)
   # Native references prefix every compiler symbol with an underscore.
   text=re.sub(r'(?<![A-Za-z0-9.$])_'+re.escape(first)+r'(?![A-Za-z0-9_.$])',lambda m:'_'+second,text)
 text=re.sub(r'\bLBB\d+_', 'LBB_',text)
 text=re.sub(r'\blCPI\d+_', 'lCPI_',text)
 local={name:'Lloh'+str(i) for i,name in enumerate(dict.fromkeys(re.findall(r'\bLloh\d+\b',text)))}
 text=re.sub(r'\bLloh\d+\b',lambda m:local[m.group()],text)
 return text
excluded={'wf__floor_run','wf__main_body','wf_fixture_main'}
compared=[]; differences=[]
for name,body in old.items():
 if name in excluded:continue
 mapped=names.get(name,name)
 assert mapped in new,('missing native body',name,mapped)
 first,second=canonical(body,True),canonical(new[mapped],False)
 if first!=second:
  differences.append({'original':name,'carrier':mapped,'diff':''.join(difflib.unified_diff(first.splitlines(True),second.splitlines(True),fromfile=name,tofile=mapped))})
 else:compared.append(name)
extra=set(new)-{names.get(name,name) for name in old}
assert extra=={'wf_carrier_main'},('unexpected native definitions',sorted(extra))
report={'original_sha256':hashlib.sha256(a.encode()).hexdigest(),'carrier_sha256':hashlib.sha256(b.encode()).hexdigest(),'native_functions_equal':compared,'native_differences':differences,'extra_functions':sorted(extra),'excluded_entry_plumbing':sorted(excluded),'normalization':'Explicit raw-IR symbol bijection; assembler-local function/Lloh ordinals only. Instructions, branches, constants, CFI and callee identity remain exact.'}
p=root/'baseline-native-qualification.json';assert not p.exists();p.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'equal':len(compared),'differences':len(differences),'extra':sorted(extra)}))
for difference in differences[:4]:print(difference['diff'][:8000])
raise SystemExit(bool(differences))
