from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess
import sys
import time

BASE = Path(__file__).parent
OUT = BASE / 'controls-runtime'
NATIVE = BASE / 'native'
CLEAN = Path('<broad-root>')
OLD = Path('<retained-whitefoot-map-occupancy-7abd6bb>')
VECTOR = Path('<retained-whitefoot-vector-source-controller>/continuation/native-inputs.json')
STAGE = sys.argv[1]
ENV = dict(os.environ)
ENV.pop('WF_WORKERS', None)
RUNTIME_NAMES = ['ordinary_values', 'sched/core', 'sched/entry', 'completion/runtime',
                 'completion/file_adapter', 'completion/bridge', 'wf_floor',
                 'sched/prim_host', 'completion/wait_host', 'completion/file_posix',
                 'completion/linux_io_uring', 'ordinary_values_ir']
RUNTIME = [OLD / 'build/native' / (name + '.o') for name in RUNTIME_NAMES]
CONFIG = (OLD / 'build/ecosystem/configuration.txt').read_text().splitlines()
PEERS = [OLD / 'build/ecosystem' / name for name in ['driver-account.o', 'rust-account.a', 'cpp-account.o']]
RETAINED_CONTROL = CLEAN / 'controls/map-control-retained-account.o'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(label, command, expected=0, stdout=None, stderr=None, kind='construction'):
    assert not (OUT / (label + '.stdout')).exists(), label
    command = list(map(str, command))
    start = time.monotonic()
    result = subprocess.run(command, cwd=BASE / 'source', env=ENV, capture_output=True, text=True)
    record = {'label': label, 'kind': kind, 'command': command, 'exit': result.returncode,
              'expected_exit': expected, 'seconds': time.monotonic() - start}
    (OUT / (label + '.stdout')).write_text(result.stdout)
    (OUT / (label + '.stderr')).write_text(result.stderr)
    with (OUT / 'stages.jsonl').open('a') as stream:
        stream.write(json.dumps(record) + '\n')
    print(json.dumps(record), flush=True)
    assert result.returncode == expected, (label, result.stdout, result.stderr)
    if stdout is not None:
        assert result.stdout == stdout, (label, result.stdout, stdout)
    if stderr is not None:
        assert result.stderr == stderr, (label, result.stderr, stderr)
    return result.stdout


if STAGE == 'freeze':
    OUT.mkdir(exist_ok=False)
    paths = [Path(__file__), BASE / 'whitefootc', BASE / 'native-artifacts.json',
             BASE / 'retention-before.json', VECTOR, *RUNTIME, *PEERS, RETAINED_CONTROL,
             OLD / 'build/ecosystem/configuration.txt']
    for family in ['slab', 'vector']:
        for mode in ['normal', 'retained']:
            paths += [CLEAN / 'controls' / f'{family}-control-{mode}.o']
            paths += [NATIVE / f'{family}-{mode}-{arm}.s' for arm in ['a', 'c']]
    paths += [NATIVE / f'vector-ecosystem-{arm}.s' for arm in ['a', 'c']]
    vector = json.loads(VECTOR.read_text())
    paths += [Path(path) for path in vector['link_commands']['timed']['unchanged_inputs']]
    paths += [NATIVE / f'map-retained-{arm}{suffix}' for arm in ['a', 'c'] for suffix in ['', '.ll']]
    paths += [OLD / 'build/ecosystem' / name for name in ['accounting.csv', 'occupancy-accounting.csv', 'geometry.csv']]
    old_runtime = CLEAN / 'runtime-attempt-2'
    paths += [old_runtime / 'stages.jsonl']
    rows = [json.loads(line) for line in (old_runtime / 'stages.jsonl').read_text().splitlines()]
    for origin in ['occupancy', 'projection']:
        faults = [row for row in rows if row['label'].startswith(origin + '-normal-fault-')]
        assert len(faults) == 17
        paths += [old_runtime / (row['label'] + '.stderr') for row in faults]
    pins = {str(path): digest(path) for path in paths}
    assert pins[str(BASE / 'whitefootc')] == '5f36879094dd1cc2531989af7b80ef30282dda70ea0229dec9200d438d264e33'
    (OUT / 'inputs-before.json').write_text(json.dumps(pins, indent=2) + '\n')
    print(json.dumps({'frozen_inputs': len(pins)}))
    sys.exit(0)

pins = json.loads((OUT / 'inputs-before.json').read_text())
assert all(digest(Path(path)) == expected for path, expected in pins.items())
if STAGE == 'construct':
    for family in ['slab', 'vector']:
        for mode in ['normal', 'retained']:
            for arm in ['a', 'c']:
                stem = f'{family}-{mode}-{arm}'
                obj = OUT / (stem + '.o')
                run(stem + '-object', ['/usr/bin/clang', '-c', '-x', 'assembler', NATIVE / (stem + '.s'), '-o', obj])
                run(stem + '-link', ['/usr/bin/clang', '-O2', CLEAN / 'controls' / f'{family}-control-{mode}.o', obj, *RUNTIME, '-pthread', '-lm', '-o', OUT / stem])
    for arm in ['a', 'c']:
        stem = f'vector-ecosystem-{arm}'
        obj = OUT / (stem + '.o')
        run(stem + '-object', ['/usr/bin/clang', '-c', '-x', 'assembler', NATIVE / (stem + '.s'), '-o', obj])
        command = json.loads(VECTOR.read_text())['link_commands']['timed']['command']
        command[3] = str(obj)
        command[-1] = str(OUT / stem)
        run(stem + '-link', command)
        stem = f'map-retained-{arm}-account'
        llvm = (NATIVE / f'map-retained-{arm}.ll').read_text()
        assert '@malloc(' in llvm and '@free(' in llvm and '@main(' not in llvm
        llvm = llvm.replace('@malloc(', '@wf_cost_allocate(').replace('@free(', '@wf_cost_release(')
        path = OUT / (stem + '.ll')
        path.write_text(llvm)
        obj = OUT / (stem + '.o')
        run(stem + '-object', ['/usr/bin/clang', '-O3', '-Wno-override-module', '-c', path, '-o', obj])
        run(stem + '-link', ['/usr/bin/clang++', *shlex.split(CONFIG[11]), PEERS[0], obj, *PEERS[1:], RETAINED_CONTROL, *RUNTIME, *shlex.split(CONFIG[16]), *shlex.split(CONFIG[12]), '-pthread', '-lm', '-o', OUT / stem])
    artifacts = {str(path): digest(path) for path in OUT.iterdir()
                 if path.suffix in ['.ll', '.o'] or (path.is_file() and os.access(path, os.X_OK))}
    (OUT / 'artifacts-before-execution.json').write_text(json.dumps(artifacts, indent=2) + '\n')
elif STAGE == 'execute':
    artifacts = json.loads((OUT / 'artifacts-before-execution.json').read_text())
    assert all(digest(Path(path)) == expected for path, expected in artifacts.items())
    for family in ['slab', 'vector']:
        for mode in ['normal', 'retained']:
            for arm in ['a', 'c']:
                stem = f'{family}-{mode}-{arm}'
                expected = ('slab library costs: 288 configurations, 864 executions passed\n' if family == 'slab'
                            else 'vector library costs: 1260 five-way configurations, 6300 executions passed\n')
                run(stem + '-check', [OUT / stem, 'check'], kind='execution', stdout=expected, stderr='')
    for arm in ['a', 'c']:
        stem = f'vector-ecosystem-{arm}'
        run(stem + '-check', [OUT / stem, 'check'], kind='execution', stdout='vector ecosystem: 1260 configurations, 8820 executions passed\n', stderr='')
        stem = f'map-retained-{arm}'
        for kind, image in [('timed', NATIVE / stem), ('account', OUT / (stem + '-account'))]:
            run(stem + '-' + kind + '-check', [image, 'check'], kind='execution', stdout='map ecosystem: 18390 oracle-checked traces passed\n', stderr='')
            run(stem + '-' + kind + '-occupancy-check', [image, 'occupancy-check'], kind='execution', stdout='map occupancy: 1440 oracle-checked traces passed\n', stderr='')
        account = OUT / (stem + '-account')
        run(stem + '-geometry-check', [account, 'geometry-check'], kind='execution', stdout='map geometry: 140 filled-map observations passed\n', stderr='')
        for command, args, filename in [('account', ['262144'], 'accounting.csv'), ('occupancy-account', ['1048576'], 'occupancy-accounting.csv'), ('geometry', [], 'geometry.csv')]:
            run(stem + '-' + command, [account, command, *args], kind='execution', stdout=(OLD / 'build/ecosystem' / filename).read_text(), stderr='')
        old_runtime = CLEAN / 'runtime-attempt-2'
        rows = [json.loads(line) for line in (old_runtime / 'stages.jsonl').read_text().splitlines()]
        origin = 'occupancy' if arm == 'a' else 'projection'
        faults = [row for row in rows if row['label'].startswith(origin + '-normal-fault-')]
        assert len(faults) == 17
        for index, row in enumerate(faults):
            image = account if 'account' in Path(row['command'][0]).name else NATIVE / stem
            expected_error = (old_runtime / (row['label'] + '.stderr')).read_text()
            run(stem + '-fault-' + str(index), [image, *row['command'][1:]], expected=1, kind='expected-failure', stdout='', stderr=expected_error)
    assert all(digest(Path(path)) == expected for path, expected in artifacts.items())
else:
    raise ValueError(STAGE)
assert all(digest(Path(path)) == expected for path, expected in pins.items())
print('Completed', STAGE, 'with all input pins unchanged; no performance timing', flush=True)
