# Complete normal Stage A result

The frozen local-only projection factor has 11 qualified primary Map gains and 4 occupancy gains, with 0 strict-screen losses and 0 qualified raw losses. Both prescribed wide 4096/3584 replacement hash targets pass the normal screen. Slab supplies no qualified gain or loss. These are frozen575/candidate5f368 observations; current-main integration has not been timed.

The practical Rust/standard-C++ target remains incomplete. Candidate primary: 22 pass, 36 deficit, 26 inconclusive across 84 cells. Candidate occupancy: 2 pass, 11 deficit, 19 inconclusive across 32 independent cells. The unchanged maintained reducer independently agrees with both primary arms for status, reason, selected standard and minimum. Occupancy uses that identical target algorithm after complete frozen-key checks; the maintained reducer has no occupancy --complete matrix. Slab has no Rust/C++ standard peers in this control driver.

## Complete factor screen

| Matrix | Cells | Qualified gain | Qualified loss | Inconclusive |
| --- | ---: | ---: | ---: | ---: |
| primary | 84 | 11 | 0 | 73 |
| occupancy | 32 | 4 | 0 | 28 |
| slab | 18 | 0 | 0 | 18 |

## Prescribed primary mechanism targets

| Hash series | Paired raw C/B median range | Paired direct-C-normalized range | M | Result |
| --- | ---: | ---: | ---: | --- |
| aligned-hash | 0.860354313–0.865987328 | 0.846527367–0.878813065 | 0.038845501 | gain |
| native-default | 0.862666283–0.866378800 | 0.863203052–0.868351772 | 0.040152689 | gain |

The independently recorded occupancy replacement cells at capacities 4096, 5120, 6144 and 8192 remain separate in cells.csv and paired-groups.csv; none is pooled with the primary target.

## Controls and qualifications

All 42 primary Map scalar controls, 16 occupancy scalar controls and 9 scalar Slab controls are retained and inconclusive. Wide hit/miss/edit paths retain changed enclosing frames and are labeled accordingly; favorable results cannot isolate removed Pair-copy cost. Both window-C and tagged-C Slab normalizations and all four outer-run/cohort groups survive.

Qualification reasons, which may overlap: normalized-cohort-unstable: 22; raw-cohort-unstable: 18; native-peer-drift-above-10pct: 13; sub-1ms: 11.

All eleven CSV sample IDs 0–10 are ranked. Map performs two unrecorded warmups. Compiler-factor medians come from paired same-sample ratios, not ratios of independently summarized medians. The controls envelope is max(3%, conservative Q, every native-peer raw and C-normalized drift over all participating groups). Q uses the shortest participating WF/native interval and the largest observed clock quantum. Selection requires raw and every C-normalized gain beyond that envelope in every group, minimum interval at least 1 ms, max/min ratio spread at most 10%, and no native-peer raw drift above 10%. Raw-only adverse directions remain separately visible; no peer-drift subtraction occurs.

## Evidence and boundary

Raw execution: 12 timings, 12 preceding clocks, 25,520 Map rows and 4,752 Slab rows; all 24 direct statuses, 12 nested guard exits and 12 integrity records pass. All 197 frozen pins and raw output hashes remain unchanged. The continuous outer guard returned 0 after 719.82 seconds; all clock observations are 1,000 ns. The child result correctly records guard_absent=false while its outer owner still holds the guard.

- envelope-result.json: execution status, full input/raw hashes, command walls and queue gaps.
- paired-samples.csv: all 15,136 matched sample pairs, raw ratios, every C normalization, and exact rational values.
- paired-groups.csv: all 304 cohort/outer-run groups, individual medians/ranges and every native drift.
- cells.csv: every 84 primary, 32 occupancy and 18 Slab cell, screen and qualification.
- ordinary-targets.csv: both arms of all 116 Map cells, selected ordinary peer, bounds and target qualifications.
- individual-standard-peers.csv: all 464 separate Rust and standard-C++ comparisons.
- primary-B-maintained-targets.csv and primary-C-maintained-targets.csv: unchanged maintained-reducer primary outputs.
- reduction.json and reduce.py: complete reduction and its one-shot reader.

No A/A or arm-by-cohort/layout/allocator/ASLR isolation is claimed. Normal-only data cannot satisfy the full two-mode mechanism criterion. Native mechanism and correctness evidence remain independent. This result authorizes no retained timing, retry, threshold change, current-main performance claim or final factor selection; those remain with the root.

## Ordinary-peer target transitions

These classifications compare each arm separately with its median-slower standard peer; a new target deficit is never automatically a paired compiler-factor regression. No pass→deficit transition occurs.

| Matrix | Baseline status | Candidate status | Cells |
| --- | --- | --- | ---: |
| primary | deficit | deficit | 28 |
| primary | deficit | inconclusive | 6 |
| primary | inconclusive | deficit | 8 |
| primary | inconclusive | inconclusive | 19 |
| primary | inconclusive | pass | 5 |
| primary | pass | inconclusive | 1 |
| primary | pass | pass | 17 |
| occupancy | deficit | deficit | 5 |
| occupancy | deficit | inconclusive | 2 |
| occupancy | inconclusive | deficit | 6 |
| occupancy | inconclusive | inconclusive | 17 |
| occupancy | inconclusive | pass | 2 |

The complete 116-cell table, both arms' bounds and selected peers, and the separate paired-factor screen are in ordinary-target-transitions.csv; its counts and source identities are in ordinary-target-transitions.json.
