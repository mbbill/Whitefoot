"""One-shot full Stage A reader; remove with the frozen experiment."""
from collections import Counter, defaultdict
from fractions import Fraction as F
from pathlib import Path
import csv, hashlib, itertools, json, statistics, subprocess

D = Path(__file__).resolve().parent
B = D.parent
PLAN = json.loads((B / 'timing-stage-a-plan.json').read_text())
PREFLIGHT = json.loads((D / 'envelope-result.json').read_text())
REDUCER = Path('<repository-root>/research/experiments/container-representation/summarize-ecosystem.pl')
WF = {'map': 'whitefoot-hash-map', 'slab': 'whitefoot'}
PEERS = {'map': ['rust-hash-map', 'cpp-unordered-map', 'absl-flat-hash-map', 'c-sparse-direct'], 'slab': ['window-c', 'tagged-c']}
NORMS = {'map': ['c-sparse-direct'], 'slab': ['window-c', 'tagged-c']}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def median(values):
    values = sorted(values)
    n = len(values)
    return values[n // 2] if n % 2 else (values[n // 2 - 1] + values[n // 2]) / 2

def spread(values):
    return max(values) / min(values) - 1

def quantum(t, q):
    return (F(t + q, t - q) ** 2 - 1) if t > q else None

def stats(values):
    return {'minimum_ns': min(values), 'median_ns': median(values), 'maximum_ns': max(values)}

def table(name, rows):
    assert rows
    fields = list(dict.fromkeys(k for r in rows for k in r))
    with (D / name).open('x', newline='') as out:
        w = csv.DictWriter(out, fieldnames=fields, lineterminator='\n')
        w.writeheader(); w.writerows(rows)

def public(value):
    if isinstance(value, F): return float(value)
    if isinstance(value, dict): return {k: public(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)): return [public(v) for v in value]
    return value

# Independent arithmetic witnesses: paired median differs from median ratio.
assert median([F(1, 2), F(3, 4), F(9, 2)]) == F(3, 4)
assert F(median([1, 3, 9]), median([2, 4, 2])) == F(3, 2)
assert quantum(3000, 1000) == 3
assert quantum(1000, 1000) is None
assert spread([F(1, 2), F(11, 20)]) == F(1, 10)

ns = {'__file__': str(B / 'timing-stage-a-envelope.py'), '__name__': 'reduce_import'}
exec(compile(Path(ns['__file__']).read_text(), ns['__file__'], 'exec'), ns)
assert ns['verify']() == 197
assert PREFLIGHT['direct_outer_exit'] == 0 and PREFLIGHT['timing_commands'] == 12
STAGES = [json.loads(x) for x in (D / 'stages.jsonl').read_text().splitlines()]
assert len(STAGES) == 24
for stage in STAGES:
    assert stage['direct_exit'] == 0
    assert sha(stage['stdout']) == stage['stdout_sha256']
    assert sha(stage['stderr']) == stage['stderr_sha256']
    assert Path(stage['stderr']).read_bytes() == b''

# Key: family, distinct matrix, width, path, capacity, count, hash series.
DATA = defaultdict(dict)
SOURCE_PINS = {}
for item in PLAN['commands']:
    label = f'{item["index"]:02d}-{item["family"]}-{item["arm"]}'
    path = D / (label + '.stdout')
    ns['integrity'](item, path.read_text())
    SOURCE_PINS[str(path)] = sha(path)
    with path.open() as f: rows = list(csv.DictReader(f))
    for row in rows:
        family = item['family']
        matrix = 'slab' if family == 'slab' else ('occupancy' if item['argv'][1] == 'occupancy-measure' else 'primary')
        cell = (family, matrix, int(row['element_bytes']), row['path'], int(row.get('requested_capacity', 0)), int(row['count']), row.get('series', ''))
        group = (item.get('outer_run', 0), int(row['cohort']))
        key = (group, row['variant'], int(row['sample']), item['arm'])
        assert key not in DATA[cell]
        DATA[cell][key] = row
assert Counter(c[1] for c in DATA) == {'primary': 84, 'occupancy': 32, 'slab': 18}

def identity(cell):
    family, matrix, width, path, capacity, count, series = cell
    return dict(family=family, matrix=matrix, element_bytes=width, path=path, requested_capacity=capacity, count=count, hash_series=series)

def elapsed(cell, group, variant, arm):
    return [int(DATA[cell][(group, variant, sample, arm)]['elapsed_ns']) for sample in range(11)]

def target(cell, arm, fixed_peer=None):
    groups = [(0, 0), (0, 1)]
    ws = [stats(elapsed(cell, g, WF['map'], arm)) for g in groups]
    native = {p: [stats(elapsed(cell, g, p, arm)) for g in groups] for p in PEERS['map']}
    selected, ratios, uppers, lowers = set(), [], [], []
    out = dict(identity(cell), arm=arm, target='median-slower-standard' if fixed_peer is None else fixed_peer)
    for i in range(2):
        rust, cpp = native['rust-hash-map'][i], native['cpp-unordered-map'][i]
        choices = [fixed_peer] if fixed_peer else [p for p in ['rust-hash-map', 'cpp-unordered-map'] if native[p][i]['median_ns'] == max(rust['median_ns'], cpp['median_ns'])]
        selected.update(choices)
        denominator = max(native[p][i]['median_ns'] for p in choices)
        largest = native[fixed_peer][i]['maximum_ns'] if fixed_peer else max(rust['maximum_ns'], cpp['maximum_ns'])
        ratios.append(F(ws[i]['median_ns'], denominator))
        uppers.append(F(ws[i]['maximum_ns'], min(native[p][i]['minimum_ns'] for p in choices)))
        lowers.append(F(ws[i]['minimum_ns'], largest))
        out.update({f'slower_standard_{i}': ';'.join(choices), f'wf_median_ns_{i}': ws[i]['median_ns'], f'rust_median_ns_{i}': rust['median_ns'], f'cpp_median_ns_{i}': cpp['median_ns'], f'absl_median_ns_{i}': native['absl-flat-hash-map'][i]['median_ns'], f'wf_over_selected_{i}': float(ratios[-1]), f'observed_upper_{i}': float(uppers[-1]), f'observed_lower_{i}': float(lowers[-1])})
    minimum = min([w['minimum_ns'] for w in ws] + [native[p][i]['minimum_ns'] for p in selected for i in range(2)])
    peer_spread = max(spread([F(ws[i]['median_ns'], native[p][i]['median_ns']) for i in range(2)]) for p in selected)
    reasons = []
    if minimum < 1000000: reasons.append('short-selected-peer')
    if peer_spread > F(1, 10): reasons.append('selected-peer-unstable')
    if spread(ratios) > F(1, 10): reasons.append('target-cohort-unstable')
    status = 'inconclusive' if reasons else 'pass' if all(x < 1 for x in uppers) else 'deficit' if all(x > 1 for x in lowers) else 'inconclusive'
    out.update(qualification_minimum_ns=minimum, selected_peer_spread_pct=float(peer_spread * 100), target_cohort_spread_pct=float(spread(ratios) * 100), status=status, reason=';'.join(reasons) if reasons else 'observed-sample-separation' if status != 'inconclusive' else 'sample-overlap-or-tie', median_result='win' if all(x < 1 for x in ratios) else 'deficit' if all(x > 1 for x in ratios) else 'inconclusive')
    return out

PAIRED, GROUPS, CELLS, TARGETS, STANDARDS = [], [], [], [], []
for cell in sorted(DATA):
    family = cell[0]; variants = [WF[family]] + PEERS[family]
    groups = [(0, 0), (0, 1)] if family == 'map' else list(itertools.product([0, 1], [0, 1]))
    gr = []
    for group in groups:
        times = {(v, a): elapsed(cell, group, v, a) for v in variants for a in ['B', 'C']}
        ratios = {v: [F(c, b) for b, c in zip(times[(v, 'B')], times[(v, 'C')], strict=True)] for v in variants}
        normals = {(v, norm): [x / y for x, y in zip(ratios[v], ratios[norm], strict=True)] for v in variants for norm in NORMS[family]}
        q = max(PREFLIGHT['clock_quantum_ns'])
        minimum = min(x for values in times.values() for x in values)
        raw = median(ratios[WF[family]])
        norm_medians = {norm: median(normals[(WF[family], norm)]) for norm in NORMS[family]}
        peer_raw_drift = max(abs(median(ratios[p]) - 1) for p in PEERS[family])
        peer_normal_drift = max(abs(median(normals[(p, norm)]) - 1) for p in PEERS[family] for norm in NORMS[family])
        record = dict(identity(cell), outer_run=group[0], cohort=group[1], raw_wf_ratio=float(raw), minimum_ns=minimum, q_ns=q, quantum_bound=float(quantum(minimum, q)) if quantum(minimum, q) is not None else None, native_peer_max_raw_drift=float(peer_raw_drift), native_peer_max_normalized_drift=float(peer_normal_drift))
        for v in variants:
            for arm in ['B', 'C']:
                record.update({f'{arm}_{v}_{k}': n for k, n in stats(times[(v, arm)]).items()})
            record[f'raw_ratio_{v}'] = float(median(ratios[v]))
            for norm in NORMS[family]: record[f'normalized_ratio_{v}_over_{norm}'] = float(median(normals[(v, norm)]))
            for sample in range(11):
                r = dict(identity(cell), outer_run=group[0], cohort=group[1], variant=v, sample=sample, baseline_elapsed_ns=times[(v, 'B')][sample], candidate_elapsed_ns=times[(v, 'C')][sample], paired_raw_ratio=float(ratios[v][sample]), paired_raw_ratio_exact=str(ratios[v][sample]))
                for norm in NORMS[family]:
                    r[f'paired_normalized_ratio_over_{norm}'] = float(normals[(v, norm)][sample])
                    r[f'paired_normalized_ratio_exact_over_{norm}'] = str(normals[(v, norm)][sample])
                PAIRED.append(r)
        GROUPS.append(record)
        gr.append(dict(raw=raw, norms=norm_medians, minimum=minimum, Q=quantum(minimum, q), peer_raw=peer_raw_drift, peer_norm=peer_normal_drift))
    Q = max(x['Q'] for x in gr) if all(x['Q'] is not None for x in gr) else None
    M = max([F(3, 100), Q] + [x['peer_raw'] for x in gr] + [x['peer_norm'] for x in gr]) if Q is not None else None
    raw_spread = spread([x['raw'] for x in gr])
    norm_spreads = {norm: spread([x['norms'][norm] for x in gr]) for norm in NORMS[family]}
    reasons = []
    if min(x['minimum'] for x in gr) < 1000000: reasons.append('sub-1ms')
    if Q is None: reasons.append('clock-unresolved')
    if raw_spread > F(1, 10): reasons.append('raw-cohort-unstable')
    if any(x > F(1, 10) for x in norm_spreads.values()): reasons.append('normalized-cohort-unstable')
    if max(x['peer_raw'] for x in gr) > F(1, 10): reasons.append('native-peer-drift-above-10pct')
    rg = M is not None and all(x['raw'] < 1 - M for x in gr)
    rl = M is not None and all(x['raw'] > 1 + M for x in gr)
    ng = M is not None and all(value < 1 - M for x in gr for value in x['norms'].values())
    nl = M is not None and all(value > 1 + M for x in gr for value in x['norms'].values())
    status = 'inconclusive' if reasons else 'gain' if rg and ng else 'loss' if rl and nl else 'inconclusive'
    control = 'native-identical-scalar' if cell[2] == 8 else 'wide-hit-miss-edit-frame-changed' if family == 'map' and cell[3] in ['hit', 'miss', 'edit-first-word'] else 'changed-wide-trace'
    summary = dict(identity(cell), control_class=control, groups=len(gr), minimum_ns=min(x['minimum'] for x in gr), Q=float(Q) if Q is not None else None, M=float(M) if M is not None else None, raw_ratio_min=float(min(x['raw'] for x in gr)), raw_ratio_max=float(max(x['raw'] for x in gr)), raw_ratio_spread_pct=float(raw_spread * 100), max_native_peer_raw_drift_pct=float(max(x['peer_raw'] for x in gr) * 100), max_native_peer_normalized_drift_pct=float(max(x['peer_norm'] for x in gr) * 100), raw_gain_beyond_M=int(rg), raw_loss_beyond_M=int(rl), all_normalizations_gain_beyond_M=int(ng), all_normalizations_loss_beyond_M=int(nl), qualified_raw_gain=int(rg and not reasons), qualified_raw_loss=int(rl and not reasons), strict_screen_result=status, qualification_reasons=';'.join(reasons), primary_mechanism_target=int(cell[1] == 'primary' and cell[2] == 256 and cell[3] == 'replace-old-value' and cell[4:6] == (4096, 3584)))
    for norm in NORMS[family]:
        summary.update({f'normalized_ratio_min_over_{norm}': float(min(x['norms'][norm] for x in gr)), f'normalized_ratio_max_over_{norm}': float(max(x['norms'][norm] for x in gr)), f'normalized_ratio_spread_pct_over_{norm}': float(norm_spreads[norm] * 100)})
    CELLS.append(summary)
    if family == 'map':
        for arm in ['B', 'C']:
            TARGETS.append(target(cell, arm))
            for peer in ['rust-hash-map', 'cpp-unordered-map']: STANDARDS.append(target(cell, arm, peer))

assert len(PAIRED) == 15136 and len(GROUPS) == 304 and len(CELLS) == 134
assert len(TARGETS) == 232 and len(STANDARDS) == 464

# Use the unchanged maintained reducer for the complete primary ordinary target.
reduction_stages = []
for arm, indices in [('B', [0, 3]), ('C', [1, 2])]:
    sources = [f'map={D / (f"{i:02d}-map-{arm}.stdout")}' for i in indices]
    command = ['perl', str(REDUCER), '--targets'] + sources
    p = subprocess.run(command, capture_output=True)
    (D / f'primary-{arm}-maintained-targets.csv').write_bytes(p.stdout)
    (D / f'primary-{arm}-maintained-targets.stderr').write_bytes(p.stderr)
    reduction_stages.append(dict(argv=command, direct_exit=p.returncode, stdout_sha256=sha(D / f'primary-{arm}-maintained-targets.csv'), stderr=p.stderr.decode()))
    assert p.returncode == 0
    rows = list(csv.DictReader(p.stdout.decode().splitlines())); assert len(rows) == 84
    ours = {(r['element_bytes'], r['path'], r['requested_capacity'], r['count'], r['hash_series']): r for r in TARGETS if r['matrix'] == 'primary' and r['arm'] == arm}
    for r in rows:
        own = ours[(int(r['payload_bytes']), r['path'], int(r['requested_capacity']), int(r['count']), r['hash_series'])]
        assert r['status'] == own['status'] and r['reason'] == own['reason']
        assert int(r['qualification_minimum_ns']) == own['qualification_minimum_ns']
        for i in range(2):
            assert r[f'slower_standard_{i}'] == own[f'slower_standard_{i}']
            assert abs(float(r[f'wf_over_slower_{i}']) - own[f'wf_over_selected_{i}']) <= 1e-9

table('paired-samples.csv', PAIRED)
table('paired-groups.csv', GROUPS)
table('cells.csv', CELLS)
table('ordinary-targets.csv', TARGETS)
table('individual-standard-peers.csv', STANDARDS)
targets = [r for r in CELLS if r['primary_mechanism_target']]
assert len(targets) == 2
summary = dict(status='Complete normal-only frozen-lineage Stage A reduction; no retained performance, rerun or causal attribution to an isolated copy', raw_rows=30272, paired_sample_rows=len(PAIRED), paired_group_rows=len(GROUPS), cells=len(CELLS), source_sha256=SOURCE_PINS, reader_sha256=sha(__file__), maintained_reducer_sha256=sha(REDUCER), maintained_primary_target_agreement=True, maintained_reduction_stages=reduction_stages, matrices={matrix: dict(Counter(r['strict_screen_result'] for r in CELLS if r['matrix'] == matrix)) for matrix in ['primary', 'occupancy', 'slab']}, normal_primary_mechanism_targets=targets, normal_primary_mechanism_target_met=all(r['strict_screen_result'] == 'gain' for r in targets), strict_screen_losses=[r for r in CELLS if r['strict_screen_result'] == 'loss'], qualified_raw_losses=[r for r in CELLS if r['qualified_raw_loss']], scalar_controls={matrix: dict(Counter(r['strict_screen_result'] for r in CELLS if r['matrix'] == matrix and r['control_class'] == 'native-identical-scalar')) for matrix in ['primary', 'occupancy', 'slab']}, ordinary_target_counts={f'{matrix}-{arm}': dict(Counter(r['status'] for r in TARGETS if r['matrix'] == matrix and r['arm'] == arm)) for matrix in ['primary', 'occupancy'] for arm in ['B', 'C']}, qualifications=dict(Counter(reason for r in CELLS for reason in r['qualification_reasons'].split(';') if reason)), method='All eleven recorded samples ranked. Each WF/native ratio pairs the original same seed/sample. Medians of paired raw/normalized ratios, never ratios of separate medians, select the compiler-factor screen. Q uses the shortest participating WF/native interval and largest observed clock quantum. M takes max(3%,Q,all peer raw/normalized drift across every cohort/outer run). Raw and all C normalizations must exceed M in the same direction in every group; minimum1ms,spread10%,native-peer raw drift10% are preserved. Raw-only adverse directions remain separately reported. Slab retains both C normalizations and all4groups. Scalar controls include every path; wide hit/miss/edit has changed enclosing frame. Rust/C++ target uses independent medians/ranges per maintained algorithm; primary84 are verified against unchanged reducer, occupancy32 apply the identical algorithm after frozen complete-key verification. No Slab Rust/C++ target is invented.', limitations='Frozen575/candidate5f368 causal comparison only; current-main integration unmeasured. No A/A, arbitrary temporal/arm-by-cohort/layout/ASLR effects isolated. Normal-only data cannot satisfy the full two-mode criterion. Root makes selection; no retained timing/retry automatically follows this reader.')
assert ns['verify']() == 197
assert all(sha(p) == value for p, value in SOURCE_PINS.items())
with (D / 'reduction.json').open('x') as out: out.write(json.dumps(public(summary), indent=2) + '\n')
print(json.dumps(public({k: v for k, v in summary.items() if k not in ['source_sha256', 'normal_primary_mechanism_targets', 'strict_screen_losses', 'qualified_raw_losses', 'maintained_reduction_stages', 'method']}), indent=2))
