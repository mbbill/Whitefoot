"""One-shot guarded stage-B runner; checks integrity, never reduces timings."""
from pathlib import Path
import csv
import hashlib
import io
import itertools
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime, timezone

BASE = Path(__file__).parent
OUT = BASE / 'timing-stage-b'
PLAN = BASE / 'timing-stage-b-plan.json'
LOCK = Path('/tmp/whitefoot-check-502.lock')
ENV = dict(os.environ)
ENV.pop('WF_WORKERS', None)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def utc():
    return datetime.now(timezone.utc).isoformat()


def append(name, value):
    with (OUT / name).open('a') as stream:
        stream.write(json.dumps(value) + '\n')


def verify():
    pins = json.loads((OUT / 'inputs-before.json').read_text())
    changed = [path for path, sha in pins.items() if digest(Path(path)) != sha]
    assert not changed, changed
    return len(pins)


def integrity(item, payload):
    reader = csv.DictReader(io.StringIO(payload))
    rows = list(reader)
    assert len(rows) == item['expected_rows'], (len(rows), item['expected_rows'])
    assert all(None not in row and None not in row.values() for row in rows)
    if item['family'] == 'map':
        header = 'contract,cohort,series,element_bytes,path,requested_capacity,count,hash,variant,sample,rounds,traces,elapsed_ns,checksum'.split(',')
        occupancy = item['argv'][1] == 'occupancy-measure'
        shapes = [(4096,3584),(5120,3584),(6144,3584),(8192,3584)] if occupancy else [(3,2),(64,56),(4096,3584)]
        paths = ['hit','miss','replace-old-value','edit-first-word'] if occupancy else ['hit','miss','replace-old-value','remove-churn','edit-first-word','fill-free','reserve-more-entries']
        series = ['aligned-hash'] if occupancy else ['native-default','aligned-hash']
        variants = ['whitefoot-hash-map','rust-hash-map','cpp-unordered-map','absl-flat-hash-map','c-sparse-direct']
        key_fields = ['cohort','element_bytes','requested_capacity','count','path','series','variant','sample']
        expected = {tuple(map(str,(item['cohort'],size,capacity,count,path,hash_series,variant,sample)))
                    for size,(capacity,count),path,hash_series,variant,sample in itertools.product([8,256],shapes,paths,series,variants,range(11))}
        assert {row['contract'] for row in rows} == {'capacity-sweep' if occupancy else 'normal'}
    else:
        header = 'contract,cohort,element_bytes,path,count,variant,sample,rounds,traces,elapsed_ns,checksum,requests,requested_bytes,peak_bytes'.split(',')
        key_fields = ['cohort','element_bytes','path','count','variant','sample']
        expected = {tuple(map(str,(cohort,size,path,count,variant,sample)))
                    for cohort,size,path,count,variant,sample in itertools.product([0,1],[8,256],['prefilled-lookup','reuse-churn','setup-cleanup'],[16,256,4096],['whitefoot','window-c','tagged-c'],range(11))}
        assert {row['contract'] for row in rows} == {item['mode']}
    assert reader.fieldnames == header, reader.fieldnames
    keys = [tuple(row[field] for field in key_fields) for row in rows]
    assert len(set(keys)) == len(keys) and set(keys) == expected
    assert all(int(row['elapsed_ns']) > 0 for row in rows)
    stable = [field for field in header if field != 'elapsed_ns']
    return {key: tuple(row[field] for field in stable) for key,row in zip(keys,rows)}


def record_run(label, argv, kind):
    started = utc()
    start = time.monotonic()
    stdout = OUT / (label + '.stdout')
    stderr = OUT / (label + '.stderr')
    with stdout.open('x') as out, stderr.open('x') as err:
        result = subprocess.run(argv, cwd=BASE, env=ENV, stdout=out, stderr=err)
    row = {'label':label,'kind':kind,'argv':argv,'expected_exit':0,'direct_exit':result.returncode,
           'started_utc':started,'ended_utc':utc(),'wall_seconds':time.monotonic()-start,
           'stdout':str(stdout),'stdout_sha256':digest(stdout),'stderr':str(stderr),'stderr_sha256':digest(stderr)}
    append('stages.jsonl',row)
    print(json.dumps(row),flush=True)
    assert result.returncode == 0, row
    assert stderr.read_bytes() == b'', stderr
    return stdout.read_text()


def one(index):
    plan = json.loads(PLAN.read_text())
    item = plan['commands'][index]
    assert item['index'] == index
    count = verify()
    label = f'{index:02d}-{item["family"]}-{item["arm"]}'
    clock = record_run(label+'-clock',[plan['clock']['path']],'clock')
    match = re.fullmatch(r'clock_quantum_ns=([1-9][0-9]*)\n',clock)
    assert match, clock
    payload = record_run(label,item['argv'],'timing')
    stable = integrity(item,payload)
    compared = []
    for previous in plan['commands'][:index]:
        same_cell_set = previous['family'] == item['family'] and (item['family'] == 'slab' or previous['argv'][1:] == item['argv'][1:])
        if same_cell_set:
            old_label = f'{previous["index"]:02d}-{previous["family"]}-{previous["arm"]}'
            assert stable == integrity(previous,(OUT/(old_label+'.stdout')).read_text()), old_label
            compared.append(previous['index'])
    assert verify() == count
    append('integrity.jsonl',{'index':index,'rows':len(stable),'exact_keys':True,
                            'matched_non_time_fields_with':compared,'clock_quantum_ns':int(match[1]),'input_pins_unchanged':count})


def check_guard_owner():
    if LOCK.exists():
        pid = int((LOCK/'pid').read_text())
        os.kill(pid,0)
        if os.environ.get('WHITEFOOT_CHECK_OWNER') != str(pid):
            raise RuntimeError(f'Existing guard {pid}: {(LOCK/"command").read_text()}')


def all_commands():
    plan = json.loads(PLAN.read_text())
    started = time.monotonic()
    previous_end = started
    for item in plan['commands']:
        check_guard_owner()
        now = time.monotonic()
        index = item['index']
        append('delays.jsonl',{'before_index':index,'seconds_since_previous_guard':now-previous_end,'utc':utc()})
        argv = ['perl','source/.github/run-check.pl',f'projection-stage-b-{index:02d}',sys.executable,str(Path(__file__)),'one',str(index)]
        with (OUT/f'{index:02d}.guard.stdout').open('x') as out, (OUT/f'{index:02d}.guard.stderr').open('x') as err:
            result = subprocess.run(argv,cwd=BASE,env=ENV,stdout=out,stderr=err)
        previous_end = time.monotonic()
        status = {'index':index,'argv':argv,'guard_exit':result.returncode,'wall_seconds':previous_end-now,'utc':utc()}
        append('guards.jsonl',status)
        print(json.dumps(status),flush=True)
        if result.returncode:
            raise SystemExit(result.returncode)
    assert verify() > 0
    stages = [json.loads(line) for line in (OUT/'stages.jsonl').read_text().splitlines()]
    checks = [json.loads(line) for line in (OUT/'integrity.jsonl').read_text().splitlines()]
    assert len(stages) == 24 and len(checks) == 12
    assert sum(check['rows'] for check in checks) == 30272
    result = {'status':'complete; integrity only; no performance reduction','exit':0,
              'wall_seconds':time.monotonic()-started,'timing_invocations':12,'clock_invocations':12,'rows':30272,
              'input_pins_unchanged':verify(),'guard_absent':not LOCK.exists()}
    (OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)


if __name__ == '__main__':
    if sys.argv[1] == 'one':
        one(int(sys.argv[2]))
    elif sys.argv[1] == 'all':
        all_commands()
    else:
        raise ValueError(sys.argv[1])
