from pathlib import Path
import csv
import hashlib
import io
import json
import os
import re
import shlex
import subprocess
import sys
import time

ROOT = Path(__file__).parent / 'source'
BASE = Path('<retained-whitefoot-map-occupancy-7abd6bb>')
OUT = Path(__file__).parent / 'runtime'
NATIVE = OUT.parent / 'native'
STAGE = sys.argv[1]
RAW = {label: NATIVE / ('map-' + arm + '.raw.ll') for label, arm in [('occupancy', 'a'), ('projection', 'c')]}
TIMED = {label: NATIVE / ('map-normal-' + arm) for label, arm in [('occupancy', 'a'), ('projection', 'c')]}
CLIS = {
    'occupancy': BASE / 'whitefootc',
    'projection': OUT.parent / 'whitefootc',
}
OWNER = ROOT / 'tests/programs/containers/hash-map-program.wf'
OBSERVER = ROOT / 'tests/programs/containers/container-allocation-observer.c'
RUNTIME_NAMES = ['ordinary_values', 'sched/core', 'sched/entry', 'completion/runtime', 'completion/file_adapter', 'completion/bridge', 'wf_floor', 'sched/prim_host', 'completion/wait_host', 'completion/file_posix', 'completion/linux_io_uring', 'ordinary_values_ir']
RUNTIME = [BASE / 'build/native' / (name + '.o') for name in RUNTIME_NAMES]
CONFIG = (BASE / 'build/ecosystem/configuration.txt').read_text().splitlines()
MODES = ('normal', 'retained')
ENV = dict(os.environ)
ENV.pop('WF_WORKERS', None)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(label, command, expected=0, stdout=None, stderr=None, kind='construction'):
    assert not (OUT / (label + '.stdout')).exists(), label
    start = time.monotonic()
    result = subprocess.run([str(x) for x in command], cwd=ROOT, env=ENV, capture_output=True, text=True)
    seconds = time.monotonic() - start
    (OUT / (label + '.stdout')).write_text(result.stdout)
    (OUT / (label + '.stderr')).write_text(result.stderr)
    record = {'label': label, 'kind': kind, 'command': [str(x) for x in command], 'exit': result.returncode, 'expected_exit': expected, 'seconds': seconds}
    with (OUT / 'stages.jsonl').open('a') as output:
        output.write(json.dumps(record) + '\n')
    print(json.dumps(record), flush=True)
    assert result.returncode == expected, (label, result.stdout, result.stderr)
    if stdout is not None:
        assert result.stdout == stdout, (label, result.stdout, stdout)
    if stderr is not None:
        assert result.stderr == stderr, (label, result.stderr, stderr)
    return result.stdout

def retain_calls(text):
    count = 0
    lines = []
    for line in text.splitlines():
        if line.startswith('define ') and ' @wf_' in line and ' @wf__' not in line and line.endswith(' {'):
            count += 1
            line = line[:-2] + ' noinline {'
        lines.append(line)
    assert count > 0
    return '\n'.join(lines) + '\n', count

def link_ecosystem(label, kind, obj, destination):
    peers = [BASE / 'build/ecosystem' / name for name in [f'driver-{kind}.o', f'rust-{kind}.a', f'cpp-{kind}.o', f'control-{kind}.o']]
    command = ['/usr/bin/clang++', *shlex.split(CONFIG[11]), peers[0], obj, *peers[1:], *RUNTIME, *shlex.split(CONFIG[16]), *shlex.split(CONFIG[12]), '-pthread', '-lm', '-o', destination]
    run(label, command)

if STAGE == 'freeze':
    OUT.mkdir(exist_ok=False)
    old_pins = {item['path']: item['sha256'] for item in json.loads((BASE / 'pre-timing-freeze.json').read_text())['artifacts']}
    paths = [Path(__file__), OUT.parent / 'source-before.json', OWNER, OBSERVER, ROOT / 'compiler/tests/programs/containers.rs', ROOT / 'compiler/src/backend/tests/owned_places.rs', BASE / 'build/ecosystem/configuration.txt', *RUNTIME, *CLIS.values()]
    for label in CLIS:
        paths += [RAW[label], TIMED[label]]
    paths += [BASE / 'build/ecosystem' / name for name in ['driver-account.o', 'rust-account.a', 'cpp-account.o', 'control-account.o', 'driver-timed.o', 'rust-timed.a', 'cpp-timed.o', 'control-timed.o', 'accounting.csv', 'occupancy-accounting.csv', 'geometry.csv']]
    for path in paths:
        if str(path) in old_pins:
            assert digest(path) == old_pins[str(path)], path
    frozen = {str(path): digest(path) for path in paths}
    assert frozen[str(CLIS['occupancy'])] == '5753999f224f89a9a99e0399b76bfd7b92cd53d5f22b0d204df4f2ec3ffbc20b'
    assert frozen[str(CLIS['projection'])] == '5f36879094dd1cc2531989af7b80ef30282dda70ea0229dec9200d438d264e33'
    (OUT / 'inputs-before.json').write_text(json.dumps(frozen, indent=2) + '\n')
    print('Frozen runtime inputs', len(frozen), digest(OUT / 'inputs-before.json'))
    sys.exit(0)

frozen = json.loads((OUT / 'inputs-before.json').read_text())
assert all(digest(Path(path)) == expected for path, expected in frozen.items())
if STAGE == 'construct':
    retention = {}
    for label, cli in CLIS.items():
        raw = (RAW[label]).read_text()
        for mode in MODES:
            module = raw
            if mode == 'retained':
                module, retention[label + '-ecosystem'] = retain_calls(module)
            for kind in ('timed', 'account'):
                if mode == 'normal' and kind == 'timed':
                    continue
                llvm = module.replace('@main(', '@wf_fixture_main(')
                if kind == 'account':
                    llvm = llvm.replace('@malloc(', '@wf_cost_allocate(').replace('@free(', '@wf_cost_release(')
                stem = label + '-' + mode + '-' + kind
                path = OUT / (stem + '.ll')
                path.write_text(llvm)
                obj = OUT / (stem + '.o')
                run(stem + '-object', ['/usr/bin/clang', '-O3', '-Wno-override-module', '-c', path, '-o', obj])
                link_ecosystem(stem + '-link', kind, obj, OUT / stem)
        for lowering, flags in [('sequential', []), ('parallel', ['--par'])]:
            stem = label + '-owner-' + lowering
            path = OUT / (stem + '.raw.ll')
            run(stem + '-emit', [cli, *flags, '--emit-llvm', OWNER, '-o', path])
            owner = path.read_text()
            assert owner.count('define i32 @main(') == 1
            assert '@malloc(' in owner and '@free(' in owner
            for mode in MODES:
                llvm = owner
                if mode == 'retained':
                    llvm, retention[stem] = retain_calls(llvm)
                for observation in ('ordinary', 'observed'):
                    name = stem + '-' + mode + '-' + observation
                    emitted = llvm
                    driver = []
                    if observation == 'observed':
                        emitted = emitted.replace('@malloc(', '@wf_observe_allocate(').replace('@free(', '@wf_observe_release(').replace('@main(', '@wf_fixture_main(')
                        driver = [OBSERVER]
                    emitted_path = OUT / (name + '.ll')
                    emitted_path.write_text(emitted)
                    run(name + '-link', ['/usr/bin/clang', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror', '-Wno-override-module', *(['-I' + str(ROOT / 'compiler/src/backend')] if driver else []), emitted_path, *driver, *RUNTIME, '-pthread', '-lm', '-o', OUT / name])
    assert retention['occupancy-ecosystem'] == retention['projection-ecosystem']
    (OUT / 'retention-counts.json').write_text(json.dumps(retention, indent=2) + '\n')
    artifacts = {str(path): digest(path) for path in OUT.iterdir() if path.is_file() and path.suffix not in ('.stdout', '.stderr', '.jsonl', '.json')}
    artifacts.update({str(TIMED[label]): digest(TIMED[label]) for label in CLIS})
    (OUT / 'artifacts-before-execution.json').write_text(json.dumps(artifacts, indent=2) + '\n')
elif STAGE == 'execute':
    artifacts = json.loads((OUT / 'artifacts-before-execution.json').read_text())
    assert all(digest(Path(path)) == expected for path, expected in artifacts.items())
    for label in CLIS:
        for mode in MODES:
            timed = TIMED[label] if mode == 'normal' else OUT / (label + '-' + mode + '-timed')
            account = OUT / (label + '-' + mode + '-account')
            stem = label + '-' + mode
            for kind, binary in [('timed', timed), ('account', account)]:
                run(stem + '-' + kind + '-check', [binary, 'check'], stdout='map ecosystem: 18390 oracle-checked traces passed\n', stderr='', kind='execution')
                run(stem + '-' + kind + '-occupancy-check', [binary, 'occupancy-check'], stdout='map occupancy: 1440 oracle-checked traces passed\n', stderr='', kind='execution')
            run(stem + '-geometry-check', [account, 'geometry-check'], stdout='map geometry: 140 filled-map observations passed\n', stderr='', kind='execution')
            controls = [(timed, ['negative-checksum'], 'independent key-ID/content/outcome oracle'), (account, ['negative-leak'], 'every allocation is reclaimed')]
            controls += [(timed, ['negative-reserve', str(variant)], 'reserve capacity floor') for variant in (0, 1, 2, 3, 5, 6, 7, 8)]
            controls += [(account, ['negative-geometry', control], message) for control, message in [('missing', 'one filled geometry snapshot'), ('population', 'filled geometry population'), ('identity', 'geometry implementation identity'), ('capacity', 'exposed capacity geometry'), ('allocation', 'filled geometry allocation snapshot'), ('checksum', 'geometry independent setup oracle'), ('diagnostic', 'diagnostic matches trace allocation')]]
            for index, (binary, args, message) in enumerate(controls):
                run(stem + '-fault-' + str(index), [binary, *args], expected=1, stdout='', stderr='map ecosystem: ' + message + '\n', kind='execution')
            for name, args, count in [('accounting', ['account', '262144'], 420), ('occupancy-accounting', ['occupancy-account', '1048576'], 160), ('geometry', ['geometry'], 140)]:
                result = run(stem + '-' + name, [account, *args], stderr='', kind='execution')
                assert len(list(csv.DictReader(io.StringIO(result)))) == count, (stem, name)
                assert result == (BASE / 'build/ecosystem' / (name + '.csv')).read_text(), (stem, name, 'frozen observation differs')
        for lowering in ('sequential', 'parallel'):
            for mode in MODES:
                stem = label + '-owner-' + lowering + '-' + mode
                run(stem + '-ordinary-execution', [OUT / (stem + '-ordinary')], stdout='', stderr='', kind='execution')
                run(stem + '-observed-execution', [OUT / (stem + '-observed')], stdout='container allocation observer: 28 allocations, each released exactly once\n', stderr='', kind='execution')
    observer = OUT / 'projection-owner-parallel-retained-observed'
    run('owner-observer-concurrent', [observer, 'concurrent'], stdout='container allocation observer: 32 allocations, each released exactly once\n', stderr='', kind='execution')
    for control, message in [('double-release', 'allocation released twice'), ('foreign-release', 'release did not return an allocated address'), ('missing-release', 'every allocation is released exactly once')]:
        run('owner-observer-' + control, [observer, control], expected=1, stdout='', stderr='container allocation observer: ' + message + '\n', kind='execution')
    assert all(digest(Path(path)) == expected for path, expected in artifacts.items())
else:
    raise ValueError(STAGE)
assert all(digest(Path(path)) == expected for path, expected in frozen.items())
print('Stage complete with all frozen inputs unchanged:', STAGE, flush=True)
