# Local consuming projection: proposed complete timing discriminator

Prepared before any local-only performance sample. This is a distinct trial
of frozen baseline B (`5753999f…`) and local-only candidate C (`5f368790…`).
The broad forwarding candidate was refused by its native gate, and its
three-arm timing protocol was never executed. No broad-candidate samples,
earlier Map group-control samples, or Vector results enter this reduction.
This plan awaits root's method review; it authorizes no timing command.

`timing-plan.json` gives every exact image hash, command, output-row count and
process position. Existing successful native and correctness records are
`native-report.md`, `native-inventory.json`, `correctness-report.json` and
`correctness-artifacts.json`. The fixture-only repair changes no production
compiler bytes or timed image. No build or link is needed for this trial.

## Recommended order and cost

Use the two existing cohorts once each, with opposite whole-process arm order:

| Stage | Cohort | Arm | Helper-mode order |
|---|---:|---|---|
| 1 | 0 | B | normal, retained |
| 2 | 0 | C | normal, retained |
| 3 | 1 | C | retained, normal |
| 4 | 1 | B | retained, normal |

Run those four stages first for `measure`, then repeat them for
`occupancy-measure`. Every command keeps work `1048576`, all eleven samples,
the two checked warmups, the original seeds and the driver's reversed peer
order in cohort 1. Each of the sixteen Map invocations gets its own guard,
clock observation, output files, direct status, start/end time and hash checks.
Release the guard after each invocation; queue interruptions are recorded.
Do not reserve the full trial as one long guard or reorder a remaining command
after inspecting timings. Stage outputs are not reduced until all prescribed
invocations finish, apart from status, hash, row and oracle integrity checks.

The fresh unchanged normal baseline in
`<retained-whitefoot-map-group-control-7abd6bb>/timing/summary.json`
records primary cohorts at 149.783143 and 149.029944 seconds, and occupancy
cohorts at 24.947477 and 24.874598 seconds, all direct status 0 at work
1048576. That is 348.635163 seconds per two-cohort image. Applying that cost
to two arms and two modes gives **1,394.540650 seconds, or 23.242344 minutes**
for Map. An individual guard is estimated at about 150 seconds for a primary
command or 25 seconds for occupancy. This is an estimate: the source-identical
retained images have passed correctness but have no timing observation, and
their cost is not claimed to equal normal mode. Record any overrun and inspect
the active stage before extending work; elapsed cost never permits trimming
cells, changing work or silently replacing a result.

The stricter alternative executes B→C and C→B within *each* existing cohort
and mode. It produces 102,080 Map rows instead of 51,040, and costs an estimated
2,789.081301 seconds / 46.484688 minutes before controls. It gives a repeated
same-cohort image observation and same-image null observations, at twice the
work. It still does not isolate arbitrary temporal drift, allocator state,
linked placement or process ASLR. Choosing that alternative must precede any
sample; it is not an automatic rescue for an inconclusive recommended trial.

The recommended B0→C0→C1→B1 schedule balances average arm positions and
opposes the direction of simple process-order drift. It does **not** estimate
an arm-by-cohort interaction independently: process position and the driver's
cohort order remain coupled, and elapsed command lengths need not be equal.
Requiring agreement across cohorts is therefore a conservative descriptive
discriminator, not a causal cancellation theorem or a confidence interval.

The motivating Vector observation must be stated narrowly. Its preserved
branch-first full pair ran one whole B→C order containing both cohorts.
Scalar suffix-three/count-16 lost despite never reaching the changed removal
body; all 37 sites of its repeated no-growth cycle had identical bytes and
addresses. The Vector report and
`.build/swap-remove-source/branch-first/timing/scalar-suffix-native-observation.json`
establish that boundary, **not** that process order caused the loss. The new
schedule addresses an unresolved confound; it does not rewrite that result.

## Complete matrices and triggered controls

Each Map primary invocation has 84 WF cells: two payloads, three unchanged
capacity/population pairs, seven paths and two hash series. Five implementations
and eleven samples produce 4,620 rows per cohort. Occupancy retains two
payloads, four capacities, four paths and aligned hashing: 32 WF cells and
1,760 rows per cohort. The two arms, two modes and two cohorts therefore retain
**51,040 Map rows**. Ordinary Rust, standard C++, Abseil and direct C remain
in every applicable cell; no default-only submatrix substitutes for this set.
Checksums, work, rounds, trace counts, implementations and all non-time fields
must match the frozen contracts and each paired observation.

Map normal images use the existing O3 allocation path. Retained images retain
the exact qualified list of 49 public-operation/callback definitions plus the
corresponding existing `RETAIN_HELPERS` C control. These are diagnostic rows.
All-call semantic images retaining 131 ecosystem or 213 owning-program
definitions are not timed or relabeled as public-retained images.

Slab is triggered: only its wide trace changes, removing three local Handle
copies in both qualified modes. Run the complete existing `measure` command
for both arms and both modes in both existing outer runs. Outer run 0 uses
B then C, normal then retained; outer run 1 uses C then B, retained then
normal. Each command already contains both internal cohorts, two payloads,
three paths, three counts, eleven seeds and all three implementations. Its
1,188 rows give **9,504 Slab rows** over eight invocations. Preserve both C
representations, the exact allocation observations and all four outer-run /
internal-cohort groups. The historical full two-mode/two-run measurement plus
checks took 5.42 seconds per arm; allow roughly 11–20 additional seconds,
explicitly an estimate, with every actual command time retained.

Vector is nontriggering: complete O2 normal/retained and O3 ecosystem native
inventories each have 59 identical bodies and identical outside constants.
PriorityQueue is likewise nontriggering: 66/66 O2 bodies and 68 O3 bodies
match. Their exact current images' full correctness has already run where
required. No Vector or PriorityQueue timing is substituted from another
experiment. This follows the previously fixed native trigger rule; it is not
a decision made after local-only timings. Total recommended timing cost is
about **23.4–23.6 minutes plus any retained-mode cost difference**, in bounded
commands. The strict repeated alternative is about 46.8–47.2 minutes on the
same estimate, and doubles the Slab observations too.

## Drift observations and descriptive screen

The recommended trial has no fresh same-image A/A execution. It explicitly
uses the already present native peers and native-unchanged WF paths as
negative controls instead. It is a new local-only discriminator, not a claim
to have completed the broad trial's A/A protocol.

For each Map cell/mode/cohort, pair by the original sample/seed, work and
trace counts. Compute each sample's raw WF ratio `r = C_WF / B_WF`, each
native peer ratio `d_p = C_p / B_p`, and direct-C-normalized WF ratio
`n = r / d_direct_C`. Report medians of those paired ratios, not ratios of
independently summarized observations. Publish all peer ratios separately.

Before every timed command, run the already constructed, pinned
`controls/clock-quantum` carrier from the sibling clean experiment. It copies
the maintained Map clock and 10,000-probe minimum-positive-delta functions
unchanged. Keep every observation and use the largest participating quantum
`q`. Let `t_min` be the shortest interval used in a cell's raw/normalized
comparison. Report the conservative ratio-of-ratios quantum bound
`Q = ((t_min + q) / (t_min - q))^2 - 1`; `t_min <= q` cannot select a gain.

The proposed per-cell screen is

`M = max(0.03, Q, max_peer_and_cohort |median(d_p) - 1|,
                 max_peer_and_cohort |median(d_p / d_direct_C) - 1|)`.

This controls envelope uses all four native references and both cohorts,
with no favorable-peer selection. It replaces the unavailable same-image
null term **before** measurement and is identified as a controls envelope,
not an empirical same-image noise estimate. Peers have unchanged compiled
inputs, but their linked addresses or runtime states need not be identical.
Their variation does not measure or remove WF-specific placement/allocator
effects. For Slab apply the same construction with both window C and tagged
C normalizations and all outer-run/cohort groups; preserve the worse screen.

Report every scalar Map cell as a WF negative control: the scalar trace and
its scalar callees are unchanged in the complete native inventory. Wide
hit/miss/edit cells also test paths without the targeted repeated replacement
copy, but the enclosing wide frame changes, so they are not labeled wholly
native-identical. Neither group is used to subtract elapsed time from a
replacement trace. A material, qualified adverse control result remains a
counterexample; a favorable unchanged-path result warns against attributing
a whole-image gain solely to removed Pair transfers.

## Selection, target and attribution are separate

The prespecified mechanism target remains wide replacement at capacity/count
4096/3584 under both native-default and aligned hashing. Require raw and
direct-C-normalized improvement beyond `M` in both cohorts and both helper
modes. Preserve the independent occupancy rows at 4096 and all larger
capacities rather than pooling them with the primary occurrence. Apply the
existing minimum-duration qualification (all relevant samples at least 1 ms)
and at-most-10% cohort ratio spread to any ranked Map comparison. A native-peer
inter-image drift above 10% also leaves attribution in that cell unresolved.
All other cells, tails, controls and qualification failures remain visible.
No unexplained material regression in a triggered family can select the
general compiler factor. Short/unstable control cells are reported as such;
they do not establish a favorable optimization claim or disappear from the
record. No replay, new arm, changed threshold or alternate emission follows
an adverse or ambiguous result automatically.

The owner's practical target is evaluated separately, only on normal public
use, using the maintained reducer: choose the median-slower ordinary
Rust/standard-C++ peer separately in each cohort; require every WF sample
below every selected-peer sample in both cohorts with the existing duration
and stability qualifications. Preserve both individual peer comparisons and
Abseil. Retained-call diagnostics cannot establish that application target.

The native evidence establishes removal of two executed 264-byte Pair copies
with the original Record captures and complete parent ABI preserved. A timing
success would establish a qualified improvement of this complete compiler
factor on these frozen images. It would not measure an isolated memcpy cost
or prove every change in elapsed time came from those transfers. A timing
failure does not invalidate the independent correctness results, and a timing
success does not by itself select a language or public-ABI change. Main's
waiting/ContextStart exclusions and final selected-base compatibility remain
separate integration obligations.
