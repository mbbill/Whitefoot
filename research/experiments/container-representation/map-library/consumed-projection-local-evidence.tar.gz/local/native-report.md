# Local consuming-projection native screen

The separately registered local-only variant passes its native gate. Both
selected Pair264 projection copies disappear on the source replacement path in
normal and retained Map images, while the original Record256 call snapshots
remain. All free/rebuild native bodies reproduce baseline. Slab removes three
Handle16 projections and introduces no aggregate transfer; Vector and
PriorityQueue reproduce baseline. This is native mechanism evidence only:
no new test harness, program execution, accounting/fault phase or performance
timing has run for this CLI. The broad factor remains refused and its long
three-arm protocol remains unexecuted.

## Identity, stages and preserved failures

The approved criterion remains `variant-plan.md`, SHA256
`fe1c6cbc880776f6053ea101554af9e97bb71918b14762abd9d870b2f768249c`.
Baseline is frozen575. The new isolated CLI is `whitefootc`, SHA256
`5f36879094dd1cc2531989af7b80ef30282dda70ea0229dec9200d438d264e33`.
The source is the exact broad freeze at
`6da90dba09db335c0ea9158fa075f3aecc27e309`, with only storage.rs changed for
this variant; `broad-parent.json` and `source-before.json` identify all inputs.
No shared source changed. The final local delta is `local-only.patch`, SHA256
`400eb408d0b33cc653d0e5fc30bf4a5c631b1f51770a7e7f5f289c6d84f45e01`.

`result.json` records the direct stages and phase timings separately:

- Two frozen-baseline source admissions exit 0; direct total 0.033785 s.
- One isolated gate/jobs2 CLI build exits 0; direct 62.617269 s, containing
  phase 63.020449 s. No test-harness construction occurred.
- The complete native continuation has 61 direct commands, all exit 0,
  direct total 8.213099 s; containing phase 8.586661 s. Analysis exits 0 in
  1.089743 s. Its outer guard exits 0 in 9.828321 s and is released.
- All 2,394 source pins, 53 input pins and 76 native artifact pins match after
  construction. Eight prior qualified baseline assemblies reproduce every
  function and all outside text under the recorded label/comment normalization.
  The two PQ O2 baseline assemblies are new constructions from the exact frozen
  transformed modules and flags; there were no older standalone assemblies.

Two authoring/setup failures are retained, not counted as successful checks:
`admission-attempt-1/` preserves OWN-1 MoveOfCopy (direct/outer exit 1).
The repair removes only `move` from the Copy payload's Call argument in the
standalone and embedded fixture; the nocopy parent is still consumed, the
independent original read and expected results stay unchanged. Both corrected
sources admit. `native-attempt-1/` preserves 20 successful commands and the
retained baseline link failure (missing main, exit 1). The runner had placed the
retained C control in the driver position. `native-link-repair.json` records its
correction to the previously qualified order: unchanged driver, WF object,
unchanged Rust/C++ peers, retained C control, unchanged runtime and libraries.
All input bytes were already pinned. The existing CLI was reused; no rebuild,
source, retention, optimization flag or runtime observation changed.

## Complete inventory

`native-inventory.json` contains all names, native frames and individual full
diffs. Raw headers, types, globals, declarations and attributes are identical
for every family. Five of 134 Map definitions change; one of 50 Slab definitions
changes. All 62 Vector and 74 PQ raw definitions and outside bytes match exactly.
All six changed raw functions retain identical block labels, branch/return
structure and ordered non-memmove callees; only temporary numbers are normalized
in that CFG observation. `native-gate-evidence.json` records that check.

The changed raw functions are Map wide trace `4250cb78d3f44027`, put
`28da32efc51c2b65` and `8d5197e2f00c3b07`, rebuild bodies
`28da32efc51c2b65.body` and `8d5197e2f00c3b07.body`, and Slab wide trace
`1779281446fb6ac7`. The inventories carry their complete symbol names.
Raw memmoves respectively change 14→8, 6→5, 6→5, 6→5, 6→5, and 8→5.

| Complete native mode | Functions A/C | Changed bodies | Frame bytes in changed bodies, A→C |
| --- | ---: | --- | --- |
| Map O3 normal | 109/109 | wide trace, two put | trace 8048→6128; each put 1136→864 |
| Map O3 retained | 124/124 | wide trace, two put | trace 6800→5168; each put 1136→864 |
| Slab O2 normal | 41/41 | wide trace | 3728→3664 |
| Slab O2 retained | 46/46 | wide trace | 3168→3104 |
| Vector O2 normal/retained, O3 ecosystem | 59/59 each | none | identical |
| PQ O2 normal/retained | 66/66 each | none | identical |
| PQ O3 ecosystem | 68/68 | none | identical |

Every native module has identical outside-function constants/directives after
the recorded local-label normalization. Optimized LLVM outside diffs are only
its input-path ModuleID comment; Slab normal additionally prints one unchanged
named type earlier. No type body, global, constant or attribute changed.
Native comparison preserves registers, offsets, callees, constants and
directives; changed register allocation is therefore visible in the full diffs.
The exact prior retention policies remain 49 Map, 25 Slab and 32 Vector retained
definitions; PQ retains 2 traces normally and 30 definitions diagnostically.
`retention-before.json` lists every selected symbol and the inventory verifies
retained definitions/calls in both arms.

## Targeted Map path and complete parent

The unchanged source's `path == 2` arm calls put on the keys populated earlier,
then consumes the returned pair (map-library.wf lines 324–346). Raw bb67 selects
2, bb69 performs put, and bb73 handles Returned. The paired snippets are
`review/map-{a,c}.replacement-raw-blocks.txt`. This is static qualification of
the source path, not a claim that this screen executed it.

In the normal linked A image, try_put is at 0x100006c10; tag 1 is checked at
6c14/6c1c, reason is loaded at 6c2c, Pair264 is copied at 6c3c, and reason-zero
branches at 6c40 to 70c8. The constructor copies Pair264 at 70e8; the caller's
Pair projection copies it again at 7104. The following Record256 capture remains
an eight-pair q load/store sequence.

In normal C, try_put is at 0x10000697c; tag checks are 6980/6988, reason is
loaded at 699c, and reason-zero branches at 69a0 to 6ddc. There is no Pair
projection copy on that route. Exactly one Pair264 constructor transfer remains
at 6df8; the caller loads the key from the returned parent's field at 6e48,
then performs the same independent Record256 capture beginning at 6e50.
`review/map-normal-{a,c}.replacement-excerpt.txt` and the full linked wide
traces preserve these instructions.

Retained A calls standalone put at 0x100005790. Within put, try_put is 72c0,
Pair264 projection copy 72e8, reason-zero branch 72ec→7384, and constructor
copy 739c. Back in the caller, Returned tag checks are 5794/579c and the
Pair264 projection copy is 57b8. Retained C calls put at 5734. Its try_put is
7238, tag checks 723c/7244, and reason branch 7250→72fc. Only the constructor
Pair264 copy remains at 7314. Back in C's caller, tag checks 5738/5740 precede
key load 5768 and Record256 capture at 576c, with no Pair transfer.
The complete retained put bodies and caller excerpts are in `review/`.
Both target projection removals therefore hold with and without retained calls;
this local-only variant deliberately keeps the child Record capture.

Both put instantiations keep the entry Record256 owned-input capture before
try_put (eight q load/store pairs). The independent retry Record256 capture
also remains. Their raw frame changes from Record256/Enum272/Pair264/Result8/
Record256 to Record256/Enum272/Result8/Record256, align 8: only the standalone
Pair264 disappears. The types remain Record `{ [32 x i64] }`, Pair
`{ i64, Record }` (264, align 8), and HashMapPut `{ i32, i1, Pair }`
(272, align 8). The whole parent and original result pointer/ABI remain.

Inserted still initializes the complete result without reading an inactive
payload. Returned/Replaced uses the remaining constructor copy. Full at the
ceiling, reserve failure and reserve success retain their original branches;
reserve success reads the active key, captures Record256 independently, and
retries into the original result. Both native put bodies were inspected in
both modes, including initialization stores and retry paths. Whole-function
trace inventory covers fill, delete/reinsert, replacement and rehash paths:
six caller Pair264 transfers disappear; normal inlining removes three more
put projection transfers. The normal trace's remaining three memcpy calls are
the existing constructors. Its q-register construction/capture paths are
unchanged apart from offsets/register assignment. Retained trace loses its
six Pair264 memcpy calls while keeping all six Record256 q-transfer paths.
No aggregate transfer is added on any changed trace path.

## Free, rebuild and controls

All four free and all four rebuild instantiations are native-identical in each
Map mode: 16 complete-body equalities, listed with canonical hashes in
`native-gate-evidence.json`. This includes the word instantiations and both
wide specializations. Thus free retains baseline tag-first behavior, no payload
transfer on Vacant/Deleted, and only its original Filled transfer. Rebuild
retains its baseline pre-exchange and retry-restoration transfer paths and
frame. The broad factor's materialized loaded-parent regressions are absent.
The remaining raw rebuild change forwards a local record into a Pair
construction; the optimizer erases that difference completely. No whole-parent
physical initialization or active-variant interpretation is changed.

Slab's only changed body removes the 16-byte handle projections at bb6, bb10
and bb36 in both modes. Those are each a q load/store pair in A and direct
field loads (or an unused handle) in C. Every remaining 256-byte capture and
construction stays on the same source block. Normal retains the take capture
at bb8.i, two 256-byte copies at bb30, the same initialization at bb31, and the
same insert-failure copies at bb7/bb11/bb37. Retained keeps its four independent
Record256 captures in bb7/bb11/bb30/bb37. The final 16-byte owning Slab capture
at bb15 remains. There are no new bulk intrinsics, register-expanded aggregate
transfers or larger frames. The full native diffs plus per-source-block
q-memory inventory are preserved; counts alone were not treated as equivalence.
Vector and PQ have no changed native bodies in any of their three modes.

## Boundary and continuation

The local-only predicate rejects every projected storage group used as a Call
argument; safe same-activation calls and potentially inline compiler calls
conservatively keep captures. It does not change FieldReuse, checked-source
consumption metadata, the ABI or any language rule. The exact candidate still
requires focused storage/owned-place tests and complete exact-image correctness,
ownership, accounting and fault controls before a timing decision. Retained
rows remain diagnostic; the owner's practical target is normal public use.
Main integration remains separate: exclude waiting functions and explicitly
reject ContextStart operands after porting, with valid main-source boundary
regressions. The all-Call exclusion already covers waiting callees. No main
merge, shared-source edit or long timing was performed in this screen.
