# Complete retained Stage B result

The exact registered twelve timings and twelve clocks complete with direct statuses 0, 30,272 raw rows, twelve integrity records and 259 unchanged pins. The continuous outer guard exits 0 in 828.70 seconds; all clocks observe 1,000 ns. No native timing is retried.

Under the unchanged all-eleven-sample raw/C-normalized criterion, primary has 7 gains/0 losses/77 inconclusive cells; occupancy has 4/0/28; Slab has 0/0/18. There are no qualified raw-only losses. All scalar controls remain inconclusive. Normal Stage A and retained Stage B both qualify the two registered wide replacement targets; current-main qualification remains a separate implementation discriminator, not final policy selection.

| Retained primary hash | Raw paired C/B range | C-normalized paired range | M |
|---|---:|---:|---:|
| aligned-hash | 0.878632972–0.890280854 | 0.882953059–0.895150537 | 0.030000000 |
| native-default | 0.889937642–0.894037375 | 0.890574088–0.916079043 | 0.030000000 |

Occupancy remains independent at all four capacities. All nine wide Slab cells meet the minimum-duration/stability qualifications but no effect exceeds M in every raw and both-normalization group; all nine scalar Slab cells remain sub-1ms. Native peer raw drift above 10% leaves 18 Map cells unresolved; every drift and adverse interval remains recorded.

Retained ordinary-target counts are diagnostic, separate from the normal public-use target. Primary B→C is 14pass/62deficit/8inconclusive→11/65/8; occupancy is 0/25/7→0/27/5. Four primary passes become inconclusive, eight cells acquire deficit flags (four primary/four occupancy), and no pass becomes deficit. A target flag is not automatically a paired compiler-factor regression. Full Rust and C++ comparisons remain separate in individual-standard-peers.csv; the unchanged maintained primary reducer agrees for both arms.

| Lost pass (all scalar capacity3/count2) | Hash | Reason | Paired raw cohorts 0 / 1 | C-normalized cohorts 0 / 1 | M |
|---|---|---|---:|---:|---:|
| fill-free | aligned-hash | sample-overlap-or-tie | 1.001388184 / 0.992508605 | 1.008142012 / 1.005251765 | 0.046625534 |
| miss | native-default | sample-overlap-or-tie | 1.001979294 / 0.992771543 | 0.996459458 / 1.003727422 | 0.085171883 |
| replace-old-value | native-default | sample-overlap-or-tie | 1.011058264 / 1.021111893 | 0.997840818 / 0.982237554 | 0.068799299 |
| reserve-more-entries | native-default | selected-peer-unstable;target-cohort-unstable | 1.070488899 / 0.987429749 | 1.073529576 / 0.991505294 | 0.047884872 |

All four lost-pass bodies are native-identical. None satisfies paired raw+normalized loss beyond M in both groups. Reserve has a single-cohort +7.05% paired raw direction, its other cohort -1.26%, and its ordinary target is peer/cohort unstable. The fill target retains a single-cohort upper-bound tail 2.0966. Both adverse observations remain visible rather than becoming a median-only pass.

Evidence: envelope-result.json and immutable raw .stdout files preserve statuses/hashes; paired-samples.csv retains 15,136 exact matched ratios; paired-groups.csv preserves 304 groups/all controls; cells.csv contains all134 cells; ordinary-targets.csv and individual-standard-peers.csv contain 232/464 comparisons; ordinary-target-transitions.csv covers all116 transitions. reduce.py reuses Stage A arithmetic unchanged; reader-reuse.diff records only Stage/output/pin/postflight identity and retained-label changes. No A/A, arm/cohort, layout, ASLR or allocator isolation is claimed. No criterion, threshold or native image changes after observation.
