# Stage A addendum: complete normal use before retained timing

Root adopted this staged method after independent review, before any local-only
timing. The complete two-mode proposal remains unchanged in `timing-plan.md`
and `timing-plan.json` as proposed history. This addendum changes only the
first-stage mode selection and its stopping boundary. It does not claim that
the original two-mode performance criterion has been completed.

Stage A runs all **normal** commands in the original proposed order:

| Invocations | Family / matrix | Fixed process order |
|---|---|---|
| 0–3 | Map primary, work 1048576 | B0 → C0 → C1 → B1 |
| 4–7 | Map occupancy, work 1048576 | B0 → C0 → C1 → B1 |
| 8–11 | Slab normal, complete internal cohorts | B/run0 → C/run0 → C/run1 → B/run1 |

`timing-stage-a-plan.json` is the exact filtered command list with executable
hashes, expected statuses, row counts and references to the original proposal.
B is frozen baseline575, using filenames ending `-a`; C is local-only
candidate5f368, using filenames ending `-c`. The twelve invocations retain
25,520 Map rows and 4,752 Slab rows. No cell, peer, seed, warmup, work count,
sample, tail, duration or stability qualification is removed within normal
mode. Primary and occupancy remain separate full matrices. Ordinary Rust,
standard C++, Abseil and direct C remain visible in Map; both existing C
representations remain visible in Slab. The native trigger inventory still
leaves Vector and PriorityQueue nontriggering; their observations are not
replaced with another experiment's timings.

The root-approved normal stage is estimated at 697.270325 seconds / 11.621172
minutes for Map, using the verified recent normal baseline cost. Normal Slab
adds four complete existing invocations; the historical full two-mode result
supports a conservative estimate of under eleven further seconds. No compiler
or native construction is needed. Record actual clock calibration, per-command
wall times and all queue gaps separately; the estimate is not a time limit or
a reason to shorten work.

Each invocation keeps its own existing UID502 guard and a preceding pinned
clock-quantum run. Once all queued Deque/Slots/PQ construction and correctness
work explicitly hands off, reserve the logical queue continuously for this
stage. No other heavy build or benchmark interleaves between these B/C
invocations. The physical guard is released after every command. Record actual
between-command delays and any urgent user interruption. Do not start while
another owner's PID is live, and do not hold an idle guard during preparation.

During the stage, inspect only execution status, stdout/stderr integrity,
headers, exact row/key counts, non-time fields, oracle/ledger consistency and
frozen hashes. Do not compute performance summaries, select favorable cells,
or decide whether to continue based on elapsed sample values until all twelve
invocations finish. Preserve every command and sample, including failures.

Apply the original proposed normal-mode descriptive screen unchanged: paired
raw WF and C-normalized ratios; the maximum of 3%, the conservative clock
bound, and all unchanged-native-peer raw/normalized drift across cohorts;
minimum-duration and cohort-stability qualifications; complete scalar/path
negative controls; no unexplained material regression in a triggered family.
The wide 4096/3584 replacement target remains prespecified under both hash
series. The ordinary-peer target remains the maintained normal-use test
against each cohort's median-slower Rust/standard-C++ peer, with strict sample
range separation and all existing qualifications.

A normal failure or adverse control ends performance selection of this
candidate. Only a qualified normal gain, or an ambiguity relevant to selecting
the broader factor, can justify retained timing **after root reviews the full
normal result**. Retained timing is not automatic, and no new arm, rerun,
threshold or emission is authorized by this stage. Normal-only evidence cannot
satisfy the final two-mode mechanism criterion or finish the overall task.
The successful retained native and correctness evidence stays separately
qualified; it is not relabeled as retained performance evidence.

No A/A experiment is claimed. Opposite arm order across the two existing
cohorts addresses simple process-order drift but leaves arm-by-cohort effects,
nonlinear temporal drift, linked layout, allocator state and process ASLR
unisolated. Unchanged peers and scalar paths are negative controls, not a way
to remove those effects. Native removal of two executed Pair copies is a
mechanism observation; a qualified elapsed-time improvement would concern the
complete frozen factor, not an isolated memcpy cost. No rejected broad-factor
or earlier experiment's samples enter the reduction.
