# Stage B preparation: complete retained diagnostics

Root independently reproduced the full normal Stage A result and authorized
preparing, but not executing, the twelve remaining retained commands from
the original two-mode proposal. This is prepared-only. Slots retains the next
assigned timing slot; Stage B needs its own explicit root host handoff.

The original proposal order is filtered without replacing a command: primary
Map B 0,C 0,C 1,B 1; occupancy Map B 0,C 0,C 1,B 1; Slab B/run 0,C/run 0,C/run 1,B/run 1.
Every Map command retains work 1048576, all original cells, peers, seeds and
CSV sample IDs 0–10 and two unrecorded checked warmups. Slab retains both
internal cohorts, all 18 cells, both C representations and all 11 samples.
Map diagnostic CSV contracts remain normal/capacity-sweep because the frozen
driver is shared; Slab CSV contract is retained. Modes are selected by frozen
images, never inferred from the Map contract label. No image is rebuilt.

All 4 retained image hashes, the exact commands,row totals and input pins
are in timing-stage-b-plan.json and timing-stage-b/inputs-before.json. The
exact totals are 25520 Map rows and 4752 Slab rows,30272 altogether. The one-shot
reader is derived from the already reviewed Stage A envelope with only output,
plan and guard labels and Slab mode checking changed. Original Stage A method,
runner, manifest, samples and criteria remain preserved. Remove this scratch
runner and registration when the experiment is retired.

Cost remains an estimate: the original normal proxy is 697.270325 seconds for
Map; fresh Stage A used 711.419129 seconds for Map,4.211864 for Slab and 719.82
for its complete guarded stage. These are normal-mode observations, not retained
cost measurements. Retained-helper overhead is unmeasured. The proposed outer
guard has 1200 seconds; original nested wrappers retain their 1800-second default.
The previously unexecuted 900-second proposal is preserved in
timing-stage-b/proposal-900.json; root directed 1200 before observation.
This is a guard budget, never a performance criterion or source acceptance rule. An overrun preserves all
partials and stops; it authorizes no shortening, retry or automatic retiming.

Before every timing, run the same pinned 10000-probe clock carrier. Hold one
continuous outer guard; allow a recorded lock only for the live inherited
WHITEFOOT_CHECK_OWNER PID. Refuse an external, mismatched or dead owner.
During execution inspect status, stdout/stderr, exact keys/headers/counts,
non-time/oracle fields and hashes only. No performance reduction until all
12 prescribed timings and 12 clocks finish. Preserve all failures.

The full frozen criterion is unchanged: paired WF raw and C-normalized
ratios; M=max(3%, conservative Q, every native peer raw and normalized drift
over all cohorts); all relevant intervals at least 1 ms; max/min ratio spread
at most 10%; peer raw drift above 10% leaves attribution unresolved; retain
all scalar controls and frame-changed wide hit/miss/edit paths; no unexplained
material regression in a triggered family. Require the wide 4096/3584
replacement target under both hash series in both modes; occupancy remains
separate at all 4 capacities. Slab keeps both C normalizations and all 4
outer-run/cohort groups. Normal ordinary Rust/C++ targets remain separate
from retained diagnostics. The Stage A transition table includes every
pass/deficit/inconclusive change and flags new deficits without relabeling
them as paired compiler-factor losses.

Native and positive normal measurements do not select general compiler policy.
The complete retained discriminator and current-main boundary, correctness and
native qualification remain separate obligations. There is no A/A claim and no
isolation of arbitrary temporal, layout, allocator, ASLR or arm/cohort effects.

Recorded-interval cost attribution: WF contributes 29.6268123% of Map and
39.6910990% of Slab observed normal sample durations across both arms. The
other implementations supply the remainder. This is not an exact whole-process
share: unrecorded warmups, clocks and guard overhead are absent. Retained-helper
call overhead is unmeasured; direct-C diagnostic helper flags may change cost
across modes. The normal 719.82-second guarded stage is the planning proxy,
with a prospective 1200-second bound. A timeout is preserved, never rescued
by shortening or a rerun.
