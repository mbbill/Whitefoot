# Local consuming projections: separate untimed variant

## Parent result and causal evidence

The broad candidate is unselected. No projection timing samples were collected;
the complete prospective three-arm protocol remains unexecuted in
`../whitefoot-consumed-projection-clean/timing-plan.md`. The variant below is a
new mechanism screen, not a replay of a failed timing discriminator. It changes
neither the frozen broad image nor the shared worktree's implementation.

The qualified baseline CLI is
`../whitefoot-map-occupancy-7abd6bb/whitefootc`, SHA-256
`5753999f224f89a9a99e0399b76bfd7b92cd53d5f22b0d204df4f2ec3ffbc20b`.
The broad candidate CLI is `../whitefoot-consumed-projection-clean/whitefootc`,
SHA-256 `f575555aa641f6cbd2aa70f08f3ff5a1969381c13e9811a4e3958715b044270c`.
Its exact-image correctness ledger is
`../whitefoot-consumed-projection-clean/controls/result.json`, SHA-256
`b940ceceec6f481142bce011bf817a3ba9cbdfd214795d07a330378b7c9ffa63`:
4 source admissions and 73 native construction commands exit 0, 26 positive
execution commands exit 0, and 34 deliberate fault controls exit 1 with their
expected diagnostics. All 53 input and 87 artifact pins remain unchanged.
These passed semantic observations do not override the adverse native screen.

The smallest actual paired witness is the retained wide free function
`wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146`.
Its complete raw and optimized bodies are the `a.` and `b.` files with that
symbol under the sibling clean `controls/` directory; the exact native diff is
`map-retained-native.wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146.diff`.
The raw difference removes one 256-byte field snapshot and its allocation,
then supplies the complete enum parent's field address to the same consume
call. The producer, descriptor update, tag switch, and selected callback are
unchanged. The producer is a typed `RunTaken`: `row_take` defines that operation
and returns it; `emit_run_taken` captures the old element address, updates the
descriptor, then emits the complete element transfer.

The optimized witness is schematic below; the cited bodies retain the exact
SSA names and metadata. `slot` is the old physical bucket, `parent` is 272
bytes, and `value` is 256 bytes.

```llvm
; Baseline: parent is removed by scalar replacement.
store i64 %shorter_length, ptr %window
%tag = load i32, ptr %slot
switch i32 %tag, label %invalid [i32 2, label %filled
                               i32 0, label %next
                               i32 1, label %next]
filled:
  %key = load i64, ptr %slot_key
  call void @llvm.memcpy.p0.p0.i64(ptr %value, ptr %slot_value, i64 256, i1 false)
  call i8 @consume(ptr %env, i64 %key, ptr %value)

; Broad candidate: the complete parent survives.
store i64 %shorter_length, ptr %window
call void @llvm.memcpy.p0.p0.i64(ptr %parent, ptr %slot, i64 272, i1 false)
%tag = load i32, ptr %parent
switch i32 %tag, label %invalid [i32 2, label %filled
                               i32 0, label %next
                               i32 1, label %next]
filled:
  %key = load i64, ptr %parent_key
  call i8 @consume(ptr %env, i64 %key, ptr %parent_value)
```

Native A tests the tag first and expands the 256-byte Filled-only copy into
eight `ldp q0, q1` / `stp q0, q1` pairs. Native B calls `_memcpy` with length
272 before `ldr w8, [sp]` and the tag comparison, including Vacant/Deleted
iterations. Its stack reservation changes from 320 to 336 bytes. The second
wide free instantiation has the same changed transfer path.

Retained rebuild has the same obstruction at its one-slot pending owner.
For `wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07`,
the complete raw `.body`, optimized bodies, and native diff are in that same
directory. A's optimized `bb29.i` clears pending length, loads its key, and
passes `pending+16` to exchange. B clears the length, copies 264 bytes into a
separate Pair, then passes that Pair's value field. Both keep the 264-byte
retry-restoration transfer. Native memcpy sites rise from one to two and the
frame from 656 to 928 bytes. The other wide instantiation agrees.

The new callee operand is an interior address of the complete parent. In these
optimized bodies that use prevents the aggregate's former partitioning and
keeps an earlier, larger transfer alive. Removing one raw copy therefore does
not establish fewer native transfers. The exact free-body pair isolates this
placement difference; this report does not claim a pass-by-pass LLVM trace.

This is physical representation traffic, not a demonstrated source-level
uninitialized read. Both raw programs already implement the same complete take
transfer. Both keep the active-variant guard before using the payload. Current
`construct_at` still writes a zero aggregate before active fields; no inactive
initialization policy changes. Padding and inactive representation bytes are
not newly interpreted as a source value. The extra physical copy alone fails
the preregistered no-extra-transfer screen.

## Producer and consumer assessment

| Parent origin | What is established before LLVM | Remaining uncertainty |
|---|---|---|
| Ordinary indirect call result | The ABI initially needs complete result storage. | An internal callee may inline and expose a removable load or construction; `Call` alone does not prove lasting materialization. |
| Window take or other place-loaded result | A complete capture exists in raw emission. | The baseline may reduce it to a tag-first or field-only read; the actual free/rebuild witnesses do so. |
| Direct struct/enum construction | Construction writes the complete representation, then its active fields. | Giving one field's address to a callee can keep otherwise-eliminable siblings or initialization alive. Existing images do not isolate a constructor-only native regression, so none is claimed. |
| Chained local projection | It inherits the root's complete backing. | Flattening its field path cannot establish that the root needs physical materialization. |

A blacklist of take names, measured payloads, or individual opcodes does not
address the shared obstruction. Retaining new provenance metadata solely to
guess LLVM's future inlining would add a second policy without proving the
needed native outcome. Deferring placement until after LLVM inlining would
need a broader lowering/optimization interface and is outside this bounded
experiment. New alias/capture attributes require their own complete contract;
they are not an authorized repair.

## Variant and responsibility

Keep the existing checked consumption, private-parent, complete-layout,
distinct-field, exposure, CFG-transfer and original fixed-point liveness
conditions. Additionally, withhold projection forwarding whenever **any**
`IrOperation::Call` uses any value in the projected value's storage group as an
argument. Apply this to every callee, including compiler rows, synthesized or
potentially inline calls, without inspecting its name, ownership mode, payload
type or size. A further local projection may still borrow; a final aggregate
crossing a call gets its ordinary independent snapshot.

The existing storage planner owns this restriction. It removes the old
consuming-call exception from this new projection mechanism; the separate
`FieldReuse` ABI placement and call-entry capture routines are untouched.
Complete-parent allocation and typed pointer resolution remain shared through
the existing allocation-root routine. No new IR, checker rule, ABI, attributes,
inline policy or liveness engine is introduced. Main's waiting/context fallback
plan remains required on eventual integration.

This conservatively skips safe same-activation owned calls, callbacks, compiler
place operations, and calls that LLVM would inline. It may retain an ultimately
redundant child copy. The reason is to avoid making the parent an additional
callee-visible storage object, not to claim that source consumption is unsafe
or that this rule guarantees LLVM performance.

The actual target remains eligible at the IR-use boundary: put's baseline Pair
`%wf.slot.2` is read only by field projections and enum-constructor memmoves;
the trace's Pair slots 2, 5, 12, 18, 21 and 26 have only field-projection reads
after their defining snapshot. None is an ordinary call operand. Their Record
children reach content/consume calls and now retain captures. Both targeted
264-byte removals must still be observed natively; source eligibility is not
a substitute for that gate.

## Fixed native gate before any runtime or timing

The isolated source begins at commit
`6da90dba09db335c0ea9158fa075f3aecc27e309` plus the exact broad source diff.
`broad-parent.json` verifies all 2,394 frozen input hashes before the local-only
edit. Freeze the complete resulting source manifest, patch, CLI, source inputs,
retention lists and commands before construction. The clean broad image stays
as an adverse diagnostic, while baseline575 remains the selecting A arm.

1. Admit the two authored source fixtures using frozen baseline575 before the
   candidate build. Preserve every direct status and any authoring repair.
2. Build exactly one isolated gate/jobs2 CLI. Construct normal and the previously
   qualified 49-definition public-operation retained Map modules with the same
   source, Clang flags and transformation as the completed broad screen.
3. Require both targeted Pair copies to disappear on the executed ordinary
   Replaced path in **both** modes. Keep the complete parent extent/alignment,
   return ABI, tag guards, initial owned-input capture and cleanup unchanged.
4. Require free's baseline tag-first path, with no payload transfer on
   Vacant/Deleted and only the baseline Filled payload transfer. Require
   rebuild's baseline pre-exchange and retry-restoration transfer paths, with no
   new capture. Check every instantiation, explicit intrinsic, expanded register
   transfer, stack reservation and caller path; a memcpy-name count is not the
   oracle. Inventory every changed function and all outside-function constants.
5. Compare complete Slab O2 normal/retained, Vector O2 normal/retained and O3
   ecosystem, and PriorityQueue O2 normal/retained and O3 ecosystem modules.
   Use the already qualified unchanged callers and exact existing retention
   policies. Preserve source/C/runtime/control bytes. Refuse any newly added
   bulk or expanded transfer path or larger required frame; do not select
   favorable functions or payloads. Any differing body gets a complete path
   account before proceeding.
6. Stop on a failed mechanism gate. No timing, automatic resampling, alternative
   inline policy, native rewrite or producer exception rescues this variant.

The PriorityQueue source is the unchanged maintained `priority-library.wf`;
its baseline575 raw and O3 native are in `../whitefoot-fixed-storage-swap/screen`,
and its O2 transformed normal/retained modules are in that trial's
`practical/control`. The exact retention rules are ten public queue operations
and four callback families, with two trace boundaries retained in both modes;
use the already preserved `practical/result.json` commands. Slab and Vector
reuse the completed clean `controls/` source transport, modules and lists.

Source fixtures cover a nested owning call-result projection whose Pair remains
local while the Wide child crosses a call, the same chain read locally, and
a directly constructed padded parent with a live independent Copy payload.
The latter compares a call consumer with a local consumer at a different
payload size. Existing value, ownership, partial-cleanup, exposure and loop
reentry observations remain unchanged. The broad test's two-forwarded-fields
expectation is explicitly replaced by one local view plus one call snapshot;
the new local-only positive retains the original two-level observation.

Admission, tests and native construction are not yet run. Expected first-stage
cost is roughly 50–65 seconds for the CLI plus 10–20 seconds for the complete
native inventory, serialized under the shared guard after the assigned phases.
Root reviews this criterion before that command. Only a successful native gate
can justify constructing the focused test harness and re-running full exact-
image semantics/accounting/faults. The long Map/triggered-control protocol stays
unexecuted until those new images and results are independently reviewed.
