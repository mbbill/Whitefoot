# Consuming projection: qualified controls and one timing protocol

Prepared before any projection performance samples. This operational plan
implements the criterion frozen in `native/criterion.md`; it does not replace
the source, native-mechanism, ownership, or independent-oracle requirements.
Long timing remains deferred until the trigger inventory and the exact images'
checks have been reviewed. No compiler rebuild or main merge is part of it.

## Images and helper modes

A is the frozen compiler at `5753999f224f89a9a99e0399b76bfd7b92cd53d5f22b0d204df4f2ec3ffbc20b`.
B is the clean projection-only compiler at
`f575555aa641f6cbd2aa70f08f3ff5a1969381c13e9811a4e3958715b044270c`.
The normal Map images and their complete raw/native comparison are already
qualified in `native/`; the rejected PQ and Deque factors are absent.

Normal Map uses ordinary O3 optimization and the original timed allocation
path. Retained Map is diagnostic: add `noinline` to the existing public
new/put/remove/lookup/edit/reserve/rehash/free definitions and eight named
callbacks, translating only the imported library's qualified symbol prefix.
Keep the two external trace boundaries. The complete 49-definition list and
added attribute are frozen in `controls/map-retention-plan.json` and must be
equal in A and B. This includes generated `.body` versions selected by the
existing operation-prefix policy, but not arbitrary internal helpers.

Compile the existing C control with its existing `RETAIN_HELPERS` macro for
this diagnostic mode. Freeze that object once and reuse it in both images.
The original driver, ordinary Rust/std C++/Abseil objects, runtime objects,
link ordering, allocation contract and oracle remain unchanged. Ordinary peer
ratios in retained mode are descriptive; the owner's practical target is
evaluated on normal public use. Completed semantic images retaining all 131
source definitions are separate evidence, never relabeled as these images.

Before timing, run the existing complete primary/occupancy checks, geometry,
accounting and negative checksum/cleanup/reserve/geometry controls on both new
retained images. Require the original expected diagnostics and accounting
bytes, including 420 primary, 160 occupancy and 140 geometry rows. Preserve
each direct status, and build cost separately from execution cost. No repeated
owner-corpus build is needed; the independent generic-owner tests already
ran in ordinary and all-call-retained forms with the same compiler images.

## Trigger inventory and source transport

Emit both frozen compilers from identical current control sources. Inventory
every raw definition, ABI header, type/global and changed optimized/native
function, preserving registers, constants, operands and callees. Native
comparison may normalize only assembly comments/blank lines and local label
numbering; preserve the normalization rule and full differences. Do not infer
that a control is unaffected merely from one selected loop or a memcpy count.

Slab uses the maintained std module and the existing comparison source with
only eight aliases added, six `deref(env)` spellings changed to `env^`, and two
`deref(value)` spellings changed to `value^`. The expanded callback arguments
are still admitted by FN-3, so they remain byte-for-byte unchanged. There are
no adapters, loop/branch changes, different capacities, or new payloads.
`controls/slab-transport.patch` contains the entire source change; the original
source is preserved beside it. Replace the removed `lib/containers/slab.wf`
build input with the embedded current std module. Translate the historical
retention selector to include std-qualified Slab helpers plus the same local
Slab workload/member helpers, leaving compiler primitive bodies optimizable.
The C driver, independent oracle and operation contract remain byte-identical.
Qualify source admission, O2 normal/retained native code and all existing
1,728 Slab correctness executions per compiler across both modes.

Vector uses unchanged current `vector-library.wf`, whose SHA256 is
`7feb508efa973f65b4fac5c044ec4eeacad78382d157bbfe1e10ba20d1ad8b7a`.
The baseline raw module must reproduce the existing qualified module hash
`22e03e27bba9dd075d7d6f86a40e52b2f0caea746c36b50e60424aa11527a73d`.
Inventory O2 normal/retained using the current Makefile selector, plus O3
ordinary ecosystem code. Reuse the independently pinned ecosystem peers and
runtime objects from `whitefoot-vector-source-controller/continuation/native-inputs.json`.
Reconstruct the small O2 C controls, since no existing current retained pair
has a qualified provenance. Run existing full checks for images whose code
changes. If all control functions/constants are identical in both modes,
record nontriggering equality; do not substitute unrelated timing results.

Any changed Slab or Vector body triggers that family's complete existing
matrix in both helper modes, with its unchanged C controls. A changed normal
Vector ecosystem body additionally triggers the complete ordinary-peer
matrix. This inventory is a prerequisite, not a discretionary exclusion after
looking at timings. Build/check estimates are about 10–20 seconds construction
plus 20–30 seconds execution, using existing frozen compilers/runtime/peers;
actual costs are recorded and an overrun is investigated before extension.

## Independent null observations with a shared A anchor

Use exactly three separately executed arms: `A-null`, `A-anchor`, and `B`.
Both A arms use the same frozen A image. Prerecord `A-anchor` as the baseline
for both comparisons: null = A-null/A-anchor; effect = B/A-anchor. No sample
from A-null is reused as an observation from A-anchor. All three sets are
preserved once; reductions refer to the same anchor rows explicitly.

This removes one redundant A execution from four-arm A/A plus A/B, saving
25% of timing work. Null and effect share a denominator and are correlated;
they are not independent statistical trials or confidence intervals. The
existing descriptive discriminator is unchanged: independent A executions
set each cell's null screen before its B/A effect is judged against it.

Map order is fixed in twelve bounded batches:

| Cohort | Mode order | Arm order within each mode |
|---|---|---|
| 0 | normal, retained | A-null, A-anchor, B |
| 1 | retained, normal | B, A-anchor, A-null |

Each batch runs the full `measure COHORT 1048576`, then full
`occupancy-measure COHORT 1048576`. Each command retains its separate stdout,
stderr, direct status and elapsed cost. Use the unchanged eleven samples,
seeds 101–111, two checked warmups, rotating implementation order, reversed
cohort order and every currently selected path. Neither the former shorter
262144 setting nor a convenient submatrix is substituted.

Per arm/mode: primary has 84 WF cells (two payloads, three shapes, seven paths,
two hash series), five implementations, eleven samples and two cohorts =
9,240 rows. Occupancy has 32 WF cells (two payloads, four capacities, four
paths, aligned hash), five implementations, eleven samples and two cohorts =
3,520 rows. Three arms and two modes therefore produce 76,560 distinct Map
rows, including all ordinary peers and C controls. The reused anchor is not
counted twice. Historical normal execution costs are 307.876 + 51.879 seconds
per arm/mode, giving 2,158.53 seconds (35.98 minutes) before triggered controls.
Retained cost can differ; this is an estimate, not a timeout selecting results.

Serialize every batch with the shared guard. Release between batches when
root's queue requires it. Freeze every executable/input hash before timing;
check it before and after every batch. No source mutation, compiler rebuild,
concurrent benchmark, sample discard, timing replay or alternate emission.

## Per-cell selection and limits

Use the existing monotonic-clock implementation and the existing 10,000-probe
minimum-positive-delta calibration, in one small standalone scratch carrier.
Its two clock functions are copied unchanged from `map-costs.c`; it is needed
because the current ecosystem driver has no clock-quantum command. It does
not alter a timed executable or timing loop. Calibrate before each batch and
retain all clock observations. For screening use the largest observed quantum
across participating batches.

Join samples by family, cell, helper mode, cohort, seed and work/trace counts.
Report the median of per-sample raw B/A ratios and of the C-normalized ratio
`(B_WF/B_C)/(A-anchor_WF/A-anchor_C)`, rather than a ratio of unpaired medians.
Report both ordinary peer ratios separately and the C timing drift. For each
cell/mode, its margin is the maximum of 3%, either cohort's absolute raw or
C-normalized null deviation from 1, and `((t_min+q)/(t_min-q))^2-1`, with
`t_min` the shortest participating interval. An interval at/below `q` cannot
select a gain. Keep every cell, tail, run and cohort separate.

The mechanistic primary is wide replacement at capacity/count 4096/3584,
under both native-default and aligned hashing. Require improvement beyond
the cell's screen in both cohorts and both helper modes, with raw and
C-normalized direction agreeing. Publish all other wide-replacement cells
and all other paths; no unexplained material regression in any triggered
Map/Slab/Vector cell is allowed. This exact population is identified before
timing because it is the frozen occupancy native path that motivated the
factor, not because of measured candidate results.

Judge the practical target only in normal mode against the median-slower
ordinary Rust/std C++ peer per cell, retaining both peer ratios. Use the
existing minimum-duration (1 ms) and cohort-spread (10%) qualification;
in both cohorts require the largest WF sample to be below the smallest
sample of that selected peer. Report unqualified cells as unranked and
qualified overlapping ranges as inconclusive. A projection gain is not a claim of
meeting the owner's target, and retained diagnostic rows cannot establish it.
Abseil remains an additional reference. Ambiguity or a failed criterion
leaves the optimization unselected.

## Triggered-family batch counts

If triggered, Slab runs its unchanged `measure` command twice per arm/mode,
with the existing reversed normal/retained outer-run order. Each command
already contains two cohorts, two payloads, three paths, three counts,
eleven seeds and three variants = 1,188 rows. Three arms, two modes and two
outer runs give 14,256 rows. Historical full two-mode/two-run cost including
checks was 5.42 seconds per arm; estimate 16–25 seconds for three arms.

If triggered, Vector O2 runs unchanged `measure` per arm/mode. It contains
two cohorts, two payloads, thirteen selected path/count pairs, eleven seeds
and five variants = 2,860 rows, giving 17,160 rows across the three arms and
two modes. All C alternatives stay visible; screen against both reverse-C
and direct-C, preserving the worse null envelope. If its O3 ecosystem code
changes, add the full existing `measure 1048576 7` per arm: 4,116 rows each,
12,348 total, estimated about four minutes from recent ~80-second images.
Do not execute any of these optional stages until the native inventory says
which are triggered and their exact image checks pass.

The waiting/main compatibility assessment is in `main-integration-plan.md`.
Its conservative exclusions and new-boundary regressions precede any final
integration; frozen timing does not merge or change main's waiting semantics.
