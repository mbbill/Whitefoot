# Clean consuming-projection Map mechanism screen

This screen isolates the consuming-projection compiler change after the rejected
PQ scratch and Deque fact candidates were withdrawn. It performs emission,
optimization, assembly and linking only: no Map program or timing loop ran.

## Frozen inputs and construction

- Source HEAD: `6da90dba09db335c0ea9158fa075f3aecc27e309`; 2,394 source inputs in `../source-freeze.json`.
- Baseline CLI: `5753999f224f89a9a99e0399b76bfd7b92cd53d5f22b0d204df4f2ec3ffbc20b`.
- Candidate CLI: `f575555aa641f6cbd2aa70f08f3ff5a1969381c13e9811a4e3958715b044270c`.
- Original `map-library.wf`, original drivers/Rust/C++/control/runtime objects
  and original link configuration are pinned in `inputs-before.json`.
- Candidate gate/jobs2 CLI build: direct 0, 49.841978 s; outer guard 50.17 s.
- Native construction: every direct status 0; outer guard 4.33 s.
- Baseline raw reproduces the original frozen raw byte for byte, SHA256
  `0adce0bf092ea45ea2b4d2b8ff6d81b2e79fa3d516563da6a9739b0cbfa736a7`.
- Candidate raw SHA256:
  `31b4d815fc21d2647b25b34ecbfa9edf9284d8f55c5cd68cd7c93d5608db38ce`.
- All frozen native inputs matched their pins after construction. The CLI build
  checked every source pin both before and after construction.

## Complete change inventory

All 134 raw definition headers are identical. All raw text outside functions
(types, globals, declarations and attributes) is byte-identical. Seven raw
functions change; all retain their block names, branches, returns and ordered
non-memmove callees (only temporary register numbers normalized for the CFG
comparison). `screen-inventory.json` and `branch-call-qualification.json` give
full function identities and counts; each changed body has its own full diff.

| Raw function suffix | Raw memmove calls, baseline → candidate | Native memcpy calls | Native maximum CFA offset |
| --- | ---: | ---: | ---: |
| trace `4250cb78d3f44027` | 14 → 2 | 12 → 3 | 8,048 → 4,560 |
| put `28da32efc51c2b65` | 6 → 5 | 2 → 1 | 1,136 → 864 |
| put `8d5197e2f00c3b07` | 6 → 5 | 2 → 1 | 1,136 → 864 |
| free `72d84b2e6d0b7146` | 2 → 1 | identical native | unchanged |
| free `d5f8785ab7665d71` | 2 → 1 | identical native | unchanged |
| rebuild `28da32efc51c2b65.body` | 6 → 3 | 2 → 0 (wrapper) | 672 → 656 |
| rebuild `8d5197e2f00c3b07.body` | 6 → 3 | 2 → 0 (wrapper) | 672 → 656 |

Exactly those five non-free functions change among 109 native functions.
Native comparison retains registers, offsets, instructions, constants and
callees, normalizing only comments and assembler local label names. Assembly
outside the function ranges is byte-identical. Word traces, swap, try_put,
exchange, lookup, remove, callbacks and all other function bodies remain equal.

## The ordinary wide replacement path

The source path is the `path == 2` replacement arm in `map-library.wf`:
prepopulation inserted each queried key, replacement calls put on the same key,
and then consumes its returned pair. The below trace follows Returned tag 1,
Replaced reason 0, including each branch; this is static path qualification,
not a claim that this screen executed the program.

Baseline linked code calls try_put at `0x100006c10`, checks tag at `6c14`/`6c1c`,
loads reason at `6c2c`, copies Pair264 at `0x100006c3c`, and takes reason-zero
branch `6c40 → 70c8`. The returned-enum constructor copies Pair264 at
`0x1000070e8`; the caller's consumed enum projection copies it at
`0x100007104`. A following 256-byte load/store sequence materializes the
record projection before content arithmetic.

Candidate calls try_put at `0x1000067ec`, checks tag at `67f0`/`67f8` (invalid
branch `6800`), loads reason at `6808`, and takes `680c → 6c1c`. No intervening
projection copy executes. Its single Pair264 transfer at `0x100006c34` builds
the returned enum. Following arithmetic reads the pair key at `6c78` and record
words at `6c7c` onward directly in that complete returned parent. The two
selected 264-byte projection copies, and the subsequent register-expanded
256-byte record projection, disappear without replacement copies on this path.
The initial 256-byte owned call argument snapshot is retained.

Both complete excerpts are in `*-replacement-result-excerpt.txt`; the complete
function disassembly is in `*.wide-trace.disassembly`. Full assembly, raw and
optimized definitions are also retained.

## Complete parent, ABI and other branches

Pair has an i64 key plus a 256-byte record, giving size 264/alignment 8. Its
parent HashMapPut retains tag, reason and pair, size 272/alignment 8. The
standalone put frame changes from `[Record256, Enum272, Pair264, Result8,
Record256]` (1,056 bytes) to `[Record256, Enum272, Result8, Record256]` (792
bytes), both align 8. The complete Enum272 parent remains, as do the initial
argument snapshot and separate retry record snapshot. The public header and
return destination are unchanged; the frame is reduced only by the independent
Pair264 slot. Native total frame includes saved registers and alignment.

The original tag/reason guards and all original CFG edges remain. In standalone
put's optimized IR and native code:

- Inserted returns the original initialized complete enum, with no payload read.
- Replaced reconstructs Returned using the one remaining Pair264 constructor
  copy, directly from the attempted parent's active field.
- Full at the capacity ceiling reconstructs the original Full result using that
  same active field; no retry occurs.
- Full below the ceiling calls reserve/rebuild while the complete attempted
  parent remains in its frame. Reserve failure reconstructs Full. Reserve
  success projects the key and retains a separate Record256 snapshot before
  retrying try_put into the original result destination.
- The trace's initial fill, remove/reinsert, replacement and rehash arms retain
  their original tag/reason branches and non-copy callees. Only private consumed
  projections are removed; raw trace has the same complete CFG.
- Rebuild removes a filled-slot record projection, a consumed Pair record
  projection before exchange, and the returned active Pair projection. It keeps
  the complete slot/Pair/enum producers and constructor/window copies.
- Free removes the private consumed filled-slot record snapshot before its
  owning consume callback. The existing native optimizer already erased that
  snapshot, so both free native bodies remain identical.

The first three-image screen had demonstrated that rejected PQ changes affected
Map raw/native output. Its `afa→123` comparison was conditional only. This clean
screen compares the original frozen575 directly to the selected-base compiler;
the rejected PQ/Deque factors do not remain in the comparison.

## Interpretation and next discriminator

The preregistered two-copy/complete-parent/public-ABI mechanism criterion is
satisfied in this clean native screen. Performance is unmeasured. The earlier
combined-source focused tests passed 27 storage and 36 owned-place cases,
including ordinary/retained cleanup and wrong-result controls, but those are
not a substitute for clean-candidate Map correctness. Next prepare/run the
unchanged Map oracle, owning-pair observer, allocation-accounting and fault
controls with these qualified images. Timing still waits for root review of
native and correctness evidence.
