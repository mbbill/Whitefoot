### Prospective consuming-projection storage comparison

This independent compiler factor tests the currently required snapshots of a
private active payload. It does not change Map's control metadata, source API,
inactive initialization or inline policy. The pending
[storage proposal](../../../../design/amendments/consumed-projection-storage.md)
keeps each complete parent allocation and forwards only a typed immutable
projection whose original CFG establishes that its parent cannot be rewritten
while that child is live. Its implementation belongs to the existing storage
planner; an additional liveness engine or a source-language rule is outside
this comparison.

The frozen occupancy image's ordinary wide replacement executes three
264-byte transfers after `hash_map_try_put`: active Pair projection in
`hash_map_put`, construction of its returned enum, and the caller's active
Pair projection. The selected tag follows the first transfer to the latter
two. The candidate targets the two projections. The middle constructor
transfer and the 256-byte `try_put` argument snapshot are not grounds for
removing their existing semantics. This mapping must be re-established on
the exact A image used below; a historical address alone does not identify a
site in a new image.

Before constructing or timing B, freeze source manifests and compiler hashes
for A and B. A is the exact current compiler input with this projection factor
absent; B differs only by this factor. Keep all Map sources, native controls,
runtime objects, commands and optimization settings identical. Keep this
comparison separate from the prospective Map metadata-layout comparison.

The structural screen is fixed before running it:

1. Trace the ordinary wide Replaced path in raw LLVM, optimized LLVM and the
   linked native image. Require both projection transfers to disappear from
   that executed path. Count remaining bulk and register-expanded transfers,
   not just `memcpy` names. If either projection remains, stop without timing.
2. Require the complete parent to retain its qualified size and alignment,
   unchanged active-variant guards and cleanup, the ordinary captured-input
   contract, and no additional bulk scalarization or inactive-data reads.
   Inspect Full, grow/retry, Inserted and all selected native variants as well
   as Replaced. A smaller result must never back its larger parent.
3. Run independent value and allocation/release observations in normal and
   retained-call modes. Cover generic owning payloads, padded parent fields,
   residual cleanup, intervening calls, an exposed Copy parent written before
   an owned argument is read, whole-parent or repeated-field use, nonidentity
   CFG input, and a previous iteration's child surviving the next parent
   construction. Withhold forwarding for schedules whose reads can outlive
   the synchronous call. Exercise each new observation with a deliberate
   wrong value or missing/reordered cleanup, then restore the candidate.

Only after the screen and correctness checks pass, run one fresh A/A plus
A/B protocol using the existing complete Map matrix, unchanged seeds, two
cohorts, normal/retained modes, allocation oracle and raw samples. Keep
per-cell null and clock-quantum screens; never replace them with a pooled
median. Require ordinary wide replacement to improve beyond its screen in
both cohorts, and no unexplained material regression elsewhere in the
triggered Map, Slab and Vector controls. Retain both ordinary Rust and C++
peer ratios and judge the owner goal against the slower peer for each cell;
this mechanism's improvement alone does not establish that goal. Allow no
timing replay or alternate-emission rescue in this discriminator. Ambiguity
or a failed criterion leaves the proposal unselected.

Compiler construction and the canonical gate remain separate from artifact
construction, correctness execution and timing. Each heavy stage needs the
shared host guard and an assigned slot; record its actual elapsed cost and
investigate an overrun before extending it. Native mechanism and performance
selection remain pending.
