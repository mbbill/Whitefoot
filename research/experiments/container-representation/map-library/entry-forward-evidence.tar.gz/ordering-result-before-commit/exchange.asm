00000001000acb14 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449.disjoint_floor>:
1000acb14:     	sub	sp, sp, #0x130
1000acb18:     	stp	x28, x27, [sp, #0x100]
1000acb1c:     	stp	x20, x19, [sp, #0x110]
1000acb20:     	stp	x29, x30, [sp, #0x120]
1000acb24:     	mov	x19, x3
1000acb28:     	ldp	q0, q1, [x4, #0xc0]
1000acb2c:     	stp	q0, q1, [sp, #0xc0]
1000acb30:     	ldp	q0, q1, [x4, #0xe0]
1000acb34:     	stp	q0, q1, [sp, #0xe0]
1000acb38:     	ldp	q0, q1, [x4, #0x80]
1000acb3c:     	stp	q0, q1, [sp, #0x80]
1000acb40:     	ldp	q0, q1, [x4, #0xa0]
1000acb44:     	stp	q0, q1, [sp, #0xa0]
1000acb48:     	ldp	q0, q1, [x4, #0x40]
1000acb4c:     	stp	q0, q1, [sp, #0x40]
1000acb50:     	ldp	q0, q1, [x4, #0x60]
1000acb54:     	stp	q0, q1, [sp, #0x60]
1000acb58:     	ldp	q0, q1, [x4]
1000acb5c:     	stp	q0, q1, [sp]
1000acb60:     	ldp	q0, q1, [x4, #0x20]
1000acb64:     	mov	w8, #0x110              ; =272
1000acb68:     	stp	q0, q1, [sp, #0x20]
1000acb6c:     	ldr	x9, [x1, #0x10]
1000acb70:     	madd	x20, x2, x8, x9
1000acb74:     	ldr	w8, [x20]
1000acb78:     	cmp	w8, #0x1
1000acb7c:     	b.hi	0x1000acbac <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449.disjoint_floor+0x98>
1000acb80:     	movi.2d	v0, #0000000000000000
1000acb84:     	stp	q0, q0, [x0, #0xf0]
1000acb88:     	stp	q0, q0, [x0, #0xd0]
1000acb8c:     	stp	q0, q0, [x0, #0xb0]
1000acb90:     	stp	q0, q0, [x0, #0x90]
1000acb94:     	stp	q0, q0, [x0, #0x70]
1000acb98:     	stp	q0, q0, [x0, #0x50]
1000acb9c:     	stp	q0, q0, [x0, #0x30]
1000acba0:     	stp	q0, q0, [x0, #0x10]
1000acba4:     	str	q0, [x0]
1000acba8:     	b	0x1000acbc4 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449.disjoint_floor+0xb0>
1000acbac:     	str	xzr, [x0]
1000acbb0:     	mov	w8, #0x1                ; =1
1000acbb4:     	str	w8, [x0], #0x8
1000acbb8:     	add	x1, x20, #0x8
1000acbbc:     	mov	w2, #0x108              ; =264
1000acbc0:     	bl	0x1000b4d58 <_writev+0x1000b4d58>
1000acbc4:     	stp	xzr, x19, [x20]
1000acbc8:     	mov	w8, #0x2                ; =2
1000acbcc:     	str	w8, [x20]
1000acbd0:     	ldp	q0, q1, [sp, #0xc0]
1000acbd4:     	stp	q0, q1, [x20, #0xd0]
1000acbd8:     	ldp	q0, q1, [sp, #0xe0]
1000acbdc:     	stp	q0, q1, [x20, #0xf0]
1000acbe0:     	ldp	q0, q1, [sp, #0x80]
1000acbe4:     	stp	q0, q1, [x20, #0x90]
1000acbe8:     	ldp	q0, q1, [sp, #0xa0]
1000acbec:     	stp	q0, q1, [x20, #0xb0]
1000acbf0:     	ldp	q0, q1, [sp, #0x40]
1000acbf4:     	stp	q0, q1, [x20, #0x50]
1000acbf8:     	ldp	q0, q1, [sp, #0x60]
1000acbfc:     	stp	q0, q1, [x20, #0x70]
1000acc00:     	ldp	q0, q1, [sp]
1000acc04:     	stp	q0, q1, [x20, #0x10]
1000acc08:     	ldp	q0, q1, [sp, #0x20]
1000acc0c:     	stp	q0, q1, [x20, #0x30]
1000acc10:     	ldp	x29, x30, [sp, #0x120]
1000acc14:     	ldp	x20, x19, [sp, #0x110]
1000acc18:     	ldp	x28, x27, [sp, #0x100]
1000acc1c:     	add	sp, sp, #0x130
1000acc20:     	ret

