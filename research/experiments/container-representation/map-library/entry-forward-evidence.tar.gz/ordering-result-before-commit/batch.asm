00000001000a4be8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027>:
1000a4be8:     	stp	x28, x27, [sp, #-0x60]!
1000a4bec:     	stp	x26, x25, [sp, #0x10]
1000a4bf0:     	stp	x24, x23, [sp, #0x20]
1000a4bf4:     	stp	x22, x21, [sp, #0x30]
1000a4bf8:     	stp	x20, x19, [sp, #0x40]
1000a4bfc:     	stp	x29, x30, [sp, #0x50]
1000a4c00:     	sub	sp, sp, #0x210
1000a4c04:     	str	x2, [sp, #0x130]
1000a4c08:     	ldr	x9, [x0, #0x38]
1000a4c0c:     	str	x1, [sp, #0x10]
1000a4c10:     	cbz	x1, 0x1000a5524 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x93c>
1000a4c14:     	ldp	x8, x10, [x0, #0x40]
1000a4c18:     	str	x8, [sp, #0x140]
1000a4c1c:     	cbz	x8, 0x1000a5518 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x930>
1000a4c20:     	mov	x11, #0x0               ; =0
1000a4c24:     	ldr	x8, [x0, #0x28]
1000a4c28:     	str	x8, [sp, #0x128]
1000a4c2c:     	ldrb	w8, [x0, #0x30]
1000a4c30:     	str	w8, [sp, #0x14c]
1000a4c34:     	mov	w13, #0x1               ; =1
1000a4c38:     	mov	w23, #0x110             ; =272
1000a4c3c:     	mov	w4, #0x83               ; =131
1000a4c40:     	movi.2d	v0, #0000000000000000
1000a4c44:     	ldp	x1, x8, [x0, #0x18]
1000a4c48:     	str	x8, [sp, #0x28]
1000a4c4c:     	mov	x12, x9
1000a4c50:     	str	x0, [sp, #0x150]
1000a4c54:     	str	x9, [sp, #0x8]
1000a4c58:     	b	0x1000a4c74 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x8c>
1000a4c5c:     	ldp	x11, x10, [sp, #0x18]
1000a4c60:     	str	x10, [x0, #0x48]
1000a4c64:     	add	x11, x11, #0x1
1000a4c68:     	ldp	x9, x8, [sp, #0x8]
1000a4c6c:     	cmp	x11, x8
1000a4c70:     	b.eq	0x1000a5528 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x940>
1000a4c74:     	mov	x20, #0x0               ; =0
1000a4c78:     	add	x10, x10, #0x1
1000a4c7c:     	stp	x11, x10, [sp, #0x18]
1000a4c80:     	ldr	x8, [sp, #0x140]
1000a4c84:     	madd	x8, x10, x8, x9
1000a4c88:     	str	x8, [sp, #0x138]
1000a4c8c:     	b	0x1000a4d98 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x1b0>
1000a4c90:     	stp	x20, x1, [sp, #0x168]
1000a4c94:     	mov	w3, #0x1                ; =1
1000a4c98:     	strb	w3, [sp, #0x20c]
1000a4c9c:     	mov	x12, x14
1000a4ca0:     	stp	x21, x24, [sp, #0x158]
1000a4ca4:     	mov	x21, x19
1000a4ca8:     	mov	x14, x16
1000a4cac:     	ldp	x0, x16, [sp, #0x1c0]
1000a4cb0:     	mov	x23, x25
1000a4cb4:     	ldp	x13, x25, [sp, #0x1b0]
1000a4cb8:     	ldp	x5, x20, [sp, #0x1a0]
1000a4cbc:     	ldp	x19, x1, [sp, #0x190]
1000a4cc0:     	ldr	x17, [sp, #0x1d8]
1000a4cc4:     	ldp	x10, x24, [sp, #0x180]
1000a4cc8:     	ldr	x11, [sp, #0x178]
1000a4ccc:     	madd	x8, x22, x4, x30
1000a4cd0:     	madd	x8, x8, x4, x11
1000a4cd4:     	madd	x8, x8, x4, x10
1000a4cd8:     	ldrb	w10, [sp, #0x20c]
1000a4cdc:     	tst	w10, #0x1
1000a4ce0:     	madd	x8, x8, x4, x24
1000a4ce4:     	cinc	x10, x3, ne
1000a4ce8:     	madd	x8, x8, x4, x17
1000a4cec:     	madd	x8, x8, x4, x19
1000a4cf0:     	madd	x8, x8, x4, x1
1000a4cf4:     	madd	x8, x8, x4, x5
1000a4cf8:     	madd	x8, x8, x4, x20
1000a4cfc:     	madd	x8, x8, x4, x13
1000a4d00:     	ldr	x11, [sp, #0x1d0]
1000a4d04:     	madd	x8, x8, x4, x11
1000a4d08:     	madd	x8, x8, x4, x28
1000a4d0c:     	madd	x8, x8, x4, x27
1000a4d10:     	madd	x8, x8, x4, x26
1000a4d14:     	madd	x8, x8, x4, x23
1000a4d18:     	madd	x8, x8, x4, x25
1000a4d1c:     	madd	x8, x8, x4, x0
1000a4d20:     	madd	x8, x8, x4, x16
1000a4d24:     	madd	x8, x8, x4, x14
1000a4d28:     	ldr	x14, [sp, #0x1e8]
1000a4d2c:     	madd	x8, x8, x4, x14
1000a4d30:     	madd	x8, x8, x4, x7
1000a4d34:     	madd	x8, x8, x4, x2
1000a4d38:     	madd	x8, x8, x4, x15
1000a4d3c:     	madd	x8, x8, x4, x21
1000a4d40:     	ldp	x0, x11, [sp, #0x150]
1000a4d44:     	madd	x8, x8, x4, x11
1000a4d48:     	ldr	x11, [sp, #0x1e0]
1000a4d4c:     	madd	x8, x8, x4, x11
1000a4d50:     	madd	x8, x8, x4, x9
1000a4d54:     	ldp	x11, x9, [sp, #0x1f0]
1000a4d58:     	madd	x8, x8, x4, x11
1000a4d5c:     	madd	x8, x8, x4, x6
1000a4d60:     	add	x9, x9, x12
1000a4d64:     	madd	x8, x8, x4, x9
1000a4d68:     	ldp	x9, x20, [sp, #0x160]
1000a4d6c:     	add	x9, x10, x9
1000a4d70:     	madd	x8, x8, x4, x9
1000a4d74:     	ldr	x9, [sp, #0x200]
1000a4d78:     	madd	x12, x8, x4, x9
1000a4d7c:     	mov	w23, #0x110             ; =272
1000a4d80:     	ldr	x1, [sp, #0x170]
1000a4d84:     	mov	w13, #0x1               ; =1
1000a4d88:     	add	x20, x20, #0x1
1000a4d8c:     	ldr	x8, [sp, #0x140]
1000a4d90:     	cmp	x20, x8
1000a4d94:     	b.eq	0x1000a4c5c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x74>
1000a4d98:     	orr	x22, x13, x20, lsl #1
1000a4d9c:     	ldr	x8, [sp, #0x130]
1000a4da0:     	cbz	x8, 0x1000a4fc0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x3d8>
1000a4da4:     	mov	x14, x12
1000a4da8:     	cbz	x1, 0x1000a4fd4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x3ec>
1000a4dac:     	ldr	w8, [sp, #0x14c]
1000a4db0:     	tbz	w8, #0x0, 0x1000a4dc4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x1dc>
1000a4db4:     	mov	x8, #0x0                ; =0
1000a4db8:     	ldr	x9, [x0]
1000a4dbc:     	cbnz	x9, 0x1000a4e08 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x220>
1000a4dc0:     	b	0x1000a4fd4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x3ec>
1000a4dc4:     	ldr	x8, [sp, #0x128]
1000a4dc8:     	eor	x8, x8, x22
1000a4dcc:     	eor	x8, x8, x8, lsr #30
1000a4dd0:     	mov	x9, #0xe5b9             ; =58809
1000a4dd4:     	movk	x9, #0x1ce4, lsl #16
1000a4dd8:     	movk	x9, #0x476d, lsl #32
1000a4ddc:     	movk	x9, #0xbf58, lsl #48
1000a4de0:     	mul	x8, x8, x9
1000a4de4:     	eor	x8, x8, x8, lsr #27
1000a4de8:     	mov	x9, #0x11eb             ; =4587
1000a4dec:     	movk	x9, #0x1331, lsl #16
1000a4df0:     	movk	x9, #0x49bb, lsl #32
1000a4df4:     	movk	x9, #0x94d0, lsl #48
1000a4df8:     	mul	x8, x8, x9
1000a4dfc:     	eor	x8, x8, x8, lsr #31
1000a4e00:     	ldr	x9, [x0]
1000a4e04:     	cbz	x9, 0x1000a4fd4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x3ec>
1000a4e08:     	udiv	x10, x8, x9
1000a4e0c:     	msub	x10, x10, x9, x8
1000a4e10:     	ldr	x11, [x0, #0x10]
1000a4e14:     	mov	x12, x9
1000a4e18:     	b	0x1000a4e30 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x248>
1000a4e1c:     	add	x8, x10, #0x1
1000a4e20:     	cmp	x8, x9
1000a4e24:     	csinc	x10, xzr, x10, hs
1000a4e28:     	subs	x12, x12, #0x1
1000a4e2c:     	b.eq	0x1000a4fd4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x3ec>
1000a4e30:     	madd	x8, x10, x23, x11
1000a4e34:     	ldr	w13, [x8]
1000a4e38:     	cmp	w13, #0x1
1000a4e3c:     	b.eq	0x1000a4e1c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x234>
1000a4e40:     	cmp	w13, #0x2
1000a4e44:     	b.ne	0x1000a4fd4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x3ec>
1000a4e48:     	ldr	x13, [x8, #0x8]
1000a4e4c:     	cmp	x13, x22
1000a4e50:     	b.ne	0x1000a4e1c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x234>
1000a4e54:     	ldp	x27, x10, [x8, #0x10]
1000a4e58:     	ldp	x11, x9, [x8, #0x20]
1000a4e5c:     	stp	x11, x10, [sp, #0x1f8]
1000a4e60:     	str	x9, [sp, #0x1f0]
1000a4e64:     	ldp	x13, x11, [x8, #0x30]
1000a4e68:     	ldp	x17, x16, [x8, #0x40]
1000a4e6c:     	str	x1, [sp, #0x170]
1000a4e70:     	ldp	x0, x1, [x8, #0x50]
1000a4e74:     	ldp	x2, x3, [x8, #0x60]
1000a4e78:     	mov	w9, #0x1                ; =1
1000a4e7c:     	ldp	x5, x15, [x8, #0x70]
1000a4e80:     	ldp	x7, x6, [x8, #0x80]
1000a4e84:     	ldp	x21, x19, [x8, #0x90]
1000a4e88:     	ldp	x24, x10, [x8, #0xa0]
1000a4e8c:     	stp	x10, x11, [sp, #0x1e0]
1000a4e90:     	ldp	x25, x26, [x8, #0xb0]
1000a4e94:     	ldp	x28, x30, [x8, #0xc0]
1000a4e98:     	ldp	x11, x10, [x8, #0xd0]
1000a4e9c:     	stp	x10, x11, [sp, #0x1d0]
1000a4ea0:     	ldp	x11, x10, [x8, #0xe0]
1000a4ea4:     	stp	x10, x11, [sp, #0x1c0]
1000a4ea8:     	str	w9, [x8]
1000a4eac:     	stur	q0, [x8, #0x8]
1000a4eb0:     	stur	q0, [x8, #0x18]
1000a4eb4:     	stur	q0, [x8, #0x28]
1000a4eb8:     	stur	q0, [x8, #0x38]
1000a4ebc:     	stur	q0, [x8, #0x48]
1000a4ec0:     	stur	q0, [x8, #0x58]
1000a4ec4:     	stur	q0, [x8, #0x68]
1000a4ec8:     	stur	q0, [x8, #0x78]
1000a4ecc:     	stur	q0, [x8, #0x88]
1000a4ed0:     	stur	q0, [x8, #0x98]
1000a4ed4:     	stur	q0, [x8, #0xa8]
1000a4ed8:     	stur	q0, [x8, #0xb8]
1000a4edc:     	stur	q0, [x8, #0xc8]
1000a4ee0:     	stur	q0, [x8, #0xd8]
1000a4ee4:     	ldp	x11, x12, [x8, #0xf0]
1000a4ee8:     	stur	q0, [x8, #0xe8]
1000a4eec:     	ldp	x9, x10, [x8, #0x100]
1000a4ef0:     	stur	q0, [x8, #0xf8]
1000a4ef4:     	str	xzr, [x8, #0x108]
1000a4ef8:     	madd	x8, x22, x4, x27
1000a4efc:     	ldr	x27, [sp, #0x200]
1000a4f00:     	madd	x8, x8, x4, x27
1000a4f04:     	ldr	x27, [sp, #0x1f8]
1000a4f08:     	madd	x8, x8, x4, x27
1000a4f0c:     	ldr	x27, [sp, #0x1f0]
1000a4f10:     	madd	x8, x8, x4, x27
1000a4f14:     	madd	x8, x8, x4, x13
1000a4f18:     	ldr	x13, [sp, #0x1e8]
1000a4f1c:     	madd	x8, x8, x4, x13
1000a4f20:     	madd	x8, x8, x4, x17
1000a4f24:     	madd	x8, x8, x4, x16
1000a4f28:     	madd	x8, x8, x4, x0
1000a4f2c:     	madd	x8, x8, x4, x1
1000a4f30:     	ldr	x1, [sp, #0x170]
1000a4f34:     	madd	x8, x8, x4, x2
1000a4f38:     	madd	x8, x8, x4, x3
1000a4f3c:     	ldr	x0, [sp, #0x150]
1000a4f40:     	madd	x8, x8, x4, x5
1000a4f44:     	madd	x8, x8, x4, x15
1000a4f48:     	madd	x8, x8, x4, x7
1000a4f4c:     	madd	x8, x8, x4, x6
1000a4f50:     	madd	x8, x8, x4, x21
1000a4f54:     	madd	x8, x8, x4, x19
1000a4f58:     	madd	x8, x8, x4, x24
1000a4f5c:     	ldp	x13, x15, [sp, #0x1d8]
1000a4f60:     	madd	x8, x8, x4, x15
1000a4f64:     	madd	x8, x8, x4, x25
1000a4f68:     	madd	x8, x8, x4, x26
1000a4f6c:     	madd	x8, x8, x4, x28
1000a4f70:     	madd	x8, x8, x4, x30
1000a4f74:     	madd	x8, x8, x4, x13
1000a4f78:     	ldp	x13, x15, [sp, #0x1c8]
1000a4f7c:     	madd	x8, x8, x4, x15
1000a4f80:     	madd	x8, x8, x4, x13
1000a4f84:     	ldr	x13, [sp, #0x1c0]
1000a4f88:     	madd	x8, x8, x4, x13
1000a4f8c:     	madd	x8, x8, x4, x11
1000a4f90:     	madd	x8, x8, x4, x12
1000a4f94:     	madd	x8, x8, x4, x9
1000a4f98:     	mov	w9, #0x4309             ; =17161
1000a4f9c:     	madd	x9, x14, x9, x10
1000a4fa0:     	madd	x8, x8, x4, x9
1000a4fa4:     	sub	x1, x1, #0x1
1000a4fa8:     	ldr	x9, [sp, #0x28]
1000a4fac:     	adds	x9, x9, #0x1
1000a4fb0:     	csinv	x9, x9, xzr, lo
1000a4fb4:     	stp	x1, x9, [x0, #0x18]
1000a4fb8:     	str	x9, [sp, #0x28]
1000a4fbc:     	add	x12, x8, #0x83
1000a4fc0:     	ldr	w8, [sp, #0x14c]
1000a4fc4:     	tbz	w8, #0x0, 0x1000a4fe0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x3f8>
1000a4fc8:     	mov	x14, x12
1000a4fcc:     	mov	x5, #0x0                ; =0
1000a4fd0:     	b	0x1000a5020 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x438>
1000a4fd4:     	mul	x12, x14, x4
1000a4fd8:     	ldr	w8, [sp, #0x14c]
1000a4fdc:     	tbnz	w8, #0x0, 0x1000a4fc8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x3e0>
1000a4fe0:     	mov	x14, x12
1000a4fe4:     	ldr	x8, [sp, #0x128]
1000a4fe8:     	eor	x8, x8, x22
1000a4fec:     	eor	x8, x8, x8, lsr #30
1000a4ff0:     	mov	x9, #0xe5b9             ; =58809
1000a4ff4:     	movk	x9, #0x1ce4, lsl #16
1000a4ff8:     	movk	x9, #0x476d, lsl #32
1000a4ffc:     	movk	x9, #0xbf58, lsl #48
1000a5000:     	mul	x8, x8, x9
1000a5004:     	eor	x8, x8, x8, lsr #27
1000a5008:     	mov	x9, #0x11eb             ; =4587
1000a500c:     	movk	x9, #0x1331, lsl #16
1000a5010:     	movk	x9, #0x49bb, lsl #32
1000a5014:     	movk	x9, #0x94d0, lsl #48
1000a5018:     	mul	x8, x8, x9
1000a501c:     	eor	x5, x8, x8, lsr #31
1000a5020:     	mov	x12, x1
1000a5024:     	ldr	x8, [sp, #0x138]
1000a5028:     	add	x30, x8, x20
1000a502c:     	add	x9, x30, #0x1
1000a5030:     	add	x8, x30, #0x2
1000a5034:     	stp	x9, x8, [sp, #0x178]
1000a5038:     	add	x9, x30, #0x3
1000a503c:     	add	x8, x30, #0x4
1000a5040:     	str	x8, [sp, #0x1d8]
1000a5044:     	add	x8, x30, #0x5
1000a5048:     	stp	x9, x8, [sp, #0x188]
1000a504c:     	add	x9, x30, #0x6
1000a5050:     	add	x8, x30, #0x7
1000a5054:     	stp	x9, x8, [sp, #0x198]
1000a5058:     	add	x9, x30, #0x8
1000a505c:     	add	x8, x30, #0x9
1000a5060:     	stp	x9, x8, [sp, #0x1a8]
1000a5064:     	add	x17, x30, #0xa
1000a5068:     	add	x28, x30, #0xb
1000a506c:     	add	x27, x30, #0xc
1000a5070:     	add	x26, x30, #0xd
1000a5074:     	add	x25, x30, #0xe
1000a5078:     	add	x9, x30, #0xf
1000a507c:     	add	x8, x30, #0x10
1000a5080:     	stp	x9, x8, [sp, #0x1b8]
1000a5084:     	add	x8, x30, #0x11
1000a5088:     	str	x8, [sp, #0x1c8]
1000a508c:     	add	x16, x30, #0x12
1000a5090:     	add	x9, x30, #0x13
1000a5094:     	add	x7, x30, #0x14
1000a5098:     	add	x2, x30, #0x15
1000a509c:     	add	x15, x30, #0x16
1000a50a0:     	add	x19, x30, #0x17
1000a50a4:     	add	x21, x30, #0x18
1000a50a8:     	add	x8, x30, #0x19
1000a50ac:     	stp	x8, x9, [sp, #0x1e0]
1000a50b0:     	add	x9, x30, #0x1a
1000a50b4:     	add	x10, x30, #0x1b
1000a50b8:     	add	x6, x30, #0x1c
1000a50bc:     	add	x8, x30, #0x1d
1000a50c0:     	stp	x10, x8, [sp, #0x1f0]
1000a50c4:     	add	x24, x30, #0x1e
1000a50c8:     	ldr	x11, [x0]
1000a50cc:     	add	x8, x30, #0x1f
1000a50d0:     	str	x8, [sp, #0x200]
1000a50d4:     	cbz	x11, 0x1000a52a0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x6b8>
1000a50d8:     	udiv	x8, x5, x11
1000a50dc:     	msub	x1, x8, x11, x5
1000a50e0:     	ldr	x13, [x0, #0x10]
1000a50e4:     	mov	x10, x11
1000a50e8:     	mov	x3, x11
1000a50ec:     	ldr	x0, [sp, #0x1d8]
1000a50f0:     	b	0x1000a5110 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x528>
1000a50f4:     	cmp	x3, x11
1000a50f8:     	csel	x3, x1, x3, eq
1000a50fc:     	add	x8, x1, #0x1
1000a5100:     	cmp	x8, x11
1000a5104:     	csinc	x1, xzr, x1, hs
1000a5108:     	subs	x10, x10, #0x1
1000a510c:     	b.eq	0x1000a52a4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x6bc>
1000a5110:     	madd	x5, x1, x23, x13
1000a5114:     	ldr	w8, [x5]
1000a5118:     	cmp	w8, #0x1
1000a511c:     	b.eq	0x1000a50f4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x50c>
1000a5120:     	cmp	w8, #0x2
1000a5124:     	b.ne	0x1000a53b8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x7d0>
1000a5128:     	ldr	x8, [x5, #0x8]
1000a512c:     	cmp	x8, x22
1000a5130:     	b.ne	0x1000a50fc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x514>
1000a5134:     	ldp	x10, x11, [x5, #0x10]
1000a5138:     	stp	x20, x10, [sp, #0x168]
1000a513c:     	ldr	x8, [sp, #0x178]
1000a5140:     	stp	x30, x8, [x5, #0x10]
1000a5144:     	ldp	x10, x8, [x5, #0x20]
1000a5148:     	stp	x8, x11, [sp, #0x118]
1000a514c:     	ldp	x11, x8, [sp, #0x180]
1000a5150:     	stp	x11, x8, [x5, #0x20]
1000a5154:     	ldp	x11, x8, [x5, #0x30]
1000a5158:     	stp	x10, x8, [sp, #0x178]
1000a515c:     	ldr	x8, [sp, #0x190]
1000a5160:     	stp	x0, x8, [x5, #0x30]
1000a5164:     	ldp	x10, x8, [x5, #0x40]
1000a5168:     	stp	x11, x8, [sp, #0x188]
1000a516c:     	ldp	x11, x8, [sp, #0x198]
1000a5170:     	stp	x11, x8, [x5, #0x40]
1000a5174:     	ldp	x20, x11, [x5, #0x50]
1000a5178:     	ldr	x8, [sp, #0x1a8]
1000a517c:     	str	x8, [x5, #0x50]
1000a5180:     	ldr	x8, [sp, #0x1b0]
1000a5184:     	str	x8, [x5, #0x58]
1000a5188:     	ldr	x8, [x5, #0x60]
1000a518c:     	str	x8, [sp, #0x1b0]
1000a5190:     	ldr	x8, [x5, #0x68]
1000a5194:     	stp	x11, x8, [sp, #0x1a0]
1000a5198:     	stp	x17, x28, [x5, #0x60]
1000a519c:     	ldp	x8, x28, [x5, #0x70]
1000a51a0:     	stp	x8, x10, [sp, #0x1d0]
1000a51a4:     	stp	x27, x26, [x5, #0x70]
1000a51a8:     	mov	x8, x25
1000a51ac:     	ldp	x26, x25, [x5, #0x80]
1000a51b0:     	str	x8, [x5, #0x80]
1000a51b4:     	ldp	x10, x8, [sp, #0x1b8]
1000a51b8:     	ldp	x0, x13, [x5, #0x90]
1000a51bc:     	stp	x10, x8, [x5, #0x88]
1000a51c0:     	ldr	x8, [sp, #0x1c8]
1000a51c4:     	ldp	x11, x10, [x5, #0xa0]
1000a51c8:     	stp	x8, x16, [x5, #0x98]
1000a51cc:     	ldr	x8, [sp, #0x1e8]
1000a51d0:     	ldp	x16, x1, [x5, #0xb0]
1000a51d4:     	stp	x8, x7, [x5, #0xa8]
1000a51d8:     	str	x2, [x5, #0xb8]
1000a51dc:     	ldp	x2, x3, [x5, #0xc0]
1000a51e0:     	stp	x15, x19, [x5, #0xc0]
1000a51e4:     	mov	x8, x21
1000a51e8:     	ldp	x7, x21, [x5, #0xd0]
1000a51ec:     	str	x8, [x5, #0xd0]
1000a51f0:     	ldr	x8, [sp, #0x1e0]
1000a51f4:     	str	x8, [x5, #0xd8]
1000a51f8:     	ldp	x23, x8, [x5, #0xe0]
1000a51fc:     	ldr	x15, [sp, #0x1f0]
1000a5200:     	stp	x9, x15, [x5, #0xe0]
1000a5204:     	ldp	x17, x15, [x5, #0xf0]
1000a5208:     	str	x6, [x5, #0xf0]
1000a520c:     	ldp	x6, x30, [sp, #0x1f8]
1000a5210:     	str	x6, [x5, #0xf8]
1000a5214:     	ldp	x6, x19, [x5, #0x100]
1000a5218:     	stp	x24, x30, [x5, #0x100]
1000a521c:     	mov	w30, #0x2               ; =2
1000a5220:     	str	x30, [x5]
1000a5224:     	stp	x15, x19, [sp, #0x1f8]
1000a5228:     	stp	x7, x6, [sp, #0x158]
1000a522c:     	mov	x6, x17
1000a5230:     	stp	x10, x8, [sp, #0x1e8]
1000a5234:     	mov	x9, x23
1000a5238:     	str	x21, [sp, #0x1e0]
1000a523c:     	mov	x21, x3
1000a5240:     	mov	x8, x2
1000a5244:     	mov	x2, x1
1000a5248:     	mov	x7, x11
1000a524c:     	mov	x10, x13
1000a5250:     	mov	x23, x26
1000a5254:     	mov	x26, x28
1000a5258:     	ldp	x27, x1, [sp, #0x1d0]
1000a525c:     	ldp	x28, x11, [sp, #0x1a8]
1000a5260:     	str	x11, [sp, #0x1d0]
1000a5264:     	ldr	x13, [sp, #0x1a0]
1000a5268:     	ldp	x17, x5, [sp, #0x188]
1000a526c:     	ldp	x15, x19, [sp, #0x178]
1000a5270:     	ldp	x24, x11, [sp, #0x118]
1000a5274:     	ldr	x30, [sp, #0x170]
1000a5278:     	strb	wzr, [sp, #0x20c]
1000a527c:     	mov	w3, #0x1                ; =1
1000a5280:     	str	x12, [sp, #0x170]
1000a5284:     	mov	x12, x14
1000a5288:     	mov	x14, x7
1000a528c:     	mov	x7, x16
1000a5290:     	mov	x16, x10
1000a5294:     	mov	x10, x15
1000a5298:     	mov	x15, x8
1000a529c:     	b	0x1000a4ccc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0xe4>
1000a52a0:     	mov	x3, #0x0                ; =0
1000a52a4:     	cmp	x3, x11
1000a52a8:     	mov	x1, x12
1000a52ac:     	str	x17, [sp, #0x1d0]
1000a52b0:     	b.hs	0x1000a4c90 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0xa8>
1000a52b4:     	cmp	x1, #0x2, lsl #12       ; =0x2000
1000a52b8:     	b.hs	0x1000a4c90 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0xa8>
1000a52bc:     	add	x1, x1, #0x1
1000a52c0:     	ldr	x0, [sp, #0x150]
1000a52c4:     	str	x1, [x0, #0x18]
1000a52c8:     	ldr	x8, [x0, #0x10]
1000a52cc:     	madd	x5, x3, x23, x8
1000a52d0:     	ldr	w10, [x5]
1000a52d4:     	cmp	w10, #0x1
1000a52d8:     	mov	x12, x14
1000a52dc:     	mov	x13, x24
1000a52e0:     	b.ne	0x1000a5308 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x720>
1000a52e4:     	ldr	x8, [sp, #0x28]
1000a52e8:     	subs	x8, x8, #0x1
1000a52ec:     	csel	x8, xzr, x8, lo
1000a52f0:     	str	x8, [sp, #0x28]
1000a52f4:     	str	x8, [x0, #0x20]
1000a52f8:     	ldp	x14, x10, [sp, #0x1a8]
1000a52fc:     	ldp	x3, x17, [sp, #0x198]
1000a5300:     	ldp	x8, x24, [sp, #0x188]
1000a5304:     	b	0x1000a53e0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x7f8>
1000a5308:     	ldp	x24, x3, [sp, #0x190]
1000a530c:     	ldr	x8, [sp, #0x188]
1000a5310:     	cbz	w10, 0x1000a53d4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x7ec>
1000a5314:     	str	wzr, [sp, #0x170]
1000a5318:     	strb	wzr, [sp, #0x20c]
1000a531c:     	ldp	x11, x10, [x5, #0x8]
1000a5320:     	stp	x10, x11, [sp, #0x118]
1000a5324:     	ldp	x11, x10, [x5, #0x18]
1000a5328:     	stp	x10, x11, [sp, #0x108]
1000a532c:     	ldp	x11, x10, [x5, #0x28]
1000a5330:     	stp	x10, x11, [sp, #0xf8]
1000a5334:     	ldp	x11, x10, [x5, #0x38]
1000a5338:     	stp	x10, x11, [sp, #0xe8]
1000a533c:     	ldp	x11, x10, [x5, #0x48]
1000a5340:     	stp	x10, x11, [sp, #0xd8]
1000a5344:     	ldp	x11, x10, [x5, #0x58]
1000a5348:     	stp	x10, x11, [sp, #0xc8]
1000a534c:     	ldp	x11, x10, [x5, #0x68]
1000a5350:     	stp	x10, x11, [sp, #0xb8]
1000a5354:     	ldp	x11, x10, [x5, #0x78]
1000a5358:     	stp	x10, x11, [sp, #0xa8]
1000a535c:     	ldp	x11, x10, [x5, #0x88]
1000a5360:     	stp	x10, x11, [sp, #0x98]
1000a5364:     	ldp	x11, x10, [x5, #0x98]
1000a5368:     	stp	x10, x11, [sp, #0x88]
1000a536c:     	ldp	x11, x10, [x5, #0xa8]
1000a5370:     	stp	x10, x11, [sp, #0x78]
1000a5374:     	ldp	x11, x10, [x5, #0xb8]
1000a5378:     	stp	x10, x11, [sp, #0x68]
1000a537c:     	ldp	x11, x10, [x5, #0xc8]
1000a5380:     	str	x10, [sp, #0x158]
1000a5384:     	ldr	x10, [x5, #0xd8]
1000a5388:     	stp	x10, x11, [sp, #0x58]
1000a538c:     	ldp	x11, x10, [x5, #0xe0]
1000a5390:     	stp	x10, x11, [sp, #0x48]
1000a5394:     	ldp	x11, x10, [x5, #0xf0]
1000a5398:     	stp	x10, x11, [sp, #0x38]
1000a539c:     	ldp	x11, x10, [x5, #0x100]
1000a53a0:     	str	x11, [sp, #0x160]
1000a53a4:     	str	x10, [sp, #0x30]
1000a53a8:     	ldr	x0, [sp, #0x150]
1000a53ac:     	ldp	x14, x10, [sp, #0x1a8]
1000a53b0:     	ldr	x17, [sp, #0x1a0]
1000a53b4:     	b	0x1000a5430 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x848>
1000a53b8:     	cmp	x3, x11
1000a53bc:     	csel	x3, x1, x3, eq
1000a53c0:     	cmp	x3, x11
1000a53c4:     	mov	x1, x12
1000a53c8:     	str	x17, [sp, #0x1d0]
1000a53cc:     	b.lo	0x1000a52b4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x6cc>
1000a53d0:     	b	0x1000a4c90 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0xa8>
1000a53d4:     	ldr	x0, [sp, #0x150]
1000a53d8:     	ldp	x14, x10, [sp, #0x1a8]
1000a53dc:     	ldr	x17, [sp, #0x1a0]
1000a53e0:     	stp	xzr, xzr, [sp, #0x118]
1000a53e4:     	stp	xzr, xzr, [sp, #0x108]
1000a53e8:     	stp	xzr, xzr, [sp, #0xf8]
1000a53ec:     	stp	xzr, xzr, [sp, #0xe8]
1000a53f0:     	stp	xzr, xzr, [sp, #0xd8]
1000a53f4:     	stp	xzr, xzr, [sp, #0xc8]
1000a53f8:     	stp	xzr, xzr, [sp, #0xb8]
1000a53fc:     	stp	xzr, xzr, [sp, #0xa8]
1000a5400:     	stp	xzr, xzr, [sp, #0x98]
1000a5404:     	stp	xzr, xzr, [sp, #0x88]
1000a5408:     	stp	xzr, xzr, [sp, #0x78]
1000a540c:     	stp	xzr, xzr, [sp, #0x68]
1000a5410:     	stp	xzr, xzr, [sp, #0x58]
1000a5414:     	stp	xzr, xzr, [sp, #0x158]
1000a5418:     	stp	xzr, xzr, [sp, #0x48]
1000a541c:     	stp	xzr, xzr, [sp, #0x38]
1000a5420:     	str	xzr, [sp, #0x30]
1000a5424:     	strb	wzr, [sp, #0x20c]
1000a5428:     	mov	w11, #0x1               ; =1
1000a542c:     	str	w11, [sp, #0x170]
1000a5430:     	stp	x22, x30, [x5, #0x8]
1000a5434:     	ldp	x11, x30, [sp, #0x178]
1000a5438:     	stp	x11, x30, [x5, #0x18]
1000a543c:     	str	x8, [x5, #0x28]
1000a5440:     	mov	w8, #0x2                ; =2
1000a5444:     	str	x8, [x5]
1000a5448:     	ldp	x8, x11, [sp, #0x1d0]
1000a544c:     	stp	x11, x24, [x5, #0x30]
1000a5450:     	stp	x3, x17, [x5, #0x40]
1000a5454:     	stp	x14, x10, [x5, #0x50]
1000a5458:     	stp	x8, x28, [x5, #0x60]
1000a545c:     	stp	x27, x26, [x5, #0x70]
1000a5460:     	ldp	x10, x11, [sp, #0x1b8]
1000a5464:     	stp	x25, x10, [x5, #0x80]
1000a5468:     	ldr	x8, [sp, #0x1c8]
1000a546c:     	stp	x11, x8, [x5, #0x90]
1000a5470:     	ldp	x8, x10, [sp, #0x1e0]
1000a5474:     	stp	x16, x10, [x5, #0xa0]
1000a5478:     	stp	x7, x2, [x5, #0xb0]
1000a547c:     	stp	x15, x19, [x5, #0xc0]
1000a5480:     	stp	x21, x8, [x5, #0xd0]
1000a5484:     	ldp	x10, x8, [sp, #0x1f0]
1000a5488:     	stp	x9, x10, [x5, #0xe0]
1000a548c:     	stp	x6, x8, [x5, #0xf0]
1000a5490:     	ldr	x8, [sp, #0x200]
1000a5494:     	stp	x13, x8, [x5, #0x100]
1000a5498:     	ldr	w8, [sp, #0x170]
1000a549c:     	tbz	w8, #0x0, 0x1000a54bc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x8d4>
1000a54a0:     	mul	x12, x12, x4
1000a54a4:     	mov	w13, #0x1               ; =1
1000a54a8:     	add	x20, x20, #0x1
1000a54ac:     	ldr	x8, [sp, #0x140]
1000a54b0:     	cmp	x20, x8
1000a54b4:     	b.ne	0x1000a4d98 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x1b0>
1000a54b8:     	b	0x1000a4c5c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x74>
1000a54bc:     	stp	x20, x1, [sp, #0x168]
1000a54c0:     	ldp	x9, x8, [sp, #0x30]
1000a54c4:     	stp	x8, x9, [sp, #0x1f8]
1000a54c8:     	ldp	x6, x10, [sp, #0x40]
1000a54cc:     	ldp	x9, x8, [sp, #0x50]
1000a54d0:     	str	x8, [sp, #0x1e0]
1000a54d4:     	ldp	x21, x15, [sp, #0x60]
1000a54d8:     	ldp	x2, x7, [sp, #0x70]
1000a54dc:     	ldp	x8, x14, [sp, #0x80]
1000a54e0:     	stp	x8, x10, [sp, #0x1e8]
1000a54e4:     	ldp	x16, x0, [sp, #0x90]
1000a54e8:     	ldp	x25, x23, [sp, #0xa0]
1000a54ec:     	ldp	x26, x27, [sp, #0xb0]
1000a54f0:     	ldp	x28, x8, [sp, #0xc0]
1000a54f4:     	str	x8, [sp, #0x1d0]
1000a54f8:     	ldp	x13, x20, [sp, #0xd0]
1000a54fc:     	ldp	x5, x1, [sp, #0xe0]
1000a5500:     	ldp	x19, x17, [sp, #0xf0]
1000a5504:     	ldp	x24, x10, [sp, #0x100]
1000a5508:     	ldp	x11, x30, [sp, #0x110]
1000a550c:     	ldr	x22, [sp, #0x120]
1000a5510:     	mov	w3, #0x1                ; =1
1000a5514:     	b	0x1000a4ccc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0xe4>
1000a5518:     	ldr	x8, [sp, #0x10]
1000a551c:     	add	x8, x10, x8
1000a5520:     	str	x8, [x0, #0x48]
1000a5524:     	mov	x12, x9
1000a5528:     	eor	x8, x12, x12, lsr #30
1000a552c:     	mov	x9, #0xe5b9             ; =58809
1000a5530:     	movk	x9, #0x1ce4, lsl #16
1000a5534:     	movk	x9, #0x476d, lsl #32
1000a5538:     	movk	x9, #0xbf58, lsl #48
1000a553c:     	mul	x8, x8, x9
1000a5540:     	eor	x8, x8, x8, lsr #27
1000a5544:     	mov	x9, #0x11eb             ; =4587
1000a5548:     	movk	x9, #0x1331, lsl #16
1000a554c:     	movk	x9, #0x49bb, lsl #32
1000a5550:     	movk	x9, #0x94d0, lsl #48
1000a5554:     	mul	x8, x8, x9
1000a5558:     	eor	x0, x8, x8, lsr #31
1000a555c:     	add	sp, sp, #0x210
1000a5560:     	ldp	x29, x30, [sp, #0x50]
1000a5564:     	ldp	x20, x19, [sp, #0x40]
1000a5568:     	ldp	x22, x21, [sp, #0x30]
1000a556c:     	ldp	x24, x23, [sp, #0x20]
1000a5570:     	ldp	x26, x25, [sp, #0x10]
1000a5574:     	ldp	x28, x27, [sp], #0x60
1000a5578:     	ret

