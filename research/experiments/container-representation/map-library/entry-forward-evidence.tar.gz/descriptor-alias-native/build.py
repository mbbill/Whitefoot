import hashlib,json,os,pathlib,subprocess,sys,time
ROOT=pathlib.Path('/private/tmp/whitefoot-container-recovery-20261001')
OUT=pathlib.Path('/private/tmp/whitefoot-map-descriptor-alias')
SRC=pathlib.Path('/private/tmp/whitefoot-mutation-home-mask')
assert os.environ.get('WHITEFOOT_CHECK_OWNER')
mode=sys.argv[1];assert mode in ['extract','native']
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
records=[]
def run(label,args):
 start=time.monotonic();p=subprocess.run(list(map(str,args)),cwd=ROOT,capture_output=True,text=True)
 (OUT/(label+'.stdout')).write_text(p.stdout);(OUT/(label+'.stderr')).write_text(p.stderr)
 row=dict(label=label,argv=list(map(str,args)),exit=p.returncode,seconds=time.monotonic()-start);records.append(row)
 (OUT/(mode+'-statuses.json')).write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert p.returncode==0,row
if mode=='extract':
 pins={str(p):sha(p) for p in [SRC/'control.raw.ll',SRC/'candidate.raw.ll',SRC/'candidate-timed',OUT/'criterion.txt',pathlib.Path(__file__)]}
 (OUT/'input-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
 run('mask-optimized-ir',['/usr/bin/clang','-O3','-S','-emit-llvm','-Wno-override-module','-x','ir',SRC/'candidate.raw.ll','-o',OUT/'mask.optimized.ll'])
else:
 for path,digest in json.loads((OUT/'input-pins.json').read_text()).items():assert sha(path)==digest,path
 links=json.loads((SRC/'link-commands.json').read_text())
 outputs={}
 for arm in ['control','fact']:
  src=OUT/('mask.optimized.ll' if arm=='control' else 'mask.fact.ll')
  text=src.read_text();assert text.count('@main(')==1
  linked=OUT/(arm+'.ll');linked.write_text(text.replace('@main(', '@mutation_unused_main('))
  obj=OUT/(arm+'.o')
  run(arm+'-native',['/usr/bin/clang','-O3','-Wno-override-module','-x','ir','-c',linked,'-o',obj])
  cmd=list(links['timed']);old=[x for x in cmd if x.endswith('/entry-forward-wf-timed.o')];assert len(old)==1
  cmd[cmd.index(old[0])]=str(obj);cmd[-1]=str(OUT/(arm+'-timed'))
  run(arm+'-link',cmd)
  run(arm+'-disassembly',[os.environ['LLVM_OBJDUMP'],'-dr','--no-show-raw-insn',OUT/(arm+'-timed')])
  outputs.update({str(p):sha(p) for p in [src,linked,obj,OUT/(arm+'-timed')]})
 (OUT/'outputs.json').write_text(json.dumps(outputs,indent=2)+'\n')
