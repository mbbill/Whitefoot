00000001000a4be8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027>:
1000a4be8:     	sub	sp, sp, #0x1c0
1000a4bec:     	stp	x28, x27, [sp, #0x160]
1000a4bf0:     	stp	x26, x25, [sp, #0x170]
1000a4bf4:     	stp	x24, x23, [sp, #0x180]
1000a4bf8:     	stp	x22, x21, [sp, #0x190]
1000a4bfc:     	stp	x20, x19, [sp, #0x1a0]
1000a4c00:     	stp	x29, x30, [sp, #0x1b0]
1000a4c04:     	str	x2, [sp, #0xa8]
1000a4c08:     	ldr	x14, [x0, #0x38]
1000a4c0c:     	str	x1, [sp, #0x10]
1000a4c10:     	cbz	x1, 0x1000a547c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x894>
1000a4c14:     	ldp	x8, x10, [x0, #0x40]
1000a4c18:     	cbz	x8, 0x1000a5470 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x888>
1000a4c1c:     	mov	x11, #0x0               ; =0
1000a4c20:     	ldp	x8, x9, [x0, #0x18]
1000a4c24:     	str	x9, [sp, #0x30]
1000a4c28:     	stp	x0, x8, [sp, #0xc0]
1000a4c2c:     	ldp	x8, x12, [x0, #0x38]
1000a4c30:     	str	x8, [sp, #0x8]
1000a4c34:     	mov	w3, #0x110              ; =272
1000a4c38:     	ldr	x8, [x0, #0x28]
1000a4c3c:     	stp	x8, x12, [sp, #0x98]
1000a4c40:     	mov	w6, #0x83               ; =131
1000a4c44:     	movi.2d	v0, #0000000000000000
1000a4c48:     	ldrb	w8, [x0, #0x30]
1000a4c4c:     	str	w8, [sp, #0xbc]
1000a4c50:     	b	0x1000a4c74 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x8c>
1000a4c54:     	mov	x1, x13
1000a4c58:     	ldp	x11, x10, [sp, #0x18]
1000a4c5c:     	str	x10, [x0, #0x48]
1000a4c60:     	add	x11, x11, #0x1
1000a4c64:     	mov	x13, x1
1000a4c68:     	ldr	x8, [sp, #0x10]
1000a4c6c:     	cmp	x11, x8
1000a4c70:     	b.eq	0x1000a547c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x894>
1000a4c74:     	add	x10, x10, #0x1
1000a4c78:     	stp	x11, x10, [sp, #0x18]
1000a4c7c:     	cbz	x12, 0x1000a4c54 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x6c>
1000a4c80:     	mov	x21, #0x0               ; =0
1000a4c84:     	ldr	x8, [sp, #0x8]
1000a4c88:     	madd	x8, x10, x12, x8
1000a4c8c:     	str	x8, [sp, #0xb0]
1000a4c90:     	b	0x1000a4dd4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x1ec>
1000a4c94:     	mov	x5, x0
1000a4c98:     	mov	x20, x27
1000a4c9c:     	mov	x13, x26
1000a4ca0:     	mov	x10, x28
1000a4ca4:     	mov	x19, x24
1000a4ca8:     	mov	x25, x7
1000a4cac:     	mov	x23, x16
1000a4cb0:     	mov	x26, x11
1000a4cb4:     	mov	x22, x30
1000a4cb8:     	mov	x27, x9
1000a4cbc:     	stp	x17, x8, [sp, #0x148]
1000a4cc0:     	stp	x2, x14, [sp, #0x138]
1000a4cc4:     	ldp	x9, x11, [sp, #0x110]
1000a4cc8:     	stp	x9, x15, [sp, #0x128]
1000a4ccc:     	ldp	x9, x8, [sp, #0x100]
1000a4cd0:     	stp	x9, x11, [sp, #0x118]
1000a4cd4:     	str	x8, [sp, #0x110]
1000a4cd8:     	ldp	x9, x8, [sp, #0x38]
1000a4cdc:     	stp	x8, x9, [sp, #0x100]
1000a4ce0:     	ldp	x17, x15, [sp, #0x48]
1000a4ce4:     	ldp	x14, x2, [sp, #0x58]
1000a4ce8:     	ldp	x28, x30, [sp, #0x68]
1000a4cec:     	ldp	x7, x16, [sp, #0x78]
1000a4cf0:     	ldp	x11, x24, [sp, #0x88]
1000a4cf4:     	ldr	x0, [sp, #0xc0]
1000a4cf8:     	madd	x8, x24, x6, x11
1000a4cfc:     	madd	x8, x8, x6, x16
1000a4d00:     	madd	x8, x8, x6, x7
1000a4d04:     	ldrb	w9, [sp, #0x15c]
1000a4d08:     	tst	w9, #0x1
1000a4d0c:     	madd	x8, x8, x6, x30
1000a4d10:     	mov	w9, #0x1                ; =1
1000a4d14:     	cinc	x9, x9, ne
1000a4d18:     	madd	x8, x8, x6, x28
1000a4d1c:     	madd	x8, x8, x6, x2
1000a4d20:     	madd	x8, x8, x6, x14
1000a4d24:     	madd	x8, x8, x6, x15
1000a4d28:     	madd	x8, x8, x6, x17
1000a4d2c:     	ldr	x11, [sp, #0x100]
1000a4d30:     	madd	x8, x8, x6, x11
1000a4d34:     	ldr	x11, [sp, #0x108]
1000a4d38:     	madd	x8, x8, x6, x11
1000a4d3c:     	ldr	x11, [sp, #0x110]
1000a4d40:     	madd	x8, x8, x6, x11
1000a4d44:     	ldr	x11, [sp, #0x118]
1000a4d48:     	madd	x8, x8, x6, x11
1000a4d4c:     	ldr	x11, [sp, #0x120]
1000a4d50:     	madd	x8, x8, x6, x11
1000a4d54:     	ldr	x11, [sp, #0x128]
1000a4d58:     	madd	x8, x8, x6, x11
1000a4d5c:     	ldr	x11, [sp, #0x130]
1000a4d60:     	madd	x8, x8, x6, x11
1000a4d64:     	ldr	x11, [sp, #0x138]
1000a4d68:     	madd	x8, x8, x6, x11
1000a4d6c:     	ldr	x11, [sp, #0x140]
1000a4d70:     	madd	x8, x8, x6, x11
1000a4d74:     	ldr	x11, [sp, #0x148]
1000a4d78:     	madd	x8, x8, x6, x11
1000a4d7c:     	madd	x8, x8, x6, x12
1000a4d80:     	madd	x8, x8, x6, x4
1000a4d84:     	ldr	x11, [sp, #0x150]
1000a4d88:     	madd	x8, x8, x6, x11
1000a4d8c:     	madd	x8, x8, x6, x27
1000a4d90:     	madd	x8, x8, x6, x22
1000a4d94:     	madd	x8, x8, x6, x26
1000a4d98:     	madd	x8, x8, x6, x23
1000a4d9c:     	madd	x8, x8, x6, x25
1000a4da0:     	madd	x8, x8, x6, x19
1000a4da4:     	madd	x8, x8, x6, x10
1000a4da8:     	ldr	x10, [sp, #0xd8]
1000a4dac:     	add	x10, x13, x10
1000a4db0:     	madd	x8, x8, x6, x10
1000a4db4:     	add	x9, x9, x20
1000a4db8:     	madd	x8, x8, x6, x9
1000a4dbc:     	madd	x14, x8, x6, x5
1000a4dc0:     	add	x21, x21, #0x1
1000a4dc4:     	mov	x13, x1
1000a4dc8:     	ldr	x12, [sp, #0xa0]
1000a4dcc:     	cmp	x21, x12
1000a4dd0:     	b.eq	0x1000a4c58 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x70>
1000a4dd4:     	str	w13, [sp, #0xd4]
1000a4dd8:     	mov	w8, #0x1                ; =1
1000a4ddc:     	orr	x24, x8, x21, lsl #1
1000a4de0:     	ldr	x8, [sp, #0xa8]
1000a4de4:     	cbz	x8, 0x1000a5000 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x418>
1000a4de8:     	ldr	x8, [sp, #0xc8]
1000a4dec:     	cbz	x8, 0x1000a5014 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x42c>
1000a4df0:     	ldr	w8, [sp, #0xbc]
1000a4df4:     	tbz	w8, #0x0, 0x1000a4e08 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x220>
1000a4df8:     	mov	x8, #0x0                ; =0
1000a4dfc:     	ldr	x9, [x0]
1000a4e00:     	cbnz	x9, 0x1000a4e4c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x264>
1000a4e04:     	b	0x1000a5014 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x42c>
1000a4e08:     	ldr	x8, [sp, #0x98]
1000a4e0c:     	eor	x8, x8, x24
1000a4e10:     	eor	x8, x8, x8, lsr #30
1000a4e14:     	mov	x9, #0xe5b9             ; =58809
1000a4e18:     	movk	x9, #0x1ce4, lsl #16
1000a4e1c:     	movk	x9, #0x476d, lsl #32
1000a4e20:     	movk	x9, #0xbf58, lsl #48
1000a4e24:     	mul	x8, x8, x9
1000a4e28:     	eor	x8, x8, x8, lsr #27
1000a4e2c:     	mov	x9, #0x11eb             ; =4587
1000a4e30:     	movk	x9, #0x1331, lsl #16
1000a4e34:     	movk	x9, #0x49bb, lsl #32
1000a4e38:     	movk	x9, #0x94d0, lsl #48
1000a4e3c:     	mul	x8, x8, x9
1000a4e40:     	eor	x8, x8, x8, lsr #31
1000a4e44:     	ldr	x9, [x0]
1000a4e48:     	cbz	x9, 0x1000a5014 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x42c>
1000a4e4c:     	udiv	x10, x8, x9
1000a4e50:     	msub	x10, x10, x9, x8
1000a4e54:     	ldr	x11, [x0, #0x10]
1000a4e58:     	mov	x12, x9
1000a4e5c:     	b	0x1000a4e74 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x28c>
1000a4e60:     	add	x8, x10, #0x1
1000a4e64:     	cmp	x8, x9
1000a4e68:     	csinc	x10, xzr, x10, hs
1000a4e6c:     	subs	x12, x12, #0x1
1000a4e70:     	b.eq	0x1000a5014 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x42c>
1000a4e74:     	madd	x8, x10, x3, x11
1000a4e78:     	ldr	w13, [x8]
1000a4e7c:     	cmp	w13, #0x1
1000a4e80:     	b.eq	0x1000a4e60 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x278>
1000a4e84:     	cmp	w13, #0x2
1000a4e88:     	b.ne	0x1000a5014 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x42c>
1000a4e8c:     	ldr	x13, [x8, #0x8]
1000a4e90:     	cmp	x13, x24
1000a4e94:     	b.ne	0x1000a4e60 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x278>
1000a4e98:     	ldp	x10, x9, [x8, #0x10]
1000a4e9c:     	stp	x9, x10, [sp, #0x148]
1000a4ea0:     	ldp	x10, x9, [x8, #0x20]
1000a4ea4:     	stp	x9, x10, [sp, #0x138]
1000a4ea8:     	ldp	x13, x10, [x8, #0x30]
1000a4eac:     	ldp	x15, x16, [x8, #0x40]
1000a4eb0:     	ldp	x17, x0, [x8, #0x50]
1000a4eb4:     	ldp	x1, x2, [x8, #0x60]
1000a4eb8:     	ldp	x4, x5, [x8, #0x70]
1000a4ebc:     	ldp	x7, x19, [x8, #0x80]
1000a4ec0:     	ldp	x20, x22, [x8, #0x90]
1000a4ec4:     	ldp	x25, x26, [x8, #0xa0]
1000a4ec8:     	ldp	x27, x28, [x8, #0xb0]
1000a4ecc:     	ldp	x30, x9, [x8, #0xc0]
1000a4ed0:     	stp	x9, x10, [sp, #0x128]
1000a4ed4:     	ldp	x10, x9, [x8, #0xd0]
1000a4ed8:     	stp	x9, x10, [sp, #0x118]
1000a4edc:     	ldp	x10, x9, [x8, #0xe0]
1000a4ee0:     	stp	x9, x10, [sp, #0x108]
1000a4ee4:     	mov	w9, #0x1                ; =1
1000a4ee8:     	str	w9, [x8]
1000a4eec:     	stur	q0, [x8, #0x8]
1000a4ef0:     	stur	q0, [x8, #0x18]
1000a4ef4:     	stur	q0, [x8, #0x28]
1000a4ef8:     	stur	q0, [x8, #0x38]
1000a4efc:     	stur	q0, [x8, #0x48]
1000a4f00:     	stur	q0, [x8, #0x58]
1000a4f04:     	stur	q0, [x8, #0x68]
1000a4f08:     	stur	q0, [x8, #0x78]
1000a4f0c:     	stur	q0, [x8, #0x88]
1000a4f10:     	stur	q0, [x8, #0x98]
1000a4f14:     	stur	q0, [x8, #0xa8]
1000a4f18:     	stur	q0, [x8, #0xb8]
1000a4f1c:     	stur	q0, [x8, #0xc8]
1000a4f20:     	stur	q0, [x8, #0xd8]
1000a4f24:     	ldp	x23, x11, [x8, #0xf0]
1000a4f28:     	stur	q0, [x8, #0xe8]
1000a4f2c:     	ldp	x9, x10, [x8, #0x100]
1000a4f30:     	stur	q0, [x8, #0xf8]
1000a4f34:     	str	xzr, [x8, #0x108]
1000a4f38:     	ldp	x12, x8, [sp, #0x148]
1000a4f3c:     	madd	x8, x24, x6, x8
1000a4f40:     	madd	x8, x8, x6, x12
1000a4f44:     	ldr	x12, [sp, #0x140]
1000a4f48:     	madd	x8, x8, x6, x12
1000a4f4c:     	ldr	x12, [sp, #0x138]
1000a4f50:     	madd	x8, x8, x6, x12
1000a4f54:     	madd	x8, x8, x6, x13
1000a4f58:     	ldp	x12, x13, [sp, #0x128]
1000a4f5c:     	madd	x8, x8, x6, x13
1000a4f60:     	madd	x8, x8, x6, x15
1000a4f64:     	madd	x8, x8, x6, x16
1000a4f68:     	madd	x8, x8, x6, x17
1000a4f6c:     	madd	x8, x8, x6, x0
1000a4f70:     	madd	x8, x8, x6, x1
1000a4f74:     	madd	x8, x8, x6, x2
1000a4f78:     	madd	x8, x8, x6, x4
1000a4f7c:     	ldr	x0, [sp, #0xc0]
1000a4f80:     	madd	x8, x8, x6, x5
1000a4f84:     	madd	x8, x8, x6, x7
1000a4f88:     	madd	x8, x8, x6, x19
1000a4f8c:     	madd	x8, x8, x6, x20
1000a4f90:     	madd	x8, x8, x6, x22
1000a4f94:     	madd	x8, x8, x6, x25
1000a4f98:     	madd	x8, x8, x6, x26
1000a4f9c:     	madd	x8, x8, x6, x27
1000a4fa0:     	madd	x8, x8, x6, x28
1000a4fa4:     	madd	x8, x8, x6, x30
1000a4fa8:     	madd	x8, x8, x6, x12
1000a4fac:     	ldp	x12, x13, [sp, #0x118]
1000a4fb0:     	madd	x8, x8, x6, x13
1000a4fb4:     	madd	x8, x8, x6, x12
1000a4fb8:     	ldp	x12, x13, [sp, #0x108]
1000a4fbc:     	madd	x8, x8, x6, x13
1000a4fc0:     	madd	x8, x8, x6, x12
1000a4fc4:     	madd	x8, x8, x6, x23
1000a4fc8:     	madd	x8, x8, x6, x11
1000a4fcc:     	madd	x8, x8, x6, x9
1000a4fd0:     	mov	w9, #0x4309             ; =17161
1000a4fd4:     	madd	x9, x14, x9, x10
1000a4fd8:     	madd	x8, x8, x6, x9
1000a4fdc:     	ldr	x10, [sp, #0xc8]
1000a4fe0:     	sub	x10, x10, #0x1
1000a4fe4:     	ldr	x9, [sp, #0x30]
1000a4fe8:     	adds	x9, x9, #0x1
1000a4fec:     	csinv	x9, x9, xzr, lo
1000a4ff0:     	str	x10, [sp, #0xc8]
1000a4ff4:     	stp	x10, x9, [x0, #0x18]
1000a4ff8:     	str	x9, [sp, #0x30]
1000a4ffc:     	add	x14, x8, #0x83
1000a5000:     	ldr	w8, [sp, #0xbc]
1000a5004:     	str	x14, [sp, #0xd8]
1000a5008:     	tbz	w8, #0x0, 0x1000a5024 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x43c>
1000a500c:     	mov	x1, #0x0                ; =0
1000a5010:     	b	0x1000a5060 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x478>
1000a5014:     	mul	x14, x14, x6
1000a5018:     	ldr	w8, [sp, #0xbc]
1000a501c:     	str	x14, [sp, #0xd8]
1000a5020:     	tbnz	w8, #0x0, 0x1000a500c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x424>
1000a5024:     	ldr	x8, [sp, #0x98]
1000a5028:     	eor	x8, x8, x24
1000a502c:     	eor	x8, x8, x8, lsr #30
1000a5030:     	mov	x9, #0xe5b9             ; =58809
1000a5034:     	movk	x9, #0x1ce4, lsl #16
1000a5038:     	movk	x9, #0x476d, lsl #32
1000a503c:     	movk	x9, #0xbf58, lsl #48
1000a5040:     	mul	x8, x8, x9
1000a5044:     	eor	x8, x8, x8, lsr #27
1000a5048:     	mov	x9, #0x11eb             ; =4587
1000a504c:     	movk	x9, #0x1331, lsl #16
1000a5050:     	movk	x9, #0x49bb, lsl #32
1000a5054:     	movk	x9, #0x94d0, lsl #48
1000a5058:     	mul	x8, x8, x9
1000a505c:     	eor	x1, x8, x8, lsr #31
1000a5060:     	ldr	x8, [sp, #0xb0]
1000a5064:     	add	x11, x8, x21
1000a5068:     	add	x16, x11, #0x1
1000a506c:     	add	x7, x11, #0x2
1000a5070:     	add	x30, x11, #0x3
1000a5074:     	add	x28, x11, #0x4
1000a5078:     	add	x2, x11, #0x5
1000a507c:     	add	x14, x11, #0x6
1000a5080:     	add	x15, x11, #0x7
1000a5084:     	add	x17, x11, #0x8
1000a5088:     	add	x9, x11, #0x9
1000a508c:     	add	x8, x11, #0xa
1000a5090:     	stp	x9, x8, [sp, #0x100]
1000a5094:     	add	x9, x11, #0xb
1000a5098:     	add	x8, x11, #0xc
1000a509c:     	stp	x9, x8, [sp, #0x110]
1000a50a0:     	add	x9, x11, #0xd
1000a50a4:     	add	x8, x11, #0xe
1000a50a8:     	stp	x9, x8, [sp, #0x120]
1000a50ac:     	add	x9, x11, #0xf
1000a50b0:     	add	x8, x11, #0x10
1000a50b4:     	stp	x9, x8, [sp, #0x130]
1000a50b8:     	add	x9, x11, #0x11
1000a50bc:     	add	x8, x11, #0x12
1000a50c0:     	stp	x9, x8, [sp, #0x140]
1000a50c4:     	add	x9, x11, #0x13
1000a50c8:     	add	x8, x11, #0x14
1000a50cc:     	stp	x9, x8, [sp, #0xe8]
1000a50d0:     	add	x8, x11, #0x15
1000a50d4:     	str	x8, [sp, #0x150]
1000a50d8:     	add	x27, x11, #0x16
1000a50dc:     	add	x22, x11, #0x17
1000a50e0:     	add	x26, x11, #0x18
1000a50e4:     	add	x23, x11, #0x19
1000a50e8:     	add	x25, x11, #0x1a
1000a50ec:     	add	x19, x11, #0x1b
1000a50f0:     	add	x10, x11, #0x1c
1000a50f4:     	add	x13, x11, #0x1d
1000a50f8:     	add	x8, x11, #0x1e
1000a50fc:     	str	x8, [sp, #0xf8]
1000a5100:     	ldr	x8, [x0]
1000a5104:     	add	x9, x11, #0x1f
1000a5108:     	str	x9, [sp, #0xe0]
1000a510c:     	cbz	x8, 0x1000a52e0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x6f8>
1000a5110:     	udiv	x9, x1, x8
1000a5114:     	msub	x1, x9, x8, x1
1000a5118:     	ldr	x9, [x0, #0x10]
1000a511c:     	mov	x20, x8
1000a5120:     	mov	x12, x8
1000a5124:     	b	0x1000a5144 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x55c>
1000a5128:     	cmp	x12, x8
1000a512c:     	csel	x12, x1, x12, eq
1000a5130:     	add	x4, x1, #0x1
1000a5134:     	cmp	x4, x8
1000a5138:     	csinc	x1, xzr, x1, hs
1000a513c:     	subs	x20, x20, #0x1
1000a5140:     	b.eq	0x1000a52e4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x6fc>
1000a5144:     	madd	x5, x1, x3, x9
1000a5148:     	ldr	w4, [x5]
1000a514c:     	cmp	w4, #0x1
1000a5150:     	b.eq	0x1000a5128 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x540>
1000a5154:     	cmp	w4, #0x2
1000a5158:     	b.ne	0x1000a5440 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x858>
1000a515c:     	ldr	x4, [x5, #0x8]
1000a5160:     	cmp	x4, x24
1000a5164:     	b.ne	0x1000a5130 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x548>
1000a5168:     	mov	x12, x13
1000a516c:     	mov	x9, x19
1000a5170:     	mov	x1, x23
1000a5174:     	mov	w4, #0x0                ; =0
1000a5178:     	ldr	x0, [x5, #0x10]
1000a517c:     	str	x0, [sp, #0x90]
1000a5180:     	ldr	x0, [x5, #0x18]
1000a5184:     	stp	x11, x16, [x5, #0x10]
1000a5188:     	ldp	x8, x11, [x5, #0x20]
1000a518c:     	stp	x8, x0, [sp, #0x80]
1000a5190:     	str	x11, [sp, #0x78]
1000a5194:     	stp	x7, x30, [x5, #0x20]
1000a5198:     	ldp	x8, x11, [x5, #0x30]
1000a519c:     	stp	x11, x8, [sp, #0x68]
1000a51a0:     	stp	x28, x2, [x5, #0x30]
1000a51a4:     	ldp	x8, x11, [x5, #0x40]
1000a51a8:     	stp	x11, x8, [sp, #0x58]
1000a51ac:     	stp	x14, x15, [x5, #0x40]
1000a51b0:     	ldp	x8, x11, [x5, #0x50]
1000a51b4:     	stp	x11, x8, [sp, #0x48]
1000a51b8:     	ldr	x11, [sp, #0x100]
1000a51bc:     	stp	x17, x11, [x5, #0x50]
1000a51c0:     	ldp	x8, x11, [x5, #0x60]
1000a51c4:     	str	x11, [sp, #0x40]
1000a51c8:     	ldr	x11, [sp, #0x108]
1000a51cc:     	str	x11, [x5, #0x60]
1000a51d0:     	ldr	x11, [sp, #0x110]
1000a51d4:     	str	x11, [x5, #0x68]
1000a51d8:     	ldr	x11, [x5, #0x70]
1000a51dc:     	str	x11, [sp, #0x110]
1000a51e0:     	ldr	x11, [x5, #0x78]
1000a51e4:     	stp	x8, x11, [sp, #0x100]
1000a51e8:     	ldp	x8, x11, [sp, #0x118]
1000a51ec:     	stp	x8, x11, [x5, #0x70]
1000a51f0:     	ldp	x8, x11, [x5, #0x80]
1000a51f4:     	stp	x11, x8, [sp, #0x118]
1000a51f8:     	ldp	x8, x11, [sp, #0x128]
1000a51fc:     	stp	x8, x11, [x5, #0x80]
1000a5200:     	ldp	x11, x2, [x5, #0x90]
1000a5204:     	str	x11, [sp, #0x130]
1000a5208:     	ldp	x8, x11, [sp, #0x138]
1000a520c:     	stp	x8, x11, [x5, #0x90]
1000a5210:     	ldp	x11, x7, [x5, #0xa0]
1000a5214:     	str	x11, [sp, #0x140]
1000a5218:     	ldr	x8, [sp, #0x148]
1000a521c:     	ldr	x11, [sp, #0xe8]
1000a5220:     	stp	x8, x11, [x5, #0xa0]
1000a5224:     	ldp	x0, x16, [x5, #0xb0]
1000a5228:     	ldp	x8, x14, [sp, #0xf0]
1000a522c:     	ldr	x11, [sp, #0x150]
1000a5230:     	stp	x8, x11, [x5, #0xb0]
1000a5234:     	ldp	x11, x30, [x5, #0xc0]
1000a5238:     	stp	x27, x22, [x5, #0xc0]
1000a523c:     	ldp	x8, x23, [x5, #0xd0]
1000a5240:     	stp	x26, x1, [x5, #0xd0]
1000a5244:     	ldp	x1, x19, [x5, #0xe0]
1000a5248:     	stp	x25, x9, [x5, #0xe0]
1000a524c:     	ldp	x9, x13, [x5, #0xf0]
1000a5250:     	stp	x10, x12, [x5, #0xf0]
1000a5254:     	ldp	x17, x15, [x5, #0x100]
1000a5258:     	ldr	x12, [sp, #0xe0]
1000a525c:     	stp	x14, x12, [x5, #0x100]
1000a5260:     	ldr	w12, [x5, #0x4]
1000a5264:     	ldr	w10, [sp, #0x2c]
1000a5268:     	mov	w28, #0x2               ; =2
1000a526c:     	stp	w28, w10, [x5]
1000a5270:     	mov	x5, x15
1000a5274:     	stp	x0, x17, [sp, #0xf0]
1000a5278:     	mov	x10, x9
1000a527c:     	mov	x25, x1
1000a5280:     	mov	x26, x8
1000a5284:     	mov	x22, x30
1000a5288:     	mov	x27, x11
1000a528c:     	str	x7, [sp, #0xe8]
1000a5290:     	ldr	x8, [sp, #0x140]
1000a5294:     	stp	x8, x16, [sp, #0x148]
1000a5298:     	ldr	x8, [sp, #0x130]
1000a529c:     	stp	x8, x2, [sp, #0x138]
1000a52a0:     	ldp	x9, x8, [sp, #0x118]
1000a52a4:     	stp	x8, x9, [sp, #0x128]
1000a52a8:     	ldp	x9, x8, [sp, #0x108]
1000a52ac:     	stp	x8, x9, [sp, #0x118]
1000a52b0:     	ldr	x9, [sp, #0x40]
1000a52b4:     	ldr	x8, [sp, #0x100]
1000a52b8:     	stp	x8, x9, [sp, #0x108]
1000a52bc:     	ldp	x8, x17, [sp, #0x48]
1000a52c0:     	str	x8, [sp, #0x100]
1000a52c4:     	ldp	x15, x14, [sp, #0x58]
1000a52c8:     	ldp	x2, x28, [sp, #0x68]
1000a52cc:     	ldp	x30, x7, [sp, #0x78]
1000a52d0:     	ldp	x16, x11, [sp, #0x88]
1000a52d4:     	str	w12, [sp, #0x2c]
1000a52d8:     	ldr	x0, [sp, #0xc0]
1000a52dc:     	b	0x1000a545c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x874>
1000a52e0:     	mov	x12, #0x0               ; =0
1000a52e4:     	mov	w4, #0x1                ; =1
1000a52e8:     	cmp	x12, x8
1000a52ec:     	b.hs	0x1000a5454 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x86c>
1000a52f0:     	ldr	x8, [sp, #0xc8]
1000a52f4:     	cmp	x8, #0x2, lsl #12       ; =0x2000
1000a52f8:     	b.hs	0x1000a5454 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x86c>
1000a52fc:     	add	x8, x8, #0x1
1000a5300:     	ldr	x9, [sp, #0xc0]
1000a5304:     	str	x8, [sp, #0xc8]
1000a5308:     	str	x8, [x9, #0x18]
1000a530c:     	ldr	x8, [x9, #0x10]
1000a5310:     	madd	x20, x12, x3, x8
1000a5314:     	ldr	w5, [x20]
1000a5318:     	cmp	w5, #0x1
1000a531c:     	b.ne	0x1000a5334 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x74c>
1000a5320:     	ldr	x8, [sp, #0x30]
1000a5324:     	subs	x8, x8, #0x1
1000a5328:     	csel	x8, xzr, x8, lo
1000a532c:     	str	x8, [sp, #0x30]
1000a5330:     	str	x8, [x9, #0x20]
1000a5334:     	ldp	x9, x8, [x20, #0x8]
1000a5338:     	stp	x8, x9, [sp, #0x88]
1000a533c:     	stp	x24, x11, [x20, #0x8]
1000a5340:     	ldp	x9, x8, [x20, #0x18]
1000a5344:     	stp	x8, x9, [sp, #0x78]
1000a5348:     	stp	x16, x7, [x20, #0x18]
1000a534c:     	ldp	x9, x8, [x20, #0x28]
1000a5350:     	stp	x8, x9, [sp, #0x68]
1000a5354:     	stp	x30, x28, [x20, #0x28]
1000a5358:     	ldp	x9, x8, [x20, #0x38]
1000a535c:     	stp	x8, x9, [sp, #0x58]
1000a5360:     	stp	x2, x14, [x20, #0x38]
1000a5364:     	ldp	x9, x8, [x20, #0x48]
1000a5368:     	stp	x8, x9, [sp, #0x48]
1000a536c:     	stp	x15, x17, [x20, #0x48]
1000a5370:     	ldp	x9, x8, [x20, #0x58]
1000a5374:     	stp	x8, x9, [sp, #0x38]
1000a5378:     	ldp	x9, x8, [sp, #0x100]
1000a537c:     	stp	x9, x8, [x20, #0x58]
1000a5380:     	ldp	x9, x8, [x20, #0x68]
1000a5384:     	stp	x8, x9, [sp, #0x100]
1000a5388:     	ldp	x9, x8, [sp, #0x110]
1000a538c:     	stp	x9, x8, [x20, #0x68]
1000a5390:     	ldp	x9, x8, [x20, #0x78]
1000a5394:     	stp	x8, x9, [sp, #0x110]
1000a5398:     	ldp	x9, x8, [sp, #0x120]
1000a539c:     	stp	x9, x8, [x20, #0x78]
1000a53a0:     	ldp	x15, x2, [x20, #0x88]
1000a53a4:     	ldp	x9, x8, [sp, #0x130]
1000a53a8:     	stp	x9, x8, [x20, #0x88]
1000a53ac:     	ldp	x14, x17, [x20, #0x98]
1000a53b0:     	ldp	x9, x8, [sp, #0x140]
1000a53b4:     	stp	x9, x8, [x20, #0x98]
1000a53b8:     	ldp	x12, x4, [x20, #0xa8]
1000a53bc:     	ldp	x9, x8, [sp, #0xe8]
1000a53c0:     	stp	x9, x8, [x20, #0xa8]
1000a53c4:     	ldp	x8, x9, [x20, #0xb8]
1000a53c8:     	ldr	x11, [sp, #0x150]
1000a53cc:     	stp	x11, x27, [x20, #0xb8]
1000a53d0:     	ldp	x30, x11, [x20, #0xc8]
1000a53d4:     	stp	x22, x26, [x20, #0xc8]
1000a53d8:     	ldp	x16, x7, [x20, #0xd8]
1000a53dc:     	stp	x23, x25, [x20, #0xd8]
1000a53e0:     	ldp	x24, x28, [x20, #0xe8]
1000a53e4:     	stp	x19, x10, [x20, #0xe8]
1000a53e8:     	ldp	x26, x27, [x20, #0xf8]
1000a53ec:     	ldr	x0, [sp, #0xf8]
1000a53f0:     	stp	x13, x0, [x20, #0xf8]
1000a53f4:     	ldr	x0, [x20, #0x108]
1000a53f8:     	ldr	x1, [sp, #0xe0]
1000a53fc:     	str	x1, [x20, #0x108]
1000a5400:     	ldr	w1, [x20, #0x4]
1000a5404:     	ldr	w10, [sp, #0xd4]
1000a5408:     	mov	w23, #0x2               ; =2
1000a540c:     	stp	w23, w10, [x20]
1000a5410:     	strb	wzr, [sp, #0x15c]
1000a5414:     	cmp	w5, #0x2
1000a5418:     	b.hs	0x1000a4c94 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0xac>
1000a541c:     	ldr	x14, [sp, #0xd8]
1000a5420:     	mul	x14, x14, x6
1000a5424:     	ldr	x0, [sp, #0xc0]
1000a5428:     	add	x21, x21, #0x1
1000a542c:     	mov	x13, x1
1000a5430:     	ldr	x12, [sp, #0xa0]
1000a5434:     	cmp	x21, x12
1000a5438:     	b.ne	0x1000a4dd4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x1ec>
1000a543c:     	b	0x1000a4c58 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x70>
1000a5440:     	cmp	x12, x8
1000a5444:     	csel	x12, x1, x12, eq
1000a5448:     	mov	w4, #0x1                ; =1
1000a544c:     	cmp	x12, x8
1000a5450:     	b.lo	0x1000a52f0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x708>
1000a5454:     	ldr	x0, [sp, #0xc0]
1000a5458:     	ldr	x5, [sp, #0xe0]
1000a545c:     	strb	w4, [sp, #0x15c]
1000a5460:     	ldr	w1, [sp, #0xd4]
1000a5464:     	ldp	x4, x20, [sp, #0xf0]
1000a5468:     	ldr	x12, [sp, #0xe8]
1000a546c:     	b	0x1000a4cf8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x110>
1000a5470:     	ldr	x8, [sp, #0x10]
1000a5474:     	add	x8, x10, x8
1000a5478:     	str	x8, [x0, #0x48]
1000a547c:     	eor	x8, x14, x14, lsr #30
1000a5480:     	mov	x9, #0xe5b9             ; =58809
1000a5484:     	movk	x9, #0x1ce4, lsl #16
1000a5488:     	movk	x9, #0x476d, lsl #32
1000a548c:     	movk	x9, #0xbf58, lsl #48
1000a5490:     	mul	x8, x8, x9
1000a5494:     	eor	x8, x8, x8, lsr #27
1000a5498:     	mov	x9, #0x11eb             ; =4587
1000a549c:     	movk	x9, #0x1331, lsl #16
1000a54a0:     	movk	x9, #0x49bb, lsl #32
1000a54a4:     	movk	x9, #0x94d0, lsl #48
1000a54a8:     	mul	x8, x8, x9
1000a54ac:     	eor	x0, x8, x8, lsr #31
1000a54b0:     	ldp	x29, x30, [sp, #0x1b0]
1000a54b4:     	ldp	x20, x19, [sp, #0x1a0]
1000a54b8:     	ldp	x22, x21, [sp, #0x190]
1000a54bc:     	ldp	x24, x23, [sp, #0x180]
1000a54c0:     	ldp	x26, x25, [sp, #0x170]
1000a54c4:     	ldp	x28, x27, [sp, #0x160]
1000a54c8:     	add	sp, sp, #0x1c0
1000a54cc:     	ret

