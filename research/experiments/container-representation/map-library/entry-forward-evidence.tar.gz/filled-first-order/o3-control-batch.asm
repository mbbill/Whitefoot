
<scratch-root>/whitefoot-map-first-probe-peel-retry1/control-timed:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000a3c2c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd>:
1000a3c2c: d29cb729    	mov	x9, #0xe5b9             ; =58809
1000a3c30: f2a39c89    	movk	x9, #0x1ce4, lsl #16
1000a3c34: f2c8eda9    	movk	x9, #0x476d, lsl #32
1000a3c38: f2f7eb09    	movk	x9, #0xbf58, lsl #48
1000a3c3c: d2823d68    	mov	x8, #0x11eb             ; =4587
1000a3c40: f2a26628    	movk	x8, #0x1331, lsl #16
1000a3c44: f2c93768    	movk	x8, #0x49bb, lsl #32
1000a3c48: f2f29a08    	movk	x8, #0x94d0, lsl #48
1000a3c4c: f9401c0a    	ldr	x10, [x0, #0x38]
1000a3c50: b40017c1    	cbz	x1, 0x1000a3f48 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x31c>
1000a3c54: a9442c0c    	ldp	x12, x11, [x0, #0x40]
1000a3c58: b400174c    	cbz	x12, 0x1000a3f40 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x314>
1000a3c5c: d101c3ff    	sub	sp, sp, #0x70
1000a3c60: a9016ffc    	stp	x28, x27, [sp, #0x10]
1000a3c64: a90267fa    	stp	x26, x25, [sp, #0x20]
1000a3c68: a9035ff8    	stp	x24, x23, [sp, #0x30]
1000a3c6c: a90457f6    	stp	x22, x21, [sp, #0x40]
1000a3c70: a9054ff4    	stp	x20, x19, [sp, #0x50]
1000a3c74: a9067bfd    	stp	x29, x30, [sp, #0x60]
1000a3c78: d280000d    	mov	x13, #0x0               ; =0
1000a3c7c: a9423813    	ldp	x19, x14, [x0, #0x20]
1000a3c80: 3940c00f    	ldrb	w15, [x0, #0x30]
1000a3c84: 52800030    	mov	w16, #0x1               ; =1
1000a3c88: 52800311    	mov	w17, #0x18              ; =24
1000a3c8c: 52800043    	mov	w3, #0x2                ; =2
1000a3c90: 52801064    	mov	w4, #0x83               ; =131
1000a3c94: aa0a03e6    	mov	x6, x10
1000a3c98: f9400c07    	ldr	x7, [x0, #0x18]
1000a3c9c: 14000005    	b	0x1000a3cb0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x84>
1000a3ca0: f900240b    	str	x11, [x0, #0x48]
1000a3ca4: 910005ad    	add	x13, x13, #0x1
1000a3ca8: eb0101bf    	cmp	x13, x1
1000a3cac: 54001300    	b.eq	0x1000a3f0c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2e0>
1000a3cb0: d2800014    	mov	x20, #0x0               ; =0
1000a3cb4: 9100056b    	add	x11, x11, #0x1
1000a3cb8: 9b0c2975    	madd	x21, x11, x12, x10
1000a3cbc: 1400000a    	b	0x1000a3ce4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xb8>
1000a3cc0: 390033f0    	strb	w16, [sp, #0xc]
1000a3cc4: 7200021f    	tst	w16, #0x1
1000a3cc8: 9a900618    	cinc	x24, x16, ne
1000a3ccc: 9b0458c5    	madd	x5, x6, x4, x22
1000a3cd0: 8b1800a5    	add	x5, x5, x24
1000a3cd4: 9b045ca6    	madd	x6, x5, x4, x23
1000a3cd8: 91000694    	add	x20, x20, #0x1
1000a3cdc: eb0c029f    	cmp	x20, x12
1000a3ce0: 54fffe00    	b.eq	0x1000a3ca0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x74>
1000a3ce4: aa140616    	orr	x22, x16, x20, lsl #1
1000a3ce8: b4000662    	cbz	x2, 0x1000a3db4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x188>
1000a3cec: b40007a7    	cbz	x7, 0x1000a3de0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b4>
1000a3cf0: 360000af    	tbz	w15, #0x0, 0x1000a3d04 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xd8>
1000a3cf4: d2800018    	mov	x24, #0x0               ; =0
1000a3cf8: f9400017    	ldr	x23, [x0]
1000a3cfc: b5000157    	cbnz	x23, 0x1000a3d24 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xf8>
1000a3d00: 14000038    	b	0x1000a3de0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b4>
1000a3d04: ca1601c5    	eor	x5, x14, x22
1000a3d08: ca4578a5    	eor	x5, x5, x5, lsr #30
1000a3d0c: 9b097ca5    	mul	x5, x5, x9
1000a3d10: ca456ca5    	eor	x5, x5, x5, lsr #27
1000a3d14: 9b087ca5    	mul	x5, x5, x8
1000a3d18: ca457cb8    	eor	x24, x5, x5, lsr #31
1000a3d1c: f9400017    	ldr	x23, [x0]
1000a3d20: b4000617    	cbz	x23, 0x1000a3de0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b4>
1000a3d24: d10006e5    	sub	x5, x23, #0x1
1000a3d28: ea0502ff    	tst	x23, x5
1000a3d2c: 54000080    	b.eq	0x1000a3d3c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x110>
1000a3d30: 9ad70b05    	udiv	x5, x24, x23
1000a3d34: 9b17e0b8    	msub	x24, x5, x23, x24
1000a3d38: 14000002    	b	0x1000a3d40 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x114>
1000a3d3c: 8a1800b8    	and	x24, x5, x24
1000a3d40: f9400819    	ldr	x25, [x0, #0x10]
1000a3d44: aa1703fa    	mov	x26, x23
1000a3d48: 14000006    	b	0x1000a3d60 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x134>
1000a3d4c: 91000705    	add	x5, x24, #0x1
1000a3d50: eb1700bf    	cmp	x5, x23
1000a3d54: 9a9827f8    	csinc	x24, xzr, x24, hs
1000a3d58: f100075a    	subs	x26, x26, #0x1
1000a3d5c: 54000420    	b.eq	0x1000a3de0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b4>
1000a3d60: 9b11671b    	madd	x27, x24, x17, x25
1000a3d64: b940037c    	ldr	w28, [x27]
1000a3d68: 7100079f    	cmp	w28, #0x1
1000a3d6c: 54ffff00    	b.eq	0x1000a3d4c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x120>
1000a3d70: 71000b9f    	cmp	w28, #0x2
1000a3d74: 54000361    	b.ne	0x1000a3de0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b4>
1000a3d78: f9400765    	ldr	x5, [x27, #0x8]
1000a3d7c: eb1600bf    	cmp	x5, x22
1000a3d80: 54fffe61    	b.ne	0x1000a3d4c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x120>
1000a3d84: f9400b65    	ldr	x5, [x27, #0x10]
1000a3d88: b9000370    	str	w16, [x27]
1000a3d8c: d10004e7    	sub	x7, x7, #0x1
1000a3d90: a900ff7f    	stp	xzr, xzr, [x27, #0x8]
1000a3d94: b1000673    	adds	x19, x19, #0x1
1000a3d98: da9f3273    	csinv	x19, x19, xzr, lo
1000a3d9c: a901cc07    	stp	x7, x19, [x0, #0x18]
1000a3da0: 9b047ed7    	mul	x23, x22, x4
1000a3da4: 52886138    	mov	w24, #0x4309            ; =17161
1000a3da8: 9b185cc6    	madd	x6, x6, x24, x23
1000a3dac: 8b0500c5    	add	x5, x6, x5
1000a3db0: 91020ca6    	add	x6, x5, #0x83
1000a3db4: 360001af    	tbz	w15, #0x0, 0x1000a3de8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1bc>
1000a3db8: d2800019    	mov	x25, #0x0               ; =0
1000a3dbc: 8b1402b7    	add	x23, x21, x20
1000a3dc0: f9400018    	ldr	x24, [x0]
1000a3dc4: b4000258    	cbz	x24, 0x1000a3e0c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1e0>
1000a3dc8: d1000705    	sub	x5, x24, #0x1
1000a3dcc: ea05031f    	tst	x24, x5
1000a3dd0: 54000220    	b.eq	0x1000a3e14 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1e8>
1000a3dd4: 9ad80b25    	udiv	x5, x25, x24
1000a3dd8: 9b18e4ba    	msub	x26, x5, x24, x25
1000a3ddc: 1400000f    	b	0x1000a3e18 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1ec>
1000a3de0: 9b047cc6    	mul	x6, x6, x4
1000a3de4: 3707feaf    	tbnz	w15, #0x0, 0x1000a3db8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x18c>
1000a3de8: ca1601c5    	eor	x5, x14, x22
1000a3dec: ca4578a5    	eor	x5, x5, x5, lsr #30
1000a3df0: 9b097ca5    	mul	x5, x5, x9
1000a3df4: ca456ca5    	eor	x5, x5, x5, lsr #27
1000a3df8: 9b087ca5    	mul	x5, x5, x8
1000a3dfc: ca457cb9    	eor	x25, x5, x5, lsr #31
1000a3e00: 8b1402b7    	add	x23, x21, x20
1000a3e04: f9400018    	ldr	x24, [x0]
1000a3e08: b5fffe18    	cbnz	x24, 0x1000a3dc8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x19c>
1000a3e0c: d2800019    	mov	x25, #0x0               ; =0
1000a3e10: 1400001f    	b	0x1000a3e8c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x260>
1000a3e14: 8a1900ba    	and	x26, x5, x25
1000a3e18: f940081b    	ldr	x27, [x0, #0x10]
1000a3e1c: aa1803fc    	mov	x28, x24
1000a3e20: aa1803f9    	mov	x25, x24
1000a3e24: 14000008    	b	0x1000a3e44 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x218>
1000a3e28: eb18033f    	cmp	x25, x24
1000a3e2c: 9a990359    	csel	x25, x26, x25, eq
1000a3e30: 91000745    	add	x5, x26, #0x1
1000a3e34: eb1800bf    	cmp	x5, x24
1000a3e38: 9a9a27fa    	csinc	x26, xzr, x26, hs
1000a3e3c: f100079c    	subs	x28, x28, #0x1
1000a3e40: 54000260    	b.eq	0x1000a3e8c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x260>
1000a3e44: 9b116f5e    	madd	x30, x26, x17, x27
1000a3e48: b94003c5    	ldr	w5, [x30]
1000a3e4c: 710004bf    	cmp	w5, #0x1
1000a3e50: 54fffec0    	b.eq	0x1000a3e28 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
1000a3e54: 710008bf    	cmp	w5, #0x2
1000a3e58: 54000161    	b.ne	0x1000a3e84 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x258>
1000a3e5c: f94007c5    	ldr	x5, [x30, #0x8]
1000a3e60: eb1600bf    	cmp	x5, x22
1000a3e64: 54fffe61    	b.ne	0x1000a3e30 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x204>
1000a3e68: f9400bc5    	ldr	x5, [x30, #0x10]
1000a3e6c: b90003c3    	str	w3, [x30]
1000a3e70: f9000bd7    	str	x23, [x30, #0x10]
1000a3e74: 390033ff    	strb	wzr, [sp, #0xc]
1000a3e78: 52800038    	mov	w24, #0x1               ; =1
1000a3e7c: aa0503f7    	mov	x23, x5
1000a3e80: 17ffff93    	b	0x1000a3ccc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xa0>
1000a3e84: eb18033f    	cmp	x25, x24
1000a3e88: 9a990359    	csel	x25, x26, x25, eq
1000a3e8c: eb18033f    	cmp	x25, x24
1000a3e90: 54fff182    	b.hs	0x1000a3cc0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
1000a3e94: f14008ff    	cmp	x7, #0x2, lsl #12       ; =0x2000
1000a3e98: 54fff142    	b.hs	0x1000a3cc0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
1000a3e9c: 910004e7    	add	x7, x7, #0x1
1000a3ea0: f9000c07    	str	x7, [x0, #0x18]
1000a3ea4: f9400805    	ldr	x5, [x0, #0x10]
1000a3ea8: 9b111738    	madd	x24, x25, x17, x5
1000a3eac: b940031b    	ldr	w27, [x24]
1000a3eb0: 7100077f    	cmp	w27, #0x1
1000a3eb4: 540000e1    	b.ne	0x1000a3ed0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2a4>
1000a3eb8: f1000665    	subs	x5, x19, #0x1
1000a3ebc: 9a8533f3    	csel	x19, xzr, x5, lo
1000a3ec0: f9001013    	str	x19, [x0, #0x20]
1000a3ec4: b9000303    	str	w3, [x24]
1000a3ec8: a900df16    	stp	x22, x23, [x24, #0x8]
1000a3ecc: 1400000a    	b	0x1000a3ef4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2c8>
1000a3ed0: a940eb19    	ldp	x25, x26, [x24, #0x8]
1000a3ed4: b9000303    	str	w3, [x24]
1000a3ed8: a900df16    	stp	x22, x23, [x24, #0x8]
1000a3edc: 340000db    	cbz	w27, 0x1000a3ef4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2c8>
1000a3ee0: 390033ff    	strb	wzr, [sp, #0xc]
1000a3ee4: 52800038    	mov	w24, #0x1               ; =1
1000a3ee8: aa1a03f7    	mov	x23, x26
1000a3eec: aa1903f6    	mov	x22, x25
1000a3ef0: 17ffff77    	b	0x1000a3ccc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xa0>
1000a3ef4: 390033ff    	strb	wzr, [sp, #0xc]
1000a3ef8: 9b047cc6    	mul	x6, x6, x4
1000a3efc: 91000694    	add	x20, x20, #0x1
1000a3f00: eb0c029f    	cmp	x20, x12
1000a3f04: 54ffef01    	b.ne	0x1000a3ce4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xb8>
1000a3f08: 17ffff66    	b	0x1000a3ca0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x74>
1000a3f0c: a9467bfd    	ldp	x29, x30, [sp, #0x60]
1000a3f10: a9454ff4    	ldp	x20, x19, [sp, #0x50]
1000a3f14: a94457f6    	ldp	x22, x21, [sp, #0x40]
1000a3f18: a9435ff8    	ldp	x24, x23, [sp, #0x30]
1000a3f1c: a94267fa    	ldp	x26, x25, [sp, #0x20]
1000a3f20: a9416ffc    	ldp	x28, x27, [sp, #0x10]
1000a3f24: 9101c3ff    	add	sp, sp, #0x70
1000a3f28: ca4678ca    	eor	x10, x6, x6, lsr #30
1000a3f2c: 9b097d49    	mul	x9, x10, x9
1000a3f30: ca496d29    	eor	x9, x9, x9, lsr #27
1000a3f34: 9b087d28    	mul	x8, x9, x8
1000a3f38: ca487d00    	eor	x0, x8, x8, lsr #31
1000a3f3c: d65f03c0    	ret
1000a3f40: 8b01016b    	add	x11, x11, x1
1000a3f44: f900240b    	str	x11, [x0, #0x48]
1000a3f48: ca4a794a    	eor	x10, x10, x10, lsr #30
1000a3f4c: 9b097d49    	mul	x9, x10, x9
1000a3f50: ca496d29    	eor	x9, x9, x9, lsr #27
1000a3f54: 9b087d28    	mul	x8, x9, x8
1000a3f58: ca487d00    	eor	x0, x8, x8, lsr #31
1000a3f5c: d65f03c0    	ret
