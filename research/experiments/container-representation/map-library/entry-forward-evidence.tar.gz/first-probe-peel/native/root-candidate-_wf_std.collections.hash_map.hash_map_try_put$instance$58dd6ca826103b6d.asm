00000001000a8528 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d>:
1000a8528:     	mov	x9, x3
1000a852c:     	mov	x3, x2
1000a8530:     	ldrb	w8, [x4, #0x8]
1000a8534:     	tbz	w8, #0x0, 0x1000a85f0 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xc8>
1000a8538:     	mov	x8, #0x0                ; =0
1000a853c:     	ldr	x10, [x1]
1000a8540:     	cbz	x10, 0x1000a8634 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x10c>
1000a8544:     	sub	x11, x10, #0x1
1000a8548:     	tst	x10, x11
1000a854c:     	b.eq	0x1000a8644 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x11c>
1000a8550:     	udiv	x11, x8, x10
1000a8554:     	msub	x8, x11, x10, x8
1000a8558:     	ldr	x11, [x1, #0x10]
1000a855c:     	mov	w12, #0x110             ; =272
1000a8560:     	madd	x12, x8, x12, x11
1000a8564:     	ldr	w13, [x12]
1000a8568:     	cbz	w13, 0x1000a865c <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x134>
1000a856c:     	mov	x2, x8
1000a8570:     	cmp	w13, #0x1
1000a8574:     	b.eq	0x1000a8588 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x60>
1000a8578:     	ldr	x12, [x12, #0x8]
1000a857c:     	mov	x2, x10
1000a8580:     	cmp	x12, x3
1000a8584:     	b.eq	0x1000a85e4 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xbc>
1000a8588:     	subs	x12, x10, #0x1
1000a858c:     	b.eq	0x1000a8660 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x138>
1000a8590:     	add	x13, x8, #0x1
1000a8594:     	cmp	x13, x10
1000a8598:     	csinc	x8, xzr, x8, hs
1000a859c:     	mov	w13, #0x110             ; =272
1000a85a0:     	b	0x1000a85c0 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x98>
1000a85a4:     	cmp	x2, x10
1000a85a8:     	csel	x2, x8, x2, eq
1000a85ac:     	add	x14, x8, #0x1
1000a85b0:     	cmp	x14, x10
1000a85b4:     	csinc	x8, xzr, x8, hs
1000a85b8:     	subs	x12, x12, #0x1
1000a85bc:     	b.eq	0x1000a8660 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x138>
1000a85c0:     	madd	x14, x8, x13, x11
1000a85c4:     	ldr	w15, [x14]
1000a85c8:     	cmp	w15, #0x1
1000a85cc:     	b.eq	0x1000a85a4 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x7c>
1000a85d0:     	cmp	w15, #0x2
1000a85d4:     	b.ne	0x1000a86ac <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x184>
1000a85d8:     	ldr	x14, [x14, #0x8]
1000a85dc:     	cmp	x14, x3
1000a85e0:     	b.ne	0x1000a85ac <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x84>
1000a85e4:     	mov	x2, x8
1000a85e8:     	mov	x4, x9
1000a85ec:     	b	0x1000ab6b0 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449>
1000a85f0:     	ldr	x8, [x4]
1000a85f4:     	eor	x8, x8, x3
1000a85f8:     	eor	x8, x8, x8, lsr #30
1000a85fc:     	mov	x10, #0xe5b9            ; =58809
1000a8600:     	movk	x10, #0x1ce4, lsl #16
1000a8604:     	movk	x10, #0x476d, lsl #32
1000a8608:     	movk	x10, #0xbf58, lsl #48
1000a860c:     	mul	x8, x8, x10
1000a8610:     	eor	x8, x8, x8, lsr #27
1000a8614:     	mov	x10, #0x11eb            ; =4587
1000a8618:     	movk	x10, #0x1331, lsl #16
1000a861c:     	movk	x10, #0x49bb, lsl #32
1000a8620:     	movk	x10, #0x94d0, lsl #48
1000a8624:     	mul	x8, x8, x10
1000a8628:     	eor	x8, x8, x8, lsr #31
1000a862c:     	ldr	x10, [x1]
1000a8630:     	cbnz	x10, 0x1000a8544 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x1c>
1000a8634:     	mov	x2, #0x0                ; =0
1000a8638:     	cmp	x2, x10
1000a863c:     	b.lo	0x1000a8668 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x140>
1000a8640:     	b	0x1000a86bc <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x194>
1000a8644:     	and	x8, x11, x8
1000a8648:     	ldr	x11, [x1, #0x10]
1000a864c:     	mov	w12, #0x110             ; =272
1000a8650:     	madd	x12, x8, x12, x11
1000a8654:     	ldr	w13, [x12]
1000a8658:     	cbnz	w13, 0x1000a856c <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x44>
1000a865c:     	mov	x2, x8
1000a8660:     	cmp	x2, x10
1000a8664:     	b.hs	0x1000a86bc <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x194>
1000a8668:     	ldr	x8, [x1, #0x18]
1000a866c:     	lsr	x10, x8, #13
1000a8670:     	cbnz	x10, 0x1000a86bc <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x194>
1000a8674:     	add	x8, x8, #0x1
1000a8678:     	str	x8, [x1, #0x18]
1000a867c:     	ldr	x8, [x1, #0x10]
1000a8680:     	mov	w10, #0x110             ; =272
1000a8684:     	mul	x10, x2, x10
1000a8688:     	ldr	w8, [x8, x10]
1000a868c:     	cmp	w8, #0x1
1000a8690:     	b.ne	0x1000a86a4 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x17c>
1000a8694:     	ldr	x8, [x1, #0x20]
1000a8698:     	subs	x8, x8, #0x1
1000a869c:     	csel	x8, xzr, x8, lo
1000a86a0:     	str	x8, [x1, #0x20]
1000a86a4:     	mov	x4, x9
1000a86a8:     	b	0x1000ab6b0 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449>
1000a86ac:     	cmp	x2, x10
1000a86b0:     	csel	x2, x8, x2, eq
1000a86b4:     	cmp	x2, x10
1000a86b8:     	b.lo	0x1000a8668 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x140>
1000a86bc:     	ldp	q0, q1, [x9]
1000a86c0:     	ldp	q2, q3, [x9, #0x20]
1000a86c4:     	ldp	q4, q5, [x9, #0x40]
1000a86c8:     	ldp	q6, q7, [x9, #0x60]
1000a86cc:     	ldp	q16, q17, [x9, #0x80]
1000a86d0:     	ldp	q18, q19, [x9, #0xa0]
1000a86d4:     	ldp	q20, q21, [x9, #0xc0]
1000a86d8:     	ldp	q22, q23, [x9, #0xe0]
1000a86dc:     	stp	xzr, x3, [x0]
1000a86e0:     	mov	w8, #0x1                ; =1
1000a86e4:     	str	w8, [x0]
1000a86e8:     	strb	w8, [x0, #0x4]
1000a86ec:     	stp	q0, q1, [x0, #0x10]
1000a86f0:     	stp	q2, q3, [x0, #0x30]
1000a86f4:     	stp	q4, q5, [x0, #0x50]
1000a86f8:     	stp	q6, q7, [x0, #0x70]
1000a86fc:     	stp	q16, q17, [x0, #0x90]
1000a8700:     	stp	q18, q19, [x0, #0xb0]
1000a8704:     	stp	q20, q21, [x0, #0xd0]
1000a8708:     	stp	q22, q23, [x0, #0xf0]
1000a870c:     	ret
