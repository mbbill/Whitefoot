00000001000a8308 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d>:
1000a8308:     	mov	x9, x3
1000a830c:     	mov	x3, x2
1000a8310:     	ldrb	w8, [x4, #0x8]
1000a8314:     	tbz	w8, #0x0, 0x1000a833c <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x34>
1000a8318:     	mov	x8, #0x0                ; =0
1000a831c:     	ldr	x10, [x1]
1000a8320:     	cbz	x10, 0x1000a8380 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x78>
1000a8324:     	sub	x11, x10, #0x1
1000a8328:     	tst	x10, x11
1000a832c:     	b.eq	0x1000a8388 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x80>
1000a8330:     	udiv	x11, x8, x10
1000a8334:     	msub	x8, x11, x10, x8
1000a8338:     	b	0x1000a838c <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x84>
1000a833c:     	ldr	x8, [x4]
1000a8340:     	eor	x8, x8, x3
1000a8344:     	eor	x8, x8, x8, lsr #30
1000a8348:     	mov	x10, #0xe5b9            ; =58809
1000a834c:     	movk	x10, #0x1ce4, lsl #16
1000a8350:     	movk	x10, #0x476d, lsl #32
1000a8354:     	movk	x10, #0xbf58, lsl #48
1000a8358:     	mul	x8, x8, x10
1000a835c:     	eor	x8, x8, x8, lsr #27
1000a8360:     	mov	x10, #0x11eb            ; =4587
1000a8364:     	movk	x10, #0x1331, lsl #16
1000a8368:     	movk	x10, #0x49bb, lsl #32
1000a836c:     	movk	x10, #0x94d0, lsl #48
1000a8370:     	mul	x8, x8, x10
1000a8374:     	eor	x8, x8, x8, lsr #31
1000a8378:     	ldr	x10, [x1]
1000a837c:     	cbnz	x10, 0x1000a8324 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x1c>
1000a8380:     	mov	x2, #0x0                ; =0
1000a8384:     	b	0x1000a83f4 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xec>
1000a8388:     	and	x8, x11, x8
1000a838c:     	ldr	x11, [x1, #0x10]
1000a8390:     	mov	w12, #0x110             ; =272
1000a8394:     	mov	x13, x10
1000a8398:     	mov	x2, x10
1000a839c:     	b	0x1000a83bc <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xb4>
1000a83a0:     	cmp	x2, x10
1000a83a4:     	csel	x2, x8, x2, eq
1000a83a8:     	add	x14, x8, #0x1
1000a83ac:     	cmp	x14, x10
1000a83b0:     	csinc	x8, xzr, x8, hs
1000a83b4:     	subs	x13, x13, #0x1
1000a83b8:     	b.eq	0x1000a83f4 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xec>
1000a83bc:     	madd	x14, x8, x12, x11
1000a83c0:     	ldr	w15, [x14]
1000a83c4:     	cmp	w15, #0x1
1000a83c8:     	b.eq	0x1000a83a0 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x98>
1000a83cc:     	cmp	w15, #0x2
1000a83d0:     	b.ne	0x1000a83ec <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xe4>
1000a83d4:     	ldr	x14, [x14, #0x8]
1000a83d8:     	cmp	x14, x3
1000a83dc:     	b.ne	0x1000a83a8 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xa0>
1000a83e0:     	mov	x2, x8
1000a83e4:     	mov	x4, x9
1000a83e8:     	b	0x1000ab284 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449>
1000a83ec:     	cmp	x2, x10
1000a83f0:     	csel	x2, x8, x2, eq
1000a83f4:     	cmp	x2, x10
1000a83f8:     	b.hs	0x1000a8440 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x138>
1000a83fc:     	ldr	x8, [x1, #0x18]
1000a8400:     	lsr	x10, x8, #13
1000a8404:     	cbnz	x10, 0x1000a8440 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x138>
1000a8408:     	add	x8, x8, #0x1
1000a840c:     	str	x8, [x1, #0x18]
1000a8410:     	ldr	x8, [x1, #0x10]
1000a8414:     	mov	w10, #0x110             ; =272
1000a8418:     	mul	x10, x2, x10
1000a841c:     	ldr	w8, [x8, x10]
1000a8420:     	cmp	w8, #0x1
1000a8424:     	b.ne	0x1000a8438 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x130>
1000a8428:     	ldr	x8, [x1, #0x20]
1000a842c:     	subs	x8, x8, #0x1
1000a8430:     	csel	x8, xzr, x8, lo
1000a8434:     	str	x8, [x1, #0x20]
1000a8438:     	mov	x4, x9
1000a843c:     	b	0x1000ab284 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449>
1000a8440:     	ldp	q0, q1, [x9]
1000a8444:     	ldp	q2, q3, [x9, #0x20]
1000a8448:     	ldp	q4, q5, [x9, #0x40]
1000a844c:     	ldp	q6, q7, [x9, #0x60]
1000a8450:     	ldp	q16, q17, [x9, #0x80]
1000a8454:     	ldp	q18, q19, [x9, #0xa0]
1000a8458:     	ldp	q20, q21, [x9, #0xc0]
1000a845c:     	ldp	q22, q23, [x9, #0xe0]
1000a8460:     	stp	xzr, x3, [x0]
1000a8464:     	mov	w8, #0x1                ; =1
1000a8468:     	str	w8, [x0]
1000a846c:     	strb	w8, [x0, #0x4]
1000a8470:     	stp	q0, q1, [x0, #0x10]
1000a8474:     	stp	q2, q3, [x0, #0x30]
1000a8478:     	stp	q4, q5, [x0, #0x50]
1000a847c:     	stp	q6, q7, [x0, #0x70]
1000a8480:     	stp	q16, q17, [x0, #0x90]
1000a8484:     	stp	q18, q19, [x0, #0xb0]
1000a8488:     	stp	q20, q21, [x0, #0xd0]
1000a848c:     	stp	q22, q23, [x0, #0xf0]
1000a8490:     	ret
