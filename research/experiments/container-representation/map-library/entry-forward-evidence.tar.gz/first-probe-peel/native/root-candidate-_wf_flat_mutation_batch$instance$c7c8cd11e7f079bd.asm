00000001000a3d68 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd>:
1000a3d68:     	mov	x9, #0xe5b9             ; =58809
1000a3d6c:     	movk	x9, #0x1ce4, lsl #16
1000a3d70:     	movk	x9, #0x476d, lsl #32
1000a3d74:     	movk	x9, #0xbf58, lsl #48
1000a3d78:     	mov	x8, #0x11eb             ; =4587
1000a3d7c:     	movk	x8, #0x1331, lsl #16
1000a3d80:     	movk	x8, #0x49bb, lsl #32
1000a3d84:     	movk	x8, #0x94d0, lsl #48
1000a3d88:     	ldr	x10, [x0, #0x38]
1000a3d8c:     	cbz	x1, 0x1000a40ec <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x384>
1000a3d90:     	ldp	x12, x11, [x0, #0x40]
1000a3d94:     	cbz	x12, 0x1000a40e4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x37c>
1000a3d98:     	sub	sp, sp, #0x70
1000a3d9c:     	stp	x28, x27, [sp, #0x10]
1000a3da0:     	stp	x26, x25, [sp, #0x20]
1000a3da4:     	stp	x24, x23, [sp, #0x30]
1000a3da8:     	stp	x22, x21, [sp, #0x40]
1000a3dac:     	stp	x20, x19, [sp, #0x50]
1000a3db0:     	stp	x29, x30, [sp, #0x60]
1000a3db4:     	mov	x13, #0x0               ; =0
1000a3db8:     	ldp	x19, x14, [x0, #0x20]
1000a3dbc:     	ldrb	w15, [x0, #0x30]
1000a3dc0:     	mov	w16, #0x1               ; =1
1000a3dc4:     	mov	w17, #0x18              ; =24
1000a3dc8:     	mov	w3, #0x2                ; =2
1000a3dcc:     	mov	w4, #0x83               ; =131
1000a3dd0:     	mov	x6, x10
1000a3dd4:     	ldr	x7, [x0, #0x18]
1000a3dd8:     	b	0x1000a3dec <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x84>
1000a3ddc:     	str	x11, [x0, #0x48]
1000a3de0:     	add	x13, x13, #0x1
1000a3de4:     	cmp	x13, x1
1000a3de8:     	b.eq	0x1000a40b0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x348>
1000a3dec:     	mov	x20, #0x0               ; =0
1000a3df0:     	add	x11, x11, #0x1
1000a3df4:     	madd	x21, x11, x12, x10
1000a3df8:     	b	0x1000a3e20 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xb8>
1000a3dfc:     	strb	w16, [sp, #0xc]
1000a3e00:     	tst	w16, #0x1
1000a3e04:     	cinc	x24, x16, ne
1000a3e08:     	madd	x5, x6, x4, x22
1000a3e0c:     	add	x5, x5, x24
1000a3e10:     	madd	x6, x5, x4, x23
1000a3e14:     	add	x20, x20, #0x1
1000a3e18:     	cmp	x20, x12
1000a3e1c:     	b.eq	0x1000a3ddc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x74>
1000a3e20:     	orr	x22, x16, x20, lsl #1
1000a3e24:     	cbz	x2, 0x1000a3ef0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x188>
1000a3e28:     	cbz	x7, 0x1000a3f54 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1ec>
1000a3e2c:     	tbz	w15, #0x0, 0x1000a3e40 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xd8>
1000a3e30:     	mov	x24, #0x0               ; =0
1000a3e34:     	ldr	x23, [x0]
1000a3e38:     	cbnz	x23, 0x1000a3e60 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xf8>
1000a3e3c:     	b	0x1000a3f54 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1ec>
1000a3e40:     	eor	x5, x14, x22
1000a3e44:     	eor	x5, x5, x5, lsr #30
1000a3e48:     	mul	x5, x5, x9
1000a3e4c:     	eor	x5, x5, x5, lsr #27
1000a3e50:     	mul	x5, x5, x8
1000a3e54:     	eor	x24, x5, x5, lsr #31
1000a3e58:     	ldr	x23, [x0]
1000a3e5c:     	cbz	x23, 0x1000a3f54 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1ec>
1000a3e60:     	sub	x5, x23, #0x1
1000a3e64:     	tst	x23, x5
1000a3e68:     	b.eq	0x1000a3e78 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x110>
1000a3e6c:     	udiv	x5, x24, x23
1000a3e70:     	msub	x24, x5, x23, x24
1000a3e74:     	b	0x1000a3e7c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x114>
1000a3e78:     	and	x24, x5, x24
1000a3e7c:     	ldr	x25, [x0, #0x10]
1000a3e80:     	mov	x26, x23
1000a3e84:     	b	0x1000a3e9c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x134>
1000a3e88:     	add	x5, x24, #0x1
1000a3e8c:     	cmp	x5, x23
1000a3e90:     	csinc	x24, xzr, x24, hs
1000a3e94:     	subs	x26, x26, #0x1
1000a3e98:     	b.eq	0x1000a3f54 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1ec>
1000a3e9c:     	madd	x27, x24, x17, x25
1000a3ea0:     	ldr	w28, [x27]
1000a3ea4:     	cmp	w28, #0x1
1000a3ea8:     	b.eq	0x1000a3e88 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x120>
1000a3eac:     	cmp	w28, #0x2
1000a3eb0:     	b.ne	0x1000a3f54 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1ec>
1000a3eb4:     	ldr	x5, [x27, #0x8]
1000a3eb8:     	cmp	x5, x22
1000a3ebc:     	b.ne	0x1000a3e88 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x120>
1000a3ec0:     	ldr	x5, [x27, #0x10]
1000a3ec4:     	str	w16, [x27]
1000a3ec8:     	sub	x7, x7, #0x1
1000a3ecc:     	stp	xzr, xzr, [x27, #0x8]
1000a3ed0:     	adds	x19, x19, #0x1
1000a3ed4:     	csinv	x19, x19, xzr, lo
1000a3ed8:     	stp	x7, x19, [x0, #0x18]
1000a3edc:     	mul	x23, x22, x4
1000a3ee0:     	mov	w24, #0x4309            ; =17161
1000a3ee4:     	madd	x6, x6, x24, x23
1000a3ee8:     	add	x5, x6, x5
1000a3eec:     	add	x6, x5, #0x83
1000a3ef0:     	tbz	w15, #0x0, 0x1000a3f5c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1f4>
1000a3ef4:     	mov	x25, #0x0               ; =0
1000a3ef8:     	add	x23, x21, x20
1000a3efc:     	ldr	x24, [x0]
1000a3f00:     	cbz	x24, 0x1000a3f80 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x218>
1000a3f04:     	sub	x5, x24, #0x1
1000a3f08:     	tst	x24, x5
1000a3f0c:     	b.eq	0x1000a4004 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x29c>
1000a3f10:     	udiv	x5, x25, x24
1000a3f14:     	msub	x28, x5, x24, x25
1000a3f18:     	ldr	x26, [x0, #0x10]
1000a3f1c:     	madd	x27, x28, x17, x26
1000a3f20:     	ldr	w30, [x27]
1000a3f24:     	cbz	w30, 0x1000a4018 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2b0>
1000a3f28:     	mov	x25, x28
1000a3f2c:     	cmp	w30, #0x1
1000a3f30:     	b.eq	0x1000a3f90 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x228>
1000a3f34:     	mov	x25, x24
1000a3f38:     	ldr	x5, [x27, #0x8]
1000a3f3c:     	cmp	x5, x22
1000a3f40:     	b.ne	0x1000a3f90 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x228>
1000a3f44:     	ldr	x5, [x27, #0x10]
1000a3f48:     	str	w3, [x27]
1000a3f4c:     	str	x23, [x27, #0x10]
1000a3f50:     	b	0x1000a3ff4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x28c>
1000a3f54:     	mul	x6, x6, x4
1000a3f58:     	tbnz	w15, #0x0, 0x1000a3ef4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x18c>
1000a3f5c:     	eor	x5, x14, x22
1000a3f60:     	eor	x5, x5, x5, lsr #30
1000a3f64:     	mul	x5, x5, x9
1000a3f68:     	eor	x5, x5, x5, lsr #27
1000a3f6c:     	mul	x5, x5, x8
1000a3f70:     	eor	x25, x5, x5, lsr #31
1000a3f74:     	add	x23, x21, x20
1000a3f78:     	ldr	x24, [x0]
1000a3f7c:     	cbnz	x24, 0x1000a3f04 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x19c>
1000a3f80:     	mov	x25, #0x0               ; =0
1000a3f84:     	cmp	x25, x24
1000a3f88:     	b.lo	0x1000a4024 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2bc>
1000a3f8c:     	b	0x1000a3dfc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
1000a3f90:     	subs	x27, x24, #0x1
1000a3f94:     	b.eq	0x1000a401c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2b4>
1000a3f98:     	add	x5, x28, #0x1
1000a3f9c:     	cmp	x5, x24
1000a3fa0:     	csinc	x28, xzr, x28, hs
1000a3fa4:     	b	0x1000a3fc4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x25c>
1000a3fa8:     	cmp	x25, x24
1000a3fac:     	csel	x25, x28, x25, eq
1000a3fb0:     	add	x5, x28, #0x1
1000a3fb4:     	cmp	x5, x24
1000a3fb8:     	csinc	x28, xzr, x28, hs
1000a3fbc:     	subs	x27, x27, #0x1
1000a3fc0:     	b.eq	0x1000a401c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2b4>
1000a3fc4:     	madd	x30, x28, x17, x26
1000a3fc8:     	ldr	w5, [x30]
1000a3fcc:     	cmp	w5, #0x1
1000a3fd0:     	b.eq	0x1000a3fa8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x240>
1000a3fd4:     	cmp	w5, #0x2
1000a3fd8:     	b.ne	0x1000a409c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x334>
1000a3fdc:     	ldr	x5, [x30, #0x8]
1000a3fe0:     	cmp	x5, x22
1000a3fe4:     	b.ne	0x1000a3fb0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x248>
1000a3fe8:     	ldr	x5, [x30, #0x10]
1000a3fec:     	str	w3, [x30]
1000a3ff0:     	str	x23, [x30, #0x10]
1000a3ff4:     	strb	wzr, [sp, #0xc]
1000a3ff8:     	mov	w24, #0x1               ; =1
1000a3ffc:     	mov	x23, x5
1000a4000:     	b	0x1000a3e08 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xa0>
1000a4004:     	and	x28, x5, x25
1000a4008:     	ldr	x26, [x0, #0x10]
1000a400c:     	madd	x27, x28, x17, x26
1000a4010:     	ldr	w30, [x27]
1000a4014:     	cbnz	w30, 0x1000a3f28 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1c0>
1000a4018:     	mov	x25, x28
1000a401c:     	cmp	x25, x24
1000a4020:     	b.hs	0x1000a3dfc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
1000a4024:     	cmp	x7, #0x2, lsl #12       ; =0x2000
1000a4028:     	b.hs	0x1000a3dfc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
1000a402c:     	add	x7, x7, #0x1
1000a4030:     	str	x7, [x0, #0x18]
1000a4034:     	ldr	x5, [x0, #0x10]
1000a4038:     	madd	x24, x25, x17, x5
1000a403c:     	ldr	w27, [x24]
1000a4040:     	cmp	w27, #0x1
1000a4044:     	b.ne	0x1000a4060 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2f8>
1000a4048:     	subs	x5, x19, #0x1
1000a404c:     	csel	x19, xzr, x5, lo
1000a4050:     	str	x19, [x0, #0x20]
1000a4054:     	str	w3, [x24]
1000a4058:     	stp	x22, x23, [x24, #0x8]
1000a405c:     	b	0x1000a4084 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x31c>
1000a4060:     	ldp	x25, x26, [x24, #0x8]
1000a4064:     	str	w3, [x24]
1000a4068:     	stp	x22, x23, [x24, #0x8]
1000a406c:     	cbz	w27, 0x1000a4084 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x31c>
1000a4070:     	strb	wzr, [sp, #0xc]
1000a4074:     	mov	w24, #0x1               ; =1
1000a4078:     	mov	x23, x26
1000a407c:     	mov	x22, x25
1000a4080:     	b	0x1000a3e08 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xa0>
1000a4084:     	strb	wzr, [sp, #0xc]
1000a4088:     	mul	x6, x6, x4
1000a408c:     	add	x20, x20, #0x1
1000a4090:     	cmp	x20, x12
1000a4094:     	b.ne	0x1000a3e20 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xb8>
1000a4098:     	b	0x1000a3ddc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x74>
1000a409c:     	cmp	x25, x24
1000a40a0:     	csel	x25, x28, x25, eq
1000a40a4:     	cmp	x25, x24
1000a40a8:     	b.lo	0x1000a4024 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2bc>
1000a40ac:     	b	0x1000a3dfc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
1000a40b0:     	ldp	x29, x30, [sp, #0x60]
1000a40b4:     	ldp	x20, x19, [sp, #0x50]
1000a40b8:     	ldp	x22, x21, [sp, #0x40]
1000a40bc:     	ldp	x24, x23, [sp, #0x30]
1000a40c0:     	ldp	x26, x25, [sp, #0x20]
1000a40c4:     	ldp	x28, x27, [sp, #0x10]
1000a40c8:     	add	sp, sp, #0x70
1000a40cc:     	eor	x10, x6, x6, lsr #30
1000a40d0:     	mul	x9, x10, x9
1000a40d4:     	eor	x9, x9, x9, lsr #27
1000a40d8:     	mul	x8, x9, x8
1000a40dc:     	eor	x0, x8, x8, lsr #31
1000a40e0:     	ret
1000a40e4:     	add	x11, x11, x1
1000a40e8:     	str	x11, [x0, #0x48]
1000a40ec:     	eor	x10, x10, x10, lsr #30
1000a40f0:     	mul	x9, x10, x9
1000a40f4:     	eor	x9, x9, x9, lsr #27
1000a40f8:     	mul	x8, x9, x8
1000a40fc:     	eor	x0, x8, x8, lsr #31
1000a4100:     	ret
