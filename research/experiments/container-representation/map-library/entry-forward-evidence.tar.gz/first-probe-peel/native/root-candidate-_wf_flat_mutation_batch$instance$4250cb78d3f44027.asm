00000001000a47dc <_wf_flat_mutation_batch$instance$4250cb78d3f44027>:
1000a47dc:     	stp	x28, x27, [sp, #-0x60]!
1000a47e0:     	stp	x26, x25, [sp, #0x10]
1000a47e4:     	stp	x24, x23, [sp, #0x20]
1000a47e8:     	stp	x22, x21, [sp, #0x30]
1000a47ec:     	stp	x20, x19, [sp, #0x40]
1000a47f0:     	stp	x29, x30, [sp, #0x50]
1000a47f4:     	sub	sp, sp, #0x3a0
1000a47f8:     	ldr	x24, [x0, #0x38]
1000a47fc:     	str	x1, [sp, #0x8]
1000a4800:     	cbz	x1, 0x1000a4d90 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x5b4>
1000a4804:     	mov	x19, x0
1000a4808:     	ldr	x26, [x0, #0x40]
1000a480c:     	cbz	x26, 0x1000a4d80 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x5a4>
1000a4810:     	mov	x21, x2
1000a4814:     	str	xzr, [sp, #0x18]
1000a4818:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x78c>
1000a481c:     	ldr	q0, [x8, #0x810]
1000a4820:     	str	q0, [sp, #0x180]
1000a4824:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x78c>
1000a4828:     	ldr	q0, [x8, #0x5c0]
1000a482c:     	str	q0, [sp, #0x170]
1000a4830:     	add	x27, sp, #0x2a0
1000a4834:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x78c>
1000a4838:     	ldr	q0, [x8, #0x5b0]
1000a483c:     	str	q0, [sp, #0x160]
1000a4840:     	mov	w28, #0x1               ; =1
1000a4844:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x78c>
1000a4848:     	ldr	q0, [x8, #0x5e0]
1000a484c:     	str	q0, [sp, #0x150]
1000a4850:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x78c>
1000a4854:     	ldr	q0, [x8, #0x5d0]
1000a4858:     	str	q0, [sp, #0x140]
1000a485c:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x78c>
1000a4860:     	ldr	q0, [x8, #0x600]
1000a4864:     	str	q0, [sp, #0x130]
1000a4868:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x78c>
1000a486c:     	ldr	q0, [x8, #0x5f0]
1000a4870:     	str	q0, [sp, #0x120]
1000a4874:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x78c>
1000a4878:     	ldr	q0, [x8, #0x620]
1000a487c:     	str	q0, [sp, #0x110]
1000a4880:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x78c>
1000a4884:     	ldr	q0, [x8, #0x610]
1000a4888:     	str	q0, [sp, #0x100]
1000a488c:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x78c>
1000a4890:     	ldr	q0, [x8, #0x640]
1000a4894:     	str	q0, [sp, #0xf0]
1000a4898:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x78c>
1000a489c:     	ldr	q0, [x8, #0x630]
1000a48a0:     	str	q0, [sp, #0xe0]
1000a48a4:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x78c>
1000a48a8:     	ldr	q0, [x8, #0x660]
1000a48ac:     	str	q0, [sp, #0xd0]
1000a48b0:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x78c>
1000a48b4:     	ldr	q0, [x8, #0x650]
1000a48b8:     	str	q0, [sp, #0xc0]
1000a48bc:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x78c>
1000a48c0:     	ldr	q0, [x8, #0x680]
1000a48c4:     	str	q0, [sp, #0xb0]
1000a48c8:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x78c>
1000a48cc:     	ldr	q0, [x8, #0x670]
1000a48d0:     	str	q0, [sp, #0xa0]
1000a48d4:     	mov	w20, #0x83              ; =131
1000a48d8:     	mov	w22, #0x110             ; =272
1000a48dc:     	ldr	x10, [x19, #0x48]
1000a48e0:     	add	x10, x10, #0x1
1000a48e4:     	str	x10, [sp, #0x10]
1000a48e8:     	cbz	x26, 0x1000a4d54 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x578>
1000a48ec:     	mov	x23, #0x0               ; =0
1000a48f0:     	ldr	x8, [x19, #0x38]
1000a48f4:     	madd	x25, x10, x26, x8
1000a48f8:     	b	0x1000a4a04 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x228>
1000a48fc:     	ldrb	w8, [sp, #0x194]
1000a4900:     	tst	w8, #0x1
1000a4904:     	ldp	x9, x8, [sp, #0x198]
1000a4908:     	madd	x8, x9, x20, x8
1000a490c:     	ldp	x10, x9, [sp, #0x1a8]
1000a4910:     	madd	x8, x8, x20, x10
1000a4914:     	madd	x8, x8, x20, x9
1000a4918:     	ldp	x10, x9, [sp, #0x1b8]
1000a491c:     	madd	x8, x8, x20, x10
1000a4920:     	madd	x8, x8, x20, x9
1000a4924:     	ldp	x10, x9, [sp, #0x1c8]
1000a4928:     	madd	x8, x8, x20, x10
1000a492c:     	madd	x8, x8, x20, x9
1000a4930:     	ldp	x10, x9, [sp, #0x1d8]
1000a4934:     	madd	x8, x8, x20, x10
1000a4938:     	madd	x8, x8, x20, x9
1000a493c:     	ldp	x10, x9, [sp, #0x1e8]
1000a4940:     	madd	x8, x8, x20, x10
1000a4944:     	madd	x8, x8, x20, x9
1000a4948:     	ldp	x10, x9, [sp, #0x1f8]
1000a494c:     	madd	x8, x8, x20, x10
1000a4950:     	madd	x8, x8, x20, x9
1000a4954:     	ldr	x9, [sp, #0x208]
1000a4958:     	madd	x8, x8, x20, x9
1000a495c:     	ldr	x9, [sp, #0x210]
1000a4960:     	madd	x8, x8, x20, x9
1000a4964:     	ldr	x9, [sp, #0x218]
1000a4968:     	madd	x8, x8, x20, x9
1000a496c:     	ldr	x9, [sp, #0x220]
1000a4970:     	madd	x8, x8, x20, x9
1000a4974:     	ldr	x9, [sp, #0x228]
1000a4978:     	madd	x8, x8, x20, x9
1000a497c:     	ldr	x9, [sp, #0x230]
1000a4980:     	madd	x8, x8, x20, x9
1000a4984:     	ldr	x9, [sp, #0x238]
1000a4988:     	madd	x8, x8, x20, x9
1000a498c:     	ldr	x9, [sp, #0x240]
1000a4990:     	madd	x8, x8, x20, x9
1000a4994:     	ldr	x9, [sp, #0x248]
1000a4998:     	madd	x8, x8, x20, x9
1000a499c:     	ldr	x9, [sp, #0x250]
1000a49a0:     	madd	x8, x8, x20, x9
1000a49a4:     	ldr	x9, [sp, #0x258]
1000a49a8:     	madd	x8, x8, x20, x9
1000a49ac:     	ldr	x9, [sp, #0x260]
1000a49b0:     	madd	x8, x8, x20, x9
1000a49b4:     	ldr	x9, [sp, #0x268]
1000a49b8:     	madd	x8, x8, x20, x9
1000a49bc:     	ldr	x9, [sp, #0x270]
1000a49c0:     	madd	x8, x8, x20, x9
1000a49c4:     	ldr	x9, [sp, #0x278]
1000a49c8:     	madd	x8, x8, x20, x9
1000a49cc:     	ldr	x9, [sp, #0x280]
1000a49d0:     	madd	x8, x8, x20, x9
1000a49d4:     	ldr	x9, [sp, #0x288]
1000a49d8:     	add	x9, x9, x24
1000a49dc:     	ldr	x10, [sp, #0x290]
1000a49e0:     	madd	x8, x8, x20, x9
1000a49e4:     	cinc	x9, x28, ne
1000a49e8:     	add	x9, x9, x10
1000a49ec:     	madd	x8, x8, x20, x9
1000a49f0:     	ldr	x9, [sp, #0x298]
1000a49f4:     	madd	x24, x8, x20, x9
1000a49f8:     	add	x23, x23, #0x1
1000a49fc:     	cmp	x23, x26
1000a4a00:     	b.eq	0x1000a4d54 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x578>
1000a4a04:     	orr	x2, x28, x23, lsl #1
1000a4a08:     	cbz	x21, 0x1000a4c60 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x484>
1000a4a0c:     	ldr	x8, [x19, #0x18]
1000a4a10:     	cbz	x8, 0x1000a4c5c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x480>
1000a4a14:     	ldrb	w9, [x19, #0x30]
1000a4a18:     	tbz	w9, #0x0, 0x1000a4a2c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x250>
1000a4a1c:     	mov	x9, #0x0                ; =0
1000a4a20:     	ldr	x10, [x19]
1000a4a24:     	cbnz	x10, 0x1000a4a70 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x294>
1000a4a28:     	b	0x1000a4c5c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x480>
1000a4a2c:     	ldr	x9, [x19, #0x28]
1000a4a30:     	eor	x9, x9, x2
1000a4a34:     	eor	x9, x9, x9, lsr #30
1000a4a38:     	mov	x10, #0xe5b9            ; =58809
1000a4a3c:     	movk	x10, #0x1ce4, lsl #16
1000a4a40:     	movk	x10, #0x476d, lsl #32
1000a4a44:     	movk	x10, #0xbf58, lsl #48
1000a4a48:     	mul	x9, x9, x10
1000a4a4c:     	eor	x9, x9, x9, lsr #27
1000a4a50:     	mov	x10, #0x11eb            ; =4587
1000a4a54:     	movk	x10, #0x1331, lsl #16
1000a4a58:     	movk	x10, #0x49bb, lsl #32
1000a4a5c:     	movk	x10, #0x94d0, lsl #48
1000a4a60:     	mul	x9, x9, x10
1000a4a64:     	eor	x9, x9, x9, lsr #31
1000a4a68:     	ldr	x10, [x19]
1000a4a6c:     	cbz	x10, 0x1000a4c5c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x480>
1000a4a70:     	sub	x11, x10, #0x1
1000a4a74:     	tst	x10, x11
1000a4a78:     	b.eq	0x1000a4a88 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2ac>
1000a4a7c:     	udiv	x11, x9, x10
1000a4a80:     	msub	x11, x11, x10, x9
1000a4a84:     	b	0x1000a4a8c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2b0>
1000a4a88:     	and	x11, x11, x9
1000a4a8c:     	ldr	x12, [x19, #0x10]
1000a4a90:     	mov	x13, x10
1000a4a94:     	b	0x1000a4aac <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2d0>
1000a4a98:     	add	x9, x11, #0x1
1000a4a9c:     	cmp	x9, x10
1000a4aa0:     	csinc	x11, xzr, x11, hs
1000a4aa4:     	subs	x13, x13, #0x1
1000a4aa8:     	b.eq	0x1000a4c5c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x480>
1000a4aac:     	madd	x9, x11, x22, x12
1000a4ab0:     	ldr	w14, [x9]
1000a4ab4:     	cmp	w14, #0x1
1000a4ab8:     	b.eq	0x1000a4a98 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2bc>
1000a4abc:     	cmp	w14, #0x2
1000a4ac0:     	b.ne	0x1000a4c5c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x480>
1000a4ac4:     	ldr	x14, [x9, #0x8]
1000a4ac8:     	cmp	x14, x2
1000a4acc:     	b.ne	0x1000a4a98 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2bc>
1000a4ad0:     	ldp	x11, x10, [x9, #0x10]
1000a4ad4:     	stp	x10, x11, [sp, #0x90]
1000a4ad8:     	ldp	x11, x10, [x9, #0x20]
1000a4adc:     	stp	x10, x11, [sp, #0x80]
1000a4ae0:     	ldp	x14, x15, [x9, #0x30]
1000a4ae4:     	ldp	x16, x17, [x9, #0x40]
1000a4ae8:     	ldp	x0, x1, [x9, #0x50]
1000a4aec:     	ldp	x3, x4, [x9, #0x60]
1000a4af0:     	ldp	x5, x6, [x9, #0x70]
1000a4af4:     	ldp	x7, x30, [x9, #0x80]
1000a4af8:     	ldp	x11, x10, [x9, #0x90]
1000a4afc:     	stp	x10, x11, [sp, #0x70]
1000a4b00:     	ldp	x11, x10, [x9, #0xa0]
1000a4b04:     	stp	x10, x11, [sp, #0x60]
1000a4b08:     	ldp	x11, x10, [x9, #0xb0]
1000a4b0c:     	stp	x10, x11, [sp, #0x50]
1000a4b10:     	ldp	x11, x10, [x9, #0xc0]
1000a4b14:     	stp	x10, x11, [sp, #0x40]
1000a4b18:     	ldp	x11, x10, [x9, #0xd0]
1000a4b1c:     	stp	x10, x11, [sp, #0x30]
1000a4b20:     	ldp	x11, x10, [x9, #0xe0]
1000a4b24:     	stp	x10, x11, [sp, #0x20]
1000a4b28:     	str	w28, [x9]
1000a4b2c:     	movi.2d	v0, #0000000000000000
1000a4b30:     	stur	q0, [x9, #0x8]
1000a4b34:     	stur	q0, [x9, #0x18]
1000a4b38:     	stur	q0, [x9, #0x28]
1000a4b3c:     	stur	q0, [x9, #0x38]
1000a4b40:     	stur	q0, [x9, #0x48]
1000a4b44:     	stur	q0, [x9, #0x58]
1000a4b48:     	stur	q0, [x9, #0x68]
1000a4b4c:     	stur	q0, [x9, #0x78]
1000a4b50:     	stur	q0, [x9, #0x88]
1000a4b54:     	stur	q0, [x9, #0x98]
1000a4b58:     	stur	q0, [x9, #0xa8]
1000a4b5c:     	stur	q0, [x9, #0xb8]
1000a4b60:     	stur	q0, [x9, #0xc8]
1000a4b64:     	stur	q0, [x9, #0xd8]
1000a4b68:     	ldp	x12, x13, [x9, #0xf0]
1000a4b6c:     	stur	q0, [x9, #0xe8]
1000a4b70:     	ldp	x10, x11, [x9, #0x100]
1000a4b74:     	stur	q0, [x9, #0xf8]
1000a4b78:     	str	xzr, [x9, #0x108]
1000a4b7c:     	sub	x8, x8, #0x1
1000a4b80:     	ldr	x9, [x19, #0x20]
1000a4b84:     	adds	x9, x9, #0x1
1000a4b88:     	csinv	x9, x9, xzr, lo
1000a4b8c:     	stp	x8, x9, [x19, #0x18]
1000a4b90:     	ldp	x9, x8, [sp, #0x90]
1000a4b94:     	madd	x8, x2, x20, x8
1000a4b98:     	madd	x8, x8, x20, x9
1000a4b9c:     	ldr	x9, [sp, #0x88]
1000a4ba0:     	madd	x8, x8, x20, x9
1000a4ba4:     	ldr	x9, [sp, #0x80]
1000a4ba8:     	madd	x8, x8, x20, x9
1000a4bac:     	madd	x8, x8, x20, x14
1000a4bb0:     	madd	x8, x8, x20, x15
1000a4bb4:     	madd	x8, x8, x20, x16
1000a4bb8:     	madd	x8, x8, x20, x17
1000a4bbc:     	madd	x8, x8, x20, x0
1000a4bc0:     	madd	x8, x8, x20, x1
1000a4bc4:     	madd	x8, x8, x20, x3
1000a4bc8:     	madd	x8, x8, x20, x4
1000a4bcc:     	madd	x8, x8, x20, x5
1000a4bd0:     	madd	x8, x8, x20, x6
1000a4bd4:     	madd	x8, x8, x20, x7
1000a4bd8:     	madd	x8, x8, x20, x30
1000a4bdc:     	ldr	x9, [sp, #0x78]
1000a4be0:     	madd	x8, x8, x20, x9
1000a4be4:     	ldr	x9, [sp, #0x70]
1000a4be8:     	madd	x8, x8, x20, x9
1000a4bec:     	ldr	x9, [sp, #0x68]
1000a4bf0:     	madd	x8, x8, x20, x9
1000a4bf4:     	ldr	x9, [sp, #0x60]
1000a4bf8:     	madd	x8, x8, x20, x9
1000a4bfc:     	ldr	x9, [sp, #0x58]
1000a4c00:     	madd	x8, x8, x20, x9
1000a4c04:     	ldr	x9, [sp, #0x50]
1000a4c08:     	madd	x8, x8, x20, x9
1000a4c0c:     	ldr	x9, [sp, #0x48]
1000a4c10:     	madd	x8, x8, x20, x9
1000a4c14:     	ldr	x9, [sp, #0x40]
1000a4c18:     	madd	x8, x8, x20, x9
1000a4c1c:     	ldr	x9, [sp, #0x38]
1000a4c20:     	madd	x8, x8, x20, x9
1000a4c24:     	ldr	x9, [sp, #0x30]
1000a4c28:     	madd	x8, x8, x20, x9
1000a4c2c:     	ldr	x9, [sp, #0x28]
1000a4c30:     	madd	x8, x8, x20, x9
1000a4c34:     	ldr	x9, [sp, #0x20]
1000a4c38:     	madd	x8, x8, x20, x9
1000a4c3c:     	madd	x8, x8, x20, x12
1000a4c40:     	madd	x8, x8, x20, x13
1000a4c44:     	madd	x8, x8, x20, x10
1000a4c48:     	mov	w9, #0x4309             ; =17161
1000a4c4c:     	madd	x9, x24, x9, x11
1000a4c50:     	madd	x8, x8, x20, x9
1000a4c54:     	add	x24, x8, #0x83
1000a4c58:     	b	0x1000a4c60 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x484>
1000a4c5c:     	mul	x24, x24, x20
1000a4c60:     	add	x8, x25, x23
1000a4c64:     	dup.2d	v0, x8
1000a4c68:     	ldr	q1, [sp, #0x180]
1000a4c6c:     	add.2d	v1, v0, v1
1000a4c70:     	stur	q1, [x27, #0x8]
1000a4c74:     	add	x9, x8, #0x1f
1000a4c78:     	ldr	q1, [sp, #0x170]
1000a4c7c:     	add.2d	v1, v0, v1
1000a4c80:     	stur	q1, [x27, #0x18]
1000a4c84:     	ldr	q1, [sp, #0x160]
1000a4c88:     	add.2d	v1, v0, v1
1000a4c8c:     	stur	q1, [x27, #0x28]
1000a4c90:     	ldr	q1, [sp, #0x150]
1000a4c94:     	add.2d	v1, v0, v1
1000a4c98:     	stur	q1, [x27, #0x38]
1000a4c9c:     	ldr	q1, [sp, #0x140]
1000a4ca0:     	add.2d	v1, v0, v1
1000a4ca4:     	stur	q1, [x27, #0x48]
1000a4ca8:     	ldr	q1, [sp, #0x130]
1000a4cac:     	add.2d	v1, v0, v1
1000a4cb0:     	stur	q1, [x27, #0x58]
1000a4cb4:     	ldr	q1, [sp, #0x120]
1000a4cb8:     	add.2d	v1, v0, v1
1000a4cbc:     	stur	q1, [x27, #0x68]
1000a4cc0:     	ldr	q1, [sp, #0x110]
1000a4cc4:     	add.2d	v1, v0, v1
1000a4cc8:     	stur	q1, [x27, #0x78]
1000a4ccc:     	ldr	q1, [sp, #0x100]
1000a4cd0:     	add.2d	v1, v0, v1
1000a4cd4:     	stur	q1, [x27, #0x88]
1000a4cd8:     	ldr	q1, [sp, #0xf0]
1000a4cdc:     	add.2d	v1, v0, v1
1000a4ce0:     	stur	q1, [x27, #0x98]
1000a4ce4:     	ldr	q1, [sp, #0xe0]
1000a4ce8:     	add.2d	v1, v0, v1
1000a4cec:     	stur	q1, [x27, #0xa8]
1000a4cf0:     	ldr	q1, [sp, #0xd0]
1000a4cf4:     	add.2d	v1, v0, v1
1000a4cf8:     	stur	q1, [x27, #0xb8]
1000a4cfc:     	ldr	q1, [sp, #0xc0]
1000a4d00:     	add.2d	v1, v0, v1
1000a4d04:     	stur	q1, [x27, #0xc8]
1000a4d08:     	ldr	q1, [sp, #0xb0]
1000a4d0c:     	add.2d	v1, v0, v1
1000a4d10:     	stur	q1, [x27, #0xd8]
1000a4d14:     	ldr	q1, [sp, #0xa0]
1000a4d18:     	add.2d	v0, v0, v1
1000a4d1c:     	stur	q0, [x27, #0xe8]
1000a4d20:     	str	x8, [sp, #0x2a0]
1000a4d24:     	str	x9, [sp, #0x398]
1000a4d28:     	add	x0, sp, #0x190
1000a4d2c:     	add	x3, sp, #0x2a0
1000a4d30:     	add	x4, x19, #0x28
1000a4d34:     	mov	x1, x19
1000a4d38:     	bl	0x1000a8528 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d>
1000a4d3c:     	ldr	w8, [sp, #0x190]
1000a4d40:     	cbnz	w8, 0x1000a48fc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x120>
1000a4d44:     	mul	x24, x24, x20
1000a4d48:     	add	x23, x23, #0x1
1000a4d4c:     	cmp	x23, x26
1000a4d50:     	b.ne	0x1000a4a04 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x228>
1000a4d54:     	ldp	x10, x9, [sp, #0x10]
1000a4d58:     	str	x10, [x19, #0x48]
1000a4d5c:     	add	x9, x9, #0x1
1000a4d60:     	ldr	x8, [sp, #0x8]
1000a4d64:     	cmp	x9, x8
1000a4d68:     	b.eq	0x1000a4d90 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x5b4>
1000a4d6c:     	ldr	x26, [x19, #0x40]
1000a4d70:     	add	x10, x10, #0x1
1000a4d74:     	stp	x10, x9, [sp, #0x10]
1000a4d78:     	cbnz	x26, 0x1000a48ec <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x110>
1000a4d7c:     	b	0x1000a4d54 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x578>
1000a4d80:     	ldr	x8, [x19, #0x48]
1000a4d84:     	ldr	x9, [sp, #0x8]
1000a4d88:     	add	x8, x8, x9
1000a4d8c:     	str	x8, [x19, #0x48]
1000a4d90:     	eor	x8, x24, x24, lsr #30
1000a4d94:     	mov	x9, #0xe5b9             ; =58809
1000a4d98:     	movk	x9, #0x1ce4, lsl #16
1000a4d9c:     	movk	x9, #0x476d, lsl #32
1000a4da0:     	movk	x9, #0xbf58, lsl #48
1000a4da4:     	mul	x8, x8, x9
1000a4da8:     	eor	x8, x8, x8, lsr #27
1000a4dac:     	mov	x9, #0x11eb             ; =4587
1000a4db0:     	movk	x9, #0x1331, lsl #16
1000a4db4:     	movk	x9, #0x49bb, lsl #32
1000a4db8:     	movk	x9, #0x94d0, lsl #48
1000a4dbc:     	mul	x8, x8, x9
1000a4dc0:     	eor	x0, x8, x8, lsr #31
1000a4dc4:     	add	sp, sp, #0x3a0
1000a4dc8:     	ldp	x29, x30, [sp, #0x50]
1000a4dcc:     	ldp	x20, x19, [sp, #0x40]
1000a4dd0:     	ldp	x22, x21, [sp, #0x30]
1000a4dd4:     	ldp	x24, x23, [sp, #0x20]
1000a4dd8:     	ldp	x26, x25, [sp, #0x10]
1000a4ddc:     	ldp	x28, x27, [sp], #0x60
1000a4de0:     	ret
