#!/usr/bin/env python3
"""Execute the separately registered first-probe peer panel once, after root native review.
Scratch recipe only; no build, calibration, retry or production source changes.
"""
import collections, csv, hashlib, json, os, pathlib, subprocess, time
ROOT = pathlib.Path('/private/tmp/whitefoot-container-recovery-20261001')
D = pathlib.Path('/private/tmp/whitefoot-map-first-probe-peel-retry1')
HOME = pathlib.Path('/private/tmp/whitefoot-map-first-probe-peel-retry1')
OUT = HOME / 'timing'
assert os.environ.get('WHITEFOOT_CHECK_OWNER'), 'Use the repository host guard'
def sha(path): return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
checks = json.loads((D / 'check-statuses.json').read_text())
assert len(checks) == 30, 'Both broad and maintained checks must finish first'
for row in checks:
    is_fault = len(row['argv']) >= 2 and row['argv'][1] == 'negative'
    assert row['exit'] == (1 if is_fault else 0), row
assert (D / 'control-ledger.stdout').read_bytes() == (D / 'candidate-ledger.stdout').read_bytes()
assert json.loads((D / 'restoration.json').read_text())['restored']
images = json.loads((D / 'images.json').read_text())
for path, digest in images.items(): assert sha(path) == digest, path
for path, digest in json.loads((HOME / 'pins.json').read_text()).items(): assert sha(path) == digest, path
for path, digest in json.loads((HOME / 'timing-pins.json').read_text()).items(): assert sha(path) == digest, path
OUT.mkdir(exist_ok=False)  # Never overwrite or silently rerun this fixed panel.
metadata = dict(criterion_sha256=sha(HOME / 'performance-question.txt'), source_shape_preflight='partial_fail', arm_labels={'control':'frozen-source-mask','candidate':'first-probe-peel'}, script_sha256=sha(__file__),
                checks_sha256=sha(D / 'check-statuses.json'), images_before=images,
                work=4194304, samples=9, per_process_timeout_seconds=180,
                order=['control0', 'candidate0', 'candidate1', 'control1'], stages=[])
def save(): (OUT / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
save()
try:
    for arm, cohort in [('control', 0), ('candidate', 0), ('candidate', 1), ('control', 1)]:
        label = f'{arm}-cohort-{cohort}'
        argv = [str(D / (arm + '-timed')), 'measure', str(cohort), '4194304']
        start = time.monotonic()
        with (OUT / (label + '.csv')).open('w') as out, (OUT / (label + '.stderr')).open('w') as err:
            process = subprocess.Popen(argv, cwd=ROOT, stdout=out, stderr=err)
            print(json.dumps(dict(event='start', label=label, pid=process.pid, argv=argv)), flush=True)
            expired = False
            try:
                code = process.wait(timeout=180)
            except subprocess.TimeoutExpired:
                expired = True
                process.kill(); code = process.wait()
            except BaseException:
                process.terminate(); code = process.wait()
                metadata['stages'].append(dict(label=label, argv=argv, pid=process.pid,
                    exit=code, seconds=time.monotonic()-start, interrupted=True))
                save(); raise
        row = dict(label=label, argv=argv, pid=process.pid, exit=code,
                   seconds=time.monotonic()-start, timed_out=expired)
        metadata['stages'].append(row); save(); print(json.dumps(row), flush=True)
        assert not expired and code == 0, row
        rows = list(csv.DictReader((OUT / (label + '.csv')).open()))
        assert len(rows) == 288
        groups = collections.Counter((r['variant'], r['width'], r['slots'], r['operation']) for r in rows)
        assert len(groups) == 32 and set(groups.values()) == {9}
        assert all(int(r['cohort']) == cohort and int(r['operations']) == 4194304 for r in rows)
        assert (OUT / (label + '.stderr')).read_bytes() == b''
finally:
    metadata['images_after'] = {path: sha(path) for path in images}
    save()
assert metadata['images_after'] == images
print('Fixed four-process panel finished. All raw observations retained; no automatic selection.', flush=True)
