import csv, hashlib, json
from pathlib import Path
H=Path('/private/tmp/whitefoot-map-first-probe-peel-retry1'); T=H/'timing'
meta=json.loads((T/'metadata.json').read_text()); assert meta['images_before']==meta['images_after']
for p,h in meta['images_before'].items(): assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
arms={};sha={}
for a in ('control','candidate'):
 for c in (0,1):
  p=T/f'{a}-cohort-{c}.csv'; r=list(csv.DictReader(p.open())); assert len(r)==288
  arms[a,c]=r; sha[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
key=lambda r:(r['variant'],r['width'],r['slots'],r['operation'],r['sample'])
for c in (0,1):
 x={key(r):{k:v for k,v in r.items() if k!='elapsed_ns'} for r in arms['control',c]}
 y={key(r):{k:v for k,v in r.items() if k!='elapsed_ns'} for r in arms['candidate',c]}
 assert len(x)==len(y)==288 and x==y
 for a in ('control','candidate'):
  within={}
  for r in arms[a,c]:
   k=(r['width'],r['slots'],r['operation'],r['sample'])
   v=tuple(r[n] for n in ('seed','population','start_generation','rounds','operations','checksum','verify','cleanup'))
   if k in within: assert within[k]==v
   else: within[k]=v
  assert len(within)==72
V=('whitefoot-flat','whitefoot-chain','rust-hash-map','cpp-unordered-map')
def stats(rr):
 ns=sorted(int(r['elapsed_ns']) for r in rr); assert len(ns)==9
 ops=int(rr[0]['operations']); assert all(int(r['operations'])==ops for r in rr)
 return dict(min_ns=ns[0],median_ns=ns[4],max_ns=ns[-1],min_ns_per_op=ns[0]/ops,median_ns_per_op=ns[4]/ops,max_ns_per_op=ns[-1]/ops)
def relation(x,y):
 if x['max_ns']<y['min_ns']:return 'WIN'
 if x['min_ns']>y['max_ns']:return 'LOSS'
 return 'OVERLAP'
def drift(x,y):return max(x/y,y/x)-1
cells=[]; max_spread=(0,None);max_drift=(0,None);min_int=min(int(r['elapsed_ns']) for rr in arms.values() for r in rr)
for w in ('word8','wide256'):
 for sl in (64,4096):
  for op in ('replace','churn'):
   cell=dict(width=w,slots=sl,operation=op,cohorts=[])
   for c in (0,1):
    s={a:{v:stats([r for r in arms[a,c] if r['variant']==v and r['width']==w and int(r['slots'])==sl and r['operation']==op]) for v in V} for a in ('control','candidate')}
    x=s['control']['whitefoot-flat'];y=s['candidate']['whitefoot-flat']
    peers={v:s['candidate'][v] for v in V[1:]}
    slow=max(V[2:],key=lambda v:peers[v]['median_ns'])
    pd={v:drift(s['control'][v]['median_ns'],s['candidate'][v]['median_ns']) for v in V[1:]}
    for v,d in pd.items():
     if d>max_drift[0]:max_drift=(d,dict(variant=v,width=w,slots=sl,operation=op,cohort=c))
    cell['cohorts'].append(dict(cohort=c,control_wf=x,candidate_wf=y,peers=peers,slower_native_peer=slow,candidate_vs_each_native={v:relation(y,peers[v]) for v in V[2:]},control_vs_each_native={v:relation(x,peers[v]) for v in V[2:]},candidate_goal=relation(y,peers[slow])=='WIN',control_goal=relation(x,peers[slow])=='WIN',candidate_control_median_ratio=y['median_ns']/x['median_ns'],candidate_vs_control_range=relation(y,x),unchanged_peer_symmetric_drift=pd))
   r0,r1=[co['candidate_control_median_ratio'] for co in cell['cohorts']]
   sp=drift(r0,r1);cell['paired_cohort_ratio_spread']=sp
   if sp>max_spread[0]:max_spread=(sp,dict(width=w,slots=sl,operation=op,ratios=[r0,r1]))
   cell['candidate_both_cohorts_goal']=all(co['candidate_goal'] for co in cell['cohorts'])
   cell['control_both_cohorts_goal']=all(co['control_goal'] for co in cell['cohorts'])
   cells.append(cell)
sumry=dict(raw_rows=sum(len(rr) for rr in arms.values()),csv_sha256=sha,images_unchanged=True,non_time_fields_identical_across_arms=True,full_content_oracles_identical_across_variants=True,min_interval_ns=min_int,min_interval_pass=min_int>=1000000,max_paired_cohort_ratio_spread={'spread':max_spread[0],**max_spread[1]},max_unchanged_peer_symmetric_drift={'drift':max_drift[0],**max_drift[1]},native_source_shape_preflight='partial_fail',cells=cells)
sumry['instrument_pass']=sumry['min_interval_pass'] and max_spread[0]<=.1 and max_drift[0]<=.1
sumry['candidate_primary_cells_pass']=sum(x['candidate_both_cohorts_goal'] for x in cells)
sumry['control_primary_cells_pass']=sum(x['control_both_cohorts_goal'] for x in cells)
sumry['candidate_cohort_observations_pass']=sum(y['candidate_goal'] for x in cells for y in x['cohorts'])
sumry['campaign_qualified']=sumry['instrument_pass'] and sumry['candidate_primary_cells_pass']==8
(T/'reduction.json').write_text(json.dumps(sumry,indent=2)+'\n')
lines=['width slots op | cohort0 WF control→peel / slower peer / relation / ratio | cohort1 same | both']
for x in cells:
 pieces=[]
 for co in x['cohorts']:
  a=co['control_wf']['median_ns_per_op'];b=co['candidate_wf']['median_ns_per_op'];v=co['slower_native_peer'];p=co['peers'][v]['median_ns_per_op']
  pieces.append(f'{a:.3f}→{b:.3f} ns/op / {v} {p:.3f} / {co["candidate_vs_each_native"][v]} / {co["candidate_control_median_ratio"]:.3f}')
 lines.append(f'{x["width"]} {x["slots"]} {x["operation"]} | '+' | '.join(pieces)+f' | {x["candidate_both_cohorts_goal"]}')
lines.append(f'min {min_int/1e6:.3f}ms; max paired spread {max_spread[0]*100:.2f}%; max peer drift {max_drift[0]*100:.2f}%; target {sumry["candidate_primary_cells_pass"]}/8; instrument {sumry["instrument_pass"]}; campaign {sumry["campaign_qualified"]}')
(T/'reduction.txt').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines))
