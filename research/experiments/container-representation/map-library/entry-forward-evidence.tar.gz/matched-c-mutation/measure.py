from pathlib import Path
import json,csv,collections,hashlib,subprocess,time,os
D=Path(__file__).parent;R=Path('<repository-root>');T=D/'timing'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert os.environ.get('WHITEFOOT_CHECK_OWNER'),'guard required'
for p,h in json.loads((D/'timing-pins.json').read_text()).items():assert sha(p)==h,p
checks=json.loads((D/'statuses.json').read_text());assert len(checks)==50 and all(x['exit']==x['expected'] for x in checks)
images=json.loads((D/'images.json').read_text())
for p,h in images.items():assert sha(p)==h,p
T.mkdir(exist_ok=False)
meta=dict(question='five-way same-image C/WF attribution only',work=4194304,samples=10,seeds=list(range(101,111)),cohorts=[0,1],criterion_sha256=sha(D/'timing-criterion.txt'),runner_sha256=sha(__file__),images_before=images,stages=[])
def save():(T/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
save()
try:
 for c in [0,1]:
  args=[str(D/'map-timed'),'measure',str(c),'4194304'];start=time.monotonic()
  with (T/f'cohort-{c}.csv').open('w') as out,(T/f'cohort-{c}.stderr').open('w') as err:
   p=subprocess.Popen(args,cwd=R,stdout=out,stderr=err);print(json.dumps(dict(event='start',cohort=c,pid=p.pid,argv=args)),flush=True)
   expired=False
   try:code=p.wait(timeout=180)
   except subprocess.TimeoutExpired:expired=True;p.kill();code=p.wait()
   except BaseException:
    p.terminate();code=p.wait();meta['stages'].append(dict(cohort=c,argv=args,pid=p.pid,exit=code,seconds=time.monotonic()-start,interrupted=True));save();raise
  row=dict(cohort=c,argv=args,pid=p.pid,exit=code,seconds=time.monotonic()-start,timed_out=expired);meta['stages'].append(row);save();print(json.dumps(row),flush=True);assert code==0 and not expired
  rows=list(csv.DictReader((T/f'cohort-{c}.csv').open()));assert len(rows)==400
  g=collections.Counter((r['variant'],r['width'],r['slots'],r['operation']) for r in rows);assert len(g)==40 and set(g.values())=={10}
  assert all(int(r['cohort'])==c and int(r['operations'])==4194304 and int(r['seed'])==101+int(r['sample']) for r in rows)
  assert not (T/f'cohort-{c}.stderr').read_bytes()
finally:
 meta['images_after']={p:sha(p) for p in images};save()
assert images==meta['images_after'];print('Fixed800-row panel complete; no automatic selection.',flush=True)
