00000001000b0bf4 <_eco_c_map_mutation_word_batch>:
1000b0bf4:     	mov	x9, #0xe5b9             ; =58809
1000b0bf8:     	movk	x9, #0x1ce4, lsl #16
1000b0bfc:     	movk	x9, #0x476d, lsl #32
1000b0c00:     	movk	x9, #0xbf58, lsl #48
1000b0c04:     	mov	x8, #0x11eb             ; =4587
1000b0c08:     	movk	x8, #0x1331, lsl #16
1000b0c0c:     	movk	x8, #0x49bb, lsl #32
1000b0c10:     	movk	x8, #0x94d0, lsl #48
1000b0c14:     	ldr	x10, [x0, #0x38]
1000b0c18:     	cbz	x1, 0x1000b0f00 <_eco_c_map_mutation_word_batch+0x30c>
1000b0c1c:     	ldp	x5, x11, [x0, #0x40]
1000b0c20:     	cbz	x5, 0x1000b0f18 <_eco_c_map_mutation_word_batch+0x324>
1000b0c24:     	stp	x24, x23, [sp, #-0x30]!
1000b0c28:     	stp	x22, x21, [sp, #0x10]
1000b0c2c:     	stp	x20, x19, [sp, #0x20]
1000b0c30:     	mov	x12, #0x0               ; =0
1000b0c34:     	mov	w13, #0x1               ; =1
1000b0c38:     	mov	w14, #0x18              ; =24
1000b0c3c:     	adrp	x15, 0x1000d4000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x35c>
1000b0c40:     	ldr	d0, [x15, #0xb80]
1000b0c44:     	mov	w15, #0x83              ; =131
1000b0c48:     	mov	x16, #0x2               ; =2
1000b0c4c:     	mov	w17, #0x4309            ; =17161
1000b0c50:     	b	0x1000b0c64 <_eco_c_map_mutation_word_batch+0x70>
1000b0c54:     	str	x11, [x0, #0x48]
1000b0c58:     	add	x12, x12, #0x1
1000b0c5c:     	cmp	x12, x1
1000b0c60:     	b.eq	0x1000b0ef4 <_eco_c_map_mutation_word_batch+0x300>
1000b0c64:     	add	x11, x11, #0x1
1000b0c68:     	cbz	x5, 0x1000b0c54 <_eco_c_map_mutation_word_batch+0x60>
1000b0c6c:     	mov	x3, #0x0                ; =0
1000b0c70:     	ldr	x4, [x0, #0x38]
1000b0c74:     	madd	x4, x5, x11, x4
1000b0c78:     	b	0x1000b0c98 <_eco_c_map_mutation_word_batch+0xa4>
1000b0c7c:     	madd	x10, x10, x15, x16
1000b0c80:     	add	x10, x5, x10
1000b0c84:     	madd	x10, x10, x15, x6
1000b0c88:     	add	x3, x3, #0x1
1000b0c8c:     	ldr	x5, [x0, #0x40]
1000b0c90:     	cmp	x3, x5
1000b0c94:     	b.hs	0x1000b0c54 <_eco_c_map_mutation_word_batch+0x60>
1000b0c98:     	orr	x5, x13, x3, lsl #1
1000b0c9c:     	cbz	x2, 0x1000b0d90 <_eco_c_map_mutation_word_batch+0x19c>
1000b0ca0:     	ldr	x6, [x0, #0x18]
1000b0ca4:     	cbz	x6, 0x1000b0d8c <_eco_c_map_mutation_word_batch+0x198>
1000b0ca8:     	ldrb	w7, [x0, #0x30]
1000b0cac:     	tbz	w7, #0x0, 0x1000b0cc0 <_eco_c_map_mutation_word_batch+0xcc>
1000b0cb0:     	mov	x19, #0x0               ; =0
1000b0cb4:     	ldr	x7, [x0]
1000b0cb8:     	cbnz	x7, 0x1000b0ce4 <_eco_c_map_mutation_word_batch+0xf0>
1000b0cbc:     	b	0x1000b0d8c <_eco_c_map_mutation_word_batch+0x198>
1000b0cc0:     	ldr	x7, [x0, #0x28]
1000b0cc4:     	eor	x7, x7, x5
1000b0cc8:     	eor	x7, x7, x7, lsr #30
1000b0ccc:     	mul	x7, x7, x9
1000b0cd0:     	eor	x7, x7, x7, lsr #27
1000b0cd4:     	mul	x7, x7, x8
1000b0cd8:     	eor	x19, x7, x7, lsr #31
1000b0cdc:     	ldr	x7, [x0]
1000b0ce0:     	cbz	x7, 0x1000b0d8c <_eco_c_map_mutation_word_batch+0x198>
1000b0ce4:     	sub	x20, x7, #0x1
1000b0ce8:     	tst	x7, x20
1000b0cec:     	b.eq	0x1000b0cfc <_eco_c_map_mutation_word_batch+0x108>
1000b0cf0:     	udiv	x20, x19, x7
1000b0cf4:     	msub	x19, x20, x7, x19
1000b0cf8:     	b	0x1000b0d00 <_eco_c_map_mutation_word_batch+0x10c>
1000b0cfc:     	and	x19, x20, x19
1000b0d00:     	ldr	x20, [x0, #0x10]
1000b0d04:     	mov	x21, x7
1000b0d08:     	b	0x1000b0d20 <_eco_c_map_mutation_word_batch+0x12c>
1000b0d0c:     	add	x22, x19, #0x1
1000b0d10:     	cmp	x22, x7
1000b0d14:     	csinc	x19, xzr, x19, eq
1000b0d18:     	subs	x21, x21, #0x1
1000b0d1c:     	b.eq	0x1000b0d8c <_eco_c_map_mutation_word_batch+0x198>
1000b0d20:     	madd	x22, x19, x14, x20
1000b0d24:     	ldr	w23, [x22]
1000b0d28:     	cmp	w23, #0x1
1000b0d2c:     	b.eq	0x1000b0d0c <_eco_c_map_mutation_word_batch+0x118>
1000b0d30:     	cbz	w23, 0x1000b0d8c <_eco_c_map_mutation_word_batch+0x198>
1000b0d34:     	ldr	x23, [x22, #0x8]
1000b0d38:     	cmp	x23, x5
1000b0d3c:     	b.ne	0x1000b0d0c <_eco_c_map_mutation_word_batch+0x118>
1000b0d40:     	ldr	w20, [x22]
1000b0d44:     	ldp	x7, x19, [x22, #0x8]
1000b0d48:     	stp	xzr, xzr, [x22, #0x8]
1000b0d4c:     	str	x13, [x22]
1000b0d50:     	cmp	w20, #0x2
1000b0d54:     	b.ne	0x1000b0e4c <_eco_c_map_mutation_word_batch+0x258>
1000b0d58:     	sub	x6, x6, #0x1
1000b0d5c:     	str	x6, [x0, #0x18]
1000b0d60:     	ldr	x6, [x0, #0x20]
1000b0d64:     	cmn	x6, #0x1
1000b0d68:     	b.eq	0x1000b0d74 <_eco_c_map_mutation_word_batch+0x180>
1000b0d6c:     	add	x6, x6, #0x1
1000b0d70:     	str	x6, [x0, #0x20]
1000b0d74:     	madd	x10, x10, x17, x19
1000b0d78:     	madd	x10, x7, x15, x10
1000b0d7c:     	add	x10, x10, #0x83
1000b0d80:     	ldrb	w6, [x0, #0x30]
1000b0d84:     	tbnz	w6, #0x0, 0x1000b0d98 <_eco_c_map_mutation_word_batch+0x1a4>
1000b0d88:     	b	0x1000b0e58 <_eco_c_map_mutation_word_batch+0x264>
1000b0d8c:     	mul	x10, x10, x15
1000b0d90:     	ldrb	w6, [x0, #0x30]
1000b0d94:     	tbz	w6, #0x0, 0x1000b0e58 <_eco_c_map_mutation_word_batch+0x264>
1000b0d98:     	mov	x19, #0x0               ; =0
1000b0d9c:     	add	x6, x4, x3
1000b0da0:     	ldr	x7, [x0]
1000b0da4:     	cbz	x7, 0x1000b0e80 <_eco_c_map_mutation_word_batch+0x28c>
1000b0da8:     	sub	x20, x7, #0x1
1000b0dac:     	tst	x7, x20
1000b0db0:     	b.eq	0x1000b0dc0 <_eco_c_map_mutation_word_batch+0x1cc>
1000b0db4:     	udiv	x20, x19, x7
1000b0db8:     	msub	x20, x20, x7, x19
1000b0dbc:     	b	0x1000b0dc4 <_eco_c_map_mutation_word_batch+0x1d0>
1000b0dc0:     	and	x20, x20, x19
1000b0dc4:     	ldr	x21, [x0, #0x10]
1000b0dc8:     	mov	x22, x7
1000b0dcc:     	mov	x19, x7
1000b0dd0:     	b	0x1000b0df0 <_eco_c_map_mutation_word_batch+0x1fc>
1000b0dd4:     	cmp	x19, x7
1000b0dd8:     	csel	x19, x20, x19, eq
1000b0ddc:     	add	x23, x20, #0x1
1000b0de0:     	cmp	x23, x7
1000b0de4:     	csinc	x20, xzr, x20, eq
1000b0de8:     	subs	x22, x22, #0x1
1000b0dec:     	b.eq	0x1000b0e84 <_eco_c_map_mutation_word_batch+0x290>
1000b0df0:     	madd	x23, x20, x14, x21
1000b0df4:     	ldr	w24, [x23]
1000b0df8:     	cmp	w24, #0x1
1000b0dfc:     	b.eq	0x1000b0dd4 <_eco_c_map_mutation_word_batch+0x1e0>
1000b0e00:     	cbz	w24, 0x1000b0e40 <_eco_c_map_mutation_word_batch+0x24c>
1000b0e04:     	ldr	x24, [x23, #0x8]
1000b0e08:     	cmp	x24, x5
1000b0e0c:     	b.ne	0x1000b0ddc <_eco_c_map_mutation_word_batch+0x1e8>
1000b0e10:     	ldr	d1, [x23]
1000b0e14:     	ldp	x7, x19, [x23, #0x8]
1000b0e18:     	str	d0, [x23]
1000b0e1c:     	stp	x5, x6, [x23, #0x8]
1000b0e20:     	fmov	w5, s1
1000b0e24:     	mul	x10, x10, x15
1000b0e28:     	cmp	w5, #0x2
1000b0e2c:     	cinc	x10, x10, eq
1000b0e30:     	b.ne	0x1000b0c88 <_eco_c_map_mutation_word_batch+0x94>
1000b0e34:     	mov	x6, x19
1000b0e38:     	mov	x5, x7
1000b0e3c:     	b	0x1000b0c80 <_eco_c_map_mutation_word_batch+0x8c>
1000b0e40:     	cmp	x19, x7
1000b0e44:     	csel	x19, x20, x19, eq
1000b0e48:     	b	0x1000b0e84 <_eco_c_map_mutation_word_batch+0x290>
1000b0e4c:     	mul	x10, x10, x15
1000b0e50:     	ldrb	w6, [x0, #0x30]
1000b0e54:     	tbnz	w6, #0x0, 0x1000b0d98 <_eco_c_map_mutation_word_batch+0x1a4>
1000b0e58:     	ldr	x6, [x0, #0x28]
1000b0e5c:     	eor	x6, x6, x5
1000b0e60:     	eor	x6, x6, x6, lsr #30
1000b0e64:     	mul	x6, x6, x9
1000b0e68:     	eor	x6, x6, x6, lsr #27
1000b0e6c:     	mul	x6, x6, x8
1000b0e70:     	eor	x19, x6, x6, lsr #31
1000b0e74:     	add	x6, x4, x3
1000b0e78:     	ldr	x7, [x0]
1000b0e7c:     	cbnz	x7, 0x1000b0da8 <_eco_c_map_mutation_word_batch+0x1b4>
1000b0e80:     	mov	x19, #0x0               ; =0
1000b0e84:     	cmp	x19, x7
1000b0e88:     	b.hs	0x1000b0c7c <_eco_c_map_mutation_word_batch+0x88>
1000b0e8c:     	ldr	x7, [x0, #0x18]
1000b0e90:     	lsr	x20, x7, #13
1000b0e94:     	cbnz	x20, 0x1000b0c7c <_eco_c_map_mutation_word_batch+0x88>
1000b0e98:     	add	x7, x7, #0x1
1000b0e9c:     	str	x7, [x0, #0x18]
1000b0ea0:     	ldr	x7, [x0, #0x10]
1000b0ea4:     	madd	x7, x19, x14, x7
1000b0ea8:     	ldr	w19, [x7]
1000b0eac:     	cmp	w19, #0x1
1000b0eb0:     	b.ne	0x1000b0ec4 <_eco_c_map_mutation_word_batch+0x2d0>
1000b0eb4:     	ldr	x19, [x0, #0x20]
1000b0eb8:     	cbz	x19, 0x1000b0ec4 <_eco_c_map_mutation_word_batch+0x2d0>
1000b0ebc:     	sub	x19, x19, #0x1
1000b0ec0:     	str	x19, [x0, #0x20]
1000b0ec4:     	ldr	d1, [x7]
1000b0ec8:     	ldp	x19, x20, [x7, #0x8]
1000b0ecc:     	str	d0, [x7]
1000b0ed0:     	stp	x5, x6, [x7, #0x8]
1000b0ed4:     	fmov	w5, s1
1000b0ed8:     	mul	x10, x10, x15
1000b0edc:     	cmp	w5, #0x2
1000b0ee0:     	cinc	x10, x10, eq
1000b0ee4:     	b.ne	0x1000b0c88 <_eco_c_map_mutation_word_batch+0x94>
1000b0ee8:     	mov	x6, x20
1000b0eec:     	mov	x5, x19
1000b0ef0:     	b	0x1000b0c80 <_eco_c_map_mutation_word_batch+0x8c>
1000b0ef4:     	ldp	x20, x19, [sp, #0x20]
1000b0ef8:     	ldp	x22, x21, [sp, #0x10]
1000b0efc:     	ldp	x24, x23, [sp], #0x30
1000b0f00:     	eor	x10, x10, x10, lsr #30
1000b0f04:     	mul	x9, x10, x9
1000b0f08:     	eor	x9, x9, x9, lsr #27
1000b0f0c:     	mul	x8, x9, x8
1000b0f10:     	eor	x0, x8, x8, lsr #31
1000b0f14:     	ret
1000b0f18:     	add	x11, x11, x1
1000b0f1c:     	str	x11, [x0, #0x48]
1000b0f20:     	eor	x10, x10, x10, lsr #30
1000b0f24:     	mul	x9, x10, x9
1000b0f28:     	eor	x9, x9, x9, lsr #27
1000b0f2c:     	mul	x8, x9, x8
1000b0f30:     	eor	x0, x8, x8, lsr #31
1000b0f34:     	ret

