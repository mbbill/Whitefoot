00000001000a3d20 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd>:
1000a3d20:     	mov	x9, #0xe5b9             ; =58809
1000a3d24:     	movk	x9, #0x1ce4, lsl #16
1000a3d28:     	movk	x9, #0x476d, lsl #32
1000a3d2c:     	movk	x9, #0xbf58, lsl #48
1000a3d30:     	mov	x8, #0x11eb             ; =4587
1000a3d34:     	movk	x8, #0x1331, lsl #16
1000a3d38:     	movk	x8, #0x49bb, lsl #32
1000a3d3c:     	movk	x8, #0x94d0, lsl #48
1000a3d40:     	ldr	x10, [x0, #0x38]
1000a3d44:     	cbz	x1, 0x1000a403c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x31c>
1000a3d48:     	ldp	x12, x11, [x0, #0x40]
1000a3d4c:     	cbz	x12, 0x1000a4034 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x314>
1000a3d50:     	sub	sp, sp, #0x70
1000a3d54:     	stp	x28, x27, [sp, #0x10]
1000a3d58:     	stp	x26, x25, [sp, #0x20]
1000a3d5c:     	stp	x24, x23, [sp, #0x30]
1000a3d60:     	stp	x22, x21, [sp, #0x40]
1000a3d64:     	stp	x20, x19, [sp, #0x50]
1000a3d68:     	stp	x29, x30, [sp, #0x60]
1000a3d6c:     	mov	x13, #0x0               ; =0
1000a3d70:     	ldp	x19, x14, [x0, #0x20]
1000a3d74:     	ldrb	w15, [x0, #0x30]
1000a3d78:     	mov	w16, #0x1               ; =1
1000a3d7c:     	mov	w17, #0x18              ; =24
1000a3d80:     	mov	w3, #0x2                ; =2
1000a3d84:     	mov	w4, #0x83               ; =131
1000a3d88:     	mov	x6, x10
1000a3d8c:     	ldr	x7, [x0, #0x18]
1000a3d90:     	b	0x1000a3da4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x84>
1000a3d94:     	str	x11, [x0, #0x48]
1000a3d98:     	add	x13, x13, #0x1
1000a3d9c:     	cmp	x13, x1
1000a3da0:     	b.eq	0x1000a4000 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2e0>
1000a3da4:     	mov	x20, #0x0               ; =0
1000a3da8:     	add	x11, x11, #0x1
1000a3dac:     	madd	x21, x11, x12, x10
1000a3db0:     	b	0x1000a3dd8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xb8>
1000a3db4:     	strb	w16, [sp, #0xc]
1000a3db8:     	tst	w16, #0x1
1000a3dbc:     	cinc	x24, x16, ne
1000a3dc0:     	madd	x5, x6, x4, x22
1000a3dc4:     	add	x5, x5, x24
1000a3dc8:     	madd	x6, x5, x4, x23
1000a3dcc:     	add	x20, x20, #0x1
1000a3dd0:     	cmp	x20, x12
1000a3dd4:     	b.eq	0x1000a3d94 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x74>
1000a3dd8:     	orr	x22, x16, x20, lsl #1
1000a3ddc:     	cbz	x2, 0x1000a3ea8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x188>
1000a3de0:     	cbz	x7, 0x1000a3ed4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b4>
1000a3de4:     	tbz	w15, #0x0, 0x1000a3df8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xd8>
1000a3de8:     	mov	x24, #0x0               ; =0
1000a3dec:     	ldr	x23, [x0]
1000a3df0:     	cbnz	x23, 0x1000a3e18 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xf8>
1000a3df4:     	b	0x1000a3ed4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b4>
1000a3df8:     	eor	x5, x14, x22
1000a3dfc:     	eor	x5, x5, x5, lsr #30
1000a3e00:     	mul	x5, x5, x9
1000a3e04:     	eor	x5, x5, x5, lsr #27
1000a3e08:     	mul	x5, x5, x8
1000a3e0c:     	eor	x24, x5, x5, lsr #31
1000a3e10:     	ldr	x23, [x0]
1000a3e14:     	cbz	x23, 0x1000a3ed4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b4>
1000a3e18:     	sub	x5, x23, #0x1
1000a3e1c:     	tst	x23, x5
1000a3e20:     	b.eq	0x1000a3e30 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x110>
1000a3e24:     	udiv	x5, x24, x23
1000a3e28:     	msub	x24, x5, x23, x24
1000a3e2c:     	b	0x1000a3e34 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x114>
1000a3e30:     	and	x24, x5, x24
1000a3e34:     	ldr	x25, [x0, #0x10]
1000a3e38:     	mov	x26, x23
1000a3e3c:     	b	0x1000a3e54 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x134>
1000a3e40:     	add	x5, x24, #0x1
1000a3e44:     	cmp	x5, x23
1000a3e48:     	csinc	x24, xzr, x24, hs
1000a3e4c:     	subs	x26, x26, #0x1
1000a3e50:     	b.eq	0x1000a3ed4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b4>
1000a3e54:     	madd	x27, x24, x17, x25
1000a3e58:     	ldr	w28, [x27]
1000a3e5c:     	cmp	w28, #0x1
1000a3e60:     	b.eq	0x1000a3e40 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x120>
1000a3e64:     	cmp	w28, #0x2
1000a3e68:     	b.ne	0x1000a3ed4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1b4>
1000a3e6c:     	ldr	x5, [x27, #0x8]
1000a3e70:     	cmp	x5, x22
1000a3e74:     	b.ne	0x1000a3e40 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x120>
1000a3e78:     	ldr	x5, [x27, #0x10]
1000a3e7c:     	str	w16, [x27]
1000a3e80:     	sub	x7, x7, #0x1
1000a3e84:     	stp	xzr, xzr, [x27, #0x8]
1000a3e88:     	adds	x19, x19, #0x1
1000a3e8c:     	csinv	x19, x19, xzr, lo
1000a3e90:     	stp	x7, x19, [x0, #0x18]
1000a3e94:     	mul	x23, x22, x4
1000a3e98:     	mov	w24, #0x4309            ; =17161
1000a3e9c:     	madd	x6, x6, x24, x23
1000a3ea0:     	add	x5, x6, x5
1000a3ea4:     	add	x6, x5, #0x83
1000a3ea8:     	tbz	w15, #0x0, 0x1000a3edc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1bc>
1000a3eac:     	mov	x25, #0x0               ; =0
1000a3eb0:     	add	x23, x21, x20
1000a3eb4:     	ldr	x24, [x0]
1000a3eb8:     	cbz	x24, 0x1000a3f00 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1e0>
1000a3ebc:     	sub	x5, x24, #0x1
1000a3ec0:     	tst	x24, x5
1000a3ec4:     	b.eq	0x1000a3f08 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1e8>
1000a3ec8:     	udiv	x5, x25, x24
1000a3ecc:     	msub	x26, x5, x24, x25
1000a3ed0:     	b	0x1000a3f0c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1ec>
1000a3ed4:     	mul	x6, x6, x4
1000a3ed8:     	tbnz	w15, #0x0, 0x1000a3eac <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x18c>
1000a3edc:     	eor	x5, x14, x22
1000a3ee0:     	eor	x5, x5, x5, lsr #30
1000a3ee4:     	mul	x5, x5, x9
1000a3ee8:     	eor	x5, x5, x5, lsr #27
1000a3eec:     	mul	x5, x5, x8
1000a3ef0:     	eor	x25, x5, x5, lsr #31
1000a3ef4:     	add	x23, x21, x20
1000a3ef8:     	ldr	x24, [x0]
1000a3efc:     	cbnz	x24, 0x1000a3ebc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x19c>
1000a3f00:     	mov	x25, #0x0               ; =0
1000a3f04:     	b	0x1000a3f80 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x260>
1000a3f08:     	and	x26, x5, x25
1000a3f0c:     	ldr	x27, [x0, #0x10]
1000a3f10:     	mov	x28, x24
1000a3f14:     	mov	x25, x24
1000a3f18:     	b	0x1000a3f38 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x218>
1000a3f1c:     	cmp	x25, x24
1000a3f20:     	csel	x25, x26, x25, eq
1000a3f24:     	add	x5, x26, #0x1
1000a3f28:     	cmp	x5, x24
1000a3f2c:     	csinc	x26, xzr, x26, hs
1000a3f30:     	subs	x28, x28, #0x1
1000a3f34:     	b.eq	0x1000a3f80 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x260>
1000a3f38:     	madd	x30, x26, x17, x27
1000a3f3c:     	ldr	w5, [x30]
1000a3f40:     	cmp	w5, #0x1
1000a3f44:     	b.eq	0x1000a3f1c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
1000a3f48:     	cmp	w5, #0x2
1000a3f4c:     	b.ne	0x1000a3f78 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x258>
1000a3f50:     	ldr	x5, [x30, #0x8]
1000a3f54:     	cmp	x5, x22
1000a3f58:     	b.ne	0x1000a3f24 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x204>
1000a3f5c:     	ldr	x5, [x30, #0x10]
1000a3f60:     	str	w3, [x30]
1000a3f64:     	str	x23, [x30, #0x10]
1000a3f68:     	strb	wzr, [sp, #0xc]
1000a3f6c:     	mov	w24, #0x1               ; =1
1000a3f70:     	mov	x23, x5
1000a3f74:     	b	0x1000a3dc0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xa0>
1000a3f78:     	cmp	x25, x24
1000a3f7c:     	csel	x25, x26, x25, eq
1000a3f80:     	cmp	x25, x24
1000a3f84:     	b.hs	0x1000a3db4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
1000a3f88:     	cmp	x7, #0x2, lsl #12       ; =0x2000
1000a3f8c:     	b.hs	0x1000a3db4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
1000a3f90:     	add	x7, x7, #0x1
1000a3f94:     	str	x7, [x0, #0x18]
1000a3f98:     	ldr	x5, [x0, #0x10]
1000a3f9c:     	madd	x24, x25, x17, x5
1000a3fa0:     	ldr	w27, [x24]
1000a3fa4:     	cmp	w27, #0x1
1000a3fa8:     	b.ne	0x1000a3fc4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2a4>
1000a3fac:     	subs	x5, x19, #0x1
1000a3fb0:     	csel	x19, xzr, x5, lo
1000a3fb4:     	str	x19, [x0, #0x20]
1000a3fb8:     	str	w3, [x24]
1000a3fbc:     	stp	x22, x23, [x24, #0x8]
1000a3fc0:     	b	0x1000a3fe8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2c8>
1000a3fc4:     	ldp	x25, x26, [x24, #0x8]
1000a3fc8:     	str	w3, [x24]
1000a3fcc:     	stp	x22, x23, [x24, #0x8]
1000a3fd0:     	cbz	w27, 0x1000a3fe8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2c8>
1000a3fd4:     	strb	wzr, [sp, #0xc]
1000a3fd8:     	mov	w24, #0x1               ; =1
1000a3fdc:     	mov	x23, x26
1000a3fe0:     	mov	x22, x25
1000a3fe4:     	b	0x1000a3dc0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xa0>
1000a3fe8:     	strb	wzr, [sp, #0xc]
1000a3fec:     	mul	x6, x6, x4
1000a3ff0:     	add	x20, x20, #0x1
1000a3ff4:     	cmp	x20, x12
1000a3ff8:     	b.ne	0x1000a3dd8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xb8>
1000a3ffc:     	b	0x1000a3d94 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x74>
1000a4000:     	ldp	x29, x30, [sp, #0x60]
1000a4004:     	ldp	x20, x19, [sp, #0x50]
1000a4008:     	ldp	x22, x21, [sp, #0x40]
1000a400c:     	ldp	x24, x23, [sp, #0x30]
1000a4010:     	ldp	x26, x25, [sp, #0x20]
1000a4014:     	ldp	x28, x27, [sp, #0x10]
1000a4018:     	add	sp, sp, #0x70
1000a401c:     	eor	x10, x6, x6, lsr #30
1000a4020:     	mul	x9, x10, x9
1000a4024:     	eor	x9, x9, x9, lsr #27
1000a4028:     	mul	x8, x9, x8
1000a402c:     	eor	x0, x8, x8, lsr #31
1000a4030:     	ret
1000a4034:     	add	x11, x11, x1
1000a4038:     	str	x11, [x0, #0x48]
1000a403c:     	eor	x10, x10, x10, lsr #30
1000a4040:     	mul	x9, x10, x9
1000a4044:     	eor	x9, x9, x9, lsr #27
1000a4048:     	mul	x8, x9, x8
1000a404c:     	eor	x0, x8, x8, lsr #31
1000a4050:     	ret

