from pathlib import Path
import json,hashlib,subprocess,os,time,csv,sys
R=Path('<repository-root>');D=Path(__file__).parent;S=Path('<source-mask-scratch>');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
mode=sys.argv[1];assert mode in ['prepare','build-check']
old=json.loads((S/'build-statuses.json').read_text());commands={}
for kind in ['timed','account']:
 link=next(x['argv'] for x in old if x['label']==f'candidate-{kind}-link').copy();link[2]=str(D/f'driver-{kind}.o');link[-1]=str(D/f'map-{kind}');link.insert(link.index('-liconv'),str(D/f'c-{kind}.o'));commands[kind]=link
inputs={str(p):sha(p) for p in [D/'criterion.txt',D/'map-mutation.c',D/'driver.c',D/'run.py',R/'research/experiments/container-representation/map-library/map-costs.c']}
for link in commands.values():
 for arg in link:
  if arg.endswith(('.o','.a')) and not arg.startswith(str(D)):
   p=Path(arg) if Path(arg).is_absolute() else R/arg;inputs[str(p)]=sha(p)
if mode=='prepare':
 (D/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n');(D/'link-commands.json').write_text(json.dumps(commands,indent=2)+'\n');print('Pinned',len(inputs),'inputs');raise SystemExit
assert os.environ.get('WHITEFOOT_CHECK_OWNER');assert inputs==json.loads((D/'inputs.json').read_text())
records=[]
def run(label,args,expected=0,message=None):
 start=time.monotonic()
 with (D/f'{label}.stdout').open('wb') as out,(D/f'{label}.stderr').open('wb') as err:p=subprocess.run(args,cwd=R,stdout=out,stderr=err)
 row=dict(label=label,argv=list(map(str,args)),exit=p.returncode,expected=expected,seconds=time.monotonic()-start);records.append(row);(D/'statuses.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True);assert p.returncode==expected,row
 if message:assert (D/f'{label}.stderr').read_text().strip()=='mutation: '+message
for kind in ['timed','account']:
 flags=['-DACCOUNT_ONLY'] if kind=='account' else []
 for stem,file in [('driver','driver.c'),('c','map-mutation.c')]:run(f'{stem}-{kind}-compile',['/usr/bin/clang','-std=c11','-O3','-Wall','-Wextra','-Werror','-DECOSYSTEM',*flags,'-c',str(D/file),'-o',str(D/f'{stem}-{kind}.o')])
 run(kind+'-link',commands[kind])
 run(kind+'-check',[str(D/f'map-{kind}'),'check'])
 assert (D/f'{kind}-check.stdout').read_text()=='mutation: 120 independent owner/three-successive-batches/verify/cleanup cases passed\n'
 run(kind+'-policy',[str(D/f'map-{kind}'),'c-policy'])
 faults={'wrong-batch-checksum':'negative wrong batch checksum','stale-generation':'negative stale generation','corrupt-last-word':'negative corrupt last word full-content','cleanup':'negative cleanup checksum'}
 if kind=='account':faults.update({'ledger-leak':'negative ledger leak','filled-allocation':'negative filled allocation'})
 for peer in ['wf','c']:
  for width in ['word','record']:
   for fault,message in faults.items():
    if width=='word' and fault=='corrupt-last-word':continue
    run(f'{kind}-{peer}-{width}-{fault}',[str(D/f'map-{kind}'),'negative',fault,peer,width],1,message)
run('bad-negative-peer',[str(D/'map-timed'),'negative','cleanup','typo','word'],1,'negative peer')
run('bad-negative-width',[str(D/'map-timed'),'negative','cleanup','c','typo'],1,'negative width')
run('ledger',[str(D/'map-account'),'account'])
rows=list(csv.DictReader((D/'ledger.stdout').open()));oldrows=list(csv.DictReader((S/'candidate-ledger.stdout').open()));assert len(rows)==40 and len(oldrows)==32
key=lambda r:tuple(r[k] for k in ['variant','width','slots','operation'])
assert {key(r):r for r in rows if r['variant']!='c-matched-flat'}=={key(r):r for r in oldrows}
for r in rows:
 if r['variant']=='c-matched-flat':
  expected=int(r['slots'])*(272 if r['width']=='wide256' else 24)
  assert int(r['filled_requests'])==1 and int(r['filled_bytes'])==expected and int(r['filled_live'])==expected
  assert int(r['final_releases'])==1 and int(r['final_live'])==0 and int(r['batch_requests'])==int(r['batch_releases'])==0
run('native',['<LLVM_OBJDUMP>','--disassemble','--no-show-raw-insn',str(D/'map-timed')])
assert all(sha(p)==h for p,h in inputs.items())
(D/'images.json').write_text(json.dumps({str(D/f'map-{k}'):sha(D/f'map-{k}') for k in ['timed','account']},indent=2)+'\n')
(D/'checks-summary.json').write_text(json.dumps(dict(stages=len(records),all_expected=True,positive_cases_per_image=120,original_32_ledger_rows_equal=True,c_rows=8,c_exact_geometry_and_allocations=True),indent=2)+'\n')
