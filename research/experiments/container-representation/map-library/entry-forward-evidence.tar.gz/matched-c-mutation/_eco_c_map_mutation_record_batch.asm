00000001000b1990 <_eco_c_map_mutation_record_batch>:
1000b1990:     	sub	sp, sp, #0x140
1000b1994:     	stp	x28, x27, [sp, #0xe0]
1000b1998:     	stp	x26, x25, [sp, #0xf0]
1000b199c:     	stp	x24, x23, [sp, #0x100]
1000b19a0:     	stp	x22, x21, [sp, #0x110]
1000b19a4:     	stp	x20, x19, [sp, #0x120]
1000b19a8:     	stp	x29, x30, [sp, #0x130]
1000b19ac:     	str	x2, [sp, #0x50]
1000b19b0:     	ldr	x17, [x0, #0x38]
1000b19b4:     	str	x1, [sp, #0x8]
1000b19b8:     	cbz	x1, 0x1000b2480 <_eco_c_map_mutation_record_batch+0xaf0>
1000b19bc:     	ldp	x8, x10, [x0, #0x40]
1000b19c0:     	cbz	x8, 0x1000b2474 <_eco_c_map_mutation_record_batch+0xae4>
1000b19c4:     	mov	x11, #0x0               ; =0
1000b19c8:     	mov	w30, #0x110             ; =272
1000b19cc:     	adrp	x9, 0x1000d4000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x35c>
1000b19d0:     	ldr	d0, [x9, #0xb80]
1000b19d4:     	mov	w15, #0x83              ; =131
1000b19d8:     	movi.2d	v1, #0000000000000000
1000b19dc:     	str	x0, [sp, #0x60]
1000b19e0:     	b	0x1000b19fc <_eco_c_map_mutation_record_batch+0x6c>
1000b19e4:     	ldp	x11, x10, [sp, #0x10]
1000b19e8:     	str	x10, [x0, #0x48]
1000b19ec:     	add	x11, x11, #0x1
1000b19f0:     	ldr	x9, [sp, #0x8]
1000b19f4:     	cmp	x11, x9
1000b19f8:     	b.eq	0x1000b2480 <_eco_c_map_mutation_record_batch+0xaf0>
1000b19fc:     	add	x10, x10, #0x1
1000b1a00:     	cbz	x8, 0x1000b19e8 <_eco_c_map_mutation_record_batch+0x58>
1000b1a04:     	stp	x11, x10, [sp, #0x10]
1000b1a08:     	mov	x14, #0x0               ; =0
1000b1a0c:     	ldr	x9, [x0, #0x38]
1000b1a10:     	madd	x8, x8, x10, x9
1000b1a14:     	str	x8, [sp, #0x58]
1000b1a18:     	b	0x1000b1b18 <_eco_c_map_mutation_record_batch+0x188>
1000b1a1c:     	ldr	x17, [sp, #0x88]
1000b1a20:     	mov	x11, #0x2               ; =2
1000b1a24:     	madd	x17, x17, x15, x11
1000b1a28:     	mov	x1, x8
1000b1a2c:     	mov	x8, x9
1000b1a30:     	mov	x9, x16
1000b1a34:     	mov	x16, x12
1000b1a38:     	mov	x12, x13
1000b1a3c:     	mov	x13, x4
1000b1a40:     	mov	x4, x2
1000b1a44:     	mov	x2, x10
1000b1a48:     	mov	x10, x6
1000b1a4c:     	mov	x6, x19
1000b1a50:     	mov	x19, x20
1000b1a54:     	mov	x20, x21
1000b1a58:     	mov	x21, x22
1000b1a5c:     	mov	x22, x24
1000b1a60:     	ldp	x28, x24, [sp, #0x78]
1000b1a64:     	ldr	x27, [sp, #0x70]
1000b1a68:     	madd	x11, x5, x15, x7
1000b1a6c:     	madd	x11, x11, x15, x1
1000b1a70:     	madd	x11, x11, x15, x9
1000b1a74:     	madd	x11, x11, x15, x8
1000b1a78:     	madd	x11, x11, x15, x12
1000b1a7c:     	madd	x11, x11, x15, x16
1000b1a80:     	madd	x11, x11, x15, x4
1000b1a84:     	madd	x11, x11, x15, x13
1000b1a88:     	madd	x11, x11, x15, x10
1000b1a8c:     	madd	x11, x11, x15, x2
1000b1a90:     	madd	x11, x11, x15, x19
1000b1a94:     	madd	x11, x11, x15, x6
1000b1a98:     	madd	x11, x11, x15, x21
1000b1a9c:     	madd	x11, x11, x15, x20
1000b1aa0:     	madd	x11, x11, x15, x22
1000b1aa4:     	madd	x11, x11, x15, x23
1000b1aa8:     	madd	x8, x11, x15, x14
1000b1aac:     	madd	x8, x8, x15, x25
1000b1ab0:     	madd	x8, x8, x15, x28
1000b1ab4:     	madd	x8, x8, x15, x24
1000b1ab8:     	madd	x8, x8, x15, x27
1000b1abc:     	madd	x8, x8, x15, x3
1000b1ac0:     	ldp	x10, x9, [sp, #0xd0]
1000b1ac4:     	madd	x8, x8, x15, x10
1000b1ac8:     	madd	x8, x8, x15, x9
1000b1acc:     	ldp	x10, x9, [sp, #0xc0]
1000b1ad0:     	madd	x8, x8, x15, x10
1000b1ad4:     	madd	x8, x8, x15, x9
1000b1ad8:     	ldp	x10, x9, [sp, #0xb0]
1000b1adc:     	madd	x8, x8, x15, x10
1000b1ae0:     	madd	x8, x8, x15, x9
1000b1ae4:     	ldp	x10, x9, [sp, #0xa0]
1000b1ae8:     	madd	x8, x8, x15, x10
1000b1aec:     	madd	x8, x8, x15, x9
1000b1af0:     	ldr	x9, [sp, #0x98]
1000b1af4:     	add	x9, x9, x17
1000b1af8:     	madd	x8, x8, x15, x9
1000b1afc:     	ldr	x9, [sp, #0x90]
1000b1b00:     	madd	x17, x8, x15, x9
1000b1b04:     	ldr	x14, [sp, #0x68]
1000b1b08:     	add	x14, x14, #0x1
1000b1b0c:     	ldr	x8, [x0, #0x40]
1000b1b10:     	cmp	x14, x8
1000b1b14:     	b.hs	0x1000b19e4 <_eco_c_map_mutation_record_batch+0x54>
1000b1b18:     	mov	w8, #0x1                ; =1
1000b1b1c:     	orr	x3, x8, x14, lsl #1
1000b1b20:     	ldr	x8, [sp, #0x50]
1000b1b24:     	cbz	x8, 0x1000b1d9c <_eco_c_map_mutation_record_batch+0x40c>
1000b1b28:     	ldr	x8, [x0, #0x18]
1000b1b2c:     	cbz	x8, 0x1000b1d98 <_eco_c_map_mutation_record_batch+0x408>
1000b1b30:     	ldrb	w9, [x0, #0x30]
1000b1b34:     	tbz	w9, #0x0, 0x1000b1b48 <_eco_c_map_mutation_record_batch+0x1b8>
1000b1b38:     	mov	x9, #0x0                ; =0
1000b1b3c:     	ldr	x10, [x0]
1000b1b40:     	cbnz	x10, 0x1000b1b8c <_eco_c_map_mutation_record_batch+0x1fc>
1000b1b44:     	b	0x1000b1d98 <_eco_c_map_mutation_record_batch+0x408>
1000b1b48:     	ldr	x9, [x0, #0x28]
1000b1b4c:     	eor	x9, x9, x3
1000b1b50:     	eor	x9, x9, x9, lsr #30
1000b1b54:     	mov	x10, #0xe5b9            ; =58809
1000b1b58:     	movk	x10, #0x1ce4, lsl #16
1000b1b5c:     	movk	x10, #0x476d, lsl #32
1000b1b60:     	movk	x10, #0xbf58, lsl #48
1000b1b64:     	mul	x9, x9, x10
1000b1b68:     	eor	x9, x9, x9, lsr #27
1000b1b6c:     	mov	x10, #0x11eb            ; =4587
1000b1b70:     	movk	x10, #0x1331, lsl #16
1000b1b74:     	movk	x10, #0x49bb, lsl #32
1000b1b78:     	movk	x10, #0x94d0, lsl #48
1000b1b7c:     	mul	x9, x9, x10
1000b1b80:     	eor	x9, x9, x9, lsr #31
1000b1b84:     	ldr	x10, [x0]
1000b1b88:     	cbz	x10, 0x1000b1d98 <_eco_c_map_mutation_record_batch+0x408>
1000b1b8c:     	sub	x11, x10, #0x1
1000b1b90:     	tst	x10, x11
1000b1b94:     	b.eq	0x1000b1ba4 <_eco_c_map_mutation_record_batch+0x214>
1000b1b98:     	udiv	x11, x9, x10
1000b1b9c:     	msub	x11, x11, x10, x9
1000b1ba0:     	b	0x1000b1ba8 <_eco_c_map_mutation_record_batch+0x218>
1000b1ba4:     	and	x11, x11, x9
1000b1ba8:     	ldr	x12, [x0, #0x10]
1000b1bac:     	mov	x13, x10
1000b1bb0:     	b	0x1000b1bc8 <_eco_c_map_mutation_record_batch+0x238>
1000b1bb4:     	add	x9, x11, #0x1
1000b1bb8:     	cmp	x9, x10
1000b1bbc:     	csinc	x11, xzr, x11, eq
1000b1bc0:     	subs	x13, x13, #0x1
1000b1bc4:     	b.eq	0x1000b1d98 <_eco_c_map_mutation_record_batch+0x408>
1000b1bc8:     	madd	x9, x11, x30, x12
1000b1bcc:     	ldr	w16, [x9]
1000b1bd0:     	cmp	w16, #0x1
1000b1bd4:     	b.eq	0x1000b1bb4 <_eco_c_map_mutation_record_batch+0x224>
1000b1bd8:     	cbz	w16, 0x1000b1d98 <_eco_c_map_mutation_record_batch+0x408>
1000b1bdc:     	ldr	x16, [x9, #0x8]
1000b1be0:     	cmp	x16, x3
1000b1be4:     	b.ne	0x1000b1bb4 <_eco_c_map_mutation_record_batch+0x224>
1000b1be8:     	str	x17, [sp, #0x88]
1000b1bec:     	ldr	w10, [x9]
1000b1bf0:     	ldp	x5, x0, [x9, #0x8]
1000b1bf4:     	ldr	x11, [x9, #0x18]
1000b1bf8:     	str	x11, [sp, #0xd8]
1000b1bfc:     	ldr	x11, [x9, #0x20]
1000b1c00:     	str	x11, [sp, #0xd0]
1000b1c04:     	ldr	x11, [x9, #0x28]
1000b1c08:     	str	x11, [sp, #0xc8]
1000b1c0c:     	ldp	x11, x1, [x9, #0x30]
1000b1c10:     	str	x11, [sp, #0xc0]
1000b1c14:     	ldp	x2, x4, [x9, #0x40]
1000b1c18:     	ldp	x6, x7, [x9, #0x50]
1000b1c1c:     	ldp	x19, x20, [x9, #0x60]
1000b1c20:     	ldp	x21, x22, [x9, #0x70]
1000b1c24:     	ldp	x23, x24, [x9, #0x80]
1000b1c28:     	ldp	x25, x26, [x9, #0x90]
1000b1c2c:     	ldp	x27, x28, [x9, #0xa0]
1000b1c30:     	ldp	x30, x11, [x9, #0xb0]
1000b1c34:     	str	x11, [sp, #0xb8]
1000b1c38:     	ldr	x11, [x9, #0xc0]
1000b1c3c:     	str	x11, [sp, #0xb0]
1000b1c40:     	ldr	x11, [x9, #0xc8]
1000b1c44:     	str	x11, [sp, #0xa8]
1000b1c48:     	ldr	x11, [x9, #0xd0]
1000b1c4c:     	str	x11, [sp, #0xa0]
1000b1c50:     	ldr	x11, [x9, #0xd8]
1000b1c54:     	str	x11, [sp, #0x98]
1000b1c58:     	ldr	x11, [x9, #0xe0]
1000b1c5c:     	str	x11, [sp, #0x90]
1000b1c60:     	mov	w11, #0x1               ; =1
1000b1c64:     	str	x11, [x9]
1000b1c68:     	stur	q1, [x9, #0x8]
1000b1c6c:     	stur	q1, [x9, #0x18]
1000b1c70:     	stur	q1, [x9, #0x28]
1000b1c74:     	stur	q1, [x9, #0x38]
1000b1c78:     	stur	q1, [x9, #0x48]
1000b1c7c:     	stur	q1, [x9, #0x58]
1000b1c80:     	stur	q1, [x9, #0x68]
1000b1c84:     	stur	q1, [x9, #0x78]
1000b1c88:     	stur	q1, [x9, #0x88]
1000b1c8c:     	stur	q1, [x9, #0x98]
1000b1c90:     	stur	q1, [x9, #0xa8]
1000b1c94:     	stur	q1, [x9, #0xb8]
1000b1c98:     	stur	q1, [x9, #0xc8]
1000b1c9c:     	stur	q1, [x9, #0xd8]
1000b1ca0:     	ldp	x11, x12, [x9, #0xe8]
1000b1ca4:     	stur	q1, [x9, #0xe8]
1000b1ca8:     	ldp	x13, x16, [x9, #0xf8]
1000b1cac:     	stur	q1, [x9, #0xf8]
1000b1cb0:     	ldr	x17, [x9, #0x108]
1000b1cb4:     	str	xzr, [x9, #0x108]
1000b1cb8:     	cmp	w10, #0x2
1000b1cbc:     	b.ne	0x1000b1db4 <_eco_c_map_mutation_record_batch+0x424>
1000b1cc0:     	mov	x9, x0
1000b1cc4:     	sub	x8, x8, #0x1
1000b1cc8:     	ldr	x0, [sp, #0x60]
1000b1ccc:     	str	x8, [x0, #0x18]
1000b1cd0:     	ldr	x8, [x0, #0x20]
1000b1cd4:     	cmn	x8, #0x1
1000b1cd8:     	b.eq	0x1000b1ce4 <_eco_c_map_mutation_record_batch+0x354>
1000b1cdc:     	add	x8, x8, #0x1
1000b1ce0:     	str	x8, [x0, #0x20]
1000b1ce4:     	madd	x8, x5, x15, x9
1000b1ce8:     	ldp	x9, x10, [sp, #0xd0]
1000b1cec:     	madd	x8, x8, x15, x10
1000b1cf0:     	madd	x8, x8, x15, x9
1000b1cf4:     	ldp	x9, x10, [sp, #0xc0]
1000b1cf8:     	madd	x8, x8, x15, x10
1000b1cfc:     	madd	x8, x8, x15, x9
1000b1d00:     	madd	x8, x8, x15, x1
1000b1d04:     	madd	x8, x8, x15, x2
1000b1d08:     	madd	x8, x8, x15, x4
1000b1d0c:     	madd	x8, x8, x15, x6
1000b1d10:     	madd	x8, x8, x15, x7
1000b1d14:     	madd	x8, x8, x15, x19
1000b1d18:     	madd	x8, x8, x15, x20
1000b1d1c:     	madd	x8, x8, x15, x21
1000b1d20:     	madd	x8, x8, x15, x22
1000b1d24:     	madd	x8, x8, x15, x23
1000b1d28:     	madd	x8, x8, x15, x24
1000b1d2c:     	madd	x8, x8, x15, x25
1000b1d30:     	madd	x8, x8, x15, x26
1000b1d34:     	madd	x8, x8, x15, x27
1000b1d38:     	madd	x8, x8, x15, x28
1000b1d3c:     	madd	x8, x8, x15, x30
1000b1d40:     	ldp	x9, x10, [sp, #0xb0]
1000b1d44:     	madd	x8, x8, x15, x10
1000b1d48:     	madd	x8, x8, x15, x9
1000b1d4c:     	ldp	x9, x10, [sp, #0xa0]
1000b1d50:     	madd	x8, x8, x15, x10
1000b1d54:     	madd	x8, x8, x15, x9
1000b1d58:     	ldp	x9, x10, [sp, #0x90]
1000b1d5c:     	madd	x8, x8, x15, x10
1000b1d60:     	madd	x8, x8, x15, x9
1000b1d64:     	madd	x8, x8, x15, x11
1000b1d68:     	madd	x8, x8, x15, x12
1000b1d6c:     	madd	x8, x8, x15, x13
1000b1d70:     	madd	x8, x8, x15, x16
1000b1d74:     	ldr	x9, [sp, #0x88]
1000b1d78:     	mov	w10, #0x4309            ; =17161
1000b1d7c:     	madd	x9, x9, x10, x17
1000b1d80:     	madd	x8, x8, x15, x9
1000b1d84:     	add	x17, x8, #0x83
1000b1d88:     	ldrb	w8, [x0, #0x30]
1000b1d8c:     	str	x17, [sp, #0x88]
1000b1d90:     	tbnz	w8, #0x0, 0x1000b1da8 <_eco_c_map_mutation_record_batch+0x418>
1000b1d94:     	b	0x1000b1dcc <_eco_c_map_mutation_record_batch+0x43c>
1000b1d98:     	mul	x17, x17, x15
1000b1d9c:     	ldrb	w8, [x0, #0x30]
1000b1da0:     	str	x17, [sp, #0x88]
1000b1da4:     	tbz	w8, #0x0, 0x1000b1dcc <_eco_c_map_mutation_record_batch+0x43c>
1000b1da8:     	mov	x15, x3
1000b1dac:     	mov	x26, #0x0               ; =0
1000b1db0:     	b	0x1000b1e0c <_eco_c_map_mutation_record_batch+0x47c>
1000b1db4:     	ldr	x17, [sp, #0x88]
1000b1db8:     	mul	x17, x17, x15
1000b1dbc:     	ldr	x0, [sp, #0x60]
1000b1dc0:     	ldrb	w8, [x0, #0x30]
1000b1dc4:     	str	x17, [sp, #0x88]
1000b1dc8:     	tbnz	w8, #0x0, 0x1000b1da8 <_eco_c_map_mutation_record_batch+0x418>
1000b1dcc:     	ldr	x8, [x0, #0x28]
1000b1dd0:     	mov	x15, x3
1000b1dd4:     	eor	x8, x8, x3
1000b1dd8:     	eor	x8, x8, x8, lsr #30
1000b1ddc:     	mov	x9, #0xe5b9             ; =58809
1000b1de0:     	movk	x9, #0x1ce4, lsl #16
1000b1de4:     	movk	x9, #0x476d, lsl #32
1000b1de8:     	movk	x9, #0xbf58, lsl #48
1000b1dec:     	mul	x8, x8, x9
1000b1df0:     	eor	x8, x8, x8, lsr #27
1000b1df4:     	mov	x9, #0x11eb             ; =4587
1000b1df8:     	movk	x9, #0x1331, lsl #16
1000b1dfc:     	movk	x9, #0x49bb, lsl #32
1000b1e00:     	movk	x9, #0x94d0, lsl #48
1000b1e04:     	mul	x8, x8, x9
1000b1e08:     	eor	x26, x8, x8, lsr #31
1000b1e0c:     	ldr	x8, [sp, #0x58]
1000b1e10:     	str	x14, [sp, #0x68]
1000b1e14:     	add	x7, x8, x14
1000b1e18:     	add	x8, x7, #0x1
1000b1e1c:     	add	x16, x7, #0x2
1000b1e20:     	add	x9, x7, #0x3
1000b1e24:     	add	x13, x7, #0x4
1000b1e28:     	add	x12, x7, #0x5
1000b1e2c:     	add	x2, x7, #0x6
1000b1e30:     	add	x4, x7, #0x7
1000b1e34:     	add	x6, x7, #0x8
1000b1e38:     	add	x10, x7, #0x9
1000b1e3c:     	add	x20, x7, #0xa
1000b1e40:     	add	x19, x7, #0xb
1000b1e44:     	add	x22, x7, #0xc
1000b1e48:     	add	x21, x7, #0xd
1000b1e4c:     	add	x24, x7, #0xe
1000b1e50:     	add	x23, x7, #0xf
1000b1e54:     	add	x14, x7, #0x10
1000b1e58:     	add	x25, x7, #0x11
1000b1e5c:     	add	x11, x7, #0x12
1000b1e60:     	str	x11, [sp, #0x78]
1000b1e64:     	add	x11, x7, #0x13
1000b1e68:     	str	x11, [sp, #0x80]
1000b1e6c:     	add	x17, x7, #0x14
1000b1e70:     	add	x3, x7, #0x15
1000b1e74:     	add	x1, x7, #0x16
1000b1e78:     	add	x11, x7, #0x17
1000b1e7c:     	add	x30, x7, #0x18
1000b1e80:     	add	x27, x7, #0x19
1000b1e84:     	add	x5, x7, #0x1a
1000b1e88:     	add	x28, x7, #0x1b
1000b1e8c:     	stp	x5, x28, [sp, #0xb0]
1000b1e90:     	add	x5, x7, #0x1c
1000b1e94:     	add	x28, x7, #0x1d
1000b1e98:     	stp	x5, x28, [sp, #0xa0]
1000b1e9c:     	add	x28, x7, #0x1e
1000b1ea0:     	str	x28, [sp, #0x98]
1000b1ea4:     	ldr	x28, [x0]
1000b1ea8:     	add	x5, x7, #0x1f
1000b1eac:     	str	x5, [sp, #0x90]
1000b1eb0:     	str	x17, [sp, #0x70]
1000b1eb4:     	stp	x1, x11, [sp, #0xd0]
1000b1eb8:     	stp	x30, x27, [sp, #0xc0]
1000b1ebc:     	cbz	x28, 0x1000b1ed8 <_eco_c_map_mutation_record_batch+0x548>
1000b1ec0:     	sub	x11, x28, #0x1
1000b1ec4:     	tst	x28, x11
1000b1ec8:     	b.eq	0x1000b1ee8 <_eco_c_map_mutation_record_batch+0x558>
1000b1ecc:     	udiv	x11, x26, x28
1000b1ed0:     	msub	x30, x11, x28, x26
1000b1ed4:     	b	0x1000b1eec <_eco_c_map_mutation_record_batch+0x55c>
1000b1ed8:     	mov	x11, #0x0               ; =0
1000b1edc:     	mov	x5, x15
1000b1ee0:     	mov	w15, #0x83              ; =131
1000b1ee4:     	b	0x1000b2140 <_eco_c_map_mutation_record_batch+0x7b0>
1000b1ee8:     	and	x30, x11, x26
1000b1eec:     	mov	x5, x15
1000b1ef0:     	ldr	x17, [x0, #0x10]
1000b1ef4:     	mov	x27, x28
1000b1ef8:     	mov	x11, x28
1000b1efc:     	mov	w0, #0x110              ; =272
1000b1f00:     	mov	w15, #0x83              ; =131
1000b1f04:     	b	0x1000b1f24 <_eco_c_map_mutation_record_batch+0x594>
1000b1f08:     	cmp	x11, x28
1000b1f0c:     	csel	x11, x30, x11, eq
1000b1f10:     	add	x1, x30, #0x1
1000b1f14:     	cmp	x1, x28
1000b1f18:     	csinc	x30, xzr, x30, eq
1000b1f1c:     	subs	x27, x27, #0x1
1000b1f20:     	b.eq	0x1000b2140 <_eco_c_map_mutation_record_batch+0x7b0>
1000b1f24:     	madd	x26, x30, x0, x17
1000b1f28:     	ldr	w1, [x26]
1000b1f2c:     	cmp	w1, #0x1
1000b1f30:     	b.eq	0x1000b1f08 <_eco_c_map_mutation_record_batch+0x578>
1000b1f34:     	cbz	w1, 0x1000b2138 <_eco_c_map_mutation_record_batch+0x7a8>
1000b1f38:     	ldr	x1, [x26, #0x8]
1000b1f3c:     	cmp	x1, x5
1000b1f40:     	b.ne	0x1000b1f10 <_eco_c_map_mutation_record_batch+0x580>
1000b1f44:     	mov	w30, #0x110             ; =272
1000b1f48:     	ldp	x11, x17, [x26, #0x8]
1000b1f4c:     	stp	x5, x7, [x26, #0x8]
1000b1f50:     	ldp	x0, x28, [x26, #0x18]
1000b1f54:     	stp	x8, x16, [x26, #0x18]
1000b1f58:     	ldp	x16, x1, [x26, #0x28]
1000b1f5c:     	stp	x9, x13, [x26, #0x28]
1000b1f60:     	ldp	x13, x9, [x26, #0x38]
1000b1f64:     	stp	x12, x2, [x26, #0x38]
1000b1f68:     	ldp	x2, x12, [x26, #0x48]
1000b1f6c:     	stp	x4, x6, [x26, #0x48]
1000b1f70:     	ldp	x6, x4, [x26, #0x58]
1000b1f74:     	stp	x10, x20, [x26, #0x58]
1000b1f78:     	ldp	x20, x10, [x26, #0x68]
1000b1f7c:     	stp	x19, x22, [x26, #0x68]
1000b1f80:     	ldp	x22, x5, [x26, #0x78]
1000b1f84:     	stp	x21, x24, [x26, #0x78]
1000b1f88:     	ldp	x24, x7, [x26, #0x88]
1000b1f8c:     	stp	x23, x14, [x26, #0x88]
1000b1f90:     	ldp	x14, x19, [x26, #0x98]
1000b1f94:     	ldr	x8, [sp, #0x78]
1000b1f98:     	stp	x25, x8, [x26, #0x98]
1000b1f9c:     	ldp	x21, x23, [x26, #0xa8]
1000b1fa0:     	ldr	x8, [sp, #0x80]
1000b1fa4:     	str	x8, [x26, #0xa8]
1000b1fa8:     	ldr	x8, [sp, #0x70]
1000b1fac:     	str	x8, [x26, #0xb0]
1000b1fb0:     	ldp	x25, x8, [x26, #0xb8]
1000b1fb4:     	str	x8, [sp, #0x80]
1000b1fb8:     	ldr	x8, [sp, #0xd0]
1000b1fbc:     	stp	x3, x8, [x26, #0xb8]
1000b1fc0:     	ldp	x3, x27, [x26, #0xc8]
1000b1fc4:     	ldr	x8, [sp, #0xd8]
1000b1fc8:     	str	x8, [x26, #0xc8]
1000b1fcc:     	ldr	x8, [sp, #0xc0]
1000b1fd0:     	str	x8, [x26, #0xd0]
1000b1fd4:     	ldr	x8, [x26, #0xd8]
1000b1fd8:     	str	x8, [sp, #0x78]
1000b1fdc:     	ldr	x8, [x26, #0xe0]
1000b1fe0:     	str	x8, [sp, #0x70]
1000b1fe4:     	ldr	x8, [sp, #0xc8]
1000b1fe8:     	str	x8, [x26, #0xd8]
1000b1fec:     	ldr	x8, [sp, #0xb0]
1000b1ff0:     	str	x8, [x26, #0xe0]
1000b1ff4:     	ldr	x8, [x26, #0xe8]
1000b1ff8:     	str	x8, [sp, #0x48]
1000b1ffc:     	ldr	x8, [x26, #0xf0]
1000b2000:     	str	x8, [sp, #0x40]
1000b2004:     	ldr	x8, [sp, #0xb8]
1000b2008:     	str	x8, [x26, #0xe8]
1000b200c:     	ldr	x8, [sp, #0xa0]
1000b2010:     	str	x8, [x26, #0xf0]
1000b2014:     	ldr	x8, [x26, #0xf8]
1000b2018:     	str	x8, [sp, #0x38]
1000b201c:     	ldr	x8, [x26, #0x100]
1000b2020:     	str	x8, [sp, #0x30]
1000b2024:     	ldr	x8, [sp, #0xa8]
1000b2028:     	str	x8, [x26, #0xf8]
1000b202c:     	ldr	x8, [sp, #0x98]
1000b2030:     	str	x8, [x26, #0x100]
1000b2034:     	ldr	x8, [x26, #0x108]
1000b2038:     	str	x8, [sp, #0x28]
1000b203c:     	ldr	x8, [sp, #0x90]
1000b2040:     	str	x8, [x26, #0x108]
1000b2044:     	ldr	d2, [x26]
1000b2048:     	str	d0, [x26]
1000b204c:     	fmov	w8, s2
1000b2050:     	cmp	w8, #0x2
1000b2054:     	b.ne	0x1000b23e8 <_eco_c_map_mutation_record_batch+0xa58>
1000b2058:     	mov	x26, x25
1000b205c:     	mov	x25, x14
1000b2060:     	mov	x14, x5
1000b2064:     	mov	x5, x11
1000b2068:     	mov	x11, x7
1000b206c:     	mov	x7, x17
1000b2070:     	str	x27, [sp, #0xc8]
1000b2074:     	mov	x27, x3
1000b2078:     	mov	x3, x21
1000b207c:     	mov	x21, x10
1000b2080:     	mov	x10, x12
1000b2084:     	mov	x12, x1
1000b2088:     	mov	x1, x0
1000b208c:     	mov	x17, x19
1000b2090:     	mov	x19, x4
1000b2094:     	mov	x4, x9
1000b2098:     	mov	x9, x28
1000b209c:     	mov	x8, x16
1000b20a0:     	mov	x16, x13
1000b20a4:     	mov	x13, x2
1000b20a8:     	mov	x2, x6
1000b20ac:     	mov	x6, x20
1000b20b0:     	mov	x20, x22
1000b20b4:     	mov	x22, x14
1000b20b8:     	mov	x0, x23
1000b20bc:     	mov	x23, x24
1000b20c0:     	mov	x14, x11
1000b20c4:     	mov	x28, x17
1000b20c8:     	mov	x24, x3
1000b20cc:     	mov	x3, x26
1000b20d0:     	ldr	x17, [sp, #0x80]
1000b20d4:     	stp	x17, x27, [sp, #0xd0]
1000b20d8:     	ldr	x17, [sp, #0xc8]
1000b20dc:     	str	x17, [sp, #0xc0]
1000b20e0:     	ldr	x17, [sp, #0x78]
1000b20e4:     	str	x17, [sp, #0xc8]
1000b20e8:     	ldr	x17, [sp, #0x70]
1000b20ec:     	str	x17, [sp, #0xb0]
1000b20f0:     	ldr	x17, [sp, #0x48]
1000b20f4:     	str	x17, [sp, #0xb8]
1000b20f8:     	ldr	x17, [sp, #0x40]
1000b20fc:     	str	x17, [sp, #0xa0]
1000b2100:     	ldr	x17, [sp, #0x38]
1000b2104:     	str	x17, [sp, #0xa8]
1000b2108:     	ldr	x17, [sp, #0x30]
1000b210c:     	str	x17, [sp, #0x98]
1000b2110:     	ldr	x17, [sp, #0x28]
1000b2114:     	str	x17, [sp, #0x90]
1000b2118:     	mov	x27, x0
1000b211c:     	mov	w26, #0x1               ; =1
1000b2120:     	ldr	x17, [sp, #0x88]
1000b2124:     	ldr	x0, [sp, #0x60]
1000b2128:     	mul	x11, x17, x15
1000b212c:     	add	x17, x11, w26, uxtw
1000b2130:     	cbnz	w26, 0x1000b1a68 <_eco_c_map_mutation_record_batch+0xd8>
1000b2134:     	b	0x1000b1b04 <_eco_c_map_mutation_record_batch+0x174>
1000b2138:     	cmp	x11, x28
1000b213c:     	csel	x11, x30, x11, eq
1000b2140:     	mov	w30, #0x110             ; =272
1000b2144:     	cmp	x11, x28
1000b2148:     	ldr	x0, [sp, #0x60]
1000b214c:     	b.hs	0x1000b1a1c <_eco_c_map_mutation_record_batch+0x8c>
1000b2150:     	ldr	x17, [x0, #0x18]
1000b2154:     	lsr	x1, x17, #13
1000b2158:     	cbnz	x1, 0x1000b1a1c <_eco_c_map_mutation_record_batch+0x8c>
1000b215c:     	add	x17, x17, #0x1
1000b2160:     	str	x17, [x0, #0x18]
1000b2164:     	ldr	x17, [x0, #0x10]
1000b2168:     	madd	x26, x11, x30, x17
1000b216c:     	ldr	w11, [x26]
1000b2170:     	cmp	w11, #0x1
1000b2174:     	ldr	x17, [sp, #0x88]
1000b2178:     	ldp	x27, x1, [sp, #0x70]
1000b217c:     	b.ne	0x1000b2190 <_eco_c_map_mutation_record_batch+0x800>
1000b2180:     	ldr	x11, [x0, #0x20]
1000b2184:     	cbz	x11, 0x1000b2190 <_eco_c_map_mutation_record_batch+0x800>
1000b2188:     	sub	x11, x11, #0x1
1000b218c:     	str	x11, [x0, #0x20]
1000b2190:     	ldp	x11, x0, [x26, #0x8]
1000b2194:     	stp	x5, x7, [x26, #0x8]
1000b2198:     	ldp	x28, x5, [x26, #0x18]
1000b219c:     	stp	x8, x16, [x26, #0x18]
1000b21a0:     	ldp	x16, x7, [x26, #0x28]
1000b21a4:     	stp	x9, x13, [x26, #0x28]
1000b21a8:     	ldp	x13, x9, [x26, #0x38]
1000b21ac:     	stp	x12, x2, [x26, #0x38]
1000b21b0:     	ldp	x2, x12, [x26, #0x48]
1000b21b4:     	stp	x4, x6, [x26, #0x48]
1000b21b8:     	ldp	x6, x4, [x26, #0x58]
1000b21bc:     	stp	x10, x20, [x26, #0x58]
1000b21c0:     	ldp	x20, x10, [x26, #0x68]
1000b21c4:     	stp	x19, x22, [x26, #0x68]
1000b21c8:     	ldp	x22, x19, [x26, #0x78]
1000b21cc:     	stp	x21, x24, [x26, #0x78]
1000b21d0:     	ldp	x24, x21, [x26, #0x88]
1000b21d4:     	stp	x23, x14, [x26, #0x88]
1000b21d8:     	ldp	x14, x23, [x26, #0x98]
1000b21dc:     	stp	x25, x1, [x26, #0x98]
1000b21e0:     	ldp	x1, x25, [x26, #0xa8]
1000b21e4:     	ldr	x8, [sp, #0x80]
1000b21e8:     	stp	x8, x27, [x26, #0xa8]
1000b21ec:     	ldr	x8, [x26, #0xb8]
1000b21f0:     	str	x8, [sp, #0x80]
1000b21f4:     	ldr	x8, [x26, #0xc0]
1000b21f8:     	str	x8, [sp, #0x78]
1000b21fc:     	ldr	x8, [sp, #0xd0]
1000b2200:     	stp	x3, x8, [x26, #0xb8]
1000b2204:     	ldp	x3, x8, [x26, #0xc8]
1000b2208:     	str	x8, [sp, #0x70]
1000b220c:     	ldr	x8, [sp, #0xd8]
1000b2210:     	str	x8, [x26, #0xc8]
1000b2214:     	ldr	x8, [sp, #0xc0]
1000b2218:     	str	x8, [x26, #0xd0]
1000b221c:     	ldr	x8, [x26, #0xd8]
1000b2220:     	str	x8, [sp, #0x48]
1000b2224:     	ldr	x8, [x26, #0xe0]
1000b2228:     	str	x8, [sp, #0x40]
1000b222c:     	ldr	x8, [sp, #0xc8]
1000b2230:     	str	x8, [x26, #0xd8]
1000b2234:     	ldr	x8, [sp, #0xb0]
1000b2238:     	str	x8, [x26, #0xe0]
1000b223c:     	ldr	x8, [x26, #0xe8]
1000b2240:     	str	x8, [sp, #0x38]
1000b2244:     	ldr	x8, [x26, #0xf0]
1000b2248:     	str	x8, [sp, #0x30]
1000b224c:     	ldr	x8, [sp, #0xb8]
1000b2250:     	str	x8, [x26, #0xe8]
1000b2254:     	ldr	x8, [sp, #0xa0]
1000b2258:     	str	x8, [x26, #0xf0]
1000b225c:     	ldr	x8, [x26, #0xf8]
1000b2260:     	str	x8, [sp, #0x28]
1000b2264:     	ldp	x8, x27, [x26, #0x100]
1000b2268:     	str	x8, [sp, #0x20]
1000b226c:     	ldr	x8, [sp, #0xa8]
1000b2270:     	str	x8, [x26, #0xf8]
1000b2274:     	ldr	x8, [sp, #0x98]
1000b2278:     	str	x8, [x26, #0x100]
1000b227c:     	ldr	x8, [sp, #0x90]
1000b2280:     	str	x8, [x26, #0x108]
1000b2284:     	ldr	d2, [x26]
1000b2288:     	str	d0, [x26]
1000b228c:     	fmov	w8, s2
1000b2290:     	cmp	w8, #0x2
1000b2294:     	b.ne	0x1000b2360 <_eco_c_map_mutation_record_batch+0x9d0>
1000b2298:     	mov	x26, x3
1000b229c:     	mov	x3, x25
1000b22a0:     	mov	x25, x14
1000b22a4:     	mov	x14, x19
1000b22a8:     	mov	x19, x4
1000b22ac:     	mov	x4, x9
1000b22b0:     	mov	x9, x5
1000b22b4:     	mov	x5, x11
1000b22b8:     	mov	x11, x21
1000b22bc:     	mov	x21, x10
1000b22c0:     	mov	x10, x12
1000b22c4:     	mov	x12, x7
1000b22c8:     	mov	x7, x0
1000b22cc:     	mov	x0, x1
1000b22d0:     	mov	x1, x28
1000b22d4:     	mov	x8, x16
1000b22d8:     	mov	x16, x13
1000b22dc:     	mov	x13, x2
1000b22e0:     	mov	x2, x6
1000b22e4:     	mov	x6, x20
1000b22e8:     	mov	x20, x22
1000b22ec:     	mov	x22, x14
1000b22f0:     	mov	x28, x23
1000b22f4:     	mov	x23, x24
1000b22f8:     	mov	x14, x11
1000b22fc:     	mov	x24, x0
1000b2300:     	mov	x11, x3
1000b2304:     	ldp	x0, x3, [sp, #0x78]
1000b2308:     	stp	x0, x26, [sp, #0xd0]
1000b230c:     	ldr	x0, [sp, #0x70]
1000b2310:     	str	x0, [sp, #0xc0]
1000b2314:     	ldr	x0, [sp, #0x48]
1000b2318:     	str	x0, [sp, #0xc8]
1000b231c:     	ldr	x0, [sp, #0x40]
1000b2320:     	str	x0, [sp, #0xb0]
1000b2324:     	ldr	x0, [sp, #0x38]
1000b2328:     	str	x0, [sp, #0xb8]
1000b232c:     	ldr	x0, [sp, #0x30]
1000b2330:     	str	x0, [sp, #0xa0]
1000b2334:     	ldr	x0, [sp, #0x28]
1000b2338:     	str	x0, [sp, #0xa8]
1000b233c:     	ldr	x0, [sp, #0x20]
1000b2340:     	stp	x27, x0, [sp, #0x90]
1000b2344:     	mov	x27, x11
1000b2348:     	mov	w26, #0x1               ; =1
1000b234c:     	ldr	x0, [sp, #0x60]
1000b2350:     	mul	x11, x17, x15
1000b2354:     	add	x17, x11, w26, uxtw
1000b2358:     	cbnz	w26, 0x1000b1a68 <_eco_c_map_mutation_record_batch+0xd8>
1000b235c:     	b	0x1000b1b04 <_eco_c_map_mutation_record_batch+0x174>
1000b2360:     	mov	x5, #0x0                ; =0
1000b2364:     	mov	x7, #0x0                ; =0
1000b2368:     	mov	x1, #0x0                ; =0
1000b236c:     	mov	x9, #0x0                ; =0
1000b2370:     	mov	x8, #0x0                ; =0
1000b2374:     	mov	x12, #0x0               ; =0
1000b2378:     	mov	x16, #0x0               ; =0
1000b237c:     	mov	x4, #0x0                ; =0
1000b2380:     	mov	x13, #0x0               ; =0
1000b2384:     	mov	x10, #0x0               ; =0
1000b2388:     	mov	x2, #0x0                ; =0
1000b238c:     	mov	x19, #0x0               ; =0
1000b2390:     	mov	x6, #0x0                ; =0
1000b2394:     	mov	x21, #0x0               ; =0
1000b2398:     	mov	x20, #0x0               ; =0
1000b239c:     	mov	x22, #0x0               ; =0
1000b23a0:     	mov	x23, #0x0               ; =0
1000b23a4:     	mov	x14, #0x0               ; =0
1000b23a8:     	mov	x25, #0x0               ; =0
1000b23ac:     	mov	x28, #0x0               ; =0
1000b23b0:     	mov	x24, #0x0               ; =0
1000b23b4:     	mov	x27, #0x0               ; =0
1000b23b8:     	mov	x3, #0x0                ; =0
1000b23bc:     	stp	xzr, xzr, [sp, #0xd0]
1000b23c0:     	stp	xzr, xzr, [sp, #0xc0]
1000b23c4:     	stp	xzr, xzr, [sp, #0xb0]
1000b23c8:     	stp	xzr, xzr, [sp, #0xa0]
1000b23cc:     	stp	xzr, xzr, [sp, #0x90]
1000b23d0:     	mov	w26, #0x0               ; =0
1000b23d4:     	ldr	x0, [sp, #0x60]
1000b23d8:     	mul	x11, x17, x15
1000b23dc:     	add	x17, x11, w26, uxtw
1000b23e0:     	cbnz	w26, 0x1000b1a68 <_eco_c_map_mutation_record_batch+0xd8>
1000b23e4:     	b	0x1000b1b04 <_eco_c_map_mutation_record_batch+0x174>
1000b23e8:     	mov	x5, #0x0                ; =0
1000b23ec:     	mov	x7, #0x0                ; =0
1000b23f0:     	mov	x1, #0x0                ; =0
1000b23f4:     	mov	x9, #0x0                ; =0
1000b23f8:     	mov	x8, #0x0                ; =0
1000b23fc:     	mov	x12, #0x0               ; =0
1000b2400:     	mov	x16, #0x0               ; =0
1000b2404:     	mov	x4, #0x0                ; =0
1000b2408:     	mov	x13, #0x0               ; =0
1000b240c:     	mov	x10, #0x0               ; =0
1000b2410:     	mov	x2, #0x0                ; =0
1000b2414:     	mov	x19, #0x0               ; =0
1000b2418:     	mov	x6, #0x0                ; =0
1000b241c:     	mov	x21, #0x0               ; =0
1000b2420:     	mov	x20, #0x0               ; =0
1000b2424:     	mov	x22, #0x0               ; =0
1000b2428:     	mov	x23, #0x0               ; =0
1000b242c:     	mov	x14, #0x0               ; =0
1000b2430:     	mov	x25, #0x0               ; =0
1000b2434:     	mov	x28, #0x0               ; =0
1000b2438:     	mov	x24, #0x0               ; =0
1000b243c:     	mov	x27, #0x0               ; =0
1000b2440:     	mov	x3, #0x0                ; =0
1000b2444:     	stp	xzr, xzr, [sp, #0xd0]
1000b2448:     	stp	xzr, xzr, [sp, #0xc0]
1000b244c:     	stp	xzr, xzr, [sp, #0xb0]
1000b2450:     	stp	xzr, xzr, [sp, #0xa0]
1000b2454:     	stp	xzr, xzr, [sp, #0x90]
1000b2458:     	mov	w26, #0x0               ; =0
1000b245c:     	ldr	x17, [sp, #0x88]
1000b2460:     	ldr	x0, [sp, #0x60]
1000b2464:     	mul	x11, x17, x15
1000b2468:     	add	x17, x11, w26, uxtw
1000b246c:     	cbnz	w26, 0x1000b1a68 <_eco_c_map_mutation_record_batch+0xd8>
1000b2470:     	b	0x1000b1b04 <_eco_c_map_mutation_record_batch+0x174>
1000b2474:     	ldr	x8, [sp, #0x8]
1000b2478:     	add	x8, x10, x8
1000b247c:     	str	x8, [x0, #0x48]
1000b2480:     	eor	x8, x17, x17, lsr #30
1000b2484:     	mov	x9, #0xe5b9             ; =58809
1000b2488:     	movk	x9, #0x1ce4, lsl #16
1000b248c:     	movk	x9, #0x476d, lsl #32
1000b2490:     	movk	x9, #0xbf58, lsl #48
1000b2494:     	mul	x8, x8, x9
1000b2498:     	eor	x8, x8, x8, lsr #27
1000b249c:     	mov	x9, #0x11eb             ; =4587
1000b24a0:     	movk	x9, #0x1331, lsl #16
1000b24a4:     	movk	x9, #0x49bb, lsl #32
1000b24a8:     	movk	x9, #0x94d0, lsl #48
1000b24ac:     	mul	x8, x8, x9
1000b24b0:     	eor	x0, x8, x8, lsr #31
1000b24b4:     	ldp	x29, x30, [sp, #0x130]
1000b24b8:     	ldp	x20, x19, [sp, #0x120]
1000b24bc:     	ldp	x22, x21, [sp, #0x110]
1000b24c0:     	ldp	x24, x23, [sp, #0x100]
1000b24c4:     	ldp	x26, x25, [sp, #0xf0]
1000b24c8:     	ldp	x28, x27, [sp, #0xe0]
1000b24cc:     	add	sp, sp, #0x140
1000b24d0:     	ret

