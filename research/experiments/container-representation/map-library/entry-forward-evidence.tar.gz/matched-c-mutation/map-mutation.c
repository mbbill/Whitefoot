/* Scratch matched operation control. No ownership/alias attributes are added. */
#define ECO_MAP_CONTROL 1
#include "<repository-root>/research/experiments/container-representation/map-library/map-costs.c"

static uint64_t matched_home(uint64_t hash, uint64_t count) {
    uint64_t mask = count - 1;
    uint64_t index = hash & mask;
    if ((count & mask) != 0) index = hash % count;
    return index;
}
static _Alignas(8) unsigned char matched_empty_anchor[8];

typedef struct { uint32_t tag; word_Pair pair; } matched_word_Cell;
typedef struct { uint64_t len, cap; matched_word_Cell *payload; uint64_t length, vacated; } matched_word_Map;
typedef struct { uint32_t tag; bool reason; word_Pair pair; } matched_word_Put;
typedef struct { uint32_t tag; word_Pair pair; } matched_word_Removed;
typedef struct { matched_word_Map map; HashEnv env; uint64_t seed, count, generation; } matched_word_Owner;
_Static_assert(sizeof(matched_word_Map) == 40 && offsetof(matched_word_Map,payload) == 16 && offsetof(matched_word_Map,vacated) == 32, "inline map layout");
_Static_assert(sizeof(matched_word_Cell) == 24 && offsetof(matched_word_Cell,pair) == 8 && offsetof(word_Pair,value) == 8, "enum cell layout");
_Static_assert(sizeof(matched_word_Put) == 24 && offsetof(matched_word_Put,reason) == 4 && offsetof(matched_word_Put,pair) == 8, "compact returned pair");
_Static_assert(sizeof(matched_word_Owner) == 80 && offsetof(matched_word_Owner,generation) == 72 && _Alignof(matched_word_Owner) <= 16, "mutation caller storage");
static matched_word_Map matched_word_new(uint64_t cap) {
    require(cap <= 8192, "matched capacity ceiling");
    matched_word_Cell *cells = cap ? wf_cost_allocate(cap * sizeof(matched_word_Cell)) : (void *)matched_empty_anchor;
    require(cells != NULL, "matched allocation");
    for (uint64_t i = 0; i < cap; ++i) cells[i].tag = EMPTY;
    return (matched_word_Map){cap,cap,cells,0,0};
}
static void matched_word_swap(matched_word_Cell *a, matched_word_Cell *b) {
    matched_word_Cell temporary;
    memcpy(&temporary,a,sizeof temporary);
    memmove(a,b,sizeof temporary);
    memcpy(b,&temporary,sizeof temporary);
}
static unsigned matched_word_action(const matched_word_Cell *slot, const HashEnv *env, const uint64_t *key) {
    if (slot->tag == EMPTY) return ACTION_STOP;
    if (slot->tag == DELETED) return ACTION_SKIP;
    return key_equal(env,&slot->pair.key,key) ? ACTION_MATCH : ACTION_MISS;
}
static HELPER Probe matched_word_find(const matched_word_Map *map, const HashEnv *env, const uint64_t *key) {
    uint64_t hash=key_hash(env,key), count=map->len;
    if (count == 0) return (Probe){false,0};
    uint64_t index=matched_home(hash,count);
    for (uint64_t step=0;step<count;++step) {
        unsigned action=matched_word_action(&map->payload[index],env,key);
        if (action==ACTION_MATCH) return (Probe){true,index};
        if (action==ACTION_STOP) return (Probe){false,0};
        index=successor(index,count);
    }
    return (Probe){false,0};
}
static HELPER matched_word_Put matched_word_exchange(matched_word_Map *map,uint64_t index,word_Pair pair) {
    matched_word_Cell offered={.tag=LIVE,.pair=pair};
    matched_word_swap(&map->payload[index],&offered);
    if (offered.tag==LIVE) return (matched_word_Put){.tag=1,.reason=false,.pair=offered.pair};
    return (matched_word_Put){.tag=0};
}
static HELPER matched_word_Put matched_word_try_put(matched_word_Map *map,const HashEnv *env,word_Pair pair) {
    uint64_t hash=key_hash(env,&pair.key),count=map->len,available=count;
    if (count>0) {
        uint64_t index=matched_home(hash,count);
        for (uint64_t step=0;step<count;++step) {
            unsigned action=matched_word_action(&map->payload[index],env,&pair.key);
            if (action==ACTION_MATCH) return matched_word_exchange(map,index,pair);
            if (action==ACTION_STOP) { if (available==count) available=index; break; }
            if (action==ACTION_SKIP && available==count) available=index;
            index=successor(index,count);
        }
    }
    if (available<count && map->length<8192) {
        ++map->length;
        if (map->payload[available].tag==DELETED && map->vacated>0) --map->vacated;
        return matched_word_exchange(map,available,pair);
    }
    return (matched_word_Put){.tag=1,.reason=true,.pair=pair};
}
static HELPER matched_word_Removed matched_word_remove(matched_word_Map *map,const HashEnv *env,const uint64_t *key) {
    uint64_t before=map->length;
    if (before==0) return (matched_word_Removed){.tag=0};
    Probe found=matched_word_find(map,env,key);
    if (!found.found) return (matched_word_Removed){.tag=0};
    matched_word_Cell old={.tag=DELETED};
    matched_word_swap(&map->payload[found.index],&old);
    if (old.tag!=LIVE) return (matched_word_Removed){.tag=0};
    map->length=before-1;
    if (map->vacated<UINT64_MAX) ++map->vacated;
    return (matched_word_Removed){.tag=1,.pair=old.pair};
}
static HELPER void matched_word_free(matched_word_Map map,Digest *digest) {
    for (uint64_t i=0;i<map.len;++i) if (map.payload[i].tag==LIVE)
        word_consume(digest,map.payload[i].pair.key,map.payload[i].pair.value);
    if (map.cap!=0) wf_cost_release(map.payload);
}
void eco_c_map_mutation_word_prepare(void *storage,uint64_t slots,uint64_t count,uint64_t seed) {
    require(count<=slots && slots<=8192,"matched mutation dimensions");
    matched_word_Owner *o=storage;
    *o=(matched_word_Owner){matched_word_new(slots),{seed^UINT64_C(0x9e3779b97f4a7c15),false},seed,count,0};
    for (uint64_t i=0;i<count;++i) {
        matched_word_Put put=matched_word_try_put(&o->map,&o->env,(word_Pair){key_at(i),word_make(seed+i)});
        require(put.tag==0,"matched prepare insertion");
    }
}
uint64_t eco_c_map_mutation_word_batch(void *storage,uint64_t rounds,uint64_t operation) {
    matched_word_Owner *o=storage;Digest digest={o->seed,0,0,0};
    for (uint64_t round=0;round<rounds;++round) {
        uint64_t next=o->generation+1,base=o->seed+next*o->count;
        for (uint64_t i=0;i<o->count;++i) {
            uint64_t key=key_at(i);
            if (operation!=0) {
                matched_word_Removed old=matched_word_remove(&o->map,&o->env,&key);
                ordered(&digest,old.tag!=0);
                if (old.tag) ordered(&digest,word_content(old.pair.key,old.pair.value));
            }
            uint64_t value=word_make(base+i);
            matched_word_Put put=matched_word_try_put(&o->map,&o->env,(word_Pair){key,value});
            ordered(&digest,put.tag ? (put.reason ? 2 : 1) : 0);
            if (put.tag) ordered(&digest,word_content(put.pair.key,put.pair.value));
        }
        o->generation=next;
    }
    return finish(digest);
}
uint64_t eco_c_map_mutation_word_geometry(const void *storage) {
    const matched_word_Owner *o=storage;return (o->map.len<<32)|o->map.length;
}
uint64_t eco_c_map_mutation_word_verify(const void *storage) {
    const matched_word_Owner *o=storage;Digest digest={o->seed,0,0,0};
    for (uint64_t i=0;i<o->count;++i) for (uint64_t miss=0;miss<2;++miss) {
        uint64_t key=key_at(i)+miss;Probe found=matched_word_find(&o->map,&o->env,&key);
        ordered(&digest,found.found);
        if (found.found) ordered(&digest,word_identity(&o->map.payload[found.index].pair.value));
    }
    return finish(digest);
}
uint64_t eco_c_map_mutation_word_finish(void *storage) {
    matched_word_Owner *o=storage;Digest digest={o->seed,0,0,0};matched_word_free(o->map,&digest);memset(o,0,sizeof *o);return finish(digest);
}
static void matched_word_policy(void) {
    HashEnv env={0,true};Digest digest={0};matched_word_Map map=matched_word_new(3);
    for (uint64_t i=0;i<3;++i) {matched_word_Put p=matched_word_try_put(&map,&env,(word_Pair){i*2+1,word_make(10+i)});require(p.tag==0,"capacity3 insert");}
    matched_word_Put full=matched_word_try_put(&map,&env,(word_Pair){99,word_make(99)});
    require(full.tag==1 && full.reason && full.pair.key==99 && word_content(99,full.pair.value)==word_content(99,word_make(99)),"complete full refusal");
    uint64_t key=1;matched_word_Removed removed=matched_word_remove(&map,&env,&key);
    require(removed.tag==1 && removed.pair.key==1 && word_content(1,removed.pair.value)==word_content(1,word_make(10)),"complete removed pair");
    matched_word_Put duplicate=matched_word_try_put(&map,&env,(word_Pair){5,word_make(55)});
    require(duplicate.tag==1 && !duplicate.reason && duplicate.pair.key==5 && word_content(5,duplicate.pair.value)==word_content(5,word_make(12)) && map.length==2 && map.vacated==1,"duplicate beyond tombstone");
    matched_word_Put inserted=matched_word_try_put(&map,&env,(word_Pair){7,word_make(77)});
    require(inserted.tag==0 && map.payload[0].pair.key==7 && map.length==3 && map.vacated==0,"first tombstone reuse");
    /* Nonzero home2 forces wrap through2,0,1 at arbitrary capacity3. */
    matched_word_free(map,&digest);env.collide=false;map=matched_word_new(3);uint64_t keys[3],used=0;
    for (uint64_t k=0;used<3;++k) if (key_hash(&env,&k)%3==2) keys[used++]=k;
    for (uint64_t i=0;i<3;++i) {matched_word_Put p=matched_word_try_put(&map,&env,(word_Pair){keys[i],word_make(i)});require(p.tag==0,"wrapped insert");}
    for (uint64_t i=0;i<3;++i) require(matched_word_find(&map,&env,&keys[i]).found,"wrapped find");
    matched_word_free(map,&digest);map=matched_word_new(0);matched_word_Put zero=matched_word_try_put(&map,&env,(word_Pair){1,word_make(8)});
    require(zero.tag==1 && zero.reason && zero.pair.key==1 && word_content(1,zero.pair.value)==word_content(1,word_make(8)),"zero capacity complete refusal");matched_word_free(map,&digest);
}

typedef struct { uint32_t tag; record_Pair pair; } matched_record_Cell;
typedef struct { uint64_t len, cap; matched_record_Cell *payload; uint64_t length, vacated; } matched_record_Map;
typedef struct { uint32_t tag; bool reason; record_Pair pair; } matched_record_Put;
typedef struct { uint32_t tag; record_Pair pair; } matched_record_Removed;
typedef struct { matched_record_Map map; HashEnv env; uint64_t seed, count, generation; } matched_record_Owner;
_Static_assert(sizeof(matched_record_Map) == 40 && offsetof(matched_record_Map,payload) == 16 && offsetof(matched_record_Map,vacated) == 32, "inline map layout");
_Static_assert(sizeof(matched_record_Cell) == 272 && offsetof(matched_record_Cell,pair) == 8 && offsetof(record_Pair,value) == 8, "enum cell layout");
_Static_assert(sizeof(matched_record_Put) == 272 && offsetof(matched_record_Put,reason) == 4 && offsetof(matched_record_Put,pair) == 8, "compact returned pair");
_Static_assert(sizeof(matched_record_Owner) == 80 && offsetof(matched_record_Owner,generation) == 72 && _Alignof(matched_record_Owner) <= 16, "mutation caller storage");
static matched_record_Map matched_record_new(uint64_t cap) {
    require(cap <= 8192, "matched capacity ceiling");
    matched_record_Cell *cells = cap ? wf_cost_allocate(cap * sizeof(matched_record_Cell)) : (void *)matched_empty_anchor;
    require(cells != NULL, "matched allocation");
    for (uint64_t i = 0; i < cap; ++i) cells[i].tag = EMPTY;
    return (matched_record_Map){cap,cap,cells,0,0};
}
static void matched_record_swap(matched_record_Cell *a, matched_record_Cell *b) {
    matched_record_Cell temporary;
    memcpy(&temporary,a,sizeof temporary);
    memmove(a,b,sizeof temporary);
    memcpy(b,&temporary,sizeof temporary);
}
static unsigned matched_record_action(const matched_record_Cell *slot, const HashEnv *env, const uint64_t *key) {
    if (slot->tag == EMPTY) return ACTION_STOP;
    if (slot->tag == DELETED) return ACTION_SKIP;
    return key_equal(env,&slot->pair.key,key) ? ACTION_MATCH : ACTION_MISS;
}
static HELPER Probe matched_record_find(const matched_record_Map *map, const HashEnv *env, const uint64_t *key) {
    uint64_t hash=key_hash(env,key), count=map->len;
    if (count == 0) return (Probe){false,0};
    uint64_t index=matched_home(hash,count);
    for (uint64_t step=0;step<count;++step) {
        unsigned action=matched_record_action(&map->payload[index],env,key);
        if (action==ACTION_MATCH) return (Probe){true,index};
        if (action==ACTION_STOP) return (Probe){false,0};
        index=successor(index,count);
    }
    return (Probe){false,0};
}
static HELPER matched_record_Put matched_record_exchange(matched_record_Map *map,uint64_t index,record_Pair pair) {
    matched_record_Cell offered={.tag=LIVE,.pair=pair};
    matched_record_swap(&map->payload[index],&offered);
    if (offered.tag==LIVE) return (matched_record_Put){.tag=1,.reason=false,.pair=offered.pair};
    return (matched_record_Put){.tag=0};
}
static HELPER matched_record_Put matched_record_try_put(matched_record_Map *map,const HashEnv *env,record_Pair pair) {
    uint64_t hash=key_hash(env,&pair.key),count=map->len,available=count;
    if (count>0) {
        uint64_t index=matched_home(hash,count);
        for (uint64_t step=0;step<count;++step) {
            unsigned action=matched_record_action(&map->payload[index],env,&pair.key);
            if (action==ACTION_MATCH) return matched_record_exchange(map,index,pair);
            if (action==ACTION_STOP) { if (available==count) available=index; break; }
            if (action==ACTION_SKIP && available==count) available=index;
            index=successor(index,count);
        }
    }
    if (available<count && map->length<8192) {
        ++map->length;
        if (map->payload[available].tag==DELETED && map->vacated>0) --map->vacated;
        return matched_record_exchange(map,available,pair);
    }
    return (matched_record_Put){.tag=1,.reason=true,.pair=pair};
}
static HELPER matched_record_Removed matched_record_remove(matched_record_Map *map,const HashEnv *env,const uint64_t *key) {
    uint64_t before=map->length;
    if (before==0) return (matched_record_Removed){.tag=0};
    Probe found=matched_record_find(map,env,key);
    if (!found.found) return (matched_record_Removed){.tag=0};
    matched_record_Cell old={.tag=DELETED};
    matched_record_swap(&map->payload[found.index],&old);
    if (old.tag!=LIVE) return (matched_record_Removed){.tag=0};
    map->length=before-1;
    if (map->vacated<UINT64_MAX) ++map->vacated;
    return (matched_record_Removed){.tag=1,.pair=old.pair};
}
static HELPER void matched_record_free(matched_record_Map map,Digest *digest) {
    for (uint64_t i=0;i<map.len;++i) if (map.payload[i].tag==LIVE)
        record_consume(digest,map.payload[i].pair.key,map.payload[i].pair.value);
    if (map.cap!=0) wf_cost_release(map.payload);
}
void eco_c_map_mutation_record_prepare(void *storage,uint64_t slots,uint64_t count,uint64_t seed) {
    require(count<=slots && slots<=8192,"matched mutation dimensions");
    matched_record_Owner *o=storage;
    *o=(matched_record_Owner){matched_record_new(slots),{seed^UINT64_C(0x9e3779b97f4a7c15),false},seed,count,0};
    for (uint64_t i=0;i<count;++i) {
        matched_record_Put put=matched_record_try_put(&o->map,&o->env,(record_Pair){key_at(i),record_make(seed+i)});
        require(put.tag==0,"matched prepare insertion");
    }
}
uint64_t eco_c_map_mutation_record_batch(void *storage,uint64_t rounds,uint64_t operation) {
    matched_record_Owner *o=storage;Digest digest={o->seed,0,0,0};
    for (uint64_t round=0;round<rounds;++round) {
        uint64_t next=o->generation+1,base=o->seed+next*o->count;
        for (uint64_t i=0;i<o->count;++i) {
            uint64_t key=key_at(i);
            if (operation!=0) {
                matched_record_Removed old=matched_record_remove(&o->map,&o->env,&key);
                ordered(&digest,old.tag!=0);
                if (old.tag) ordered(&digest,record_content(old.pair.key,old.pair.value));
            }
            Record value=record_make(base+i);
            matched_record_Put put=matched_record_try_put(&o->map,&o->env,(record_Pair){key,value});
            ordered(&digest,put.tag ? (put.reason ? 2 : 1) : 0);
            if (put.tag) ordered(&digest,record_content(put.pair.key,put.pair.value));
        }
        o->generation=next;
    }
    return finish(digest);
}
uint64_t eco_c_map_mutation_record_geometry(const void *storage) {
    const matched_record_Owner *o=storage;return (o->map.len<<32)|o->map.length;
}
uint64_t eco_c_map_mutation_record_verify(const void *storage) {
    const matched_record_Owner *o=storage;Digest digest={o->seed,0,0,0};
    for (uint64_t i=0;i<o->count;++i) for (uint64_t miss=0;miss<2;++miss) {
        uint64_t key=key_at(i)+miss;Probe found=matched_record_find(&o->map,&o->env,&key);
        ordered(&digest,found.found);
        if (found.found) ordered(&digest,record_identity(&o->map.payload[found.index].pair.value));
    }
    return finish(digest);
}
uint64_t eco_c_map_mutation_record_finish(void *storage) {
    matched_record_Owner *o=storage;Digest digest={o->seed,0,0,0};matched_record_free(o->map,&digest);memset(o,0,sizeof *o);return finish(digest);
}
static void matched_record_policy(void) {
    HashEnv env={0,true};Digest digest={0};matched_record_Map map=matched_record_new(3);
    for (uint64_t i=0;i<3;++i) {matched_record_Put p=matched_record_try_put(&map,&env,(record_Pair){i*2+1,record_make(10+i)});require(p.tag==0,"capacity3 insert");}
    matched_record_Put full=matched_record_try_put(&map,&env,(record_Pair){99,record_make(99)});
    require(full.tag==1 && full.reason && full.pair.key==99 && record_content(99,full.pair.value)==record_content(99,record_make(99)),"complete full refusal");
    uint64_t key=1;matched_record_Removed removed=matched_record_remove(&map,&env,&key);
    require(removed.tag==1 && removed.pair.key==1 && record_content(1,removed.pair.value)==record_content(1,record_make(10)),"complete removed pair");
    matched_record_Put duplicate=matched_record_try_put(&map,&env,(record_Pair){5,record_make(55)});
    require(duplicate.tag==1 && !duplicate.reason && duplicate.pair.key==5 && record_content(5,duplicate.pair.value)==record_content(5,record_make(12)) && map.length==2 && map.vacated==1,"duplicate beyond tombstone");
    matched_record_Put inserted=matched_record_try_put(&map,&env,(record_Pair){7,record_make(77)});
    require(inserted.tag==0 && map.payload[0].pair.key==7 && map.length==3 && map.vacated==0,"first tombstone reuse");
    /* Nonzero home2 forces wrap through2,0,1 at arbitrary capacity3. */
    matched_record_free(map,&digest);env.collide=false;map=matched_record_new(3);uint64_t keys[3],used=0;
    for (uint64_t k=0;used<3;++k) if (key_hash(&env,&k)%3==2) keys[used++]=k;
    for (uint64_t i=0;i<3;++i) {matched_record_Put p=matched_record_try_put(&map,&env,(record_Pair){keys[i],record_make(i)});require(p.tag==0,"wrapped insert");}
    for (uint64_t i=0;i<3;++i) require(matched_record_find(&map,&env,&keys[i]).found,"wrapped find");
    matched_record_free(map,&digest);map=matched_record_new(0);matched_record_Put zero=matched_record_try_put(&map,&env,(record_Pair){1,record_make(8)});
    require(zero.tag==1 && zero.reason && zero.pair.key==1 && record_content(1,zero.pair.value)==record_content(1,record_make(8)),"zero capacity complete refusal");matched_record_free(map,&digest);
}

void eco_c_map_mutation_policy_check(void) { matched_word_policy(); matched_record_policy(); puts("matched C: capacity0/3 wrap, full refusal, tombstone duplicate/reuse passed"); }
