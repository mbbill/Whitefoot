00000001000a83fc <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d>:
1000a83fc:     	mov	x9, x3
1000a8400:     	mov	x3, x2
1000a8404:     	ldrb	w8, [x4, #0x8]
1000a8408:     	tbz	w8, #0x0, 0x1000a8430 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x34>
1000a840c:     	mov	x8, #0x0                ; =0
1000a8410:     	ldr	x10, [x1]
1000a8414:     	cbz	x10, 0x1000a8474 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x78>
1000a8418:     	sub	x11, x10, #0x1
1000a841c:     	tst	x10, x11
1000a8420:     	b.eq	0x1000a847c <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x80>
1000a8424:     	udiv	x11, x8, x10
1000a8428:     	msub	x8, x11, x10, x8
1000a842c:     	b	0x1000a8480 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x84>
1000a8430:     	ldr	x8, [x4]
1000a8434:     	eor	x8, x8, x3
1000a8438:     	eor	x8, x8, x8, lsr #30
1000a843c:     	mov	x10, #0xe5b9            ; =58809
1000a8440:     	movk	x10, #0x1ce4, lsl #16
1000a8444:     	movk	x10, #0x476d, lsl #32
1000a8448:     	movk	x10, #0xbf58, lsl #48
1000a844c:     	mul	x8, x8, x10
1000a8450:     	eor	x8, x8, x8, lsr #27
1000a8454:     	mov	x10, #0x11eb            ; =4587
1000a8458:     	movk	x10, #0x1331, lsl #16
1000a845c:     	movk	x10, #0x49bb, lsl #32
1000a8460:     	movk	x10, #0x94d0, lsl #48
1000a8464:     	mul	x8, x8, x10
1000a8468:     	eor	x8, x8, x8, lsr #31
1000a846c:     	ldr	x10, [x1]
1000a8470:     	cbnz	x10, 0x1000a8418 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x1c>
1000a8474:     	mov	x2, #0x0                ; =0
1000a8478:     	b	0x1000a84e8 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xec>
1000a847c:     	and	x8, x11, x8
1000a8480:     	ldr	x11, [x1, #0x10]
1000a8484:     	mov	w12, #0x110             ; =272
1000a8488:     	mov	x13, x10
1000a848c:     	mov	x2, x10
1000a8490:     	b	0x1000a84b0 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xb4>
1000a8494:     	cmp	x2, x10
1000a8498:     	csel	x2, x8, x2, eq
1000a849c:     	add	x14, x8, #0x1
1000a84a0:     	cmp	x14, x10
1000a84a4:     	csinc	x8, xzr, x8, hs
1000a84a8:     	subs	x13, x13, #0x1
1000a84ac:     	b.eq	0x1000a84e8 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xec>
1000a84b0:     	madd	x14, x8, x12, x11
1000a84b4:     	ldr	w15, [x14]
1000a84b8:     	cmp	w15, #0x1
1000a84bc:     	b.eq	0x1000a8494 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x98>
1000a84c0:     	cmp	w15, #0x2
1000a84c4:     	b.ne	0x1000a84e0 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xe4>
1000a84c8:     	ldr	x14, [x14, #0x8]
1000a84cc:     	cmp	x14, x3
1000a84d0:     	b.ne	0x1000a849c <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xa0>
1000a84d4:     	mov	x2, x8
1000a84d8:     	mov	x4, x9
1000a84dc:     	b	0x1000ab378 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449>
1000a84e0:     	cmp	x2, x10
1000a84e4:     	csel	x2, x8, x2, eq
1000a84e8:     	cmp	x2, x10
1000a84ec:     	b.hs	0x1000a8534 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x138>
1000a84f0:     	ldr	x8, [x1, #0x18]
1000a84f4:     	lsr	x10, x8, #13
1000a84f8:     	cbnz	x10, 0x1000a8534 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x138>
1000a84fc:     	add	x8, x8, #0x1
1000a8500:     	str	x8, [x1, #0x18]
1000a8504:     	ldr	x8, [x1, #0x10]
1000a8508:     	mov	w10, #0x110             ; =272
1000a850c:     	mul	x10, x2, x10
1000a8510:     	ldr	w8, [x8, x10]
1000a8514:     	cmp	w8, #0x1
1000a8518:     	b.ne	0x1000a852c <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x130>
1000a851c:     	ldr	x8, [x1, #0x20]
1000a8520:     	subs	x8, x8, #0x1
1000a8524:     	csel	x8, xzr, x8, lo
1000a8528:     	str	x8, [x1, #0x20]
1000a852c:     	mov	x4, x9
1000a8530:     	b	0x1000ab378 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449>
1000a8534:     	ldp	q0, q1, [x9]
1000a8538:     	ldp	q2, q3, [x9, #0x20]
1000a853c:     	ldp	q4, q5, [x9, #0x40]
1000a8540:     	ldp	q6, q7, [x9, #0x60]
1000a8544:     	ldp	q16, q17, [x9, #0x80]
1000a8548:     	ldp	q18, q19, [x9, #0xa0]
1000a854c:     	ldp	q20, q21, [x9, #0xc0]
1000a8550:     	ldp	q22, q23, [x9, #0xe0]
1000a8554:     	stp	xzr, x3, [x0]
1000a8558:     	mov	w8, #0x1                ; =1
1000a855c:     	str	w8, [x0]
1000a8560:     	strb	w8, [x0, #0x4]
1000a8564:     	stp	q0, q1, [x0, #0x10]
1000a8568:     	stp	q2, q3, [x0, #0x30]
1000a856c:     	stp	q4, q5, [x0, #0x50]
1000a8570:     	stp	q6, q7, [x0, #0x70]
1000a8574:     	stp	q16, q17, [x0, #0x90]
1000a8578:     	stp	q18, q19, [x0, #0xb0]
1000a857c:     	stp	q20, q21, [x0, #0xd0]
1000a8580:     	stp	q22, q23, [x0, #0xf0]
1000a8584:     	ret

