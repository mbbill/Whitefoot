00000001000a472c <_wf_flat_mutation_batch$instance$4250cb78d3f44027>:
1000a472c:     	stp	x28, x27, [sp, #-0x60]!
1000a4730:     	stp	x26, x25, [sp, #0x10]
1000a4734:     	stp	x24, x23, [sp, #0x20]
1000a4738:     	stp	x22, x21, [sp, #0x30]
1000a473c:     	stp	x20, x19, [sp, #0x40]
1000a4740:     	stp	x29, x30, [sp, #0x50]
1000a4744:     	sub	sp, sp, #0x3a0
1000a4748:     	ldr	x24, [x0, #0x38]
1000a474c:     	str	x1, [sp, #0x8]
1000a4750:     	cbz	x1, 0x1000a4ce0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x5b4>
1000a4754:     	mov	x19, x0
1000a4758:     	ldr	x26, [x0, #0x40]
1000a475c:     	cbz	x26, 0x1000a4cd0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x5a4>
1000a4760:     	mov	x21, x2
1000a4764:     	str	xzr, [sp, #0x18]
1000a4768:     	adrp	x8, 0x1000d4000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x35c>
1000a476c:     	ldr	q0, [x8, #0xc40]
1000a4770:     	str	q0, [sp, #0x180]
1000a4774:     	adrp	x8, 0x1000d4000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x35c>
1000a4778:     	ldr	q0, [x8, #0x9f0]
1000a477c:     	str	q0, [sp, #0x170]
1000a4780:     	add	x27, sp, #0x2a0
1000a4784:     	adrp	x8, 0x1000d4000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x35c>
1000a4788:     	ldr	q0, [x8, #0x9e0]
1000a478c:     	str	q0, [sp, #0x160]
1000a4790:     	mov	w28, #0x1               ; =1
1000a4794:     	adrp	x8, 0x1000d4000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x35c>
1000a4798:     	ldr	q0, [x8, #0xa10]
1000a479c:     	str	q0, [sp, #0x150]
1000a47a0:     	adrp	x8, 0x1000d4000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x35c>
1000a47a4:     	ldr	q0, [x8, #0xa00]
1000a47a8:     	str	q0, [sp, #0x140]
1000a47ac:     	adrp	x8, 0x1000d4000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x35c>
1000a47b0:     	ldr	q0, [x8, #0xa30]
1000a47b4:     	str	q0, [sp, #0x130]
1000a47b8:     	adrp	x8, 0x1000d4000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x35c>
1000a47bc:     	ldr	q0, [x8, #0xa20]
1000a47c0:     	str	q0, [sp, #0x120]
1000a47c4:     	adrp	x8, 0x1000d4000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x35c>
1000a47c8:     	ldr	q0, [x8, #0xa50]
1000a47cc:     	str	q0, [sp, #0x110]
1000a47d0:     	adrp	x8, 0x1000d4000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x35c>
1000a47d4:     	ldr	q0, [x8, #0xa40]
1000a47d8:     	str	q0, [sp, #0x100]
1000a47dc:     	adrp	x8, 0x1000d4000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x35c>
1000a47e0:     	ldr	q0, [x8, #0xa70]
1000a47e4:     	str	q0, [sp, #0xf0]
1000a47e8:     	adrp	x8, 0x1000d4000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x35c>
1000a47ec:     	ldr	q0, [x8, #0xa60]
1000a47f0:     	str	q0, [sp, #0xe0]
1000a47f4:     	adrp	x8, 0x1000d4000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x35c>
1000a47f8:     	ldr	q0, [x8, #0xa90]
1000a47fc:     	str	q0, [sp, #0xd0]
1000a4800:     	adrp	x8, 0x1000d4000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x35c>
1000a4804:     	ldr	q0, [x8, #0xa80]
1000a4808:     	str	q0, [sp, #0xc0]
1000a480c:     	adrp	x8, 0x1000d4000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x35c>
1000a4810:     	ldr	q0, [x8, #0xab0]
1000a4814:     	str	q0, [sp, #0xb0]
1000a4818:     	adrp	x8, 0x1000d4000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x35c>
1000a481c:     	ldr	q0, [x8, #0xaa0]
1000a4820:     	str	q0, [sp, #0xa0]
1000a4824:     	mov	w20, #0x83              ; =131
1000a4828:     	mov	w22, #0x110             ; =272
1000a482c:     	ldr	x10, [x19, #0x48]
1000a4830:     	add	x10, x10, #0x1
1000a4834:     	str	x10, [sp, #0x10]
1000a4838:     	cbz	x26, 0x1000a4ca4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x578>
1000a483c:     	mov	x23, #0x0               ; =0
1000a4840:     	ldr	x8, [x19, #0x38]
1000a4844:     	madd	x25, x10, x26, x8
1000a4848:     	b	0x1000a4954 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x228>
1000a484c:     	ldrb	w8, [sp, #0x194]
1000a4850:     	tst	w8, #0x1
1000a4854:     	ldp	x9, x8, [sp, #0x198]
1000a4858:     	madd	x8, x9, x20, x8
1000a485c:     	ldp	x10, x9, [sp, #0x1a8]
1000a4860:     	madd	x8, x8, x20, x10
1000a4864:     	madd	x8, x8, x20, x9
1000a4868:     	ldp	x10, x9, [sp, #0x1b8]
1000a486c:     	madd	x8, x8, x20, x10
1000a4870:     	madd	x8, x8, x20, x9
1000a4874:     	ldp	x10, x9, [sp, #0x1c8]
1000a4878:     	madd	x8, x8, x20, x10
1000a487c:     	madd	x8, x8, x20, x9
1000a4880:     	ldp	x10, x9, [sp, #0x1d8]
1000a4884:     	madd	x8, x8, x20, x10
1000a4888:     	madd	x8, x8, x20, x9
1000a488c:     	ldp	x10, x9, [sp, #0x1e8]
1000a4890:     	madd	x8, x8, x20, x10
1000a4894:     	madd	x8, x8, x20, x9
1000a4898:     	ldp	x10, x9, [sp, #0x1f8]
1000a489c:     	madd	x8, x8, x20, x10
1000a48a0:     	madd	x8, x8, x20, x9
1000a48a4:     	ldr	x9, [sp, #0x208]
1000a48a8:     	madd	x8, x8, x20, x9
1000a48ac:     	ldr	x9, [sp, #0x210]
1000a48b0:     	madd	x8, x8, x20, x9
1000a48b4:     	ldr	x9, [sp, #0x218]
1000a48b8:     	madd	x8, x8, x20, x9
1000a48bc:     	ldr	x9, [sp, #0x220]
1000a48c0:     	madd	x8, x8, x20, x9
1000a48c4:     	ldr	x9, [sp, #0x228]
1000a48c8:     	madd	x8, x8, x20, x9
1000a48cc:     	ldr	x9, [sp, #0x230]
1000a48d0:     	madd	x8, x8, x20, x9
1000a48d4:     	ldr	x9, [sp, #0x238]
1000a48d8:     	madd	x8, x8, x20, x9
1000a48dc:     	ldr	x9, [sp, #0x240]
1000a48e0:     	madd	x8, x8, x20, x9
1000a48e4:     	ldr	x9, [sp, #0x248]
1000a48e8:     	madd	x8, x8, x20, x9
1000a48ec:     	ldr	x9, [sp, #0x250]
1000a48f0:     	madd	x8, x8, x20, x9
1000a48f4:     	ldr	x9, [sp, #0x258]
1000a48f8:     	madd	x8, x8, x20, x9
1000a48fc:     	ldr	x9, [sp, #0x260]
1000a4900:     	madd	x8, x8, x20, x9
1000a4904:     	ldr	x9, [sp, #0x268]
1000a4908:     	madd	x8, x8, x20, x9
1000a490c:     	ldr	x9, [sp, #0x270]
1000a4910:     	madd	x8, x8, x20, x9
1000a4914:     	ldr	x9, [sp, #0x278]
1000a4918:     	madd	x8, x8, x20, x9
1000a491c:     	ldr	x9, [sp, #0x280]
1000a4920:     	madd	x8, x8, x20, x9
1000a4924:     	ldr	x9, [sp, #0x288]
1000a4928:     	add	x9, x9, x24
1000a492c:     	ldr	x10, [sp, #0x290]
1000a4930:     	madd	x8, x8, x20, x9
1000a4934:     	cinc	x9, x28, ne
1000a4938:     	add	x9, x9, x10
1000a493c:     	madd	x8, x8, x20, x9
1000a4940:     	ldr	x9, [sp, #0x298]
1000a4944:     	madd	x24, x8, x20, x9
1000a4948:     	add	x23, x23, #0x1
1000a494c:     	cmp	x23, x26
1000a4950:     	b.eq	0x1000a4ca4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x578>
1000a4954:     	orr	x2, x28, x23, lsl #1
1000a4958:     	cbz	x21, 0x1000a4bb0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x484>
1000a495c:     	ldr	x8, [x19, #0x18]
1000a4960:     	cbz	x8, 0x1000a4bac <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x480>
1000a4964:     	ldrb	w9, [x19, #0x30]
1000a4968:     	tbz	w9, #0x0, 0x1000a497c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x250>
1000a496c:     	mov	x9, #0x0                ; =0
1000a4970:     	ldr	x10, [x19]
1000a4974:     	cbnz	x10, 0x1000a49c0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x294>
1000a4978:     	b	0x1000a4bac <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x480>
1000a497c:     	ldr	x9, [x19, #0x28]
1000a4980:     	eor	x9, x9, x2
1000a4984:     	eor	x9, x9, x9, lsr #30
1000a4988:     	mov	x10, #0xe5b9            ; =58809
1000a498c:     	movk	x10, #0x1ce4, lsl #16
1000a4990:     	movk	x10, #0x476d, lsl #32
1000a4994:     	movk	x10, #0xbf58, lsl #48
1000a4998:     	mul	x9, x9, x10
1000a499c:     	eor	x9, x9, x9, lsr #27
1000a49a0:     	mov	x10, #0x11eb            ; =4587
1000a49a4:     	movk	x10, #0x1331, lsl #16
1000a49a8:     	movk	x10, #0x49bb, lsl #32
1000a49ac:     	movk	x10, #0x94d0, lsl #48
1000a49b0:     	mul	x9, x9, x10
1000a49b4:     	eor	x9, x9, x9, lsr #31
1000a49b8:     	ldr	x10, [x19]
1000a49bc:     	cbz	x10, 0x1000a4bac <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x480>
1000a49c0:     	sub	x11, x10, #0x1
1000a49c4:     	tst	x10, x11
1000a49c8:     	b.eq	0x1000a49d8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2ac>
1000a49cc:     	udiv	x11, x9, x10
1000a49d0:     	msub	x11, x11, x10, x9
1000a49d4:     	b	0x1000a49dc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2b0>
1000a49d8:     	and	x11, x11, x9
1000a49dc:     	ldr	x12, [x19, #0x10]
1000a49e0:     	mov	x13, x10
1000a49e4:     	b	0x1000a49fc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2d0>
1000a49e8:     	add	x9, x11, #0x1
1000a49ec:     	cmp	x9, x10
1000a49f0:     	csinc	x11, xzr, x11, hs
1000a49f4:     	subs	x13, x13, #0x1
1000a49f8:     	b.eq	0x1000a4bac <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x480>
1000a49fc:     	madd	x9, x11, x22, x12
1000a4a00:     	ldr	w14, [x9]
1000a4a04:     	cmp	w14, #0x1
1000a4a08:     	b.eq	0x1000a49e8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2bc>
1000a4a0c:     	cmp	w14, #0x2
1000a4a10:     	b.ne	0x1000a4bac <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x480>
1000a4a14:     	ldr	x14, [x9, #0x8]
1000a4a18:     	cmp	x14, x2
1000a4a1c:     	b.ne	0x1000a49e8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2bc>
1000a4a20:     	ldp	x11, x10, [x9, #0x10]
1000a4a24:     	stp	x10, x11, [sp, #0x90]
1000a4a28:     	ldp	x11, x10, [x9, #0x20]
1000a4a2c:     	stp	x10, x11, [sp, #0x80]
1000a4a30:     	ldp	x14, x15, [x9, #0x30]
1000a4a34:     	ldp	x16, x17, [x9, #0x40]
1000a4a38:     	ldp	x0, x1, [x9, #0x50]
1000a4a3c:     	ldp	x3, x4, [x9, #0x60]
1000a4a40:     	ldp	x5, x6, [x9, #0x70]
1000a4a44:     	ldp	x7, x30, [x9, #0x80]
1000a4a48:     	ldp	x11, x10, [x9, #0x90]
1000a4a4c:     	stp	x10, x11, [sp, #0x70]
1000a4a50:     	ldp	x11, x10, [x9, #0xa0]
1000a4a54:     	stp	x10, x11, [sp, #0x60]
1000a4a58:     	ldp	x11, x10, [x9, #0xb0]
1000a4a5c:     	stp	x10, x11, [sp, #0x50]
1000a4a60:     	ldp	x11, x10, [x9, #0xc0]
1000a4a64:     	stp	x10, x11, [sp, #0x40]
1000a4a68:     	ldp	x11, x10, [x9, #0xd0]
1000a4a6c:     	stp	x10, x11, [sp, #0x30]
1000a4a70:     	ldp	x11, x10, [x9, #0xe0]
1000a4a74:     	stp	x10, x11, [sp, #0x20]
1000a4a78:     	str	w28, [x9]
1000a4a7c:     	movi.2d	v0, #0000000000000000
1000a4a80:     	stur	q0, [x9, #0x8]
1000a4a84:     	stur	q0, [x9, #0x18]
1000a4a88:     	stur	q0, [x9, #0x28]
1000a4a8c:     	stur	q0, [x9, #0x38]
1000a4a90:     	stur	q0, [x9, #0x48]
1000a4a94:     	stur	q0, [x9, #0x58]
1000a4a98:     	stur	q0, [x9, #0x68]
1000a4a9c:     	stur	q0, [x9, #0x78]
1000a4aa0:     	stur	q0, [x9, #0x88]
1000a4aa4:     	stur	q0, [x9, #0x98]
1000a4aa8:     	stur	q0, [x9, #0xa8]
1000a4aac:     	stur	q0, [x9, #0xb8]
1000a4ab0:     	stur	q0, [x9, #0xc8]
1000a4ab4:     	stur	q0, [x9, #0xd8]
1000a4ab8:     	ldp	x12, x13, [x9, #0xf0]
1000a4abc:     	stur	q0, [x9, #0xe8]
1000a4ac0:     	ldp	x10, x11, [x9, #0x100]
1000a4ac4:     	stur	q0, [x9, #0xf8]
1000a4ac8:     	str	xzr, [x9, #0x108]
1000a4acc:     	sub	x8, x8, #0x1
1000a4ad0:     	ldr	x9, [x19, #0x20]
1000a4ad4:     	adds	x9, x9, #0x1
1000a4ad8:     	csinv	x9, x9, xzr, lo
1000a4adc:     	stp	x8, x9, [x19, #0x18]
1000a4ae0:     	ldp	x9, x8, [sp, #0x90]
1000a4ae4:     	madd	x8, x2, x20, x8
1000a4ae8:     	madd	x8, x8, x20, x9
1000a4aec:     	ldr	x9, [sp, #0x88]
1000a4af0:     	madd	x8, x8, x20, x9
1000a4af4:     	ldr	x9, [sp, #0x80]
1000a4af8:     	madd	x8, x8, x20, x9
1000a4afc:     	madd	x8, x8, x20, x14
1000a4b00:     	madd	x8, x8, x20, x15
1000a4b04:     	madd	x8, x8, x20, x16
1000a4b08:     	madd	x8, x8, x20, x17
1000a4b0c:     	madd	x8, x8, x20, x0
1000a4b10:     	madd	x8, x8, x20, x1
1000a4b14:     	madd	x8, x8, x20, x3
1000a4b18:     	madd	x8, x8, x20, x4
1000a4b1c:     	madd	x8, x8, x20, x5
1000a4b20:     	madd	x8, x8, x20, x6
1000a4b24:     	madd	x8, x8, x20, x7
1000a4b28:     	madd	x8, x8, x20, x30
1000a4b2c:     	ldr	x9, [sp, #0x78]
1000a4b30:     	madd	x8, x8, x20, x9
1000a4b34:     	ldr	x9, [sp, #0x70]
1000a4b38:     	madd	x8, x8, x20, x9
1000a4b3c:     	ldr	x9, [sp, #0x68]
1000a4b40:     	madd	x8, x8, x20, x9
1000a4b44:     	ldr	x9, [sp, #0x60]
1000a4b48:     	madd	x8, x8, x20, x9
1000a4b4c:     	ldr	x9, [sp, #0x58]
1000a4b50:     	madd	x8, x8, x20, x9
1000a4b54:     	ldr	x9, [sp, #0x50]
1000a4b58:     	madd	x8, x8, x20, x9
1000a4b5c:     	ldr	x9, [sp, #0x48]
1000a4b60:     	madd	x8, x8, x20, x9
1000a4b64:     	ldr	x9, [sp, #0x40]
1000a4b68:     	madd	x8, x8, x20, x9
1000a4b6c:     	ldr	x9, [sp, #0x38]
1000a4b70:     	madd	x8, x8, x20, x9
1000a4b74:     	ldr	x9, [sp, #0x30]
1000a4b78:     	madd	x8, x8, x20, x9
1000a4b7c:     	ldr	x9, [sp, #0x28]
1000a4b80:     	madd	x8, x8, x20, x9
1000a4b84:     	ldr	x9, [sp, #0x20]
1000a4b88:     	madd	x8, x8, x20, x9
1000a4b8c:     	madd	x8, x8, x20, x12
1000a4b90:     	madd	x8, x8, x20, x13
1000a4b94:     	madd	x8, x8, x20, x10
1000a4b98:     	mov	w9, #0x4309             ; =17161
1000a4b9c:     	madd	x9, x24, x9, x11
1000a4ba0:     	madd	x8, x8, x20, x9
1000a4ba4:     	add	x24, x8, #0x83
1000a4ba8:     	b	0x1000a4bb0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x484>
1000a4bac:     	mul	x24, x24, x20
1000a4bb0:     	add	x8, x25, x23
1000a4bb4:     	dup.2d	v0, x8
1000a4bb8:     	ldr	q1, [sp, #0x180]
1000a4bbc:     	add.2d	v1, v0, v1
1000a4bc0:     	stur	q1, [x27, #0x8]
1000a4bc4:     	add	x9, x8, #0x1f
1000a4bc8:     	ldr	q1, [sp, #0x170]
1000a4bcc:     	add.2d	v1, v0, v1
1000a4bd0:     	stur	q1, [x27, #0x18]
1000a4bd4:     	ldr	q1, [sp, #0x160]
1000a4bd8:     	add.2d	v1, v0, v1
1000a4bdc:     	stur	q1, [x27, #0x28]
1000a4be0:     	ldr	q1, [sp, #0x150]
1000a4be4:     	add.2d	v1, v0, v1
1000a4be8:     	stur	q1, [x27, #0x38]
1000a4bec:     	ldr	q1, [sp, #0x140]
1000a4bf0:     	add.2d	v1, v0, v1
1000a4bf4:     	stur	q1, [x27, #0x48]
1000a4bf8:     	ldr	q1, [sp, #0x130]
1000a4bfc:     	add.2d	v1, v0, v1
1000a4c00:     	stur	q1, [x27, #0x58]
1000a4c04:     	ldr	q1, [sp, #0x120]
1000a4c08:     	add.2d	v1, v0, v1
1000a4c0c:     	stur	q1, [x27, #0x68]
1000a4c10:     	ldr	q1, [sp, #0x110]
1000a4c14:     	add.2d	v1, v0, v1
1000a4c18:     	stur	q1, [x27, #0x78]
1000a4c1c:     	ldr	q1, [sp, #0x100]
1000a4c20:     	add.2d	v1, v0, v1
1000a4c24:     	stur	q1, [x27, #0x88]
1000a4c28:     	ldr	q1, [sp, #0xf0]
1000a4c2c:     	add.2d	v1, v0, v1
1000a4c30:     	stur	q1, [x27, #0x98]
1000a4c34:     	ldr	q1, [sp, #0xe0]
1000a4c38:     	add.2d	v1, v0, v1
1000a4c3c:     	stur	q1, [x27, #0xa8]
1000a4c40:     	ldr	q1, [sp, #0xd0]
1000a4c44:     	add.2d	v1, v0, v1
1000a4c48:     	stur	q1, [x27, #0xb8]
1000a4c4c:     	ldr	q1, [sp, #0xc0]
1000a4c50:     	add.2d	v1, v0, v1
1000a4c54:     	stur	q1, [x27, #0xc8]
1000a4c58:     	ldr	q1, [sp, #0xb0]
1000a4c5c:     	add.2d	v1, v0, v1
1000a4c60:     	stur	q1, [x27, #0xd8]
1000a4c64:     	ldr	q1, [sp, #0xa0]
1000a4c68:     	add.2d	v0, v0, v1
1000a4c6c:     	stur	q0, [x27, #0xe8]
1000a4c70:     	str	x8, [sp, #0x2a0]
1000a4c74:     	str	x9, [sp, #0x398]
1000a4c78:     	add	x0, sp, #0x190
1000a4c7c:     	add	x3, sp, #0x2a0
1000a4c80:     	add	x4, x19, #0x28
1000a4c84:     	mov	x1, x19
1000a4c88:     	bl	0x1000a83fc <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d>
1000a4c8c:     	ldr	w8, [sp, #0x190]
1000a4c90:     	cbnz	w8, 0x1000a484c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x120>
1000a4c94:     	mul	x24, x24, x20
1000a4c98:     	add	x23, x23, #0x1
1000a4c9c:     	cmp	x23, x26
1000a4ca0:     	b.ne	0x1000a4954 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x228>
1000a4ca4:     	ldp	x10, x9, [sp, #0x10]
1000a4ca8:     	str	x10, [x19, #0x48]
1000a4cac:     	add	x9, x9, #0x1
1000a4cb0:     	ldr	x8, [sp, #0x8]
1000a4cb4:     	cmp	x9, x8
1000a4cb8:     	b.eq	0x1000a4ce0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x5b4>
1000a4cbc:     	ldr	x26, [x19, #0x40]
1000a4cc0:     	add	x10, x10, #0x1
1000a4cc4:     	stp	x10, x9, [sp, #0x10]
1000a4cc8:     	cbnz	x26, 0x1000a483c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x110>
1000a4ccc:     	b	0x1000a4ca4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x578>
1000a4cd0:     	ldr	x8, [x19, #0x48]
1000a4cd4:     	ldr	x9, [sp, #0x8]
1000a4cd8:     	add	x8, x8, x9
1000a4cdc:     	str	x8, [x19, #0x48]
1000a4ce0:     	eor	x8, x24, x24, lsr #30
1000a4ce4:     	mov	x9, #0xe5b9             ; =58809
1000a4ce8:     	movk	x9, #0x1ce4, lsl #16
1000a4cec:     	movk	x9, #0x476d, lsl #32
1000a4cf0:     	movk	x9, #0xbf58, lsl #48
1000a4cf4:     	mul	x8, x8, x9
1000a4cf8:     	eor	x8, x8, x8, lsr #27
1000a4cfc:     	mov	x9, #0x11eb             ; =4587
1000a4d00:     	movk	x9, #0x1331, lsl #16
1000a4d04:     	movk	x9, #0x49bb, lsl #32
1000a4d08:     	movk	x9, #0x94d0, lsl #48
1000a4d0c:     	mul	x8, x8, x9
1000a4d10:     	eor	x0, x8, x8, lsr #31
1000a4d14:     	add	sp, sp, #0x3a0
1000a4d18:     	ldp	x29, x30, [sp, #0x50]
1000a4d1c:     	ldp	x20, x19, [sp, #0x40]
1000a4d20:     	ldp	x22, x21, [sp, #0x30]
1000a4d24:     	ldp	x24, x23, [sp, #0x20]
1000a4d28:     	ldp	x26, x25, [sp, #0x10]
1000a4d2c:     	ldp	x28, x27, [sp], #0x60
1000a4d30:     	ret

