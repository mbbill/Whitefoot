from pathlib import Path
import csv,json,hashlib,statistics,collections
D=Path(__file__).parent;T=D/'timing';m=json.loads((T/'metadata.json').read_text());assert len(m['stages'])==2 and all(x['exit']==0 and not x['timed_out'] for x in m['stages']);assert m['images_before']==m['images_after']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in m['images_after'].items():assert sha(Path(p))==h
V=['whitefoot-flat','whitefoot-chain','rust-hash-map','cpp-unordered-map','c-matched-flat'];rows=[];pins={};g={};positions=[]
for c in [0,1]:
 p=T/f'cohort-{c}.csv';rr=list(csv.DictReader(p.open()));assert len(rr)==400;pins[p.name]=sha(p)
 assert len({tuple(r[k] for k in ['variant','width','slots','operation','sample']) for r in rr})==400
 check={};pos=collections.Counter()
 for i,r in enumerate(rr):
  assert int(r['operations'])==4194304 and int(r['cohort'])==c and int(r['seed'])==101+int(r['sample'])
  k=tuple(r[x] for x in ['width','slots','operation','sample']);v=tuple(r[x] for x in ['seed','population','start_generation','rounds','operations','checksum','verify','cleanup'])
  if k in check:assert check[k]==v
  else:check[k]=v
  pos[r['width'],r['slots'],r['operation'],r['variant'],i%5]+=1
  g.setdefault((c,r['width'],int(r['slots']),r['operation'],r['variant']),[]).append(r)
 assert set(pos.values())=={2};positions.append(dict(cohort=c,each_variant_appears_twice_at_every_position=True));rows+=rr
assert len(g)==80 and all(len(x)==10 for x in g.values())
def st(rr):
 ns=sorted(int(r['elapsed_ns']) for r in rr);return dict(min=ns[0]/4194304,median=statistics.median(ns)/4194304,max=ns[-1]/4194304)
def rel(a,b):return 'LOWER' if a['max']<b['min'] else 'HIGHER' if a['min']>b['max'] else 'OVERLAP'
def spr(a,b):return max(a/b,b/a)-1
minimum=min(int(r['elapsed_ns']) for r in rows);cells=[];ranges=[];maxnative=(0,None)
for w in ['word8','wide256']:
 for slots in [64,4096]:
  for op in ['replace','churn']:
   item=dict(width=w,slots=slots,operation=op,cohorts=[])
   for c in [0,1]:
    stats={v:st(g[c,w,slots,op,v]) for v in V};wf=stats['whitefoot-flat'];cc=stats['c-matched-flat'];native=['rust-hash-map','cpp-unordered-map'];slow=max(native,key=lambda v:stats[v]['median'])
    item['cohorts'].append(dict(cohort=c,participants=stats,c_vs_wf=rel(cc,wf),c_wf_median_ratio=cc['median']/wf['median'],wf_vs_native={v:rel(wf,stats[v]) for v in native},c_vs_native={v:rel(cc,stats[v]) for v in native},slower_native_peer=slow))
   a,b=item['cohorts'];item['c_wf_ratio_spread']=spr(a['c_wf_median_ratio'],b['c_wf_median_ratio']);item['participant_cohort_median_spread']={v:spr(a['participants'][v]['median'],b['participants'][v]['median']) for v in V}
   direction=a['c_vs_wf'] if a['c_vs_wf']==b['c_vs_wf'] else 'INCONSISTENT'
   item['qualified_c_vs_wf_direction']=direction if direction in ['LOWER','HIGHER'] and item['c_wf_ratio_spread']<=.1 and minimum>=1000000 else 'UNRESOLVED'
   for v in ['rust-hash-map','cpp-unordered-map']:
    d=item['participant_cohort_median_spread'][v]
    if d>maxnative[0]:maxnative=(d,dict(variant=v,width=w,slots=slots,operation=op))
   cells.append(item)
result=dict(question='same-image matched C/WF attribution, not before-after adoption',raw_rows=len(rows),unique_keys=len({tuple(r[k] for k in ['cohort','variant','width','slots','operation','sample']) for r in rows}),groups=len(g),samples_per_group=10,balanced_positions=positions,full_content_oracles_equal=True,images_unchanged=True,min_interval_ns=minimum,min_interval_pass=minimum>=1000000,csv_sha256=pins,max_c_wf_ratio_spread=max(x['c_wf_ratio_spread'] for x in cells),max_native_cohort_spread=dict(spread=maxnative[0],**maxnative[1]),qualified_direction_counts=dict(collections.Counter(x['qualified_c_vs_wf_direction'] for x in cells)),cells=cells)
(T/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
lines=['width slots operation | C/WF median ratio c0 / c1 | full-range direction c0 / c1 | ratio spread | qualified direction']
allranges=['width slots operation variant | cohort0 median[min,max] ns | cohort1 median[min,max] ns | median spread']
for x in cells:
 co=x['cohorts'];lines.append(f'{x["width"]} {x["slots"]} {x["operation"]} | {co[0]["c_wf_median_ratio"]:.6f} / {co[1]["c_wf_median_ratio"]:.6f} | {co[0]["c_vs_wf"]} / {co[1]["c_vs_wf"]} | {x["c_wf_ratio_spread"]*100:.6f}% | {x["qualified_c_vs_wf_direction"]}')
 for v in V:
  bits=[]
  for c in co:
   s=c['participants'][v];bits.append(f'{s["median"]:.6f}[{s["min"]:.6f},{s["max"]:.6f}]')
  allranges.append(f'{x["width"]} {x["slots"]} {x["operation"]} {v} | '+ ' | '.join(bits)+f' | {x["participant_cohort_median_spread"][v]*100:.6f}%')
(T/'primary-table.txt').write_text('\n'.join(lines)+'\n');(T/'all-peer-ranges.txt').write_text('\n'.join(allranges)+'\n')
print('\n'.join(lines));print(json.dumps({k:v for k,v in result.items() if k!='cells'},indent=2))
