00000001000a4be8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027>:
1000a4be8:     	stp	x28, x27, [sp, #-0x60]!
1000a4bec:     	stp	x26, x25, [sp, #0x10]
1000a4bf0:     	stp	x24, x23, [sp, #0x20]
1000a4bf4:     	stp	x22, x21, [sp, #0x30]
1000a4bf8:     	stp	x20, x19, [sp, #0x40]
1000a4bfc:     	stp	x29, x30, [sp, #0x50]
1000a4c00:     	sub	sp, sp, #0x3a0
1000a4c04:     	ldr	x24, [x0, #0x38]
1000a4c08:     	str	x1, [sp, #0x8]
1000a4c0c:     	cbz	x1, 0x1000a5188 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x5a0>
1000a4c10:     	mov	x19, x0
1000a4c14:     	ldr	x26, [x0, #0x40]
1000a4c18:     	cbz	x26, 0x1000a5178 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x590>
1000a4c1c:     	mov	x21, x2
1000a4c20:     	str	xzr, [sp, #0x18]
1000a4c24:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x44c>
1000a4c28:     	ldr	q0, [x8, #0xb50]
1000a4c2c:     	str	q0, [sp, #0x180]
1000a4c30:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x44c>
1000a4c34:     	ldr	q0, [x8, #0x900]
1000a4c38:     	str	q0, [sp, #0x170]
1000a4c3c:     	add	x27, sp, #0x2a0
1000a4c40:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x44c>
1000a4c44:     	ldr	q0, [x8, #0x8f0]
1000a4c48:     	str	q0, [sp, #0x160]
1000a4c4c:     	mov	w28, #0x1               ; =1
1000a4c50:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x44c>
1000a4c54:     	ldr	q0, [x8, #0x920]
1000a4c58:     	str	q0, [sp, #0x150]
1000a4c5c:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x44c>
1000a4c60:     	ldr	q0, [x8, #0x910]
1000a4c64:     	str	q0, [sp, #0x140]
1000a4c68:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x44c>
1000a4c6c:     	ldr	q0, [x8, #0x940]
1000a4c70:     	str	q0, [sp, #0x130]
1000a4c74:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x44c>
1000a4c78:     	ldr	q0, [x8, #0x930]
1000a4c7c:     	str	q0, [sp, #0x120]
1000a4c80:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x44c>
1000a4c84:     	ldr	q0, [x8, #0x960]
1000a4c88:     	str	q0, [sp, #0x110]
1000a4c8c:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x44c>
1000a4c90:     	ldr	q0, [x8, #0x950]
1000a4c94:     	str	q0, [sp, #0x100]
1000a4c98:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x44c>
1000a4c9c:     	ldr	q0, [x8, #0x980]
1000a4ca0:     	str	q0, [sp, #0xf0]
1000a4ca4:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x44c>
1000a4ca8:     	ldr	q0, [x8, #0x970]
1000a4cac:     	str	q0, [sp, #0xe0]
1000a4cb0:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x44c>
1000a4cb4:     	ldr	q0, [x8, #0x9a0]
1000a4cb8:     	str	q0, [sp, #0xd0]
1000a4cbc:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x44c>
1000a4cc0:     	ldr	q0, [x8, #0x990]
1000a4cc4:     	str	q0, [sp, #0xc0]
1000a4cc8:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x44c>
1000a4ccc:     	ldr	q0, [x8, #0x9c0]
1000a4cd0:     	str	q0, [sp, #0xb0]
1000a4cd4:     	adrp	x8, 0x1000cc000 <__RNvNtNtNtNtNtCs8Mbv00yxnRz_4core3num3imp7flt2dec8strategy6dragon9POW5TO256+0x44c>
1000a4cd8:     	ldr	q0, [x8, #0x9b0]
1000a4cdc:     	str	q0, [sp, #0xa0]
1000a4ce0:     	mov	w20, #0x83              ; =131
1000a4ce4:     	mov	w22, #0x110             ; =272
1000a4ce8:     	ldr	x10, [x19, #0x48]
1000a4cec:     	add	x10, x10, #0x1
1000a4cf0:     	str	x10, [sp, #0x10]
1000a4cf4:     	cbz	x26, 0x1000a514c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x564>
1000a4cf8:     	mov	x23, #0x0               ; =0
1000a4cfc:     	ldr	x8, [x19, #0x38]
1000a4d00:     	madd	x25, x10, x26, x8
1000a4d04:     	b	0x1000a4e10 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x228>
1000a4d08:     	ldrb	w8, [sp, #0x194]
1000a4d0c:     	tst	w8, #0x1
1000a4d10:     	ldp	x9, x8, [sp, #0x198]
1000a4d14:     	madd	x8, x9, x20, x8
1000a4d18:     	ldp	x10, x9, [sp, #0x1a8]
1000a4d1c:     	madd	x8, x8, x20, x10
1000a4d20:     	madd	x8, x8, x20, x9
1000a4d24:     	ldp	x10, x9, [sp, #0x1b8]
1000a4d28:     	madd	x8, x8, x20, x10
1000a4d2c:     	madd	x8, x8, x20, x9
1000a4d30:     	ldp	x10, x9, [sp, #0x1c8]
1000a4d34:     	madd	x8, x8, x20, x10
1000a4d38:     	madd	x8, x8, x20, x9
1000a4d3c:     	ldp	x10, x9, [sp, #0x1d8]
1000a4d40:     	madd	x8, x8, x20, x10
1000a4d44:     	madd	x8, x8, x20, x9
1000a4d48:     	ldp	x10, x9, [sp, #0x1e8]
1000a4d4c:     	madd	x8, x8, x20, x10
1000a4d50:     	madd	x8, x8, x20, x9
1000a4d54:     	ldp	x10, x9, [sp, #0x1f8]
1000a4d58:     	madd	x8, x8, x20, x10
1000a4d5c:     	madd	x8, x8, x20, x9
1000a4d60:     	ldr	x9, [sp, #0x208]
1000a4d64:     	madd	x8, x8, x20, x9
1000a4d68:     	ldr	x9, [sp, #0x210]
1000a4d6c:     	madd	x8, x8, x20, x9
1000a4d70:     	ldr	x9, [sp, #0x218]
1000a4d74:     	madd	x8, x8, x20, x9
1000a4d78:     	ldr	x9, [sp, #0x220]
1000a4d7c:     	madd	x8, x8, x20, x9
1000a4d80:     	ldr	x9, [sp, #0x228]
1000a4d84:     	madd	x8, x8, x20, x9
1000a4d88:     	ldr	x9, [sp, #0x230]
1000a4d8c:     	madd	x8, x8, x20, x9
1000a4d90:     	ldr	x9, [sp, #0x238]
1000a4d94:     	madd	x8, x8, x20, x9
1000a4d98:     	ldr	x9, [sp, #0x240]
1000a4d9c:     	madd	x8, x8, x20, x9
1000a4da0:     	ldr	x9, [sp, #0x248]
1000a4da4:     	madd	x8, x8, x20, x9
1000a4da8:     	ldr	x9, [sp, #0x250]
1000a4dac:     	madd	x8, x8, x20, x9
1000a4db0:     	ldr	x9, [sp, #0x258]
1000a4db4:     	madd	x8, x8, x20, x9
1000a4db8:     	ldr	x9, [sp, #0x260]
1000a4dbc:     	madd	x8, x8, x20, x9
1000a4dc0:     	ldr	x9, [sp, #0x268]
1000a4dc4:     	madd	x8, x8, x20, x9
1000a4dc8:     	ldr	x9, [sp, #0x270]
1000a4dcc:     	madd	x8, x8, x20, x9
1000a4dd0:     	ldr	x9, [sp, #0x278]
1000a4dd4:     	madd	x8, x8, x20, x9
1000a4dd8:     	ldr	x9, [sp, #0x280]
1000a4ddc:     	madd	x8, x8, x20, x9
1000a4de0:     	ldr	x9, [sp, #0x288]
1000a4de4:     	add	x9, x9, x24
1000a4de8:     	ldr	x10, [sp, #0x290]
1000a4dec:     	madd	x8, x8, x20, x9
1000a4df0:     	cinc	x9, x28, ne
1000a4df4:     	add	x9, x9, x10
1000a4df8:     	madd	x8, x8, x20, x9
1000a4dfc:     	ldr	x9, [sp, #0x298]
1000a4e00:     	madd	x24, x8, x20, x9
1000a4e04:     	add	x23, x23, #0x1
1000a4e08:     	cmp	x23, x26
1000a4e0c:     	b.eq	0x1000a514c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x564>
1000a4e10:     	orr	x2, x28, x23, lsl #1
1000a4e14:     	cbz	x21, 0x1000a5058 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x470>
1000a4e18:     	ldr	x8, [x19, #0x18]
1000a4e1c:     	cbz	x8, 0x1000a5054 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x46c>
1000a4e20:     	ldrb	w9, [x19, #0x30]
1000a4e24:     	tbz	w9, #0x0, 0x1000a4e38 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x250>
1000a4e28:     	mov	x9, #0x0                ; =0
1000a4e2c:     	ldr	x10, [x19]
1000a4e30:     	cbnz	x10, 0x1000a4e7c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x294>
1000a4e34:     	b	0x1000a5054 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x46c>
1000a4e38:     	ldr	x9, [x19, #0x28]
1000a4e3c:     	eor	x9, x9, x2
1000a4e40:     	eor	x9, x9, x9, lsr #30
1000a4e44:     	mov	x10, #0xe5b9            ; =58809
1000a4e48:     	movk	x10, #0x1ce4, lsl #16
1000a4e4c:     	movk	x10, #0x476d, lsl #32
1000a4e50:     	movk	x10, #0xbf58, lsl #48
1000a4e54:     	mul	x9, x9, x10
1000a4e58:     	eor	x9, x9, x9, lsr #27
1000a4e5c:     	mov	x10, #0x11eb            ; =4587
1000a4e60:     	movk	x10, #0x1331, lsl #16
1000a4e64:     	movk	x10, #0x49bb, lsl #32
1000a4e68:     	movk	x10, #0x94d0, lsl #48
1000a4e6c:     	mul	x9, x9, x10
1000a4e70:     	eor	x9, x9, x9, lsr #31
1000a4e74:     	ldr	x10, [x19]
1000a4e78:     	cbz	x10, 0x1000a5054 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x46c>
1000a4e7c:     	udiv	x11, x9, x10
1000a4e80:     	msub	x11, x11, x10, x9
1000a4e84:     	ldr	x12, [x19, #0x10]
1000a4e88:     	mov	x13, x10
1000a4e8c:     	b	0x1000a4ea4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2bc>
1000a4e90:     	add	x9, x11, #0x1
1000a4e94:     	cmp	x9, x10
1000a4e98:     	csinc	x11, xzr, x11, hs
1000a4e9c:     	subs	x13, x13, #0x1
1000a4ea0:     	b.eq	0x1000a5054 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x46c>
1000a4ea4:     	madd	x9, x11, x22, x12
1000a4ea8:     	ldr	w14, [x9]
1000a4eac:     	cmp	w14, #0x1
1000a4eb0:     	b.eq	0x1000a4e90 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2a8>
1000a4eb4:     	cmp	w14, #0x2
1000a4eb8:     	b.ne	0x1000a5054 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x46c>
1000a4ebc:     	ldr	x14, [x9, #0x8]
1000a4ec0:     	cmp	x14, x2
1000a4ec4:     	b.ne	0x1000a4e90 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x2a8>
1000a4ec8:     	ldp	x11, x10, [x9, #0x10]
1000a4ecc:     	stp	x10, x11, [sp, #0x90]
1000a4ed0:     	ldp	x11, x10, [x9, #0x20]
1000a4ed4:     	stp	x10, x11, [sp, #0x80]
1000a4ed8:     	ldp	x14, x15, [x9, #0x30]
1000a4edc:     	ldp	x16, x17, [x9, #0x40]
1000a4ee0:     	ldp	x0, x1, [x9, #0x50]
1000a4ee4:     	ldp	x3, x4, [x9, #0x60]
1000a4ee8:     	ldp	x5, x6, [x9, #0x70]
1000a4eec:     	ldp	x7, x30, [x9, #0x80]
1000a4ef0:     	ldp	x11, x10, [x9, #0x90]
1000a4ef4:     	stp	x10, x11, [sp, #0x70]
1000a4ef8:     	ldp	x11, x10, [x9, #0xa0]
1000a4efc:     	stp	x10, x11, [sp, #0x60]
1000a4f00:     	ldp	x11, x10, [x9, #0xb0]
1000a4f04:     	stp	x10, x11, [sp, #0x50]
1000a4f08:     	ldp	x11, x10, [x9, #0xc0]
1000a4f0c:     	stp	x10, x11, [sp, #0x40]
1000a4f10:     	ldp	x11, x10, [x9, #0xd0]
1000a4f14:     	stp	x10, x11, [sp, #0x30]
1000a4f18:     	ldp	x11, x10, [x9, #0xe0]
1000a4f1c:     	stp	x10, x11, [sp, #0x20]
1000a4f20:     	str	w28, [x9]
1000a4f24:     	movi.2d	v0, #0000000000000000
1000a4f28:     	stur	q0, [x9, #0x8]
1000a4f2c:     	stur	q0, [x9, #0x18]
1000a4f30:     	stur	q0, [x9, #0x28]
1000a4f34:     	stur	q0, [x9, #0x38]
1000a4f38:     	stur	q0, [x9, #0x48]
1000a4f3c:     	stur	q0, [x9, #0x58]
1000a4f40:     	stur	q0, [x9, #0x68]
1000a4f44:     	stur	q0, [x9, #0x78]
1000a4f48:     	stur	q0, [x9, #0x88]
1000a4f4c:     	stur	q0, [x9, #0x98]
1000a4f50:     	stur	q0, [x9, #0xa8]
1000a4f54:     	stur	q0, [x9, #0xb8]
1000a4f58:     	stur	q0, [x9, #0xc8]
1000a4f5c:     	stur	q0, [x9, #0xd8]
1000a4f60:     	ldp	x12, x13, [x9, #0xf0]
1000a4f64:     	stur	q0, [x9, #0xe8]
1000a4f68:     	ldp	x10, x11, [x9, #0x100]
1000a4f6c:     	stur	q0, [x9, #0xf8]
1000a4f70:     	str	xzr, [x9, #0x108]
1000a4f74:     	sub	x8, x8, #0x1
1000a4f78:     	ldr	x9, [x19, #0x20]
1000a4f7c:     	adds	x9, x9, #0x1
1000a4f80:     	csinv	x9, x9, xzr, lo
1000a4f84:     	stp	x8, x9, [x19, #0x18]
1000a4f88:     	ldp	x9, x8, [sp, #0x90]
1000a4f8c:     	madd	x8, x2, x20, x8
1000a4f90:     	madd	x8, x8, x20, x9
1000a4f94:     	ldr	x9, [sp, #0x88]
1000a4f98:     	madd	x8, x8, x20, x9
1000a4f9c:     	ldr	x9, [sp, #0x80]
1000a4fa0:     	madd	x8, x8, x20, x9
1000a4fa4:     	madd	x8, x8, x20, x14
1000a4fa8:     	madd	x8, x8, x20, x15
1000a4fac:     	madd	x8, x8, x20, x16
1000a4fb0:     	madd	x8, x8, x20, x17
1000a4fb4:     	madd	x8, x8, x20, x0
1000a4fb8:     	madd	x8, x8, x20, x1
1000a4fbc:     	madd	x8, x8, x20, x3
1000a4fc0:     	madd	x8, x8, x20, x4
1000a4fc4:     	madd	x8, x8, x20, x5
1000a4fc8:     	madd	x8, x8, x20, x6
1000a4fcc:     	madd	x8, x8, x20, x7
1000a4fd0:     	madd	x8, x8, x20, x30
1000a4fd4:     	ldr	x9, [sp, #0x78]
1000a4fd8:     	madd	x8, x8, x20, x9
1000a4fdc:     	ldr	x9, [sp, #0x70]
1000a4fe0:     	madd	x8, x8, x20, x9
1000a4fe4:     	ldr	x9, [sp, #0x68]
1000a4fe8:     	madd	x8, x8, x20, x9
1000a4fec:     	ldr	x9, [sp, #0x60]
1000a4ff0:     	madd	x8, x8, x20, x9
1000a4ff4:     	ldr	x9, [sp, #0x58]
1000a4ff8:     	madd	x8, x8, x20, x9
1000a4ffc:     	ldr	x9, [sp, #0x50]
1000a5000:     	madd	x8, x8, x20, x9
1000a5004:     	ldr	x9, [sp, #0x48]
1000a5008:     	madd	x8, x8, x20, x9
1000a500c:     	ldr	x9, [sp, #0x40]
1000a5010:     	madd	x8, x8, x20, x9
1000a5014:     	ldr	x9, [sp, #0x38]
1000a5018:     	madd	x8, x8, x20, x9
1000a501c:     	ldr	x9, [sp, #0x30]
1000a5020:     	madd	x8, x8, x20, x9
1000a5024:     	ldr	x9, [sp, #0x28]
1000a5028:     	madd	x8, x8, x20, x9
1000a502c:     	ldr	x9, [sp, #0x20]
1000a5030:     	madd	x8, x8, x20, x9
1000a5034:     	madd	x8, x8, x20, x12
1000a5038:     	madd	x8, x8, x20, x13
1000a503c:     	madd	x8, x8, x20, x10
1000a5040:     	mov	w9, #0x4309             ; =17161
1000a5044:     	madd	x9, x24, x9, x11
1000a5048:     	madd	x8, x8, x20, x9
1000a504c:     	add	x24, x8, #0x83
1000a5050:     	b	0x1000a5058 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x470>
1000a5054:     	mul	x24, x24, x20
1000a5058:     	add	x8, x25, x23
1000a505c:     	dup.2d	v0, x8
1000a5060:     	ldr	q1, [sp, #0x180]
1000a5064:     	add.2d	v1, v0, v1
1000a5068:     	stur	q1, [x27, #0x8]
1000a506c:     	add	x9, x8, #0x1f
1000a5070:     	ldr	q1, [sp, #0x170]
1000a5074:     	add.2d	v1, v0, v1
1000a5078:     	stur	q1, [x27, #0x18]
1000a507c:     	ldr	q1, [sp, #0x160]
1000a5080:     	add.2d	v1, v0, v1
1000a5084:     	stur	q1, [x27, #0x28]
1000a5088:     	ldr	q1, [sp, #0x150]
1000a508c:     	add.2d	v1, v0, v1
1000a5090:     	stur	q1, [x27, #0x38]
1000a5094:     	ldr	q1, [sp, #0x140]
1000a5098:     	add.2d	v1, v0, v1
1000a509c:     	stur	q1, [x27, #0x48]
1000a50a0:     	ldr	q1, [sp, #0x130]
1000a50a4:     	add.2d	v1, v0, v1
1000a50a8:     	stur	q1, [x27, #0x58]
1000a50ac:     	ldr	q1, [sp, #0x120]
1000a50b0:     	add.2d	v1, v0, v1
1000a50b4:     	stur	q1, [x27, #0x68]
1000a50b8:     	ldr	q1, [sp, #0x110]
1000a50bc:     	add.2d	v1, v0, v1
1000a50c0:     	stur	q1, [x27, #0x78]
1000a50c4:     	ldr	q1, [sp, #0x100]
1000a50c8:     	add.2d	v1, v0, v1
1000a50cc:     	stur	q1, [x27, #0x88]
1000a50d0:     	ldr	q1, [sp, #0xf0]
1000a50d4:     	add.2d	v1, v0, v1
1000a50d8:     	stur	q1, [x27, #0x98]
1000a50dc:     	ldr	q1, [sp, #0xe0]
1000a50e0:     	add.2d	v1, v0, v1
1000a50e4:     	stur	q1, [x27, #0xa8]
1000a50e8:     	ldr	q1, [sp, #0xd0]
1000a50ec:     	add.2d	v1, v0, v1
1000a50f0:     	stur	q1, [x27, #0xb8]
1000a50f4:     	ldr	q1, [sp, #0xc0]
1000a50f8:     	add.2d	v1, v0, v1
1000a50fc:     	stur	q1, [x27, #0xc8]
1000a5100:     	ldr	q1, [sp, #0xb0]
1000a5104:     	add.2d	v1, v0, v1
1000a5108:     	stur	q1, [x27, #0xd8]
1000a510c:     	ldr	q1, [sp, #0xa0]
1000a5110:     	add.2d	v0, v0, v1
1000a5114:     	stur	q0, [x27, #0xe8]
1000a5118:     	str	x8, [sp, #0x2a0]
1000a511c:     	str	x9, [sp, #0x398]
1000a5120:     	add	x0, sp, #0x190
1000a5124:     	add	x3, sp, #0x2a0
1000a5128:     	add	x4, x19, #0x28
1000a512c:     	mov	x1, x19
1000a5130:     	bl	0x1000ac468 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d.disjoint_floor>
1000a5134:     	ldr	w8, [sp, #0x190]
1000a5138:     	cbnz	w8, 0x1000a4d08 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x120>
1000a513c:     	mul	x24, x24, x20
1000a5140:     	add	x23, x23, #0x1
1000a5144:     	cmp	x23, x26
1000a5148:     	b.ne	0x1000a4e10 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x228>
1000a514c:     	ldp	x10, x9, [sp, #0x10]
1000a5150:     	str	x10, [x19, #0x48]
1000a5154:     	add	x9, x9, #0x1
1000a5158:     	ldr	x8, [sp, #0x8]
1000a515c:     	cmp	x9, x8
1000a5160:     	b.eq	0x1000a5188 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x5a0>
1000a5164:     	ldr	x26, [x19, #0x40]
1000a5168:     	add	x10, x10, #0x1
1000a516c:     	stp	x10, x9, [sp, #0x10]
1000a5170:     	cbnz	x26, 0x1000a4cf8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x110>
1000a5174:     	b	0x1000a514c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x564>
1000a5178:     	ldr	x8, [x19, #0x48]
1000a517c:     	ldr	x9, [sp, #0x8]
1000a5180:     	add	x8, x8, x9
1000a5184:     	str	x8, [x19, #0x48]
1000a5188:     	eor	x8, x24, x24, lsr #30
1000a518c:     	mov	x9, #0xe5b9             ; =58809
1000a5190:     	movk	x9, #0x1ce4, lsl #16
1000a5194:     	movk	x9, #0x476d, lsl #32
1000a5198:     	movk	x9, #0xbf58, lsl #48
1000a519c:     	mul	x8, x8, x9
1000a51a0:     	eor	x8, x8, x8, lsr #27
1000a51a4:     	mov	x9, #0x11eb             ; =4587
1000a51a8:     	movk	x9, #0x1331, lsl #16
1000a51ac:     	movk	x9, #0x49bb, lsl #32
1000a51b0:     	movk	x9, #0x94d0, lsl #48
1000a51b4:     	mul	x8, x8, x9
1000a51b8:     	eor	x0, x8, x8, lsr #31
1000a51bc:     	add	sp, sp, #0x3a0
1000a51c0:     	ldp	x29, x30, [sp, #0x50]
1000a51c4:     	ldp	x20, x19, [sp, #0x40]
1000a51c8:     	ldp	x22, x21, [sp, #0x30]
1000a51cc:     	ldp	x24, x23, [sp, #0x20]
1000a51d0:     	ldp	x26, x25, [sp, #0x10]
1000a51d4:     	ldp	x28, x27, [sp], #0x60
1000a51d8:     	ret

