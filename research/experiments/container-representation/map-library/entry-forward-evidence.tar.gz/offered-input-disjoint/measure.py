"""One authorized fixed panel; scratch attribution instrument, no retries."""
import pathlib, hashlib, subprocess, time, json, csv, os
assert os.environ.get('WHITEFOOT_CHECK_OWNER'), 'Use the repository host guard'
base = pathlib.Path('/private/tmp/whitefoot-map-replacement-input-disjoint')
control = pathlib.Path('/private/tmp/whitefoot-map-replacement-disjoint/candidate-timed')
images = {'control': control, 'candidate': base / 'candidate-timed'}
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pins = json.loads((base / 'timing-pins.json').read_text())
for path, digest in pins.items():
    assert sha(pathlib.Path(path)) == digest, path
out = base / 'timing'
out.mkdir(exist_ok=False)
meta = {'criterion_sha256': sha(base / 'timing-criterion.txt'), 'images_before': {str(p):sha(p) for p in images.values()}, 'work':1048576, 'samples':9, 'order':['control0','candidate0','candidate1','control1'], 'stages':[]}
for arm, cohort in [('control',0),('candidate',0),('candidate',1),('control',1)]:
    label = arm + '-cohort-' + str(cohort)
    args = [str(images[arm]), 'measure', str(cohort), '1048576']
    start = time.monotonic()
    print('START', label, flush=True)
    with (out / (label + '.csv')).open('w') as stdout, (out / (label + '.stderr')).open('w') as stderr:
        try:
            result = subprocess.run(args, stdout=stdout, stderr=stderr, timeout=180)
            code = result.returncode
        except subprocess.TimeoutExpired:
            code = None
    meta['stages'].append({'label':label,'argv':args,'exit':code,'seconds':time.monotonic()-start})
    (out / 'metadata.json').write_text(json.dumps(meta, indent=2) + '\n')
    print('END', label, code, flush=True)
    assert code == 0
    rows = list(csv.DictReader((out / (label + '.csv')).open()))
    assert len(rows) == 288
meta['images_after'] = {str(p):sha(p) for p in images.values()}
assert meta['images_after'] == meta['images_before']
(out / 'metadata.json').write_text(json.dumps(meta, indent=2) + '\n')
print('Complete: all1152 raw rows retained; no verdict inferred by runner', flush=True)
