import pathlib,subprocess,json,hashlib,time,shutil
root=pathlib.Path.cwd();v=root/'research/experiments/container-representation/map-library';d=v/'.build/lookup-api/mutation-screen';p=v/'.build/lookup-chain-probe';out=pathlib.Path('/private/tmp/whitefoot-entry-forward-final-proof');out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cli=root/'compiler/target/gate/whitefootc';shutil.copy2(cli,out/'whitefootc');cli=out/'whitefootc'
meta={'compiler_sha256':sha(cli),'source_pins':{str(root/f):sha(root/f) for f in ['compiler/src/backend/storage.rs','compiler/src/backend/emitter.rs','compiler/src/backend/emitter/places.rs','compiler/src/backend/tests/owned_places.rs']},'stages':[],'comparisons':[]}
def run(label,argv):
 start=time.monotonic();r=subprocess.run(list(map(str,argv)),capture_output=True,text=True);meta['stages'].append(dict(label=label,argv=list(map(str,argv)),exit=r.returncode,seconds=time.monotonic()-start,stdout=r.stdout,stderr=r.stderr));(out/'metadata.json').write_text(json.dumps(meta,indent=2));print(label,r.returncode,flush=True);assert r.returncode==0
for label,source,previous in [('mutation',p/'mutation-complete.wf',d/'entry-forward.raw.ll'),('whole-map',v/'map-library.wf',pathlib.Path('/private/tmp/whitefoot-entry-forward-whole-map-run/candidate/map.raw.ll'))]:
 raw=out/(label+'.raw.ll');run(label+'-emit',[cli,'--emit-llvm',source,'-o',raw]);same=raw.read_bytes()==previous.read_bytes();meta['comparisons'].append(dict(label=label+'-raw',same=same,sha256=sha(raw),previous=str(previous)));assert same,(label,'raw changed; timing must be repeated')
 if label=='mutation':
  obj=out/'mutation.o';run('mutation-native',['/usr/bin/clang','-O3','-Wno-override-module','-x','ir','-c',raw,'-o',obj]);old=d/'entry-forward.o';same=obj.read_bytes()==old.read_bytes();meta['comparisons'].append(dict(label='mutation-object',same=same,sha256=sha(obj),previous=str(old)));assert same
 else:
  for mode in ['timed','account']:
   text=raw.read_text().replace('@main(', '@wf_fixture_main(')
   if mode=='account':text=text.replace('@malloc(', '@wf_cost_allocate(').replace('@free(', '@wf_cost_release(')
   ir=out/('whole-map-'+mode+'.ll');ir.write_text(text);obj=ir.with_suffix('.o');run('whole-map-'+mode+'-native',['clang','-O3','-Wno-override-module','-c',ir,'-o',obj]);old=pathlib.Path('/private/tmp/whitefoot-entry-forward-whole-map-run/candidate')/('wf-'+mode+'.o');same=obj.read_bytes()==old.read_bytes();meta['comparisons'].append(dict(label='whole-map-'+mode+'-object',same=same,sha256=sha(obj),previous=str(old)));assert same
(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');print('All emitted modules and native objects match the measured candidate byte-for-byte.',flush=True)
