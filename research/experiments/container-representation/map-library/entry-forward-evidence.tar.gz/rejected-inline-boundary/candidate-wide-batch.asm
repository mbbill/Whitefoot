00000001000a4cd0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027>:
1000a4cd0:     	sub	sp, sp, #0x1c0
1000a4cd4:     	stp	x28, x27, [sp, #0x160]
1000a4cd8:     	stp	x26, x25, [sp, #0x170]
1000a4cdc:     	stp	x24, x23, [sp, #0x180]
1000a4ce0:     	stp	x22, x21, [sp, #0x190]
1000a4ce4:     	stp	x20, x19, [sp, #0x1a0]
1000a4ce8:     	stp	x29, x30, [sp, #0x1b0]
1000a4cec:     	str	x2, [sp, #0xa8]
1000a4cf0:     	ldr	x14, [x0, #0x38]
1000a4cf4:     	str	x1, [sp, #0x10]
1000a4cf8:     	cbz	x1, 0x1000a5564 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x894>
1000a4cfc:     	ldp	x8, x10, [x0, #0x40]
1000a4d00:     	cbz	x8, 0x1000a5558 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x888>
1000a4d04:     	mov	x11, #0x0               ; =0
1000a4d08:     	ldp	x8, x9, [x0, #0x18]
1000a4d0c:     	str	x9, [sp, #0x30]
1000a4d10:     	stp	x0, x8, [sp, #0xc0]
1000a4d14:     	ldp	x8, x12, [x0, #0x38]
1000a4d18:     	str	x8, [sp, #0x8]
1000a4d1c:     	mov	w3, #0x110              ; =272
1000a4d20:     	ldr	x8, [x0, #0x28]
1000a4d24:     	stp	x8, x12, [sp, #0x98]
1000a4d28:     	mov	w6, #0x83               ; =131
1000a4d2c:     	movi.2d	v0, #0000000000000000
1000a4d30:     	ldrb	w8, [x0, #0x30]
1000a4d34:     	str	w8, [sp, #0xbc]
1000a4d38:     	b	0x1000a4d5c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x8c>
1000a4d3c:     	mov	x1, x13
1000a4d40:     	ldp	x11, x10, [sp, #0x18]
1000a4d44:     	str	x10, [x0, #0x48]
1000a4d48:     	add	x11, x11, #0x1
1000a4d4c:     	mov	x13, x1
1000a4d50:     	ldr	x8, [sp, #0x10]
1000a4d54:     	cmp	x11, x8
1000a4d58:     	b.eq	0x1000a5564 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x894>
1000a4d5c:     	add	x10, x10, #0x1
1000a4d60:     	stp	x11, x10, [sp, #0x18]
1000a4d64:     	cbz	x12, 0x1000a4d3c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x6c>
1000a4d68:     	mov	x21, #0x0               ; =0
1000a4d6c:     	ldr	x8, [sp, #0x8]
1000a4d70:     	madd	x8, x10, x12, x8
1000a4d74:     	str	x8, [sp, #0xb0]
1000a4d78:     	b	0x1000a4ebc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x1ec>
1000a4d7c:     	mov	x5, x0
1000a4d80:     	mov	x20, x27
1000a4d84:     	mov	x13, x26
1000a4d88:     	mov	x10, x28
1000a4d8c:     	mov	x19, x24
1000a4d90:     	mov	x25, x7
1000a4d94:     	mov	x23, x16
1000a4d98:     	mov	x26, x11
1000a4d9c:     	mov	x22, x30
1000a4da0:     	mov	x27, x9
1000a4da4:     	stp	x17, x8, [sp, #0x148]
1000a4da8:     	stp	x2, x14, [sp, #0x138]
1000a4dac:     	ldp	x9, x11, [sp, #0x110]
1000a4db0:     	stp	x9, x15, [sp, #0x128]
1000a4db4:     	ldp	x9, x8, [sp, #0x100]
1000a4db8:     	stp	x9, x11, [sp, #0x118]
1000a4dbc:     	str	x8, [sp, #0x110]
1000a4dc0:     	ldp	x9, x8, [sp, #0x38]
1000a4dc4:     	stp	x8, x9, [sp, #0x100]
1000a4dc8:     	ldp	x17, x15, [sp, #0x48]
1000a4dcc:     	ldp	x14, x2, [sp, #0x58]
1000a4dd0:     	ldp	x28, x30, [sp, #0x68]
1000a4dd4:     	ldp	x7, x16, [sp, #0x78]
1000a4dd8:     	ldp	x11, x24, [sp, #0x88]
1000a4ddc:     	ldr	x0, [sp, #0xc0]
1000a4de0:     	madd	x8, x24, x6, x11
1000a4de4:     	madd	x8, x8, x6, x16
1000a4de8:     	madd	x8, x8, x6, x7
1000a4dec:     	ldrb	w9, [sp, #0x15c]
1000a4df0:     	tst	w9, #0x1
1000a4df4:     	madd	x8, x8, x6, x30
1000a4df8:     	mov	w9, #0x1                ; =1
1000a4dfc:     	cinc	x9, x9, ne
1000a4e00:     	madd	x8, x8, x6, x28
1000a4e04:     	madd	x8, x8, x6, x2
1000a4e08:     	madd	x8, x8, x6, x14
1000a4e0c:     	madd	x8, x8, x6, x15
1000a4e10:     	madd	x8, x8, x6, x17
1000a4e14:     	ldr	x11, [sp, #0x100]
1000a4e18:     	madd	x8, x8, x6, x11
1000a4e1c:     	ldr	x11, [sp, #0x108]
1000a4e20:     	madd	x8, x8, x6, x11
1000a4e24:     	ldr	x11, [sp, #0x110]
1000a4e28:     	madd	x8, x8, x6, x11
1000a4e2c:     	ldr	x11, [sp, #0x118]
1000a4e30:     	madd	x8, x8, x6, x11
1000a4e34:     	ldr	x11, [sp, #0x120]
1000a4e38:     	madd	x8, x8, x6, x11
1000a4e3c:     	ldr	x11, [sp, #0x128]
1000a4e40:     	madd	x8, x8, x6, x11
1000a4e44:     	ldr	x11, [sp, #0x130]
1000a4e48:     	madd	x8, x8, x6, x11
1000a4e4c:     	ldr	x11, [sp, #0x138]
1000a4e50:     	madd	x8, x8, x6, x11
1000a4e54:     	ldr	x11, [sp, #0x140]
1000a4e58:     	madd	x8, x8, x6, x11
1000a4e5c:     	ldr	x11, [sp, #0x148]
1000a4e60:     	madd	x8, x8, x6, x11
1000a4e64:     	madd	x8, x8, x6, x12
1000a4e68:     	madd	x8, x8, x6, x4
1000a4e6c:     	ldr	x11, [sp, #0x150]
1000a4e70:     	madd	x8, x8, x6, x11
1000a4e74:     	madd	x8, x8, x6, x27
1000a4e78:     	madd	x8, x8, x6, x22
1000a4e7c:     	madd	x8, x8, x6, x26
1000a4e80:     	madd	x8, x8, x6, x23
1000a4e84:     	madd	x8, x8, x6, x25
1000a4e88:     	madd	x8, x8, x6, x19
1000a4e8c:     	madd	x8, x8, x6, x10
1000a4e90:     	ldr	x10, [sp, #0xd8]
1000a4e94:     	add	x10, x13, x10
1000a4e98:     	madd	x8, x8, x6, x10
1000a4e9c:     	add	x9, x9, x20
1000a4ea0:     	madd	x8, x8, x6, x9
1000a4ea4:     	madd	x14, x8, x6, x5
1000a4ea8:     	add	x21, x21, #0x1
1000a4eac:     	mov	x13, x1
1000a4eb0:     	ldr	x12, [sp, #0xa0]
1000a4eb4:     	cmp	x21, x12
1000a4eb8:     	b.eq	0x1000a4d40 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x70>
1000a4ebc:     	str	w13, [sp, #0xd4]
1000a4ec0:     	mov	w8, #0x1                ; =1
1000a4ec4:     	orr	x24, x8, x21, lsl #1
1000a4ec8:     	ldr	x8, [sp, #0xa8]
1000a4ecc:     	cbz	x8, 0x1000a50e8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x418>
1000a4ed0:     	ldr	x8, [sp, #0xc8]
1000a4ed4:     	cbz	x8, 0x1000a50fc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x42c>
1000a4ed8:     	ldr	w8, [sp, #0xbc]
1000a4edc:     	tbz	w8, #0x0, 0x1000a4ef0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x220>
1000a4ee0:     	mov	x8, #0x0                ; =0
1000a4ee4:     	ldr	x9, [x0]
1000a4ee8:     	cbnz	x9, 0x1000a4f34 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x264>
1000a4eec:     	b	0x1000a50fc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x42c>
1000a4ef0:     	ldr	x8, [sp, #0x98]
1000a4ef4:     	eor	x8, x8, x24
1000a4ef8:     	eor	x8, x8, x8, lsr #30
1000a4efc:     	mov	x9, #0xe5b9             ; =58809
1000a4f00:     	movk	x9, #0x1ce4, lsl #16
1000a4f04:     	movk	x9, #0x476d, lsl #32
1000a4f08:     	movk	x9, #0xbf58, lsl #48
1000a4f0c:     	mul	x8, x8, x9
1000a4f10:     	eor	x8, x8, x8, lsr #27
1000a4f14:     	mov	x9, #0x11eb             ; =4587
1000a4f18:     	movk	x9, #0x1331, lsl #16
1000a4f1c:     	movk	x9, #0x49bb, lsl #32
1000a4f20:     	movk	x9, #0x94d0, lsl #48
1000a4f24:     	mul	x8, x8, x9
1000a4f28:     	eor	x8, x8, x8, lsr #31
1000a4f2c:     	ldr	x9, [x0]
1000a4f30:     	cbz	x9, 0x1000a50fc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x42c>
1000a4f34:     	udiv	x10, x8, x9
1000a4f38:     	msub	x10, x10, x9, x8
1000a4f3c:     	ldr	x11, [x0, #0x10]
1000a4f40:     	mov	x12, x9
1000a4f44:     	b	0x1000a4f5c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x28c>
1000a4f48:     	add	x8, x10, #0x1
1000a4f4c:     	cmp	x8, x9
1000a4f50:     	csinc	x10, xzr, x10, hs
1000a4f54:     	subs	x12, x12, #0x1
1000a4f58:     	b.eq	0x1000a50fc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x42c>
1000a4f5c:     	madd	x8, x10, x3, x11
1000a4f60:     	ldr	w13, [x8]
1000a4f64:     	cmp	w13, #0x1
1000a4f68:     	b.eq	0x1000a4f48 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x278>
1000a4f6c:     	cmp	w13, #0x2
1000a4f70:     	b.ne	0x1000a50fc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x42c>
1000a4f74:     	ldr	x13, [x8, #0x8]
1000a4f78:     	cmp	x13, x24
1000a4f7c:     	b.ne	0x1000a4f48 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x278>
1000a4f80:     	ldp	x10, x9, [x8, #0x10]
1000a4f84:     	stp	x9, x10, [sp, #0x148]
1000a4f88:     	ldp	x10, x9, [x8, #0x20]
1000a4f8c:     	stp	x9, x10, [sp, #0x138]
1000a4f90:     	ldp	x13, x10, [x8, #0x30]
1000a4f94:     	ldp	x15, x16, [x8, #0x40]
1000a4f98:     	ldp	x17, x0, [x8, #0x50]
1000a4f9c:     	ldp	x1, x2, [x8, #0x60]
1000a4fa0:     	ldp	x4, x5, [x8, #0x70]
1000a4fa4:     	ldp	x7, x19, [x8, #0x80]
1000a4fa8:     	ldp	x20, x22, [x8, #0x90]
1000a4fac:     	ldp	x25, x26, [x8, #0xa0]
1000a4fb0:     	ldp	x27, x28, [x8, #0xb0]
1000a4fb4:     	ldp	x30, x9, [x8, #0xc0]
1000a4fb8:     	stp	x9, x10, [sp, #0x128]
1000a4fbc:     	ldp	x10, x9, [x8, #0xd0]
1000a4fc0:     	stp	x9, x10, [sp, #0x118]
1000a4fc4:     	ldp	x10, x9, [x8, #0xe0]
1000a4fc8:     	stp	x9, x10, [sp, #0x108]
1000a4fcc:     	mov	w9, #0x1                ; =1
1000a4fd0:     	str	w9, [x8]
1000a4fd4:     	stur	q0, [x8, #0x8]
1000a4fd8:     	stur	q0, [x8, #0x18]
1000a4fdc:     	stur	q0, [x8, #0x28]
1000a4fe0:     	stur	q0, [x8, #0x38]
1000a4fe4:     	stur	q0, [x8, #0x48]
1000a4fe8:     	stur	q0, [x8, #0x58]
1000a4fec:     	stur	q0, [x8, #0x68]
1000a4ff0:     	stur	q0, [x8, #0x78]
1000a4ff4:     	stur	q0, [x8, #0x88]
1000a4ff8:     	stur	q0, [x8, #0x98]
1000a4ffc:     	stur	q0, [x8, #0xa8]
1000a5000:     	stur	q0, [x8, #0xb8]
1000a5004:     	stur	q0, [x8, #0xc8]
1000a5008:     	stur	q0, [x8, #0xd8]
1000a500c:     	ldp	x23, x11, [x8, #0xf0]
1000a5010:     	stur	q0, [x8, #0xe8]
1000a5014:     	ldp	x9, x10, [x8, #0x100]
1000a5018:     	stur	q0, [x8, #0xf8]
1000a501c:     	str	xzr, [x8, #0x108]
1000a5020:     	ldp	x12, x8, [sp, #0x148]
1000a5024:     	madd	x8, x24, x6, x8
1000a5028:     	madd	x8, x8, x6, x12
1000a502c:     	ldr	x12, [sp, #0x140]
1000a5030:     	madd	x8, x8, x6, x12
1000a5034:     	ldr	x12, [sp, #0x138]
1000a5038:     	madd	x8, x8, x6, x12
1000a503c:     	madd	x8, x8, x6, x13
1000a5040:     	ldp	x12, x13, [sp, #0x128]
1000a5044:     	madd	x8, x8, x6, x13
1000a5048:     	madd	x8, x8, x6, x15
1000a504c:     	madd	x8, x8, x6, x16
1000a5050:     	madd	x8, x8, x6, x17
1000a5054:     	madd	x8, x8, x6, x0
1000a5058:     	madd	x8, x8, x6, x1
1000a505c:     	madd	x8, x8, x6, x2
1000a5060:     	madd	x8, x8, x6, x4
1000a5064:     	ldr	x0, [sp, #0xc0]
1000a5068:     	madd	x8, x8, x6, x5
1000a506c:     	madd	x8, x8, x6, x7
1000a5070:     	madd	x8, x8, x6, x19
1000a5074:     	madd	x8, x8, x6, x20
1000a5078:     	madd	x8, x8, x6, x22
1000a507c:     	madd	x8, x8, x6, x25
1000a5080:     	madd	x8, x8, x6, x26
1000a5084:     	madd	x8, x8, x6, x27
1000a5088:     	madd	x8, x8, x6, x28
1000a508c:     	madd	x8, x8, x6, x30
1000a5090:     	madd	x8, x8, x6, x12
1000a5094:     	ldp	x12, x13, [sp, #0x118]
1000a5098:     	madd	x8, x8, x6, x13
1000a509c:     	madd	x8, x8, x6, x12
1000a50a0:     	ldp	x12, x13, [sp, #0x108]
1000a50a4:     	madd	x8, x8, x6, x13
1000a50a8:     	madd	x8, x8, x6, x12
1000a50ac:     	madd	x8, x8, x6, x23
1000a50b0:     	madd	x8, x8, x6, x11
1000a50b4:     	madd	x8, x8, x6, x9
1000a50b8:     	mov	w9, #0x4309             ; =17161
1000a50bc:     	madd	x9, x14, x9, x10
1000a50c0:     	madd	x8, x8, x6, x9
1000a50c4:     	ldr	x10, [sp, #0xc8]
1000a50c8:     	sub	x10, x10, #0x1
1000a50cc:     	ldr	x9, [sp, #0x30]
1000a50d0:     	adds	x9, x9, #0x1
1000a50d4:     	csinv	x9, x9, xzr, lo
1000a50d8:     	str	x10, [sp, #0xc8]
1000a50dc:     	stp	x10, x9, [x0, #0x18]
1000a50e0:     	str	x9, [sp, #0x30]
1000a50e4:     	add	x14, x8, #0x83
1000a50e8:     	ldr	w8, [sp, #0xbc]
1000a50ec:     	str	x14, [sp, #0xd8]
1000a50f0:     	tbz	w8, #0x0, 0x1000a510c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x43c>
1000a50f4:     	mov	x1, #0x0                ; =0
1000a50f8:     	b	0x1000a5148 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x478>
1000a50fc:     	mul	x14, x14, x6
1000a5100:     	ldr	w8, [sp, #0xbc]
1000a5104:     	str	x14, [sp, #0xd8]
1000a5108:     	tbnz	w8, #0x0, 0x1000a50f4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x424>
1000a510c:     	ldr	x8, [sp, #0x98]
1000a5110:     	eor	x8, x8, x24
1000a5114:     	eor	x8, x8, x8, lsr #30
1000a5118:     	mov	x9, #0xe5b9             ; =58809
1000a511c:     	movk	x9, #0x1ce4, lsl #16
1000a5120:     	movk	x9, #0x476d, lsl #32
1000a5124:     	movk	x9, #0xbf58, lsl #48
1000a5128:     	mul	x8, x8, x9
1000a512c:     	eor	x8, x8, x8, lsr #27
1000a5130:     	mov	x9, #0x11eb             ; =4587
1000a5134:     	movk	x9, #0x1331, lsl #16
1000a5138:     	movk	x9, #0x49bb, lsl #32
1000a513c:     	movk	x9, #0x94d0, lsl #48
1000a5140:     	mul	x8, x8, x9
1000a5144:     	eor	x1, x8, x8, lsr #31
1000a5148:     	ldr	x8, [sp, #0xb0]
1000a514c:     	add	x11, x8, x21
1000a5150:     	add	x16, x11, #0x1
1000a5154:     	add	x7, x11, #0x2
1000a5158:     	add	x30, x11, #0x3
1000a515c:     	add	x28, x11, #0x4
1000a5160:     	add	x2, x11, #0x5
1000a5164:     	add	x14, x11, #0x6
1000a5168:     	add	x15, x11, #0x7
1000a516c:     	add	x17, x11, #0x8
1000a5170:     	add	x9, x11, #0x9
1000a5174:     	add	x8, x11, #0xa
1000a5178:     	stp	x9, x8, [sp, #0x100]
1000a517c:     	add	x9, x11, #0xb
1000a5180:     	add	x8, x11, #0xc
1000a5184:     	stp	x9, x8, [sp, #0x110]
1000a5188:     	add	x9, x11, #0xd
1000a518c:     	add	x8, x11, #0xe
1000a5190:     	stp	x9, x8, [sp, #0x120]
1000a5194:     	add	x9, x11, #0xf
1000a5198:     	add	x8, x11, #0x10
1000a519c:     	stp	x9, x8, [sp, #0x130]
1000a51a0:     	add	x9, x11, #0x11
1000a51a4:     	add	x8, x11, #0x12
1000a51a8:     	stp	x9, x8, [sp, #0x140]
1000a51ac:     	add	x9, x11, #0x13
1000a51b0:     	add	x8, x11, #0x14
1000a51b4:     	stp	x9, x8, [sp, #0xe8]
1000a51b8:     	add	x8, x11, #0x15
1000a51bc:     	str	x8, [sp, #0x150]
1000a51c0:     	add	x27, x11, #0x16
1000a51c4:     	add	x22, x11, #0x17
1000a51c8:     	add	x26, x11, #0x18
1000a51cc:     	add	x23, x11, #0x19
1000a51d0:     	add	x25, x11, #0x1a
1000a51d4:     	add	x19, x11, #0x1b
1000a51d8:     	add	x10, x11, #0x1c
1000a51dc:     	add	x13, x11, #0x1d
1000a51e0:     	add	x8, x11, #0x1e
1000a51e4:     	str	x8, [sp, #0xf8]
1000a51e8:     	ldr	x8, [x0]
1000a51ec:     	add	x9, x11, #0x1f
1000a51f0:     	str	x9, [sp, #0xe0]
1000a51f4:     	cbz	x8, 0x1000a53c8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x6f8>
1000a51f8:     	udiv	x9, x1, x8
1000a51fc:     	msub	x1, x9, x8, x1
1000a5200:     	ldr	x9, [x0, #0x10]
1000a5204:     	mov	x20, x8
1000a5208:     	mov	x12, x8
1000a520c:     	b	0x1000a522c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x55c>
1000a5210:     	cmp	x12, x8
1000a5214:     	csel	x12, x1, x12, eq
1000a5218:     	add	x4, x1, #0x1
1000a521c:     	cmp	x4, x8
1000a5220:     	csinc	x1, xzr, x1, hs
1000a5224:     	subs	x20, x20, #0x1
1000a5228:     	b.eq	0x1000a53cc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x6fc>
1000a522c:     	madd	x5, x1, x3, x9
1000a5230:     	ldr	w4, [x5]
1000a5234:     	cmp	w4, #0x1
1000a5238:     	b.eq	0x1000a5210 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x540>
1000a523c:     	cmp	w4, #0x2
1000a5240:     	b.ne	0x1000a5528 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x858>
1000a5244:     	ldr	x4, [x5, #0x8]
1000a5248:     	cmp	x4, x24
1000a524c:     	b.ne	0x1000a5218 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x548>
1000a5250:     	mov	x12, x13
1000a5254:     	mov	x9, x19
1000a5258:     	mov	x1, x23
1000a525c:     	mov	w4, #0x0                ; =0
1000a5260:     	ldr	x0, [x5, #0x10]
1000a5264:     	str	x0, [sp, #0x90]
1000a5268:     	ldr	x0, [x5, #0x18]
1000a526c:     	stp	x11, x16, [x5, #0x10]
1000a5270:     	ldp	x8, x11, [x5, #0x20]
1000a5274:     	stp	x8, x0, [sp, #0x80]
1000a5278:     	str	x11, [sp, #0x78]
1000a527c:     	stp	x7, x30, [x5, #0x20]
1000a5280:     	ldp	x8, x11, [x5, #0x30]
1000a5284:     	stp	x11, x8, [sp, #0x68]
1000a5288:     	stp	x28, x2, [x5, #0x30]
1000a528c:     	ldp	x8, x11, [x5, #0x40]
1000a5290:     	stp	x11, x8, [sp, #0x58]
1000a5294:     	stp	x14, x15, [x5, #0x40]
1000a5298:     	ldp	x8, x11, [x5, #0x50]
1000a529c:     	stp	x11, x8, [sp, #0x48]
1000a52a0:     	ldr	x11, [sp, #0x100]
1000a52a4:     	stp	x17, x11, [x5, #0x50]
1000a52a8:     	ldp	x8, x11, [x5, #0x60]
1000a52ac:     	str	x11, [sp, #0x40]
1000a52b0:     	ldr	x11, [sp, #0x108]
1000a52b4:     	str	x11, [x5, #0x60]
1000a52b8:     	ldr	x11, [sp, #0x110]
1000a52bc:     	str	x11, [x5, #0x68]
1000a52c0:     	ldr	x11, [x5, #0x70]
1000a52c4:     	str	x11, [sp, #0x110]
1000a52c8:     	ldr	x11, [x5, #0x78]
1000a52cc:     	stp	x8, x11, [sp, #0x100]
1000a52d0:     	ldp	x8, x11, [sp, #0x118]
1000a52d4:     	stp	x8, x11, [x5, #0x70]
1000a52d8:     	ldp	x8, x11, [x5, #0x80]
1000a52dc:     	stp	x11, x8, [sp, #0x118]
1000a52e0:     	ldp	x8, x11, [sp, #0x128]
1000a52e4:     	stp	x8, x11, [x5, #0x80]
1000a52e8:     	ldp	x11, x2, [x5, #0x90]
1000a52ec:     	str	x11, [sp, #0x130]
1000a52f0:     	ldp	x8, x11, [sp, #0x138]
1000a52f4:     	stp	x8, x11, [x5, #0x90]
1000a52f8:     	ldp	x11, x7, [x5, #0xa0]
1000a52fc:     	str	x11, [sp, #0x140]
1000a5300:     	ldr	x8, [sp, #0x148]
1000a5304:     	ldr	x11, [sp, #0xe8]
1000a5308:     	stp	x8, x11, [x5, #0xa0]
1000a530c:     	ldp	x0, x16, [x5, #0xb0]
1000a5310:     	ldp	x8, x14, [sp, #0xf0]
1000a5314:     	ldr	x11, [sp, #0x150]
1000a5318:     	stp	x8, x11, [x5, #0xb0]
1000a531c:     	ldp	x11, x30, [x5, #0xc0]
1000a5320:     	stp	x27, x22, [x5, #0xc0]
1000a5324:     	ldp	x8, x23, [x5, #0xd0]
1000a5328:     	stp	x26, x1, [x5, #0xd0]
1000a532c:     	ldp	x1, x19, [x5, #0xe0]
1000a5330:     	stp	x25, x9, [x5, #0xe0]
1000a5334:     	ldp	x9, x13, [x5, #0xf0]
1000a5338:     	stp	x10, x12, [x5, #0xf0]
1000a533c:     	ldp	x17, x15, [x5, #0x100]
1000a5340:     	ldr	x12, [sp, #0xe0]
1000a5344:     	stp	x14, x12, [x5, #0x100]
1000a5348:     	ldr	w12, [x5, #0x4]
1000a534c:     	ldr	w10, [sp, #0x2c]
1000a5350:     	mov	w28, #0x2               ; =2
1000a5354:     	stp	w28, w10, [x5]
1000a5358:     	mov	x5, x15
1000a535c:     	stp	x0, x17, [sp, #0xf0]
1000a5360:     	mov	x10, x9
1000a5364:     	mov	x25, x1
1000a5368:     	mov	x26, x8
1000a536c:     	mov	x22, x30
1000a5370:     	mov	x27, x11
1000a5374:     	str	x7, [sp, #0xe8]
1000a5378:     	ldr	x8, [sp, #0x140]
1000a537c:     	stp	x8, x16, [sp, #0x148]
1000a5380:     	ldr	x8, [sp, #0x130]
1000a5384:     	stp	x8, x2, [sp, #0x138]
1000a5388:     	ldp	x9, x8, [sp, #0x118]
1000a538c:     	stp	x8, x9, [sp, #0x128]
1000a5390:     	ldp	x9, x8, [sp, #0x108]
1000a5394:     	stp	x8, x9, [sp, #0x118]
1000a5398:     	ldr	x9, [sp, #0x40]
1000a539c:     	ldr	x8, [sp, #0x100]
1000a53a0:     	stp	x8, x9, [sp, #0x108]
1000a53a4:     	ldp	x8, x17, [sp, #0x48]
1000a53a8:     	str	x8, [sp, #0x100]
1000a53ac:     	ldp	x15, x14, [sp, #0x58]
1000a53b0:     	ldp	x2, x28, [sp, #0x68]
1000a53b4:     	ldp	x30, x7, [sp, #0x78]
1000a53b8:     	ldp	x16, x11, [sp, #0x88]
1000a53bc:     	str	w12, [sp, #0x2c]
1000a53c0:     	ldr	x0, [sp, #0xc0]
1000a53c4:     	b	0x1000a5544 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x874>
1000a53c8:     	mov	x12, #0x0               ; =0
1000a53cc:     	mov	w4, #0x1                ; =1
1000a53d0:     	cmp	x12, x8
1000a53d4:     	b.hs	0x1000a553c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x86c>
1000a53d8:     	ldr	x8, [sp, #0xc8]
1000a53dc:     	cmp	x8, #0x2, lsl #12       ; =0x2000
1000a53e0:     	b.hs	0x1000a553c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x86c>
1000a53e4:     	add	x8, x8, #0x1
1000a53e8:     	ldr	x9, [sp, #0xc0]
1000a53ec:     	str	x8, [sp, #0xc8]
1000a53f0:     	str	x8, [x9, #0x18]
1000a53f4:     	ldr	x8, [x9, #0x10]
1000a53f8:     	madd	x20, x12, x3, x8
1000a53fc:     	ldr	w5, [x20]
1000a5400:     	cmp	w5, #0x1
1000a5404:     	b.ne	0x1000a541c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x74c>
1000a5408:     	ldr	x8, [sp, #0x30]
1000a540c:     	subs	x8, x8, #0x1
1000a5410:     	csel	x8, xzr, x8, lo
1000a5414:     	str	x8, [sp, #0x30]
1000a5418:     	str	x8, [x9, #0x20]
1000a541c:     	ldp	x9, x8, [x20, #0x8]
1000a5420:     	stp	x8, x9, [sp, #0x88]
1000a5424:     	stp	x24, x11, [x20, #0x8]
1000a5428:     	ldp	x9, x8, [x20, #0x18]
1000a542c:     	stp	x8, x9, [sp, #0x78]
1000a5430:     	stp	x16, x7, [x20, #0x18]
1000a5434:     	ldp	x9, x8, [x20, #0x28]
1000a5438:     	stp	x8, x9, [sp, #0x68]
1000a543c:     	stp	x30, x28, [x20, #0x28]
1000a5440:     	ldp	x9, x8, [x20, #0x38]
1000a5444:     	stp	x8, x9, [sp, #0x58]
1000a5448:     	stp	x2, x14, [x20, #0x38]
1000a544c:     	ldp	x9, x8, [x20, #0x48]
1000a5450:     	stp	x8, x9, [sp, #0x48]
1000a5454:     	stp	x15, x17, [x20, #0x48]
1000a5458:     	ldp	x9, x8, [x20, #0x58]
1000a545c:     	stp	x8, x9, [sp, #0x38]
1000a5460:     	ldp	x9, x8, [sp, #0x100]
1000a5464:     	stp	x9, x8, [x20, #0x58]
1000a5468:     	ldp	x9, x8, [x20, #0x68]
1000a546c:     	stp	x8, x9, [sp, #0x100]
1000a5470:     	ldp	x9, x8, [sp, #0x110]
1000a5474:     	stp	x9, x8, [x20, #0x68]
1000a5478:     	ldp	x9, x8, [x20, #0x78]
1000a547c:     	stp	x8, x9, [sp, #0x110]
1000a5480:     	ldp	x9, x8, [sp, #0x120]
1000a5484:     	stp	x9, x8, [x20, #0x78]
1000a5488:     	ldp	x15, x2, [x20, #0x88]
1000a548c:     	ldp	x9, x8, [sp, #0x130]
1000a5490:     	stp	x9, x8, [x20, #0x88]
1000a5494:     	ldp	x14, x17, [x20, #0x98]
1000a5498:     	ldp	x9, x8, [sp, #0x140]
1000a549c:     	stp	x9, x8, [x20, #0x98]
1000a54a0:     	ldp	x12, x4, [x20, #0xa8]
1000a54a4:     	ldp	x9, x8, [sp, #0xe8]
1000a54a8:     	stp	x9, x8, [x20, #0xa8]
1000a54ac:     	ldp	x8, x9, [x20, #0xb8]
1000a54b0:     	ldr	x11, [sp, #0x150]
1000a54b4:     	stp	x11, x27, [x20, #0xb8]
1000a54b8:     	ldp	x30, x11, [x20, #0xc8]
1000a54bc:     	stp	x22, x26, [x20, #0xc8]
1000a54c0:     	ldp	x16, x7, [x20, #0xd8]
1000a54c4:     	stp	x23, x25, [x20, #0xd8]
1000a54c8:     	ldp	x24, x28, [x20, #0xe8]
1000a54cc:     	stp	x19, x10, [x20, #0xe8]
1000a54d0:     	ldp	x26, x27, [x20, #0xf8]
1000a54d4:     	ldr	x0, [sp, #0xf8]
1000a54d8:     	stp	x13, x0, [x20, #0xf8]
1000a54dc:     	ldr	x0, [x20, #0x108]
1000a54e0:     	ldr	x1, [sp, #0xe0]
1000a54e4:     	str	x1, [x20, #0x108]
1000a54e8:     	ldr	w1, [x20, #0x4]
1000a54ec:     	ldr	w10, [sp, #0xd4]
1000a54f0:     	mov	w23, #0x2               ; =2
1000a54f4:     	stp	w23, w10, [x20]
1000a54f8:     	strb	wzr, [sp, #0x15c]
1000a54fc:     	cmp	w5, #0x2
1000a5500:     	b.hs	0x1000a4d7c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0xac>
1000a5504:     	ldr	x14, [sp, #0xd8]
1000a5508:     	mul	x14, x14, x6
1000a550c:     	ldr	x0, [sp, #0xc0]
1000a5510:     	add	x21, x21, #0x1
1000a5514:     	mov	x13, x1
1000a5518:     	ldr	x12, [sp, #0xa0]
1000a551c:     	cmp	x21, x12
1000a5520:     	b.ne	0x1000a4ebc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x1ec>
1000a5524:     	b	0x1000a4d40 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x70>
1000a5528:     	cmp	x12, x8
1000a552c:     	csel	x12, x1, x12, eq
1000a5530:     	mov	w4, #0x1                ; =1
1000a5534:     	cmp	x12, x8
1000a5538:     	b.lo	0x1000a53d8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x708>
1000a553c:     	ldr	x0, [sp, #0xc0]
1000a5540:     	ldr	x5, [sp, #0xe0]
1000a5544:     	strb	w4, [sp, #0x15c]
1000a5548:     	ldr	w1, [sp, #0xd4]
1000a554c:     	ldp	x4, x20, [sp, #0xf0]
1000a5550:     	ldr	x12, [sp, #0xe8]
1000a5554:     	b	0x1000a4de0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x110>
1000a5558:     	ldr	x8, [sp, #0x10]
1000a555c:     	add	x8, x10, x8
1000a5560:     	str	x8, [x0, #0x48]
1000a5564:     	eor	x8, x14, x14, lsr #30
1000a5568:     	mov	x9, #0xe5b9             ; =58809
1000a556c:     	movk	x9, #0x1ce4, lsl #16
1000a5570:     	movk	x9, #0x476d, lsl #32
1000a5574:     	movk	x9, #0xbf58, lsl #48
1000a5578:     	mul	x8, x8, x9
1000a557c:     	eor	x8, x8, x8, lsr #27
1000a5580:     	mov	x9, #0x11eb             ; =4587
1000a5584:     	movk	x9, #0x1331, lsl #16
1000a5588:     	movk	x9, #0x49bb, lsl #32
1000a558c:     	movk	x9, #0x94d0, lsl #48
1000a5590:     	mul	x8, x8, x9
1000a5594:     	eor	x0, x8, x8, lsr #31
1000a5598:     	ldp	x29, x30, [sp, #0x1b0]
1000a559c:     	ldp	x20, x19, [sp, #0x1a0]
1000a55a0:     	ldp	x22, x21, [sp, #0x190]
1000a55a4:     	ldp	x24, x23, [sp, #0x180]
1000a55a8:     	ldp	x26, x25, [sp, #0x170]
1000a55ac:     	ldp	x28, x27, [sp, #0x160]
1000a55b0:     	add	sp, sp, #0x1c0
1000a55b4:     	ret

