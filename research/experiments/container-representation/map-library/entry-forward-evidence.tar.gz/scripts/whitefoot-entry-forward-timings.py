import pathlib,subprocess,time,json,hashlib,shlex
root=pathlib.Path.cwd()
cli=root/'research/experiments/container-representation/map-library/.build/lookup-api/mutation-screen/whitefootc-running-index'
source=root/'tests/programs/containers/hash-map-program.wf'
line=pathlib.Path('/private/tmp/whitefoot-mutation-final-candidate-timed-link.log').read_text().splitlines()[0]
objects=[a for a in shlex.split(line) if '/.build/native/' in a]
records=[]
def run(label,args,expected=0,stdout=None):
 t=time.monotonic(); p=subprocess.run([str(a) for a in args],capture_output=True,text=True)
 row=dict(label=label,command=[str(a) for a in args],seconds=time.monotonic()-t,exit=p.returncode,stdout=p.stdout,stderr=p.stderr); records.append(row)
 print(json.dumps(row),flush=True)
 assert p.returncode==expected,row
 if stdout is not None: assert p.stdout==stdout,row
 return p

d=root/'research/experiments/container-representation/map-library/.build/lookup-api/mutation-screen'
for cohort,arms in [(0,['candidate','entry-forward']),(1,['entry-forward','candidate'])]:
 for arm in arms:
  p=run(arm+' cohort '+str(cohort),[d/(arm+'-timed'),'measure',str(cohort),'1048576'])
  (d/(arm+'-entry-forward-cohort-'+str(cohort)+'.csv')).write_text(p.stdout)
pathlib.Path('/private/tmp/whitefoot-entry-forward-timings.json').write_text(json.dumps(records,indent=2)+'\n')
