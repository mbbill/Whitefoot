import pathlib,subprocess,time,json,hashlib,shlex
root=pathlib.Path.cwd()
cli=root/'research/experiments/container-representation/map-library/.build/lookup-api/mutation-screen/whitefootc-running-index'
source=root/'tests/programs/containers/hash-map-program.wf'
line=pathlib.Path('/private/tmp/whitefoot-mutation-final-candidate-timed-link.log').read_text().splitlines()[0]
objects=[a for a in shlex.split(line) if '/.build/native/' in a]
records=[]
def run(label,args,expected=0,stdout=None):
 t=time.monotonic(); p=subprocess.run([str(a) for a in args],capture_output=True,text=True)
 row=dict(label=label,command=[str(a) for a in args],seconds=time.monotonic()-t,exit=p.returncode,stdout=p.stdout,stderr=p.stderr); records.append(row)
 print(json.dumps(row),flush=True)
 assert p.returncode==expected,row
 if stdout is not None: assert p.stdout==stdout,row
 return p

d=root/'research/experiments/container-representation/map-library/.build/lookup-api/mutation-screen'
for arm in ['candidate','entry-forward']:
 for kind in ['timed','account']:
  exe=d/(arm+'-'+kind)
  run(arm+' '+kind+' check',[exe,'check'])
  faults=['wrong-batch-checksum','stale-generation','corrupt-last-word','cleanup']
  if kind=='account': faults+=['ledger-leak','filled-allocation']
  for fault in faults: run(arm+' '+kind+' '+fault,[exe,'negative',fault],expected=1)
 account=run(arm+' ledger',[d/(arm+'-account'),'account'])
 (d/(arm+'-entry-forward-check-account.csv')).write_text(account.stdout)
assert (d/'candidate-entry-forward-check-account.csv').read_bytes()==(d/'entry-forward-entry-forward-check-account.csv').read_bytes()
pathlib.Path('/private/tmp/whitefoot-entry-forward-controls.json').write_text(json.dumps(records,indent=2)+'\n')
