import pathlib,subprocess,time,json,hashlib,shlex
root=pathlib.Path.cwd()
cli=root/'research/experiments/container-representation/map-library/.build/lookup-api/mutation-screen/whitefootc-running-index'
source=root/'tests/programs/containers/hash-map-program.wf'
line=pathlib.Path('/private/tmp/whitefoot-mutation-final-candidate-timed-link.log').read_text().splitlines()[0]
objects=[a for a in shlex.split(line) if '/.build/native/' in a]
records=[]
def run(label,args,expected=0,stdout=None):
 t=time.monotonic(); p=subprocess.run([str(a) for a in args],capture_output=True,text=True)
 row=dict(label=label,command=[str(a) for a in args],seconds=time.monotonic()-t,exit=p.returncode,stdout=p.stdout,stderr=p.stderr); records.append(row)
 print(json.dumps(row),flush=True)
 assert p.returncode==expected,row
 if stdout is not None: assert p.stdout==stdout,row
 return p

d=root/'research/experiments/container-representation/map-library/.build/lookup-api/mutation-screen'
p=root/'research/experiments/container-representation/map-library/.build/lookup-chain-probe'
cli=root/'compiler/target/gate/whitefootc'
import shutil
shutil.copy2(cli,d/'whitefootc-entry-forward')
cli=d/'whitefootc-entry-forward'
run('emit unchanged mutation witness',[cli,'--emit-llvm',p/'mutation-complete.wf','-o',d/'entry-forward.raw.ll'])
run('raw object',['/usr/bin/clang','-O3','-Wno-override-module','-x','ir','-c',d/'entry-forward.raw.ll','-o',d/'entry-forward.o'])
for kind in ['timed','account']:
 text=(d/'entry-forward.raw.ll').read_text().replace('define i32 @main(', 'define i32 @mutation_unused_main(')
 if kind=='account':
  baseline=(d/'candidate-wf-account.ll').read_text() if (d/'candidate-wf-account.ll').exists() else ''
  # Exact hook names are checked against the retained control below.
  for old,new in [('@malloc(', '@wf_cost_allocate('),('@realloc(', '@wf_cost_reallocate('),('@free(', '@wf_cost_release(')]: text=text.replace(old,new)
 src=d/('entry-forward-wf-'+kind+'.ll'); src.write_text(text)
 obj=src.with_suffix('.o')
 run(kind+' object',['/usr/bin/clang','-O3','-Wno-override-module','-x','ir','-c',src,'-o',obj])
 run(kind+' link',['/usr/bin/clang++','-O3',d/('driver-'+kind+'.o'),d/('rust-'+kind+'.a'),d/('cpp-'+kind+'.o'),*objects,obj,'-liconv','-lSystem','-lc','-lm','-pthread','-o',d/('entry-forward-'+kind)])
pathlib.Path('/private/tmp/whitefoot-entry-forward-images.json').write_text(json.dumps(records,indent=2)+'\n')
