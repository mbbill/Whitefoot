#!/usr/bin/env python3
"""One-shot longer whole-trace hit discriminator; root executes under guard."""
import csv
import difflib
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time

root, prior, out = map(lambda s: Path(s).resolve(), sys.argv[1:4])
assert os.environ.get('WHITEFOOT_CHECK_OWNER'), 'Run under run-check.pl'
out.mkdir(parents=True, exist_ok=False)
v = root / 'research/experiments/container-representation/map-library'
old = json.loads((prior / 'metadata.json').read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert old['artifact_pins_before'] == old['artifact_pins_after']
pins = old['artifact_pins_after']
assert all(sha(Path(p)) == h for p, h in pins.items()), 'prior objects/images changed'
source = v / 'map-ecosystem.c'
assert sha(source) == old['source_pins'][str(source)], 'driver source changed'
original = source.read_text()
before = '''static void measure(unsigned cohort, uint64_t work, bool occupancy) {
    const Shape *shapes = occupancy ? occupancy_shapes : measured_shapes;
    const unsigned *selected_paths = occupancy ? occupancy_paths : paths;
    size_t shape_count = occupancy ? ELEMENTS(occupancy_shapes) : ELEMENTS(measured_shapes);
    size_t path_count = occupancy ? ELEMENTS(occupancy_paths) : ELEMENTS(paths);'''
after = '''static void measure(unsigned cohort, uint64_t work, bool occupancy) {
    static const Shape target_shapes[] = {{64, 56}};
    static const unsigned target_paths[] = {HIT};
    const Shape *shapes = target_shapes;
    const unsigned *selected_paths = target_paths;
    size_t shape_count = ELEMENTS(target_shapes);
    size_t path_count = ELEMENTS(target_paths);'''
assert original.count(before) == 1
modified = original.replace(before, after)
driver = out / 'driver.c'
driver.write_text(modified)
(out / 'driver.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),
    modified.splitlines(True), 'a/map-ecosystem.c', 'b/map-ecosystem.c')))
metadata = {'criterion': {'question': 'Longer unchanged whole-trace hit64 adverse-cell discriminator',
    'work': 8388608, 'samples': 11, 'cohorts': 2, 'widths': [8, 256], 'capacity': 64,
    'count': 56, 'path': 'hit', 'series': ['native-default', 'aligned-hash'],
    'peers': 'all five existing implementations', 'rows_per_process': 220,
    'minimum_every_sample_ns': 1000000, 'measure_deadline_s': 180,
    'direction': 'strict disjoint full sample envelopes in BOTH cohorts; overlap unresolved',
    'order': ['control-c0', 'candidate-c0', 'candidate-c1', 'control-c1'],
    'retries': 0, 'original_panel_retained': str(prior),
    'limitations': 'WF function placement differs; no isolated-query or layout attribution claim'},
    'input_pins': pins, 'original_driver_sha256': sha(source), 'driver_sha256': sha(driver),
    'prior_prerequisites': str(prior / 'statuses.json'), 'absl_link': old['absl_link']}
(out / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
statuses = []
def run(label, argv, limit=60, expected=0, message=None, csv_output=False):
    argv = list(map(str, argv)); so = out / (label + ('.csv' if csv_output else '.stdout'))
    se = out / (label + '.stderr'); start = time.monotonic()
    print('START', label, shlex.join(argv), flush=True)
    result = {'label': label, 'argv': argv, 'cwd': str(root), 'deadline_s': limit,
              'expected_exit': expected, 'stdout': str(so), 'stderr': str(se)}
    with so.open('wb') as stdout, se.open('wb') as stderr:
        try:
            result['exit'] = subprocess.run(argv, cwd=root, stdout=stdout, stderr=stderr,
                                            timeout=limit).returncode
        except subprocess.TimeoutExpired:
            result.update(exit=None, timeout=True)
    result['wall_s'] = time.monotonic() - start; statuses.append(result)
    (out / 'statuses.json').write_text(json.dumps(statuses, indent=2) + '\n')
    print('END', label, result['exit'], result['wall_s'], flush=True)
    assert result['exit'] == expected, result
    if message is not None:
        assert not so.read_bytes() and se.read_text().strip() == message, label
    return so

run('driver-build', ['clang', '-DECOSYSTEM', '-std=c11', '-O3', '-Wall', '-Wextra', '-Werror',
                    '-I', v, '-c', driver, '-o', out / 'driver.o'])
runtime_names = ['ordinary_values', 'sched/core', 'sched/entry', 'completion/runtime',
                 'completion/file_adapter', 'completion/bridge', 'wf_floor', 'sched/prim_host',
                 'completion/wait_host', 'completion/file_posix', 'completion/linux_io_uring',
                 'ordinary_values_ir']
shared = prior / 'shared'
for arm in ['control', 'candidate']:
    inputs = [out / 'driver.o', shared / 'rust-timed.a', shared / 'cpp-timed.o',
              shared / 'control-timed.o', *[shared / 'native' / (n + '.o') for n in runtime_names],
              prior / arm / 'wf-timed.o']
    run(arm + '-link', ['clang++', '-O3', *inputs, *old['absl_link'], '-liconv', '-lSystem',
                       '-lc', '-lm', '-pthread', '-lm', '-o', out / (arm + '-timed')])
    image = out / (arm + '-timed')
    run(arm + '-check', [image, 'check'])
    run(arm + '-negative-checksum', [image, 'negative-checksum'], expected=1,
        message='map ecosystem: independent key-ID/content/outcome oracle')
    for variant in [0, 1, 2, 3, 5, 6, 7, 8]:
        run(arm + '-negative-reserve-' + str(variant), [image, 'negative-reserve', variant], expected=1,
            message='map ecosystem: reserve capacity floor')
metadata['images_before'] = {arm: sha(out / (arm + '-timed')) for arm in ['control', 'candidate']}
(out / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
for arm, cohort in [('control', 0), ('candidate', 0), ('candidate', 1), ('control', 1)]:
    file = run(arm + '-cohort-' + str(cohort), [out / (arm + '-timed'), 'measure', cohort, 8388608],
               limit=180, csv_output=True)
    rows = list(csv.DictReader(file.open()))
    assert len(rows) == 220
    assert all(r['requested_capacity'] == '64' and r['count'] == '56' and r['path'] == 'hit' for r in rows)
metadata['images_after'] = {arm: sha(out / (arm + '-timed')) for arm in ['control', 'candidate']}
metadata['inputs_unchanged'] = all(sha(Path(p)) == h for p, h in pins.items())
(out / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
assert metadata['images_before'] == metadata['images_after'] and metadata['inputs_unchanged']
print('COMPLETE; all original and targeted rows retained separately', flush=True)
