00000001000a5934 <_wf_flat_mutation_batch$instance$4250cb78d3f44027>:
1000a5934:     	sub	sp, sp, #0x1c0
1000a5938:     	stp	x28, x27, [sp, #0x160]
1000a593c:     	stp	x26, x25, [sp, #0x170]
1000a5940:     	stp	x24, x23, [sp, #0x180]
1000a5944:     	stp	x22, x21, [sp, #0x190]
1000a5948:     	stp	x20, x19, [sp, #0x1a0]
1000a594c:     	stp	x29, x30, [sp, #0x1b0]
1000a5950:     	str	x2, [sp, #0xb0]
1000a5954:     	ldr	x9, [x0, #0x38]
1000a5958:     	str	x1, [sp, #0x10]
1000a595c:     	cbz	x1, 0x1000a6224 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x8f0>
1000a5960:     	ldp	x8, x10, [x0, #0x40]
1000a5964:     	str	x8, [sp, #0xc0]
1000a5968:     	cbz	x8, 0x1000a6218 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x8e4>
1000a596c:     	mov	x11, #0x0               ; =0
1000a5970:     	ldp	x22, x8, [x0, #0x18]
1000a5974:     	str	x8, [sp, #0x30]
1000a5978:     	mov	w17, #0x110             ; =272
1000a597c:     	ldr	x8, [x0, #0x28]
1000a5980:     	stp	x0, x8, [sp, #0x90]
1000a5984:     	mov	w5, #0x83               ; =131
1000a5988:     	movi.2d	v0, #0000000000000000
1000a598c:     	ldrb	w8, [x0, #0x30]
1000a5990:     	str	w8, [sp, #0xcc]
1000a5994:     	mov	x14, x9
1000a5998:     	str	x9, [sp, #0x8]
1000a599c:     	b	0x1000a59b8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x84>
1000a59a0:     	ldp	x11, x10, [sp, #0x18]
1000a59a4:     	str	x10, [x0, #0x48]
1000a59a8:     	add	x11, x11, #0x1
1000a59ac:     	ldp	x9, x8, [sp, #0x8]
1000a59b0:     	cmp	x11, x8
1000a59b4:     	b.eq	0x1000a6228 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x8f4>
1000a59b8:     	mov	x20, #0x0               ; =0
1000a59bc:     	add	x10, x10, #0x1
1000a59c0:     	stp	x11, x10, [sp, #0x18]
1000a59c4:     	ldr	x8, [sp, #0xc0]
1000a59c8:     	madd	x8, x10, x8, x9
1000a59cc:     	str	x8, [sp, #0xb8]
1000a59d0:     	b	0x1000a5b28 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x1f4>
1000a59d4:     	mov	x1, x26
1000a59d8:     	mov	x11, x0
1000a59dc:     	mov	x7, x28
1000a59e0:     	mov	x14, x27
1000a59e4:     	mov	x0, x24
1000a59e8:     	mov	x2, x10
1000a59ec:     	mov	x27, x30
1000a59f0:     	mov	x23, x3
1000a59f4:     	mov	x3, x22
1000a59f8:     	stp	x9, x4, [sp, #0x148]
1000a59fc:     	mov	x4, x8
1000a5a00:     	stp	x15, x16, [sp, #0x138]
1000a5a04:     	stp	x12, x25, [sp, #0x128]
1000a5a08:     	mov	x12, x6
1000a5a0c:     	mov	x19, x21
1000a5a10:     	ldr	x21, [sp, #0x120]
1000a5a14:     	ldp	x9, x8, [sp, #0x108]
1000a5a18:     	stp	x8, x9, [sp, #0x118]
1000a5a1c:     	ldr	x9, [sp, #0x38]
1000a5a20:     	ldr	x8, [sp, #0x100]
1000a5a24:     	stp	x8, x9, [sp, #0x108]
1000a5a28:     	ldp	x8, x25, [sp, #0x40]
1000a5a2c:     	str	x8, [sp, #0x100]
1000a5a30:     	ldp	x15, x26, [sp, #0x50]
1000a5a34:     	ldp	x16, x28, [sp, #0x60]
1000a5a38:     	ldp	x30, x6, [sp, #0x70]
1000a5a3c:     	ldp	x10, x24, [sp, #0x80]
1000a5a40:     	str	w13, [sp, #0xa4]
1000a5a44:     	mov	x13, x0
1000a5a48:     	ldr	x0, [sp, #0x90]
1000a5a4c:     	ldr	x22, [sp, #0xa8]
1000a5a50:     	madd	x8, x24, x5, x10
1000a5a54:     	madd	x8, x8, x5, x6
1000a5a58:     	madd	x8, x8, x5, x30
1000a5a5c:     	ldrb	w9, [sp, #0x15c]
1000a5a60:     	tst	w9, #0x1
1000a5a64:     	madd	x8, x8, x5, x28
1000a5a68:     	mov	w9, #0x1                ; =1
1000a5a6c:     	cinc	x9, x9, ne
1000a5a70:     	madd	x8, x8, x5, x16
1000a5a74:     	madd	x8, x8, x5, x26
1000a5a78:     	madd	x8, x8, x5, x15
1000a5a7c:     	madd	x8, x8, x5, x25
1000a5a80:     	ldr	x10, [sp, #0x100]
1000a5a84:     	madd	x8, x8, x5, x10
1000a5a88:     	ldr	x10, [sp, #0x108]
1000a5a8c:     	madd	x8, x8, x5, x10
1000a5a90:     	ldr	x10, [sp, #0x110]
1000a5a94:     	madd	x8, x8, x5, x10
1000a5a98:     	ldr	x10, [sp, #0x118]
1000a5a9c:     	madd	x8, x8, x5, x10
1000a5aa0:     	ldr	x10, [sp, #0x120]
1000a5aa4:     	madd	x8, x8, x5, x10
1000a5aa8:     	madd	x8, x8, x5, x21
1000a5aac:     	madd	x8, x8, x5, x19
1000a5ab0:     	ldr	x10, [sp, #0x128]
1000a5ab4:     	madd	x8, x8, x5, x10
1000a5ab8:     	ldr	x10, [sp, #0x130]
1000a5abc:     	madd	x8, x8, x5, x10
1000a5ac0:     	ldr	x10, [sp, #0x138]
1000a5ac4:     	madd	x8, x8, x5, x10
1000a5ac8:     	ldr	x10, [sp, #0x140]
1000a5acc:     	madd	x8, x8, x5, x10
1000a5ad0:     	ldr	x10, [sp, #0x148]
1000a5ad4:     	madd	x8, x8, x5, x10
1000a5ad8:     	ldr	x10, [sp, #0x150]
1000a5adc:     	madd	x8, x8, x5, x10
1000a5ae0:     	madd	x8, x8, x5, x4
1000a5ae4:     	madd	x8, x8, x5, x3
1000a5ae8:     	madd	x8, x8, x5, x23
1000a5aec:     	madd	x8, x8, x5, x27
1000a5af0:     	madd	x8, x8, x5, x2
1000a5af4:     	madd	x8, x8, x5, x12
1000a5af8:     	madd	x8, x8, x5, x13
1000a5afc:     	madd	x8, x8, x5, x14
1000a5b00:     	ldr	x10, [sp, #0xf0]
1000a5b04:     	add	x10, x7, x10
1000a5b08:     	madd	x8, x8, x5, x10
1000a5b0c:     	add	x9, x9, x11
1000a5b10:     	madd	x8, x8, x5, x9
1000a5b14:     	madd	x14, x8, x5, x1
1000a5b18:     	add	x20, x20, #0x1
1000a5b1c:     	ldr	x8, [sp, #0xc0]
1000a5b20:     	cmp	x20, x8
1000a5b24:     	b.eq	0x1000a59a0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x6c>
1000a5b28:     	mov	w8, #0x1                ; =1
1000a5b2c:     	orr	x24, x8, x20, lsl #1
1000a5b30:     	ldr	x8, [sp, #0xb0]
1000a5b34:     	cbz	x8, 0x1000a5d54 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x420>
1000a5b38:     	cbz	x22, 0x1000a5d68 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x434>
1000a5b3c:     	ldr	w8, [sp, #0xcc]
1000a5b40:     	tbz	w8, #0x0, 0x1000a5b54 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x220>
1000a5b44:     	mov	x8, #0x0                ; =0
1000a5b48:     	ldr	x9, [x0]
1000a5b4c:     	cbnz	x9, 0x1000a5b98 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x264>
1000a5b50:     	b	0x1000a5d68 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x434>
1000a5b54:     	ldr	x8, [sp, #0x98]
1000a5b58:     	eor	x8, x24, x8
1000a5b5c:     	eor	x8, x8, x8, lsr #30
1000a5b60:     	mov	x9, #0xe5b9             ; =58809
1000a5b64:     	movk	x9, #0x1ce4, lsl #16
1000a5b68:     	movk	x9, #0x476d, lsl #32
1000a5b6c:     	movk	x9, #0xbf58, lsl #48
1000a5b70:     	mul	x8, x8, x9
1000a5b74:     	eor	x8, x8, x8, lsr #27
1000a5b78:     	mov	x9, #0x11eb             ; =4587
1000a5b7c:     	movk	x9, #0x1331, lsl #16
1000a5b80:     	movk	x9, #0x49bb, lsl #32
1000a5b84:     	movk	x9, #0x94d0, lsl #48
1000a5b88:     	mul	x8, x8, x9
1000a5b8c:     	eor	x8, x8, x8, lsr #31
1000a5b90:     	ldr	x9, [x0]
1000a5b94:     	cbz	x9, 0x1000a5d68 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x434>
1000a5b98:     	udiv	x10, x8, x9
1000a5b9c:     	msub	x10, x10, x9, x8
1000a5ba0:     	ldr	x11, [x0, #0x10]
1000a5ba4:     	mov	x12, x9
1000a5ba8:     	b	0x1000a5bc0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x28c>
1000a5bac:     	add	x8, x10, #0x1
1000a5bb0:     	cmp	x8, x9
1000a5bb4:     	csinc	x10, xzr, x10, hs
1000a5bb8:     	subs	x12, x12, #0x1
1000a5bbc:     	b.eq	0x1000a5d68 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x434>
1000a5bc0:     	madd	x8, x10, x17, x11
1000a5bc4:     	ldr	w13, [x8]
1000a5bc8:     	cmp	w13, #0x1
1000a5bcc:     	b.eq	0x1000a5bac <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x278>
1000a5bd0:     	cmp	w13, #0x2
1000a5bd4:     	b.ne	0x1000a5d68 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x434>
1000a5bd8:     	ldr	x13, [x8, #0x8]
1000a5bdc:     	cmp	x13, x24
1000a5be0:     	b.ne	0x1000a5bac <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x278>
1000a5be4:     	ldp	x21, x10, [x8, #0x10]
1000a5be8:     	ldp	x11, x9, [x8, #0x20]
1000a5bec:     	stp	x11, x10, [sp, #0x148]
1000a5bf0:     	str	x9, [sp, #0x140]
1000a5bf4:     	ldp	x13, x10, [x8, #0x30]
1000a5bf8:     	ldp	x15, x16, [x8, #0x40]
1000a5bfc:     	ldp	x0, x1, [x8, #0x50]
1000a5c00:     	str	x22, [sp, #0xa8]
1000a5c04:     	ldp	x2, x3, [x8, #0x60]
1000a5c08:     	ldp	x4, x6, [x8, #0x70]
1000a5c0c:     	ldp	x7, x19, [x8, #0x80]
1000a5c10:     	ldp	x9, x22, [x8, #0x90]
1000a5c14:     	stp	x9, x10, [sp, #0x130]
1000a5c18:     	ldp	x23, x25, [x8, #0xa0]
1000a5c1c:     	ldp	x26, x27, [x8, #0xb0]
1000a5c20:     	ldp	x28, x30, [x8, #0xc0]
1000a5c24:     	ldp	x10, x9, [x8, #0xd0]
1000a5c28:     	stp	x9, x10, [sp, #0x120]
1000a5c2c:     	ldp	x10, x9, [x8, #0xe0]
1000a5c30:     	stp	x9, x10, [sp, #0x110]
1000a5c34:     	mov	w9, #0x1                ; =1
1000a5c38:     	str	w9, [x8]
1000a5c3c:     	stur	q0, [x8, #0x8]
1000a5c40:     	stur	q0, [x8, #0x18]
1000a5c44:     	stur	q0, [x8, #0x28]
1000a5c48:     	stur	q0, [x8, #0x38]
1000a5c4c:     	stur	q0, [x8, #0x48]
1000a5c50:     	stur	q0, [x8, #0x58]
1000a5c54:     	stur	q0, [x8, #0x68]
1000a5c58:     	stur	q0, [x8, #0x78]
1000a5c5c:     	stur	q0, [x8, #0x88]
1000a5c60:     	stur	q0, [x8, #0x98]
1000a5c64:     	stur	q0, [x8, #0xa8]
1000a5c68:     	stur	q0, [x8, #0xb8]
1000a5c6c:     	stur	q0, [x8, #0xc8]
1000a5c70:     	stur	q0, [x8, #0xd8]
1000a5c74:     	ldp	x11, x12, [x8, #0xf0]
1000a5c78:     	stur	q0, [x8, #0xe8]
1000a5c7c:     	ldp	x9, x10, [x8, #0x100]
1000a5c80:     	stur	q0, [x8, #0xf8]
1000a5c84:     	str	xzr, [x8, #0x108]
1000a5c88:     	madd	x8, x24, x5, x21
1000a5c8c:     	ldr	x21, [sp, #0x150]
1000a5c90:     	madd	x8, x8, x5, x21
1000a5c94:     	ldr	x21, [sp, #0x148]
1000a5c98:     	madd	x8, x8, x5, x21
1000a5c9c:     	ldr	x21, [sp, #0x140]
1000a5ca0:     	madd	x8, x8, x5, x21
1000a5ca4:     	madd	x8, x8, x5, x13
1000a5ca8:     	ldr	x13, [sp, #0x138]
1000a5cac:     	madd	x8, x8, x5, x13
1000a5cb0:     	madd	x8, x8, x5, x15
1000a5cb4:     	madd	x8, x8, x5, x16
1000a5cb8:     	madd	x8, x8, x5, x0
1000a5cbc:     	madd	x8, x8, x5, x1
1000a5cc0:     	madd	x8, x8, x5, x2
1000a5cc4:     	ldr	x13, [sp, #0xa8]
1000a5cc8:     	ldr	x0, [sp, #0x90]
1000a5ccc:     	madd	x8, x8, x5, x3
1000a5cd0:     	madd	x8, x8, x5, x4
1000a5cd4:     	madd	x8, x8, x5, x6
1000a5cd8:     	madd	x8, x8, x5, x7
1000a5cdc:     	madd	x8, x8, x5, x19
1000a5ce0:     	ldr	x15, [sp, #0x130]
1000a5ce4:     	madd	x8, x8, x5, x15
1000a5ce8:     	madd	x8, x8, x5, x22
1000a5cec:     	mov	x22, x13
1000a5cf0:     	madd	x8, x8, x5, x23
1000a5cf4:     	madd	x8, x8, x5, x25
1000a5cf8:     	madd	x8, x8, x5, x26
1000a5cfc:     	madd	x8, x8, x5, x27
1000a5d00:     	madd	x8, x8, x5, x28
1000a5d04:     	madd	x8, x8, x5, x30
1000a5d08:     	ldp	x13, x15, [sp, #0x120]
1000a5d0c:     	madd	x8, x8, x5, x15
1000a5d10:     	madd	x8, x8, x5, x13
1000a5d14:     	ldp	x13, x15, [sp, #0x110]
1000a5d18:     	madd	x8, x8, x5, x15
1000a5d1c:     	madd	x8, x8, x5, x13
1000a5d20:     	madd	x8, x8, x5, x11
1000a5d24:     	madd	x8, x8, x5, x12
1000a5d28:     	madd	x8, x8, x5, x9
1000a5d2c:     	mov	w9, #0x4309             ; =17161
1000a5d30:     	madd	x9, x14, x9, x10
1000a5d34:     	madd	x8, x8, x5, x9
1000a5d38:     	sub	x22, x22, #0x1
1000a5d3c:     	ldr	x9, [sp, #0x30]
1000a5d40:     	adds	x9, x9, #0x1
1000a5d44:     	csinv	x9, x9, xzr, lo
1000a5d48:     	stp	x22, x9, [x0, #0x18]
1000a5d4c:     	str	x9, [sp, #0x30]
1000a5d50:     	add	x14, x8, #0x83
1000a5d54:     	ldr	w8, [sp, #0xcc]
1000a5d58:     	str	x14, [sp, #0xf0]
1000a5d5c:     	tbz	w8, #0x0, 0x1000a5d78 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x444>
1000a5d60:     	mov	x11, #0x0               ; =0
1000a5d64:     	b	0x1000a5db4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x480>
1000a5d68:     	mul	x14, x14, x5
1000a5d6c:     	ldr	w8, [sp, #0xcc]
1000a5d70:     	str	x14, [sp, #0xf0]
1000a5d74:     	tbnz	w8, #0x0, 0x1000a5d60 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x42c>
1000a5d78:     	ldr	x8, [sp, #0x98]
1000a5d7c:     	eor	x8, x24, x8
1000a5d80:     	eor	x8, x8, x8, lsr #30
1000a5d84:     	mov	x9, #0xe5b9             ; =58809
1000a5d88:     	movk	x9, #0x1ce4, lsl #16
1000a5d8c:     	movk	x9, #0x476d, lsl #32
1000a5d90:     	movk	x9, #0xbf58, lsl #48
1000a5d94:     	mul	x8, x8, x9
1000a5d98:     	eor	x8, x8, x8, lsr #27
1000a5d9c:     	mov	x9, #0x11eb             ; =4587
1000a5da0:     	movk	x9, #0x1331, lsl #16
1000a5da4:     	movk	x9, #0x49bb, lsl #32
1000a5da8:     	movk	x9, #0x94d0, lsl #48
1000a5dac:     	mul	x8, x8, x9
1000a5db0:     	eor	x11, x8, x8, lsr #31
1000a5db4:     	mov	x4, x22
1000a5db8:     	ldr	x8, [sp, #0xb8]
1000a5dbc:     	add	x10, x8, x20
1000a5dc0:     	add	x6, x10, #0x1
1000a5dc4:     	add	x30, x10, #0x2
1000a5dc8:     	add	x28, x10, #0x3
1000a5dcc:     	add	x16, x10, #0x4
1000a5dd0:     	add	x26, x10, #0x5
1000a5dd4:     	add	x15, x10, #0x6
1000a5dd8:     	add	x25, x10, #0x7
1000a5ddc:     	add	x9, x10, #0x8
1000a5de0:     	add	x8, x10, #0x9
1000a5de4:     	stp	x9, x8, [sp, #0x100]
1000a5de8:     	add	x9, x10, #0xa
1000a5dec:     	add	x8, x10, #0xb
1000a5df0:     	stp	x9, x8, [sp, #0x110]
1000a5df4:     	add	x9, x10, #0xc
1000a5df8:     	add	x8, x10, #0xd
1000a5dfc:     	str	x8, [sp, #0xd0]
1000a5e00:     	add	x19, x10, #0xe
1000a5e04:     	add	x8, x10, #0xf
1000a5e08:     	stp	x9, x8, [sp, #0x120]
1000a5e0c:     	add	x9, x10, #0x10
1000a5e10:     	add	x8, x10, #0x11
1000a5e14:     	stp	x9, x8, [sp, #0x130]
1000a5e18:     	add	x9, x10, #0x12
1000a5e1c:     	add	x8, x10, #0x13
1000a5e20:     	stp	x9, x8, [sp, #0x140]
1000a5e24:     	add	x8, x10, #0x14
1000a5e28:     	str	x8, [sp, #0x150]
1000a5e2c:     	add	x9, x10, #0x15
1000a5e30:     	add	x21, x10, #0x16
1000a5e34:     	add	x23, x10, #0x17
1000a5e38:     	add	x27, x10, #0x18
1000a5e3c:     	add	x2, x10, #0x19
1000a5e40:     	add	x8, x10, #0x1a
1000a5e44:     	stp	x9, x8, [sp, #0xd8]
1000a5e48:     	add	x12, x10, #0x1b
1000a5e4c:     	add	x14, x10, #0x1c
1000a5e50:     	add	x7, x10, #0x1d
1000a5e54:     	add	x8, x10, #0x1e
1000a5e58:     	str	x8, [sp, #0xf8]
1000a5e5c:     	ldr	x3, [x0]
1000a5e60:     	add	x8, x10, #0x1f
1000a5e64:     	str	x8, [sp, #0xe8]
1000a5e68:     	cbz	x3, 0x1000a606c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x738>
1000a5e6c:     	udiv	x8, x11, x3
1000a5e70:     	msub	x11, x8, x3, x11
1000a5e74:     	ldr	x22, [x0, #0x10]
1000a5e78:     	mov	x13, x3
1000a5e7c:     	mov	x8, x3
1000a5e80:     	b	0x1000a5ea0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x56c>
1000a5e84:     	cmp	x8, x3
1000a5e88:     	csel	x8, x11, x8, eq
1000a5e8c:     	add	x9, x11, #0x1
1000a5e90:     	cmp	x9, x3
1000a5e94:     	csinc	x11, xzr, x11, hs
1000a5e98:     	subs	x13, x13, #0x1
1000a5e9c:     	b.eq	0x1000a6070 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x73c>
1000a5ea0:     	madd	x1, x11, x17, x22
1000a5ea4:     	ldr	w9, [x1]
1000a5ea8:     	cmp	w9, #0x1
1000a5eac:     	b.eq	0x1000a5e84 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x550>
1000a5eb0:     	cmp	w9, #0x2
1000a5eb4:     	b.ne	0x1000a61e4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x8b0>
1000a5eb8:     	ldr	x9, [x1, #0x8]
1000a5ebc:     	cmp	x9, x24
1000a5ec0:     	b.ne	0x1000a5e8c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x558>
1000a5ec4:     	mov	x9, x2
1000a5ec8:     	mov	x11, x27
1000a5ecc:     	mov	x8, x23
1000a5ed0:     	ldr	x13, [x1, #0x10]
1000a5ed4:     	str	x13, [sp, #0xa8]
1000a5ed8:     	ldr	x13, [x1, #0x18]
1000a5edc:     	stp	x10, x6, [x1, #0x10]
1000a5ee0:     	ldr	x10, [x1, #0x20]
1000a5ee4:     	stp	x10, x13, [sp, #0x80]
1000a5ee8:     	ldr	x10, [x1, #0x28]
1000a5eec:     	str	x10, [sp, #0x78]
1000a5ef0:     	stp	x30, x28, [x1, #0x20]
1000a5ef4:     	ldr	x10, [x1, #0x30]
1000a5ef8:     	str	x10, [sp, #0x70]
1000a5efc:     	ldr	x10, [x1, #0x38]
1000a5f00:     	str	x10, [sp, #0x68]
1000a5f04:     	stp	x16, x26, [x1, #0x30]
1000a5f08:     	ldr	x10, [x1, #0x40]
1000a5f0c:     	str	x10, [sp, #0x60]
1000a5f10:     	ldr	x10, [x1, #0x48]
1000a5f14:     	str	x10, [sp, #0x58]
1000a5f18:     	stp	x15, x25, [x1, #0x40]
1000a5f1c:     	ldr	x10, [x1, #0x50]
1000a5f20:     	str	x10, [sp, #0x50]
1000a5f24:     	ldr	x10, [x1, #0x58]
1000a5f28:     	str	x10, [sp, #0x48]
1000a5f2c:     	ldr	x10, [sp, #0x100]
1000a5f30:     	str	x10, [x1, #0x50]
1000a5f34:     	ldr	x10, [sp, #0x108]
1000a5f38:     	str	x10, [x1, #0x58]
1000a5f3c:     	ldr	x10, [x1, #0x60]
1000a5f40:     	str	x10, [sp, #0x108]
1000a5f44:     	ldr	x10, [x1, #0x68]
1000a5f48:     	str	x10, [sp, #0x100]
1000a5f4c:     	ldr	x10, [sp, #0x110]
1000a5f50:     	str	x10, [x1, #0x60]
1000a5f54:     	ldr	x10, [sp, #0x118]
1000a5f58:     	str	x10, [x1, #0x68]
1000a5f5c:     	ldr	x10, [x1, #0x70]
1000a5f60:     	str	x10, [sp, #0x118]
1000a5f64:     	ldr	x10, [x1, #0x78]
1000a5f68:     	str	x10, [sp, #0x110]
1000a5f6c:     	ldr	x10, [sp, #0x120]
1000a5f70:     	str	x10, [x1, #0x70]
1000a5f74:     	ldp	x10, x13, [sp, #0xd0]
1000a5f78:     	str	x10, [x1, #0x78]
1000a5f7c:     	ldp	x10, x28, [x1, #0x80]
1000a5f80:     	str	x10, [sp, #0x120]
1000a5f84:     	ldr	x10, [sp, #0x128]
1000a5f88:     	stp	x19, x10, [x1, #0x80]
1000a5f8c:     	ldp	x26, x25, [x1, #0x90]
1000a5f90:     	ldr	x10, [sp, #0x130]
1000a5f94:     	str	x10, [x1, #0x90]
1000a5f98:     	ldr	x10, [sp, #0x138]
1000a5f9c:     	str	x10, [x1, #0x98]
1000a5fa0:     	ldp	x19, x6, [x1, #0xa0]
1000a5fa4:     	ldr	x10, [sp, #0x140]
1000a5fa8:     	str	x10, [x1, #0xa0]
1000a5fac:     	ldp	x10, x15, [sp, #0x148]
1000a5fb0:     	str	x10, [x1, #0xa8]
1000a5fb4:     	ldp	x3, x10, [x1, #0xb0]
1000a5fb8:     	stp	x15, x13, [x1, #0xb0]
1000a5fbc:     	ldp	x22, x23, [x1, #0xc0]
1000a5fc0:     	stp	x21, x8, [x1, #0xc0]
1000a5fc4:     	ldp	x27, x2, [x1, #0xd0]
1000a5fc8:     	stp	x11, x9, [x1, #0xd0]
1000a5fcc:     	ldp	x11, x13, [x1, #0xe0]
1000a5fd0:     	ldp	x9, x0, [sp, #0xe0]
1000a5fd4:     	stp	x9, x12, [x1, #0xe0]
1000a5fd8:     	ldp	x9, x15, [x1, #0xf0]
1000a5fdc:     	stp	x14, x7, [x1, #0xf0]
1000a5fe0:     	ldp	x16, x12, [x1, #0x100]
1000a5fe4:     	ldr	x7, [sp, #0xf8]
1000a5fe8:     	stp	x7, x0, [x1, #0x100]
1000a5fec:     	mov	x0, x4
1000a5ff0:     	ldr	w21, [x1, #0x4]
1000a5ff4:     	ldr	w4, [sp, #0x2c]
1000a5ff8:     	mov	w30, #0x2               ; =2
1000a5ffc:     	stp	w30, w4, [x1]
1000a6000:     	mov	x1, x12
1000a6004:     	mov	x7, x15
1000a6008:     	mov	x14, x9
1000a600c:     	mov	w9, #0x0                ; =0
1000a6010:     	mov	x12, x11
1000a6014:     	mov	x4, x10
1000a6018:     	stp	x6, x3, [sp, #0x148]
1000a601c:     	mov	x3, x22
1000a6020:     	stp	x25, x19, [sp, #0x138]
1000a6024:     	stp	x28, x26, [sp, #0x128]
1000a6028:     	ldp	x11, x19, [sp, #0x118]
1000a602c:     	ldr	x10, [sp, #0x100]
1000a6030:     	stp	x10, x11, [sp, #0x118]
1000a6034:     	ldp	x11, x8, [sp, #0x108]
1000a6038:     	ldr	x10, [sp, #0x48]
1000a603c:     	stp	x10, x11, [sp, #0x108]
1000a6040:     	ldp	x10, x25, [sp, #0x50]
1000a6044:     	stp	x16, x10, [sp, #0xf8]
1000a6048:     	ldp	x15, x26, [sp, #0x60]
1000a604c:     	ldp	x16, x28, [sp, #0x70]
1000a6050:     	ldp	x30, x6, [sp, #0x80]
1000a6054:     	ldr	x10, [sp, #0xa8]
1000a6058:     	str	w21, [sp, #0x2c]
1000a605c:     	mov	x21, x8
1000a6060:     	mov	x22, x0
1000a6064:     	ldr	x0, [sp, #0x90]
1000a6068:     	b	0x1000a620c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x8d8>
1000a606c:     	mov	x8, #0x0                ; =0
1000a6070:     	mov	w9, #0x1                ; =1
1000a6074:     	cmp	x8, x3
1000a6078:     	b.hs	0x1000a61f8 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x8c4>
1000a607c:     	mov	x22, x4
1000a6080:     	cmp	x4, #0x2, lsl #12       ; =0x2000
1000a6084:     	mov	x13, x12
1000a6088:     	mov	x3, x21
1000a608c:     	b.hs	0x1000a61dc <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x8a8>
1000a6090:     	add	x22, x22, #0x1
1000a6094:     	str	x22, [x0, #0x18]
1000a6098:     	ldr	x9, [x0, #0x10]
1000a609c:     	madd	x1, x8, x17, x9
1000a60a0:     	ldr	w11, [x1]
1000a60a4:     	cmp	w11, #0x1
1000a60a8:     	str	x22, [sp, #0xa8]
1000a60ac:     	b.ne	0x1000a60c4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x790>
1000a60b0:     	ldr	x8, [sp, #0x30]
1000a60b4:     	subs	x8, x8, #0x1
1000a60b8:     	csel	x8, xzr, x8, lo
1000a60bc:     	str	x8, [sp, #0x30]
1000a60c0:     	str	x8, [x0, #0x20]
1000a60c4:     	ldp	x9, x8, [x1, #0x8]
1000a60c8:     	stp	x8, x9, [sp, #0x80]
1000a60cc:     	stp	x24, x10, [x1, #0x8]
1000a60d0:     	ldp	x9, x8, [x1, #0x18]
1000a60d4:     	stp	x8, x9, [sp, #0x70]
1000a60d8:     	stp	x6, x30, [x1, #0x18]
1000a60dc:     	ldp	x9, x8, [x1, #0x28]
1000a60e0:     	stp	x8, x9, [sp, #0x60]
1000a60e4:     	stp	x28, x16, [x1, #0x28]
1000a60e8:     	ldp	x9, x8, [x1, #0x38]
1000a60ec:     	stp	x8, x9, [sp, #0x50]
1000a60f0:     	stp	x26, x15, [x1, #0x38]
1000a60f4:     	ldp	x9, x8, [x1, #0x48]
1000a60f8:     	stp	x8, x9, [sp, #0x40]
1000a60fc:     	ldr	x8, [sp, #0x100]
1000a6100:     	stp	x25, x8, [x1, #0x48]
1000a6104:     	ldp	x9, x8, [x1, #0x58]
1000a6108:     	str	x8, [sp, #0x38]
1000a610c:     	ldp	x10, x8, [sp, #0x108]
1000a6110:     	stp	x10, x8, [x1, #0x58]
1000a6114:     	ldp	x10, x8, [x1, #0x68]
1000a6118:     	str	x10, [sp, #0x110]
1000a611c:     	stp	x9, x8, [sp, #0x100]
1000a6120:     	ldp	x9, x8, [sp, #0x118]
1000a6124:     	stp	x9, x8, [x1, #0x68]
1000a6128:     	ldp	x8, x21, [x1, #0x78]
1000a612c:     	str	x8, [sp, #0x120]
1000a6130:     	ldr	x8, [sp, #0xd0]
1000a6134:     	stp	x8, x19, [x1, #0x78]
1000a6138:     	ldp	x12, x25, [x1, #0x88]
1000a613c:     	ldp	x9, x8, [sp, #0x128]
1000a6140:     	stp	x9, x8, [x1, #0x88]
1000a6144:     	ldp	x15, x16, [x1, #0x98]
1000a6148:     	ldp	x9, x8, [sp, #0x138]
1000a614c:     	stp	x9, x8, [x1, #0x98]
1000a6150:     	ldp	x9, x4, [x1, #0xa8]
1000a6154:     	ldp	x10, x8, [sp, #0x148]
1000a6158:     	stp	x10, x8, [x1, #0xa8]
1000a615c:     	ldp	x8, x22, [x1, #0xb8]
1000a6160:     	ldp	x10, x0, [sp, #0xd8]
1000a6164:     	stp	x10, x3, [x1, #0xb8]
1000a6168:     	ldp	x3, x30, [x1, #0xc8]
1000a616c:     	stp	x23, x27, [x1, #0xc8]
1000a6170:     	ldp	x10, x6, [x1, #0xd8]
1000a6174:     	stp	x2, x0, [x1, #0xd8]
1000a6178:     	ldp	x24, x27, [x1, #0xe8]
1000a617c:     	stp	x13, x14, [x1, #0xe8]
1000a6180:     	ldp	x28, x0, [x1, #0xf8]
1000a6184:     	ldr	x13, [sp, #0xf8]
1000a6188:     	stp	x7, x13, [x1, #0xf8]
1000a618c:     	ldr	x26, [x1, #0x108]
1000a6190:     	ldr	x13, [sp, #0xe8]
1000a6194:     	str	x13, [x1, #0x108]
1000a6198:     	ldr	w13, [x1, #0x4]
1000a619c:     	ldr	w2, [sp, #0xa4]
1000a61a0:     	mov	w19, #0x2               ; =2
1000a61a4:     	stp	w19, w2, [x1]
1000a61a8:     	strb	wzr, [sp, #0x15c]
1000a61ac:     	cmp	w11, #0x2
1000a61b0:     	b.hs	0x1000a59d4 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0xa0>
1000a61b4:     	ldr	x14, [sp, #0xf0]
1000a61b8:     	mul	x14, x14, x5
1000a61bc:     	str	w13, [sp, #0xa4]
1000a61c0:     	ldr	x0, [sp, #0x90]
1000a61c4:     	ldr	x22, [sp, #0xa8]
1000a61c8:     	add	x20, x20, #0x1
1000a61cc:     	ldr	x8, [sp, #0xc0]
1000a61d0:     	cmp	x20, x8
1000a61d4:     	b.ne	0x1000a5b28 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x1f4>
1000a61d8:     	b	0x1000a59a0 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x6c>
1000a61dc:     	ldp	x12, x1, [sp, #0xe0]
1000a61e0:     	b	0x1000a6208 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x8d4>
1000a61e4:     	cmp	x8, x3
1000a61e8:     	csel	x8, x11, x8, eq
1000a61ec:     	mov	w9, #0x1                ; =1
1000a61f0:     	cmp	x8, x3
1000a61f4:     	b.lo	0x1000a607c <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x748>
1000a61f8:     	mov	x13, x12
1000a61fc:     	ldp	x12, x1, [sp, #0xe0]
1000a6200:     	mov	x3, x21
1000a6204:     	mov	x22, x4
1000a6208:     	ldp	x21, x4, [sp, #0xd0]
1000a620c:     	strb	w9, [sp, #0x15c]
1000a6210:     	ldr	x11, [sp, #0xf8]
1000a6214:     	b	0x1000a5a50 <_wf_flat_mutation_batch$instance$4250cb78d3f44027+0x11c>
1000a6218:     	ldr	x8, [sp, #0x10]
1000a621c:     	add	x8, x10, x8
1000a6220:     	str	x8, [x0, #0x48]
1000a6224:     	mov	x14, x9
1000a6228:     	eor	x8, x14, x14, lsr #30
1000a622c:     	mov	x9, #0xe5b9             ; =58809
1000a6230:     	movk	x9, #0x1ce4, lsl #16
1000a6234:     	movk	x9, #0x476d, lsl #32
1000a6238:     	movk	x9, #0xbf58, lsl #48
1000a623c:     	mul	x8, x8, x9
1000a6240:     	eor	x8, x8, x8, lsr #27
1000a6244:     	mov	x9, #0x11eb             ; =4587
1000a6248:     	movk	x9, #0x1331, lsl #16
1000a624c:     	movk	x9, #0x49bb, lsl #32
1000a6250:     	movk	x9, #0x94d0, lsl #48
1000a6254:     	mul	x8, x8, x9
1000a6258:     	eor	x0, x8, x8, lsr #31
1000a625c:     	ldp	x29, x30, [sp, #0x1b0]
1000a6260:     	ldp	x20, x19, [sp, #0x1a0]
1000a6264:     	ldp	x22, x21, [sp, #0x190]
1000a6268:     	ldp	x24, x23, [sp, #0x180]
1000a626c:     	ldp	x26, x25, [sp, #0x170]
1000a6270:     	ldp	x28, x27, [sp, #0x160]
1000a6274:     	add	sp, sp, #0x1c0
1000a6278:     	ret

