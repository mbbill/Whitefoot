// Isolated replacement/churn peer. Preparation, verification and full cleanup
// are separate calls; batch construction and returned-value consumption stay
// inside the operation interval. Retire with the scratch mutation experiment.
#include <array>
#include <cstdint>
#include <cstdlib>
#include <functional>
#include <memory>
#include <new>
#include <unordered_map>
#include <utility>

#ifdef ACCOUNT_ONLY
#include "../../../../ecosystem-allocator.hpp"
template<class T> using NativeAllocator = EcosystemAllocator<T>;
#else
template<class T> using NativeAllocator = std::allocator<T>;
#endif

namespace {
using Word = std::uint64_t;
struct Record {
    std::array<Word, 32> words;
    Record() = default;
    Record(const Record&) = delete;
    Record& operator=(const Record&) = delete;
    Record(Record&&) noexcept = default;
    Record& operator=(Record&&) noexcept = default;
};
static_assert(sizeof(Word) == 8);
static_assert(sizeof(Record) == 256);

Word mix(Word value) {
    value ^= value >> 30; value *= UINT64_C(0xbf58476d1ce4e5b9);
    value ^= value >> 27; value *= UINT64_C(0x94d049bb133111eb);
    return value ^ (value >> 31);
}
struct AlignedHash {
    Word salt;
    bool collide;
    std::size_t operator()(Word key) const {
        return collide ? 0 : mix(key ^ salt);
    }
};

template<class V> struct Payload;
template<> struct Payload<Word> {
    static Word make(Word seed) { return seed; }
    static Word identity(const Word& value) { return value; }
    static Word content(Word key, Word value) { return key * 131 + value; }
};
template<> struct Payload<Record> {
    static Record make(Word seed) {
        Record value;
        for (std::size_t index = 0; index < value.words.size(); ++index)
            value.words[index] = seed + index;
        return value;
    }
    static Word identity(const Record& value) { return value.words[0]; }
    static Word content(Word key, Record value) {
        for (Word word : value.words) key = key * 131 + word;
        return key;
    }
};
struct Digest {
    Word ordered_value, sum = 0, parity = 0, count = 0;
    explicit Digest(Word seed) : ordered_value(seed) {}
    void ordered(Word value) { ordered_value = ordered_value * 131 + value; }
    void consume(Word value) { sum += value; parity ^= mix(value); ++count; }
    Word finish() const {
        return mix(ordered_value) ^ mix(sum) ^ parity
            ^ (count * UINT64_C(0x9e3779b97f4a7c15));
    }
};
Word key_at(Word index) { return index * 2 + 1; }

template<class V>
using Map = std::unordered_map<Word, V, AlignedHash, std::equal_to<Word>,
                              NativeAllocator<std::pair<const Word, V>>>;

template<class V> struct MutationOwner {
    Map<V> map;
    Word count, seed, generation = 0;
    MutationOwner(Word count, Word seed)
        : map(0, AlignedHash{seed ^ UINT64_C(0x9e3779b97f4a7c15), false}),
          count(count), seed(seed) {}
};

template<class V>
void prepare(void* storage, Word slots, Word count, Word seed) {
    static_assert(sizeof(MutationOwner<V>) <= 128, "owner fits caller storage");
    static_assert(alignof(MutationOwner<V>) <= 16, "owner fits caller alignment");
    if (count > slots || slots > 8192) std::abort();
    auto* owner = new (storage) MutationOwner<V>(count, seed);
    owner->map.reserve(slots);
    for (Word index = 0; index < count; ++index)
        owner->map.try_emplace(key_at(index), Payload<V>::make(seed + index));
    if (owner->map.size() != count || owner->map.bucket_count() > UINT32_MAX)
        std::abort();
}

template<class V>
Word batch(void* storage, Word rounds, Word operation) {
    auto& owner = *static_cast<MutationOwner<V>*>(storage);
    Digest digest(owner.seed);
    for (Word round = 0; round < rounds; ++round) {
        Word next_generation = owner.generation + 1;
        Word base = owner.seed + next_generation * owner.count;
        for (Word index = 0; index < owner.count; ++index) {
            Word key = key_at(index);
            if (operation != 0) {
                auto removed = owner.map.extract(key);
                digest.ordered(!removed.empty());
                if (!removed.empty())
                    digest.ordered(Payload<V>::content(removed.key(),
                                                       std::move(removed.mapped())));
                // The detached node is destroyed here, before construction and
                // try_emplace below. Churn therefore frees and allocates nodes;
                // it does not recycle a node handle across the insertion.
            }
            V offered = Payload<V>::make(base + index);
            auto [entry, inserted] = owner.map.try_emplace(key, std::move(offered));
            digest.ordered(inserted ? 0 : 1);
            if (!inserted) {
                // Failed try_emplace preserves offered. Observe the complete
                // displaced payload, including all 32 words for Record.
                V previous = std::exchange(entry->second, std::move(offered));
                digest.ordered(Payload<V>::content(entry->first, std::move(previous)));
            }
        }
        owner.generation = next_generation;
    }
    return digest.finish();
}

template<class V>
Word geometry(const void* storage) {
    const auto& owner = *static_cast<const MutationOwner<V>*>(storage);
    // This is the actual chaining bucket count, not a payload-slot count.
    return (Word(owner.map.bucket_count()) << 32) | Word(owner.map.size());
}

template<class V>
Word verify(const void* storage) {
    const auto& owner = *static_cast<const MutationOwner<V>*>(storage);
    Digest digest(owner.seed);
    for (Word index = 0; index < owner.count; ++index) {
        Word key = key_at(index);
        auto found = owner.map.find(key);
        digest.ordered(found != owner.map.end());
        if (found != owner.map.end())
            digest.ordered(Payload<V>::identity(found->second));
        auto missing = owner.map.find(key + 1);
        digest.ordered(missing != owner.map.end());
        if (missing != owner.map.end())
            digest.ordered(Payload<V>::identity(missing->second));
    }
    return digest.finish();
}

template<class V>
Word finish(void* storage) {
    auto* owner = static_cast<MutationOwner<V>*>(storage);
    Digest digest(owner->seed);
    for (auto& [key, value] : owner->map)
        digest.consume(Payload<V>::content(key, std::move(value)));
    Word result = digest.finish();
    std::destroy_at(owner);
    return result;
}
} // namespace

#define MUTATION_ENTRY(WIDTH, VALUE)                                     \
extern "C" void eco_cpp_map_mutation_##WIDTH##_prepare(                  \
    void* storage, Word slots, Word count, Word seed) {                   \
    prepare<VALUE>(storage, slots, count, seed);                          \
}                                                                       \
extern "C" Word eco_cpp_map_mutation_##WIDTH##_batch(                    \
    void* storage, Word rounds, Word operation) {                        \
    return batch<VALUE>(storage, rounds, operation);                      \
}                                                                       \
extern "C" Word eco_cpp_map_mutation_##WIDTH##_geometry(                 \
    const void* storage) { return geometry<VALUE>(storage); }             \
extern "C" Word eco_cpp_map_mutation_##WIDTH##_verify(                   \
    const void* storage) { return verify<VALUE>(storage); }               \
extern "C" Word eco_cpp_map_mutation_##WIDTH##_finish(void* storage) {   \
    return finish<VALUE>(storage);                                       \
}

MUTATION_ENTRY(word, Word)
MUTATION_ENTRY(record, Record)
