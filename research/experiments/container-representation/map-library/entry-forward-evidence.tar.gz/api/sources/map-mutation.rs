//! Scratch ordinary HashMap replacement/churn comparator. Retire with the
//! rejected experiment or promote into the maintained map harness if selected.
use std::collections::HashMap;
use std::ffi::c_void;
use std::hash::{BuildHasher, Hasher};

#[cfg(account_only)]
#[path = "../../../../ecosystem-allocator.rs"]
mod ecosystem_allocator;

fn mix(mut value: u64) -> u64 {
    value ^= value >> 30;
    value = value.wrapping_mul(0xbf58_476d_1ce4_e5b9);
    value ^= value >> 27;
    value = value.wrapping_mul(0x94d0_49bb_1331_11eb);
    value ^ (value >> 31)
}

struct AlignedBuild {
    salt: u64,
    collide: bool,
}

struct AlignedHasher {
    salt: u64,
    collide: bool,
    hash: u64,
}

impl BuildHasher for AlignedBuild {
    type Hasher = AlignedHasher;

    fn build_hasher(&self) -> Self::Hasher {
        AlignedHasher {
            salt: self.salt,
            collide: self.collide,
            hash: 0,
        }
    }
}

impl Hasher for AlignedHasher {
    fn finish(&self) -> u64 {
        self.hash
    }

    fn write_u64(&mut self, value: u64) {
        self.hash = if self.collide {
            0
        } else {
            mix(value ^ self.salt)
        };
    }

    fn write(&mut self, bytes: &[u8]) {
        let word: [u8; 8] = bytes.try_into().expect("the aligned key is one u64");
        self.write_u64(u64::from_ne_bytes(word));
    }
}

trait Payload {
    fn make(seed: u64) -> Self;
    fn identity(&self) -> u64;
    fn content(self, key: u64) -> u64;
}

impl Payload for u64 {
    fn make(seed: u64) -> Self {
        seed
    }

    fn identity(&self) -> u64 {
        *self
    }

    fn content(self, key: u64) -> u64 {
        key.wrapping_mul(131).wrapping_add(self)
    }
}

struct Record {
    words: [u64; 32],
}

impl Payload for Record {
    fn make(seed: u64) -> Self {
        Self {
            words: std::array::from_fn(|index| seed.wrapping_add(index as u64)),
        }
    }

    fn identity(&self) -> u64 {
        self.words[0]
    }

    fn content(self, mut key: u64) -> u64 {
        for word in self.words {
            key = key.wrapping_mul(131).wrapping_add(word);
        }
        key
    }
}

struct Digest {
    ordered: u64,
    sum: u64,
    parity: u64,
    count: u64,
}

impl Digest {
    fn new(seed: u64) -> Self {
        Self {
            ordered: seed,
            sum: 0,
            parity: 0,
            count: 0,
        }
    }

    fn ordered(&mut self, value: u64) {
        self.ordered = self.ordered.wrapping_mul(131).wrapping_add(value);
    }

    fn consume(&mut self, value: u64) {
        self.sum = self.sum.wrapping_add(value);
        self.parity ^= mix(value);
        self.count = self.count.wrapping_add(1);
    }

    fn finish(self) -> u64 {
        mix(self.ordered)
            ^ mix(self.sum)
            ^ self.parity
            ^ self.count.wrapping_mul(0x9e37_79b9_7f4a_7c15)
    }
}

fn key_at(index: u64) -> u64 {
    index.wrapping_mul(2).wrapping_add(1)
}

struct MutationState<V> {
    map: HashMap<u64, V, AlignedBuild>,
    count: u64,
    seed: u64,
    generation: u64,
}

unsafe fn mutation_prepare<V: Payload>(storage: *mut c_void, slots: u64, count: u64, seed: u64) {
    assert!(std::mem::size_of::<MutationState<V>>() <= 128);
    assert!(std::mem::align_of::<MutationState<V>>() <= 16);
    assert!(!storage.is_null() && (storage as usize) % 16 == 0);
    assert!(count <= slots && slots <= 8192);
    let mut map = HashMap::with_capacity_and_hasher(
        usize::try_from(slots / 2).expect("mutation capacity fits usize"),
        AlignedBuild {
            salt: seed ^ 0x9e37_79b9_7f4a_7c15,
            collide: false,
        },
    );
    assert!(count <= map.capacity() as u64);
    for index in 0..count {
        map.insert(key_at(index), V::make(seed.wrapping_add(index)));
    }
    // Fresh caller-owned storage holds the native descriptor, without a Box.
    unsafe {
        storage.cast::<MutationState<V>>().write(MutationState {
            map,
            count,
            seed,
            generation: 0,
        })
    };
}

unsafe fn mutation_batch<V: Payload>(storage: *mut c_void, rounds: u64, operation: u64) -> u64 {
    let state = unsafe { &mut *storage.cast::<MutationState<V>>() };
    let mut digest = Digest::new(state.seed);
    for _ in 0..rounds {
        let next_generation = state.generation.wrapping_add(1);
        let base = state
            .seed
            .wrapping_add(next_generation.wrapping_mul(state.count));
        for index in 0..state.count {
            let key = key_at(index);
            if operation != 0 {
                let removed = state.map.remove_entry(&key);
                digest.ordered(u64::from(removed.is_some()));
                if let Some((old_key, value)) = removed {
                    digest.ordered(value.content(old_key));
                }
            }
            // Payload construction belongs to the ordinary timed insert call.
            let old = state.map.insert(key, V::make(base.wrapping_add(index)));
            digest.ordered(u64::from(old.is_some()));
            if let Some(value) = old {
                // Equal integer keys have identical content in the WF pair.
                digest.ordered(value.content(key));
            }
        }
        state.generation = next_generation;
    }
    digest.finish()
}

unsafe fn mutation_geometry<V>(storage: *const c_void) -> u64 {
    let state = unsafe { &*storage.cast::<MutationState<V>>() };
    // Report Rust's usable capacity, not an invented physical slot count.
    let usable = u32::try_from(state.map.capacity()).expect("mutation capacity fits geometry");
    let length = u32::try_from(state.map.len()).expect("mutation length fits geometry");
    (u64::from(usable) << 32) | u64::from(length)
}

unsafe fn mutation_verify<V: Payload>(storage: *const c_void) -> u64 {
    let state = unsafe { &*storage.cast::<MutationState<V>>() };
    let mut digest = Digest::new(state.seed);
    for index in 0..state.count {
        let key = key_at(index);
        let found = state.map.get(&key);
        digest.ordered(u64::from(found.is_some()));
        if let Some(value) = found {
            digest.ordered(value.identity());
        }
        let missing = state.map.get(&key.wrapping_add(1));
        digest.ordered(u64::from(missing.is_some()));
        if let Some(value) = missing {
            digest.ordered(value.identity());
        }
    }
    digest.finish()
}

unsafe fn mutation_finish<V: Payload>(storage: *mut c_void) -> u64 {
    // Consume once; caller storage is uninitialized again after this call.
    let MutationState { map, seed, .. } = unsafe { storage.cast::<MutationState<V>>().read() };
    let mut digest = Digest::new(seed);
    for (key, value) in map {
        digest.consume(value.content(key));
    }
    digest.finish()
}

macro_rules! mutation_exports {
    ($value:ty, $prepare:ident, $batch:ident, $geometry:ident, $verify:ident, $finish:ident) => {
        #[unsafe(no_mangle)]
        pub unsafe extern "C" fn $prepare(storage: *mut c_void, slots: u64, count: u64, seed: u64) {
            unsafe { mutation_prepare::<$value>(storage, slots, count, seed) }
        }

        #[unsafe(no_mangle)]
        pub unsafe extern "C" fn $batch(storage: *mut c_void, rounds: u64, operation: u64) -> u64 {
            unsafe { mutation_batch::<$value>(storage, rounds, operation) }
        }

        #[unsafe(no_mangle)]
        pub unsafe extern "C" fn $geometry(storage: *const c_void) -> u64 {
            unsafe { mutation_geometry::<$value>(storage) }
        }

        #[unsafe(no_mangle)]
        pub unsafe extern "C" fn $verify(storage: *const c_void) -> u64 {
            unsafe { mutation_verify::<$value>(storage) }
        }

        #[unsafe(no_mangle)]
        pub unsafe extern "C" fn $finish(storage: *mut c_void) -> u64 {
            unsafe { mutation_finish::<$value>(storage) }
        }
    };
}

mutation_exports!(
    u64,
    eco_rust_map_mutation_word_prepare,
    eco_rust_map_mutation_word_batch,
    eco_rust_map_mutation_word_geometry,
    eco_rust_map_mutation_word_verify,
    eco_rust_map_mutation_word_finish
);
mutation_exports!(
    Record,
    eco_rust_map_mutation_record_prepare,
    eco_rust_map_mutation_record_batch,
    eco_rust_map_mutation_record_geometry,
    eco_rust_map_mutation_record_verify,
    eco_rust_map_mutation_record_finish
);
