#define _POSIX_C_SOURCE 200809L
#include <inttypes.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

enum { WORDS = 32, IMPLEMENTATIONS = 4, SAMPLES = 9 };
typedef struct { uint64_t ordered, sum, parity, count; } Digest;
typedef union { max_align_t alignment; _Alignas(16) unsigned char bytes[128]; } Storage;
_Static_assert(_Alignof(Storage) >= 16 && sizeof(Storage) >= 128, "owner ABI");
typedef void (*Prepare)(void *, uint64_t, uint64_t, uint64_t);
typedef uint64_t (*Batch)(void *, uint64_t, uint64_t);
typedef uint64_t (*Observe)(const void *);
typedef uint64_t (*Finish)(void *);
typedef struct {
    const char *name, *capacity_kind;
    bool wide;
    Prepare prepare;
    Batch batch;
    Observe geometry, verify;
    Finish finish;
} Api;

#define MUTATION_DECLARE(PREFIX, WIDTH) \
    extern void PREFIX##_mutation_##WIDTH##_prepare(void *, uint64_t, uint64_t, uint64_t); \
    extern uint64_t PREFIX##_mutation_##WIDTH##_batch(void *, uint64_t, uint64_t); \
    extern uint64_t PREFIX##_mutation_##WIDTH##_geometry(const void *); \
    extern uint64_t PREFIX##_mutation_##WIDTH##_verify(const void *); \
    extern uint64_t PREFIX##_mutation_##WIDTH##_finish(void *)
MUTATION_DECLARE(wf_flat, word);
MUTATION_DECLARE(wf_chain, word);
MUTATION_DECLARE(eco_rust_map, word);
MUTATION_DECLARE(eco_cpp_map, word);
MUTATION_DECLARE(wf_flat, record);
MUTATION_DECLARE(wf_chain, record);
MUTATION_DECLARE(eco_rust_map, record);
MUTATION_DECLARE(eco_cpp_map, record);
#undef MUTATION_DECLARE
#define ENTRY(NAME, KIND, WIDE, PREFIX, WIDTH) \
    {NAME, KIND, WIDE, PREFIX##_mutation_##WIDTH##_prepare, \
     PREFIX##_mutation_##WIDTH##_batch, PREFIX##_mutation_##WIDTH##_geometry, \
     PREFIX##_mutation_##WIDTH##_verify, PREFIX##_mutation_##WIDTH##_finish}
static const Api apis[] = {
    ENTRY("whitefoot-flat", "physical-slots", false, wf_flat, word),
    ENTRY("whitefoot-chain", "head-buckets", false, wf_chain, word),
    ENTRY("rust-hash-map", "usable-entries", false, eco_rust_map, word),
    ENTRY("cpp-unordered-map", "chaining-buckets", false, eco_cpp_map, word),
    ENTRY("whitefoot-flat", "physical-slots", true, wf_flat, record),
    ENTRY("whitefoot-chain", "head-buckets", true, wf_chain, record),
    ENTRY("rust-hash-map", "usable-entries", true, eco_rust_map, record),
    ENTRY("cpp-unordered-map", "chaining-buckets", true, eco_cpp_map, record),
};
#undef ENTRY

static volatile uint64_t observed;
static void require(bool condition, const char *message) {
    if (!condition) { fprintf(stderr, "mutation: %s\n", message); exit(1); }
}
static uint64_t mix(uint64_t value) {
    value ^= value >> 30; value *= UINT64_C(0xbf58476d1ce4e5b9);
    value ^= value >> 27; value *= UINT64_C(0x94d049bb133111eb);
    return value ^ (value >> 31);
}
static void ordered(Digest *digest, uint64_t value) {
    digest->ordered = digest->ordered * UINT64_C(131) + value;
}
static void final_value(Digest *digest, uint64_t value) {
    digest->sum += value; digest->parity ^= mix(value); ++digest->count;
}
static uint64_t finish(Digest digest) {
    return mix(digest.ordered) ^ mix(digest.sum) ^ digest.parity
        ^ digest.count * UINT64_C(0x9e3779b97f4a7c15);
}
static uint64_t content(bool wide, uint64_t key, uint64_t first) {
    for (unsigned i = 0; i < (wide ? WORDS : 1); ++i)
        key = key * UINT64_C(131) + first + i;
    return key;
}
static uint64_t expected_batch(bool wide, uint64_t count, uint64_t seed,
                               uint64_t start_generation, uint64_t rounds, uint64_t operation) {
    Digest digest = {seed, 0, 0, 0};
    for (uint64_t round = 0; round < rounds; ++round) {
        uint64_t old_generation = start_generation + round;
        for (uint64_t index = 0; index < count; ++index) {
            uint64_t key = index * 2 + 1;
            uint64_t old_first = seed + old_generation * count + index;
            if (operation != 0) {
                ordered(&digest, 1);
                ordered(&digest, content(wide, key, old_first));
                ordered(&digest, 0);
            } else {
                ordered(&digest, 1);
                ordered(&digest, content(wide, key, old_first));
            }
        }
    }
    return finish(digest);
}
static uint64_t expected_verify(uint64_t count, uint64_t seed, uint64_t generation) {
    Digest digest = {seed, 0, 0, 0};
    for (uint64_t index = 0; index < count; ++index) {
        ordered(&digest, 1);
        ordered(&digest, seed + generation * count + index);
        ordered(&digest, 0);
    }
    return finish(digest);
}
static uint64_t expected_cleanup(bool wide, uint64_t count, uint64_t seed, uint64_t generation) {
    Digest digest = {seed, 0, 0, 0};
    for (uint64_t index = 0; index < count; ++index)
        final_value(&digest, content(wide, index * 2 + 1,
                                    seed + generation * count + index));
    return finish(digest);
}

#ifdef ACCOUNT_ONLY
typedef struct { uint64_t requests, releases, bytes, live, peak; } Ledger;
typedef union { struct { uint64_t bytes, magic; } data; max_align_t alignment; } Header;
static Ledger ledger;
void wf_ecosystem_note_alloc(uint64_t bytes) {
    require(UINT64_MAX - ledger.live >= bytes && UINT64_MAX - ledger.bytes >= bytes,
            "allocation extent");
    ++ledger.requests; ledger.bytes += bytes; ledger.live += bytes;
    if (ledger.live > ledger.peak) ledger.peak = ledger.live;
}
void wf_ecosystem_note_dealloc(uint64_t bytes) {
    require(ledger.live >= bytes, "allocation release extent");
    ++ledger.releases; ledger.live -= bytes;
}
void wf_ecosystem_note_realloc(uint64_t before, uint64_t after) {
    wf_ecosystem_note_dealloc(before); wf_ecosystem_note_alloc(after);
}
void *wf_cost_allocate(uint64_t bytes) {
    require(bytes <= SIZE_MAX - sizeof(Header), "allocation extent");
    Header *header = malloc(sizeof *header + (size_t)bytes);
    require(header != NULL, "host allocation");
    header->data.bytes = bytes; header->data.magic = UINT64_C(0x6d617065636f6e6f);
    wf_ecosystem_note_alloc(bytes); return header + 1;
}
void *wf_cost_reallocate(void *pointer, uint64_t bytes) {
    if (pointer == NULL) return wf_cost_allocate(bytes);
    require(bytes <= SIZE_MAX - sizeof(Header), "reallocation extent");
    Header *header = (Header *)pointer - 1;
    require(header->data.magic == UINT64_C(0x6d617065636f6e6f), "reallocation header");
    uint64_t old_bytes = header->data.bytes;
    Header *replacement = realloc(header, sizeof *header + (size_t)bytes);
    /* NULL preserves the original allocation and its ledger entry. */
    if (replacement == NULL) return NULL;
    replacement->data.bytes = bytes;
    wf_ecosystem_note_realloc(old_bytes, bytes);
    return replacement + 1;
}
void wf_cost_release(void *pointer) {
    if (pointer == NULL) return;
    Header *header = (Header *)pointer - 1;
    require(header->data.magic == UINT64_C(0x6d617065636f6e6f), "allocation header");
    wf_ecosystem_note_dealloc(header->data.bytes); header->data.magic = 0; free(header);
}
static void clean_ledger(void) {
    require(ledger.live == 0 && ledger.requests == ledger.releases, "every allocation reclaimed");
}
#else
static void clean_ledger(void) {}
#endif

static uint64_t expected_capacity(const Api *api, uint64_t slots) {
    return strcmp(api->capacity_kind, "usable-entries") == 0 ? slots - slots / 8 : slots;
}
typedef enum { FAULT_NONE, FAULT_BATCH, FAULT_GENERATION, FAULT_LAST_WORD,
               FAULT_CLEANUP, FAULT_LEDGER_LEAK, FAULT_FILLED_ALLOCATION } Fault;
static void corrupt_last_word(Storage *storage, uint64_t slots) {
    /* Frozen flat WF LLVM: owner begins {len,cap,payload}; wide enum cells
     * are {tag,padding,key,words[32]} with stride 272 and live tag 2. Only this
     * explicit negative reads that representation; ordinary checks are opaque. */
    require(sizeof(void *) == 8, "negative payload ABI");
    unsigned char *payload = NULL;
    memcpy(&payload, storage->bytes + 16, sizeof payload);
    require(payload != NULL, "negative payload pointer");
    for (uint64_t i = 0; i < slots; ++i) {
        uint32_t tag;
        memcpy(&tag, payload + i * 272, sizeof tag);
        if (tag == 2) {
            uint64_t last;
            unsigned char *place = payload + i * 272 + 16 + 31 * 8;
            memcpy(&last, place, sizeof last); last ^= 1;
            memcpy(place, &last, sizeof last);
            return;
        }
    }
    require(false, "negative payload live-cell injection site");
}
static void checked(const Api *api, uint64_t slots, uint64_t seed, uint64_t operation,
                    Fault fault, bool report) {
    const uint64_t count = slots / 2;
    const uint64_t batch_rounds[] = {0, 1, 2};
    uint64_t generation = 0, actual = 0;
    Storage storage = {0};
#ifdef ACCOUNT_ONLY
    clean_ledger(); ledger = (Ledger){0};
#endif
    api->prepare(storage.bytes, slots, count, seed);
    uint64_t geometry = api->geometry(storage.bytes);
    require((uint32_t)geometry == count, "filled population");
    require((geometry >> 32) == expected_capacity(api, slots), "filled capacity");
    require(api->verify(storage.bytes) == expected_verify(count, seed, 0), "prepared key oracle");
#ifdef ACCOUNT_ONLY
    if (fault == FAULT_FILLED_ALLOCATION) ledger.live = 0;
    require(ledger.live != 0, fault == FAULT_FILLED_ALLOCATION
            ? "negative filled allocation" : "filled allocation");
    Ledger before = ledger;
#endif
    for (size_t b = 0; b < sizeof batch_rounds / sizeof *batch_rounds; ++b) {
        uint64_t rounds = batch_rounds[b];
        if (fault == FAULT_LAST_WORD && b == 1) {
            corrupt_last_word(&storage, slots);
            require(api->verify(storage.bytes) == expected_verify(count, seed, generation),
                    "last-word fault preserves the first-word observation");
        }
        /* The frozen flat owner is 80 bytes: generation is the final i64 at 72.
         * Reset only that actual state after a successful previous batch. */
        if (fault == FAULT_GENERATION && b == 2) {
            uint64_t stale = 0;
            memcpy(storage.bytes + 72, &stale, sizeof stale);
        }
        actual = api->batch(storage.bytes, rounds, operation);
        if (fault == FAULT_BATCH && b == 1) actual ^= 1;
        const char *batch_message = fault == FAULT_BATCH ? "negative wrong batch checksum"
            : fault == FAULT_GENERATION ? "negative stale generation"
            : fault == FAULT_LAST_WORD ? "negative corrupt last word full-content"
            : "independent full old-value batch oracle";
        require(actual == expected_batch(api->wide, count, seed, generation, rounds, operation),
                batch_message);
        generation += rounds;
        require(api->geometry(storage.bytes) == geometry, "retained geometry");
        require(api->verify(storage.bytes) == expected_verify(count, seed, generation),
                "independent generation and key oracle");
        observed ^= actual;
    }
#ifdef ACCOUNT_ONLY
    Ledger after = ledger;
    if (operation == 0 || strcmp(api->name, "cpp-unordered-map") != 0) {
        require(memcmp(&before, &after, sizeof before) == 0, "nonallocating batch ledger");
    } else {
        require(after.requests - before.requests == count * generation
                && after.releases - before.releases == count * generation
                && after.live == before.live, "C++ churn node allocation ledger");
    }
    if (fault == FAULT_LEDGER_LEAK) (void)wf_cost_allocate(8);
#endif
    uint64_t cleanup = api->finish(storage.bytes);
    if (fault == FAULT_CLEANUP) cleanup ^= 1;
    require(cleanup == expected_cleanup(api->wide, count, seed, generation),
            fault == FAULT_CLEANUP ? "negative cleanup checksum"
            : "independent full-content cleanup oracle");
#ifdef ACCOUNT_ONLY
    if (fault == FAULT_LEDGER_LEAK)
        require(ledger.live == 0 && ledger.requests == ledger.releases, "negative ledger leak");
    if (report)
        printf("%s,%s,%s,%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%s,%" PRIu64
               ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64
               ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64
               ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 "\n",
               api->name, api->capacity_kind, api->wide ? "wide256" : "word8",
               slots, count, geometry >> 32, operation ? "churn" : "replace", generation,
               before.requests, before.releases, before.bytes, before.live, before.peak,
               after.requests - before.requests, after.releases - before.releases,
               after.bytes - before.bytes, after.live,
               ledger.requests, ledger.releases, ledger.bytes, ledger.live, ledger.peak);
#else
    (void)report;
#endif
    clean_ledger(); observed ^= actual ^ cleanup;
}
static void check_all(void) {
    const uint64_t slots[] = {64, 4096};
    const uint64_t seeds[] = {17, 101, UINT64_MAX};
    unsigned cases = 0;
    for (size_t a = 0; a < sizeof apis / sizeof *apis; ++a)
        for (size_t c = 0; c < sizeof slots / sizeof *slots; ++c)
            for (size_t s = 0; s < sizeof seeds / sizeof *seeds; ++s)
                for (uint64_t op = 0; op < 2; ++op) {
                    checked(&apis[a], slots[c], seeds[s], op, FAULT_NONE, false); ++cases;
                }
    printf("mutation: %u independent owner/three-successive-batches/verify/cleanup cases passed\n", cases);
}
static void negative(const char *kind) {
    Fault fault;
    if (strcmp(kind, "wrong-batch-checksum") == 0) fault = FAULT_BATCH;
    else if (strcmp(kind, "stale-generation") == 0) fault = FAULT_GENERATION;
    else if (strcmp(kind, "corrupt-last-word") == 0) fault = FAULT_LAST_WORD;
    else if (strcmp(kind, "cleanup") == 0) fault = FAULT_CLEANUP;
#ifdef ACCOUNT_ONLY
    else if (strcmp(kind, "ledger-leak") == 0) fault = FAULT_LEDGER_LEAK;
    else if (strcmp(kind, "filled-allocation") == 0) fault = FAULT_FILLED_ALLOCATION;
#endif
    else { require(false, "unknown or unavailable negative control"); return; }
    checked(&apis[4], 64, 101, 0, fault, false);
    /* An uncaught fault returns 0: no always-failing fallback can masquerade
     * as the particular guard this control is intended to exercise. */
    puts("mutation: negative control was not rejected");
}
#ifdef ACCOUNT_ONLY
static void account(void) {
    const uint64_t slots[] = {64, 4096};
    puts("variant,capacity_kind,width,slots,population,capacity,operation,rounds,filled_requests,filled_releases,filled_bytes,filled_live,filled_peak,batch_requests,batch_releases,batch_bytes,batch_live,final_requests,final_releases,final_bytes,final_live,final_peak");
    for (size_t a = 0; a < sizeof apis / sizeof *apis; ++a)
        for (size_t c = 0; c < sizeof slots / sizeof *slots; ++c)
            for (uint64_t op = 0; op < 2; ++op)
                checked(&apis[a], slots[c], 101, op, FAULT_NONE, true);
}
#endif
#ifndef ACCOUNT_ONLY
static uint64_t nanoseconds(void) {
    struct timespec instant;
    require(clock_gettime(CLOCK_MONOTONIC, &instant) == 0, "clock");
    return (uint64_t)instant.tv_sec * UINT64_C(1000000000) + (uint64_t)instant.tv_nsec;
}
static uint64_t parse_work(const char *text) {
    char *end = NULL; unsigned long long work = strtoull(text, &end, 10);
    require(end != text && *end == '\0' && work > 0 && work <= UINT64_C(16777216), "work");
    return (uint64_t)work;
}

static void measure(unsigned cohort, uint64_t work) {
    const uint64_t slots[] = {64, 4096};
    puts("variant,capacity_kind,width,slots,population,capacity,operation,cohort,sample,seed,start_generation,rounds,operations,elapsed_ns,checksum,verify,cleanup");
    for (unsigned width = 0; width < 2; ++width)
        for (unsigned shape = 0; shape < 2; ++shape)
            for (uint64_t op = 0; op < 2; ++op)
                for (unsigned sample = 0; sample < SAMPLES; ++sample)
                    for (unsigned turn = 0; turn < IMPLEMENTATIONS; ++turn) {
                        unsigned peer = (sample + turn) % IMPLEMENTATIONS;
                        if (cohort) peer = IMPLEMENTATIONS - 1 - peer;
                        const Api *api = &apis[width * IMPLEMENTATIONS + peer];
                        uint64_t target = slots[cohort ? 1 - shape : shape];
                        uint64_t count = target / 2;
                        uint64_t rounds = (work + count - 1) / count;
                        uint64_t seed = 101 + sample;
                        Storage storage = {0};
                        api->prepare(storage.bytes, target, count, seed);
                        uint64_t geometry = api->geometry(storage.bytes);
                        require((uint32_t)geometry == count, "timed population");
                        require((geometry >> 32) == expected_capacity(api, target), "timed capacity");
                        /* One complete untimed batch on this SAME owner. */
                        uint64_t warmup = api->batch(storage.bytes, rounds, op);
                        require(warmup == expected_batch(api->wide, count, seed, 0, rounds, op), "warmup batch oracle");
                        require(api->geometry(storage.bytes) == geometry, "warmup geometry");
                        require(api->verify(storage.bytes) == expected_verify(count, seed, rounds), "warmup verify oracle");
                        observed ^= warmup;
                        uint64_t start_generation = rounds;
                        uint64_t start = nanoseconds();
                        uint64_t actual = api->batch(storage.bytes, rounds, op);
                        uint64_t elapsed = nanoseconds() - start;
                        require(actual == expected_batch(api->wide, count, seed, start_generation, rounds, op), "timed batch oracle");
                        require(api->geometry(storage.bytes) == geometry, "timed geometry");
                        uint64_t verify = api->verify(storage.bytes);
                        require(verify == expected_verify(count, seed, start_generation + rounds), "timed verify oracle");
                        uint64_t cleanup = api->finish(storage.bytes);
                        require(cleanup == expected_cleanup(api->wide, count, seed, start_generation + rounds), "timed cleanup oracle");
                        clean_ledger(); observed ^= actual ^ verify ^ cleanup;
                        printf("%s,%s,%s,%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%s,%u,%u,%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 "\n",
                               api->name, api->capacity_kind, api->wide ? "wide256" : "word8",
                               target, count, geometry >> 32, op ? "churn" : "replace",
                               cohort, sample, seed, start_generation, rounds, rounds * count,
                               elapsed, actual, verify, cleanup);
                        fflush(stdout);
                    }
}
#endif
int main(int argc, char **argv) {
    require(argc >= 2, "mode");
    if (strcmp(argv[1], "check") == 0) {
        require(argc == 2, "check args"); check_all();
    } else if (strcmp(argv[1], "negative") == 0) {
        require(argc == 3, "negative args"); negative(argv[2]);
#ifdef ACCOUNT_ONLY
    } else if (strcmp(argv[1], "account") == 0) {
        require(argc == 2, "account args"); account();
#endif
#ifndef ACCOUNT_ONLY
    } else if (strcmp(argv[1], "measure") == 0) {
        require(argc == 4 && (strcmp(argv[2], "0") == 0 || strcmp(argv[2], "1") == 0), "measure args");
        measure((unsigned)(argv[2][0] - '0'), parse_work(argv[3]));
#endif
    } else require(false, "unknown mode");
    return 0;
}
