import pathlib,json,hashlib,subprocess,time,os
D=pathlib.Path('/private/tmp/whitefoot-map-capacity-snapshot');R=pathlib.Path('/private/tmp/whitefoot-container-recovery-20261001')
assert os.environ.get('WHITEFOOT_CHECK_OWNER')
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
for p,h in json.loads((D/'pins.json').read_text()).items():assert sha(p)==h,p
for p,h in json.loads((D/'outputs.json').read_text()).items():assert sha(D/p)==h,p
records=[]
def run(label,args,expected=0,message=None):
 start=time.monotonic();p=subprocess.run(list(map(str,args)),cwd=R,capture_output=True,text=True)
 (D/(label+'.stdout')).write_text(p.stdout);(D/(label+'.stderr')).write_text(p.stderr)
 row=dict(label=label,argv=list(map(str,args)),exit=p.returncode,seconds=time.monotonic()-start);records.append(row)
 (D/'check-statuses.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert p.returncode==expected,row
 if message is not None:assert p.stderr.strip()=='mutation: '+message,p.stderr
 return p.stdout
faults={'wrong-batch-checksum':'negative wrong batch checksum','stale-generation':'negative stale generation','corrupt-last-word':'negative corrupt last word full-content','cleanup':'negative cleanup checksum','ledger-leak':'negative ledger leak','filled-allocation':'negative filled allocation'}
ledgers=[]
for arm in ['control','candidate']:
 text=(D/(arm+'.ll')).read_text()
 for old,new in [('@malloc(','@wf_cost_allocate('),('@realloc(','@wf_cost_reallocate('),('@free(','@wf_cost_release(')]:text=text.replace(old,new)
 ll=D/(arm+'-account.ll');ll.write_text(text);obj=ll.with_suffix('.o')
 run(arm+'-account-object',['/usr/bin/clang','-O3','-Wno-override-module','-x','ir','-c',ll,'-o',obj])
 cmd=json.loads(pathlib.Path('/private/tmp/whitefoot-mutation-home-mask/link-commands.json').read_text())['account'];old=[x for x in cmd if x.endswith('/entry-forward-wf-account.o')];assert len(old)==1
 cmd[cmd.index(old[0])]=str(obj);cmd[-1]=str(D/(arm+'-account'));run(arm+'-account-link',cmd)
 for kind in ['timed','account']:
  exe=D/(arm+'-'+kind);run(arm+'-'+kind+'-check',[exe,'check'])
  for fault,msg in faults.items():
   if kind=='timed' and fault in ['ledger-leak','filled-allocation']:continue
   run(arm+'-'+kind+'-'+fault,[exe,'negative',fault],1,msg)
 ledgers.append(run(arm+'-ledger',[D/(arm+'-account'),'account']))
assert ledgers[0]==ledgers[1]
assert ledgers[0]==pathlib.Path('/private/tmp/whitefoot-mutation-home-mask/candidate-ledger.stdout').read_text()
assert len(ledgers[0].splitlines())==33
(D/'images.json').write_text(json.dumps({str(D/(arm+'-'+kind)):sha(D/(arm+'-'+kind)) for arm in ['control','candidate'] for kind in ['timed','account']},indent=2)+'\n')
print('All30stages matched; both32-row ledgers equal each other and source-mask ledger. Stop for root review.')
