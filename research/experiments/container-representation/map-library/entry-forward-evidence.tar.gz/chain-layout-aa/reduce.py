from pathlib import Path
import csv,json,hashlib,collections
D=Path(__file__).parent;T=D/'timing';meta=json.loads((T/'metadata.json').read_text());assert len(meta['stages'])==4 and all(x['exit']==0 and not x['timed_out'] for x in meta['stages']);assert meta['images_before']==meta['images_after']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in meta['images_before'].items():assert sha(Path(p))==h
arms={};pins={};groups={}
for a in ['control','candidate']:
 for c in [0,1]:
  p=T/f'{a}-cohort-{c}.csv';rows=list(csv.DictReader(p.open()));assert len(rows)==288;arms[a,c]=rows;pins[p.name]=sha(p)
  keys=[tuple(r[k] for k in ['variant','width','slots','operation','sample']) for r in rows];assert len(set(keys))==288
  assert all(int(r['cohort'])==c and int(r['operations'])==4194304 for r in rows)
  for r in rows:groups.setdefault((a,c,r['variant'],r['width'],int(r['slots']),r['operation']),[]).append(int(r['elapsed_ns']))
for c in [0,1]:
 def vals(a):return {tuple(r[k] for k in ['variant','width','slots','operation','sample']):{k:v for k,v in r.items() if k!='elapsed_ns'} for r in arms[a,c]}
 assert vals('control')==vals('candidate')
 for a in ['control','candidate']:
  checks={}
  for r in arms[a,c]:
   key=tuple(r[k] for k in ['width','slots','operation','sample']);value=tuple(r[k] for k in ['seed','population','start_generation','rounds','operations','checksum','verify','cleanup'])
   if key in checks:assert checks[key]==value
   else:checks[key]=value
assert len(groups)==128 and all(len(v)==9 for v in groups.values())
def st(v):
 v=sorted(v);return dict(min=v[0]/4194304,median=v[4]/4194304,max=v[-1]/4194304)
def spread(a,b):return max(a/b,b/a)-1
def relation(a,b):return 'LOWER' if b['max']<a['min'] else 'HIGHER' if b['min']>a['max'] else 'OVERLAP'
rows=[]
for var in ['whitefoot-flat','whitefoot-chain','rust-hash-map','cpp-unordered-map']:
 for w in ['word8','wide256']:
  for slots in [64,4096]:
   for op in ['replace','churn']:
    item=dict(variant=var,width=w,slots=slots,operation=op,cohorts=[])
    for c in [0,1]:
     a=st(groups['control',c,var,w,slots,op]);b=st(groups['candidate',c,var,w,slots,op]);item['cohorts'].append(dict(cohort=c,control=a,candidate=b,relation=relation(a,b),ratio=b['median']/a['median'],symmetric_drift=spread(a['median'],b['median'])))
    item['paired_ratio_spread']=spread(*[x['ratio'] for x in item['cohorts']]);rows.append(item)
response=next(x for x in rows if (x['variant'],x['width'],x['slots'],x['operation'])==('whitefoot-chain','word8',4096,'churn'))
min_ns=min(v for values in groups.values() for v in values)
max_native=max((co['symmetric_drift'],x['variant'],x['width'],x['slots'],x['operation'],co['cohort']) for x in rows if x['variant'] in ['rust-hash-map','cpp-unordered-map'] for co in x['cohorts'])
max_allspread=max((x['paired_ratio_spread'],x['variant'],x['width'],x['slots'],x['operation']) for x in rows)
max_flatspread=max(x['paired_ratio_spread'] for x in rows if x['variant']=='whitefoot-flat')
separation=response['cohorts'][0]['relation'] in ['LOWER','HIGHER'] and response['cohorts'][0]['relation']==response['cohorts'][1]['relation']
instrument=min_ns>=1000000 and max_native[0]<=.1 and max_allspread[0]<=.1
result=dict(question='whole linked-layout A/A sensitivity, not algorithm qualification',raw_rows=1152,groups=128,samples_per_group=9,non_time_fields_identical=True,images_unchanged=True,csv_sha256=pins,min_interval_ns=min_ns,max_native_peer_drift=max_native,max_all_paired_ratio_spread=max_allspread,max_flat_paired_ratio_spread=max_flatspread,primary_response=response,primary_same_direction_separation=separation,instrument_pass=instrument,qualified_layout_response=separation and instrument and response['paired_ratio_spread']<=.1,cells=rows)
(T/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
lines=['variant width slots operation | c0 control median[range] -> relocated median[range] / relation | c1 same | ratio spread']
for x in rows:
 bits=[]
 for co in x['cohorts']:
  a,b=co['control'],co['candidate'];bits.append(f'{a["median"]:.6f}[{a["min"]:.6f},{a["max"]:.6f}] -> {b["median"]:.6f}[{b["min"]:.6f},{b["max"]:.6f}] / {co["relation"]}')
 lines.append(f'{x["variant"]} {x["width"]} {x["slots"]} {x["operation"]} | '+ ' | '.join(bits)+f' | {x["paired_ratio_spread"]*100:.6f}%')
(T/'table.txt').write_text('\n'.join(lines)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='cells'},indent=2))
