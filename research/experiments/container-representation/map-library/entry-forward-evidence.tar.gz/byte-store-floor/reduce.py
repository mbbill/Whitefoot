import csv, hashlib, json
from pathlib import Path
H=Path('<byte-store-scratch>'); T=H/'timing'
meta=json.loads((T/'metadata.json').read_text()); assert meta['images_before']==meta['images_after']
for p,h in meta['images_before'].items(): assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
arms={};sha={}
for a in ('control','candidate'):
 for c in (0,1):
  p=T/f'{a}-cohort-{c}.csv'; r=list(csv.DictReader(p.open())); assert len(r)==288
  arms[a,c]=r; sha[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
key=lambda r:(r['variant'],r['width'],r['slots'],r['operation'],r['sample'])
for c in (0,1):
 x={key(r):{k:v for k,v in r.items() if k!='elapsed_ns'} for r in arms['control',c]}
 y={key(r):{k:v for k,v in r.items() if k!='elapsed_ns'} for r in arms['candidate',c]}
 assert len(x)==len(y)==288 and x==y
 for a in ('control','candidate'):
  within={}
  for r in arms[a,c]:
   k=(r['width'],r['slots'],r['operation'],r['sample'])
   v=tuple(r[n] for n in ('seed','population','start_generation','rounds','operations','checksum','verify','cleanup'))
   if k in within: assert within[k]==v
   else: within[k]=v
  assert len(within)==72
V=('whitefoot-flat','whitefoot-chain','rust-hash-map','cpp-unordered-map')
def stats(rr):
 ns=sorted(int(r['elapsed_ns']) for r in rr); assert len(ns)==9
 ops=int(rr[0]['operations']); assert all(int(r['operations'])==ops for r in rr)
 return dict(min_ns=ns[0],median_ns=ns[4],max_ns=ns[-1],min_ns_per_op=ns[0]/ops,median_ns_per_op=ns[4]/ops,max_ns_per_op=ns[-1]/ops)
def relation(x,y):
 if x['max_ns']<y['min_ns']:return 'WIN'
 if x['min_ns']>y['max_ns']:return 'LOSS'
 return 'OVERLAP'
def drift(x,y):return max(x/y,y/x)-1
cells=[]
minimum=min(int(r['elapsed_ns']) for rr in arms.values() for r in rr)
for variant in V[:2]:
 for width in ('word8','wide256'):
  for slots in (64,4096):
   for operation in ('replace','churn'):
    cell=dict(variant=variant,width=width,slots=slots,operation=operation,cohorts=[])
    for cohort in (0,1):
     st={a:{v:stats([r for r in arms[a,cohort] if r['variant']==v and r['width']==width and int(r['slots'])==slots and r['operation']==operation]) for v in V} for a in ('control','candidate')}
     old,new=st['control'][variant],st['candidate'][variant]
     peers={v:drift(st['control'][v]['median_ns'],st['candidate'][v]['median_ns']) for v in V[2:]}
     cell['cohorts'].append(dict(cohort=cohort,stats=st,ratio=new['median_ns']/old['median_ns'],direction=relation(new,old),peer_drift=peers,candidate_vs_peers={v:relation(new,st['candidate'][v]) for v in V[2:]}))
    cell['ratio_spread']=drift(*(c['ratio'] for c in cell['cohorts']))
    cell['peer_drift_pass']=all(d<=.1 for c in cell['cohorts'] for d in c['peer_drift'].values())
    cell['duration_pass']=all(c['stats'][a][v]['min_ns']>=1000000 for c in cell['cohorts'] for a in ('control','candidate') for v in [variant,*V[2:]])
    cell['stable']=cell['ratio_spread']<=.1 and cell['peer_drift_pass'] and cell['duration_pass']
    cell['both_win']=all(c['direction']=='WIN' for c in cell['cohorts'])
    cell['both_loss']=all(c['direction']=='LOSS' for c in cell['cohorts'])
    cells.append(cell)
maxspread=max(c['ratio_spread'] for c in cells)
maxdrift=max(d for c in cells for co in c['cohorts'] for d in co['peer_drift'].values())
useful=[c for c in cells if c['variant']=='whitefoot-flat' and c['width']=='word8' and c['both_win'] and c['stable']]
adverse=[c for c in cells if any(co['direction']=='LOSS' for co in c['cohorts'])]
result=dict(rows=1152,images_unchanged=True,non_time_fields_identical=True,full_content_digests_identical=True,csv_sha256=sha,min_interval_ns=minimum,max_ratio_spread=maxspread,max_peer_drift=maxdrift,cells=cells,useful_scalar_cells=len(useful),separated_adverse_cell_count=len(adverse),criterion_pass=bool(useful) and not adverse and all(c['stable'] for c in cells))
(T/'reduction.json').write_text(json.dumps(result,indent=2)+'\n')
lines=['variant width slots operation | c0 control->candidate median ns/op [ranges]; direction | c1 same | spread% | max peer drift%']
for c in cells:
 parts=[]
 for co in c['cohorts']:
  a,b=[co['stats'][k][c['variant']] for k in ('control','candidate')]
  parts.append(f"{a['median_ns_per_op']:.4f}[{a['min_ns_per_op']:.4f},{a['max_ns_per_op']:.4f}]->{b['median_ns_per_op']:.4f}[{b['min_ns_per_op']:.4f},{b['max_ns_per_op']:.4f}] {co['direction']}")
 lines.append(f"{c['variant']} {c['width']} {c['slots']} {c['operation']} | "+' | '.join(parts)+f" | {100*c['ratio_spread']:.3f} | {100*max(d for co in c['cohorts'] for d in co['peer_drift'].values()):.3f}")
lines.append(f"min interval {minimum/1e6:.6f}ms; max ratio spread {maxspread*100:.3f}%; max peer drift {maxdrift*100:.3f}%; useful scalar {len(useful)}; adverse cells {len(adverse)}; criterion {result['criterion_pass']}")
(T/'reduction.txt').write_text('\n'.join(lines)+'\n');print('\n'.join(lines))
with (T/'combined.csv').open('w') as out:
 fieldnames=['arm',*next(iter(arms.values()))[0].keys()];writer=csv.DictWriter(out,fieldnames=fieldnames);writer.writeheader()
 for a,c in [('control',0),('candidate',0),('candidate',1),('control',1)]:
  for r in arms[a,c]:writer.writerow(dict(arm=a,**r))
