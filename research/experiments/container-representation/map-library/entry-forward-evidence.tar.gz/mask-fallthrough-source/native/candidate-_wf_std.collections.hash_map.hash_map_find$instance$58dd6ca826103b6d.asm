00000001000ab3c4 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d>:
1000ab3c4:     	ldrb	w8, [x2, #0x8]
1000ab3c8:     	tbz	w8, #0x0, 0x1000ab3dc <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0x18>
1000ab3cc:     	mov	x8, #0x0                ; =0
1000ab3d0:     	ldr	x9, [x0]
1000ab3d4:     	cbnz	x9, 0x1000ab424 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0x60>
1000ab3d8:     	b	0x1000ab498 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0xd4>
1000ab3dc:     	ldr	x8, [x2]
1000ab3e0:     	ldr	x9, [x1]
1000ab3e4:     	eor	x8, x9, x8
1000ab3e8:     	eor	x8, x8, x8, lsr #30
1000ab3ec:     	mov	x9, #0xe5b9             ; =58809
1000ab3f0:     	movk	x9, #0x1ce4, lsl #16
1000ab3f4:     	movk	x9, #0x476d, lsl #32
1000ab3f8:     	movk	x9, #0xbf58, lsl #48
1000ab3fc:     	mul	x8, x8, x9
1000ab400:     	eor	x8, x8, x8, lsr #27
1000ab404:     	mov	x9, #0x11eb             ; =4587
1000ab408:     	movk	x9, #0x1331, lsl #16
1000ab40c:     	movk	x9, #0x49bb, lsl #32
1000ab410:     	movk	x9, #0x94d0, lsl #48
1000ab414:     	mul	x8, x8, x9
1000ab418:     	eor	x8, x8, x8, lsr #31
1000ab41c:     	ldr	x9, [x0]
1000ab420:     	cbz	x9, 0x1000ab498 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0xd4>
1000ab424:     	sub	x10, x9, #0x1
1000ab428:     	and	x11, x10, x8
1000ab42c:     	udiv	x12, x8, x9
1000ab430:     	msub	x8, x12, x9, x8
1000ab434:     	tst	x9, x10
1000ab438:     	csel	x8, x11, x8, eq
1000ab43c:     	ldr	x10, [x0, #0x10]
1000ab440:     	mov	w11, #0x110             ; =272
1000ab444:     	mov	x12, x9
1000ab448:     	b	0x1000ab460 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0x9c>
1000ab44c:     	add	x13, x8, #0x1
1000ab450:     	cmp	x13, x9
1000ab454:     	csinc	x8, xzr, x8, hs
1000ab458:     	subs	x12, x12, #0x1
1000ab45c:     	b.eq	0x1000ab498 <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0xd4>
1000ab460:     	madd	x14, x8, x11, x10
1000ab464:     	ldr	w13, [x14]
1000ab468:     	cmp	w13, #0x1
1000ab46c:     	b.eq	0x1000ab44c <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0x88>
1000ab470:     	cmp	w13, #0x2
1000ab474:     	b.ne	0x1000ab4ac <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0xe8>
1000ab478:     	ldr	x13, [x14, #0x8]
1000ab47c:     	ldr	x14, [x1]
1000ab480:     	cmp	x13, x14
1000ab484:     	b.ne	0x1000ab44c <_wf_std.collections.hash_map.hash_map_find$instance$58dd6ca826103b6d+0x88>
1000ab488:     	mov	w0, #0x0                ; =0
1000ab48c:     	mov	x1, x8
1000ab490:     	mov	w2, #0x0                ; =0
1000ab494:     	ret
1000ab498:     	mov	x8, #0x0                ; =0
1000ab49c:     	mov	w0, #0x1                ; =1
1000ab4a0:     	mov	x1, x8
1000ab4a4:     	mov	w2, #0x0                ; =0
1000ab4a8:     	ret
1000ab4ac:     	mov	w0, #0x1                ; =1
1000ab4b0:     	mov	x8, x13
1000ab4b4:     	mov	x1, x8
1000ab4b8:     	mov	w2, #0x0                ; =0
1000ab4bc:     	ret

