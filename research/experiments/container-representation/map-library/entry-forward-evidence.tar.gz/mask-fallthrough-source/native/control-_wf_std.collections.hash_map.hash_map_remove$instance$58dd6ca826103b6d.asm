00000001000a8494 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d>:
1000a8494:     	ldr	x8, [x1, #0x18]
1000a8498:     	cbz	x8, 0x1000a8614 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x180>
1000a849c:     	ldrb	w9, [x3, #0x8]
1000a84a0:     	tbz	w9, #0x0, 0x1000a84b4 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x20>
1000a84a4:     	mov	x10, #0x0               ; =0
1000a84a8:     	ldr	x9, [x1]
1000a84ac:     	cbnz	x9, 0x1000a84fc <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x68>
1000a84b0:     	b	0x1000a8614 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x180>
1000a84b4:     	ldr	x9, [x3]
1000a84b8:     	ldr	x10, [x2]
1000a84bc:     	eor	x9, x10, x9
1000a84c0:     	eor	x9, x9, x9, lsr #30
1000a84c4:     	mov	x10, #0xe5b9            ; =58809
1000a84c8:     	movk	x10, #0x1ce4, lsl #16
1000a84cc:     	movk	x10, #0x476d, lsl #32
1000a84d0:     	movk	x10, #0xbf58, lsl #48
1000a84d4:     	mul	x9, x9, x10
1000a84d8:     	eor	x9, x9, x9, lsr #27
1000a84dc:     	mov	x10, #0x11eb            ; =4587
1000a84e0:     	movk	x10, #0x1331, lsl #16
1000a84e4:     	movk	x10, #0x49bb, lsl #32
1000a84e8:     	movk	x10, #0x94d0, lsl #48
1000a84ec:     	mul	x9, x9, x10
1000a84f0:     	eor	x10, x9, x9, lsr #31
1000a84f4:     	ldr	x9, [x1]
1000a84f8:     	cbz	x9, 0x1000a8614 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x180>
1000a84fc:     	sub	x11, x9, #0x1
1000a8500:     	tst	x9, x11
1000a8504:     	b.eq	0x1000a8514 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x80>
1000a8508:     	udiv	x11, x10, x9
1000a850c:     	msub	x12, x11, x9, x10
1000a8510:     	b	0x1000a8518 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x84>
1000a8514:     	and	x12, x11, x10
1000a8518:     	ldr	x13, [x1, #0x10]
1000a851c:     	mov	w14, #0x110             ; =272
1000a8520:     	mov	x15, x9
1000a8524:     	b	0x1000a853c <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0xa8>
1000a8528:     	add	x10, x12, #0x1
1000a852c:     	cmp	x10, x9
1000a8530:     	csinc	x12, xzr, x12, hs
1000a8534:     	subs	x15, x15, #0x1
1000a8538:     	b.eq	0x1000a8614 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x180>
1000a853c:     	madd	x10, x12, x14, x13
1000a8540:     	ldr	w11, [x10]
1000a8544:     	cmp	w11, #0x1
1000a8548:     	b.eq	0x1000a8528 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x94>
1000a854c:     	cmp	w11, #0x2
1000a8550:     	b.ne	0x1000a8614 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x180>
1000a8554:     	ldr	x11, [x10, #0x8]
1000a8558:     	ldr	x16, [x2]
1000a855c:     	cmp	x11, x16
1000a8560:     	b.ne	0x1000a8528 <_wf_std.collections.hash_map.hash_map_remove$instance$58dd6ca826103b6d+0x94>
1000a8564:     	mov	w9, #0x1                ; =1
1000a8568:     	str	w9, [x10]
1000a856c:     	sub	x8, x8, #0x1
1000a8570:     	ldp	q0, q1, [x10, #0x10]
1000a8574:     	ldp	q2, q3, [x10, #0x30]
1000a8578:     	ldp	q4, q5, [x10, #0x50]
1000a857c:     	ldp	q6, q7, [x10, #0x70]
1000a8580:     	ldp	q16, q17, [x10, #0x90]
1000a8584:     	ldp	q18, q19, [x10, #0xb0]
1000a8588:     	ldp	q20, q21, [x10, #0xd0]
1000a858c:     	ldp	q22, q23, [x10, #0xf0]
1000a8590:     	movi.2d	v24, #0000000000000000
1000a8594:     	stur	q24, [x10, #0x18]
1000a8598:     	stur	q24, [x10, #0x28]
1000a859c:     	stur	q24, [x10, #0x38]
1000a85a0:     	stur	q24, [x10, #0x48]
1000a85a4:     	stur	q24, [x10, #0x58]
1000a85a8:     	stur	q24, [x10, #0x68]
1000a85ac:     	stur	q24, [x10, #0x78]
1000a85b0:     	stur	q24, [x10, #0x88]
1000a85b4:     	stur	q24, [x10, #0x98]
1000a85b8:     	stur	q24, [x10, #0xa8]
1000a85bc:     	stur	q24, [x10, #0xb8]
1000a85c0:     	stur	q24, [x10, #0xc8]
1000a85c4:     	stur	q24, [x10, #0xd8]
1000a85c8:     	stur	q24, [x10, #0xe8]
1000a85cc:     	stur	q24, [x10, #0xf8]
1000a85d0:     	stur	q24, [x10, #0x8]
1000a85d4:     	str	xzr, [x10, #0x108]
1000a85d8:     	ldr	x10, [x1, #0x20]
1000a85dc:     	adds	x10, x10, #0x1
1000a85e0:     	csinv	x10, x10, xzr, lo
1000a85e4:     	stp	x8, x10, [x1, #0x18]
1000a85e8:     	stp	xzr, x11, [x0]
1000a85ec:     	str	w9, [x0]
1000a85f0:     	stp	q0, q1, [x0, #0x10]
1000a85f4:     	stp	q2, q3, [x0, #0x30]
1000a85f8:     	stp	q4, q5, [x0, #0x50]
1000a85fc:     	stp	q6, q7, [x0, #0x70]
1000a8600:     	stp	q16, q17, [x0, #0x90]
1000a8604:     	stp	q18, q19, [x0, #0xb0]
1000a8608:     	stp	q20, q21, [x0, #0xd0]
1000a860c:     	stp	q22, q23, [x0, #0xf0]
1000a8610:     	ret
1000a8614:     	movi.2d	v0, #0000000000000000
1000a8618:     	stp	q0, q0, [x0, #0xf0]
1000a861c:     	stp	q0, q0, [x0, #0xd0]
1000a8620:     	stp	q0, q0, [x0, #0xb0]
1000a8624:     	stp	q0, q0, [x0, #0x90]
1000a8628:     	stp	q0, q0, [x0, #0x70]
1000a862c:     	stp	q0, q0, [x0, #0x50]
1000a8630:     	stp	q0, q0, [x0, #0x30]
1000a8634:     	stp	q0, q0, [x0, #0x10]
1000a8638:     	str	q0, [x0]
1000a863c:     	ret

