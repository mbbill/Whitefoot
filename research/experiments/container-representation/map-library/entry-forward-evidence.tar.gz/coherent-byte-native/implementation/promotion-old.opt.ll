; ModuleID = '<implementation-scratch>/promotion-old.ll'
source_filename = "<implementation-scratch>/promotion-old.ll"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx26.0.0"

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define i1 @wf_copy_flag(i1 %flag) local_unnamed_addr #0 {
entry:
  %source.sroa.0 = alloca i8, align 8
  store i1 %flag, ptr %source.sroa.0, align 8
  %source.sroa.0.0.source.sroa.0.0.source.sroa.0.0.source.sroa.0.0.source.sroa.0.0.copy.sroa.0.0.copyload = load i8, ptr %source.sroa.0, align 8
  %result = trunc i8 %source.sroa.0.0.source.sroa.0.0.source.sroa.0.0.source.sroa.0.0.source.sroa.0.0.copy.sroa.0.0.copyload to i1
  ret i1 %result
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) }
