declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define i1 @wf_copy_flag(i1 %flag) {
entry:
  %source = alloca {i1}
  %copy = alloca {i1}
  store i1 %flag, ptr %source
  call void @llvm.memcpy.p0.p0.i64(ptr %copy, ptr %source, i64 1, i1 false)
  %value = load i8, ptr %copy
  %result = trunc i8 %value to i1
  ret i1 %result
}
