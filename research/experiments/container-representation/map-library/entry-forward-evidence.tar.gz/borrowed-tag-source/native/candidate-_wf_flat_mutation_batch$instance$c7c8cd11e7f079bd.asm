00000001000a3ba8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd>:
1000a3ba8:     	mov	x9, #0xe5b9             ; =58809
1000a3bac:     	movk	x9, #0x1ce4, lsl #16
1000a3bb0:     	movk	x9, #0x476d, lsl #32
1000a3bb4:     	movk	x9, #0xbf58, lsl #48
1000a3bb8:     	mov	x8, #0x11eb             ; =4587
1000a3bbc:     	movk	x8, #0x1331, lsl #16
1000a3bc0:     	movk	x8, #0x49bb, lsl #32
1000a3bc4:     	movk	x8, #0x94d0, lsl #48
1000a3bc8:     	ldr	x10, [x0, #0x38]
1000a3bcc:     	cbz	x1, 0x1000a3ea4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2fc>
1000a3bd0:     	ldp	x12, x11, [x0, #0x40]
1000a3bd4:     	cbz	x12, 0x1000a3e9c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2f4>
1000a3bd8:     	sub	sp, sp, #0x70
1000a3bdc:     	stp	x28, x27, [sp, #0x10]
1000a3be0:     	stp	x26, x25, [sp, #0x20]
1000a3be4:     	stp	x24, x23, [sp, #0x30]
1000a3be8:     	stp	x22, x21, [sp, #0x40]
1000a3bec:     	stp	x20, x19, [sp, #0x50]
1000a3bf0:     	stp	x29, x30, [sp, #0x60]
1000a3bf4:     	mov	x13, #0x0               ; =0
1000a3bf8:     	ldp	x19, x14, [x0, #0x20]
1000a3bfc:     	ldrb	w15, [x0, #0x30]
1000a3c00:     	mov	w16, #0x1               ; =1
1000a3c04:     	mov	w17, #0x18              ; =24
1000a3c08:     	mov	w3, #0x2                ; =2
1000a3c0c:     	mov	w4, #0x83               ; =131
1000a3c10:     	mov	x6, x10
1000a3c14:     	ldr	x7, [x0, #0x18]
1000a3c18:     	b	0x1000a3c2c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x84>
1000a3c1c:     	str	x11, [x0, #0x48]
1000a3c20:     	add	x13, x13, #0x1
1000a3c24:     	cmp	x13, x1
1000a3c28:     	b.eq	0x1000a3e68 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2c0>
1000a3c2c:     	mov	x20, #0x0               ; =0
1000a3c30:     	add	x11, x11, #0x1
1000a3c34:     	madd	x21, x11, x12, x10
1000a3c38:     	b	0x1000a3c60 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xb8>
1000a3c3c:     	strb	w16, [sp, #0xc]
1000a3c40:     	tst	w16, #0x1
1000a3c44:     	cinc	x24, x16, ne
1000a3c48:     	madd	x5, x6, x4, x22
1000a3c4c:     	add	x5, x5, x24
1000a3c50:     	madd	x6, x5, x4, x23
1000a3c54:     	add	x20, x20, #0x1
1000a3c58:     	cmp	x20, x12
1000a3c5c:     	b.eq	0x1000a3c1c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x74>
1000a3c60:     	orr	x22, x16, x20, lsl #1
1000a3c64:     	cbz	x2, 0x1000a3d1c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x174>
1000a3c68:     	cbz	x7, 0x1000a3da4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
1000a3c6c:     	tbz	w15, #0x0, 0x1000a3c80 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xd8>
1000a3c70:     	mov	x24, #0x0               ; =0
1000a3c74:     	ldr	x23, [x0]
1000a3c78:     	cbnz	x23, 0x1000a3ca0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xf8>
1000a3c7c:     	b	0x1000a3da4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
1000a3c80:     	eor	x5, x14, x22
1000a3c84:     	eor	x5, x5, x5, lsr #30
1000a3c88:     	mul	x5, x5, x9
1000a3c8c:     	eor	x5, x5, x5, lsr #27
1000a3c90:     	mul	x5, x5, x8
1000a3c94:     	eor	x24, x5, x5, lsr #31
1000a3c98:     	ldr	x23, [x0]
1000a3c9c:     	cbz	x23, 0x1000a3da4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
1000a3ca0:     	udiv	x5, x24, x23
1000a3ca4:     	msub	x24, x5, x23, x24
1000a3ca8:     	ldr	x25, [x0, #0x10]
1000a3cac:     	mov	x26, x23
1000a3cb0:     	b	0x1000a3cc8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x120>
1000a3cb4:     	add	x5, x24, #0x1
1000a3cb8:     	cmp	x5, x23
1000a3cbc:     	csinc	x24, xzr, x24, hs
1000a3cc0:     	subs	x26, x26, #0x1
1000a3cc4:     	b.eq	0x1000a3da4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
1000a3cc8:     	madd	x27, x24, x17, x25
1000a3ccc:     	ldr	w28, [x27]
1000a3cd0:     	cmp	w28, #0x1
1000a3cd4:     	b.eq	0x1000a3cb4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x10c>
1000a3cd8:     	cmp	w28, #0x2
1000a3cdc:     	b.ne	0x1000a3da4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
1000a3ce0:     	ldr	x5, [x27, #0x8]
1000a3ce4:     	cmp	x5, x22
1000a3ce8:     	b.ne	0x1000a3cb4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x10c>
1000a3cec:     	ldr	x5, [x27, #0x10]
1000a3cf0:     	str	w16, [x27]
1000a3cf4:     	sub	x7, x7, #0x1
1000a3cf8:     	stp	xzr, xzr, [x27, #0x8]
1000a3cfc:     	adds	x19, x19, #0x1
1000a3d00:     	csinv	x19, x19, xzr, lo
1000a3d04:     	stp	x7, x19, [x0, #0x18]
1000a3d08:     	mul	x23, x22, x4
1000a3d0c:     	mov	w24, #0x4309            ; =17161
1000a3d10:     	madd	x6, x6, x24, x23
1000a3d14:     	add	x5, x6, x5
1000a3d18:     	add	x6, x5, #0x83
1000a3d1c:     	tbz	w15, #0x0, 0x1000a3dac <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x204>
1000a3d20:     	mov	x25, #0x0               ; =0
1000a3d24:     	add	x23, x21, x20
1000a3d28:     	ldr	x24, [x0]
1000a3d2c:     	cbz	x24, 0x1000a3dd0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x228>
1000a3d30:     	udiv	x5, x25, x24
1000a3d34:     	msub	x26, x5, x24, x25
1000a3d38:     	ldr	x27, [x0, #0x10]
1000a3d3c:     	mov	x28, x24
1000a3d40:     	mov	x25, x24
1000a3d44:     	b	0x1000a3d64 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1bc>
1000a3d48:     	cmp	x25, x24
1000a3d4c:     	csel	x25, x26, x25, eq
1000a3d50:     	add	x5, x26, #0x1
1000a3d54:     	cmp	x5, x24
1000a3d58:     	csinc	x26, xzr, x26, hs
1000a3d5c:     	subs	x28, x28, #0x1
1000a3d60:     	b.eq	0x1000a3dd4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x22c>
1000a3d64:     	madd	x30, x26, x17, x27
1000a3d68:     	ldr	w5, [x30]
1000a3d6c:     	cmp	w5, #0x1
1000a3d70:     	b.eq	0x1000a3d48 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1a0>
1000a3d74:     	cmp	w5, #0x2
1000a3d78:     	b.ne	0x1000a3e54 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2ac>
1000a3d7c:     	ldr	x5, [x30, #0x8]
1000a3d80:     	cmp	x5, x22
1000a3d84:     	b.ne	0x1000a3d50 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1a8>
1000a3d88:     	ldr	x5, [x30, #0x10]
1000a3d8c:     	str	w3, [x30]
1000a3d90:     	str	x23, [x30, #0x10]
1000a3d94:     	strb	wzr, [sp, #0xc]
1000a3d98:     	mov	w24, #0x1               ; =1
1000a3d9c:     	mov	x23, x5
1000a3da0:     	b	0x1000a3c48 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xa0>
1000a3da4:     	mul	x6, x6, x4
1000a3da8:     	tbnz	w15, #0x0, 0x1000a3d20 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x178>
1000a3dac:     	eor	x5, x14, x22
1000a3db0:     	eor	x5, x5, x5, lsr #30
1000a3db4:     	mul	x5, x5, x9
1000a3db8:     	eor	x5, x5, x5, lsr #27
1000a3dbc:     	mul	x5, x5, x8
1000a3dc0:     	eor	x25, x5, x5, lsr #31
1000a3dc4:     	add	x23, x21, x20
1000a3dc8:     	ldr	x24, [x0]
1000a3dcc:     	cbnz	x24, 0x1000a3d30 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x188>
1000a3dd0:     	mov	x25, #0x0               ; =0
1000a3dd4:     	cmp	x25, x24
1000a3dd8:     	b.hs	0x1000a3c3c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
1000a3ddc:     	cmp	x7, #0x2, lsl #12       ; =0x2000
1000a3de0:     	b.hs	0x1000a3c3c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
1000a3de4:     	add	x7, x7, #0x1
1000a3de8:     	str	x7, [x0, #0x18]
1000a3dec:     	ldr	x5, [x0, #0x10]
1000a3df0:     	madd	x24, x25, x17, x5
1000a3df4:     	ldr	w25, [x24]
1000a3df8:     	cmp	w25, #0x1
1000a3dfc:     	b.ne	0x1000a3e10 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x268>
1000a3e00:     	subs	x5, x19, #0x1
1000a3e04:     	csel	x19, xzr, x5, lo
1000a3e08:     	str	x19, [x0, #0x20]
1000a3e0c:     	b	0x1000a3e34 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x28c>
1000a3e10:     	cbz	w25, 0x1000a3e34 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x28c>
1000a3e14:     	ldp	x5, x25, [x24, #0x8]
1000a3e18:     	str	w3, [x24]
1000a3e1c:     	stp	x22, x23, [x24, #0x8]
1000a3e20:     	strb	wzr, [sp, #0xc]
1000a3e24:     	mov	w24, #0x1               ; =1
1000a3e28:     	mov	x23, x25
1000a3e2c:     	mov	x22, x5
1000a3e30:     	b	0x1000a3c48 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xa0>
1000a3e34:     	str	w3, [x24]
1000a3e38:     	stp	x22, x23, [x24, #0x8]
1000a3e3c:     	strb	wzr, [sp, #0xc]
1000a3e40:     	mul	x6, x6, x4
1000a3e44:     	add	x20, x20, #0x1
1000a3e48:     	cmp	x20, x12
1000a3e4c:     	b.ne	0x1000a3c60 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xb8>
1000a3e50:     	b	0x1000a3c1c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x74>
1000a3e54:     	cmp	x25, x24
1000a3e58:     	csel	x25, x26, x25, eq
1000a3e5c:     	cmp	x25, x24
1000a3e60:     	b.lo	0x1000a3ddc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x234>
1000a3e64:     	b	0x1000a3c3c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
1000a3e68:     	ldp	x29, x30, [sp, #0x60]
1000a3e6c:     	ldp	x20, x19, [sp, #0x50]
1000a3e70:     	ldp	x22, x21, [sp, #0x40]
1000a3e74:     	ldp	x24, x23, [sp, #0x30]
1000a3e78:     	ldp	x26, x25, [sp, #0x20]
1000a3e7c:     	ldp	x28, x27, [sp, #0x10]
1000a3e80:     	add	sp, sp, #0x70
1000a3e84:     	eor	x10, x6, x6, lsr #30
1000a3e88:     	mul	x9, x10, x9
1000a3e8c:     	eor	x9, x9, x9, lsr #27
1000a3e90:     	mul	x8, x9, x8
1000a3e94:     	eor	x0, x8, x8, lsr #31
1000a3e98:     	ret
1000a3e9c:     	add	x11, x11, x1
1000a3ea0:     	str	x11, [x0, #0x48]
1000a3ea4:     	eor	x10, x10, x10, lsr #30
1000a3ea8:     	mul	x9, x10, x9
1000a3eac:     	eor	x9, x9, x9, lsr #27
1000a3eb0:     	mul	x8, x9, x8
1000a3eb4:     	eor	x0, x8, x8, lsr #31
1000a3eb8:     	ret

