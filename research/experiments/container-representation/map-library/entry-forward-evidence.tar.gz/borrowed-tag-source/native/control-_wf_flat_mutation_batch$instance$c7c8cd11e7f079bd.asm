00000001000a41fc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd>:
1000a41fc:     	mov	x9, #0xe5b9             ; =58809
1000a4200:     	movk	x9, #0x1ce4, lsl #16
1000a4204:     	movk	x9, #0x476d, lsl #32
1000a4208:     	movk	x9, #0xbf58, lsl #48
1000a420c:     	mov	x8, #0x11eb             ; =4587
1000a4210:     	movk	x8, #0x1331, lsl #16
1000a4214:     	movk	x8, #0x49bb, lsl #32
1000a4218:     	movk	x8, #0x94d0, lsl #48
1000a421c:     	ldr	x10, [x0, #0x38]
1000a4220:     	cbz	x1, 0x1000a44f8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2fc>
1000a4224:     	ldp	x12, x11, [x0, #0x40]
1000a4228:     	cbz	x12, 0x1000a44f0 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2f4>
1000a422c:     	sub	sp, sp, #0x70
1000a4230:     	stp	x28, x27, [sp, #0x10]
1000a4234:     	stp	x26, x25, [sp, #0x20]
1000a4238:     	stp	x24, x23, [sp, #0x30]
1000a423c:     	stp	x22, x21, [sp, #0x40]
1000a4240:     	stp	x20, x19, [sp, #0x50]
1000a4244:     	stp	x29, x30, [sp, #0x60]
1000a4248:     	mov	x13, #0x0               ; =0
1000a424c:     	ldp	x19, x14, [x0, #0x20]
1000a4250:     	ldrb	w15, [x0, #0x30]
1000a4254:     	mov	w16, #0x1               ; =1
1000a4258:     	mov	w17, #0x18              ; =24
1000a425c:     	mov	w3, #0x2                ; =2
1000a4260:     	mov	w4, #0x83               ; =131
1000a4264:     	mov	x6, x10
1000a4268:     	ldr	x7, [x0, #0x18]
1000a426c:     	b	0x1000a4280 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x84>
1000a4270:     	str	x11, [x0, #0x48]
1000a4274:     	add	x13, x13, #0x1
1000a4278:     	cmp	x13, x1
1000a427c:     	b.eq	0x1000a44bc <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2c0>
1000a4280:     	mov	x20, #0x0               ; =0
1000a4284:     	add	x11, x11, #0x1
1000a4288:     	madd	x21, x11, x12, x10
1000a428c:     	b	0x1000a42b4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xb8>
1000a4290:     	strb	w16, [sp, #0xc]
1000a4294:     	tst	w16, #0x1
1000a4298:     	cinc	x24, x16, ne
1000a429c:     	madd	x5, x6, x4, x22
1000a42a0:     	add	x5, x5, x24
1000a42a4:     	madd	x6, x5, x4, x23
1000a42a8:     	add	x20, x20, #0x1
1000a42ac:     	cmp	x20, x12
1000a42b0:     	b.eq	0x1000a4270 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x74>
1000a42b4:     	orr	x22, x16, x20, lsl #1
1000a42b8:     	cbz	x2, 0x1000a4370 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x174>
1000a42bc:     	cbz	x7, 0x1000a43f8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
1000a42c0:     	tbz	w15, #0x0, 0x1000a42d4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xd8>
1000a42c4:     	mov	x24, #0x0               ; =0
1000a42c8:     	ldr	x23, [x0]
1000a42cc:     	cbnz	x23, 0x1000a42f4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xf8>
1000a42d0:     	b	0x1000a43f8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
1000a42d4:     	eor	x5, x14, x22
1000a42d8:     	eor	x5, x5, x5, lsr #30
1000a42dc:     	mul	x5, x5, x9
1000a42e0:     	eor	x5, x5, x5, lsr #27
1000a42e4:     	mul	x5, x5, x8
1000a42e8:     	eor	x24, x5, x5, lsr #31
1000a42ec:     	ldr	x23, [x0]
1000a42f0:     	cbz	x23, 0x1000a43f8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
1000a42f4:     	udiv	x5, x24, x23
1000a42f8:     	msub	x24, x5, x23, x24
1000a42fc:     	ldr	x25, [x0, #0x10]
1000a4300:     	mov	x26, x23
1000a4304:     	b	0x1000a431c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x120>
1000a4308:     	add	x5, x24, #0x1
1000a430c:     	cmp	x5, x23
1000a4310:     	csinc	x24, xzr, x24, hs
1000a4314:     	subs	x26, x26, #0x1
1000a4318:     	b.eq	0x1000a43f8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
1000a431c:     	madd	x27, x24, x17, x25
1000a4320:     	ldr	w28, [x27]
1000a4324:     	cmp	w28, #0x1
1000a4328:     	b.eq	0x1000a4308 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x10c>
1000a432c:     	cmp	w28, #0x2
1000a4330:     	b.ne	0x1000a43f8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1fc>
1000a4334:     	ldr	x5, [x27, #0x8]
1000a4338:     	cmp	x5, x22
1000a433c:     	b.ne	0x1000a4308 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x10c>
1000a4340:     	ldr	x5, [x27, #0x10]
1000a4344:     	str	w16, [x27]
1000a4348:     	sub	x7, x7, #0x1
1000a434c:     	stp	xzr, xzr, [x27, #0x8]
1000a4350:     	adds	x19, x19, #0x1
1000a4354:     	csinv	x19, x19, xzr, lo
1000a4358:     	stp	x7, x19, [x0, #0x18]
1000a435c:     	mul	x23, x22, x4
1000a4360:     	mov	w24, #0x4309            ; =17161
1000a4364:     	madd	x6, x6, x24, x23
1000a4368:     	add	x5, x6, x5
1000a436c:     	add	x6, x5, #0x83
1000a4370:     	tbz	w15, #0x0, 0x1000a4400 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x204>
1000a4374:     	mov	x25, #0x0               ; =0
1000a4378:     	add	x23, x21, x20
1000a437c:     	ldr	x24, [x0]
1000a4380:     	cbz	x24, 0x1000a4424 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x228>
1000a4384:     	udiv	x5, x25, x24
1000a4388:     	msub	x26, x5, x24, x25
1000a438c:     	ldr	x27, [x0, #0x10]
1000a4390:     	mov	x28, x24
1000a4394:     	mov	x25, x24
1000a4398:     	b	0x1000a43b8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1bc>
1000a439c:     	cmp	x25, x24
1000a43a0:     	csel	x25, x26, x25, eq
1000a43a4:     	add	x5, x26, #0x1
1000a43a8:     	cmp	x5, x24
1000a43ac:     	csinc	x26, xzr, x26, hs
1000a43b0:     	subs	x28, x28, #0x1
1000a43b4:     	b.eq	0x1000a4428 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x22c>
1000a43b8:     	madd	x30, x26, x17, x27
1000a43bc:     	ldr	w5, [x30]
1000a43c0:     	cmp	w5, #0x1
1000a43c4:     	b.eq	0x1000a439c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1a0>
1000a43c8:     	cmp	w5, #0x2
1000a43cc:     	b.ne	0x1000a44a8 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x2ac>
1000a43d0:     	ldr	x5, [x30, #0x8]
1000a43d4:     	cmp	x5, x22
1000a43d8:     	b.ne	0x1000a43a4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x1a8>
1000a43dc:     	ldr	x5, [x30, #0x10]
1000a43e0:     	str	w3, [x30]
1000a43e4:     	str	x23, [x30, #0x10]
1000a43e8:     	strb	wzr, [sp, #0xc]
1000a43ec:     	mov	w24, #0x1               ; =1
1000a43f0:     	mov	x23, x5
1000a43f4:     	b	0x1000a429c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xa0>
1000a43f8:     	mul	x6, x6, x4
1000a43fc:     	tbnz	w15, #0x0, 0x1000a4374 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x178>
1000a4400:     	eor	x5, x14, x22
1000a4404:     	eor	x5, x5, x5, lsr #30
1000a4408:     	mul	x5, x5, x9
1000a440c:     	eor	x5, x5, x5, lsr #27
1000a4410:     	mul	x5, x5, x8
1000a4414:     	eor	x25, x5, x5, lsr #31
1000a4418:     	add	x23, x21, x20
1000a441c:     	ldr	x24, [x0]
1000a4420:     	cbnz	x24, 0x1000a4384 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x188>
1000a4424:     	mov	x25, #0x0               ; =0
1000a4428:     	cmp	x25, x24
1000a442c:     	b.hs	0x1000a4290 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
1000a4430:     	cmp	x7, #0x2, lsl #12       ; =0x2000
1000a4434:     	b.hs	0x1000a4290 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
1000a4438:     	add	x7, x7, #0x1
1000a443c:     	str	x7, [x0, #0x18]
1000a4440:     	ldr	x5, [x0, #0x10]
1000a4444:     	madd	x24, x25, x17, x5
1000a4448:     	ldr	w27, [x24]
1000a444c:     	cmp	w27, #0x1
1000a4450:     	b.ne	0x1000a446c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x270>
1000a4454:     	subs	x5, x19, #0x1
1000a4458:     	csel	x19, xzr, x5, lo
1000a445c:     	str	x19, [x0, #0x20]
1000a4460:     	str	w3, [x24]
1000a4464:     	stp	x22, x23, [x24, #0x8]
1000a4468:     	b	0x1000a4490 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x294>
1000a446c:     	ldp	x25, x26, [x24, #0x8]
1000a4470:     	str	w3, [x24]
1000a4474:     	stp	x22, x23, [x24, #0x8]
1000a4478:     	cbz	w27, 0x1000a4490 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x294>
1000a447c:     	strb	wzr, [sp, #0xc]
1000a4480:     	mov	w24, #0x1               ; =1
1000a4484:     	mov	x23, x26
1000a4488:     	mov	x22, x25
1000a448c:     	b	0x1000a429c <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xa0>
1000a4490:     	strb	wzr, [sp, #0xc]
1000a4494:     	mul	x6, x6, x4
1000a4498:     	add	x20, x20, #0x1
1000a449c:     	cmp	x20, x12
1000a44a0:     	b.ne	0x1000a42b4 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0xb8>
1000a44a4:     	b	0x1000a4270 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x74>
1000a44a8:     	cmp	x25, x24
1000a44ac:     	csel	x25, x26, x25, eq
1000a44b0:     	cmp	x25, x24
1000a44b4:     	b.lo	0x1000a4430 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x234>
1000a44b8:     	b	0x1000a4290 <_wf_flat_mutation_batch$instance$c7c8cd11e7f079bd+0x94>
1000a44bc:     	ldp	x29, x30, [sp, #0x60]
1000a44c0:     	ldp	x20, x19, [sp, #0x50]
1000a44c4:     	ldp	x22, x21, [sp, #0x40]
1000a44c8:     	ldp	x24, x23, [sp, #0x30]
1000a44cc:     	ldp	x26, x25, [sp, #0x20]
1000a44d0:     	ldp	x28, x27, [sp, #0x10]
1000a44d4:     	add	sp, sp, #0x70
1000a44d8:     	eor	x10, x6, x6, lsr #30
1000a44dc:     	mul	x9, x10, x9
1000a44e0:     	eor	x9, x9, x9, lsr #27
1000a44e4:     	mul	x8, x9, x8
1000a44e8:     	eor	x0, x8, x8, lsr #31
1000a44ec:     	ret
1000a44f0:     	add	x11, x11, x1
1000a44f4:     	str	x11, [x0, #0x48]
1000a44f8:     	eor	x10, x10, x10, lsr #30
1000a44fc:     	mul	x9, x10, x9
1000a4500:     	eor	x9, x9, x9, lsr #27
1000a4504:     	mul	x8, x9, x8
1000a4508:     	eor	x0, x8, x8, lsr #31
1000a450c:     	ret

