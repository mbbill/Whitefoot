00000001000a8858 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d>:
1000a8858:     	mov	x9, x3
1000a885c:     	mov	x3, x2
1000a8860:     	ldrb	w8, [x4, #0x8]
1000a8864:     	tbz	w8, #0x0, 0x1000a88dc <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x84>
1000a8868:     	mov	x8, #0x0                ; =0
1000a886c:     	ldr	x10, [x1]
1000a8870:     	cbz	x10, 0x1000a8920 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xc8>
1000a8874:     	udiv	x11, x8, x10
1000a8878:     	msub	x8, x11, x10, x8
1000a887c:     	ldr	x11, [x1, #0x10]
1000a8880:     	mov	w12, #0x110             ; =272
1000a8884:     	mov	x13, x10
1000a8888:     	mov	x2, x10
1000a888c:     	b	0x1000a88ac <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x54>
1000a8890:     	cmp	x2, x10
1000a8894:     	csel	x2, x8, x2, eq
1000a8898:     	add	x14, x8, #0x1
1000a889c:     	cmp	x14, x10
1000a88a0:     	csinc	x8, xzr, x8, hs
1000a88a4:     	subs	x13, x13, #0x1
1000a88a8:     	b.eq	0x1000a8924 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xcc>
1000a88ac:     	madd	x14, x8, x12, x11
1000a88b0:     	ldr	w15, [x14]
1000a88b4:     	cmp	w15, #0x1
1000a88b8:     	b.eq	0x1000a8890 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x38>
1000a88bc:     	cmp	w15, #0x2
1000a88c0:     	b.ne	0x1000a8970 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x118>
1000a88c4:     	ldr	x14, [x14, #0x8]
1000a88c8:     	cmp	x14, x3
1000a88cc:     	b.ne	0x1000a8898 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x40>
1000a88d0:     	mov	x2, x8
1000a88d4:     	mov	x4, x9
1000a88d8:     	b	0x1000ab734 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449>
1000a88dc:     	ldr	x8, [x4]
1000a88e0:     	eor	x8, x8, x3
1000a88e4:     	eor	x8, x8, x8, lsr #30
1000a88e8:     	mov	x10, #0xe5b9            ; =58809
1000a88ec:     	movk	x10, #0x1ce4, lsl #16
1000a88f0:     	movk	x10, #0x476d, lsl #32
1000a88f4:     	movk	x10, #0xbf58, lsl #48
1000a88f8:     	mul	x8, x8, x10
1000a88fc:     	eor	x8, x8, x8, lsr #27
1000a8900:     	mov	x10, #0x11eb            ; =4587
1000a8904:     	movk	x10, #0x1331, lsl #16
1000a8908:     	movk	x10, #0x49bb, lsl #32
1000a890c:     	movk	x10, #0x94d0, lsl #48
1000a8910:     	mul	x8, x8, x10
1000a8914:     	eor	x8, x8, x8, lsr #31
1000a8918:     	ldr	x10, [x1]
1000a891c:     	cbnz	x10, 0x1000a8874 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x1c>
1000a8920:     	mov	x2, #0x0                ; =0
1000a8924:     	cmp	x2, x10
1000a8928:     	b.hs	0x1000a8980 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x128>
1000a892c:     	ldr	x8, [x1, #0x18]
1000a8930:     	lsr	x10, x8, #13
1000a8934:     	cbnz	x10, 0x1000a8980 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x128>
1000a8938:     	add	x8, x8, #0x1
1000a893c:     	str	x8, [x1, #0x18]
1000a8940:     	ldr	x8, [x1, #0x10]
1000a8944:     	mov	w10, #0x110             ; =272
1000a8948:     	mul	x10, x2, x10
1000a894c:     	ldr	w8, [x8, x10]
1000a8950:     	cmp	w8, #0x1
1000a8954:     	b.ne	0x1000a8968 <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0x110>
1000a8958:     	ldr	x8, [x1, #0x20]
1000a895c:     	subs	x8, x8, #0x1
1000a8960:     	csel	x8, xzr, x8, lo
1000a8964:     	str	x8, [x1, #0x20]
1000a8968:     	mov	x4, x9
1000a896c:     	b	0x1000ab734 <_wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449>
1000a8970:     	cmp	x2, x10
1000a8974:     	csel	x2, x8, x2, eq
1000a8978:     	cmp	x2, x10
1000a897c:     	b.lo	0x1000a892c <_wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d+0xd4>
1000a8980:     	ldp	q0, q1, [x9]
1000a8984:     	ldp	q2, q3, [x9, #0x20]
1000a8988:     	ldp	q4, q5, [x9, #0x40]
1000a898c:     	ldp	q6, q7, [x9, #0x60]
1000a8990:     	ldp	q16, q17, [x9, #0x80]
1000a8994:     	ldp	q18, q19, [x9, #0xa0]
1000a8998:     	ldp	q20, q21, [x9, #0xc0]
1000a899c:     	ldp	q22, q23, [x9, #0xe0]
1000a89a0:     	stp	xzr, x3, [x0]
1000a89a4:     	mov	w8, #0x1                ; =1
1000a89a8:     	str	w8, [x0]
1000a89ac:     	strb	w8, [x0, #0x4]
1000a89b0:     	stp	q0, q1, [x0, #0x10]
1000a89b4:     	stp	q2, q3, [x0, #0x30]
1000a89b8:     	stp	q4, q5, [x0, #0x50]
1000a89bc:     	stp	q6, q7, [x0, #0x70]
1000a89c0:     	stp	q16, q17, [x0, #0x90]
1000a89c4:     	stp	q18, q19, [x0, #0xb0]
1000a89c8:     	stp	q20, q21, [x0, #0xd0]
1000a89cc:     	stp	q22, q23, [x0, #0xf0]
1000a89d0:     	ret

