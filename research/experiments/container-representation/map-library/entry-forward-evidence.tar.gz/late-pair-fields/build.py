import pathlib,json,subprocess,time,hashlib,os
R=pathlib.Path('<repository-root>')
D=pathlib.Path('<scratch-root>/late-pair-fields')
os.chdir(R)
base=json.loads(pathlib.Path('<scratch-root>/mutation-home-mask/link-commands.json').read_text())['timed']
statuses=[]
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def run(label,cmd):
 t=time.monotonic()
 with (D/(label+'.stdout')).open('wb') as out,(D/(label+'.stderr')).open('wb') as err:
  p=subprocess.run(cmd,stdout=out,stderr=err)
 statuses.append(dict(label=label,command=cmd,exit=p.returncode,seconds=time.monotonic()-t))
 (D/'build-statuses.json').write_text(json.dumps(statuses,indent=2)+'\n')
 print(label,p.returncode,round(statuses[-1]['seconds'],6),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
assert sha(D/'control.raw.ll')=='09cb4c4ea979d9dedb46dbc2bcb267d984d472777f0a69f4af86df68ede57b41'
assert sha(D/'candidate.raw.ll')=='b12033acda90f60ed00bcb5dc6da134e3058ad83a9a98fe1f8c6a41a55e0e048'
inputs={str(pathlib.Path(x).resolve()):sha(x) for x in base[2:] if pathlib.Path(x).is_file() and not x.endswith('entry-forward-timed') and not x.endswith('entry-forward-wf-timed.o')}
(D/'native-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
links={}
for arm in ['control','candidate']:
 raw=(D/(arm+'.raw.ll')).read_text();assert raw.count('define i32 @main(')==1
 ll=D/(arm+'-wf-timed.ll');ll.write_text(raw.replace('define i32 @main(','define i32 @mutation_unused_main('))
 obj=D/(arm+'-wf-timed.o');binary=D/(arm+'-timed')
 run(arm+'-object',['/usr/bin/clang','-O3','-Wno-override-module','-x','ir','-c',str(ll),'-o',str(obj)])
 cmd=[str(obj) if x.endswith('/entry-forward-wf-timed.o') else x for x in base];cmd[-1]=str(binary)
 links[arm]=cmd;run(arm+'-link',cmd)
 run(arm+'-native',[os.environ['LLVM_OBJDUMP'],'-dr','--no-show-raw-insn',str(binary)])
(D/'link-commands.json').write_text(json.dumps(links,indent=2)+'\n')
(D/'native-outputs.json').write_text(json.dumps({p.name:sha(p) for p in D.iterdir() if p.name.endswith(('.o','-timed','-native.stdout','-wf-timed.ll'))},indent=2)+'\n')
