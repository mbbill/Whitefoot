#!/usr/bin/env python3
"""One-shot disjoint-storage diagnostic; retire with its recorded result.
prepare is read/write only. build/check require the repository host guard.
No compiler build, source modification, or timing mode exists.
"""
import difflib, hashlib, json, os, pathlib, subprocess, sys, time
ROOT = pathlib.Path('/private/tmp/whitefoot-container-recovery-20261001')
D = ROOT / 'research/experiments/container-representation/map-library/.build/lookup-api/mutation-screen'
OUT = pathlib.Path('/private/tmp/whitefoot-map-replacement-disjoint')
SOURCE = D / 'entry-forward.raw.ll'
EXPECTED = '09cb4c4ea979d9dedb46dbc2bcb267d984d472777f0a69f4af86df68ede57b41'
SYMBOLS = ['wf_std.collections.hash_map.hash_map_try_put$instance$58dd6ca826103b6d',
           'wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449']
OBJDUMP = os.environ['LLVM_OBJDUMP']  # Measured instrument: LLVM22.1.8.
def sha(path): return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def absolute(value):
    path = pathlib.Path(value)
    return path if path.is_absolute() else ROOT / path
mode = sys.argv[1] if len(sys.argv) == 2 else ''
assert mode in ['prepare', 'build', 'check'], 'Use prepare, build, or check; timing is not authorized.'
assert sha(SOURCE) == EXPECTED, 'Frozen input changed'
links = {r['label'].split()[0]: r['command'] for r in json.loads(pathlib.Path('/private/tmp/whitefoot-entry-forward-images.json').read_text()) if r['label'].endswith(' link')}
if mode == 'prepare':
    OUT.mkdir(exist_ok=True)
    original = SOURCE.read_text()
    import re
    def definition(text, symbol):
        matches = list(re.finditer(r'^define [^\n]*@' + re.escape(symbol) + r'\([^\n]*\{\n.*?^}\n', text, re.M | re.S))
        assert len(matches) == 1, symbol
        return matches[0].group(0)
    batch_symbol = 'wf_flat_mutation_batch$instance$4250cb78d3f44027'
    batch = definition(original, batch_symbol)
    try_put = definition(original, SYMBOLS[0])
    exchange = definition(original, SYMBOLS[1])
    assert ') alwaysinline ' not in try_put + exchange
    assert ') noinline ' not in try_put + exchange
    assert all(body.splitlines()[0].endswith(') #0 {') for body in [try_put, exchange])
    clone_names = [name + '.disjoint_floor' for name in SYMBOLS]
    assert all(name not in original for name in clone_names)
    call = 'call void @' + SYMBOLS[0] + '(ptr %wf.slot.9, ptr %v95, i64 %v96, ptr %wf.slot.8, ptr %v97)'
    assert batch.count(call) == 1
    assert batch.count('@' + SYMBOLS[0] + '(') == 1
    assert '%wf.slot.8 = alloca %wf.t.862971f7a971a883, align 8' in batch
    assert '%wf.slot.9 = alloca %wf.t.114ba5754d75c8d6, align 8' in batch
    changed_batch = batch.replace(call, call.replace(SYMBOLS[0], clone_names[0]))
    clone_try = try_put.replace('@' + SYMBOLS[0] + '(', '@' + clone_names[0] + '(', 1)
    assert clone_try.count('@' + SYMBOLS[1] + '(') == 2
    clone_try = clone_try.replace('@' + SYMBOLS[1] + '(', '@' + clone_names[1] + '(')
    clone_exchange = exchange.replace('@' + SYMBOLS[1] + '(', '@' + clone_names[1] + '(', 1)
    # Audited call-site allocation fact; ordinary helpers/ABI remain unchanged.
    clone_try = clone_try.replace('(ptr %wf.result,', '(ptr noalias %wf.result,', 1)
    clone_exchange = clone_exchange.replace('(ptr %wf.result,', '(ptr noalias %wf.result,', 1)
    assert clone_try.count('(ptr noalias %wf.result,') == 1
    assert clone_exchange.count('(ptr noalias %wf.result,') == 1
    changed = original.replace(batch, changed_batch, 1) + '\n' + clone_try + '\n' + clone_exchange
    assert definition(changed, SYMBOLS[0]) == try_put
    assert definition(changed, SYMBOLS[1]) == exchange
    assert changed.removesuffix('\n' + clone_try + '\n' + clone_exchange).replace(changed_batch, batch, 1) == original
    (OUT / 'callgraph.json').write_text(json.dumps({
        'original': {batch_symbol: [SYMBOLS[0]], SYMBOLS[0]: [SYMBOLS[1], SYMBOLS[1]]},
        'candidate': {batch_symbol: [clone_names[0]], clone_names[0]: [clone_names[1], clone_names[1]]},
        'original_helpers': 'unchanged; all other callers still use originals',
        'attribute_scope': 'noalias on clone result only; no input attribute or inline changes',
        'source_result_allocation': '%wf.slot.9: HashMapPut272, align8',
        'source_input_allocation': '%wf.slot.8: Record256, align8',
    }, indent=2) + '\n')
    assert 'attributes #0 = { "probe-stack"="__chkstk_darwin" }' in original
    (OUT / 'candidate.raw.ll').write_text(changed)
    (OUT / 'modules.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True), changed.splitlines(True), fromfile='entry-forward.raw.ll', tofile='candidate.raw.ll')))
    paths = {SOURCE, D / 'entry-forward.o', D / 'entry-forward-timed', D / 'entry-forward-account', D / 'driver-mutation.c'}
    for kind, command in links.items():
        for arg in command[1:command.index('-o')]:
            if arg.endswith(('.o', '.a')): paths.add(absolute(arg))
        baseline = original.replace('define i32 @main(', 'define i32 @mutation_unused_main(')
        candidate = changed.replace('define i32 @main(', 'define i32 @mutation_unused_main(')
        if kind == 'account':
            for old, new in [('@malloc(', '@wf_cost_allocate('), ('@realloc(', '@wf_cost_reallocate('), ('@free(', '@wf_cost_release(')]:
                baseline, candidate = baseline.replace(old, new), candidate.replace(old, new)
        frozen = D / ('entry-forward-wf-' + kind + '.ll')
        assert baseline == frozen.read_text(), 'Remapping differs from measured input'
        paths.add(frozen)
        target = OUT / ('candidate-wf-' + kind + '.ll')
        target.write_text(candidate)
        paths.add(target)
    paths.add(OUT / 'candidate.raw.ll')
    paths.add(pathlib.Path(__file__))
    paths.add(OUT / 'criterion.txt')
    paths.add(OUT / 'callgraph.json')
    (OUT / 'inputs.json').write_text(json.dumps({str(p): sha(p) for p in sorted(paths)}, indent=2) + '\n')
    (OUT / 'link-commands.json').write_text(json.dumps(links, indent=2) + '\n')
    print('Prepared isolated clone patch and frozen input manifest:', OUT)
    sys.exit(0)
assert os.environ.get('WHITEFOOT_CHECK_OWNER'), 'Run through perl .github/run-check.pl'
for path, digest in json.loads((OUT / 'inputs.json').read_text()).items():
    assert sha(path) == digest, path
records = []
def run(label, command, expected=0, message=None):
    start = time.monotonic()
    result = subprocess.run([str(x) for x in command], cwd=ROOT, capture_output=True, text=True)
    (OUT / (label + '.stdout')).write_text(result.stdout)
    (OUT / (label + '.stderr')).write_text(result.stderr)
    record = dict(label=label, command=[str(x) for x in command], exit=result.returncode, seconds=time.monotonic()-start)
    records.append(record)
    (OUT / (mode + '-statuses.json')).write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    assert result.returncode == expected, record
    if message: assert result.stderr.strip() == 'mutation: ' + message, result.stderr
    return result.stdout
if mode == 'build':
    for kind, command in links.items():
        obj = OUT / ('candidate-wf-' + kind + '.o')
        run(kind + '-object', ['/usr/bin/clang', '-O3', '-Wno-override-module', '-x', 'ir', '-c', obj.with_suffix('.ll'), '-o', obj])
        command = list(command)
        old = str(D / ('entry-forward-wf-' + kind + '.o'))
        assert command.count(old) == 1
        command[command.index(old)] = str(obj)
        command[-1] = str(OUT / ('candidate-' + kind))
        run(kind + '-link', command)
    for label, path in [('control', D / 'entry-forward-timed'), ('candidate', OUT / 'candidate-timed')]:
        run(label + '-native', [OBJDUMP, '-dr', '--no-show-raw-insn', path])
    (OUT / 'outputs.json').write_text(json.dumps({str(p): sha(p) for p in OUT.glob('candidate-*') if p.suffix != '.ll'}, indent=2) + '\n')
    print('STOP: root must review the native gate before correctness or timing.')
else:
    faults = {'wrong-batch-checksum': 'negative wrong batch checksum', 'stale-generation': 'negative stale generation', 'corrupt-last-word': 'negative corrupt last word full-content', 'cleanup': 'negative cleanup checksum', 'ledger-leak': 'negative ledger leak', 'filled-allocation': 'negative filled allocation'}
    ledgers = []
    for arm, prefix in [('control', D / 'entry-forward'), ('candidate', OUT / 'candidate')]:
        for kind in ['timed', 'account']:
            exe = str(prefix) + '-' + kind
            run(arm + '-' + kind + '-check', [exe, 'check'])
            for fault, message in faults.items():
                if kind == 'timed' and fault in ['ledger-leak', 'filled-allocation']: continue
                run(arm + '-' + kind + '-' + fault, [exe, 'negative', fault], 1, message)
        ledgers.append(run(arm + '-ledger', [str(prefix) + '-account', 'account']))
    assert ledgers[0] == ledgers[1], 'Allocation ledgers differ'
    print('Existing broad controls and exact account equality passed. No timing launched.')
