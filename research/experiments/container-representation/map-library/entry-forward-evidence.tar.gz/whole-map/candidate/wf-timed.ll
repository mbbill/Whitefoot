; Whitefoot conservative module
source_filename = "whitefoot"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-apple-darwin"

%wf.t.ee6ca7dc0a065510 = type { i64, i1 }
%wf.t.84597570beb237fa = type { i64, i64, i64, i64 }
%wf.t.862971f7a971a883 = type { [32 x i64] }
%wf.t.88c85cf833d71e28.v0 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v1 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v2 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v3 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v4 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v5 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v6 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v7 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v8 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v9 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v10 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v11 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v13 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v14 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v15 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v16 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v17 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v18 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v19 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v20 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v21 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v22 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v23 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v24 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v25 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v26 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v27 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28.v28 = type { i32, i32, i8 }
%wf.t.88c85cf833d71e28 = type { i32, [8 x i8], [0 x %wf.t.88c85cf833d71e28.v0] }
%wf.t.996089250604052e = type { i32, %wf.t.88c85cf833d71e28 }
%wf.t.f3380055fe20f353 = type { i32, i64 }
%wf.t.07ce75c387735f4b = type { i32, i64 }
%wf.t.15b8e6e37e607262 = type { { i128, i128 }, { i128, i128 } }
%wf.t.3b1b6d56073edde7 = type { i32, %wf.t.88c85cf833d71e28 }
%wf.t.8656946ecebc34ec = type { { i128, i128 }, %wf.t.15b8e6e37e607262, { i128, i128 }, { i128, i128 }, { i128, i128 }, { i128, i128 }, { i128, i128 }, { i128, i128 } }
%wf.t.b7e1ed626c09888a = type { i32, i64, i8 }
%wf.t.7d7f918f7b4962fd = type { i32, i8, i8 }
%wf.t.d684c580aa29d578 = type { %wf.t.0a5f51efa7ad5b17, %wf.t.ee6ca7dc0a065510, i64, i64 }
%wf.t.0a5f51efa7ad5b17 = type { { i64, i64, ptr }, i64, i64 }
%wf.t.a1df460b0959673f = type { i32, i64, i64 }
%wf.t.cec24d6ee3b08025 = type { %wf.t.588b2641b8ac7d45, %wf.t.ee6ca7dc0a065510, i64, i64 }
%wf.t.588b2641b8ac7d45 = type { { i64, i64, ptr }, i64, i64 }
%wf.t.dceb7b9db1c9ad1d = type { i32, i64, %wf.t.862971f7a971a883 }
%wf.t.4f32c909b75cc77b = type { i32, { i128, i128 } }
%wf.t.050c23416549474d.v0 = type { i32, i64 }
%wf.t.050c23416549474d.v1 = type { i32, %wf.t.88c85cf833d71e28 }
%wf.t.050c23416549474d = type { i32, [12 x i8], [0 x %wf.t.050c23416549474d.v0] }
%wf.t.5b970ff2ad934046.v0 = type { i32, i64 }
%wf.t.5b970ff2ad934046.v1 = type { i32, %wf.t.996089250604052e }
%wf.t.5b970ff2ad934046 = type { i32, [20 x i8], [0 x %wf.t.5b970ff2ad934046.v0] }
%wf.t.8e49cf34abe1c006.v0 = type { i32, { i128, i128 } }
%wf.t.8e49cf34abe1c006.v1 = type { i32, i1 }
%wf.t.8e49cf34abe1c006 = type { i32, [44 x i8], [0 x %wf.t.8e49cf34abe1c006.v0] }
%wf.t.b80a9bfbd1f59cb4.v0 = type { i32, i64 }
%wf.t.b80a9bfbd1f59cb4.v1 = type { i32, %wf.t.f3380055fe20f353 }
%wf.t.b80a9bfbd1f59cb4 = type { i32, [20 x i8], [0 x %wf.t.b80a9bfbd1f59cb4.v0] }
%wf.t.4ef4128edabf98be = type { i32, i64, i1 }
%wf.t.f60af608c1958040.v0 = type { i32, i64 }
%wf.t.f60af608c1958040.v1 = type { i32, %wf.t.07ce75c387735f4b }
%wf.t.f60af608c1958040 = type { i32, [20 x i8], [0 x %wf.t.f60af608c1958040.v0] }
%wf.t.245242d1ce38c3e4.v0 = type { i32, { i128, i128 } }
%wf.t.245242d1ce38c3e4.v1 = type { i32, i1 }
%wf.t.245242d1ce38c3e4 = type { i32, [44 x i8], [0 x %wf.t.245242d1ce38c3e4.v0] }
%wf.t.0559b7ce3d6da8f1.v0 = type { i32, { i128, i128 } }
%wf.t.0559b7ce3d6da8f1.v1 = type { i32, %wf.t.88c85cf833d71e28 }
%wf.t.0559b7ce3d6da8f1 = type { i32, [44 x i8], [0 x %wf.t.0559b7ce3d6da8f1.v0] }
%wf.t.401891d75555d20e.v0 = type { i32, { i128, i128 } }
%wf.t.401891d75555d20e.v1 = type { i32, %wf.t.88c85cf833d71e28 }
%wf.t.401891d75555d20e = type { i32, [44 x i8], [0 x %wf.t.401891d75555d20e.v0] }
%wf.t.27caeb25122ac7c4.v0 = type { i32, { i128, i128 } }
%wf.t.27caeb25122ac7c4.v1 = type { i32, %wf.t.88c85cf833d71e28 }
%wf.t.27caeb25122ac7c4 = type { i32, [44 x i8], [0 x %wf.t.27caeb25122ac7c4.v0] }
%wf.t.6df397eafd3120ad.v0 = type { i32, i8 }
%wf.t.6df397eafd3120ad.v1 = type { i32, %wf.t.3b1b6d56073edde7 }
%wf.t.6df397eafd3120ad = type { i32, [16 x i8], [0 x %wf.t.6df397eafd3120ad.v0] }
%wf.t.8074de807c9b0e4e = type { %wf.t.6df397eafd3120ad, i64, i64 }
%wf.t.688872f0f831158e.v0 = type { i32, { i128, i128 } }
%wf.t.688872f0f831158e.v1 = type { i32, %wf.t.88c85cf833d71e28 }
%wf.t.688872f0f831158e = type { i32, [44 x i8], [0 x %wf.t.688872f0f831158e.v0] }
%wf.t.93559409a7432998.v0 = type { i32, i8 }
%wf.t.93559409a7432998.v1 = type { i32, %wf.t.88c85cf833d71e28 }
%wf.t.93559409a7432998 = type { i32, [12 x i8], [0 x %wf.t.93559409a7432998.v0] }
%wf.t.fe1d7d6862eac796 = type { { i64, i64, ptr }, i64, i64 }
%wf.t.5591089753cba638 = type { i32, i1, %wf.t.c5066f96ffdbc504 }
%wf.t.c5066f96ffdbc504 = type { i64, i64 }
%wf.t.84dc23e49b76868c = type { i32, %wf.t.c5066f96ffdbc504 }
%wf.t.4380a1278c72e25d = type { { i64, i64, ptr }, i64, i64 }
%wf.t.114ba5754d75c8d6 = type { i32, i1, %wf.t.d72ca22fbd302a84 }
%wf.t.d72ca22fbd302a84 = type { i64, %wf.t.862971f7a971a883 }
%wf.t.aba8f6d9883dda3a = type { i32, %wf.t.d72ca22fbd302a84 }

@.wf.empty.slots.payload = private global [8 x i8] zeroinitializer, align 8
@.wf_resource.heap = private unnamed_addr constant [20 x i8] c"\7B\22\72\65\73\6F\75\72\63\65\22\3A\22\68\65\61\70\22\7D\0A", align 1
declare i64 @write(i32, ptr, i64)
declare ptr @__error()

define private i64 @wf_resource_write(ptr %bytes, i64 %length) #0 {
entry:
  br label %write
write:
  %written = call i64 @write(i32 2, ptr %bytes, i64 %length)
  %failed = icmp slt i64 %written, 0
  br i1 %failed, label %error, label %done
error:
  %errno = call ptr @__error()
  %code = load i32, ptr %errno, align 4
  %interrupted = icmp eq i32 %code, 4
  br i1 %interrupted, label %write, label %done
done:
  ret i64 %written
}

declare void @abort() noreturn
declare ptr @malloc(i64)
declare ptr @realloc(ptr, i64)
declare void @free(ptr)

define private void @wf_resource_record_abort(ptr %message, i64 %length) noreturn #0 {
entry:
  br label %write.loop
write.loop:
  %cursor = phi ptr [ %message, %entry ], [ %next, %write.more ]
  %remaining = phi i64 [ %length, %entry ], [ %left, %write.more ]
  %written = call i64 @wf_resource_write(ptr %cursor, i64 %remaining)
  %complete = icmp eq i64 %written, %remaining
  br i1 %complete, label %abort, label %write.incomplete
write.incomplete:
  %progress = icmp sgt i64 %written, 0
  br i1 %progress, label %write.more, label %abort
write.more:
  %next = getelementptr i8, ptr %cursor, i64 %written
  %left = sub i64 %remaining, %written
  br label %write.loop
abort:
  call void @abort()
  unreachable
}

define private void @wf_resource_abort() noreturn #0 {
entry:
  call void @wf_resource_record_abort(ptr @.wf_resource.heap, i64 20)
  unreachable
}

declare void @llvm.assume(i1)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1 immarg)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1 immarg)
declare i64 @llvm.uadd.sat.i64(i64, i64)
declare i64 @llvm.usub.sat.i64(i64, i64)

define i64 @wf_map_cost_mix(i64 %v0) #0 {
entry:
  %v1 = select i1 true, i32 30, i32 30
  %t0 = zext i32 %v1 to i64
  %v2 = lshr i64 %v0, %t0
  %v3 = xor i64 %v0, %v2
  %v4 = select i1 true, i64 13787848793156543929, i64 13787848793156543929
  %v5 = mul i64 %v3, %v4
  %v6 = select i1 true, i32 27, i32 27
  %t1 = zext i32 %v6 to i64
  %v7 = lshr i64 %v5, %t1
  %v8 = xor i64 %v5, %v7
  %v9 = select i1 true, i64 10723151780598845931, i64 10723151780598845931
  %v10 = mul i64 %v8, %v9
  %v11 = select i1 true, i32 31, i32 31
  %t2 = zext i32 %v11 to i64
  %v12 = lshr i64 %v10, %t2
  %v13 = xor i64 %v10, %v12
  ret i64 %v13
}

define i64 @wf_map_cost_hash(ptr noalias nonnull captures(none) dereferenceable(16) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.ee6ca7dc0a065510, align 8
  %wf.slot.1 = alloca %wf.t.ee6ca7dc0a065510, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.ee6ca7dc0a065510, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %wf.slot.0, i32 0, i32 1
  %v3 = load i1, ptr %t0
  switch i1 %v3, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v4 = phi ptr [ %v0, %bb3 ]
  %v5 = phi ptr [ %v1, %bb3 ]
  %v7 = load i64, ptr %v5
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v4, i64 ptrtoint (ptr getelementptr (%wf.t.ee6ca7dc0a065510, ptr null, i32 1) to i64), i1 false)
  %t1 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %wf.slot.1, i32 0, i32 0
  %v9 = load i64, ptr %t1
  %v10 = xor i64 %v7, %v9
  %v11 = call i64 @wf_map_cost_mix(i64 %v10)
  ret i64 %v11
bb2:
  %v6 = select i1 true, i64 0, i64 0
  ret i64 %v6
bb3:
  br label %bb1
}

define i1 @wf_map_cost_equal(ptr noalias nonnull captures(none) dereferenceable(16) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(8) %v2) #0 {
entry:
  %v3 = load i64, ptr %v1
  %v4 = load i64, ptr %v2
  %v5 = icmp eq i64 %v3, %v4
  ret i1 %v5
}

define i64 @wf_map_cost_key(i64 %v0) #0 {
entry:
  %v1 = select i1 true, i64 2, i64 2
  %v2 = mul i64 %v0, %v1
  %v3 = select i1 true, i64 1, i64 1
  %v4 = add i64 %v2, %v3
  ret i64 %v4
}

define i8 @wf_map_cost_ordered(ptr noalias nonnull captures(none) dereferenceable(32) %v0, i64 %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.84597570beb237fa, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %wf.slot.0, i32 0, i32 0
  %v3 = load i64, ptr %t0
  %v4 = select i1 true, i64 131, i64 131
  %v5 = mul i64 %v3, %v4
  %t1 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v0, i32 0, i32 0
  %v6 = getelementptr i8, ptr %t1, i64 0
  %v7 = add i64 %v5, %v1
  store i64 %v7, ptr %v6
  %v8 = select i1 true, i8 0, i8 0
  ret i8 %v8
}

define i8 @wf_map_cost_final(ptr noalias nonnull captures(none) dereferenceable(32) %v0, i64 %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.84597570beb237fa, align 8
  %wf.slot.1 = alloca %wf.t.84597570beb237fa, align 8
  %wf.slot.2 = alloca %wf.t.84597570beb237fa, align 8
  %t0 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v0, i32 0, i32 1
  %v2 = getelementptr i8, ptr %t0, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %t1 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %wf.slot.0, i32 0, i32 1
  %v4 = load i64, ptr %t1
  %v5 = add i64 %v4, %v1
  store i64 %v5, ptr %v2
  %v6 = call i64 @wf_map_cost_mix(i64 %v1)
  %t2 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v0, i32 0, i32 2
  %v7 = getelementptr i8, ptr %t2, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %t3 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %wf.slot.1, i32 0, i32 2
  %v9 = load i64, ptr %t3
  %v10 = xor i64 %v9, %v6
  store i64 %v10, ptr %v7
  %t4 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v0, i32 0, i32 3
  %v11 = getelementptr i8, ptr %t4, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %t5 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %wf.slot.2, i32 0, i32 3
  %v13 = load i64, ptr %t5
  %v14 = select i1 true, i64 1, i64 1
  %v15 = add i64 %v13, %v14
  store i64 %v15, ptr %v11
  %v16 = select i1 true, i8 0, i8 0
  ret i8 %v16
}

define i64 @wf_map_cost_finish(ptr %wf.arg.v0) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.84597570beb237fa, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v0, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %wf.slot.0, i32 0, i32 0
  %v1 = load i64, ptr %t0
  %v2 = call i64 @wf_map_cost_mix(i64 %v1)
  %t1 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %wf.slot.0, i32 0, i32 1
  %v3 = load i64, ptr %t1
  %v4 = call i64 @wf_map_cost_mix(i64 %v3)
  %v5 = xor i64 %v2, %v4
  %t2 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %wf.slot.0, i32 0, i32 2
  %v6 = load i64, ptr %t2
  %v7 = xor i64 %v5, %v6
  %t3 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %wf.slot.0, i32 0, i32 3
  %v8 = load i64, ptr %t3
  %v9 = select i1 true, i64 11400714819323198485, i64 11400714819323198485
  %v10 = mul i64 %v8, %v9
  %v11 = xor i64 %v7, %v10
  ret i64 %v11
}

define i64 @wf_map_cost_word_make(i64 %v0) #0 {
entry:
  ret i64 %v0
}

define i64 @wf_map_cost_word_content(i64 %v0, i64 %v1) #0 {
entry:
  %v2 = select i1 true, i64 131, i64 131
  %v3 = mul i64 %v0, %v2
  %v4 = add i64 %v3, %v1
  ret i64 %v4
}

define i64 @wf_map_cost_word_observe(ptr noalias nonnull captures(none) dereferenceable(32) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(8) %v2) #0 {
entry:
  %v3 = load i64, ptr %v2
  ret i64 %v3
}

define i64 @wf_map_cost_word_edit(ptr noalias nonnull captures(none) dereferenceable(32) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(8) %v2) #0 {
entry:
  %v3 = load i64, ptr %v2
  %v4 = select i1 true, i64 1, i64 1
  %v5 = add i64 %v3, %v4
  store i64 %v5, ptr %v2
  %v6 = load i64, ptr %v2
  ret i64 %v6
}

define i8 @wf_map_cost_word_consume(ptr noalias nonnull captures(none) dereferenceable(32) %v0, i64 %v1, i64 %v2) #0 {
entry:
  %v3 = call i64 @wf_map_cost_word_content(i64 %v1, i64 %v2)
  %v4 = call i8 @wf_map_cost_final(ptr %v0, i64 %v3)
  %v5 = select i1 true, i8 0, i8 0
  ret i8 %v5
}

define void @wf_map_cost_record_make(ptr %wf.result, i64 %v0) #0 {
entry:
  %wf.slot.0 = alloca [32 x i64], align 8
  %v3 = alloca [32 x i64], align 8
  %v1 = select i1 true, i64 0, i64 0
  call void @wf_array_filled$instance$581665c886d1d2c8(ptr %v3, i64 %v1)
  %v4 = select i1 true, i64 0, i64 0
  %v5 = select i1 true, i64 32, i64 32
  br label %bb1
bb1:
  %v6 = phi i64 [ %v0, %entry ], [ %v16, %bb5 ]
  %v7 = phi ptr [ %v3, %entry ], [ %v17, %bb5 ]
  %v8 = phi i64 [ %v4, %entry ], [ %v18, %bb5 ]
  %v9 = phi i64 [ %v5, %entry ], [ %v19, %bb5 ]
  %v10 = phi i64 [ %v4, %entry ], [ %v22, %bb5 ]
  %v13 = icmp ult i64 %v10, %v9
  switch i1 %v13, label %invalid.tag.b1 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b1:
  unreachable
bb2:
  %t0 = getelementptr inbounds [32 x i64], ptr %v7, i64 0, i64 %v10
  %v14 = getelementptr i8, ptr %t0, i64 0
  %v15 = add i64 %v6, %v10
  store i64 %v15, ptr %v14
  br label %bb5
bb3:
  br label %bb4
bb4:
  %v11 = phi i64 [ %v6, %bb3 ]
  %v12 = phi ptr [ %v7, %bb3 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v12, i64 ptrtoint (ptr getelementptr ([32 x i64], ptr null, i32 1) to i64), i1 false)
  store %wf.t.862971f7a971a883 zeroinitializer, ptr %wf.result
  %t1 = getelementptr inbounds %wf.t.862971f7a971a883, ptr %wf.result, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %t1, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr ([32 x i64], ptr null, i32 1) to i64), i1 false)
  ret void
bb5:
  %v16 = phi i64 [ %v6, %bb2 ]
  %v17 = phi ptr [ %v7, %bb2 ]
  %v18 = phi i64 [ %v8, %bb2 ]
  %v19 = phi i64 [ %v9, %bb2 ]
  %v20 = phi i64 [ %v10, %bb2 ]
  %v21 = select i1 true, i64 1, i64 1
  %v22 = add i64 %v20, %v21
  br label %bb1
}

define i64 @wf_map_cost_record_content(i64 %v0, ptr %wf.arg.v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.862971f7a971a883, align 8
  %v2 = alloca %wf.t.862971f7a971a883, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v1, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %v2, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %v3 = select i1 true, i64 0, i64 0
  %v4 = select i1 true, i64 32, i64 32
  br label %bb1
bb1:
  %v5 = phi i64 [ %v0, %entry ], [ %v21, %bb5 ]
  %v6 = phi ptr [ %v2, %entry ], [ %v22, %bb5 ]
  %v7 = phi i64 [ %v0, %entry ], [ %v23, %bb5 ]
  %v8 = phi i64 [ %v3, %entry ], [ %v24, %bb5 ]
  %v9 = phi i64 [ %v4, %entry ], [ %v25, %bb5 ]
  %v10 = phi i64 [ %v3, %entry ], [ %v28, %bb5 ]
  %v14 = icmp ult i64 %v10, %v9
  switch i1 %v14, label %invalid.tag.b1 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v15 = select i1 true, i64 131, i64 131
  %v16 = mul i64 %v7, %v15
  %t0 = getelementptr inbounds %wf.t.862971f7a971a883, ptr %v6, i32 0, i32 0
  %v17 = getelementptr i8, ptr %t0, i64 0
  %t1 = getelementptr inbounds [32 x i64], ptr %v17, i64 0, i64 %v10
  %v18 = getelementptr i8, ptr %t1, i64 0
  %v19 = load i64, ptr %v18
  %v20 = add i64 %v16, %v19
  br label %bb5
bb3:
  br label %bb4
bb4:
  %v11 = phi i64 [ %v5, %bb3 ]
  %v12 = phi ptr [ %v6, %bb3 ]
  %v13 = phi i64 [ %v7, %bb3 ]
  ; drop %v12
  ret i64 %v13
bb5:
  %v21 = phi i64 [ %v5, %bb2 ]
  %v22 = phi ptr [ %v6, %bb2 ]
  %v23 = phi i64 [ %v20, %bb2 ]
  %v24 = phi i64 [ %v8, %bb2 ]
  %v25 = phi i64 [ %v9, %bb2 ]
  %v26 = phi i64 [ %v10, %bb2 ]
  %v27 = select i1 true, i64 1, i64 1
  %v28 = add i64 %v26, %v27
  br label %bb1
}

define i64 @wf_map_cost_record_observe(ptr noalias nonnull captures(none) dereferenceable(32) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(256) %v2) #0 {
entry:
  %t0 = getelementptr inbounds %wf.t.862971f7a971a883, ptr %v2, i32 0, i32 0
  %v3 = getelementptr i8, ptr %t0, i64 0
  %v4 = select i1 true, i64 0, i64 0
  %t1 = getelementptr inbounds [32 x i64], ptr %v3, i64 0, i64 %v4
  %v5 = getelementptr i8, ptr %t1, i64 0
  %v6 = load i64, ptr %v5
  ret i64 %v6
}

define i64 @wf_map_cost_record_edit(ptr noalias nonnull captures(none) dereferenceable(32) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(256) %v2) #0 {
entry:
  %t0 = getelementptr inbounds %wf.t.862971f7a971a883, ptr %v2, i32 0, i32 0
  %v3 = getelementptr i8, ptr %t0, i64 0
  %v4 = select i1 true, i64 0, i64 0
  %t1 = getelementptr inbounds [32 x i64], ptr %v3, i64 0, i64 %v4
  %v5 = getelementptr i8, ptr %t1, i64 0
  %t2 = getelementptr inbounds %wf.t.862971f7a971a883, ptr %v2, i32 0, i32 0
  %v6 = getelementptr i8, ptr %t2, i64 0
  %v7 = select i1 true, i64 0, i64 0
  %t3 = getelementptr inbounds [32 x i64], ptr %v6, i64 0, i64 %v7
  %v8 = getelementptr i8, ptr %t3, i64 0
  %v9 = load i64, ptr %v8
  %v10 = select i1 true, i64 1, i64 1
  %v11 = add i64 %v9, %v10
  store i64 %v11, ptr %v5
  %t4 = getelementptr inbounds %wf.t.862971f7a971a883, ptr %v2, i32 0, i32 0
  %v12 = getelementptr i8, ptr %t4, i64 0
  %v13 = select i1 true, i64 0, i64 0
  %t5 = getelementptr inbounds [32 x i64], ptr %v12, i64 0, i64 %v13
  %v14 = getelementptr i8, ptr %t5, i64 0
  %v15 = load i64, ptr %v14
  ret i64 %v15
}

define i8 @wf_map_cost_record_consume(ptr noalias nonnull captures(none) dereferenceable(32) %v0, i64 %v1, ptr %wf.arg.v2) #0 {
entry:
  %v3 = call i64 @wf_map_cost_record_content(i64 %v1, ptr %wf.arg.v2)
  %v4 = call i8 @wf_map_cost_final(ptr %v0, i64 %v3)
  %v5 = select i1 true, i8 0, i8 0
  ret i8 %v5
}

define i8 @wf_map_cost_lookup_result(ptr %wf.arg.v0, ptr noalias nonnull captures(none) dereferenceable(32) %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.b7e1ed626c09888a, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v0, i64 ptrtoint (ptr getelementptr (%wf.t.b7e1ed626c09888a, ptr null, i32 1) to i64), i1 false)
  %t0 = load %wf.t.b7e1ed626c09888a, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.b7e1ed626c09888a %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb2
    i32 1, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v3 = phi ptr [ %v1, %bb2 ], [ %v1, %bb3 ]
  %v11 = select i1 true, i8 0, i8 0
  ret i8 %v11
bb2:
  %t2 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.slot.0, i32 0, i32 1
  %v4 = load i64, ptr %t2
  %v5 = select i1 true, i64 1, i64 1
  %v6 = call i8 @wf_map_cost_ordered(ptr %v1, i64 %v5)
  %v7 = call i8 @wf_map_cost_ordered(ptr %v1, i64 %v4)
  br label %bb1
bb3:
  %t3 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.slot.0, i32 0, i32 2
  %v8 = load i8, ptr %t3
  %v9 = select i1 true, i64 0, i64 0
  %v10 = call i8 @wf_map_cost_ordered(ptr %v1, i64 %v9)
  br label %bb1
}

define i8 @wf_map_cost_rebuild_result(ptr %wf.arg.v0, ptr noalias nonnull captures(none) dereferenceable(32) %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.7d7f918f7b4962fd, align 4
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v0, i64 ptrtoint (ptr getelementptr (%wf.t.7d7f918f7b4962fd, ptr null, i32 1) to i64), i1 false)
  %t0 = load %wf.t.7d7f918f7b4962fd, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.7d7f918f7b4962fd %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb2
    i32 1, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v3 = phi ptr [ %v1, %bb2 ], [ %v1, %bb3 ]
  %v10 = select i1 true, i8 0, i8 0
  ret i8 %v10
bb2:
  %t2 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.slot.0, i32 0, i32 1
  %v4 = load i8, ptr %t2
  %v5 = select i1 true, i64 1, i64 1
  %v6 = call i8 @wf_map_cost_ordered(ptr %v1, i64 %v5)
  br label %bb1
bb3:
  %t3 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.slot.0, i32 0, i32 2
  %v7 = load i8, ptr %t3
  %v8 = select i1 true, i64 0, i64 0
  %v9 = call i8 @wf_map_cost_ordered(ptr %v1, i64 %v8)
  br label %bb1
}

define i64 @wf_map_cost_library_word_trace(i64 %v0, i64 %v1, i64 %v2, i64 %v3, i64 %v4, i64 %v5) #0 {
entry:
  %v6 = select i1 true, i64 8, i64 8
  %v7 = icmp eq i64 %v4, %v6
  switch i1 %v7, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v8 = phi i64 [ %v0, %bb3 ]
  %v9 = phi i64 [ %v1, %bb3 ]
  %v10 = phi i64 [ %v2, %bb3 ]
  %v11 = phi i64 [ %v3, %bb3 ]
  %v12 = phi i64 [ %v4, %bb3 ]
  %v13 = phi i64 [ %v5, %bb3 ]
  %v15 = call i64 @wf_map_cost_library_trace$instance$c7c8cd11e7f079bd(i64 %v8, i64 %v9, i64 %v10, i64 %v11, i64 %v12, i64 %v13)
  ret i64 %v15
bb2:
  %v14 = call i64 @wf_map_cost_library_policy$instance$c7c8cd11e7f079bd(i64 %v3, i64 %v5)
  ret i64 %v14
bb3:
  br label %bb1
}

define i64 @wf_map_cost_library_record_trace(i64 %v0, i64 %v1, i64 %v2, i64 %v3, i64 %v4, i64 %v5) #0 {
entry:
  %v6 = select i1 true, i64 8, i64 8
  %v7 = icmp eq i64 %v4, %v6
  switch i1 %v7, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v8 = phi i64 [ %v0, %bb3 ]
  %v9 = phi i64 [ %v1, %bb3 ]
  %v10 = phi i64 [ %v2, %bb3 ]
  %v11 = phi i64 [ %v3, %bb3 ]
  %v12 = phi i64 [ %v4, %bb3 ]
  %v13 = phi i64 [ %v5, %bb3 ]
  %v15 = call i64 @wf_map_cost_library_trace$instance$4250cb78d3f44027(i64 %v8, i64 %v9, i64 %v10, i64 %v11, i64 %v12, i64 %v13)
  ret i64 %v15
bb2:
  %v14 = call i64 @wf_map_cost_library_policy$instance$4250cb78d3f44027(i64 %v3, i64 %v5)
  ret i64 %v14
bb3:
  br label %bb1
}

define i64 @wf_map_cost_library_word_geometry(i64 %v0, i64 %v1, i64 %v2) #0 {
entry:
  %v3 = call i64 @wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd(i64 %v0, i64 %v1, i64 %v2)
  ret i64 %v3
}

define i64 @wf_map_cost_library_record_geometry(i64 %v0, i64 %v1, i64 %v2) #0 {
entry:
  %v3 = call i64 @wf_map_cost_library_geometry$instance$4250cb78d3f44027(i64 %v0, i64 %v1, i64 %v2)
  ret i64 %v3
}

define void @wf_map_cost_lookup_word_prepare(ptr %wf.result, i64 %v0, i64 %v1, i64 %v2) #0 {
entry:
  call void @wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd(ptr %wf.result, i64 %v0, i64 %v1, i64 %v2)
  ret void
}

define void @wf_map_cost_lookup_record_prepare(ptr %wf.result, i64 %v0, i64 %v1, i64 %v2) #0 {
entry:
  call void @wf_map_cost_lookup_prepare$instance$4250cb78d3f44027(ptr %wf.result, i64 %v0, i64 %v1, i64 %v2)
  ret void
}

define i64 @wf_map_cost_lookup_word_query(ptr noalias nonnull captures(none) dereferenceable(72) %v0, i64 %v1, i64 %v2) #0 {
entry:
  %v3 = call i64 @wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd(ptr %v0, i64 %v1, i64 %v2)
  ret i64 %v3
}

define i64 @wf_map_cost_lookup_record_query(ptr noalias nonnull captures(none) dereferenceable(72) %v0, i64 %v1, i64 %v2) #0 {
entry:
  %v3 = call i64 @wf_map_cost_lookup_query$instance$4250cb78d3f44027(ptr %v0, i64 %v1, i64 %v2)
  ret i64 %v3
}

define i64 @wf_map_cost_lookup_word_geometry(ptr noalias nonnull captures(none) dereferenceable(72) %v0) #0 {
entry:
  %v1 = call i64 @wf_map_cost_lookup_geometry$instance$e194368921a477a7(ptr %v0)
  ret i64 %v1
}

define i64 @wf_map_cost_lookup_record_geometry(ptr noalias nonnull captures(none) dereferenceable(72) %v0) #0 {
entry:
  %v1 = call i64 @wf_map_cost_lookup_geometry$instance$9fed7d4c5d7cc122(ptr %v0)
  ret i64 %v1
}

define i64 @wf_map_cost_lookup_word_finish(ptr %wf.arg.v0) #0 {
entry:
  %v1 = call i64 @wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd(ptr %wf.arg.v0)
  ret i64 %v1
}

define i64 @wf_map_cost_lookup_record_finish(ptr %wf.arg.v0) #0 {
entry:
  %v1 = call i64 @wf_map_cost_lookup_finish$instance$4250cb78d3f44027(ptr %wf.arg.v0)
  ret i64 %v1
}

define void @wf_main(ptr %wf.result) #0 {
entry:
  %v0 = select i1 true, i64 3, i64 3
  %v1 = select i1 true, i64 2, i64 2
  %v2 = select i1 true, i64 2, i64 2
  %v3 = select i1 true, i64 17, i64 17
  %v4 = select i1 true, i64 7, i64 7
  %v5 = select i1 true, i64 0, i64 0
  %v6 = call i64 @wf_map_cost_library_word_trace(i64 %v0, i64 %v1, i64 %v2, i64 %v3, i64 %v4, i64 %v5)
  %v7 = select i1 true, i64 3, i64 3
  %v8 = select i1 true, i64 2, i64 2
  %v9 = select i1 true, i64 2, i64 2
  %v10 = select i1 true, i64 17, i64 17
  %v11 = select i1 true, i64 3, i64 3
  %v12 = select i1 true, i64 1, i64 1
  %v13 = call i64 @wf_map_cost_library_record_trace(i64 %v7, i64 %v8, i64 %v9, i64 %v10, i64 %v11, i64 %v12)
  %v14 = select i1 true, i8 0, i8 0
  call void @wf_std.process.exit_status(ptr %wf.result, i8 %v14)
  ret void
}

declare void @wf_std.time.clock_share(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(32) %v0)

declare void @wf_std.time.wall_clock_share(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(32) %v0)

declare void @wf_std.time.now(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(32) %v0)

declare void @wf_std.time.instant_after(ptr %wf.result, ptr %wf.arg.v0, i64 %v1)

declare i64 @wf_std.time.nanoseconds_from(ptr %wf.arg.v0, ptr %wf.arg.v1)

declare i1 @wf_std.time.instant_reached(ptr %wf.arg.v0, ptr %wf.arg.v1)

declare i32 @wf_std.time.sleep_until.start(ptr %wf.result, ptr %wf.arg.v0, ptr %wf.operation)
declare void @wf_std.time.sleep_until.finish(ptr %wf.result, ptr %wf.arg.v0, ptr %wf.operation)

declare i64 @wf_std.time.unix_nanoseconds(ptr noalias nonnull captures(none) dereferenceable(32) %v0)

declare void @wf_std.io.factory_share(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(32) %v0)

declare i32 @wf_std.io.write_once.start(ptr %wf.result, ptr %v0, ptr %v1, ptr %wf.arg.v2.data, i64 %wf.arg.v2.len, i64 %v3, i64 %v4, ptr %wf.arg.v5, ptr %wf.operation)
declare void @wf_std.io.write_once.finish(ptr %wf.result, ptr %v0, ptr %v1, ptr %wf.arg.v2.data, i64 %wf.arg.v2.len, i64 %v3, i64 %v4, ptr %wf.arg.v5, ptr %wf.operation)

declare i32 @wf_std.io.read_next.start(ptr %wf.result, ptr %v0, ptr %v1, ptr %wf.arg.v2.data, i64 %wf.arg.v2.len, i64 %v3, i64 %v4, ptr %wf.arg.v5, ptr %wf.operation)
declare void @wf_std.io.read_next.finish(ptr %wf.result, ptr %v0, ptr %v1, ptr %wf.arg.v2.data, i64 %wf.arg.v2.len, i64 %v3, i64 %v4, ptr %wf.arg.v5, ptr %wf.operation)

declare i64 @wf_std.text.args_count(ptr noalias nonnull captures(none) dereferenceable(32) %v0)

declare void @wf_std.text.arg_get(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(32) %v0, i64 %v1)

declare i64 @wf_std.text.host_bytes_len(ptr noalias nonnull captures(none) dereferenceable(32) %v0)

declare void @wf_std.text.host_copy_bytes(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(32) %v0, ptr noalias nonnull captures(none) %wf.arg.v1.data, i64 %wf.arg.v1.len, i64 %v2, i64 %v3)

declare %wf.t.4ef4128edabf98be @wf_std.text.host_utf8_len(ptr noalias nonnull captures(none) dereferenceable(32) %v0)

declare void @wf_std.text.host_copy_utf8(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(32) %v0, ptr noalias nonnull captures(none) %wf.arg.v1.data, i64 %wf.arg.v1.len, i64 %v2, i64 %v3)

declare void @wf_std.fs.relative_path(ptr %wf.result, ptr %wf.arg.v0)

declare i32 @wf_std.fs.open_read.start(ptr %wf.result, ptr %v0, ptr %v1, ptr %v2, ptr %wf.operation)
declare void @wf_std.fs.open_read.finish(ptr %wf.result, ptr %v0, ptr %v1, ptr %v2, ptr %wf.operation)

declare i32 @wf_std.fs.read_at.start(ptr %wf.result, ptr %v0, ptr %v1, ptr %wf.arg.v2.data, i64 %wf.arg.v2.len, i64 %v3, i64 %v4, i64 %v5, ptr %wf.operation)
declare void @wf_std.fs.read_at.finish(ptr %wf.result, ptr %v0, ptr %v1, ptr %wf.arg.v2.data, i64 %wf.arg.v2.len, i64 %v3, i64 %v4, i64 %v5, ptr %wf.operation)

declare i32 @wf_std.fs.open_directory.start(ptr %wf.result, ptr %v0, ptr %v1, ptr %wf.arg.v2.data, i64 %wf.arg.v2.len, i64 %v3, i64 %v4, ptr %wf.operation)
declare void @wf_std.fs.open_directory.finish(ptr %wf.result, ptr %v0, ptr %v1, ptr %wf.arg.v2.data, i64 %wf.arg.v2.len, i64 %v3, i64 %v4, ptr %wf.operation)

declare i32 @wf_std.fs.open_directory_source.start(ptr %wf.result, ptr %v0, ptr %v1, ptr %wf.operation)
declare void @wf_std.fs.open_directory_source.finish(ptr %wf.result, ptr %v0, ptr %v1, ptr %wf.operation)

declare i32 @wf_std.fs.directory_next.start(ptr %wf.result, ptr %v0, ptr %wf.arg.v1.data, i64 %wf.arg.v1.len, i64 %v2, i64 %v3, ptr %wf.operation)
declare void @wf_std.fs.directory_next.finish(ptr %wf.result, ptr %v0, ptr %wf.arg.v1.data, i64 %wf.arg.v1.len, i64 %v2, i64 %v3, ptr %wf.operation)

declare i32 @wf_std.fs.open_file.start(ptr %wf.result, ptr %v0, ptr %v1, ptr %wf.arg.v2.data, i64 %wf.arg.v2.len, i64 %v3, i64 %v4, ptr %wf.operation)
declare void @wf_std.fs.open_file.finish(ptr %wf.result, ptr %v0, ptr %v1, ptr %wf.arg.v2.data, i64 %wf.arg.v2.len, i64 %v3, i64 %v4, ptr %wf.operation)

declare i32 @wf_std.fs.open_append.start(ptr %wf.result, ptr %v0, ptr %v1, ptr %wf.arg.v2.data, i64 %wf.arg.v2.len, i64 %v3, i64 %v4, ptr %wf.operation)
declare void @wf_std.fs.open_append.finish(ptr %wf.result, ptr %v0, ptr %v1, ptr %wf.arg.v2.data, i64 %wf.arg.v2.len, i64 %v3, i64 %v4, ptr %wf.operation)

declare i32 @wf_std.fs.append_once.start(ptr %wf.result, ptr %v0, ptr %v1, ptr %wf.arg.v2.data, i64 %wf.arg.v2.len, i64 %v3, i64 %v4, ptr %wf.operation)
declare void @wf_std.fs.append_once.finish(ptr %wf.result, ptr %v0, ptr %v1, ptr %wf.arg.v2.data, i64 %wf.arg.v2.len, i64 %v3, i64 %v4, ptr %wf.operation)

declare i32 @wf_std.fs.sync_file.start(ptr %wf.result, ptr %v0, ptr %v1, ptr %wf.operation)
declare void @wf_std.fs.sync_file.finish(ptr %wf.result, ptr %v0, ptr %v1, ptr %wf.operation)

declare i32 @wf_std.fs.close_read.start(ptr %wf.result, ptr %v0, ptr %wf.arg.v1, ptr %wf.operation)
declare void @wf_std.fs.close_read.finish(ptr %wf.result, ptr %v0, ptr %wf.arg.v1, ptr %wf.operation)

declare i32 @wf_std.fs.close_write.start(ptr %wf.result, ptr %v0, ptr %wf.arg.v1, ptr %wf.operation)
declare void @wf_std.fs.close_write.finish(ptr %wf.result, ptr %v0, ptr %wf.arg.v1, ptr %wf.operation)

declare i32 @wf_std.fs.close_directory.start(ptr %wf.result, ptr %v0, ptr %wf.arg.v1, ptr %wf.operation)
declare void @wf_std.fs.close_directory.finish(ptr %wf.result, ptr %v0, ptr %wf.arg.v1, ptr %wf.operation)

declare i32 @wf_std.fs.close_directory_write.start(ptr %wf.result, ptr %v0, ptr %wf.arg.v1, ptr %wf.operation)
declare void @wf_std.fs.close_directory_write.finish(ptr %wf.result, ptr %v0, ptr %wf.arg.v1, ptr %wf.operation)

declare i32 @wf_std.fs.close_directory_source.start(ptr %wf.result, ptr %v0, ptr %wf.arg.v1, ptr %wf.operation)
declare void @wf_std.fs.close_directory_source.finish(ptr %wf.result, ptr %v0, ptr %wf.arg.v1, ptr %wf.operation)

declare void @wf_std.process.exit_status(ptr %wf.result, i8 %v0)

define i64 @wf_std.collections.hash_map.hash_map_probe(i64 %v0, i64 %v1, i64 %v2) #0 {
entry:
  %v3 = sub nuw i64 %v2, %v0
  %v4 = icmp uge i64 %v1, %v3
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v5 = phi i64 [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb3 ]
  %v7 = phi i64 [ %v2, %bb3 ]
  %v8 = phi i64 [ %v3, %bb3 ]
  %v10 = add nuw i64 %v5, %v6
  ret i64 %v10
bb2:
  %v9 = sub nuw i64 %v1, %v3
  ret i64 %v9
bb3:
  br label %bb1
}

define void @wf_array_filled$instance$581665c886d1d2c8(ptr %wf.result, i64 %v0) #0 {
entry:
  %wf.slot.0 = alloca i64, align 8
  store i64 0, ptr %wf.slot.0
  br label %array.fill.head.v1
array.fill.head.v1:
  %t0 = load i64, ptr %wf.slot.0
  %t1 = icmp ult i64 %t0, 32
  br i1 %t1, label %array.fill.body.v1, label %array.fill.done.v1
array.fill.body.v1:
  %t2 = getelementptr inbounds [32 x i64], ptr %wf.result, i64 0, i64 %t0
  store i64 %v0, ptr %t2
  %t3 = add i64 %t0, 1
  store i64 %t3, ptr %wf.slot.0
  br label %array.fill.head.v1
array.fill.done.v1:
  ret void
}

define i64 @wf_map_cost_library_policy$instance$c7c8cd11e7f079bd(i64 %v0, i64 %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.5591089753cba638, align 8
  %wf.slot.1 = alloca %wf.t.5591089753cba638, align 8
  %wf.slot.2 = alloca %wf.t.5591089753cba638, align 8
  %wf.slot.3 = alloca %wf.t.fe1d7d6862eac796, align 8
  %wf.slot.4 = alloca %wf.t.84597570beb237fa, align 8
  %v7 = alloca %wf.t.ee6ca7dc0a065510, align 8
  %v10 = alloca %wf.t.fe1d7d6862eac796, align 8
  %v15 = alloca %wf.t.84597570beb237fa, align 8
  %v2 = select i1 true, i64 11400714819323198485, i64 11400714819323198485
  %v3 = xor i64 %v0, %v2
  %v4 = select i1 true, i64 0, i64 0
  %v5 = icmp ne i64 %v1, %v4
  store %wf.t.ee6ca7dc0a065510 zeroinitializer, ptr %v7
  %t0 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v7, i32 0, i32 0
  store i64 %v3, ptr %t0
  %t1 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v7, i32 0, i32 1
  store i1 %v5, ptr %t1
  %v8 = select i1 true, i64 3, i64 3
  call void @wf_std.collections.hash_map.hash_map_new$instance$a62a753cf2b0b5ca(ptr %v10, i64 %v8)
  %v11 = select i1 true, i64 0, i64 0
  %v12 = select i1 true, i64 0, i64 0
  %v13 = select i1 true, i64 0, i64 0
  store %wf.t.84597570beb237fa zeroinitializer, ptr %v15
  %t2 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v15, i32 0, i32 0
  store i64 %v0, ptr %t2
  %t3 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v15, i32 0, i32 1
  store i64 %v11, ptr %t3
  %t4 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v15, i32 0, i32 2
  store i64 %v12, ptr %t4
  %t5 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v15, i32 0, i32 3
  store i64 %v13, ptr %t5
  %v16 = select i1 true, i64 0, i64 0
  %v17 = select i1 true, i64 3, i64 3
  br label %bb1
bb1:
  %v18 = phi i64 [ %v0, %entry ], [ %v41, %bb5 ]
  %v19 = phi i64 [ %v1, %entry ], [ %v42, %bb5 ]
  %v20 = phi i64 [ %v3, %entry ], [ %v43, %bb5 ]
  %v21 = phi i1 [ %v5, %entry ], [ %v44, %bb5 ]
  %v22 = phi ptr [ %v7, %entry ], [ %v45, %bb5 ]
  %v23 = phi ptr [ %v10, %entry ], [ %v46, %bb5 ]
  %v24 = phi ptr [ %v15, %entry ], [ %v47, %bb5 ]
  %v25 = phi i64 [ %v16, %entry ], [ %v48, %bb5 ]
  %v26 = phi i64 [ %v17, %entry ], [ %v49, %bb5 ]
  %v27 = phi i64 [ %v16, %entry ], [ %v52, %bb5 ]
  %v35 = icmp ult i64 %v27, %v26
  switch i1 %v35, label %invalid.tag.b1 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v36 = call i64 @wf_map_cost_key(i64 %v27)
  %v37 = add i64 %v18, %v27
  %v38 = call i64 @wf_map_cost_word_make(i64 %v37)
  call void @wf_std.collections.hash_map.hash_map_put$instance$c7b22b9ef52855b6(ptr %wf.slot.0, ptr %v23, i64 %v36, i64 %v38, ptr %v22)
  %v40 = call i8 @wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd(ptr %wf.slot.0, ptr %v24)
  br label %bb5
bb3:
  br label %bb4
bb4:
  %v28 = phi i64 [ %v18, %bb3 ]
  %v29 = phi i64 [ %v19, %bb3 ]
  %v30 = phi i64 [ %v20, %bb3 ]
  %v31 = phi i1 [ %v21, %bb3 ]
  %v32 = phi ptr [ %v22, %bb3 ]
  %v33 = phi ptr [ %v23, %bb3 ]
  %v34 = phi ptr [ %v24, %bb3 ]
  %v53 = select i1 true, i64 10, i64 10
  %v54 = add i64 %v28, %v53
  %v55 = call i64 @wf_map_cost_word_make(i64 %v54)
  %v56 = select i1 true, i64 1, i64 1
  call void @wf_std.collections.hash_map.hash_map_put$instance$c7b22b9ef52855b6(ptr %wf.slot.1, ptr %v33, i64 %v56, i64 %v55, ptr %v32)
  %v58 = call i8 @wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd(ptr %wf.slot.1, ptr %v34)
  %v59 = select i1 true, i64 20, i64 20
  %v60 = add i64 %v28, %v59
  %v61 = call i64 @wf_map_cost_word_make(i64 %v60)
  %v62 = select i1 true, i64 7, i64 7
  call void @wf_std.collections.hash_map.hash_map_put$instance$c7b22b9ef52855b6(ptr %wf.slot.2, ptr %v33, i64 %v62, i64 %v61, ptr %v32)
  %v64 = call i8 @wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd(ptr %wf.slot.2, ptr %v34)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.3, ptr %v33, i64 ptrtoint (ptr getelementptr (%wf.t.fe1d7d6862eac796, ptr null, i32 1) to i64), i1 false)
  %v66 = call i8 @wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760(ptr %wf.slot.3, ptr %v34)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.4, ptr %v34, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %v68 = call i64 @wf_map_cost_finish(ptr %wf.slot.4)
  ret i64 %v68
bb5:
  %v41 = phi i64 [ %v18, %bb2 ]
  %v42 = phi i64 [ %v19, %bb2 ]
  %v43 = phi i64 [ %v20, %bb2 ]
  %v44 = phi i1 [ %v21, %bb2 ]
  %v45 = phi ptr [ %v22, %bb2 ]
  %v46 = phi ptr [ %v23, %bb2 ]
  %v47 = phi ptr [ %v24, %bb2 ]
  %v48 = phi i64 [ %v25, %bb2 ]
  %v49 = phi i64 [ %v26, %bb2 ]
  %v50 = phi i64 [ %v27, %bb2 ]
  %v51 = select i1 true, i64 1, i64 1
  %v52 = add i64 %v50, %v51
  br label %bb1
}

define i64 @wf_map_cost_library_trace$instance$c7c8cd11e7f079bd(i64 %v0, i64 %v1, i64 %v2, i64 %v3, i64 %v4, i64 %v5) #0 {
entry:
  %wf.frame = alloca { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, align 8
  %wf.slot.0 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 0
  %wf.slot.1 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 1
  %wf.slot.2 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 2
  %wf.slot.3 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 3
  %wf.slot.4 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 4
  %wf.slot.5 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 5
  %wf.slot.6 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 6
  %wf.slot.7 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 7
  %wf.slot.8 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 8
  %wf.slot.9 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 9
  %wf.slot.10 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 10
  %wf.slot.11 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 11
  %wf.slot.12 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 12
  %wf.slot.13 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 13
  %wf.slot.14 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 14
  %wf.slot.15 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 15
  %wf.slot.16 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 16
  %wf.slot.17 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 17
  %wf.slot.18 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 18
  %wf.slot.19 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 19
  %wf.slot.20 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 20
  %v11 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 21
  %v13 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 22
  %v18 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 23
  %v192 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 24
  %v280 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 25
  %v607 = getelementptr inbounds { %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.84dc23e49b76868c, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.5591089753cba638, %wf.t.c5066f96ffdbc504, %wf.t.b7e1ed626c09888a, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.0a5f51efa7ad5b17, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 26
  %v6 = select i1 true, i64 11400714819323198485, i64 11400714819323198485
  %v7 = xor i64 %v3, %v6
  %v8 = select i1 true, i64 0, i64 0
  %v9 = icmp ne i64 %v5, %v8
  store %wf.t.ee6ca7dc0a065510 zeroinitializer, ptr %v11
  %t0 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v11, i32 0, i32 0
  store i64 %v7, ptr %t0
  %t1 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v11, i32 0, i32 1
  store i1 %v9, ptr %t1
  call void @wf_std.collections.hash_map.hash_map_new$instance$820b2044b97e0fbd(ptr %v13, i64 %v0)
  %v14 = select i1 true, i64 0, i64 0
  %v15 = select i1 true, i64 0, i64 0
  %v16 = select i1 true, i64 0, i64 0
  store %wf.t.84597570beb237fa zeroinitializer, ptr %v18
  %t2 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v18, i32 0, i32 0
  store i64 %v3, ptr %t2
  %t3 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v18, i32 0, i32 1
  store i64 %v14, ptr %t3
  %t4 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v18, i32 0, i32 2
  store i64 %v15, ptr %t4
  %t5 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v18, i32 0, i32 3
  store i64 %v16, ptr %t5
  %v19 = select i1 true, i64 0, i64 0
  br label %bb1
bb1:
  %v20 = phi i64 [ %v0, %entry ], [ %v96, %bb11 ]
  %v21 = phi i64 [ %v1, %entry ], [ %v97, %bb11 ]
  %v22 = phi i64 [ %v2, %entry ], [ %v98, %bb11 ]
  %v23 = phi i64 [ %v3, %entry ], [ %v99, %bb11 ]
  %v24 = phi i64 [ %v4, %entry ], [ %v100, %bb11 ]
  %v25 = phi i64 [ %v5, %entry ], [ %v101, %bb11 ]
  %v26 = phi i64 [ %v7, %entry ], [ %v102, %bb11 ]
  %v27 = phi i1 [ %v9, %entry ], [ %v103, %bb11 ]
  %v28 = phi ptr [ %v11, %entry ], [ %v104, %bb11 ]
  %v29 = phi ptr [ %v13, %entry ], [ %v105, %bb11 ]
  %v30 = phi ptr [ %v18, %entry ], [ %v106, %bb11 ]
  %v31 = phi i64 [ %v19, %entry ], [ %v107, %bb11 ]
  %v32 = phi i64 [ %v1, %entry ], [ %v108, %bb11 ]
  %v33 = phi i64 [ %v19, %entry ], [ %v111, %bb11 ]
  %v45 = icmp ult i64 %v33, %v32
  switch i1 %v45, label %invalid.tag.b1 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v46 = call i64 @wf_map_cost_key(i64 %v33)
  %v47 = add i64 %v23, %v33
  %v48 = call i64 @wf_map_cost_word_make(i64 %v47)
  call void @wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad(ptr %wf.slot.0, ptr %v29, i64 %v46, i64 %v48, ptr %v28)
  %t6 = load %wf.t.5591089753cba638, ptr %wf.slot.0
  %t7 = extractvalue %wf.t.5591089753cba638 %t6, 0
  switch i32 %t7, label %invalid.tag.b2 [
    i32 0, label %bb6
    i32 1, label %bb7
  ]
invalid.tag.b2:
  unreachable
bb3:
  br label %bb4
bb4:
  %v34 = phi i64 [ %v20, %bb3 ]
  %v35 = phi i64 [ %v21, %bb3 ]
  %v36 = phi i64 [ %v22, %bb3 ]
  %v37 = phi i64 [ %v23, %bb3 ]
  %v38 = phi i64 [ %v24, %bb3 ]
  %v39 = phi i64 [ %v25, %bb3 ]
  %v40 = phi i64 [ %v26, %bb3 ]
  %v41 = phi i1 [ %v27, %bb3 ]
  %v42 = phi ptr [ %v28, %bb3 ]
  %v43 = phi ptr [ %v29, %bb3 ]
  %v44 = phi ptr [ %v30, %bb3 ]
  %v112 = select i1 true, i64 0, i64 0
  br label %bb12
bb5:
  %v50 = phi i64 [ %v20, %bb6 ], [ %v70, %bb8 ]
  %v51 = phi i64 [ %v21, %bb6 ], [ %v71, %bb8 ]
  %v52 = phi i64 [ %v22, %bb6 ], [ %v72, %bb8 ]
  %v53 = phi i64 [ %v23, %bb6 ], [ %v73, %bb8 ]
  %v54 = phi i64 [ %v24, %bb6 ], [ %v74, %bb8 ]
  %v55 = phi i64 [ %v25, %bb6 ], [ %v75, %bb8 ]
  %v56 = phi i64 [ %v26, %bb6 ], [ %v76, %bb8 ]
  %v57 = phi i1 [ %v27, %bb6 ], [ %v77, %bb8 ]
  %v58 = phi ptr [ %v28, %bb6 ], [ %v78, %bb8 ]
  %v59 = phi ptr [ %v29, %bb6 ], [ %v79, %bb8 ]
  %v60 = phi ptr [ %v30, %bb6 ], [ %v80, %bb8 ]
  %v61 = phi i64 [ %v33, %bb6 ], [ %v81, %bb8 ]
  %v62 = phi i64 [ %v46, %bb6 ], [ %v82, %bb8 ]
  %v63 = phi i64 [ %v47, %bb6 ], [ %v83, %bb8 ]
  %v64 = phi i64 [ %v48, %bb6 ], [ %v84, %bb8 ]
  br label %bb11
bb6:
  %v66 = select i1 true, i64 0, i64 0
  %v67 = call i8 @wf_map_cost_ordered(ptr %v30, i64 %v66)
  br label %bb5
bb7:
  %t8 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.slot.0, i32 0, i32 1
  %v68 = load i1, ptr %t8
  %t9 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.slot.0, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %t9, i64 ptrtoint (ptr getelementptr (%wf.t.c5066f96ffdbc504, ptr null, i32 1) to i64), i1 false)
  switch i1 %v68, label %invalid.tag.b7 [
    i1 0, label %bb9
    i1 1, label %bb10
  ]
invalid.tag.b7:
  unreachable
bb8:
  %v70 = phi i64 [ %v20, %bb9 ], [ %v20, %bb10 ]
  %v71 = phi i64 [ %v21, %bb9 ], [ %v21, %bb10 ]
  %v72 = phi i64 [ %v22, %bb9 ], [ %v22, %bb10 ]
  %v73 = phi i64 [ %v23, %bb9 ], [ %v23, %bb10 ]
  %v74 = phi i64 [ %v24, %bb9 ], [ %v24, %bb10 ]
  %v75 = phi i64 [ %v25, %bb9 ], [ %v25, %bb10 ]
  %v76 = phi i64 [ %v26, %bb9 ], [ %v26, %bb10 ]
  %v77 = phi i1 [ %v27, %bb9 ], [ %v27, %bb10 ]
  %v78 = phi ptr [ %v28, %bb9 ], [ %v28, %bb10 ]
  %v79 = phi ptr [ %v29, %bb9 ], [ %v29, %bb10 ]
  %v80 = phi ptr [ %v30, %bb9 ], [ %v30, %bb10 ]
  %v81 = phi i64 [ %v33, %bb9 ], [ %v33, %bb10 ]
  %v82 = phi i64 [ %v46, %bb9 ], [ %v46, %bb10 ]
  %v83 = phi i64 [ %v47, %bb9 ], [ %v47, %bb10 ]
  %v84 = phi i64 [ %v48, %bb9 ], [ %v48, %bb10 ]
  %v86 = phi i1 [ %v68, %bb9 ], [ %v68, %bb10 ]
  %t10 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.1, i32 0, i32 0
  %v92 = load i64, ptr %t10
  ; ownership-consuming projection
  %t11 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.1, i32 0, i32 1
  %v93 = load i64, ptr %t11
  ; ownership-consuming projection
  %v94 = call i64 @wf_map_cost_word_content(i64 %v92, i64 %v93)
  %v95 = call i8 @wf_map_cost_ordered(ptr %v80, i64 %v94)
  br label %bb5
bb9:
  %v88 = select i1 true, i64 1, i64 1
  %v89 = call i8 @wf_map_cost_ordered(ptr %v30, i64 %v88)
  br label %bb8
bb10:
  %v90 = select i1 true, i64 2, i64 2
  %v91 = call i8 @wf_map_cost_ordered(ptr %v30, i64 %v90)
  br label %bb8
bb11:
  %v96 = phi i64 [ %v50, %bb5 ]
  %v97 = phi i64 [ %v51, %bb5 ]
  %v98 = phi i64 [ %v52, %bb5 ]
  %v99 = phi i64 [ %v53, %bb5 ]
  %v100 = phi i64 [ %v54, %bb5 ]
  %v101 = phi i64 [ %v55, %bb5 ]
  %v102 = phi i64 [ %v56, %bb5 ]
  %v103 = phi i1 [ %v57, %bb5 ]
  %v104 = phi ptr [ %v58, %bb5 ]
  %v105 = phi ptr [ %v59, %bb5 ]
  %v106 = phi ptr [ %v60, %bb5 ]
  %v107 = phi i64 [ %v31, %bb5 ]
  %v108 = phi i64 [ %v32, %bb5 ]
  %v109 = phi i64 [ %v33, %bb5 ]
  %v110 = select i1 true, i64 1, i64 1
  %v111 = add i64 %v109, %v110
  br label %bb1
bb12:
  %v113 = phi i64 [ %v34, %bb4 ], [ %v947, %bb93 ]
  %v114 = phi i64 [ %v35, %bb4 ], [ %v948, %bb93 ]
  %v115 = phi i64 [ %v36, %bb4 ], [ %v949, %bb93 ]
  %v116 = phi i64 [ %v37, %bb4 ], [ %v950, %bb93 ]
  %v117 = phi i64 [ %v38, %bb4 ], [ %v951, %bb93 ]
  %v118 = phi i64 [ %v39, %bb4 ], [ %v952, %bb93 ]
  %v119 = phi i64 [ %v40, %bb4 ], [ %v953, %bb93 ]
  %v120 = phi i1 [ %v41, %bb4 ], [ %v954, %bb93 ]
  %v121 = phi ptr [ %v42, %bb4 ], [ %v955, %bb93 ]
  %v122 = phi ptr [ %v43, %bb4 ], [ %v956, %bb93 ]
  %v123 = phi ptr [ %v44, %bb4 ], [ %v957, %bb93 ]
  %v124 = phi i64 [ %v112, %bb4 ], [ %v958, %bb93 ]
  %v125 = phi i64 [ %v36, %bb4 ], [ %v959, %bb93 ]
  %v126 = phi i64 [ %v112, %bb4 ], [ %v962, %bb93 ]
  %v138 = icmp ult i64 %v126, %v125
  switch i1 %v138, label %invalid.tag.b12 [
    i1 1, label %bb13
    i1 0, label %bb14
  ]
invalid.tag.b12:
  unreachable
bb13:
  %v139 = select i1 true, i64 5, i64 5
  %v140 = icmp eq i64 %v117, %v139
  switch i1 %v140, label %invalid.tag.b13 [
    i1 1, label %bb17
    i1 0, label %bb18
  ]
invalid.tag.b13:
  unreachable
bb14:
  br label %bb15
bb15:
  %v127 = phi i64 [ %v113, %bb14 ]
  %v128 = phi i64 [ %v114, %bb14 ]
  %v129 = phi i64 [ %v115, %bb14 ]
  %v130 = phi i64 [ %v116, %bb14 ]
  %v131 = phi i64 [ %v117, %bb14 ]
  %v132 = phi i64 [ %v118, %bb14 ]
  %v133 = phi i64 [ %v119, %bb14 ]
  %v134 = phi i1 [ %v120, %bb14 ]
  %v135 = phi ptr [ %v121, %bb14 ]
  %v136 = phi ptr [ %v122, %bb14 ]
  %v137 = phi ptr [ %v123, %bb14 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.19, ptr %v136, i64 ptrtoint (ptr getelementptr (%wf.t.0a5f51efa7ad5b17, ptr null, i32 1) to i64), i1 false)
  %v964 = call i8 @wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19(ptr %wf.slot.19, ptr %v137)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.20, ptr %v137, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %v966 = call i64 @wf_map_cost_finish(ptr %wf.slot.20)
  ret i64 %v966
bb16:
  %v141 = phi i64 [ %v322, %bb35 ], [ %v566, %bb61 ]
  %v142 = phi i64 [ %v323, %bb35 ], [ %v567, %bb61 ]
  %v143 = phi i64 [ %v324, %bb35 ], [ %v568, %bb61 ]
  %v144 = phi i64 [ %v325, %bb35 ], [ %v569, %bb61 ]
  %v145 = phi i64 [ %v326, %bb35 ], [ %v570, %bb61 ]
  %v146 = phi i64 [ %v327, %bb35 ], [ %v571, %bb61 ]
  %v147 = phi i64 [ %v328, %bb35 ], [ %v572, %bb61 ]
  %v148 = phi i1 [ %v329, %bb35 ], [ %v573, %bb61 ]
  %v149 = phi ptr [ %v330, %bb35 ], [ %v574, %bb61 ]
  %v150 = phi ptr [ %v331, %bb35 ], [ %v575, %bb61 ]
  %v151 = phi ptr [ %v332, %bb35 ], [ %v576, %bb61 ]
  %v152 = phi i64 [ %v333, %bb35 ], [ %v577, %bb61 ]
  br label %bb93
bb17:
  %v153 = select i1 true, i64 2, i64 2
  %v154 = udiv i64 %v114, %v153
  %v155 = sub nuw i64 %v114, %v154
  %v156 = select i1 true, i64 0, i64 0
  br label %bb19
bb18:
  %v430 = select i1 true, i64 4, i64 4
  %v431 = icmp eq i64 %v117, %v430
  %v432 = select i1 true, i64 9, i64 9
  %v433 = icmp eq i64 %v117, %v432
  %v434 = select i1 true, i64 10, i64 10
  %v435 = icmp eq i64 %v117, %v434
  %v436 = or i1 %v433, %v435
  %v437 = or i1 %v431, %v436
  switch i1 %v437, label %invalid.tag.b18 [
    i1 1, label %bb44
    i1 0, label %bb45
  ]
invalid.tag.b18:
  unreachable
bb19:
  %v157 = phi i64 [ %v113, %bb17 ], [ %v223, %bb26 ]
  %v158 = phi i64 [ %v114, %bb17 ], [ %v224, %bb26 ]
  %v159 = phi i64 [ %v115, %bb17 ], [ %v225, %bb26 ]
  %v160 = phi i64 [ %v116, %bb17 ], [ %v226, %bb26 ]
  %v161 = phi i64 [ %v117, %bb17 ], [ %v227, %bb26 ]
  %v162 = phi i64 [ %v118, %bb17 ], [ %v228, %bb26 ]
  %v163 = phi i64 [ %v119, %bb17 ], [ %v229, %bb26 ]
  %v164 = phi i1 [ %v120, %bb17 ], [ %v230, %bb26 ]
  %v165 = phi ptr [ %v121, %bb17 ], [ %v231, %bb26 ]
  %v166 = phi ptr [ %v122, %bb17 ], [ %v232, %bb26 ]
  %v167 = phi ptr [ %v123, %bb17 ], [ %v233, %bb26 ]
  %v168 = phi i64 [ %v126, %bb17 ], [ %v234, %bb26 ]
  %v169 = phi i64 [ %v154, %bb17 ], [ %v235, %bb26 ]
  %v170 = phi i64 [ %v155, %bb17 ], [ %v236, %bb26 ]
  %v171 = phi i64 [ %v156, %bb17 ], [ %v237, %bb26 ]
  %v172 = phi i64 [ %v155, %bb17 ], [ %v238, %bb26 ]
  %v173 = phi i64 [ %v156, %bb17 ], [ %v241, %bb26 ]
  %v188 = icmp ult i64 %v173, %v172
  switch i1 %v188, label %invalid.tag.b19 [
    i1 1, label %bb20
    i1 0, label %bb21
  ]
invalid.tag.b19:
  unreachable
bb20:
  %v189 = select i1 true, i64 2, i64 2
  %v190 = mul i64 %v173, %v189
  %v191 = call i64 @wf_map_cost_key(i64 %v190)
  store i64 %v191, ptr %v192
  %v193 = call %wf.t.84dc23e49b76868c @wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad(ptr %v166, ptr %v192, ptr %v165)
  store %wf.t.84dc23e49b76868c %v193, ptr %wf.slot.2
  %t12 = load %wf.t.84dc23e49b76868c, ptr %wf.slot.2
  %t13 = extractvalue %wf.t.84dc23e49b76868c %t12, 0
  switch i32 %t13, label %invalid.tag.b20 [
    i32 1, label %bb24
    i32 0, label %bb25
  ]
invalid.tag.b20:
  unreachable
bb21:
  br label %bb22
bb22:
  %v174 = phi i64 [ %v157, %bb21 ]
  %v175 = phi i64 [ %v158, %bb21 ]
  %v176 = phi i64 [ %v159, %bb21 ]
  %v177 = phi i64 [ %v160, %bb21 ]
  %v178 = phi i64 [ %v161, %bb21 ]
  %v179 = phi i64 [ %v162, %bb21 ]
  %v180 = phi i64 [ %v163, %bb21 ]
  %v181 = phi i1 [ %v164, %bb21 ]
  %v182 = phi ptr [ %v165, %bb21 ]
  %v183 = phi ptr [ %v166, %bb21 ]
  %v184 = phi ptr [ %v167, %bb21 ]
  %v185 = phi i64 [ %v168, %bb21 ]
  %v186 = phi i64 [ %v169, %bb21 ]
  %v187 = phi i64 [ %v170, %bb21 ]
  %v242 = call %wf.t.7d7f918f7b4962fd @wf_std.collections.hash_map.hash_map_rehash$instance$fde7c6722a8b0dad(ptr %v183, ptr %v182)
  store %wf.t.7d7f918f7b4962fd %v242, ptr %wf.slot.5
  %v243 = call i8 @wf_map_cost_rebuild_result(ptr %wf.slot.5, ptr %v184)
  %v244 = select i1 true, i64 0, i64 0
  br label %bb27
bb23:
  %v194 = phi i64 [ %v157, %bb24 ], [ %v157, %bb25 ]
  %v195 = phi i64 [ %v158, %bb24 ], [ %v158, %bb25 ]
  %v196 = phi i64 [ %v159, %bb24 ], [ %v159, %bb25 ]
  %v197 = phi i64 [ %v160, %bb24 ], [ %v160, %bb25 ]
  %v198 = phi i64 [ %v161, %bb24 ], [ %v161, %bb25 ]
  %v199 = phi i64 [ %v162, %bb24 ], [ %v162, %bb25 ]
  %v200 = phi i64 [ %v163, %bb24 ], [ %v163, %bb25 ]
  %v201 = phi i1 [ %v164, %bb24 ], [ %v164, %bb25 ]
  %v202 = phi ptr [ %v165, %bb24 ], [ %v165, %bb25 ]
  %v203 = phi ptr [ %v166, %bb24 ], [ %v166, %bb25 ]
  %v204 = phi ptr [ %v167, %bb24 ], [ %v167, %bb25 ]
  %v205 = phi i64 [ %v168, %bb24 ], [ %v168, %bb25 ]
  %v206 = phi i64 [ %v169, %bb24 ], [ %v169, %bb25 ]
  %v207 = phi i64 [ %v170, %bb24 ], [ %v170, %bb25 ]
  %v208 = phi i64 [ %v173, %bb24 ], [ %v173, %bb25 ]
  %v209 = phi i64 [ %v190, %bb24 ], [ %v190, %bb25 ]
  %v210 = phi ptr [ %v192, %bb24 ], [ %v192, %bb25 ]
  %v221 = call %wf.t.b7e1ed626c09888a @wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50(ptr %v203, ptr %v210, ptr %v202, ptr %v204)
  store %wf.t.b7e1ed626c09888a %v221, ptr %wf.slot.4
  %v222 = call i8 @wf_map_cost_lookup_result(ptr %wf.slot.4, ptr %v204)
  br label %bb26
bb24:
  %t14 = getelementptr inbounds %wf.t.84dc23e49b76868c, ptr %wf.slot.2, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.3, ptr %t14, i64 ptrtoint (ptr getelementptr (%wf.t.c5066f96ffdbc504, ptr null, i32 1) to i64), i1 false)
  %v213 = select i1 true, i64 1, i64 1
  %v214 = call i8 @wf_map_cost_ordered(ptr %v167, i64 %v213)
  %t15 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.3, i32 0, i32 0
  %v215 = load i64, ptr %t15
  ; ownership-consuming projection
  %t16 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.3, i32 0, i32 1
  %v216 = load i64, ptr %t16
  ; ownership-consuming projection
  %v217 = call i64 @wf_map_cost_word_content(i64 %v215, i64 %v216)
  %v218 = call i8 @wf_map_cost_ordered(ptr %v167, i64 %v217)
  br label %bb23
bb25:
  %v219 = select i1 true, i64 0, i64 0
  %v220 = call i8 @wf_map_cost_ordered(ptr %v167, i64 %v219)
  br label %bb23
bb26:
  %v223 = phi i64 [ %v194, %bb23 ]
  %v224 = phi i64 [ %v195, %bb23 ]
  %v225 = phi i64 [ %v196, %bb23 ]
  %v226 = phi i64 [ %v197, %bb23 ]
  %v227 = phi i64 [ %v198, %bb23 ]
  %v228 = phi i64 [ %v199, %bb23 ]
  %v229 = phi i64 [ %v200, %bb23 ]
  %v230 = phi i1 [ %v201, %bb23 ]
  %v231 = phi ptr [ %v202, %bb23 ]
  %v232 = phi ptr [ %v203, %bb23 ]
  %v233 = phi ptr [ %v204, %bb23 ]
  %v234 = phi i64 [ %v205, %bb23 ]
  %v235 = phi i64 [ %v206, %bb23 ]
  %v236 = phi i64 [ %v207, %bb23 ]
  %v237 = phi i64 [ %v171, %bb23 ]
  %v238 = phi i64 [ %v172, %bb23 ]
  %v239 = phi i64 [ %v173, %bb23 ]
  %v240 = select i1 true, i64 1, i64 1
  %v241 = add i64 %v239, %v240
  br label %bb19
bb27:
  %v245 = phi i64 [ %v174, %bb22 ], [ %v283, %bb31 ]
  %v246 = phi i64 [ %v175, %bb22 ], [ %v284, %bb31 ]
  %v247 = phi i64 [ %v176, %bb22 ], [ %v285, %bb31 ]
  %v248 = phi i64 [ %v177, %bb22 ], [ %v286, %bb31 ]
  %v249 = phi i64 [ %v178, %bb22 ], [ %v287, %bb31 ]
  %v250 = phi i64 [ %v179, %bb22 ], [ %v288, %bb31 ]
  %v251 = phi i64 [ %v180, %bb22 ], [ %v289, %bb31 ]
  %v252 = phi i1 [ %v181, %bb22 ], [ %v290, %bb31 ]
  %v253 = phi ptr [ %v182, %bb22 ], [ %v291, %bb31 ]
  %v254 = phi ptr [ %v183, %bb22 ], [ %v292, %bb31 ]
  %v255 = phi ptr [ %v184, %bb22 ], [ %v293, %bb31 ]
  %v256 = phi i64 [ %v185, %bb22 ], [ %v294, %bb31 ]
  %v257 = phi i64 [ %v186, %bb22 ], [ %v295, %bb31 ]
  %v258 = phi i64 [ %v187, %bb22 ], [ %v296, %bb31 ]
  %v260 = phi i64 [ %v244, %bb22 ], [ %v298, %bb31 ]
  %v261 = phi i64 [ %v175, %bb22 ], [ %v299, %bb31 ]
  %v262 = phi i64 [ %v244, %bb22 ], [ %v302, %bb31 ]
  %v278 = icmp ult i64 %v262, %v261
  switch i1 %v278, label %invalid.tag.b27 [
    i1 1, label %bb28
    i1 0, label %bb29
  ]
invalid.tag.b27:
  unreachable
bb28:
  %v279 = call i64 @wf_map_cost_key(i64 %v262)
  store i64 %v279, ptr %v280
  %v281 = call %wf.t.b7e1ed626c09888a @wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50(ptr %v254, ptr %v280, ptr %v253, ptr %v255)
  store %wf.t.b7e1ed626c09888a %v281, ptr %wf.slot.6
  %v282 = call i8 @wf_map_cost_lookup_result(ptr %wf.slot.6, ptr %v255)
  br label %bb31
bb29:
  br label %bb30
bb30:
  %v263 = phi i64 [ %v245, %bb29 ]
  %v264 = phi i64 [ %v246, %bb29 ]
  %v265 = phi i64 [ %v247, %bb29 ]
  %v266 = phi i64 [ %v248, %bb29 ]
  %v267 = phi i64 [ %v249, %bb29 ]
  %v268 = phi i64 [ %v250, %bb29 ]
  %v269 = phi i64 [ %v251, %bb29 ]
  %v270 = phi i1 [ %v252, %bb29 ]
  %v271 = phi ptr [ %v253, %bb29 ]
  %v272 = phi ptr [ %v254, %bb29 ]
  %v273 = phi ptr [ %v255, %bb29 ]
  %v274 = phi i64 [ %v256, %bb29 ]
  %v275 = phi i64 [ %v257, %bb29 ]
  %v276 = phi i64 [ %v258, %bb29 ]
  %v303 = select i1 true, i64 0, i64 0
  br label %bb32
bb31:
  %v283 = phi i64 [ %v245, %bb28 ]
  %v284 = phi i64 [ %v246, %bb28 ]
  %v285 = phi i64 [ %v247, %bb28 ]
  %v286 = phi i64 [ %v248, %bb28 ]
  %v287 = phi i64 [ %v249, %bb28 ]
  %v288 = phi i64 [ %v250, %bb28 ]
  %v289 = phi i64 [ %v251, %bb28 ]
  %v290 = phi i1 [ %v252, %bb28 ]
  %v291 = phi ptr [ %v253, %bb28 ]
  %v292 = phi ptr [ %v254, %bb28 ]
  %v293 = phi ptr [ %v255, %bb28 ]
  %v294 = phi i64 [ %v256, %bb28 ]
  %v295 = phi i64 [ %v257, %bb28 ]
  %v296 = phi i64 [ %v258, %bb28 ]
  %v298 = phi i64 [ %v260, %bb28 ]
  %v299 = phi i64 [ %v261, %bb28 ]
  %v300 = phi i64 [ %v262, %bb28 ]
  %v301 = select i1 true, i64 1, i64 1
  %v302 = add i64 %v300, %v301
  br label %bb27
bb32:
  %v304 = phi i64 [ %v263, %bb30 ], [ %v410, %bb42 ]
  %v305 = phi i64 [ %v264, %bb30 ], [ %v411, %bb42 ]
  %v306 = phi i64 [ %v265, %bb30 ], [ %v412, %bb42 ]
  %v307 = phi i64 [ %v266, %bb30 ], [ %v413, %bb42 ]
  %v308 = phi i64 [ %v267, %bb30 ], [ %v414, %bb42 ]
  %v309 = phi i64 [ %v268, %bb30 ], [ %v415, %bb42 ]
  %v310 = phi i64 [ %v269, %bb30 ], [ %v416, %bb42 ]
  %v311 = phi i1 [ %v270, %bb30 ], [ %v417, %bb42 ]
  %v312 = phi ptr [ %v271, %bb30 ], [ %v418, %bb42 ]
  %v313 = phi ptr [ %v272, %bb30 ], [ %v419, %bb42 ]
  %v314 = phi ptr [ %v273, %bb30 ], [ %v420, %bb42 ]
  %v315 = phi i64 [ %v274, %bb30 ], [ %v421, %bb42 ]
  %v316 = phi i64 [ %v275, %bb30 ], [ %v422, %bb42 ]
  %v317 = phi i64 [ %v276, %bb30 ], [ %v423, %bb42 ]
  %v319 = phi i64 [ %v303, %bb30 ], [ %v425, %bb42 ]
  %v320 = phi i64 [ %v276, %bb30 ], [ %v426, %bb42 ]
  %v321 = phi i64 [ %v303, %bb30 ], [ %v429, %bb42 ]
  %v337 = icmp ult i64 %v321, %v320
  switch i1 %v337, label %invalid.tag.b32 [
    i1 1, label %bb33
    i1 0, label %bb34
  ]
invalid.tag.b32:
  unreachable
bb33:
  %v338 = select i1 true, i64 2, i64 2
  %v339 = mul i64 %v321, %v338
  %v340 = call i64 @wf_map_cost_key(i64 %v339)
  %v341 = select i1 true, i64 1, i64 1
  %v342 = add i64 %v315, %v341
  %v343 = mul i64 %v342, %v305
  %v344 = add i64 %v307, %v343
  %v345 = add i64 %v344, %v339
  %v346 = call i64 @wf_map_cost_word_make(i64 %v345)
  call void @wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad(ptr %wf.slot.7, ptr %v313, i64 %v340, i64 %v346, ptr %v312)
  %t17 = load %wf.t.5591089753cba638, ptr %wf.slot.7
  %t18 = extractvalue %wf.t.5591089753cba638 %t17, 0
  switch i32 %t18, label %invalid.tag.b33 [
    i32 0, label %bb37
    i32 1, label %bb38
  ]
invalid.tag.b33:
  unreachable
bb34:
  br label %bb35
bb35:
  %v322 = phi i64 [ %v304, %bb34 ]
  %v323 = phi i64 [ %v305, %bb34 ]
  %v324 = phi i64 [ %v306, %bb34 ]
  %v325 = phi i64 [ %v307, %bb34 ]
  %v326 = phi i64 [ %v308, %bb34 ]
  %v327 = phi i64 [ %v309, %bb34 ]
  %v328 = phi i64 [ %v310, %bb34 ]
  %v329 = phi i1 [ %v311, %bb34 ]
  %v330 = phi ptr [ %v312, %bb34 ]
  %v331 = phi ptr [ %v313, %bb34 ]
  %v332 = phi ptr [ %v314, %bb34 ]
  %v333 = phi i64 [ %v315, %bb34 ]
  %v334 = phi i64 [ %v316, %bb34 ]
  %v335 = phi i64 [ %v317, %bb34 ]
  br label %bb16
bb36:
  %v348 = phi i64 [ %v304, %bb37 ], [ %v376, %bb39 ]
  %v349 = phi i64 [ %v305, %bb37 ], [ %v377, %bb39 ]
  %v350 = phi i64 [ %v306, %bb37 ], [ %v378, %bb39 ]
  %v351 = phi i64 [ %v307, %bb37 ], [ %v379, %bb39 ]
  %v352 = phi i64 [ %v308, %bb37 ], [ %v380, %bb39 ]
  %v353 = phi i64 [ %v309, %bb37 ], [ %v381, %bb39 ]
  %v354 = phi i64 [ %v310, %bb37 ], [ %v382, %bb39 ]
  %v355 = phi i1 [ %v311, %bb37 ], [ %v383, %bb39 ]
  %v356 = phi ptr [ %v312, %bb37 ], [ %v384, %bb39 ]
  %v357 = phi ptr [ %v313, %bb37 ], [ %v385, %bb39 ]
  %v358 = phi ptr [ %v314, %bb37 ], [ %v386, %bb39 ]
  %v359 = phi i64 [ %v315, %bb37 ], [ %v387, %bb39 ]
  %v360 = phi i64 [ %v316, %bb37 ], [ %v388, %bb39 ]
  %v361 = phi i64 [ %v317, %bb37 ], [ %v389, %bb39 ]
  %v363 = phi i64 [ %v321, %bb37 ], [ %v391, %bb39 ]
  %v364 = phi i64 [ %v339, %bb37 ], [ %v392, %bb39 ]
  %v365 = phi i64 [ %v340, %bb37 ], [ %v393, %bb39 ]
  %v366 = phi i64 [ %v342, %bb37 ], [ %v394, %bb39 ]
  %v367 = phi i64 [ %v343, %bb37 ], [ %v395, %bb39 ]
  %v368 = phi i64 [ %v344, %bb37 ], [ %v396, %bb39 ]
  %v369 = phi i64 [ %v345, %bb37 ], [ %v397, %bb39 ]
  %v370 = phi i64 [ %v346, %bb37 ], [ %v398, %bb39 ]
  br label %bb42
bb37:
  %v372 = select i1 true, i64 0, i64 0
  %v373 = call i8 @wf_map_cost_ordered(ptr %v314, i64 %v372)
  br label %bb36
bb38:
  %t19 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.slot.7, i32 0, i32 1
  %v374 = load i1, ptr %t19
  %t20 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.slot.7, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.8, ptr %t20, i64 ptrtoint (ptr getelementptr (%wf.t.c5066f96ffdbc504, ptr null, i32 1) to i64), i1 false)
  switch i1 %v374, label %invalid.tag.b38 [
    i1 0, label %bb40
    i1 1, label %bb41
  ]
invalid.tag.b38:
  unreachable
bb39:
  %v376 = phi i64 [ %v304, %bb40 ], [ %v304, %bb41 ]
  %v377 = phi i64 [ %v305, %bb40 ], [ %v305, %bb41 ]
  %v378 = phi i64 [ %v306, %bb40 ], [ %v306, %bb41 ]
  %v379 = phi i64 [ %v307, %bb40 ], [ %v307, %bb41 ]
  %v380 = phi i64 [ %v308, %bb40 ], [ %v308, %bb41 ]
  %v381 = phi i64 [ %v309, %bb40 ], [ %v309, %bb41 ]
  %v382 = phi i64 [ %v310, %bb40 ], [ %v310, %bb41 ]
  %v383 = phi i1 [ %v311, %bb40 ], [ %v311, %bb41 ]
  %v384 = phi ptr [ %v312, %bb40 ], [ %v312, %bb41 ]
  %v385 = phi ptr [ %v313, %bb40 ], [ %v313, %bb41 ]
  %v386 = phi ptr [ %v314, %bb40 ], [ %v314, %bb41 ]
  %v387 = phi i64 [ %v315, %bb40 ], [ %v315, %bb41 ]
  %v388 = phi i64 [ %v316, %bb40 ], [ %v316, %bb41 ]
  %v389 = phi i64 [ %v317, %bb40 ], [ %v317, %bb41 ]
  %v391 = phi i64 [ %v321, %bb40 ], [ %v321, %bb41 ]
  %v392 = phi i64 [ %v339, %bb40 ], [ %v339, %bb41 ]
  %v393 = phi i64 [ %v340, %bb40 ], [ %v340, %bb41 ]
  %v394 = phi i64 [ %v342, %bb40 ], [ %v342, %bb41 ]
  %v395 = phi i64 [ %v343, %bb40 ], [ %v343, %bb41 ]
  %v396 = phi i64 [ %v344, %bb40 ], [ %v344, %bb41 ]
  %v397 = phi i64 [ %v345, %bb40 ], [ %v345, %bb41 ]
  %v398 = phi i64 [ %v346, %bb40 ], [ %v346, %bb41 ]
  %v400 = phi i1 [ %v374, %bb40 ], [ %v374, %bb41 ]
  %t21 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.8, i32 0, i32 0
  %v406 = load i64, ptr %t21
  ; ownership-consuming projection
  %t22 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.8, i32 0, i32 1
  %v407 = load i64, ptr %t22
  ; ownership-consuming projection
  %v408 = call i64 @wf_map_cost_word_content(i64 %v406, i64 %v407)
  %v409 = call i8 @wf_map_cost_ordered(ptr %v386, i64 %v408)
  br label %bb36
bb40:
  %v402 = select i1 true, i64 1, i64 1
  %v403 = call i8 @wf_map_cost_ordered(ptr %v314, i64 %v402)
  br label %bb39
bb41:
  %v404 = select i1 true, i64 2, i64 2
  %v405 = call i8 @wf_map_cost_ordered(ptr %v314, i64 %v404)
  br label %bb39
bb42:
  %v410 = phi i64 [ %v348, %bb36 ]
  %v411 = phi i64 [ %v349, %bb36 ]
  %v412 = phi i64 [ %v350, %bb36 ]
  %v413 = phi i64 [ %v351, %bb36 ]
  %v414 = phi i64 [ %v352, %bb36 ]
  %v415 = phi i64 [ %v353, %bb36 ]
  %v416 = phi i64 [ %v354, %bb36 ]
  %v417 = phi i1 [ %v355, %bb36 ]
  %v418 = phi ptr [ %v356, %bb36 ]
  %v419 = phi ptr [ %v357, %bb36 ]
  %v420 = phi ptr [ %v358, %bb36 ]
  %v421 = phi i64 [ %v359, %bb36 ]
  %v422 = phi i64 [ %v360, %bb36 ]
  %v423 = phi i64 [ %v361, %bb36 ]
  %v425 = phi i64 [ %v319, %bb36 ]
  %v426 = phi i64 [ %v320, %bb36 ]
  %v427 = phi i64 [ %v321, %bb36 ]
  %v428 = select i1 true, i64 1, i64 1
  %v429 = add i64 %v427, %v428
  br label %bb32
bb43:
  %v438 = phi i64 [ %v113, %bb45 ], [ %v502, %bb52 ]
  %v439 = phi i64 [ %v114, %bb45 ], [ %v503, %bb52 ]
  %v440 = phi i64 [ %v115, %bb45 ], [ %v504, %bb52 ]
  %v441 = phi i64 [ %v116, %bb45 ], [ %v505, %bb52 ]
  %v442 = phi i64 [ %v117, %bb45 ], [ %v506, %bb52 ]
  %v443 = phi i64 [ %v118, %bb45 ], [ %v507, %bb52 ]
  %v444 = phi i64 [ %v119, %bb45 ], [ %v508, %bb52 ]
  %v445 = phi i1 [ %v120, %bb45 ], [ %v509, %bb52 ]
  %v446 = phi ptr [ %v121, %bb45 ], [ %v510, %bb52 ]
  %v447 = phi ptr [ %v122, %bb45 ], [ %v511, %bb52 ]
  %v448 = phi ptr [ %v123, %bb45 ], [ %v512, %bb52 ]
  %v449 = phi i64 [ %v126, %bb45 ], [ %v513, %bb52 ]
  %v450 = phi i1 [ %v431, %bb45 ], [ %v514, %bb52 ]
  %v451 = phi i1 [ %v433, %bb45 ], [ %v515, %bb52 ]
  %v452 = phi i1 [ %v435, %bb45 ], [ %v516, %bb52 ]
  %v453 = phi i1 [ %v436, %bb45 ], [ %v517, %bb52 ]
  %v454 = phi i1 [ %v437, %bb45 ], [ %v518, %bb52 ]
  %v545 = select i1 true, i64 0, i64 0
  br label %bb58
bb44:
  %v455 = select i1 true, i64 1, i64 1
  %v456 = select i1 true, i64 0, i64 0
  %v457 = icmp ne i64 %v113, %v456
  switch i1 %v457, label %invalid.tag.b44 [
    i1 1, label %bb47
    i1 0, label %bb48
  ]
invalid.tag.b44:
  unreachable
bb45:
  br label %bb43
bb46:
  %v458 = phi i64 [ %v113, %bb47 ], [ %v113, %bb48 ]
  %v459 = phi i64 [ %v114, %bb47 ], [ %v114, %bb48 ]
  %v460 = phi i64 [ %v115, %bb47 ], [ %v115, %bb48 ]
  %v461 = phi i64 [ %v116, %bb47 ], [ %v116, %bb48 ]
  %v462 = phi i64 [ %v117, %bb47 ], [ %v117, %bb48 ]
  %v463 = phi i64 [ %v118, %bb47 ], [ %v118, %bb48 ]
  %v464 = phi i64 [ %v119, %bb47 ], [ %v119, %bb48 ]
  %v465 = phi i1 [ %v120, %bb47 ], [ %v120, %bb48 ]
  %v466 = phi ptr [ %v121, %bb47 ], [ %v121, %bb48 ]
  %v467 = phi ptr [ %v122, %bb47 ], [ %v122, %bb48 ]
  %v468 = phi ptr [ %v123, %bb47 ], [ %v123, %bb48 ]
  %v469 = phi i64 [ %v126, %bb47 ], [ %v126, %bb48 ]
  %v470 = phi i1 [ %v431, %bb47 ], [ %v431, %bb48 ]
  %v471 = phi i1 [ %v433, %bb47 ], [ %v433, %bb48 ]
  %v472 = phi i1 [ %v435, %bb47 ], [ %v435, %bb48 ]
  %v473 = phi i1 [ %v436, %bb47 ], [ %v436, %bb48 ]
  %v474 = phi i1 [ %v437, %bb47 ], [ %v437, %bb48 ]
  %v475 = phi i64 [ %v477, %bb47 ], [ %v455, %bb48 ]
  %v478 = select i1 true, i64 10, i64 10
  %v479 = icmp eq i64 %v462, %v478
  switch i1 %v479, label %invalid.tag.b46 [
    i1 1, label %bb50
    i1 0, label %bb51
  ]
invalid.tag.b46:
  unreachable
bb47:
  %v476 = select i1 true, i64 2, i64 2
  %v477 = mul nuw i64 %v113, %v476
  br label %bb46
bb48:
  br label %bb46
bb49:
  %v480 = phi i64 [ %v458, %bb50 ], [ %v458, %bb51 ]
  %v481 = phi i64 [ %v459, %bb50 ], [ %v459, %bb51 ]
  %v482 = phi i64 [ %v460, %bb50 ], [ %v460, %bb51 ]
  %v483 = phi i64 [ %v461, %bb50 ], [ %v461, %bb51 ]
  %v484 = phi i64 [ %v462, %bb50 ], [ %v462, %bb51 ]
  %v485 = phi i64 [ %v463, %bb50 ], [ %v463, %bb51 ]
  %v486 = phi i64 [ %v464, %bb50 ], [ %v464, %bb51 ]
  %v487 = phi i1 [ %v465, %bb50 ], [ %v465, %bb51 ]
  %v488 = phi ptr [ %v466, %bb50 ], [ %v466, %bb51 ]
  %v489 = phi ptr [ %v467, %bb50 ], [ %v467, %bb51 ]
  %v490 = phi ptr [ %v468, %bb50 ], [ %v468, %bb51 ]
  %v491 = phi i64 [ %v469, %bb50 ], [ %v469, %bb51 ]
  %v492 = phi i1 [ %v470, %bb50 ], [ %v470, %bb51 ]
  %v493 = phi i1 [ %v471, %bb50 ], [ %v471, %bb51 ]
  %v494 = phi i1 [ %v472, %bb50 ], [ %v472, %bb51 ]
  %v495 = phi i1 [ %v473, %bb50 ], [ %v473, %bb51 ]
  %v496 = phi i1 [ %v474, %bb50 ], [ %v474, %bb51 ]
  %v497 = phi i64 [ %v475, %bb50 ], [ %v475, %bb51 ]
  switch i1 %v495, label %invalid.tag.b49 [
    i1 1, label %bb53
    i1 0, label %bb54
  ]
invalid.tag.b49:
  unreachable
bb50:
  %v498 = select i1 true, i64 1, i64 1
  %v499 = call i8 @wf_map_cost_ordered(ptr %v468, i64 %v498)
  br label %bb49
bb51:
  %v500 = call %wf.t.7d7f918f7b4962fd @wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad(ptr %v467, i64 %v475, ptr %v466)
  store %wf.t.7d7f918f7b4962fd %v500, ptr %wf.slot.9
  %v501 = call i8 @wf_map_cost_rebuild_result(ptr %wf.slot.9, ptr %v468)
  br label %bb49
bb52:
  %v502 = phi i64 [ %v480, %bb54 ], [ %v522, %bb55 ]
  %v503 = phi i64 [ %v481, %bb54 ], [ %v523, %bb55 ]
  %v504 = phi i64 [ %v482, %bb54 ], [ %v524, %bb55 ]
  %v505 = phi i64 [ %v483, %bb54 ], [ %v525, %bb55 ]
  %v506 = phi i64 [ %v484, %bb54 ], [ %v526, %bb55 ]
  %v507 = phi i64 [ %v485, %bb54 ], [ %v527, %bb55 ]
  %v508 = phi i64 [ %v486, %bb54 ], [ %v528, %bb55 ]
  %v509 = phi i1 [ %v487, %bb54 ], [ %v529, %bb55 ]
  %v510 = phi ptr [ %v488, %bb54 ], [ %v530, %bb55 ]
  %v511 = phi ptr [ %v489, %bb54 ], [ %v531, %bb55 ]
  %v512 = phi ptr [ %v490, %bb54 ], [ %v532, %bb55 ]
  %v513 = phi i64 [ %v491, %bb54 ], [ %v533, %bb55 ]
  %v514 = phi i1 [ %v492, %bb54 ], [ %v534, %bb55 ]
  %v515 = phi i1 [ %v493, %bb54 ], [ %v535, %bb55 ]
  %v516 = phi i1 [ %v494, %bb54 ], [ %v536, %bb55 ]
  %v517 = phi i1 [ %v495, %bb54 ], [ %v537, %bb55 ]
  %v518 = phi i1 [ %v496, %bb54 ], [ %v538, %bb55 ]
  %v519 = phi i64 [ %v497, %bb54 ], [ %v539, %bb55 ]
  br label %bb43
bb53:
  %v520 = call i64 @wf_std.collections.hash_map.hash_map_capacity$instance$820b2044b97e0fbd(ptr %v489)
  %v521 = icmp uge i64 %v520, %v497
  switch i1 %v521, label %invalid.tag.b53 [
    i1 1, label %bb56
    i1 0, label %bb57
  ]
invalid.tag.b53:
  unreachable
bb54:
  br label %bb52
bb55:
  %v522 = phi i64 [ %v480, %bb56 ], [ %v480, %bb57 ]
  %v523 = phi i64 [ %v481, %bb56 ], [ %v481, %bb57 ]
  %v524 = phi i64 [ %v482, %bb56 ], [ %v482, %bb57 ]
  %v525 = phi i64 [ %v483, %bb56 ], [ %v483, %bb57 ]
  %v526 = phi i64 [ %v484, %bb56 ], [ %v484, %bb57 ]
  %v527 = phi i64 [ %v485, %bb56 ], [ %v485, %bb57 ]
  %v528 = phi i64 [ %v486, %bb56 ], [ %v486, %bb57 ]
  %v529 = phi i1 [ %v487, %bb56 ], [ %v487, %bb57 ]
  %v530 = phi ptr [ %v488, %bb56 ], [ %v488, %bb57 ]
  %v531 = phi ptr [ %v489, %bb56 ], [ %v489, %bb57 ]
  %v532 = phi ptr [ %v490, %bb56 ], [ %v490, %bb57 ]
  %v533 = phi i64 [ %v491, %bb56 ], [ %v491, %bb57 ]
  %v534 = phi i1 [ %v492, %bb56 ], [ %v492, %bb57 ]
  %v535 = phi i1 [ %v493, %bb56 ], [ %v493, %bb57 ]
  %v536 = phi i1 [ %v494, %bb56 ], [ %v494, %bb57 ]
  %v537 = phi i1 [ %v495, %bb56 ], [ %v495, %bb57 ]
  %v538 = phi i1 [ %v496, %bb56 ], [ %v496, %bb57 ]
  %v539 = phi i64 [ %v497, %bb56 ], [ %v497, %bb57 ]
  %v540 = phi i64 [ %v520, %bb56 ], [ %v520, %bb57 ]
  br label %bb52
bb56:
  %v541 = select i1 true, i64 1, i64 1
  %v542 = call i8 @wf_map_cost_ordered(ptr %v490, i64 %v541)
  br label %bb55
bb57:
  %v543 = select i1 true, i64 0, i64 0
  %v544 = call i8 @wf_map_cost_ordered(ptr %v490, i64 %v543)
  br label %bb55
bb58:
  %v546 = phi i64 [ %v438, %bb43 ], [ %v925, %bb92 ]
  %v547 = phi i64 [ %v439, %bb43 ], [ %v926, %bb92 ]
  %v548 = phi i64 [ %v440, %bb43 ], [ %v927, %bb92 ]
  %v549 = phi i64 [ %v441, %bb43 ], [ %v928, %bb92 ]
  %v550 = phi i64 [ %v442, %bb43 ], [ %v929, %bb92 ]
  %v551 = phi i64 [ %v443, %bb43 ], [ %v930, %bb92 ]
  %v552 = phi i64 [ %v444, %bb43 ], [ %v931, %bb92 ]
  %v553 = phi i1 [ %v445, %bb43 ], [ %v932, %bb92 ]
  %v554 = phi ptr [ %v446, %bb43 ], [ %v933, %bb92 ]
  %v555 = phi ptr [ %v447, %bb43 ], [ %v934, %bb92 ]
  %v556 = phi ptr [ %v448, %bb43 ], [ %v935, %bb92 ]
  %v557 = phi i64 [ %v449, %bb43 ], [ %v936, %bb92 ]
  %v558 = phi i1 [ %v450, %bb43 ], [ %v937, %bb92 ]
  %v559 = phi i1 [ %v451, %bb43 ], [ %v938, %bb92 ]
  %v560 = phi i1 [ %v452, %bb43 ], [ %v939, %bb92 ]
  %v561 = phi i1 [ %v453, %bb43 ], [ %v940, %bb92 ]
  %v562 = phi i1 [ %v454, %bb43 ], [ %v941, %bb92 ]
  %v563 = phi i64 [ %v545, %bb43 ], [ %v942, %bb92 ]
  %v564 = phi i64 [ %v439, %bb43 ], [ %v943, %bb92 ]
  %v565 = phi i64 [ %v545, %bb43 ], [ %v946, %bb92 ]
  %v583 = icmp ult i64 %v565, %v564
  switch i1 %v583, label %invalid.tag.b58 [
    i1 1, label %bb59
    i1 0, label %bb60
  ]
invalid.tag.b58:
  unreachable
bb59:
  %v584 = select i1 true, i64 1, i64 1
  %v585 = icmp eq i64 %v550, %v584
  switch i1 %v585, label %invalid.tag.b59 [
    i1 1, label %bb63
    i1 0, label %bb64
  ]
invalid.tag.b59:
  unreachable
bb60:
  br label %bb61
bb61:
  %v566 = phi i64 [ %v546, %bb60 ]
  %v567 = phi i64 [ %v547, %bb60 ]
  %v568 = phi i64 [ %v548, %bb60 ]
  %v569 = phi i64 [ %v549, %bb60 ]
  %v570 = phi i64 [ %v550, %bb60 ]
  %v571 = phi i64 [ %v551, %bb60 ]
  %v572 = phi i64 [ %v552, %bb60 ]
  %v573 = phi i1 [ %v553, %bb60 ]
  %v574 = phi ptr [ %v554, %bb60 ]
  %v575 = phi ptr [ %v555, %bb60 ]
  %v576 = phi ptr [ %v556, %bb60 ]
  %v577 = phi i64 [ %v557, %bb60 ]
  %v578 = phi i1 [ %v558, %bb60 ]
  %v579 = phi i1 [ %v559, %bb60 ]
  %v580 = phi i1 [ %v560, %bb60 ]
  %v581 = phi i1 [ %v561, %bb60 ]
  %v582 = phi i1 [ %v562, %bb60 ]
  br label %bb16
bb62:
  %v586 = phi i64 [ %v546, %bb63 ], [ %v546, %bb64 ]
  %v587 = phi i64 [ %v547, %bb63 ], [ %v547, %bb64 ]
  %v588 = phi i64 [ %v548, %bb63 ], [ %v548, %bb64 ]
  %v589 = phi i64 [ %v549, %bb63 ], [ %v549, %bb64 ]
  %v590 = phi i64 [ %v550, %bb63 ], [ %v550, %bb64 ]
  %v591 = phi i64 [ %v551, %bb63 ], [ %v551, %bb64 ]
  %v592 = phi i64 [ %v552, %bb63 ], [ %v552, %bb64 ]
  %v593 = phi i1 [ %v553, %bb63 ], [ %v553, %bb64 ]
  %v594 = phi ptr [ %v554, %bb63 ], [ %v554, %bb64 ]
  %v595 = phi ptr [ %v555, %bb63 ], [ %v555, %bb64 ]
  %v596 = phi ptr [ %v556, %bb63 ], [ %v556, %bb64 ]
  %v597 = phi i64 [ %v557, %bb63 ], [ %v557, %bb64 ]
  %v598 = phi i1 [ %v558, %bb63 ], [ %v558, %bb64 ]
  %v599 = phi i1 [ %v559, %bb63 ], [ %v559, %bb64 ]
  %v600 = phi i1 [ %v560, %bb63 ], [ %v560, %bb64 ]
  %v601 = phi i1 [ %v561, %bb63 ], [ %v561, %bb64 ]
  %v602 = phi i1 [ %v562, %bb63 ], [ %v562, %bb64 ]
  %v603 = phi i64 [ %v565, %bb63 ], [ %v565, %bb64 ]
  %v604 = phi i64 [ %v605, %bb63 ], [ %v565, %bb64 ]
  %v606 = call i64 @wf_map_cost_key(i64 %v604)
  store i64 %v606, ptr %v607
  %v608 = select i1 true, i64 0, i64 0
  %v609 = icmp eq i64 %v590, %v608
  %v610 = select i1 true, i64 1, i64 1
  %v611 = icmp eq i64 %v590, %v610
  %v612 = or i1 %v609, %v611
  %v613 = or i1 %v612, %v602
  switch i1 %v613, label %invalid.tag.b62 [
    i1 1, label %bb66
    i1 0, label %bb67
  ]
invalid.tag.b62:
  unreachable
bb63:
  %v605 = add i64 %v547, %v565
  br label %bb62
bb64:
  br label %bb62
bb65:
  %v614 = phi i64 [ %v586, %bb66 ], [ %v642, %bb68 ]
  %v615 = phi i64 [ %v587, %bb66 ], [ %v643, %bb68 ]
  %v616 = phi i64 [ %v588, %bb66 ], [ %v644, %bb68 ]
  %v617 = phi i64 [ %v589, %bb66 ], [ %v645, %bb68 ]
  %v618 = phi i64 [ %v590, %bb66 ], [ %v646, %bb68 ]
  %v619 = phi i64 [ %v591, %bb66 ], [ %v647, %bb68 ]
  %v620 = phi i64 [ %v592, %bb66 ], [ %v648, %bb68 ]
  %v621 = phi i1 [ %v593, %bb66 ], [ %v649, %bb68 ]
  %v622 = phi ptr [ %v594, %bb66 ], [ %v650, %bb68 ]
  %v623 = phi ptr [ %v595, %bb66 ], [ %v651, %bb68 ]
  %v624 = phi ptr [ %v596, %bb66 ], [ %v652, %bb68 ]
  %v625 = phi i64 [ %v597, %bb66 ], [ %v653, %bb68 ]
  %v626 = phi i1 [ %v598, %bb66 ], [ %v654, %bb68 ]
  %v627 = phi i1 [ %v599, %bb66 ], [ %v655, %bb68 ]
  %v628 = phi i1 [ %v600, %bb66 ], [ %v656, %bb68 ]
  %v629 = phi i1 [ %v601, %bb66 ], [ %v657, %bb68 ]
  %v630 = phi i1 [ %v602, %bb66 ], [ %v658, %bb68 ]
  %v631 = phi i64 [ %v603, %bb66 ], [ %v659, %bb68 ]
  %v632 = phi i64 [ %v604, %bb66 ], [ %v660, %bb68 ]
  %v633 = phi ptr [ %v607, %bb66 ], [ %v661, %bb68 ]
  %v634 = phi i1 [ %v609, %bb66 ], [ %v662, %bb68 ]
  %v635 = phi i1 [ %v611, %bb66 ], [ %v663, %bb68 ]
  %v636 = phi i1 [ %v612, %bb66 ], [ %v664, %bb68 ]
  %v637 = phi i1 [ %v613, %bb66 ], [ %v665, %bb68 ]
  br label %bb92
bb66:
  %v638 = call %wf.t.b7e1ed626c09888a @wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50(ptr %v595, ptr %v607, ptr %v594, ptr %v596)
  store %wf.t.b7e1ed626c09888a %v638, ptr %wf.slot.10
  %v639 = call i8 @wf_map_cost_lookup_result(ptr %wf.slot.10, ptr %v596)
  br label %bb65
bb67:
  %v640 = select i1 true, i64 2, i64 2
  %v641 = icmp eq i64 %v590, %v640
  switch i1 %v641, label %invalid.tag.b67 [
    i1 1, label %bb69
    i1 0, label %bb70
  ]
invalid.tag.b67:
  unreachable
bb68:
  %v642 = phi i64 [ %v674, %bb71 ], [ %v750, %bb77 ]
  %v643 = phi i64 [ %v675, %bb71 ], [ %v751, %bb77 ]
  %v644 = phi i64 [ %v676, %bb71 ], [ %v752, %bb77 ]
  %v645 = phi i64 [ %v677, %bb71 ], [ %v753, %bb77 ]
  %v646 = phi i64 [ %v678, %bb71 ], [ %v754, %bb77 ]
  %v647 = phi i64 [ %v679, %bb71 ], [ %v755, %bb77 ]
  %v648 = phi i64 [ %v680, %bb71 ], [ %v756, %bb77 ]
  %v649 = phi i1 [ %v681, %bb71 ], [ %v757, %bb77 ]
  %v650 = phi ptr [ %v682, %bb71 ], [ %v758, %bb77 ]
  %v651 = phi ptr [ %v683, %bb71 ], [ %v759, %bb77 ]
  %v652 = phi ptr [ %v684, %bb71 ], [ %v760, %bb77 ]
  %v653 = phi i64 [ %v685, %bb71 ], [ %v761, %bb77 ]
  %v654 = phi i1 [ %v686, %bb71 ], [ %v762, %bb77 ]
  %v655 = phi i1 [ %v687, %bb71 ], [ %v763, %bb77 ]
  %v656 = phi i1 [ %v688, %bb71 ], [ %v764, %bb77 ]
  %v657 = phi i1 [ %v689, %bb71 ], [ %v765, %bb77 ]
  %v658 = phi i1 [ %v690, %bb71 ], [ %v766, %bb77 ]
  %v659 = phi i64 [ %v691, %bb71 ], [ %v767, %bb77 ]
  %v660 = phi i64 [ %v692, %bb71 ], [ %v768, %bb77 ]
  %v661 = phi ptr [ %v693, %bb71 ], [ %v769, %bb77 ]
  %v662 = phi i1 [ %v694, %bb71 ], [ %v770, %bb77 ]
  %v663 = phi i1 [ %v695, %bb71 ], [ %v771, %bb77 ]
  %v664 = phi i1 [ %v696, %bb71 ], [ %v772, %bb77 ]
  %v665 = phi i1 [ %v697, %bb71 ], [ %v773, %bb77 ]
  br label %bb65
bb69:
  %v666 = select i1 true, i64 1, i64 1
  %v667 = add i64 %v597, %v666
  %v668 = mul i64 %v667, %v587
  %v669 = add i64 %v589, %v668
  %v670 = add i64 %v669, %v603
  %v671 = call i64 @wf_map_cost_word_make(i64 %v670)
  %v672 = load i64, ptr %v607
  call void @wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad(ptr %wf.slot.11, ptr %v595, i64 %v672, i64 %v671, ptr %v594)
  %t23 = load %wf.t.5591089753cba638, ptr %wf.slot.11
  %t24 = extractvalue %wf.t.5591089753cba638 %t23, 0
  switch i32 %t24, label %invalid.tag.b69 [
    i32 0, label %bb72
    i32 1, label %bb73
  ]
invalid.tag.b69:
  unreachable
bb70:
  %v748 = select i1 true, i64 3, i64 3
  %v749 = icmp eq i64 %v590, %v748
  switch i1 %v749, label %invalid.tag.b70 [
    i1 1, label %bb78
    i1 0, label %bb79
  ]
invalid.tag.b70:
  unreachable
bb71:
  %v674 = phi i64 [ %v586, %bb72 ], [ %v708, %bb74 ]
  %v675 = phi i64 [ %v587, %bb72 ], [ %v709, %bb74 ]
  %v676 = phi i64 [ %v588, %bb72 ], [ %v710, %bb74 ]
  %v677 = phi i64 [ %v589, %bb72 ], [ %v711, %bb74 ]
  %v678 = phi i64 [ %v590, %bb72 ], [ %v712, %bb74 ]
  %v679 = phi i64 [ %v591, %bb72 ], [ %v713, %bb74 ]
  %v680 = phi i64 [ %v592, %bb72 ], [ %v714, %bb74 ]
  %v681 = phi i1 [ %v593, %bb72 ], [ %v715, %bb74 ]
  %v682 = phi ptr [ %v594, %bb72 ], [ %v716, %bb74 ]
  %v683 = phi ptr [ %v595, %bb72 ], [ %v717, %bb74 ]
  %v684 = phi ptr [ %v596, %bb72 ], [ %v718, %bb74 ]
  %v685 = phi i64 [ %v597, %bb72 ], [ %v719, %bb74 ]
  %v686 = phi i1 [ %v598, %bb72 ], [ %v720, %bb74 ]
  %v687 = phi i1 [ %v599, %bb72 ], [ %v721, %bb74 ]
  %v688 = phi i1 [ %v600, %bb72 ], [ %v722, %bb74 ]
  %v689 = phi i1 [ %v601, %bb72 ], [ %v723, %bb74 ]
  %v690 = phi i1 [ %v602, %bb72 ], [ %v724, %bb74 ]
  %v691 = phi i64 [ %v603, %bb72 ], [ %v725, %bb74 ]
  %v692 = phi i64 [ %v604, %bb72 ], [ %v726, %bb74 ]
  %v693 = phi ptr [ %v607, %bb72 ], [ %v727, %bb74 ]
  %v694 = phi i1 [ %v609, %bb72 ], [ %v728, %bb74 ]
  %v695 = phi i1 [ %v611, %bb72 ], [ %v729, %bb74 ]
  %v696 = phi i1 [ %v612, %bb72 ], [ %v730, %bb74 ]
  %v697 = phi i1 [ %v613, %bb72 ], [ %v731, %bb74 ]
  %v698 = phi i64 [ %v667, %bb72 ], [ %v732, %bb74 ]
  %v699 = phi i64 [ %v668, %bb72 ], [ %v733, %bb74 ]
  %v700 = phi i64 [ %v669, %bb72 ], [ %v734, %bb74 ]
  %v701 = phi i64 [ %v670, %bb72 ], [ %v735, %bb74 ]
  %v702 = phi i64 [ %v671, %bb72 ], [ %v736, %bb74 ]
  br label %bb68
bb72:
  %v704 = select i1 true, i64 0, i64 0
  %v705 = call i8 @wf_map_cost_ordered(ptr %v596, i64 %v704)
  br label %bb71
bb73:
  %t25 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.slot.11, i32 0, i32 1
  %v706 = load i1, ptr %t25
  %t26 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.slot.11, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.12, ptr %t26, i64 ptrtoint (ptr getelementptr (%wf.t.c5066f96ffdbc504, ptr null, i32 1) to i64), i1 false)
  switch i1 %v706, label %invalid.tag.b73 [
    i1 0, label %bb75
    i1 1, label %bb76
  ]
invalid.tag.b73:
  unreachable
bb74:
  %v708 = phi i64 [ %v586, %bb75 ], [ %v586, %bb76 ]
  %v709 = phi i64 [ %v587, %bb75 ], [ %v587, %bb76 ]
  %v710 = phi i64 [ %v588, %bb75 ], [ %v588, %bb76 ]
  %v711 = phi i64 [ %v589, %bb75 ], [ %v589, %bb76 ]
  %v712 = phi i64 [ %v590, %bb75 ], [ %v590, %bb76 ]
  %v713 = phi i64 [ %v591, %bb75 ], [ %v591, %bb76 ]
  %v714 = phi i64 [ %v592, %bb75 ], [ %v592, %bb76 ]
  %v715 = phi i1 [ %v593, %bb75 ], [ %v593, %bb76 ]
  %v716 = phi ptr [ %v594, %bb75 ], [ %v594, %bb76 ]
  %v717 = phi ptr [ %v595, %bb75 ], [ %v595, %bb76 ]
  %v718 = phi ptr [ %v596, %bb75 ], [ %v596, %bb76 ]
  %v719 = phi i64 [ %v597, %bb75 ], [ %v597, %bb76 ]
  %v720 = phi i1 [ %v598, %bb75 ], [ %v598, %bb76 ]
  %v721 = phi i1 [ %v599, %bb75 ], [ %v599, %bb76 ]
  %v722 = phi i1 [ %v600, %bb75 ], [ %v600, %bb76 ]
  %v723 = phi i1 [ %v601, %bb75 ], [ %v601, %bb76 ]
  %v724 = phi i1 [ %v602, %bb75 ], [ %v602, %bb76 ]
  %v725 = phi i64 [ %v603, %bb75 ], [ %v603, %bb76 ]
  %v726 = phi i64 [ %v604, %bb75 ], [ %v604, %bb76 ]
  %v727 = phi ptr [ %v607, %bb75 ], [ %v607, %bb76 ]
  %v728 = phi i1 [ %v609, %bb75 ], [ %v609, %bb76 ]
  %v729 = phi i1 [ %v611, %bb75 ], [ %v611, %bb76 ]
  %v730 = phi i1 [ %v612, %bb75 ], [ %v612, %bb76 ]
  %v731 = phi i1 [ %v613, %bb75 ], [ %v613, %bb76 ]
  %v732 = phi i64 [ %v667, %bb75 ], [ %v667, %bb76 ]
  %v733 = phi i64 [ %v668, %bb75 ], [ %v668, %bb76 ]
  %v734 = phi i64 [ %v669, %bb75 ], [ %v669, %bb76 ]
  %v735 = phi i64 [ %v670, %bb75 ], [ %v670, %bb76 ]
  %v736 = phi i64 [ %v671, %bb75 ], [ %v671, %bb76 ]
  %v738 = phi i1 [ %v706, %bb75 ], [ %v706, %bb76 ]
  %t27 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.12, i32 0, i32 0
  %v744 = load i64, ptr %t27
  ; ownership-consuming projection
  %t28 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.12, i32 0, i32 1
  %v745 = load i64, ptr %t28
  ; ownership-consuming projection
  %v746 = call i64 @wf_map_cost_word_content(i64 %v744, i64 %v745)
  %v747 = call i8 @wf_map_cost_ordered(ptr %v718, i64 %v746)
  br label %bb71
bb75:
  %v740 = select i1 true, i64 1, i64 1
  %v741 = call i8 @wf_map_cost_ordered(ptr %v596, i64 %v740)
  br label %bb74
bb76:
  %v742 = select i1 true, i64 2, i64 2
  %v743 = call i8 @wf_map_cost_ordered(ptr %v596, i64 %v742)
  br label %bb74
bb77:
  %v750 = phi i64 [ %v819, %bb83 ], [ %v899, %bb89 ]
  %v751 = phi i64 [ %v820, %bb83 ], [ %v900, %bb89 ]
  %v752 = phi i64 [ %v821, %bb83 ], [ %v901, %bb89 ]
  %v753 = phi i64 [ %v822, %bb83 ], [ %v902, %bb89 ]
  %v754 = phi i64 [ %v823, %bb83 ], [ %v903, %bb89 ]
  %v755 = phi i64 [ %v824, %bb83 ], [ %v904, %bb89 ]
  %v756 = phi i64 [ %v825, %bb83 ], [ %v905, %bb89 ]
  %v757 = phi i1 [ %v826, %bb83 ], [ %v906, %bb89 ]
  %v758 = phi ptr [ %v827, %bb83 ], [ %v907, %bb89 ]
  %v759 = phi ptr [ %v828, %bb83 ], [ %v908, %bb89 ]
  %v760 = phi ptr [ %v829, %bb83 ], [ %v909, %bb89 ]
  %v761 = phi i64 [ %v830, %bb83 ], [ %v910, %bb89 ]
  %v762 = phi i1 [ %v831, %bb83 ], [ %v911, %bb89 ]
  %v763 = phi i1 [ %v832, %bb83 ], [ %v912, %bb89 ]
  %v764 = phi i1 [ %v833, %bb83 ], [ %v913, %bb89 ]
  %v765 = phi i1 [ %v834, %bb83 ], [ %v914, %bb89 ]
  %v766 = phi i1 [ %v835, %bb83 ], [ %v915, %bb89 ]
  %v767 = phi i64 [ %v836, %bb83 ], [ %v916, %bb89 ]
  %v768 = phi i64 [ %v837, %bb83 ], [ %v917, %bb89 ]
  %v769 = phi ptr [ %v838, %bb83 ], [ %v918, %bb89 ]
  %v770 = phi i1 [ %v839, %bb83 ], [ %v919, %bb89 ]
  %v771 = phi i1 [ %v840, %bb83 ], [ %v920, %bb89 ]
  %v772 = phi i1 [ %v841, %bb83 ], [ %v921, %bb89 ]
  %v773 = phi i1 [ %v842, %bb83 ], [ %v922, %bb89 ]
  br label %bb68
bb78:
  %v774 = call %wf.t.84dc23e49b76868c @wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad(ptr %v595, ptr %v607, ptr %v594)
  store %wf.t.84dc23e49b76868c %v774, ptr %wf.slot.13
  %t29 = load %wf.t.84dc23e49b76868c, ptr %wf.slot.13
  %t30 = extractvalue %wf.t.84dc23e49b76868c %t29, 0
  switch i32 %t30, label %invalid.tag.b78 [
    i32 1, label %bb81
    i32 0, label %bb82
  ]
invalid.tag.b78:
  unreachable
bb79:
  %v897 = select i1 true, i64 7, i64 7
  %v898 = icmp eq i64 %v590, %v897
  switch i1 %v898, label %invalid.tag.b79 [
    i1 1, label %bb90
    i1 0, label %bb91
  ]
invalid.tag.b79:
  unreachable
bb80:
  %v775 = phi i64 [ %v586, %bb81 ], [ %v586, %bb82 ]
  %v776 = phi i64 [ %v587, %bb81 ], [ %v587, %bb82 ]
  %v777 = phi i64 [ %v588, %bb81 ], [ %v588, %bb82 ]
  %v778 = phi i64 [ %v589, %bb81 ], [ %v589, %bb82 ]
  %v779 = phi i64 [ %v590, %bb81 ], [ %v590, %bb82 ]
  %v780 = phi i64 [ %v591, %bb81 ], [ %v591, %bb82 ]
  %v781 = phi i64 [ %v592, %bb81 ], [ %v592, %bb82 ]
  %v782 = phi i1 [ %v593, %bb81 ], [ %v593, %bb82 ]
  %v783 = phi ptr [ %v594, %bb81 ], [ %v594, %bb82 ]
  %v784 = phi ptr [ %v595, %bb81 ], [ %v595, %bb82 ]
  %v785 = phi ptr [ %v596, %bb81 ], [ %v596, %bb82 ]
  %v786 = phi i64 [ %v597, %bb81 ], [ %v597, %bb82 ]
  %v787 = phi i1 [ %v598, %bb81 ], [ %v598, %bb82 ]
  %v788 = phi i1 [ %v599, %bb81 ], [ %v599, %bb82 ]
  %v789 = phi i1 [ %v600, %bb81 ], [ %v600, %bb82 ]
  %v790 = phi i1 [ %v601, %bb81 ], [ %v601, %bb82 ]
  %v791 = phi i1 [ %v602, %bb81 ], [ %v602, %bb82 ]
  %v792 = phi i64 [ %v603, %bb81 ], [ %v603, %bb82 ]
  %v793 = phi i64 [ %v604, %bb81 ], [ %v604, %bb82 ]
  %v794 = phi ptr [ %v607, %bb81 ], [ %v607, %bb82 ]
  %v795 = phi i1 [ %v609, %bb81 ], [ %v609, %bb82 ]
  %v796 = phi i1 [ %v611, %bb81 ], [ %v611, %bb82 ]
  %v797 = phi i1 [ %v612, %bb81 ], [ %v612, %bb82 ]
  %v798 = phi i1 [ %v613, %bb81 ], [ %v613, %bb82 ]
  %v809 = call %wf.t.b7e1ed626c09888a @wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50(ptr %v784, ptr %v794, ptr %v783, ptr %v785)
  store %wf.t.b7e1ed626c09888a %v809, ptr %wf.slot.15
  %v810 = call i8 @wf_map_cost_lookup_result(ptr %wf.slot.15, ptr %v785)
  %v811 = select i1 true, i64 1, i64 1
  %v812 = add i64 %v786, %v811
  %v813 = mul i64 %v812, %v776
  %v814 = add i64 %v778, %v813
  %v815 = add i64 %v814, %v792
  %v816 = call i64 @wf_map_cost_word_make(i64 %v815)
  %v817 = load i64, ptr %v794
  call void @wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad(ptr %wf.slot.16, ptr %v784, i64 %v817, i64 %v816, ptr %v783)
  %t31 = load %wf.t.5591089753cba638, ptr %wf.slot.16
  %t32 = extractvalue %wf.t.5591089753cba638 %t31, 0
  switch i32 %t32, label %invalid.tag.b80 [
    i32 0, label %bb84
    i32 1, label %bb85
  ]
invalid.tag.b80:
  unreachable
bb81:
  %t33 = getelementptr inbounds %wf.t.84dc23e49b76868c, ptr %wf.slot.13, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.14, ptr %t33, i64 ptrtoint (ptr getelementptr (%wf.t.c5066f96ffdbc504, ptr null, i32 1) to i64), i1 false)
  %v801 = select i1 true, i64 1, i64 1
  %v802 = call i8 @wf_map_cost_ordered(ptr %v596, i64 %v801)
  %t34 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.14, i32 0, i32 0
  %v803 = load i64, ptr %t34
  ; ownership-consuming projection
  %t35 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.14, i32 0, i32 1
  %v804 = load i64, ptr %t35
  ; ownership-consuming projection
  %v805 = call i64 @wf_map_cost_word_content(i64 %v803, i64 %v804)
  %v806 = call i8 @wf_map_cost_ordered(ptr %v596, i64 %v805)
  br label %bb80
bb82:
  %v807 = select i1 true, i64 0, i64 0
  %v808 = call i8 @wf_map_cost_ordered(ptr %v596, i64 %v807)
  br label %bb80
bb83:
  %v819 = phi i64 [ %v775, %bb84 ], [ %v855, %bb86 ]
  %v820 = phi i64 [ %v776, %bb84 ], [ %v856, %bb86 ]
  %v821 = phi i64 [ %v777, %bb84 ], [ %v857, %bb86 ]
  %v822 = phi i64 [ %v778, %bb84 ], [ %v858, %bb86 ]
  %v823 = phi i64 [ %v779, %bb84 ], [ %v859, %bb86 ]
  %v824 = phi i64 [ %v780, %bb84 ], [ %v860, %bb86 ]
  %v825 = phi i64 [ %v781, %bb84 ], [ %v861, %bb86 ]
  %v826 = phi i1 [ %v782, %bb84 ], [ %v862, %bb86 ]
  %v827 = phi ptr [ %v783, %bb84 ], [ %v863, %bb86 ]
  %v828 = phi ptr [ %v784, %bb84 ], [ %v864, %bb86 ]
  %v829 = phi ptr [ %v785, %bb84 ], [ %v865, %bb86 ]
  %v830 = phi i64 [ %v786, %bb84 ], [ %v866, %bb86 ]
  %v831 = phi i1 [ %v787, %bb84 ], [ %v867, %bb86 ]
  %v832 = phi i1 [ %v788, %bb84 ], [ %v868, %bb86 ]
  %v833 = phi i1 [ %v789, %bb84 ], [ %v869, %bb86 ]
  %v834 = phi i1 [ %v790, %bb84 ], [ %v870, %bb86 ]
  %v835 = phi i1 [ %v791, %bb84 ], [ %v871, %bb86 ]
  %v836 = phi i64 [ %v792, %bb84 ], [ %v872, %bb86 ]
  %v837 = phi i64 [ %v793, %bb84 ], [ %v873, %bb86 ]
  %v838 = phi ptr [ %v794, %bb84 ], [ %v874, %bb86 ]
  %v839 = phi i1 [ %v795, %bb84 ], [ %v875, %bb86 ]
  %v840 = phi i1 [ %v796, %bb84 ], [ %v876, %bb86 ]
  %v841 = phi i1 [ %v797, %bb84 ], [ %v877, %bb86 ]
  %v842 = phi i1 [ %v798, %bb84 ], [ %v878, %bb86 ]
  %v845 = phi i64 [ %v812, %bb84 ], [ %v881, %bb86 ]
  %v846 = phi i64 [ %v813, %bb84 ], [ %v882, %bb86 ]
  %v847 = phi i64 [ %v814, %bb84 ], [ %v883, %bb86 ]
  %v848 = phi i64 [ %v815, %bb84 ], [ %v884, %bb86 ]
  %v849 = phi i64 [ %v816, %bb84 ], [ %v885, %bb86 ]
  br label %bb77
bb84:
  %v851 = select i1 true, i64 0, i64 0
  %v852 = call i8 @wf_map_cost_ordered(ptr %v785, i64 %v851)
  br label %bb83
bb85:
  %t36 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.slot.16, i32 0, i32 1
  %v853 = load i1, ptr %t36
  %t37 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.slot.16, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.17, ptr %t37, i64 ptrtoint (ptr getelementptr (%wf.t.c5066f96ffdbc504, ptr null, i32 1) to i64), i1 false)
  switch i1 %v853, label %invalid.tag.b85 [
    i1 0, label %bb87
    i1 1, label %bb88
  ]
invalid.tag.b85:
  unreachable
bb86:
  %v855 = phi i64 [ %v775, %bb87 ], [ %v775, %bb88 ]
  %v856 = phi i64 [ %v776, %bb87 ], [ %v776, %bb88 ]
  %v857 = phi i64 [ %v777, %bb87 ], [ %v777, %bb88 ]
  %v858 = phi i64 [ %v778, %bb87 ], [ %v778, %bb88 ]
  %v859 = phi i64 [ %v779, %bb87 ], [ %v779, %bb88 ]
  %v860 = phi i64 [ %v780, %bb87 ], [ %v780, %bb88 ]
  %v861 = phi i64 [ %v781, %bb87 ], [ %v781, %bb88 ]
  %v862 = phi i1 [ %v782, %bb87 ], [ %v782, %bb88 ]
  %v863 = phi ptr [ %v783, %bb87 ], [ %v783, %bb88 ]
  %v864 = phi ptr [ %v784, %bb87 ], [ %v784, %bb88 ]
  %v865 = phi ptr [ %v785, %bb87 ], [ %v785, %bb88 ]
  %v866 = phi i64 [ %v786, %bb87 ], [ %v786, %bb88 ]
  %v867 = phi i1 [ %v787, %bb87 ], [ %v787, %bb88 ]
  %v868 = phi i1 [ %v788, %bb87 ], [ %v788, %bb88 ]
  %v869 = phi i1 [ %v789, %bb87 ], [ %v789, %bb88 ]
  %v870 = phi i1 [ %v790, %bb87 ], [ %v790, %bb88 ]
  %v871 = phi i1 [ %v791, %bb87 ], [ %v791, %bb88 ]
  %v872 = phi i64 [ %v792, %bb87 ], [ %v792, %bb88 ]
  %v873 = phi i64 [ %v793, %bb87 ], [ %v793, %bb88 ]
  %v874 = phi ptr [ %v794, %bb87 ], [ %v794, %bb88 ]
  %v875 = phi i1 [ %v795, %bb87 ], [ %v795, %bb88 ]
  %v876 = phi i1 [ %v796, %bb87 ], [ %v796, %bb88 ]
  %v877 = phi i1 [ %v797, %bb87 ], [ %v797, %bb88 ]
  %v878 = phi i1 [ %v798, %bb87 ], [ %v798, %bb88 ]
  %v881 = phi i64 [ %v812, %bb87 ], [ %v812, %bb88 ]
  %v882 = phi i64 [ %v813, %bb87 ], [ %v813, %bb88 ]
  %v883 = phi i64 [ %v814, %bb87 ], [ %v814, %bb88 ]
  %v884 = phi i64 [ %v815, %bb87 ], [ %v815, %bb88 ]
  %v885 = phi i64 [ %v816, %bb87 ], [ %v816, %bb88 ]
  %v887 = phi i1 [ %v853, %bb87 ], [ %v853, %bb88 ]
  %t38 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.17, i32 0, i32 0
  %v893 = load i64, ptr %t38
  ; ownership-consuming projection
  %t39 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.17, i32 0, i32 1
  %v894 = load i64, ptr %t39
  ; ownership-consuming projection
  %v895 = call i64 @wf_map_cost_word_content(i64 %v893, i64 %v894)
  %v896 = call i8 @wf_map_cost_ordered(ptr %v865, i64 %v895)
  br label %bb83
bb87:
  %v889 = select i1 true, i64 1, i64 1
  %v890 = call i8 @wf_map_cost_ordered(ptr %v785, i64 %v889)
  br label %bb86
bb88:
  %v891 = select i1 true, i64 2, i64 2
  %v892 = call i8 @wf_map_cost_ordered(ptr %v785, i64 %v891)
  br label %bb86
bb89:
  %v899 = phi i64 [ %v586, %bb90 ], [ %v586, %bb91 ]
  %v900 = phi i64 [ %v587, %bb90 ], [ %v587, %bb91 ]
  %v901 = phi i64 [ %v588, %bb90 ], [ %v588, %bb91 ]
  %v902 = phi i64 [ %v589, %bb90 ], [ %v589, %bb91 ]
  %v903 = phi i64 [ %v590, %bb90 ], [ %v590, %bb91 ]
  %v904 = phi i64 [ %v591, %bb90 ], [ %v591, %bb91 ]
  %v905 = phi i64 [ %v592, %bb90 ], [ %v592, %bb91 ]
  %v906 = phi i1 [ %v593, %bb90 ], [ %v593, %bb91 ]
  %v907 = phi ptr [ %v594, %bb90 ], [ %v594, %bb91 ]
  %v908 = phi ptr [ %v595, %bb90 ], [ %v595, %bb91 ]
  %v909 = phi ptr [ %v596, %bb90 ], [ %v596, %bb91 ]
  %v910 = phi i64 [ %v597, %bb90 ], [ %v597, %bb91 ]
  %v911 = phi i1 [ %v598, %bb90 ], [ %v598, %bb91 ]
  %v912 = phi i1 [ %v599, %bb90 ], [ %v599, %bb91 ]
  %v913 = phi i1 [ %v600, %bb90 ], [ %v600, %bb91 ]
  %v914 = phi i1 [ %v601, %bb90 ], [ %v601, %bb91 ]
  %v915 = phi i1 [ %v602, %bb90 ], [ %v602, %bb91 ]
  %v916 = phi i64 [ %v603, %bb90 ], [ %v603, %bb91 ]
  %v917 = phi i64 [ %v604, %bb90 ], [ %v604, %bb91 ]
  %v918 = phi ptr [ %v607, %bb90 ], [ %v607, %bb91 ]
  %v919 = phi i1 [ %v609, %bb90 ], [ %v609, %bb91 ]
  %v920 = phi i1 [ %v611, %bb90 ], [ %v611, %bb91 ]
  %v921 = phi i1 [ %v612, %bb90 ], [ %v612, %bb91 ]
  %v922 = phi i1 [ %v613, %bb90 ], [ %v613, %bb91 ]
  br label %bb77
bb90:
  %v923 = call %wf.t.b7e1ed626c09888a @wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567(ptr %v595, ptr %v607, ptr %v594, ptr %v596)
  store %wf.t.b7e1ed626c09888a %v923, ptr %wf.slot.18
  %v924 = call i8 @wf_map_cost_lookup_result(ptr %wf.slot.18, ptr %v596)
  br label %bb89
bb91:
  br label %bb89
bb92:
  %v925 = phi i64 [ %v614, %bb65 ]
  %v926 = phi i64 [ %v615, %bb65 ]
  %v927 = phi i64 [ %v616, %bb65 ]
  %v928 = phi i64 [ %v617, %bb65 ]
  %v929 = phi i64 [ %v618, %bb65 ]
  %v930 = phi i64 [ %v619, %bb65 ]
  %v931 = phi i64 [ %v620, %bb65 ]
  %v932 = phi i1 [ %v621, %bb65 ]
  %v933 = phi ptr [ %v622, %bb65 ]
  %v934 = phi ptr [ %v623, %bb65 ]
  %v935 = phi ptr [ %v624, %bb65 ]
  %v936 = phi i64 [ %v625, %bb65 ]
  %v937 = phi i1 [ %v626, %bb65 ]
  %v938 = phi i1 [ %v627, %bb65 ]
  %v939 = phi i1 [ %v628, %bb65 ]
  %v940 = phi i1 [ %v629, %bb65 ]
  %v941 = phi i1 [ %v630, %bb65 ]
  %v942 = phi i64 [ %v563, %bb65 ]
  %v943 = phi i64 [ %v564, %bb65 ]
  %v944 = phi i64 [ %v565, %bb65 ]
  %v945 = select i1 true, i64 1, i64 1
  %v946 = add i64 %v944, %v945
  br label %bb58
bb93:
  %v947 = phi i64 [ %v141, %bb16 ]
  %v948 = phi i64 [ %v142, %bb16 ]
  %v949 = phi i64 [ %v143, %bb16 ]
  %v950 = phi i64 [ %v144, %bb16 ]
  %v951 = phi i64 [ %v145, %bb16 ]
  %v952 = phi i64 [ %v146, %bb16 ]
  %v953 = phi i64 [ %v147, %bb16 ]
  %v954 = phi i1 [ %v148, %bb16 ]
  %v955 = phi ptr [ %v149, %bb16 ]
  %v956 = phi ptr [ %v150, %bb16 ]
  %v957 = phi ptr [ %v151, %bb16 ]
  %v958 = phi i64 [ %v124, %bb16 ]
  %v959 = phi i64 [ %v125, %bb16 ]
  %v960 = phi i64 [ %v126, %bb16 ]
  %v961 = select i1 true, i64 1, i64 1
  %v962 = add i64 %v960, %v961
  br label %bb12
}

define i64 @wf_map_cost_library_policy$instance$4250cb78d3f44027(i64 %v0, i64 %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.1 = alloca %wf.t.114ba5754d75c8d6, align 8
  %wf.slot.2 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.3 = alloca %wf.t.114ba5754d75c8d6, align 8
  %wf.slot.4 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.5 = alloca %wf.t.114ba5754d75c8d6, align 8
  %wf.slot.6 = alloca %wf.t.4380a1278c72e25d, align 8
  %wf.slot.7 = alloca %wf.t.84597570beb237fa, align 8
  %v7 = alloca %wf.t.ee6ca7dc0a065510, align 8
  %v10 = alloca %wf.t.4380a1278c72e25d, align 8
  %v15 = alloca %wf.t.84597570beb237fa, align 8
  %v2 = select i1 true, i64 11400714819323198485, i64 11400714819323198485
  %v3 = xor i64 %v0, %v2
  %v4 = select i1 true, i64 0, i64 0
  %v5 = icmp ne i64 %v1, %v4
  store %wf.t.ee6ca7dc0a065510 zeroinitializer, ptr %v7
  %t0 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v7, i32 0, i32 0
  store i64 %v3, ptr %t0
  %t1 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v7, i32 0, i32 1
  store i1 %v5, ptr %t1
  %v8 = select i1 true, i64 3, i64 3
  call void @wf_std.collections.hash_map.hash_map_new$instance$96033bf6ddb80743(ptr %v10, i64 %v8)
  %v11 = select i1 true, i64 0, i64 0
  %v12 = select i1 true, i64 0, i64 0
  %v13 = select i1 true, i64 0, i64 0
  store %wf.t.84597570beb237fa zeroinitializer, ptr %v15
  %t2 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v15, i32 0, i32 0
  store i64 %v0, ptr %t2
  %t3 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v15, i32 0, i32 1
  store i64 %v11, ptr %t3
  %t4 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v15, i32 0, i32 2
  store i64 %v12, ptr %t4
  %t5 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v15, i32 0, i32 3
  store i64 %v13, ptr %t5
  %v16 = select i1 true, i64 0, i64 0
  %v17 = select i1 true, i64 3, i64 3
  br label %bb1
bb1:
  %v18 = phi i64 [ %v0, %entry ], [ %v41, %bb5 ]
  %v19 = phi i64 [ %v1, %entry ], [ %v42, %bb5 ]
  %v20 = phi i64 [ %v3, %entry ], [ %v43, %bb5 ]
  %v21 = phi i1 [ %v5, %entry ], [ %v44, %bb5 ]
  %v22 = phi ptr [ %v7, %entry ], [ %v45, %bb5 ]
  %v23 = phi ptr [ %v10, %entry ], [ %v46, %bb5 ]
  %v24 = phi ptr [ %v15, %entry ], [ %v47, %bb5 ]
  %v25 = phi i64 [ %v16, %entry ], [ %v48, %bb5 ]
  %v26 = phi i64 [ %v17, %entry ], [ %v49, %bb5 ]
  %v27 = phi i64 [ %v16, %entry ], [ %v52, %bb5 ]
  %v35 = icmp ult i64 %v27, %v26
  switch i1 %v35, label %invalid.tag.b1 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v36 = call i64 @wf_map_cost_key(i64 %v27)
  %v37 = add i64 %v18, %v27
  call void @wf_map_cost_record_make(ptr %wf.slot.0, i64 %v37)
  call void @wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07(ptr %wf.slot.1, ptr %v23, i64 %v36, ptr %wf.slot.0, ptr %v22)
  %v40 = call i8 @wf_map_cost_library_policy_result$instance$4250cb78d3f44027(ptr %wf.slot.1, ptr %v24)
  br label %bb5
bb3:
  br label %bb4
bb4:
  %v28 = phi i64 [ %v18, %bb3 ]
  %v29 = phi i64 [ %v19, %bb3 ]
  %v30 = phi i64 [ %v20, %bb3 ]
  %v31 = phi i1 [ %v21, %bb3 ]
  %v32 = phi ptr [ %v22, %bb3 ]
  %v33 = phi ptr [ %v23, %bb3 ]
  %v34 = phi ptr [ %v24, %bb3 ]
  %v53 = select i1 true, i64 10, i64 10
  %v54 = add i64 %v28, %v53
  call void @wf_map_cost_record_make(ptr %wf.slot.2, i64 %v54)
  %v56 = select i1 true, i64 1, i64 1
  call void @wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07(ptr %wf.slot.3, ptr %v33, i64 %v56, ptr %wf.slot.2, ptr %v32)
  %v58 = call i8 @wf_map_cost_library_policy_result$instance$4250cb78d3f44027(ptr %wf.slot.3, ptr %v34)
  %v59 = select i1 true, i64 20, i64 20
  %v60 = add i64 %v28, %v59
  call void @wf_map_cost_record_make(ptr %wf.slot.4, i64 %v60)
  %v62 = select i1 true, i64 7, i64 7
  call void @wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07(ptr %wf.slot.5, ptr %v33, i64 %v62, ptr %wf.slot.4, ptr %v32)
  %v64 = call i8 @wf_map_cost_library_policy_result$instance$4250cb78d3f44027(ptr %wf.slot.5, ptr %v34)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.6, ptr %v33, i64 ptrtoint (ptr getelementptr (%wf.t.4380a1278c72e25d, ptr null, i32 1) to i64), i1 false)
  %v66 = call i8 @wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146(ptr %wf.slot.6, ptr %v34)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.7, ptr %v34, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %v68 = call i64 @wf_map_cost_finish(ptr %wf.slot.7)
  ret i64 %v68
bb5:
  %v41 = phi i64 [ %v18, %bb2 ]
  %v42 = phi i64 [ %v19, %bb2 ]
  %v43 = phi i64 [ %v20, %bb2 ]
  %v44 = phi i1 [ %v21, %bb2 ]
  %v45 = phi ptr [ %v22, %bb2 ]
  %v46 = phi ptr [ %v23, %bb2 ]
  %v47 = phi ptr [ %v24, %bb2 ]
  %v48 = phi i64 [ %v25, %bb2 ]
  %v49 = phi i64 [ %v26, %bb2 ]
  %v50 = phi i64 [ %v27, %bb2 ]
  %v51 = select i1 true, i64 1, i64 1
  %v52 = add i64 %v50, %v51
  br label %bb1
}

define i64 @wf_map_cost_library_trace$instance$4250cb78d3f44027(i64 %v0, i64 %v1, i64 %v2, i64 %v3, i64 %v4, i64 %v5) #0 {
entry:
  %wf.frame = alloca { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, align 8
  %wf.slot.0 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 0
  %wf.slot.1 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 1
  %wf.slot.2 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 2
  %wf.slot.3 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 3
  %wf.slot.4 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 4
  %wf.slot.5 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 5
  %wf.slot.6 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 6
  %wf.slot.7 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 7
  %wf.slot.8 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 8
  %wf.slot.9 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 9
  %wf.slot.10 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 10
  %wf.slot.11 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 11
  %wf.slot.12 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 12
  %wf.slot.13 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 13
  %wf.slot.14 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 14
  %wf.slot.15 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 15
  %wf.slot.16 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 16
  %wf.slot.17 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 17
  %wf.slot.18 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 18
  %wf.slot.19 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 19
  %wf.slot.20 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 20
  %wf.slot.21 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 21
  %wf.slot.22 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 22
  %wf.slot.23 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 23
  %wf.slot.24 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 24
  %wf.slot.25 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 25
  %wf.slot.26 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 26
  %wf.slot.27 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 27
  %wf.slot.28 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 28
  %wf.slot.29 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 29
  %wf.slot.30 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 30
  %v11 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 31
  %v13 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 32
  %v18 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 33
  %v192 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 34
  %v280 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 35
  %v607 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.7d7f918f7b4962fd, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.aba8f6d9883dda3a, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.862971f7a971a883, %wf.t.114ba5754d75c8d6, %wf.t.d72ca22fbd302a84, %wf.t.862971f7a971a883, %wf.t.b7e1ed626c09888a, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, %wf.t.ee6ca7dc0a065510, %wf.t.588b2641b8ac7d45, %wf.t.84597570beb237fa, i64, i64, i64 }, ptr %wf.frame, i32 0, i32 36
  %v6 = select i1 true, i64 11400714819323198485, i64 11400714819323198485
  %v7 = xor i64 %v3, %v6
  %v8 = select i1 true, i64 0, i64 0
  %v9 = icmp ne i64 %v5, %v8
  store %wf.t.ee6ca7dc0a065510 zeroinitializer, ptr %v11
  %t0 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v11, i32 0, i32 0
  store i64 %v7, ptr %t0
  %t1 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v11, i32 0, i32 1
  store i1 %v9, ptr %t1
  call void @wf_std.collections.hash_map.hash_map_new$instance$0e108827ecbbe374(ptr %v13, i64 %v0)
  %v14 = select i1 true, i64 0, i64 0
  %v15 = select i1 true, i64 0, i64 0
  %v16 = select i1 true, i64 0, i64 0
  store %wf.t.84597570beb237fa zeroinitializer, ptr %v18
  %t2 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v18, i32 0, i32 0
  store i64 %v3, ptr %t2
  %t3 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v18, i32 0, i32 1
  store i64 %v14, ptr %t3
  %t4 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v18, i32 0, i32 2
  store i64 %v15, ptr %t4
  %t5 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v18, i32 0, i32 3
  store i64 %v16, ptr %t5
  %v19 = select i1 true, i64 0, i64 0
  br label %bb1
bb1:
  %v20 = phi i64 [ %v0, %entry ], [ %v96, %bb11 ]
  %v21 = phi i64 [ %v1, %entry ], [ %v97, %bb11 ]
  %v22 = phi i64 [ %v2, %entry ], [ %v98, %bb11 ]
  %v23 = phi i64 [ %v3, %entry ], [ %v99, %bb11 ]
  %v24 = phi i64 [ %v4, %entry ], [ %v100, %bb11 ]
  %v25 = phi i64 [ %v5, %entry ], [ %v101, %bb11 ]
  %v26 = phi i64 [ %v7, %entry ], [ %v102, %bb11 ]
  %v27 = phi i1 [ %v9, %entry ], [ %v103, %bb11 ]
  %v28 = phi ptr [ %v11, %entry ], [ %v104, %bb11 ]
  %v29 = phi ptr [ %v13, %entry ], [ %v105, %bb11 ]
  %v30 = phi ptr [ %v18, %entry ], [ %v106, %bb11 ]
  %v31 = phi i64 [ %v19, %entry ], [ %v107, %bb11 ]
  %v32 = phi i64 [ %v1, %entry ], [ %v108, %bb11 ]
  %v33 = phi i64 [ %v19, %entry ], [ %v111, %bb11 ]
  %v45 = icmp ult i64 %v33, %v32
  switch i1 %v45, label %invalid.tag.b1 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v46 = call i64 @wf_map_cost_key(i64 %v33)
  %v47 = add i64 %v23, %v33
  call void @wf_map_cost_record_make(ptr %wf.slot.0, i64 %v47)
  call void @wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65(ptr %wf.slot.1, ptr %v29, i64 %v46, ptr %wf.slot.0, ptr %v28)
  %t6 = load %wf.t.114ba5754d75c8d6, ptr %wf.slot.1
  %t7 = extractvalue %wf.t.114ba5754d75c8d6 %t6, 0
  switch i32 %t7, label %invalid.tag.b2 [
    i32 0, label %bb6
    i32 1, label %bb7
  ]
invalid.tag.b2:
  unreachable
bb3:
  br label %bb4
bb4:
  %v34 = phi i64 [ %v20, %bb3 ]
  %v35 = phi i64 [ %v21, %bb3 ]
  %v36 = phi i64 [ %v22, %bb3 ]
  %v37 = phi i64 [ %v23, %bb3 ]
  %v38 = phi i64 [ %v24, %bb3 ]
  %v39 = phi i64 [ %v25, %bb3 ]
  %v40 = phi i64 [ %v26, %bb3 ]
  %v41 = phi i1 [ %v27, %bb3 ]
  %v42 = phi ptr [ %v28, %bb3 ]
  %v43 = phi ptr [ %v29, %bb3 ]
  %v44 = phi ptr [ %v30, %bb3 ]
  %v112 = select i1 true, i64 0, i64 0
  br label %bb12
bb5:
  %v50 = phi i64 [ %v20, %bb6 ], [ %v70, %bb8 ]
  %v51 = phi i64 [ %v21, %bb6 ], [ %v71, %bb8 ]
  %v52 = phi i64 [ %v22, %bb6 ], [ %v72, %bb8 ]
  %v53 = phi i64 [ %v23, %bb6 ], [ %v73, %bb8 ]
  %v54 = phi i64 [ %v24, %bb6 ], [ %v74, %bb8 ]
  %v55 = phi i64 [ %v25, %bb6 ], [ %v75, %bb8 ]
  %v56 = phi i64 [ %v26, %bb6 ], [ %v76, %bb8 ]
  %v57 = phi i1 [ %v27, %bb6 ], [ %v77, %bb8 ]
  %v58 = phi ptr [ %v28, %bb6 ], [ %v78, %bb8 ]
  %v59 = phi ptr [ %v29, %bb6 ], [ %v79, %bb8 ]
  %v60 = phi ptr [ %v30, %bb6 ], [ %v80, %bb8 ]
  %v61 = phi i64 [ %v33, %bb6 ], [ %v81, %bb8 ]
  %v62 = phi i64 [ %v46, %bb6 ], [ %v82, %bb8 ]
  %v63 = phi i64 [ %v47, %bb6 ], [ %v83, %bb8 ]
  br label %bb11
bb6:
  %v66 = select i1 true, i64 0, i64 0
  %v67 = call i8 @wf_map_cost_ordered(ptr %v30, i64 %v66)
  br label %bb5
bb7:
  %t8 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.slot.1, i32 0, i32 1
  %v68 = load i1, ptr %t8
  %t9 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.slot.1, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %t9, i64 ptrtoint (ptr getelementptr (%wf.t.d72ca22fbd302a84, ptr null, i32 1) to i64), i1 false)
  switch i1 %v68, label %invalid.tag.b7 [
    i1 0, label %bb9
    i1 1, label %bb10
  ]
invalid.tag.b7:
  unreachable
bb8:
  %v70 = phi i64 [ %v20, %bb9 ], [ %v20, %bb10 ]
  %v71 = phi i64 [ %v21, %bb9 ], [ %v21, %bb10 ]
  %v72 = phi i64 [ %v22, %bb9 ], [ %v22, %bb10 ]
  %v73 = phi i64 [ %v23, %bb9 ], [ %v23, %bb10 ]
  %v74 = phi i64 [ %v24, %bb9 ], [ %v24, %bb10 ]
  %v75 = phi i64 [ %v25, %bb9 ], [ %v25, %bb10 ]
  %v76 = phi i64 [ %v26, %bb9 ], [ %v26, %bb10 ]
  %v77 = phi i1 [ %v27, %bb9 ], [ %v27, %bb10 ]
  %v78 = phi ptr [ %v28, %bb9 ], [ %v28, %bb10 ]
  %v79 = phi ptr [ %v29, %bb9 ], [ %v29, %bb10 ]
  %v80 = phi ptr [ %v30, %bb9 ], [ %v30, %bb10 ]
  %v81 = phi i64 [ %v33, %bb9 ], [ %v33, %bb10 ]
  %v82 = phi i64 [ %v46, %bb9 ], [ %v46, %bb10 ]
  %v83 = phi i64 [ %v47, %bb9 ], [ %v47, %bb10 ]
  %v86 = phi i1 [ %v68, %bb9 ], [ %v68, %bb10 ]
  %t10 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.2, i32 0, i32 0
  %v92 = load i64, ptr %t10
  ; ownership-consuming projection
  %t11 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.2, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.3, ptr %t11, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %v94 = call i64 @wf_map_cost_record_content(i64 %v92, ptr %wf.slot.3)
  %v95 = call i8 @wf_map_cost_ordered(ptr %v80, i64 %v94)
  br label %bb5
bb9:
  %v88 = select i1 true, i64 1, i64 1
  %v89 = call i8 @wf_map_cost_ordered(ptr %v30, i64 %v88)
  br label %bb8
bb10:
  %v90 = select i1 true, i64 2, i64 2
  %v91 = call i8 @wf_map_cost_ordered(ptr %v30, i64 %v90)
  br label %bb8
bb11:
  %v96 = phi i64 [ %v50, %bb5 ]
  %v97 = phi i64 [ %v51, %bb5 ]
  %v98 = phi i64 [ %v52, %bb5 ]
  %v99 = phi i64 [ %v53, %bb5 ]
  %v100 = phi i64 [ %v54, %bb5 ]
  %v101 = phi i64 [ %v55, %bb5 ]
  %v102 = phi i64 [ %v56, %bb5 ]
  %v103 = phi i1 [ %v57, %bb5 ]
  %v104 = phi ptr [ %v58, %bb5 ]
  %v105 = phi ptr [ %v59, %bb5 ]
  %v106 = phi ptr [ %v60, %bb5 ]
  %v107 = phi i64 [ %v31, %bb5 ]
  %v108 = phi i64 [ %v32, %bb5 ]
  %v109 = phi i64 [ %v33, %bb5 ]
  %v110 = select i1 true, i64 1, i64 1
  %v111 = add i64 %v109, %v110
  br label %bb1
bb12:
  %v113 = phi i64 [ %v34, %bb4 ], [ %v947, %bb93 ]
  %v114 = phi i64 [ %v35, %bb4 ], [ %v948, %bb93 ]
  %v115 = phi i64 [ %v36, %bb4 ], [ %v949, %bb93 ]
  %v116 = phi i64 [ %v37, %bb4 ], [ %v950, %bb93 ]
  %v117 = phi i64 [ %v38, %bb4 ], [ %v951, %bb93 ]
  %v118 = phi i64 [ %v39, %bb4 ], [ %v952, %bb93 ]
  %v119 = phi i64 [ %v40, %bb4 ], [ %v953, %bb93 ]
  %v120 = phi i1 [ %v41, %bb4 ], [ %v954, %bb93 ]
  %v121 = phi ptr [ %v42, %bb4 ], [ %v955, %bb93 ]
  %v122 = phi ptr [ %v43, %bb4 ], [ %v956, %bb93 ]
  %v123 = phi ptr [ %v44, %bb4 ], [ %v957, %bb93 ]
  %v124 = phi i64 [ %v112, %bb4 ], [ %v958, %bb93 ]
  %v125 = phi i64 [ %v36, %bb4 ], [ %v959, %bb93 ]
  %v126 = phi i64 [ %v112, %bb4 ], [ %v962, %bb93 ]
  %v138 = icmp ult i64 %v126, %v125
  switch i1 %v138, label %invalid.tag.b12 [
    i1 1, label %bb13
    i1 0, label %bb14
  ]
invalid.tag.b12:
  unreachable
bb13:
  %v139 = select i1 true, i64 5, i64 5
  %v140 = icmp eq i64 %v117, %v139
  switch i1 %v140, label %invalid.tag.b13 [
    i1 1, label %bb17
    i1 0, label %bb18
  ]
invalid.tag.b13:
  unreachable
bb14:
  br label %bb15
bb15:
  %v127 = phi i64 [ %v113, %bb14 ]
  %v128 = phi i64 [ %v114, %bb14 ]
  %v129 = phi i64 [ %v115, %bb14 ]
  %v130 = phi i64 [ %v116, %bb14 ]
  %v131 = phi i64 [ %v117, %bb14 ]
  %v132 = phi i64 [ %v118, %bb14 ]
  %v133 = phi i64 [ %v119, %bb14 ]
  %v134 = phi i1 [ %v120, %bb14 ]
  %v135 = phi ptr [ %v121, %bb14 ]
  %v136 = phi ptr [ %v122, %bb14 ]
  %v137 = phi ptr [ %v123, %bb14 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.29, ptr %v136, i64 ptrtoint (ptr getelementptr (%wf.t.588b2641b8ac7d45, ptr null, i32 1) to i64), i1 false)
  %v964 = call i8 @wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71(ptr %wf.slot.29, ptr %v137)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.30, ptr %v137, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %v966 = call i64 @wf_map_cost_finish(ptr %wf.slot.30)
  ret i64 %v966
bb16:
  %v141 = phi i64 [ %v322, %bb35 ], [ %v566, %bb61 ]
  %v142 = phi i64 [ %v323, %bb35 ], [ %v567, %bb61 ]
  %v143 = phi i64 [ %v324, %bb35 ], [ %v568, %bb61 ]
  %v144 = phi i64 [ %v325, %bb35 ], [ %v569, %bb61 ]
  %v145 = phi i64 [ %v326, %bb35 ], [ %v570, %bb61 ]
  %v146 = phi i64 [ %v327, %bb35 ], [ %v571, %bb61 ]
  %v147 = phi i64 [ %v328, %bb35 ], [ %v572, %bb61 ]
  %v148 = phi i1 [ %v329, %bb35 ], [ %v573, %bb61 ]
  %v149 = phi ptr [ %v330, %bb35 ], [ %v574, %bb61 ]
  %v150 = phi ptr [ %v331, %bb35 ], [ %v575, %bb61 ]
  %v151 = phi ptr [ %v332, %bb35 ], [ %v576, %bb61 ]
  %v152 = phi i64 [ %v333, %bb35 ], [ %v577, %bb61 ]
  br label %bb93
bb17:
  %v153 = select i1 true, i64 2, i64 2
  %v154 = udiv i64 %v114, %v153
  %v155 = sub nuw i64 %v114, %v154
  %v156 = select i1 true, i64 0, i64 0
  br label %bb19
bb18:
  %v430 = select i1 true, i64 4, i64 4
  %v431 = icmp eq i64 %v117, %v430
  %v432 = select i1 true, i64 9, i64 9
  %v433 = icmp eq i64 %v117, %v432
  %v434 = select i1 true, i64 10, i64 10
  %v435 = icmp eq i64 %v117, %v434
  %v436 = or i1 %v433, %v435
  %v437 = or i1 %v431, %v436
  switch i1 %v437, label %invalid.tag.b18 [
    i1 1, label %bb44
    i1 0, label %bb45
  ]
invalid.tag.b18:
  unreachable
bb19:
  %v157 = phi i64 [ %v113, %bb17 ], [ %v223, %bb26 ]
  %v158 = phi i64 [ %v114, %bb17 ], [ %v224, %bb26 ]
  %v159 = phi i64 [ %v115, %bb17 ], [ %v225, %bb26 ]
  %v160 = phi i64 [ %v116, %bb17 ], [ %v226, %bb26 ]
  %v161 = phi i64 [ %v117, %bb17 ], [ %v227, %bb26 ]
  %v162 = phi i64 [ %v118, %bb17 ], [ %v228, %bb26 ]
  %v163 = phi i64 [ %v119, %bb17 ], [ %v229, %bb26 ]
  %v164 = phi i1 [ %v120, %bb17 ], [ %v230, %bb26 ]
  %v165 = phi ptr [ %v121, %bb17 ], [ %v231, %bb26 ]
  %v166 = phi ptr [ %v122, %bb17 ], [ %v232, %bb26 ]
  %v167 = phi ptr [ %v123, %bb17 ], [ %v233, %bb26 ]
  %v168 = phi i64 [ %v126, %bb17 ], [ %v234, %bb26 ]
  %v169 = phi i64 [ %v154, %bb17 ], [ %v235, %bb26 ]
  %v170 = phi i64 [ %v155, %bb17 ], [ %v236, %bb26 ]
  %v171 = phi i64 [ %v156, %bb17 ], [ %v237, %bb26 ]
  %v172 = phi i64 [ %v155, %bb17 ], [ %v238, %bb26 ]
  %v173 = phi i64 [ %v156, %bb17 ], [ %v241, %bb26 ]
  %v188 = icmp ult i64 %v173, %v172
  switch i1 %v188, label %invalid.tag.b19 [
    i1 1, label %bb20
    i1 0, label %bb21
  ]
invalid.tag.b19:
  unreachable
bb20:
  %v189 = select i1 true, i64 2, i64 2
  %v190 = mul i64 %v173, %v189
  %v191 = call i64 @wf_map_cost_key(i64 %v190)
  store i64 %v191, ptr %v192
  call void @wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65(ptr %wf.slot.4, ptr %v166, ptr %v192, ptr %v165)
  %t12 = load %wf.t.aba8f6d9883dda3a, ptr %wf.slot.4
  %t13 = extractvalue %wf.t.aba8f6d9883dda3a %t12, 0
  switch i32 %t13, label %invalid.tag.b20 [
    i32 1, label %bb24
    i32 0, label %bb25
  ]
invalid.tag.b20:
  unreachable
bb21:
  br label %bb22
bb22:
  %v174 = phi i64 [ %v157, %bb21 ]
  %v175 = phi i64 [ %v158, %bb21 ]
  %v176 = phi i64 [ %v159, %bb21 ]
  %v177 = phi i64 [ %v160, %bb21 ]
  %v178 = phi i64 [ %v161, %bb21 ]
  %v179 = phi i64 [ %v162, %bb21 ]
  %v180 = phi i64 [ %v163, %bb21 ]
  %v181 = phi i1 [ %v164, %bb21 ]
  %v182 = phi ptr [ %v165, %bb21 ]
  %v183 = phi ptr [ %v166, %bb21 ]
  %v184 = phi ptr [ %v167, %bb21 ]
  %v185 = phi i64 [ %v168, %bb21 ]
  %v186 = phi i64 [ %v169, %bb21 ]
  %v187 = phi i64 [ %v170, %bb21 ]
  %v242 = call %wf.t.7d7f918f7b4962fd @wf_std.collections.hash_map.hash_map_rehash$instance$28da32efc51c2b65(ptr %v183, ptr %v182)
  store %wf.t.7d7f918f7b4962fd %v242, ptr %wf.slot.8
  %v243 = call i8 @wf_map_cost_rebuild_result(ptr %wf.slot.8, ptr %v184)
  %v244 = select i1 true, i64 0, i64 0
  br label %bb27
bb23:
  %v194 = phi i64 [ %v157, %bb24 ], [ %v157, %bb25 ]
  %v195 = phi i64 [ %v158, %bb24 ], [ %v158, %bb25 ]
  %v196 = phi i64 [ %v159, %bb24 ], [ %v159, %bb25 ]
  %v197 = phi i64 [ %v160, %bb24 ], [ %v160, %bb25 ]
  %v198 = phi i64 [ %v161, %bb24 ], [ %v161, %bb25 ]
  %v199 = phi i64 [ %v162, %bb24 ], [ %v162, %bb25 ]
  %v200 = phi i64 [ %v163, %bb24 ], [ %v163, %bb25 ]
  %v201 = phi i1 [ %v164, %bb24 ], [ %v164, %bb25 ]
  %v202 = phi ptr [ %v165, %bb24 ], [ %v165, %bb25 ]
  %v203 = phi ptr [ %v166, %bb24 ], [ %v166, %bb25 ]
  %v204 = phi ptr [ %v167, %bb24 ], [ %v167, %bb25 ]
  %v205 = phi i64 [ %v168, %bb24 ], [ %v168, %bb25 ]
  %v206 = phi i64 [ %v169, %bb24 ], [ %v169, %bb25 ]
  %v207 = phi i64 [ %v170, %bb24 ], [ %v170, %bb25 ]
  %v208 = phi i64 [ %v173, %bb24 ], [ %v173, %bb25 ]
  %v209 = phi i64 [ %v190, %bb24 ], [ %v190, %bb25 ]
  %v210 = phi ptr [ %v192, %bb24 ], [ %v192, %bb25 ]
  %v221 = call %wf.t.b7e1ed626c09888a @wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe(ptr %v203, ptr %v210, ptr %v202, ptr %v204)
  store %wf.t.b7e1ed626c09888a %v221, ptr %wf.slot.7
  %v222 = call i8 @wf_map_cost_lookup_result(ptr %wf.slot.7, ptr %v204)
  br label %bb26
bb24:
  %t14 = getelementptr inbounds %wf.t.aba8f6d9883dda3a, ptr %wf.slot.4, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.5, ptr %t14, i64 ptrtoint (ptr getelementptr (%wf.t.d72ca22fbd302a84, ptr null, i32 1) to i64), i1 false)
  %v213 = select i1 true, i64 1, i64 1
  %v214 = call i8 @wf_map_cost_ordered(ptr %v167, i64 %v213)
  %t15 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.5, i32 0, i32 0
  %v215 = load i64, ptr %t15
  ; ownership-consuming projection
  %t16 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.5, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.6, ptr %t16, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %v217 = call i64 @wf_map_cost_record_content(i64 %v215, ptr %wf.slot.6)
  %v218 = call i8 @wf_map_cost_ordered(ptr %v167, i64 %v217)
  br label %bb23
bb25:
  %v219 = select i1 true, i64 0, i64 0
  %v220 = call i8 @wf_map_cost_ordered(ptr %v167, i64 %v219)
  br label %bb23
bb26:
  %v223 = phi i64 [ %v194, %bb23 ]
  %v224 = phi i64 [ %v195, %bb23 ]
  %v225 = phi i64 [ %v196, %bb23 ]
  %v226 = phi i64 [ %v197, %bb23 ]
  %v227 = phi i64 [ %v198, %bb23 ]
  %v228 = phi i64 [ %v199, %bb23 ]
  %v229 = phi i64 [ %v200, %bb23 ]
  %v230 = phi i1 [ %v201, %bb23 ]
  %v231 = phi ptr [ %v202, %bb23 ]
  %v232 = phi ptr [ %v203, %bb23 ]
  %v233 = phi ptr [ %v204, %bb23 ]
  %v234 = phi i64 [ %v205, %bb23 ]
  %v235 = phi i64 [ %v206, %bb23 ]
  %v236 = phi i64 [ %v207, %bb23 ]
  %v237 = phi i64 [ %v171, %bb23 ]
  %v238 = phi i64 [ %v172, %bb23 ]
  %v239 = phi i64 [ %v173, %bb23 ]
  %v240 = select i1 true, i64 1, i64 1
  %v241 = add i64 %v239, %v240
  br label %bb19
bb27:
  %v245 = phi i64 [ %v174, %bb22 ], [ %v283, %bb31 ]
  %v246 = phi i64 [ %v175, %bb22 ], [ %v284, %bb31 ]
  %v247 = phi i64 [ %v176, %bb22 ], [ %v285, %bb31 ]
  %v248 = phi i64 [ %v177, %bb22 ], [ %v286, %bb31 ]
  %v249 = phi i64 [ %v178, %bb22 ], [ %v287, %bb31 ]
  %v250 = phi i64 [ %v179, %bb22 ], [ %v288, %bb31 ]
  %v251 = phi i64 [ %v180, %bb22 ], [ %v289, %bb31 ]
  %v252 = phi i1 [ %v181, %bb22 ], [ %v290, %bb31 ]
  %v253 = phi ptr [ %v182, %bb22 ], [ %v291, %bb31 ]
  %v254 = phi ptr [ %v183, %bb22 ], [ %v292, %bb31 ]
  %v255 = phi ptr [ %v184, %bb22 ], [ %v293, %bb31 ]
  %v256 = phi i64 [ %v185, %bb22 ], [ %v294, %bb31 ]
  %v257 = phi i64 [ %v186, %bb22 ], [ %v295, %bb31 ]
  %v258 = phi i64 [ %v187, %bb22 ], [ %v296, %bb31 ]
  %v260 = phi i64 [ %v244, %bb22 ], [ %v298, %bb31 ]
  %v261 = phi i64 [ %v175, %bb22 ], [ %v299, %bb31 ]
  %v262 = phi i64 [ %v244, %bb22 ], [ %v302, %bb31 ]
  %v278 = icmp ult i64 %v262, %v261
  switch i1 %v278, label %invalid.tag.b27 [
    i1 1, label %bb28
    i1 0, label %bb29
  ]
invalid.tag.b27:
  unreachable
bb28:
  %v279 = call i64 @wf_map_cost_key(i64 %v262)
  store i64 %v279, ptr %v280
  %v281 = call %wf.t.b7e1ed626c09888a @wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe(ptr %v254, ptr %v280, ptr %v253, ptr %v255)
  store %wf.t.b7e1ed626c09888a %v281, ptr %wf.slot.9
  %v282 = call i8 @wf_map_cost_lookup_result(ptr %wf.slot.9, ptr %v255)
  br label %bb31
bb29:
  br label %bb30
bb30:
  %v263 = phi i64 [ %v245, %bb29 ]
  %v264 = phi i64 [ %v246, %bb29 ]
  %v265 = phi i64 [ %v247, %bb29 ]
  %v266 = phi i64 [ %v248, %bb29 ]
  %v267 = phi i64 [ %v249, %bb29 ]
  %v268 = phi i64 [ %v250, %bb29 ]
  %v269 = phi i64 [ %v251, %bb29 ]
  %v270 = phi i1 [ %v252, %bb29 ]
  %v271 = phi ptr [ %v253, %bb29 ]
  %v272 = phi ptr [ %v254, %bb29 ]
  %v273 = phi ptr [ %v255, %bb29 ]
  %v274 = phi i64 [ %v256, %bb29 ]
  %v275 = phi i64 [ %v257, %bb29 ]
  %v276 = phi i64 [ %v258, %bb29 ]
  %v303 = select i1 true, i64 0, i64 0
  br label %bb32
bb31:
  %v283 = phi i64 [ %v245, %bb28 ]
  %v284 = phi i64 [ %v246, %bb28 ]
  %v285 = phi i64 [ %v247, %bb28 ]
  %v286 = phi i64 [ %v248, %bb28 ]
  %v287 = phi i64 [ %v249, %bb28 ]
  %v288 = phi i64 [ %v250, %bb28 ]
  %v289 = phi i64 [ %v251, %bb28 ]
  %v290 = phi i1 [ %v252, %bb28 ]
  %v291 = phi ptr [ %v253, %bb28 ]
  %v292 = phi ptr [ %v254, %bb28 ]
  %v293 = phi ptr [ %v255, %bb28 ]
  %v294 = phi i64 [ %v256, %bb28 ]
  %v295 = phi i64 [ %v257, %bb28 ]
  %v296 = phi i64 [ %v258, %bb28 ]
  %v298 = phi i64 [ %v260, %bb28 ]
  %v299 = phi i64 [ %v261, %bb28 ]
  %v300 = phi i64 [ %v262, %bb28 ]
  %v301 = select i1 true, i64 1, i64 1
  %v302 = add i64 %v300, %v301
  br label %bb27
bb32:
  %v304 = phi i64 [ %v263, %bb30 ], [ %v410, %bb42 ]
  %v305 = phi i64 [ %v264, %bb30 ], [ %v411, %bb42 ]
  %v306 = phi i64 [ %v265, %bb30 ], [ %v412, %bb42 ]
  %v307 = phi i64 [ %v266, %bb30 ], [ %v413, %bb42 ]
  %v308 = phi i64 [ %v267, %bb30 ], [ %v414, %bb42 ]
  %v309 = phi i64 [ %v268, %bb30 ], [ %v415, %bb42 ]
  %v310 = phi i64 [ %v269, %bb30 ], [ %v416, %bb42 ]
  %v311 = phi i1 [ %v270, %bb30 ], [ %v417, %bb42 ]
  %v312 = phi ptr [ %v271, %bb30 ], [ %v418, %bb42 ]
  %v313 = phi ptr [ %v272, %bb30 ], [ %v419, %bb42 ]
  %v314 = phi ptr [ %v273, %bb30 ], [ %v420, %bb42 ]
  %v315 = phi i64 [ %v274, %bb30 ], [ %v421, %bb42 ]
  %v316 = phi i64 [ %v275, %bb30 ], [ %v422, %bb42 ]
  %v317 = phi i64 [ %v276, %bb30 ], [ %v423, %bb42 ]
  %v319 = phi i64 [ %v303, %bb30 ], [ %v425, %bb42 ]
  %v320 = phi i64 [ %v276, %bb30 ], [ %v426, %bb42 ]
  %v321 = phi i64 [ %v303, %bb30 ], [ %v429, %bb42 ]
  %v337 = icmp ult i64 %v321, %v320
  switch i1 %v337, label %invalid.tag.b32 [
    i1 1, label %bb33
    i1 0, label %bb34
  ]
invalid.tag.b32:
  unreachable
bb33:
  %v338 = select i1 true, i64 2, i64 2
  %v339 = mul i64 %v321, %v338
  %v340 = call i64 @wf_map_cost_key(i64 %v339)
  %v341 = select i1 true, i64 1, i64 1
  %v342 = add i64 %v315, %v341
  %v343 = mul i64 %v342, %v305
  %v344 = add i64 %v307, %v343
  %v345 = add i64 %v344, %v339
  call void @wf_map_cost_record_make(ptr %wf.slot.10, i64 %v345)
  call void @wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65(ptr %wf.slot.11, ptr %v313, i64 %v340, ptr %wf.slot.10, ptr %v312)
  %t17 = load %wf.t.114ba5754d75c8d6, ptr %wf.slot.11
  %t18 = extractvalue %wf.t.114ba5754d75c8d6 %t17, 0
  switch i32 %t18, label %invalid.tag.b33 [
    i32 0, label %bb37
    i32 1, label %bb38
  ]
invalid.tag.b33:
  unreachable
bb34:
  br label %bb35
bb35:
  %v322 = phi i64 [ %v304, %bb34 ]
  %v323 = phi i64 [ %v305, %bb34 ]
  %v324 = phi i64 [ %v306, %bb34 ]
  %v325 = phi i64 [ %v307, %bb34 ]
  %v326 = phi i64 [ %v308, %bb34 ]
  %v327 = phi i64 [ %v309, %bb34 ]
  %v328 = phi i64 [ %v310, %bb34 ]
  %v329 = phi i1 [ %v311, %bb34 ]
  %v330 = phi ptr [ %v312, %bb34 ]
  %v331 = phi ptr [ %v313, %bb34 ]
  %v332 = phi ptr [ %v314, %bb34 ]
  %v333 = phi i64 [ %v315, %bb34 ]
  %v334 = phi i64 [ %v316, %bb34 ]
  %v335 = phi i64 [ %v317, %bb34 ]
  br label %bb16
bb36:
  %v348 = phi i64 [ %v304, %bb37 ], [ %v376, %bb39 ]
  %v349 = phi i64 [ %v305, %bb37 ], [ %v377, %bb39 ]
  %v350 = phi i64 [ %v306, %bb37 ], [ %v378, %bb39 ]
  %v351 = phi i64 [ %v307, %bb37 ], [ %v379, %bb39 ]
  %v352 = phi i64 [ %v308, %bb37 ], [ %v380, %bb39 ]
  %v353 = phi i64 [ %v309, %bb37 ], [ %v381, %bb39 ]
  %v354 = phi i64 [ %v310, %bb37 ], [ %v382, %bb39 ]
  %v355 = phi i1 [ %v311, %bb37 ], [ %v383, %bb39 ]
  %v356 = phi ptr [ %v312, %bb37 ], [ %v384, %bb39 ]
  %v357 = phi ptr [ %v313, %bb37 ], [ %v385, %bb39 ]
  %v358 = phi ptr [ %v314, %bb37 ], [ %v386, %bb39 ]
  %v359 = phi i64 [ %v315, %bb37 ], [ %v387, %bb39 ]
  %v360 = phi i64 [ %v316, %bb37 ], [ %v388, %bb39 ]
  %v361 = phi i64 [ %v317, %bb37 ], [ %v389, %bb39 ]
  %v363 = phi i64 [ %v321, %bb37 ], [ %v391, %bb39 ]
  %v364 = phi i64 [ %v339, %bb37 ], [ %v392, %bb39 ]
  %v365 = phi i64 [ %v340, %bb37 ], [ %v393, %bb39 ]
  %v366 = phi i64 [ %v342, %bb37 ], [ %v394, %bb39 ]
  %v367 = phi i64 [ %v343, %bb37 ], [ %v395, %bb39 ]
  %v368 = phi i64 [ %v344, %bb37 ], [ %v396, %bb39 ]
  %v369 = phi i64 [ %v345, %bb37 ], [ %v397, %bb39 ]
  br label %bb42
bb37:
  %v372 = select i1 true, i64 0, i64 0
  %v373 = call i8 @wf_map_cost_ordered(ptr %v314, i64 %v372)
  br label %bb36
bb38:
  %t19 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.slot.11, i32 0, i32 1
  %v374 = load i1, ptr %t19
  %t20 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.slot.11, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.12, ptr %t20, i64 ptrtoint (ptr getelementptr (%wf.t.d72ca22fbd302a84, ptr null, i32 1) to i64), i1 false)
  switch i1 %v374, label %invalid.tag.b38 [
    i1 0, label %bb40
    i1 1, label %bb41
  ]
invalid.tag.b38:
  unreachable
bb39:
  %v376 = phi i64 [ %v304, %bb40 ], [ %v304, %bb41 ]
  %v377 = phi i64 [ %v305, %bb40 ], [ %v305, %bb41 ]
  %v378 = phi i64 [ %v306, %bb40 ], [ %v306, %bb41 ]
  %v379 = phi i64 [ %v307, %bb40 ], [ %v307, %bb41 ]
  %v380 = phi i64 [ %v308, %bb40 ], [ %v308, %bb41 ]
  %v381 = phi i64 [ %v309, %bb40 ], [ %v309, %bb41 ]
  %v382 = phi i64 [ %v310, %bb40 ], [ %v310, %bb41 ]
  %v383 = phi i1 [ %v311, %bb40 ], [ %v311, %bb41 ]
  %v384 = phi ptr [ %v312, %bb40 ], [ %v312, %bb41 ]
  %v385 = phi ptr [ %v313, %bb40 ], [ %v313, %bb41 ]
  %v386 = phi ptr [ %v314, %bb40 ], [ %v314, %bb41 ]
  %v387 = phi i64 [ %v315, %bb40 ], [ %v315, %bb41 ]
  %v388 = phi i64 [ %v316, %bb40 ], [ %v316, %bb41 ]
  %v389 = phi i64 [ %v317, %bb40 ], [ %v317, %bb41 ]
  %v391 = phi i64 [ %v321, %bb40 ], [ %v321, %bb41 ]
  %v392 = phi i64 [ %v339, %bb40 ], [ %v339, %bb41 ]
  %v393 = phi i64 [ %v340, %bb40 ], [ %v340, %bb41 ]
  %v394 = phi i64 [ %v342, %bb40 ], [ %v342, %bb41 ]
  %v395 = phi i64 [ %v343, %bb40 ], [ %v343, %bb41 ]
  %v396 = phi i64 [ %v344, %bb40 ], [ %v344, %bb41 ]
  %v397 = phi i64 [ %v345, %bb40 ], [ %v345, %bb41 ]
  %v400 = phi i1 [ %v374, %bb40 ], [ %v374, %bb41 ]
  %t21 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.12, i32 0, i32 0
  %v406 = load i64, ptr %t21
  ; ownership-consuming projection
  %t22 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.12, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.13, ptr %t22, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %v408 = call i64 @wf_map_cost_record_content(i64 %v406, ptr %wf.slot.13)
  %v409 = call i8 @wf_map_cost_ordered(ptr %v386, i64 %v408)
  br label %bb36
bb40:
  %v402 = select i1 true, i64 1, i64 1
  %v403 = call i8 @wf_map_cost_ordered(ptr %v314, i64 %v402)
  br label %bb39
bb41:
  %v404 = select i1 true, i64 2, i64 2
  %v405 = call i8 @wf_map_cost_ordered(ptr %v314, i64 %v404)
  br label %bb39
bb42:
  %v410 = phi i64 [ %v348, %bb36 ]
  %v411 = phi i64 [ %v349, %bb36 ]
  %v412 = phi i64 [ %v350, %bb36 ]
  %v413 = phi i64 [ %v351, %bb36 ]
  %v414 = phi i64 [ %v352, %bb36 ]
  %v415 = phi i64 [ %v353, %bb36 ]
  %v416 = phi i64 [ %v354, %bb36 ]
  %v417 = phi i1 [ %v355, %bb36 ]
  %v418 = phi ptr [ %v356, %bb36 ]
  %v419 = phi ptr [ %v357, %bb36 ]
  %v420 = phi ptr [ %v358, %bb36 ]
  %v421 = phi i64 [ %v359, %bb36 ]
  %v422 = phi i64 [ %v360, %bb36 ]
  %v423 = phi i64 [ %v361, %bb36 ]
  %v425 = phi i64 [ %v319, %bb36 ]
  %v426 = phi i64 [ %v320, %bb36 ]
  %v427 = phi i64 [ %v321, %bb36 ]
  %v428 = select i1 true, i64 1, i64 1
  %v429 = add i64 %v427, %v428
  br label %bb32
bb43:
  %v438 = phi i64 [ %v113, %bb45 ], [ %v502, %bb52 ]
  %v439 = phi i64 [ %v114, %bb45 ], [ %v503, %bb52 ]
  %v440 = phi i64 [ %v115, %bb45 ], [ %v504, %bb52 ]
  %v441 = phi i64 [ %v116, %bb45 ], [ %v505, %bb52 ]
  %v442 = phi i64 [ %v117, %bb45 ], [ %v506, %bb52 ]
  %v443 = phi i64 [ %v118, %bb45 ], [ %v507, %bb52 ]
  %v444 = phi i64 [ %v119, %bb45 ], [ %v508, %bb52 ]
  %v445 = phi i1 [ %v120, %bb45 ], [ %v509, %bb52 ]
  %v446 = phi ptr [ %v121, %bb45 ], [ %v510, %bb52 ]
  %v447 = phi ptr [ %v122, %bb45 ], [ %v511, %bb52 ]
  %v448 = phi ptr [ %v123, %bb45 ], [ %v512, %bb52 ]
  %v449 = phi i64 [ %v126, %bb45 ], [ %v513, %bb52 ]
  %v450 = phi i1 [ %v431, %bb45 ], [ %v514, %bb52 ]
  %v451 = phi i1 [ %v433, %bb45 ], [ %v515, %bb52 ]
  %v452 = phi i1 [ %v435, %bb45 ], [ %v516, %bb52 ]
  %v453 = phi i1 [ %v436, %bb45 ], [ %v517, %bb52 ]
  %v454 = phi i1 [ %v437, %bb45 ], [ %v518, %bb52 ]
  %v545 = select i1 true, i64 0, i64 0
  br label %bb58
bb44:
  %v455 = select i1 true, i64 1, i64 1
  %v456 = select i1 true, i64 0, i64 0
  %v457 = icmp ne i64 %v113, %v456
  switch i1 %v457, label %invalid.tag.b44 [
    i1 1, label %bb47
    i1 0, label %bb48
  ]
invalid.tag.b44:
  unreachable
bb45:
  br label %bb43
bb46:
  %v458 = phi i64 [ %v113, %bb47 ], [ %v113, %bb48 ]
  %v459 = phi i64 [ %v114, %bb47 ], [ %v114, %bb48 ]
  %v460 = phi i64 [ %v115, %bb47 ], [ %v115, %bb48 ]
  %v461 = phi i64 [ %v116, %bb47 ], [ %v116, %bb48 ]
  %v462 = phi i64 [ %v117, %bb47 ], [ %v117, %bb48 ]
  %v463 = phi i64 [ %v118, %bb47 ], [ %v118, %bb48 ]
  %v464 = phi i64 [ %v119, %bb47 ], [ %v119, %bb48 ]
  %v465 = phi i1 [ %v120, %bb47 ], [ %v120, %bb48 ]
  %v466 = phi ptr [ %v121, %bb47 ], [ %v121, %bb48 ]
  %v467 = phi ptr [ %v122, %bb47 ], [ %v122, %bb48 ]
  %v468 = phi ptr [ %v123, %bb47 ], [ %v123, %bb48 ]
  %v469 = phi i64 [ %v126, %bb47 ], [ %v126, %bb48 ]
  %v470 = phi i1 [ %v431, %bb47 ], [ %v431, %bb48 ]
  %v471 = phi i1 [ %v433, %bb47 ], [ %v433, %bb48 ]
  %v472 = phi i1 [ %v435, %bb47 ], [ %v435, %bb48 ]
  %v473 = phi i1 [ %v436, %bb47 ], [ %v436, %bb48 ]
  %v474 = phi i1 [ %v437, %bb47 ], [ %v437, %bb48 ]
  %v475 = phi i64 [ %v477, %bb47 ], [ %v455, %bb48 ]
  %v478 = select i1 true, i64 10, i64 10
  %v479 = icmp eq i64 %v462, %v478
  switch i1 %v479, label %invalid.tag.b46 [
    i1 1, label %bb50
    i1 0, label %bb51
  ]
invalid.tag.b46:
  unreachable
bb47:
  %v476 = select i1 true, i64 2, i64 2
  %v477 = mul nuw i64 %v113, %v476
  br label %bb46
bb48:
  br label %bb46
bb49:
  %v480 = phi i64 [ %v458, %bb50 ], [ %v458, %bb51 ]
  %v481 = phi i64 [ %v459, %bb50 ], [ %v459, %bb51 ]
  %v482 = phi i64 [ %v460, %bb50 ], [ %v460, %bb51 ]
  %v483 = phi i64 [ %v461, %bb50 ], [ %v461, %bb51 ]
  %v484 = phi i64 [ %v462, %bb50 ], [ %v462, %bb51 ]
  %v485 = phi i64 [ %v463, %bb50 ], [ %v463, %bb51 ]
  %v486 = phi i64 [ %v464, %bb50 ], [ %v464, %bb51 ]
  %v487 = phi i1 [ %v465, %bb50 ], [ %v465, %bb51 ]
  %v488 = phi ptr [ %v466, %bb50 ], [ %v466, %bb51 ]
  %v489 = phi ptr [ %v467, %bb50 ], [ %v467, %bb51 ]
  %v490 = phi ptr [ %v468, %bb50 ], [ %v468, %bb51 ]
  %v491 = phi i64 [ %v469, %bb50 ], [ %v469, %bb51 ]
  %v492 = phi i1 [ %v470, %bb50 ], [ %v470, %bb51 ]
  %v493 = phi i1 [ %v471, %bb50 ], [ %v471, %bb51 ]
  %v494 = phi i1 [ %v472, %bb50 ], [ %v472, %bb51 ]
  %v495 = phi i1 [ %v473, %bb50 ], [ %v473, %bb51 ]
  %v496 = phi i1 [ %v474, %bb50 ], [ %v474, %bb51 ]
  %v497 = phi i64 [ %v475, %bb50 ], [ %v475, %bb51 ]
  switch i1 %v495, label %invalid.tag.b49 [
    i1 1, label %bb53
    i1 0, label %bb54
  ]
invalid.tag.b49:
  unreachable
bb50:
  %v498 = select i1 true, i64 1, i64 1
  %v499 = call i8 @wf_map_cost_ordered(ptr %v468, i64 %v498)
  br label %bb49
bb51:
  %v500 = call %wf.t.7d7f918f7b4962fd @wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65(ptr %v467, i64 %v475, ptr %v466)
  store %wf.t.7d7f918f7b4962fd %v500, ptr %wf.slot.14
  %v501 = call i8 @wf_map_cost_rebuild_result(ptr %wf.slot.14, ptr %v468)
  br label %bb49
bb52:
  %v502 = phi i64 [ %v480, %bb54 ], [ %v522, %bb55 ]
  %v503 = phi i64 [ %v481, %bb54 ], [ %v523, %bb55 ]
  %v504 = phi i64 [ %v482, %bb54 ], [ %v524, %bb55 ]
  %v505 = phi i64 [ %v483, %bb54 ], [ %v525, %bb55 ]
  %v506 = phi i64 [ %v484, %bb54 ], [ %v526, %bb55 ]
  %v507 = phi i64 [ %v485, %bb54 ], [ %v527, %bb55 ]
  %v508 = phi i64 [ %v486, %bb54 ], [ %v528, %bb55 ]
  %v509 = phi i1 [ %v487, %bb54 ], [ %v529, %bb55 ]
  %v510 = phi ptr [ %v488, %bb54 ], [ %v530, %bb55 ]
  %v511 = phi ptr [ %v489, %bb54 ], [ %v531, %bb55 ]
  %v512 = phi ptr [ %v490, %bb54 ], [ %v532, %bb55 ]
  %v513 = phi i64 [ %v491, %bb54 ], [ %v533, %bb55 ]
  %v514 = phi i1 [ %v492, %bb54 ], [ %v534, %bb55 ]
  %v515 = phi i1 [ %v493, %bb54 ], [ %v535, %bb55 ]
  %v516 = phi i1 [ %v494, %bb54 ], [ %v536, %bb55 ]
  %v517 = phi i1 [ %v495, %bb54 ], [ %v537, %bb55 ]
  %v518 = phi i1 [ %v496, %bb54 ], [ %v538, %bb55 ]
  %v519 = phi i64 [ %v497, %bb54 ], [ %v539, %bb55 ]
  br label %bb43
bb53:
  %v520 = call i64 @wf_std.collections.hash_map.hash_map_capacity$instance$0e108827ecbbe374(ptr %v489)
  %v521 = icmp uge i64 %v520, %v497
  switch i1 %v521, label %invalid.tag.b53 [
    i1 1, label %bb56
    i1 0, label %bb57
  ]
invalid.tag.b53:
  unreachable
bb54:
  br label %bb52
bb55:
  %v522 = phi i64 [ %v480, %bb56 ], [ %v480, %bb57 ]
  %v523 = phi i64 [ %v481, %bb56 ], [ %v481, %bb57 ]
  %v524 = phi i64 [ %v482, %bb56 ], [ %v482, %bb57 ]
  %v525 = phi i64 [ %v483, %bb56 ], [ %v483, %bb57 ]
  %v526 = phi i64 [ %v484, %bb56 ], [ %v484, %bb57 ]
  %v527 = phi i64 [ %v485, %bb56 ], [ %v485, %bb57 ]
  %v528 = phi i64 [ %v486, %bb56 ], [ %v486, %bb57 ]
  %v529 = phi i1 [ %v487, %bb56 ], [ %v487, %bb57 ]
  %v530 = phi ptr [ %v488, %bb56 ], [ %v488, %bb57 ]
  %v531 = phi ptr [ %v489, %bb56 ], [ %v489, %bb57 ]
  %v532 = phi ptr [ %v490, %bb56 ], [ %v490, %bb57 ]
  %v533 = phi i64 [ %v491, %bb56 ], [ %v491, %bb57 ]
  %v534 = phi i1 [ %v492, %bb56 ], [ %v492, %bb57 ]
  %v535 = phi i1 [ %v493, %bb56 ], [ %v493, %bb57 ]
  %v536 = phi i1 [ %v494, %bb56 ], [ %v494, %bb57 ]
  %v537 = phi i1 [ %v495, %bb56 ], [ %v495, %bb57 ]
  %v538 = phi i1 [ %v496, %bb56 ], [ %v496, %bb57 ]
  %v539 = phi i64 [ %v497, %bb56 ], [ %v497, %bb57 ]
  %v540 = phi i64 [ %v520, %bb56 ], [ %v520, %bb57 ]
  br label %bb52
bb56:
  %v541 = select i1 true, i64 1, i64 1
  %v542 = call i8 @wf_map_cost_ordered(ptr %v490, i64 %v541)
  br label %bb55
bb57:
  %v543 = select i1 true, i64 0, i64 0
  %v544 = call i8 @wf_map_cost_ordered(ptr %v490, i64 %v543)
  br label %bb55
bb58:
  %v546 = phi i64 [ %v438, %bb43 ], [ %v925, %bb92 ]
  %v547 = phi i64 [ %v439, %bb43 ], [ %v926, %bb92 ]
  %v548 = phi i64 [ %v440, %bb43 ], [ %v927, %bb92 ]
  %v549 = phi i64 [ %v441, %bb43 ], [ %v928, %bb92 ]
  %v550 = phi i64 [ %v442, %bb43 ], [ %v929, %bb92 ]
  %v551 = phi i64 [ %v443, %bb43 ], [ %v930, %bb92 ]
  %v552 = phi i64 [ %v444, %bb43 ], [ %v931, %bb92 ]
  %v553 = phi i1 [ %v445, %bb43 ], [ %v932, %bb92 ]
  %v554 = phi ptr [ %v446, %bb43 ], [ %v933, %bb92 ]
  %v555 = phi ptr [ %v447, %bb43 ], [ %v934, %bb92 ]
  %v556 = phi ptr [ %v448, %bb43 ], [ %v935, %bb92 ]
  %v557 = phi i64 [ %v449, %bb43 ], [ %v936, %bb92 ]
  %v558 = phi i1 [ %v450, %bb43 ], [ %v937, %bb92 ]
  %v559 = phi i1 [ %v451, %bb43 ], [ %v938, %bb92 ]
  %v560 = phi i1 [ %v452, %bb43 ], [ %v939, %bb92 ]
  %v561 = phi i1 [ %v453, %bb43 ], [ %v940, %bb92 ]
  %v562 = phi i1 [ %v454, %bb43 ], [ %v941, %bb92 ]
  %v563 = phi i64 [ %v545, %bb43 ], [ %v942, %bb92 ]
  %v564 = phi i64 [ %v439, %bb43 ], [ %v943, %bb92 ]
  %v565 = phi i64 [ %v545, %bb43 ], [ %v946, %bb92 ]
  %v583 = icmp ult i64 %v565, %v564
  switch i1 %v583, label %invalid.tag.b58 [
    i1 1, label %bb59
    i1 0, label %bb60
  ]
invalid.tag.b58:
  unreachable
bb59:
  %v584 = select i1 true, i64 1, i64 1
  %v585 = icmp eq i64 %v550, %v584
  switch i1 %v585, label %invalid.tag.b59 [
    i1 1, label %bb63
    i1 0, label %bb64
  ]
invalid.tag.b59:
  unreachable
bb60:
  br label %bb61
bb61:
  %v566 = phi i64 [ %v546, %bb60 ]
  %v567 = phi i64 [ %v547, %bb60 ]
  %v568 = phi i64 [ %v548, %bb60 ]
  %v569 = phi i64 [ %v549, %bb60 ]
  %v570 = phi i64 [ %v550, %bb60 ]
  %v571 = phi i64 [ %v551, %bb60 ]
  %v572 = phi i64 [ %v552, %bb60 ]
  %v573 = phi i1 [ %v553, %bb60 ]
  %v574 = phi ptr [ %v554, %bb60 ]
  %v575 = phi ptr [ %v555, %bb60 ]
  %v576 = phi ptr [ %v556, %bb60 ]
  %v577 = phi i64 [ %v557, %bb60 ]
  %v578 = phi i1 [ %v558, %bb60 ]
  %v579 = phi i1 [ %v559, %bb60 ]
  %v580 = phi i1 [ %v560, %bb60 ]
  %v581 = phi i1 [ %v561, %bb60 ]
  %v582 = phi i1 [ %v562, %bb60 ]
  br label %bb16
bb62:
  %v586 = phi i64 [ %v546, %bb63 ], [ %v546, %bb64 ]
  %v587 = phi i64 [ %v547, %bb63 ], [ %v547, %bb64 ]
  %v588 = phi i64 [ %v548, %bb63 ], [ %v548, %bb64 ]
  %v589 = phi i64 [ %v549, %bb63 ], [ %v549, %bb64 ]
  %v590 = phi i64 [ %v550, %bb63 ], [ %v550, %bb64 ]
  %v591 = phi i64 [ %v551, %bb63 ], [ %v551, %bb64 ]
  %v592 = phi i64 [ %v552, %bb63 ], [ %v552, %bb64 ]
  %v593 = phi i1 [ %v553, %bb63 ], [ %v553, %bb64 ]
  %v594 = phi ptr [ %v554, %bb63 ], [ %v554, %bb64 ]
  %v595 = phi ptr [ %v555, %bb63 ], [ %v555, %bb64 ]
  %v596 = phi ptr [ %v556, %bb63 ], [ %v556, %bb64 ]
  %v597 = phi i64 [ %v557, %bb63 ], [ %v557, %bb64 ]
  %v598 = phi i1 [ %v558, %bb63 ], [ %v558, %bb64 ]
  %v599 = phi i1 [ %v559, %bb63 ], [ %v559, %bb64 ]
  %v600 = phi i1 [ %v560, %bb63 ], [ %v560, %bb64 ]
  %v601 = phi i1 [ %v561, %bb63 ], [ %v561, %bb64 ]
  %v602 = phi i1 [ %v562, %bb63 ], [ %v562, %bb64 ]
  %v603 = phi i64 [ %v565, %bb63 ], [ %v565, %bb64 ]
  %v604 = phi i64 [ %v605, %bb63 ], [ %v565, %bb64 ]
  %v606 = call i64 @wf_map_cost_key(i64 %v604)
  store i64 %v606, ptr %v607
  %v608 = select i1 true, i64 0, i64 0
  %v609 = icmp eq i64 %v590, %v608
  %v610 = select i1 true, i64 1, i64 1
  %v611 = icmp eq i64 %v590, %v610
  %v612 = or i1 %v609, %v611
  %v613 = or i1 %v612, %v602
  switch i1 %v613, label %invalid.tag.b62 [
    i1 1, label %bb66
    i1 0, label %bb67
  ]
invalid.tag.b62:
  unreachable
bb63:
  %v605 = add i64 %v547, %v565
  br label %bb62
bb64:
  br label %bb62
bb65:
  %v614 = phi i64 [ %v586, %bb66 ], [ %v642, %bb68 ]
  %v615 = phi i64 [ %v587, %bb66 ], [ %v643, %bb68 ]
  %v616 = phi i64 [ %v588, %bb66 ], [ %v644, %bb68 ]
  %v617 = phi i64 [ %v589, %bb66 ], [ %v645, %bb68 ]
  %v618 = phi i64 [ %v590, %bb66 ], [ %v646, %bb68 ]
  %v619 = phi i64 [ %v591, %bb66 ], [ %v647, %bb68 ]
  %v620 = phi i64 [ %v592, %bb66 ], [ %v648, %bb68 ]
  %v621 = phi i1 [ %v593, %bb66 ], [ %v649, %bb68 ]
  %v622 = phi ptr [ %v594, %bb66 ], [ %v650, %bb68 ]
  %v623 = phi ptr [ %v595, %bb66 ], [ %v651, %bb68 ]
  %v624 = phi ptr [ %v596, %bb66 ], [ %v652, %bb68 ]
  %v625 = phi i64 [ %v597, %bb66 ], [ %v653, %bb68 ]
  %v626 = phi i1 [ %v598, %bb66 ], [ %v654, %bb68 ]
  %v627 = phi i1 [ %v599, %bb66 ], [ %v655, %bb68 ]
  %v628 = phi i1 [ %v600, %bb66 ], [ %v656, %bb68 ]
  %v629 = phi i1 [ %v601, %bb66 ], [ %v657, %bb68 ]
  %v630 = phi i1 [ %v602, %bb66 ], [ %v658, %bb68 ]
  %v631 = phi i64 [ %v603, %bb66 ], [ %v659, %bb68 ]
  %v632 = phi i64 [ %v604, %bb66 ], [ %v660, %bb68 ]
  %v633 = phi ptr [ %v607, %bb66 ], [ %v661, %bb68 ]
  %v634 = phi i1 [ %v609, %bb66 ], [ %v662, %bb68 ]
  %v635 = phi i1 [ %v611, %bb66 ], [ %v663, %bb68 ]
  %v636 = phi i1 [ %v612, %bb66 ], [ %v664, %bb68 ]
  %v637 = phi i1 [ %v613, %bb66 ], [ %v665, %bb68 ]
  br label %bb92
bb66:
  %v638 = call %wf.t.b7e1ed626c09888a @wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe(ptr %v595, ptr %v607, ptr %v594, ptr %v596)
  store %wf.t.b7e1ed626c09888a %v638, ptr %wf.slot.15
  %v639 = call i8 @wf_map_cost_lookup_result(ptr %wf.slot.15, ptr %v596)
  br label %bb65
bb67:
  %v640 = select i1 true, i64 2, i64 2
  %v641 = icmp eq i64 %v590, %v640
  switch i1 %v641, label %invalid.tag.b67 [
    i1 1, label %bb69
    i1 0, label %bb70
  ]
invalid.tag.b67:
  unreachable
bb68:
  %v642 = phi i64 [ %v674, %bb71 ], [ %v750, %bb77 ]
  %v643 = phi i64 [ %v675, %bb71 ], [ %v751, %bb77 ]
  %v644 = phi i64 [ %v676, %bb71 ], [ %v752, %bb77 ]
  %v645 = phi i64 [ %v677, %bb71 ], [ %v753, %bb77 ]
  %v646 = phi i64 [ %v678, %bb71 ], [ %v754, %bb77 ]
  %v647 = phi i64 [ %v679, %bb71 ], [ %v755, %bb77 ]
  %v648 = phi i64 [ %v680, %bb71 ], [ %v756, %bb77 ]
  %v649 = phi i1 [ %v681, %bb71 ], [ %v757, %bb77 ]
  %v650 = phi ptr [ %v682, %bb71 ], [ %v758, %bb77 ]
  %v651 = phi ptr [ %v683, %bb71 ], [ %v759, %bb77 ]
  %v652 = phi ptr [ %v684, %bb71 ], [ %v760, %bb77 ]
  %v653 = phi i64 [ %v685, %bb71 ], [ %v761, %bb77 ]
  %v654 = phi i1 [ %v686, %bb71 ], [ %v762, %bb77 ]
  %v655 = phi i1 [ %v687, %bb71 ], [ %v763, %bb77 ]
  %v656 = phi i1 [ %v688, %bb71 ], [ %v764, %bb77 ]
  %v657 = phi i1 [ %v689, %bb71 ], [ %v765, %bb77 ]
  %v658 = phi i1 [ %v690, %bb71 ], [ %v766, %bb77 ]
  %v659 = phi i64 [ %v691, %bb71 ], [ %v767, %bb77 ]
  %v660 = phi i64 [ %v692, %bb71 ], [ %v768, %bb77 ]
  %v661 = phi ptr [ %v693, %bb71 ], [ %v769, %bb77 ]
  %v662 = phi i1 [ %v694, %bb71 ], [ %v770, %bb77 ]
  %v663 = phi i1 [ %v695, %bb71 ], [ %v771, %bb77 ]
  %v664 = phi i1 [ %v696, %bb71 ], [ %v772, %bb77 ]
  %v665 = phi i1 [ %v697, %bb71 ], [ %v773, %bb77 ]
  br label %bb65
bb69:
  %v666 = select i1 true, i64 1, i64 1
  %v667 = add i64 %v597, %v666
  %v668 = mul i64 %v667, %v587
  %v669 = add i64 %v589, %v668
  %v670 = add i64 %v669, %v603
  call void @wf_map_cost_record_make(ptr %wf.slot.16, i64 %v670)
  %v672 = load i64, ptr %v607
  call void @wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65(ptr %wf.slot.17, ptr %v595, i64 %v672, ptr %wf.slot.16, ptr %v594)
  %t23 = load %wf.t.114ba5754d75c8d6, ptr %wf.slot.17
  %t24 = extractvalue %wf.t.114ba5754d75c8d6 %t23, 0
  switch i32 %t24, label %invalid.tag.b69 [
    i32 0, label %bb72
    i32 1, label %bb73
  ]
invalid.tag.b69:
  unreachable
bb70:
  %v748 = select i1 true, i64 3, i64 3
  %v749 = icmp eq i64 %v590, %v748
  switch i1 %v749, label %invalid.tag.b70 [
    i1 1, label %bb78
    i1 0, label %bb79
  ]
invalid.tag.b70:
  unreachable
bb71:
  %v674 = phi i64 [ %v586, %bb72 ], [ %v708, %bb74 ]
  %v675 = phi i64 [ %v587, %bb72 ], [ %v709, %bb74 ]
  %v676 = phi i64 [ %v588, %bb72 ], [ %v710, %bb74 ]
  %v677 = phi i64 [ %v589, %bb72 ], [ %v711, %bb74 ]
  %v678 = phi i64 [ %v590, %bb72 ], [ %v712, %bb74 ]
  %v679 = phi i64 [ %v591, %bb72 ], [ %v713, %bb74 ]
  %v680 = phi i64 [ %v592, %bb72 ], [ %v714, %bb74 ]
  %v681 = phi i1 [ %v593, %bb72 ], [ %v715, %bb74 ]
  %v682 = phi ptr [ %v594, %bb72 ], [ %v716, %bb74 ]
  %v683 = phi ptr [ %v595, %bb72 ], [ %v717, %bb74 ]
  %v684 = phi ptr [ %v596, %bb72 ], [ %v718, %bb74 ]
  %v685 = phi i64 [ %v597, %bb72 ], [ %v719, %bb74 ]
  %v686 = phi i1 [ %v598, %bb72 ], [ %v720, %bb74 ]
  %v687 = phi i1 [ %v599, %bb72 ], [ %v721, %bb74 ]
  %v688 = phi i1 [ %v600, %bb72 ], [ %v722, %bb74 ]
  %v689 = phi i1 [ %v601, %bb72 ], [ %v723, %bb74 ]
  %v690 = phi i1 [ %v602, %bb72 ], [ %v724, %bb74 ]
  %v691 = phi i64 [ %v603, %bb72 ], [ %v725, %bb74 ]
  %v692 = phi i64 [ %v604, %bb72 ], [ %v726, %bb74 ]
  %v693 = phi ptr [ %v607, %bb72 ], [ %v727, %bb74 ]
  %v694 = phi i1 [ %v609, %bb72 ], [ %v728, %bb74 ]
  %v695 = phi i1 [ %v611, %bb72 ], [ %v729, %bb74 ]
  %v696 = phi i1 [ %v612, %bb72 ], [ %v730, %bb74 ]
  %v697 = phi i1 [ %v613, %bb72 ], [ %v731, %bb74 ]
  %v698 = phi i64 [ %v667, %bb72 ], [ %v732, %bb74 ]
  %v699 = phi i64 [ %v668, %bb72 ], [ %v733, %bb74 ]
  %v700 = phi i64 [ %v669, %bb72 ], [ %v734, %bb74 ]
  %v701 = phi i64 [ %v670, %bb72 ], [ %v735, %bb74 ]
  br label %bb68
bb72:
  %v704 = select i1 true, i64 0, i64 0
  %v705 = call i8 @wf_map_cost_ordered(ptr %v596, i64 %v704)
  br label %bb71
bb73:
  %t25 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.slot.17, i32 0, i32 1
  %v706 = load i1, ptr %t25
  %t26 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.slot.17, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.18, ptr %t26, i64 ptrtoint (ptr getelementptr (%wf.t.d72ca22fbd302a84, ptr null, i32 1) to i64), i1 false)
  switch i1 %v706, label %invalid.tag.b73 [
    i1 0, label %bb75
    i1 1, label %bb76
  ]
invalid.tag.b73:
  unreachable
bb74:
  %v708 = phi i64 [ %v586, %bb75 ], [ %v586, %bb76 ]
  %v709 = phi i64 [ %v587, %bb75 ], [ %v587, %bb76 ]
  %v710 = phi i64 [ %v588, %bb75 ], [ %v588, %bb76 ]
  %v711 = phi i64 [ %v589, %bb75 ], [ %v589, %bb76 ]
  %v712 = phi i64 [ %v590, %bb75 ], [ %v590, %bb76 ]
  %v713 = phi i64 [ %v591, %bb75 ], [ %v591, %bb76 ]
  %v714 = phi i64 [ %v592, %bb75 ], [ %v592, %bb76 ]
  %v715 = phi i1 [ %v593, %bb75 ], [ %v593, %bb76 ]
  %v716 = phi ptr [ %v594, %bb75 ], [ %v594, %bb76 ]
  %v717 = phi ptr [ %v595, %bb75 ], [ %v595, %bb76 ]
  %v718 = phi ptr [ %v596, %bb75 ], [ %v596, %bb76 ]
  %v719 = phi i64 [ %v597, %bb75 ], [ %v597, %bb76 ]
  %v720 = phi i1 [ %v598, %bb75 ], [ %v598, %bb76 ]
  %v721 = phi i1 [ %v599, %bb75 ], [ %v599, %bb76 ]
  %v722 = phi i1 [ %v600, %bb75 ], [ %v600, %bb76 ]
  %v723 = phi i1 [ %v601, %bb75 ], [ %v601, %bb76 ]
  %v724 = phi i1 [ %v602, %bb75 ], [ %v602, %bb76 ]
  %v725 = phi i64 [ %v603, %bb75 ], [ %v603, %bb76 ]
  %v726 = phi i64 [ %v604, %bb75 ], [ %v604, %bb76 ]
  %v727 = phi ptr [ %v607, %bb75 ], [ %v607, %bb76 ]
  %v728 = phi i1 [ %v609, %bb75 ], [ %v609, %bb76 ]
  %v729 = phi i1 [ %v611, %bb75 ], [ %v611, %bb76 ]
  %v730 = phi i1 [ %v612, %bb75 ], [ %v612, %bb76 ]
  %v731 = phi i1 [ %v613, %bb75 ], [ %v613, %bb76 ]
  %v732 = phi i64 [ %v667, %bb75 ], [ %v667, %bb76 ]
  %v733 = phi i64 [ %v668, %bb75 ], [ %v668, %bb76 ]
  %v734 = phi i64 [ %v669, %bb75 ], [ %v669, %bb76 ]
  %v735 = phi i64 [ %v670, %bb75 ], [ %v670, %bb76 ]
  %v738 = phi i1 [ %v706, %bb75 ], [ %v706, %bb76 ]
  %t27 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.18, i32 0, i32 0
  %v744 = load i64, ptr %t27
  ; ownership-consuming projection
  %t28 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.18, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.19, ptr %t28, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %v746 = call i64 @wf_map_cost_record_content(i64 %v744, ptr %wf.slot.19)
  %v747 = call i8 @wf_map_cost_ordered(ptr %v718, i64 %v746)
  br label %bb71
bb75:
  %v740 = select i1 true, i64 1, i64 1
  %v741 = call i8 @wf_map_cost_ordered(ptr %v596, i64 %v740)
  br label %bb74
bb76:
  %v742 = select i1 true, i64 2, i64 2
  %v743 = call i8 @wf_map_cost_ordered(ptr %v596, i64 %v742)
  br label %bb74
bb77:
  %v750 = phi i64 [ %v819, %bb83 ], [ %v899, %bb89 ]
  %v751 = phi i64 [ %v820, %bb83 ], [ %v900, %bb89 ]
  %v752 = phi i64 [ %v821, %bb83 ], [ %v901, %bb89 ]
  %v753 = phi i64 [ %v822, %bb83 ], [ %v902, %bb89 ]
  %v754 = phi i64 [ %v823, %bb83 ], [ %v903, %bb89 ]
  %v755 = phi i64 [ %v824, %bb83 ], [ %v904, %bb89 ]
  %v756 = phi i64 [ %v825, %bb83 ], [ %v905, %bb89 ]
  %v757 = phi i1 [ %v826, %bb83 ], [ %v906, %bb89 ]
  %v758 = phi ptr [ %v827, %bb83 ], [ %v907, %bb89 ]
  %v759 = phi ptr [ %v828, %bb83 ], [ %v908, %bb89 ]
  %v760 = phi ptr [ %v829, %bb83 ], [ %v909, %bb89 ]
  %v761 = phi i64 [ %v830, %bb83 ], [ %v910, %bb89 ]
  %v762 = phi i1 [ %v831, %bb83 ], [ %v911, %bb89 ]
  %v763 = phi i1 [ %v832, %bb83 ], [ %v912, %bb89 ]
  %v764 = phi i1 [ %v833, %bb83 ], [ %v913, %bb89 ]
  %v765 = phi i1 [ %v834, %bb83 ], [ %v914, %bb89 ]
  %v766 = phi i1 [ %v835, %bb83 ], [ %v915, %bb89 ]
  %v767 = phi i64 [ %v836, %bb83 ], [ %v916, %bb89 ]
  %v768 = phi i64 [ %v837, %bb83 ], [ %v917, %bb89 ]
  %v769 = phi ptr [ %v838, %bb83 ], [ %v918, %bb89 ]
  %v770 = phi i1 [ %v839, %bb83 ], [ %v919, %bb89 ]
  %v771 = phi i1 [ %v840, %bb83 ], [ %v920, %bb89 ]
  %v772 = phi i1 [ %v841, %bb83 ], [ %v921, %bb89 ]
  %v773 = phi i1 [ %v842, %bb83 ], [ %v922, %bb89 ]
  br label %bb68
bb78:
  call void @wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65(ptr %wf.slot.20, ptr %v595, ptr %v607, ptr %v594)
  %t29 = load %wf.t.aba8f6d9883dda3a, ptr %wf.slot.20
  %t30 = extractvalue %wf.t.aba8f6d9883dda3a %t29, 0
  switch i32 %t30, label %invalid.tag.b78 [
    i32 1, label %bb81
    i32 0, label %bb82
  ]
invalid.tag.b78:
  unreachable
bb79:
  %v897 = select i1 true, i64 7, i64 7
  %v898 = icmp eq i64 %v590, %v897
  switch i1 %v898, label %invalid.tag.b79 [
    i1 1, label %bb90
    i1 0, label %bb91
  ]
invalid.tag.b79:
  unreachable
bb80:
  %v775 = phi i64 [ %v586, %bb81 ], [ %v586, %bb82 ]
  %v776 = phi i64 [ %v587, %bb81 ], [ %v587, %bb82 ]
  %v777 = phi i64 [ %v588, %bb81 ], [ %v588, %bb82 ]
  %v778 = phi i64 [ %v589, %bb81 ], [ %v589, %bb82 ]
  %v779 = phi i64 [ %v590, %bb81 ], [ %v590, %bb82 ]
  %v780 = phi i64 [ %v591, %bb81 ], [ %v591, %bb82 ]
  %v781 = phi i64 [ %v592, %bb81 ], [ %v592, %bb82 ]
  %v782 = phi i1 [ %v593, %bb81 ], [ %v593, %bb82 ]
  %v783 = phi ptr [ %v594, %bb81 ], [ %v594, %bb82 ]
  %v784 = phi ptr [ %v595, %bb81 ], [ %v595, %bb82 ]
  %v785 = phi ptr [ %v596, %bb81 ], [ %v596, %bb82 ]
  %v786 = phi i64 [ %v597, %bb81 ], [ %v597, %bb82 ]
  %v787 = phi i1 [ %v598, %bb81 ], [ %v598, %bb82 ]
  %v788 = phi i1 [ %v599, %bb81 ], [ %v599, %bb82 ]
  %v789 = phi i1 [ %v600, %bb81 ], [ %v600, %bb82 ]
  %v790 = phi i1 [ %v601, %bb81 ], [ %v601, %bb82 ]
  %v791 = phi i1 [ %v602, %bb81 ], [ %v602, %bb82 ]
  %v792 = phi i64 [ %v603, %bb81 ], [ %v603, %bb82 ]
  %v793 = phi i64 [ %v604, %bb81 ], [ %v604, %bb82 ]
  %v794 = phi ptr [ %v607, %bb81 ], [ %v607, %bb82 ]
  %v795 = phi i1 [ %v609, %bb81 ], [ %v609, %bb82 ]
  %v796 = phi i1 [ %v611, %bb81 ], [ %v611, %bb82 ]
  %v797 = phi i1 [ %v612, %bb81 ], [ %v612, %bb82 ]
  %v798 = phi i1 [ %v613, %bb81 ], [ %v613, %bb82 ]
  %v809 = call %wf.t.b7e1ed626c09888a @wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe(ptr %v784, ptr %v794, ptr %v783, ptr %v785)
  store %wf.t.b7e1ed626c09888a %v809, ptr %wf.slot.23
  %v810 = call i8 @wf_map_cost_lookup_result(ptr %wf.slot.23, ptr %v785)
  %v811 = select i1 true, i64 1, i64 1
  %v812 = add i64 %v786, %v811
  %v813 = mul i64 %v812, %v776
  %v814 = add i64 %v778, %v813
  %v815 = add i64 %v814, %v792
  call void @wf_map_cost_record_make(ptr %wf.slot.24, i64 %v815)
  %v817 = load i64, ptr %v794
  call void @wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65(ptr %wf.slot.25, ptr %v784, i64 %v817, ptr %wf.slot.24, ptr %v783)
  %t31 = load %wf.t.114ba5754d75c8d6, ptr %wf.slot.25
  %t32 = extractvalue %wf.t.114ba5754d75c8d6 %t31, 0
  switch i32 %t32, label %invalid.tag.b80 [
    i32 0, label %bb84
    i32 1, label %bb85
  ]
invalid.tag.b80:
  unreachable
bb81:
  %t33 = getelementptr inbounds %wf.t.aba8f6d9883dda3a, ptr %wf.slot.20, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.21, ptr %t33, i64 ptrtoint (ptr getelementptr (%wf.t.d72ca22fbd302a84, ptr null, i32 1) to i64), i1 false)
  %v801 = select i1 true, i64 1, i64 1
  %v802 = call i8 @wf_map_cost_ordered(ptr %v596, i64 %v801)
  %t34 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.21, i32 0, i32 0
  %v803 = load i64, ptr %t34
  ; ownership-consuming projection
  %t35 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.21, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.22, ptr %t35, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %v805 = call i64 @wf_map_cost_record_content(i64 %v803, ptr %wf.slot.22)
  %v806 = call i8 @wf_map_cost_ordered(ptr %v596, i64 %v805)
  br label %bb80
bb82:
  %v807 = select i1 true, i64 0, i64 0
  %v808 = call i8 @wf_map_cost_ordered(ptr %v596, i64 %v807)
  br label %bb80
bb83:
  %v819 = phi i64 [ %v775, %bb84 ], [ %v855, %bb86 ]
  %v820 = phi i64 [ %v776, %bb84 ], [ %v856, %bb86 ]
  %v821 = phi i64 [ %v777, %bb84 ], [ %v857, %bb86 ]
  %v822 = phi i64 [ %v778, %bb84 ], [ %v858, %bb86 ]
  %v823 = phi i64 [ %v779, %bb84 ], [ %v859, %bb86 ]
  %v824 = phi i64 [ %v780, %bb84 ], [ %v860, %bb86 ]
  %v825 = phi i64 [ %v781, %bb84 ], [ %v861, %bb86 ]
  %v826 = phi i1 [ %v782, %bb84 ], [ %v862, %bb86 ]
  %v827 = phi ptr [ %v783, %bb84 ], [ %v863, %bb86 ]
  %v828 = phi ptr [ %v784, %bb84 ], [ %v864, %bb86 ]
  %v829 = phi ptr [ %v785, %bb84 ], [ %v865, %bb86 ]
  %v830 = phi i64 [ %v786, %bb84 ], [ %v866, %bb86 ]
  %v831 = phi i1 [ %v787, %bb84 ], [ %v867, %bb86 ]
  %v832 = phi i1 [ %v788, %bb84 ], [ %v868, %bb86 ]
  %v833 = phi i1 [ %v789, %bb84 ], [ %v869, %bb86 ]
  %v834 = phi i1 [ %v790, %bb84 ], [ %v870, %bb86 ]
  %v835 = phi i1 [ %v791, %bb84 ], [ %v871, %bb86 ]
  %v836 = phi i64 [ %v792, %bb84 ], [ %v872, %bb86 ]
  %v837 = phi i64 [ %v793, %bb84 ], [ %v873, %bb86 ]
  %v838 = phi ptr [ %v794, %bb84 ], [ %v874, %bb86 ]
  %v839 = phi i1 [ %v795, %bb84 ], [ %v875, %bb86 ]
  %v840 = phi i1 [ %v796, %bb84 ], [ %v876, %bb86 ]
  %v841 = phi i1 [ %v797, %bb84 ], [ %v877, %bb86 ]
  %v842 = phi i1 [ %v798, %bb84 ], [ %v878, %bb86 ]
  %v845 = phi i64 [ %v812, %bb84 ], [ %v881, %bb86 ]
  %v846 = phi i64 [ %v813, %bb84 ], [ %v882, %bb86 ]
  %v847 = phi i64 [ %v814, %bb84 ], [ %v883, %bb86 ]
  %v848 = phi i64 [ %v815, %bb84 ], [ %v884, %bb86 ]
  br label %bb77
bb84:
  %v851 = select i1 true, i64 0, i64 0
  %v852 = call i8 @wf_map_cost_ordered(ptr %v785, i64 %v851)
  br label %bb83
bb85:
  %t36 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.slot.25, i32 0, i32 1
  %v853 = load i1, ptr %t36
  %t37 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.slot.25, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.26, ptr %t37, i64 ptrtoint (ptr getelementptr (%wf.t.d72ca22fbd302a84, ptr null, i32 1) to i64), i1 false)
  switch i1 %v853, label %invalid.tag.b85 [
    i1 0, label %bb87
    i1 1, label %bb88
  ]
invalid.tag.b85:
  unreachable
bb86:
  %v855 = phi i64 [ %v775, %bb87 ], [ %v775, %bb88 ]
  %v856 = phi i64 [ %v776, %bb87 ], [ %v776, %bb88 ]
  %v857 = phi i64 [ %v777, %bb87 ], [ %v777, %bb88 ]
  %v858 = phi i64 [ %v778, %bb87 ], [ %v778, %bb88 ]
  %v859 = phi i64 [ %v779, %bb87 ], [ %v779, %bb88 ]
  %v860 = phi i64 [ %v780, %bb87 ], [ %v780, %bb88 ]
  %v861 = phi i64 [ %v781, %bb87 ], [ %v781, %bb88 ]
  %v862 = phi i1 [ %v782, %bb87 ], [ %v782, %bb88 ]
  %v863 = phi ptr [ %v783, %bb87 ], [ %v783, %bb88 ]
  %v864 = phi ptr [ %v784, %bb87 ], [ %v784, %bb88 ]
  %v865 = phi ptr [ %v785, %bb87 ], [ %v785, %bb88 ]
  %v866 = phi i64 [ %v786, %bb87 ], [ %v786, %bb88 ]
  %v867 = phi i1 [ %v787, %bb87 ], [ %v787, %bb88 ]
  %v868 = phi i1 [ %v788, %bb87 ], [ %v788, %bb88 ]
  %v869 = phi i1 [ %v789, %bb87 ], [ %v789, %bb88 ]
  %v870 = phi i1 [ %v790, %bb87 ], [ %v790, %bb88 ]
  %v871 = phi i1 [ %v791, %bb87 ], [ %v791, %bb88 ]
  %v872 = phi i64 [ %v792, %bb87 ], [ %v792, %bb88 ]
  %v873 = phi i64 [ %v793, %bb87 ], [ %v793, %bb88 ]
  %v874 = phi ptr [ %v794, %bb87 ], [ %v794, %bb88 ]
  %v875 = phi i1 [ %v795, %bb87 ], [ %v795, %bb88 ]
  %v876 = phi i1 [ %v796, %bb87 ], [ %v796, %bb88 ]
  %v877 = phi i1 [ %v797, %bb87 ], [ %v797, %bb88 ]
  %v878 = phi i1 [ %v798, %bb87 ], [ %v798, %bb88 ]
  %v881 = phi i64 [ %v812, %bb87 ], [ %v812, %bb88 ]
  %v882 = phi i64 [ %v813, %bb87 ], [ %v813, %bb88 ]
  %v883 = phi i64 [ %v814, %bb87 ], [ %v814, %bb88 ]
  %v884 = phi i64 [ %v815, %bb87 ], [ %v815, %bb88 ]
  %v887 = phi i1 [ %v853, %bb87 ], [ %v853, %bb88 ]
  %t38 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.26, i32 0, i32 0
  %v893 = load i64, ptr %t38
  ; ownership-consuming projection
  %t39 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.26, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.27, ptr %t39, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %v895 = call i64 @wf_map_cost_record_content(i64 %v893, ptr %wf.slot.27)
  %v896 = call i8 @wf_map_cost_ordered(ptr %v865, i64 %v895)
  br label %bb83
bb87:
  %v889 = select i1 true, i64 1, i64 1
  %v890 = call i8 @wf_map_cost_ordered(ptr %v785, i64 %v889)
  br label %bb86
bb88:
  %v891 = select i1 true, i64 2, i64 2
  %v892 = call i8 @wf_map_cost_ordered(ptr %v785, i64 %v891)
  br label %bb86
bb89:
  %v899 = phi i64 [ %v586, %bb90 ], [ %v586, %bb91 ]
  %v900 = phi i64 [ %v587, %bb90 ], [ %v587, %bb91 ]
  %v901 = phi i64 [ %v588, %bb90 ], [ %v588, %bb91 ]
  %v902 = phi i64 [ %v589, %bb90 ], [ %v589, %bb91 ]
  %v903 = phi i64 [ %v590, %bb90 ], [ %v590, %bb91 ]
  %v904 = phi i64 [ %v591, %bb90 ], [ %v591, %bb91 ]
  %v905 = phi i64 [ %v592, %bb90 ], [ %v592, %bb91 ]
  %v906 = phi i1 [ %v593, %bb90 ], [ %v593, %bb91 ]
  %v907 = phi ptr [ %v594, %bb90 ], [ %v594, %bb91 ]
  %v908 = phi ptr [ %v595, %bb90 ], [ %v595, %bb91 ]
  %v909 = phi ptr [ %v596, %bb90 ], [ %v596, %bb91 ]
  %v910 = phi i64 [ %v597, %bb90 ], [ %v597, %bb91 ]
  %v911 = phi i1 [ %v598, %bb90 ], [ %v598, %bb91 ]
  %v912 = phi i1 [ %v599, %bb90 ], [ %v599, %bb91 ]
  %v913 = phi i1 [ %v600, %bb90 ], [ %v600, %bb91 ]
  %v914 = phi i1 [ %v601, %bb90 ], [ %v601, %bb91 ]
  %v915 = phi i1 [ %v602, %bb90 ], [ %v602, %bb91 ]
  %v916 = phi i64 [ %v603, %bb90 ], [ %v603, %bb91 ]
  %v917 = phi i64 [ %v604, %bb90 ], [ %v604, %bb91 ]
  %v918 = phi ptr [ %v607, %bb90 ], [ %v607, %bb91 ]
  %v919 = phi i1 [ %v609, %bb90 ], [ %v609, %bb91 ]
  %v920 = phi i1 [ %v611, %bb90 ], [ %v611, %bb91 ]
  %v921 = phi i1 [ %v612, %bb90 ], [ %v612, %bb91 ]
  %v922 = phi i1 [ %v613, %bb90 ], [ %v613, %bb91 ]
  br label %bb77
bb90:
  %v923 = call %wf.t.b7e1ed626c09888a @wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49(ptr %v595, ptr %v607, ptr %v594, ptr %v596)
  store %wf.t.b7e1ed626c09888a %v923, ptr %wf.slot.28
  %v924 = call i8 @wf_map_cost_lookup_result(ptr %wf.slot.28, ptr %v596)
  br label %bb89
bb91:
  br label %bb89
bb92:
  %v925 = phi i64 [ %v614, %bb65 ]
  %v926 = phi i64 [ %v615, %bb65 ]
  %v927 = phi i64 [ %v616, %bb65 ]
  %v928 = phi i64 [ %v617, %bb65 ]
  %v929 = phi i64 [ %v618, %bb65 ]
  %v930 = phi i64 [ %v619, %bb65 ]
  %v931 = phi i64 [ %v620, %bb65 ]
  %v932 = phi i1 [ %v621, %bb65 ]
  %v933 = phi ptr [ %v622, %bb65 ]
  %v934 = phi ptr [ %v623, %bb65 ]
  %v935 = phi ptr [ %v624, %bb65 ]
  %v936 = phi i64 [ %v625, %bb65 ]
  %v937 = phi i1 [ %v626, %bb65 ]
  %v938 = phi i1 [ %v627, %bb65 ]
  %v939 = phi i1 [ %v628, %bb65 ]
  %v940 = phi i1 [ %v629, %bb65 ]
  %v941 = phi i1 [ %v630, %bb65 ]
  %v942 = phi i64 [ %v563, %bb65 ]
  %v943 = phi i64 [ %v564, %bb65 ]
  %v944 = phi i64 [ %v565, %bb65 ]
  %v945 = select i1 true, i64 1, i64 1
  %v946 = add i64 %v944, %v945
  br label %bb58
bb93:
  %v947 = phi i64 [ %v141, %bb16 ]
  %v948 = phi i64 [ %v142, %bb16 ]
  %v949 = phi i64 [ %v143, %bb16 ]
  %v950 = phi i64 [ %v144, %bb16 ]
  %v951 = phi i64 [ %v145, %bb16 ]
  %v952 = phi i64 [ %v146, %bb16 ]
  %v953 = phi i64 [ %v147, %bb16 ]
  %v954 = phi i1 [ %v148, %bb16 ]
  %v955 = phi ptr [ %v149, %bb16 ]
  %v956 = phi ptr [ %v150, %bb16 ]
  %v957 = phi ptr [ %v151, %bb16 ]
  %v958 = phi i64 [ %v124, %bb16 ]
  %v959 = phi i64 [ %v125, %bb16 ]
  %v960 = phi i64 [ %v126, %bb16 ]
  %v961 = select i1 true, i64 1, i64 1
  %v962 = add i64 %v960, %v961
  br label %bb12
}

define i64 @wf_map_cost_library_geometry$instance$c7c8cd11e7f079bd(i64 %v0, i64 %v1, i64 %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.5591089753cba638, align 8
  %wf.slot.1 = alloca %wf.t.0a5f51efa7ad5b17, align 8
  %wf.slot.2 = alloca %wf.t.84597570beb237fa, align 8
  %v9 = alloca %wf.t.ee6ca7dc0a065510, align 8
  %v11 = alloca %wf.t.0a5f51efa7ad5b17, align 8
  %v16 = alloca %wf.t.84597570beb237fa, align 8
  %v3 = select i1 true, i64 11400714819323198485, i64 11400714819323198485
  %v4 = xor i64 %v2, %v3
  %v5 = select i1 true, i64 0, i64 0
  %v6 = select i1 true, i64 0, i64 0
  %v7 = icmp ne i64 %v5, %v6
  store %wf.t.ee6ca7dc0a065510 zeroinitializer, ptr %v9
  %t0 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v9, i32 0, i32 0
  store i64 %v4, ptr %t0
  %t1 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v9, i32 0, i32 1
  store i1 %v7, ptr %t1
  call void @wf_std.collections.hash_map.hash_map_new$instance$820b2044b97e0fbd(ptr %v11, i64 %v0)
  %v12 = select i1 true, i64 0, i64 0
  %v13 = select i1 true, i64 0, i64 0
  %v14 = select i1 true, i64 0, i64 0
  store %wf.t.84597570beb237fa zeroinitializer, ptr %v16
  %t2 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v16, i32 0, i32 0
  store i64 %v2, ptr %t2
  %t3 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v16, i32 0, i32 1
  store i64 %v12, ptr %t3
  %t4 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v16, i32 0, i32 2
  store i64 %v13, ptr %t4
  %t5 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v16, i32 0, i32 3
  store i64 %v14, ptr %t5
  %v17 = select i1 true, i64 0, i64 0
  br label %bb1
bb1:
  %v18 = phi i64 [ %v0, %entry ], [ %v43, %bb5 ]
  %v19 = phi i64 [ %v1, %entry ], [ %v44, %bb5 ]
  %v20 = phi i64 [ %v2, %entry ], [ %v45, %bb5 ]
  %v21 = phi i64 [ %v4, %entry ], [ %v46, %bb5 ]
  %v22 = phi i1 [ %v7, %entry ], [ %v47, %bb5 ]
  %v23 = phi ptr [ %v9, %entry ], [ %v48, %bb5 ]
  %v24 = phi ptr [ %v11, %entry ], [ %v49, %bb5 ]
  %v25 = phi ptr [ %v16, %entry ], [ %v50, %bb5 ]
  %v26 = phi i64 [ %v17, %entry ], [ %v51, %bb5 ]
  %v27 = phi i64 [ %v1, %entry ], [ %v52, %bb5 ]
  %v28 = phi i64 [ %v17, %entry ], [ %v55, %bb5 ]
  %v37 = icmp ult i64 %v28, %v27
  switch i1 %v37, label %invalid.tag.b1 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v38 = call i64 @wf_map_cost_key(i64 %v28)
  %v39 = add i64 %v20, %v28
  %v40 = call i64 @wf_map_cost_word_make(i64 %v39)
  call void @wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad(ptr %wf.slot.0, ptr %v24, i64 %v38, i64 %v40, ptr %v23)
  %v42 = call i8 @wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd(ptr %wf.slot.0, ptr %v25)
  br label %bb5
bb3:
  br label %bb4
bb4:
  %v29 = phi i64 [ %v18, %bb3 ]
  %v30 = phi i64 [ %v19, %bb3 ]
  %v31 = phi i64 [ %v20, %bb3 ]
  %v32 = phi i64 [ %v21, %bb3 ]
  %v33 = phi i1 [ %v22, %bb3 ]
  %v34 = phi ptr [ %v23, %bb3 ]
  %v35 = phi ptr [ %v24, %bb3 ]
  %v36 = phi ptr [ %v25, %bb3 ]
  %v56 = call i64 @wf_std.collections.hash_map.hash_map_capacity$instance$820b2044b97e0fbd(ptr %v35)
  %v57 = call i64 @wf_std.collections.hash_map.hash_map_len$instance$820b2044b97e0fbd(ptr %v35)
  %v58 = select i1 true, i64 4294967296, i64 4294967296
  %v59 = mul i64 %v56, %v58
  %v60 = add i64 %v59, %v57
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v35, i64 ptrtoint (ptr getelementptr (%wf.t.0a5f51efa7ad5b17, ptr null, i32 1) to i64), i1 false)
  %v62 = call i8 @wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19(ptr %wf.slot.1, ptr %v36)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %v36, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %v64 = call i64 @wf_map_cost_finish(ptr %wf.slot.2)
  %v65 = xor i64 %v64, %v60
  ret i64 %v65
bb5:
  %v43 = phi i64 [ %v18, %bb2 ]
  %v44 = phi i64 [ %v19, %bb2 ]
  %v45 = phi i64 [ %v20, %bb2 ]
  %v46 = phi i64 [ %v21, %bb2 ]
  %v47 = phi i1 [ %v22, %bb2 ]
  %v48 = phi ptr [ %v23, %bb2 ]
  %v49 = phi ptr [ %v24, %bb2 ]
  %v50 = phi ptr [ %v25, %bb2 ]
  %v51 = phi i64 [ %v26, %bb2 ]
  %v52 = phi i64 [ %v27, %bb2 ]
  %v53 = phi i64 [ %v28, %bb2 ]
  %v54 = select i1 true, i64 1, i64 1
  %v55 = add i64 %v53, %v54
  br label %bb1
}

define i64 @wf_map_cost_library_geometry$instance$4250cb78d3f44027(i64 %v0, i64 %v1, i64 %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.1 = alloca %wf.t.114ba5754d75c8d6, align 8
  %wf.slot.2 = alloca %wf.t.588b2641b8ac7d45, align 8
  %wf.slot.3 = alloca %wf.t.84597570beb237fa, align 8
  %v9 = alloca %wf.t.ee6ca7dc0a065510, align 8
  %v11 = alloca %wf.t.588b2641b8ac7d45, align 8
  %v16 = alloca %wf.t.84597570beb237fa, align 8
  %v3 = select i1 true, i64 11400714819323198485, i64 11400714819323198485
  %v4 = xor i64 %v2, %v3
  %v5 = select i1 true, i64 0, i64 0
  %v6 = select i1 true, i64 0, i64 0
  %v7 = icmp ne i64 %v5, %v6
  store %wf.t.ee6ca7dc0a065510 zeroinitializer, ptr %v9
  %t0 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v9, i32 0, i32 0
  store i64 %v4, ptr %t0
  %t1 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v9, i32 0, i32 1
  store i1 %v7, ptr %t1
  call void @wf_std.collections.hash_map.hash_map_new$instance$0e108827ecbbe374(ptr %v11, i64 %v0)
  %v12 = select i1 true, i64 0, i64 0
  %v13 = select i1 true, i64 0, i64 0
  %v14 = select i1 true, i64 0, i64 0
  store %wf.t.84597570beb237fa zeroinitializer, ptr %v16
  %t2 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v16, i32 0, i32 0
  store i64 %v2, ptr %t2
  %t3 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v16, i32 0, i32 1
  store i64 %v12, ptr %t3
  %t4 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v16, i32 0, i32 2
  store i64 %v13, ptr %t4
  %t5 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v16, i32 0, i32 3
  store i64 %v14, ptr %t5
  %v17 = select i1 true, i64 0, i64 0
  br label %bb1
bb1:
  %v18 = phi i64 [ %v0, %entry ], [ %v43, %bb5 ]
  %v19 = phi i64 [ %v1, %entry ], [ %v44, %bb5 ]
  %v20 = phi i64 [ %v2, %entry ], [ %v45, %bb5 ]
  %v21 = phi i64 [ %v4, %entry ], [ %v46, %bb5 ]
  %v22 = phi i1 [ %v7, %entry ], [ %v47, %bb5 ]
  %v23 = phi ptr [ %v9, %entry ], [ %v48, %bb5 ]
  %v24 = phi ptr [ %v11, %entry ], [ %v49, %bb5 ]
  %v25 = phi ptr [ %v16, %entry ], [ %v50, %bb5 ]
  %v26 = phi i64 [ %v17, %entry ], [ %v51, %bb5 ]
  %v27 = phi i64 [ %v1, %entry ], [ %v52, %bb5 ]
  %v28 = phi i64 [ %v17, %entry ], [ %v55, %bb5 ]
  %v37 = icmp ult i64 %v28, %v27
  switch i1 %v37, label %invalid.tag.b1 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v38 = call i64 @wf_map_cost_key(i64 %v28)
  %v39 = add i64 %v20, %v28
  call void @wf_map_cost_record_make(ptr %wf.slot.0, i64 %v39)
  call void @wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65(ptr %wf.slot.1, ptr %v24, i64 %v38, ptr %wf.slot.0, ptr %v23)
  %v42 = call i8 @wf_map_cost_library_policy_result$instance$4250cb78d3f44027(ptr %wf.slot.1, ptr %v25)
  br label %bb5
bb3:
  br label %bb4
bb4:
  %v29 = phi i64 [ %v18, %bb3 ]
  %v30 = phi i64 [ %v19, %bb3 ]
  %v31 = phi i64 [ %v20, %bb3 ]
  %v32 = phi i64 [ %v21, %bb3 ]
  %v33 = phi i1 [ %v22, %bb3 ]
  %v34 = phi ptr [ %v23, %bb3 ]
  %v35 = phi ptr [ %v24, %bb3 ]
  %v36 = phi ptr [ %v25, %bb3 ]
  %v56 = call i64 @wf_std.collections.hash_map.hash_map_capacity$instance$0e108827ecbbe374(ptr %v35)
  %v57 = call i64 @wf_std.collections.hash_map.hash_map_len$instance$0e108827ecbbe374(ptr %v35)
  %v58 = select i1 true, i64 4294967296, i64 4294967296
  %v59 = mul i64 %v56, %v58
  %v60 = add i64 %v59, %v57
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %v35, i64 ptrtoint (ptr getelementptr (%wf.t.588b2641b8ac7d45, ptr null, i32 1) to i64), i1 false)
  %v62 = call i8 @wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71(ptr %wf.slot.2, ptr %v36)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.3, ptr %v36, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %v64 = call i64 @wf_map_cost_finish(ptr %wf.slot.3)
  %v65 = xor i64 %v64, %v60
  ret i64 %v65
bb5:
  %v43 = phi i64 [ %v18, %bb2 ]
  %v44 = phi i64 [ %v19, %bb2 ]
  %v45 = phi i64 [ %v20, %bb2 ]
  %v46 = phi i64 [ %v21, %bb2 ]
  %v47 = phi i1 [ %v22, %bb2 ]
  %v48 = phi ptr [ %v23, %bb2 ]
  %v49 = phi ptr [ %v24, %bb2 ]
  %v50 = phi ptr [ %v25, %bb2 ]
  %v51 = phi i64 [ %v26, %bb2 ]
  %v52 = phi i64 [ %v27, %bb2 ]
  %v53 = phi i64 [ %v28, %bb2 ]
  %v54 = select i1 true, i64 1, i64 1
  %v55 = add i64 %v53, %v54
  br label %bb1
}

define void @wf_map_cost_lookup_prepare$instance$c7c8cd11e7f079bd(ptr %wf.result, i64 %v0, i64 %v1, i64 %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.5591089753cba638, align 8
  %wf.slot.1 = alloca %wf.t.0a5f51efa7ad5b17, align 8
  %wf.slot.2 = alloca %wf.t.ee6ca7dc0a065510, align 8
  %v9 = alloca %wf.t.ee6ca7dc0a065510, align 8
  %v11 = alloca %wf.t.0a5f51efa7ad5b17, align 8
  %v16 = alloca %wf.t.84597570beb237fa, align 8
  %v3 = select i1 true, i64 11400714819323198485, i64 11400714819323198485
  %v4 = xor i64 %v2, %v3
  %v5 = select i1 true, i64 0, i64 0
  %v6 = select i1 true, i64 0, i64 0
  %v7 = icmp ne i64 %v5, %v6
  store %wf.t.ee6ca7dc0a065510 zeroinitializer, ptr %v9
  %t0 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v9, i32 0, i32 0
  store i64 %v4, ptr %t0
  %t1 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v9, i32 0, i32 1
  store i1 %v7, ptr %t1
  call void @wf_std.collections.hash_map.hash_map_new$instance$820b2044b97e0fbd(ptr %v11, i64 %v0)
  %v12 = select i1 true, i64 0, i64 0
  %v13 = select i1 true, i64 0, i64 0
  %v14 = select i1 true, i64 0, i64 0
  store %wf.t.84597570beb237fa zeroinitializer, ptr %v16
  %t2 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v16, i32 0, i32 0
  store i64 %v2, ptr %t2
  %t3 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v16, i32 0, i32 1
  store i64 %v12, ptr %t3
  %t4 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v16, i32 0, i32 2
  store i64 %v13, ptr %t4
  %t5 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v16, i32 0, i32 3
  store i64 %v14, ptr %t5
  %v17 = select i1 true, i64 0, i64 0
  br label %bb1
bb1:
  %v18 = phi i64 [ %v0, %entry ], [ %v43, %bb5 ]
  %v19 = phi i64 [ %v1, %entry ], [ %v44, %bb5 ]
  %v20 = phi i64 [ %v2, %entry ], [ %v45, %bb5 ]
  %v21 = phi i64 [ %v4, %entry ], [ %v46, %bb5 ]
  %v22 = phi i1 [ %v7, %entry ], [ %v47, %bb5 ]
  %v23 = phi ptr [ %v9, %entry ], [ %v48, %bb5 ]
  %v24 = phi ptr [ %v11, %entry ], [ %v49, %bb5 ]
  %v25 = phi ptr [ %v16, %entry ], [ %v50, %bb5 ]
  %v26 = phi i64 [ %v17, %entry ], [ %v51, %bb5 ]
  %v27 = phi i64 [ %v1, %entry ], [ %v52, %bb5 ]
  %v28 = phi i64 [ %v17, %entry ], [ %v55, %bb5 ]
  %v37 = icmp ult i64 %v28, %v27
  switch i1 %v37, label %invalid.tag.b1 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v38 = call i64 @wf_map_cost_key(i64 %v28)
  %v39 = add i64 %v20, %v28
  %v40 = call i64 @wf_map_cost_word_make(i64 %v39)
  call void @wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad(ptr %wf.slot.0, ptr %v24, i64 %v38, i64 %v40, ptr %v23)
  %v42 = call i8 @wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd(ptr %wf.slot.0, ptr %v25)
  br label %bb5
bb3:
  br label %bb4
bb4:
  %v29 = phi i64 [ %v18, %bb3 ]
  %v30 = phi i64 [ %v19, %bb3 ]
  %v31 = phi i64 [ %v20, %bb3 ]
  %v32 = phi i64 [ %v21, %bb3 ]
  %v33 = phi i1 [ %v22, %bb3 ]
  %v34 = phi ptr [ %v23, %bb3 ]
  %v35 = phi ptr [ %v24, %bb3 ]
  %v36 = phi ptr [ %v25, %bb3 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v35, i64 ptrtoint (ptr getelementptr (%wf.t.0a5f51efa7ad5b17, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %v34, i64 ptrtoint (ptr getelementptr (%wf.t.ee6ca7dc0a065510, ptr null, i32 1) to i64), i1 false)
  store %wf.t.d684c580aa29d578 zeroinitializer, ptr %wf.result
  %t6 = getelementptr inbounds %wf.t.d684c580aa29d578, ptr %wf.result, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %t6, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr (%wf.t.0a5f51efa7ad5b17, ptr null, i32 1) to i64), i1 false)
  %t7 = getelementptr inbounds %wf.t.d684c580aa29d578, ptr %wf.result, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t7, ptr %wf.slot.2, i64 ptrtoint (ptr getelementptr (%wf.t.ee6ca7dc0a065510, ptr null, i32 1) to i64), i1 false)
  %t8 = getelementptr inbounds %wf.t.d684c580aa29d578, ptr %wf.result, i32 0, i32 2
  store i64 %v31, ptr %t8
  %t9 = getelementptr inbounds %wf.t.d684c580aa29d578, ptr %wf.result, i32 0, i32 3
  store i64 %v30, ptr %t9
  ret void
bb5:
  %v43 = phi i64 [ %v18, %bb2 ]
  %v44 = phi i64 [ %v19, %bb2 ]
  %v45 = phi i64 [ %v20, %bb2 ]
  %v46 = phi i64 [ %v21, %bb2 ]
  %v47 = phi i1 [ %v22, %bb2 ]
  %v48 = phi ptr [ %v23, %bb2 ]
  %v49 = phi ptr [ %v24, %bb2 ]
  %v50 = phi ptr [ %v25, %bb2 ]
  %v51 = phi i64 [ %v26, %bb2 ]
  %v52 = phi i64 [ %v27, %bb2 ]
  %v53 = phi i64 [ %v28, %bb2 ]
  %v54 = select i1 true, i64 1, i64 1
  %v55 = add i64 %v53, %v54
  br label %bb1
}

define void @wf_map_cost_lookup_prepare$instance$4250cb78d3f44027(ptr %wf.result, i64 %v0, i64 %v1, i64 %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.1 = alloca %wf.t.114ba5754d75c8d6, align 8
  %wf.slot.2 = alloca %wf.t.588b2641b8ac7d45, align 8
  %wf.slot.3 = alloca %wf.t.ee6ca7dc0a065510, align 8
  %v9 = alloca %wf.t.ee6ca7dc0a065510, align 8
  %v11 = alloca %wf.t.588b2641b8ac7d45, align 8
  %v16 = alloca %wf.t.84597570beb237fa, align 8
  %v3 = select i1 true, i64 11400714819323198485, i64 11400714819323198485
  %v4 = xor i64 %v2, %v3
  %v5 = select i1 true, i64 0, i64 0
  %v6 = select i1 true, i64 0, i64 0
  %v7 = icmp ne i64 %v5, %v6
  store %wf.t.ee6ca7dc0a065510 zeroinitializer, ptr %v9
  %t0 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v9, i32 0, i32 0
  store i64 %v4, ptr %t0
  %t1 = getelementptr inbounds %wf.t.ee6ca7dc0a065510, ptr %v9, i32 0, i32 1
  store i1 %v7, ptr %t1
  call void @wf_std.collections.hash_map.hash_map_new$instance$0e108827ecbbe374(ptr %v11, i64 %v0)
  %v12 = select i1 true, i64 0, i64 0
  %v13 = select i1 true, i64 0, i64 0
  %v14 = select i1 true, i64 0, i64 0
  store %wf.t.84597570beb237fa zeroinitializer, ptr %v16
  %t2 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v16, i32 0, i32 0
  store i64 %v2, ptr %t2
  %t3 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v16, i32 0, i32 1
  store i64 %v12, ptr %t3
  %t4 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v16, i32 0, i32 2
  store i64 %v13, ptr %t4
  %t5 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v16, i32 0, i32 3
  store i64 %v14, ptr %t5
  %v17 = select i1 true, i64 0, i64 0
  br label %bb1
bb1:
  %v18 = phi i64 [ %v0, %entry ], [ %v43, %bb5 ]
  %v19 = phi i64 [ %v1, %entry ], [ %v44, %bb5 ]
  %v20 = phi i64 [ %v2, %entry ], [ %v45, %bb5 ]
  %v21 = phi i64 [ %v4, %entry ], [ %v46, %bb5 ]
  %v22 = phi i1 [ %v7, %entry ], [ %v47, %bb5 ]
  %v23 = phi ptr [ %v9, %entry ], [ %v48, %bb5 ]
  %v24 = phi ptr [ %v11, %entry ], [ %v49, %bb5 ]
  %v25 = phi ptr [ %v16, %entry ], [ %v50, %bb5 ]
  %v26 = phi i64 [ %v17, %entry ], [ %v51, %bb5 ]
  %v27 = phi i64 [ %v1, %entry ], [ %v52, %bb5 ]
  %v28 = phi i64 [ %v17, %entry ], [ %v55, %bb5 ]
  %v37 = icmp ult i64 %v28, %v27
  switch i1 %v37, label %invalid.tag.b1 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v38 = call i64 @wf_map_cost_key(i64 %v28)
  %v39 = add i64 %v20, %v28
  call void @wf_map_cost_record_make(ptr %wf.slot.0, i64 %v39)
  call void @wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65(ptr %wf.slot.1, ptr %v24, i64 %v38, ptr %wf.slot.0, ptr %v23)
  %v42 = call i8 @wf_map_cost_library_policy_result$instance$4250cb78d3f44027(ptr %wf.slot.1, ptr %v25)
  br label %bb5
bb3:
  br label %bb4
bb4:
  %v29 = phi i64 [ %v18, %bb3 ]
  %v30 = phi i64 [ %v19, %bb3 ]
  %v31 = phi i64 [ %v20, %bb3 ]
  %v32 = phi i64 [ %v21, %bb3 ]
  %v33 = phi i1 [ %v22, %bb3 ]
  %v34 = phi ptr [ %v23, %bb3 ]
  %v35 = phi ptr [ %v24, %bb3 ]
  %v36 = phi ptr [ %v25, %bb3 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %v35, i64 ptrtoint (ptr getelementptr (%wf.t.588b2641b8ac7d45, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.3, ptr %v34, i64 ptrtoint (ptr getelementptr (%wf.t.ee6ca7dc0a065510, ptr null, i32 1) to i64), i1 false)
  store %wf.t.cec24d6ee3b08025 zeroinitializer, ptr %wf.result
  %t6 = getelementptr inbounds %wf.t.cec24d6ee3b08025, ptr %wf.result, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %t6, ptr %wf.slot.2, i64 ptrtoint (ptr getelementptr (%wf.t.588b2641b8ac7d45, ptr null, i32 1) to i64), i1 false)
  %t7 = getelementptr inbounds %wf.t.cec24d6ee3b08025, ptr %wf.result, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t7, ptr %wf.slot.3, i64 ptrtoint (ptr getelementptr (%wf.t.ee6ca7dc0a065510, ptr null, i32 1) to i64), i1 false)
  %t8 = getelementptr inbounds %wf.t.cec24d6ee3b08025, ptr %wf.result, i32 0, i32 2
  store i64 %v31, ptr %t8
  %t9 = getelementptr inbounds %wf.t.cec24d6ee3b08025, ptr %wf.result, i32 0, i32 3
  store i64 %v30, ptr %t9
  ret void
bb5:
  %v43 = phi i64 [ %v18, %bb2 ]
  %v44 = phi i64 [ %v19, %bb2 ]
  %v45 = phi i64 [ %v20, %bb2 ]
  %v46 = phi i64 [ %v21, %bb2 ]
  %v47 = phi i1 [ %v22, %bb2 ]
  %v48 = phi ptr [ %v23, %bb2 ]
  %v49 = phi ptr [ %v24, %bb2 ]
  %v50 = phi ptr [ %v25, %bb2 ]
  %v51 = phi i64 [ %v26, %bb2 ]
  %v52 = phi i64 [ %v27, %bb2 ]
  %v53 = phi i64 [ %v28, %bb2 ]
  %v54 = select i1 true, i64 1, i64 1
  %v55 = add i64 %v53, %v54
  br label %bb1
}

define i64 @wf_map_cost_lookup_query$instance$c7c8cd11e7f079bd(ptr noalias nonnull captures(none) dereferenceable(72) %v0, i64 %v1, i64 %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.d684c580aa29d578, align 8
  %wf.slot.1 = alloca %wf.t.d684c580aa29d578, align 8
  %wf.slot.2 = alloca %wf.t.b7e1ed626c09888a, align 8
  %wf.slot.3 = alloca %wf.t.84597570beb237fa, align 8
  %v9 = alloca %wf.t.84597570beb237fa, align 8
  %v56 = alloca i64, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.d684c580aa29d578, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.d684c580aa29d578, ptr %wf.slot.0, i32 0, i32 2
  %v4 = load i64, ptr %t0
  %v5 = select i1 true, i64 0, i64 0
  %v6 = select i1 true, i64 0, i64 0
  %v7 = select i1 true, i64 0, i64 0
  store %wf.t.84597570beb237fa zeroinitializer, ptr %v9
  %t1 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v9, i32 0, i32 0
  store i64 %v4, ptr %t1
  %t2 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v9, i32 0, i32 1
  store i64 %v5, ptr %t2
  %t3 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v9, i32 0, i32 2
  store i64 %v6, ptr %t3
  %t4 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v9, i32 0, i32 3
  store i64 %v7, ptr %t4
  %v10 = select i1 true, i64 0, i64 0
  %v11 = icmp ne i64 %v2, %v10
  switch i1 %v11, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v12 = phi i64 [ %v17, %bb2 ], [ %v18, %bb3 ]
  %v13 = phi ptr [ %v0, %bb2 ], [ %v0, %bb3 ]
  %v14 = phi i64 [ %v1, %bb2 ], [ %v1, %bb3 ]
  %v15 = phi i64 [ %v2, %bb2 ], [ %v2, %bb3 ]
  %v16 = phi ptr [ %v9, %bb2 ], [ %v9, %bb3 ]
  %v19 = select i1 true, i64 0, i64 0
  br label %bb4
bb2:
  %v17 = select i1 true, i64 2, i64 2
  br label %bb1
bb3:
  %v18 = select i1 true, i64 1, i64 1
  br label %bb1
bb4:
  %v20 = phi ptr [ %v13, %bb1 ], [ %v72, %bb13 ]
  %v21 = phi i64 [ %v14, %bb1 ], [ %v73, %bb13 ]
  %v22 = phi i64 [ %v15, %bb1 ], [ %v74, %bb13 ]
  %v23 = phi ptr [ %v16, %bb1 ], [ %v75, %bb13 ]
  %v24 = phi i64 [ %v12, %bb1 ], [ %v76, %bb13 ]
  %v25 = phi i64 [ %v19, %bb1 ], [ %v77, %bb13 ]
  %v26 = phi i64 [ %v14, %bb1 ], [ %v78, %bb13 ]
  %v27 = phi i64 [ %v19, %bb1 ], [ %v81, %bb13 ]
  %v33 = icmp ult i64 %v27, %v26
  switch i1 %v33, label %invalid.tag.b4 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b4:
  unreachable
bb5:
  %v34 = select i1 true, i64 0, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v20, i64 ptrtoint (ptr getelementptr (%wf.t.d684c580aa29d578, ptr null, i32 1) to i64), i1 false)
  %t5 = getelementptr inbounds %wf.t.d684c580aa29d578, ptr %wf.slot.1, i32 0, i32 3
  %v36 = load i64, ptr %t5
  br label %bb8
bb6:
  br label %bb7
bb7:
  %v28 = phi ptr [ %v20, %bb6 ]
  %v29 = phi i64 [ %v21, %bb6 ]
  %v30 = phi i64 [ %v22, %bb6 ]
  %v31 = phi ptr [ %v23, %bb6 ]
  %v32 = phi i64 [ %v24, %bb6 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.3, ptr %v31, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %v83 = call i64 @wf_map_cost_finish(ptr %wf.slot.3)
  ret i64 %v83
bb8:
  %v37 = phi ptr [ %v20, %bb5 ], [ %v61, %bb12 ]
  %v38 = phi i64 [ %v21, %bb5 ], [ %v62, %bb12 ]
  %v39 = phi i64 [ %v22, %bb5 ], [ %v63, %bb12 ]
  %v40 = phi ptr [ %v23, %bb5 ], [ %v64, %bb12 ]
  %v41 = phi i64 [ %v24, %bb5 ], [ %v65, %bb12 ]
  %v42 = phi i64 [ %v27, %bb5 ], [ %v66, %bb12 ]
  %v43 = phi i64 [ %v34, %bb5 ], [ %v67, %bb12 ]
  %v44 = phi i64 [ %v36, %bb5 ], [ %v68, %bb12 ]
  %v45 = phi i64 [ %v34, %bb5 ], [ %v71, %bb12 ]
  %v52 = icmp ult i64 %v45, %v44
  switch i1 %v52, label %invalid.tag.b8 [
    i1 1, label %bb9
    i1 0, label %bb10
  ]
invalid.tag.b8:
  unreachable
bb9:
  %v53 = select i1 true, i64 2, i64 2
  %v54 = mul i64 %v45, %v53
  %v55 = add i64 %v54, %v41
  store i64 %v55, ptr %v56
  %t6 = getelementptr inbounds %wf.t.d684c580aa29d578, ptr %v37, i32 0, i32 0
  %v57 = getelementptr i8, ptr %t6, i64 0
  %t7 = getelementptr inbounds %wf.t.d684c580aa29d578, ptr %v37, i32 0, i32 1
  %v58 = getelementptr i8, ptr %t7, i64 0
  %v59 = call %wf.t.b7e1ed626c09888a @wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50(ptr %v57, ptr %v56, ptr %v58, ptr %v40)
  store %wf.t.b7e1ed626c09888a %v59, ptr %wf.slot.2
  %v60 = call i8 @wf_map_cost_lookup_result(ptr %wf.slot.2, ptr %v40)
  br label %bb12
bb10:
  br label %bb11
bb11:
  %v46 = phi ptr [ %v37, %bb10 ]
  %v47 = phi i64 [ %v38, %bb10 ]
  %v48 = phi i64 [ %v39, %bb10 ]
  %v49 = phi ptr [ %v40, %bb10 ]
  %v50 = phi i64 [ %v41, %bb10 ]
  %v51 = phi i64 [ %v42, %bb10 ]
  br label %bb13
bb12:
  %v61 = phi ptr [ %v37, %bb9 ]
  %v62 = phi i64 [ %v38, %bb9 ]
  %v63 = phi i64 [ %v39, %bb9 ]
  %v64 = phi ptr [ %v40, %bb9 ]
  %v65 = phi i64 [ %v41, %bb9 ]
  %v66 = phi i64 [ %v42, %bb9 ]
  %v67 = phi i64 [ %v43, %bb9 ]
  %v68 = phi i64 [ %v44, %bb9 ]
  %v69 = phi i64 [ %v45, %bb9 ]
  %v70 = select i1 true, i64 1, i64 1
  %v71 = add i64 %v69, %v70
  br label %bb8
bb13:
  %v72 = phi ptr [ %v46, %bb11 ]
  %v73 = phi i64 [ %v47, %bb11 ]
  %v74 = phi i64 [ %v48, %bb11 ]
  %v75 = phi ptr [ %v49, %bb11 ]
  %v76 = phi i64 [ %v50, %bb11 ]
  %v77 = phi i64 [ %v25, %bb11 ]
  %v78 = phi i64 [ %v26, %bb11 ]
  %v79 = phi i64 [ %v27, %bb11 ]
  %v80 = select i1 true, i64 1, i64 1
  %v81 = add i64 %v79, %v80
  br label %bb4
}

define i64 @wf_map_cost_lookup_query$instance$4250cb78d3f44027(ptr noalias nonnull captures(none) dereferenceable(72) %v0, i64 %v1, i64 %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.cec24d6ee3b08025, align 8
  %wf.slot.1 = alloca %wf.t.cec24d6ee3b08025, align 8
  %wf.slot.2 = alloca %wf.t.b7e1ed626c09888a, align 8
  %wf.slot.3 = alloca %wf.t.84597570beb237fa, align 8
  %v9 = alloca %wf.t.84597570beb237fa, align 8
  %v56 = alloca i64, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.cec24d6ee3b08025, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.cec24d6ee3b08025, ptr %wf.slot.0, i32 0, i32 2
  %v4 = load i64, ptr %t0
  %v5 = select i1 true, i64 0, i64 0
  %v6 = select i1 true, i64 0, i64 0
  %v7 = select i1 true, i64 0, i64 0
  store %wf.t.84597570beb237fa zeroinitializer, ptr %v9
  %t1 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v9, i32 0, i32 0
  store i64 %v4, ptr %t1
  %t2 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v9, i32 0, i32 1
  store i64 %v5, ptr %t2
  %t3 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v9, i32 0, i32 2
  store i64 %v6, ptr %t3
  %t4 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v9, i32 0, i32 3
  store i64 %v7, ptr %t4
  %v10 = select i1 true, i64 0, i64 0
  %v11 = icmp ne i64 %v2, %v10
  switch i1 %v11, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v12 = phi i64 [ %v17, %bb2 ], [ %v18, %bb3 ]
  %v13 = phi ptr [ %v0, %bb2 ], [ %v0, %bb3 ]
  %v14 = phi i64 [ %v1, %bb2 ], [ %v1, %bb3 ]
  %v15 = phi i64 [ %v2, %bb2 ], [ %v2, %bb3 ]
  %v16 = phi ptr [ %v9, %bb2 ], [ %v9, %bb3 ]
  %v19 = select i1 true, i64 0, i64 0
  br label %bb4
bb2:
  %v17 = select i1 true, i64 2, i64 2
  br label %bb1
bb3:
  %v18 = select i1 true, i64 1, i64 1
  br label %bb1
bb4:
  %v20 = phi ptr [ %v13, %bb1 ], [ %v72, %bb13 ]
  %v21 = phi i64 [ %v14, %bb1 ], [ %v73, %bb13 ]
  %v22 = phi i64 [ %v15, %bb1 ], [ %v74, %bb13 ]
  %v23 = phi ptr [ %v16, %bb1 ], [ %v75, %bb13 ]
  %v24 = phi i64 [ %v12, %bb1 ], [ %v76, %bb13 ]
  %v25 = phi i64 [ %v19, %bb1 ], [ %v77, %bb13 ]
  %v26 = phi i64 [ %v14, %bb1 ], [ %v78, %bb13 ]
  %v27 = phi i64 [ %v19, %bb1 ], [ %v81, %bb13 ]
  %v33 = icmp ult i64 %v27, %v26
  switch i1 %v33, label %invalid.tag.b4 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b4:
  unreachable
bb5:
  %v34 = select i1 true, i64 0, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v20, i64 ptrtoint (ptr getelementptr (%wf.t.cec24d6ee3b08025, ptr null, i32 1) to i64), i1 false)
  %t5 = getelementptr inbounds %wf.t.cec24d6ee3b08025, ptr %wf.slot.1, i32 0, i32 3
  %v36 = load i64, ptr %t5
  br label %bb8
bb6:
  br label %bb7
bb7:
  %v28 = phi ptr [ %v20, %bb6 ]
  %v29 = phi i64 [ %v21, %bb6 ]
  %v30 = phi i64 [ %v22, %bb6 ]
  %v31 = phi ptr [ %v23, %bb6 ]
  %v32 = phi i64 [ %v24, %bb6 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.3, ptr %v31, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %v83 = call i64 @wf_map_cost_finish(ptr %wf.slot.3)
  ret i64 %v83
bb8:
  %v37 = phi ptr [ %v20, %bb5 ], [ %v61, %bb12 ]
  %v38 = phi i64 [ %v21, %bb5 ], [ %v62, %bb12 ]
  %v39 = phi i64 [ %v22, %bb5 ], [ %v63, %bb12 ]
  %v40 = phi ptr [ %v23, %bb5 ], [ %v64, %bb12 ]
  %v41 = phi i64 [ %v24, %bb5 ], [ %v65, %bb12 ]
  %v42 = phi i64 [ %v27, %bb5 ], [ %v66, %bb12 ]
  %v43 = phi i64 [ %v34, %bb5 ], [ %v67, %bb12 ]
  %v44 = phi i64 [ %v36, %bb5 ], [ %v68, %bb12 ]
  %v45 = phi i64 [ %v34, %bb5 ], [ %v71, %bb12 ]
  %v52 = icmp ult i64 %v45, %v44
  switch i1 %v52, label %invalid.tag.b8 [
    i1 1, label %bb9
    i1 0, label %bb10
  ]
invalid.tag.b8:
  unreachable
bb9:
  %v53 = select i1 true, i64 2, i64 2
  %v54 = mul i64 %v45, %v53
  %v55 = add i64 %v54, %v41
  store i64 %v55, ptr %v56
  %t6 = getelementptr inbounds %wf.t.cec24d6ee3b08025, ptr %v37, i32 0, i32 0
  %v57 = getelementptr i8, ptr %t6, i64 0
  %t7 = getelementptr inbounds %wf.t.cec24d6ee3b08025, ptr %v37, i32 0, i32 1
  %v58 = getelementptr i8, ptr %t7, i64 0
  %v59 = call %wf.t.b7e1ed626c09888a @wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe(ptr %v57, ptr %v56, ptr %v58, ptr %v40)
  store %wf.t.b7e1ed626c09888a %v59, ptr %wf.slot.2
  %v60 = call i8 @wf_map_cost_lookup_result(ptr %wf.slot.2, ptr %v40)
  br label %bb12
bb10:
  br label %bb11
bb11:
  %v46 = phi ptr [ %v37, %bb10 ]
  %v47 = phi i64 [ %v38, %bb10 ]
  %v48 = phi i64 [ %v39, %bb10 ]
  %v49 = phi ptr [ %v40, %bb10 ]
  %v50 = phi i64 [ %v41, %bb10 ]
  %v51 = phi i64 [ %v42, %bb10 ]
  br label %bb13
bb12:
  %v61 = phi ptr [ %v37, %bb9 ]
  %v62 = phi i64 [ %v38, %bb9 ]
  %v63 = phi i64 [ %v39, %bb9 ]
  %v64 = phi ptr [ %v40, %bb9 ]
  %v65 = phi i64 [ %v41, %bb9 ]
  %v66 = phi i64 [ %v42, %bb9 ]
  %v67 = phi i64 [ %v43, %bb9 ]
  %v68 = phi i64 [ %v44, %bb9 ]
  %v69 = phi i64 [ %v45, %bb9 ]
  %v70 = select i1 true, i64 1, i64 1
  %v71 = add i64 %v69, %v70
  br label %bb8
bb13:
  %v72 = phi ptr [ %v46, %bb11 ]
  %v73 = phi i64 [ %v47, %bb11 ]
  %v74 = phi i64 [ %v48, %bb11 ]
  %v75 = phi ptr [ %v49, %bb11 ]
  %v76 = phi i64 [ %v50, %bb11 ]
  %v77 = phi i64 [ %v25, %bb11 ]
  %v78 = phi i64 [ %v26, %bb11 ]
  %v79 = phi i64 [ %v27, %bb11 ]
  %v80 = select i1 true, i64 1, i64 1
  %v81 = add i64 %v79, %v80
  br label %bb4
}

define i64 @wf_map_cost_lookup_geometry$instance$e194368921a477a7(ptr noalias nonnull captures(none) dereferenceable(72) %v0) #0 {
entry:
  %t0 = getelementptr inbounds %wf.t.d684c580aa29d578, ptr %v0, i32 0, i32 0
  %v1 = getelementptr i8, ptr %t0, i64 0
  %v2 = call i64 @wf_std.collections.hash_map.hash_map_capacity$instance$820b2044b97e0fbd(ptr %v1)
  %t1 = getelementptr inbounds %wf.t.d684c580aa29d578, ptr %v0, i32 0, i32 0
  %v3 = getelementptr i8, ptr %t1, i64 0
  %v4 = call i64 @wf_std.collections.hash_map.hash_map_len$instance$820b2044b97e0fbd(ptr %v3)
  %v5 = select i1 true, i64 4294967296, i64 4294967296
  %v6 = mul i64 %v2, %v5
  %v7 = add i64 %v6, %v4
  ret i64 %v7
}

define i64 @wf_map_cost_lookup_geometry$instance$9fed7d4c5d7cc122(ptr noalias nonnull captures(none) dereferenceable(72) %v0) #0 {
entry:
  %t0 = getelementptr inbounds %wf.t.cec24d6ee3b08025, ptr %v0, i32 0, i32 0
  %v1 = getelementptr i8, ptr %t0, i64 0
  %v2 = call i64 @wf_std.collections.hash_map.hash_map_capacity$instance$0e108827ecbbe374(ptr %v1)
  %t1 = getelementptr inbounds %wf.t.cec24d6ee3b08025, ptr %v0, i32 0, i32 0
  %v3 = getelementptr i8, ptr %t1, i64 0
  %v4 = call i64 @wf_std.collections.hash_map.hash_map_len$instance$0e108827ecbbe374(ptr %v3)
  %v5 = select i1 true, i64 4294967296, i64 4294967296
  %v6 = mul i64 %v2, %v5
  %v7 = add i64 %v6, %v4
  ret i64 %v7
}

define i64 @wf_map_cost_lookup_finish$instance$c7c8cd11e7f079bd(ptr %wf.arg.v0) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.d684c580aa29d578, align 8
  %wf.slot.1 = alloca %wf.t.0a5f51efa7ad5b17, align 8
  %wf.slot.2 = alloca %wf.t.ee6ca7dc0a065510, align 8
  %wf.slot.3 = alloca %wf.t.84597570beb237fa, align 8
  %v9 = alloca %wf.t.84597570beb237fa, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v0, i64 ptrtoint (ptr getelementptr (%wf.t.d684c580aa29d578, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.d684c580aa29d578, ptr %wf.slot.0, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %t0, i64 ptrtoint (ptr getelementptr (%wf.t.0a5f51efa7ad5b17, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %t1 = getelementptr inbounds %wf.t.d684c580aa29d578, ptr %wf.slot.0, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %t1, i64 ptrtoint (ptr getelementptr (%wf.t.ee6ca7dc0a065510, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %t2 = getelementptr inbounds %wf.t.d684c580aa29d578, ptr %wf.slot.0, i32 0, i32 2
  %v3 = load i64, ptr %t2
  ; ownership-consuming projection
  %t3 = getelementptr inbounds %wf.t.d684c580aa29d578, ptr %wf.slot.0, i32 0, i32 3
  %v4 = load i64, ptr %t3
  ; ownership-consuming projection
  %v5 = select i1 true, i64 0, i64 0
  %v6 = select i1 true, i64 0, i64 0
  %v7 = select i1 true, i64 0, i64 0
  store %wf.t.84597570beb237fa zeroinitializer, ptr %v9
  %t4 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v9, i32 0, i32 0
  store i64 %v3, ptr %t4
  %t5 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v9, i32 0, i32 1
  store i64 %v5, ptr %t5
  %t6 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v9, i32 0, i32 2
  store i64 %v6, ptr %t6
  %t7 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v9, i32 0, i32 3
  store i64 %v7, ptr %t7
  %v10 = call i8 @wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19(ptr %wf.slot.1, ptr %v9)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.3, ptr %v9, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %v12 = call i64 @wf_map_cost_finish(ptr %wf.slot.3)
  ret i64 %v12
}

define i64 @wf_map_cost_lookup_finish$instance$4250cb78d3f44027(ptr %wf.arg.v0) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.cec24d6ee3b08025, align 8
  %wf.slot.1 = alloca %wf.t.588b2641b8ac7d45, align 8
  %wf.slot.2 = alloca %wf.t.ee6ca7dc0a065510, align 8
  %wf.slot.3 = alloca %wf.t.84597570beb237fa, align 8
  %v9 = alloca %wf.t.84597570beb237fa, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v0, i64 ptrtoint (ptr getelementptr (%wf.t.cec24d6ee3b08025, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.cec24d6ee3b08025, ptr %wf.slot.0, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %t0, i64 ptrtoint (ptr getelementptr (%wf.t.588b2641b8ac7d45, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %t1 = getelementptr inbounds %wf.t.cec24d6ee3b08025, ptr %wf.slot.0, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %t1, i64 ptrtoint (ptr getelementptr (%wf.t.ee6ca7dc0a065510, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %t2 = getelementptr inbounds %wf.t.cec24d6ee3b08025, ptr %wf.slot.0, i32 0, i32 2
  %v3 = load i64, ptr %t2
  ; ownership-consuming projection
  %t3 = getelementptr inbounds %wf.t.cec24d6ee3b08025, ptr %wf.slot.0, i32 0, i32 3
  %v4 = load i64, ptr %t3
  ; ownership-consuming projection
  %v5 = select i1 true, i64 0, i64 0
  %v6 = select i1 true, i64 0, i64 0
  %v7 = select i1 true, i64 0, i64 0
  store %wf.t.84597570beb237fa zeroinitializer, ptr %v9
  %t4 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v9, i32 0, i32 0
  store i64 %v3, ptr %t4
  %t5 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v9, i32 0, i32 1
  store i64 %v5, ptr %t5
  %t6 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v9, i32 0, i32 2
  store i64 %v6, ptr %t6
  %t7 = getelementptr inbounds %wf.t.84597570beb237fa, ptr %v9, i32 0, i32 3
  store i64 %v7, ptr %t7
  %v10 = call i8 @wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71(ptr %wf.slot.1, ptr %v9)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.3, ptr %v9, i64 ptrtoint (ptr getelementptr (%wf.t.84597570beb237fa, ptr null, i32 1) to i64), i1 false)
  %v12 = call i64 @wf_map_cost_finish(ptr %wf.slot.3)
  ret i64 %v12
}

define void @wf_std.collections.hash_map.hash_map_new$instance$a62a753cf2b0b5ca(ptr %wf.result, i64 %v0) #0 {
entry:
  %wf.slot.0 = alloca { i64, i64, ptr }, align 8
  %v2 = alloca { i64, i64, ptr }, align 8
  %v1 = call { i64, i64, ptr } @wf_box_slots_new$instance$b45b69d9d0c6bbd0(i64 %v0)
  store { i64, i64, ptr } %v1, ptr %v2
  %v3 = call i8 @wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca(ptr %v2, i64 %v0)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v2, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  %v5 = select i1 true, i64 0, i64 0
  %v6 = select i1 true, i64 0, i64 0
  store %wf.t.fe1d7d6862eac796 zeroinitializer, ptr %wf.result
  %t0 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %wf.result, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %t0, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  %t1 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %wf.result, i32 0, i32 1
  store i64 %v5, ptr %t1
  %t2 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %wf.result, i32 0, i32 2
  store i64 %v6, ptr %t2
  ret void
}

define void @wf_std.collections.hash_map.hash_map_put$instance$c7b22b9ef52855b6(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, i64 %v2, ptr noalias nonnull captures(none) dereferenceable(16) %v3) #0 {
entry:
  %wf.frame = alloca { %wf.t.fe1d7d6862eac796, %wf.t.fe1d7d6862eac796, %wf.t.fe1d7d6862eac796, %wf.t.7d7f918f7b4962fd }, align 8
  %wf.slot.0 = getelementptr inbounds { %wf.t.fe1d7d6862eac796, %wf.t.fe1d7d6862eac796, %wf.t.fe1d7d6862eac796, %wf.t.7d7f918f7b4962fd }, ptr %wf.frame, i32 0, i32 0
  %wf.slot.1 = getelementptr inbounds { %wf.t.fe1d7d6862eac796, %wf.t.fe1d7d6862eac796, %wf.t.fe1d7d6862eac796, %wf.t.7d7f918f7b4962fd }, ptr %wf.frame, i32 0, i32 1
  %wf.slot.2 = getelementptr inbounds { %wf.t.fe1d7d6862eac796, %wf.t.fe1d7d6862eac796, %wf.t.fe1d7d6862eac796, %wf.t.7d7f918f7b4962fd }, ptr %wf.frame, i32 0, i32 2
  %wf.slot.3 = getelementptr inbounds { %wf.t.fe1d7d6862eac796, %wf.t.fe1d7d6862eac796, %wf.t.fe1d7d6862eac796, %wf.t.7d7f918f7b4962fd }, ptr %wf.frame, i32 0, i32 3
  %t0 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %v0, i32 0, i32 0
  %v4 = getelementptr i8, ptr %t0, i64 0
  %v5 = getelementptr i8, ptr %v4, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v5, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v6 = add i64 %t1, 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.fe1d7d6862eac796, ptr null, i32 1) to i64), i1 false)
  %t3 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %wf.slot.0, i32 0, i32 1
  %v8 = load i64, ptr %t3
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.fe1d7d6862eac796, ptr null, i32 1) to i64), i1 false)
  %t4 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %wf.slot.1, i32 0, i32 2
  %v10 = load i64, ptr %t4
  %v11 = call i64 @llvm.uadd.sat.i64(i64 %v8, i64 %v10)
  %v12 = select i1 true, i64 4, i64 4
  %v13 = udiv i64 %v6, %v12
  %v14 = sub nuw i64 %v6, %v13
  %v15 = icmp uge i64 %v11, %v14
  %v16 = select i1 true, i64 3, i64 3
  %v17 = icmp ult i64 %v6, %v16
  %v18 = and i1 %v15, %v17
  switch i1 %v18, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v19 = phi ptr [ %v0, %bb3 ], [ %v36, %bb4 ]
  %v20 = phi i64 [ %v1, %bb3 ], [ %v37, %bb4 ]
  %v21 = phi i64 [ %v2, %bb3 ], [ %v38, %bb4 ]
  %v22 = phi ptr [ %v3, %bb3 ], [ %v39, %bb4 ]
  %v23 = phi i64 [ %v6, %bb3 ], [ %v40, %bb4 ]
  %v24 = phi i64 [ %v11, %bb3 ], [ %v41, %bb4 ]
  %v25 = phi i64 [ %v13, %bb3 ], [ %v42, %bb4 ]
  %v26 = phi i64 [ %v14, %bb3 ], [ %v43, %bb4 ]
  %v27 = phi i1 [ %v15, %bb3 ], [ %v44, %bb4 ]
  %v28 = phi i1 [ %v17, %bb3 ], [ %v45, %bb4 ]
  %v29 = phi i1 [ %v18, %bb3 ], [ %v46, %bb4 ]
  call void @wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6(ptr %wf.result, ptr %v19, i64 %v20, i64 %v21, ptr %v22)
  ret void
bb2:
  %v30 = select i1 true, i64 3, i64 3
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.fe1d7d6862eac796, ptr null, i32 1) to i64), i1 false)
  %t5 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %wf.slot.2, i32 0, i32 1
  %v32 = load i64, ptr %t5
  %v33 = select i1 true, i64 2, i64 2
  %v34 = udiv i64 %v14, %v33
  %v35 = icmp ult i64 %v32, %v34
  switch i1 %v35, label %invalid.tag.b2 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b2:
  unreachable
bb3:
  br label %bb1
bb4:
  %v36 = phi ptr [ %v0, %bb5 ], [ %v52, %bb7 ]
  %v37 = phi i64 [ %v1, %bb5 ], [ %v53, %bb7 ]
  %v38 = phi i64 [ %v2, %bb5 ], [ %v54, %bb7 ]
  %v39 = phi ptr [ %v3, %bb5 ], [ %v55, %bb7 ]
  %v40 = phi i64 [ %v6, %bb5 ], [ %v56, %bb7 ]
  %v41 = phi i64 [ %v11, %bb5 ], [ %v57, %bb7 ]
  %v42 = phi i64 [ %v13, %bb5 ], [ %v58, %bb7 ]
  %v43 = phi i64 [ %v14, %bb5 ], [ %v59, %bb7 ]
  %v44 = phi i1 [ %v15, %bb5 ], [ %v60, %bb7 ]
  %v45 = phi i1 [ %v17, %bb5 ], [ %v61, %bb7 ]
  %v46 = phi i1 [ %v18, %bb5 ], [ %v62, %bb7 ]
  %v47 = phi i64 [ %v6, %bb5 ], [ %v63, %bb7 ]
  %v48 = phi i64 [ %v32, %bb5 ], [ %v64, %bb7 ]
  %v49 = phi i64 [ %v34, %bb5 ], [ %v65, %bb7 ]
  %v101 = call %wf.t.7d7f918f7b4962fd @wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6(ptr %v36, i64 %v47, ptr %v39)
  store %wf.t.7d7f918f7b4962fd %v101, ptr %wf.slot.3
  br label %bb1
bb5:
  br label %bb4
bb6:
  %v50 = select i1 true, i64 0, i64 0
  %v51 = icmp eq i64 %v6, %v50
  switch i1 %v51, label %invalid.tag.b6 [
    i1 1, label %bb8
    i1 0, label %bb9
  ]
invalid.tag.b6:
  unreachable
bb7:
  %v52 = phi ptr [ %v0, %bb8 ], [ %v69, %bb10 ]
  %v53 = phi i64 [ %v1, %bb8 ], [ %v70, %bb10 ]
  %v54 = phi i64 [ %v2, %bb8 ], [ %v71, %bb10 ]
  %v55 = phi ptr [ %v3, %bb8 ], [ %v72, %bb10 ]
  %v56 = phi i64 [ %v6, %bb8 ], [ %v73, %bb10 ]
  %v57 = phi i64 [ %v11, %bb8 ], [ %v74, %bb10 ]
  %v58 = phi i64 [ %v13, %bb8 ], [ %v75, %bb10 ]
  %v59 = phi i64 [ %v14, %bb8 ], [ %v76, %bb10 ]
  %v60 = phi i1 [ %v15, %bb8 ], [ %v77, %bb10 ]
  %v61 = phi i1 [ %v17, %bb8 ], [ %v78, %bb10 ]
  %v62 = phi i1 [ %v18, %bb8 ], [ %v79, %bb10 ]
  %v63 = phi i64 [ %v66, %bb8 ], [ %v80, %bb10 ]
  %v64 = phi i64 [ %v32, %bb8 ], [ %v81, %bb10 ]
  %v65 = phi i64 [ %v34, %bb8 ], [ %v82, %bb10 ]
  br label %bb4
bb8:
  %v66 = select i1 true, i64 1, i64 1
  br label %bb7
bb9:
  %v67 = select i1 true, i64 9223372036854775807, i64 9223372036854775807
  %v68 = icmp ule i64 %v6, %v67
  switch i1 %v68, label %invalid.tag.b9 [
    i1 1, label %bb11
    i1 0, label %bb12
  ]
invalid.tag.b9:
  unreachable
bb10:
  %v69 = phi ptr [ %v0, %bb12 ], [ %v86, %bb13 ]
  %v70 = phi i64 [ %v1, %bb12 ], [ %v87, %bb13 ]
  %v71 = phi i64 [ %v2, %bb12 ], [ %v88, %bb13 ]
  %v72 = phi ptr [ %v3, %bb12 ], [ %v89, %bb13 ]
  %v73 = phi i64 [ %v6, %bb12 ], [ %v90, %bb13 ]
  %v74 = phi i64 [ %v11, %bb12 ], [ %v91, %bb13 ]
  %v75 = phi i64 [ %v13, %bb12 ], [ %v92, %bb13 ]
  %v76 = phi i64 [ %v14, %bb12 ], [ %v93, %bb13 ]
  %v77 = phi i1 [ %v15, %bb12 ], [ %v94, %bb13 ]
  %v78 = phi i1 [ %v17, %bb12 ], [ %v95, %bb13 ]
  %v79 = phi i1 [ %v18, %bb12 ], [ %v96, %bb13 ]
  %v80 = phi i64 [ %v30, %bb12 ], [ %v97, %bb13 ]
  %v81 = phi i64 [ %v32, %bb12 ], [ %v98, %bb13 ]
  %v82 = phi i64 [ %v34, %bb12 ], [ %v99, %bb13 ]
  br label %bb7
bb11:
  %v83 = add nuw i64 %v6, %v6
  %v84 = select i1 true, i64 3, i64 3
  %v85 = icmp ule i64 %v83, %v84
  switch i1 %v85, label %invalid.tag.b11 [
    i1 1, label %bb14
    i1 0, label %bb15
  ]
invalid.tag.b11:
  unreachable
bb12:
  br label %bb10
bb13:
  %v86 = phi ptr [ %v0, %bb14 ], [ %v0, %bb15 ]
  %v87 = phi i64 [ %v1, %bb14 ], [ %v1, %bb15 ]
  %v88 = phi i64 [ %v2, %bb14 ], [ %v2, %bb15 ]
  %v89 = phi ptr [ %v3, %bb14 ], [ %v3, %bb15 ]
  %v90 = phi i64 [ %v6, %bb14 ], [ %v6, %bb15 ]
  %v91 = phi i64 [ %v11, %bb14 ], [ %v11, %bb15 ]
  %v92 = phi i64 [ %v13, %bb14 ], [ %v13, %bb15 ]
  %v93 = phi i64 [ %v14, %bb14 ], [ %v14, %bb15 ]
  %v94 = phi i1 [ %v15, %bb14 ], [ %v15, %bb15 ]
  %v95 = phi i1 [ %v17, %bb14 ], [ %v17, %bb15 ]
  %v96 = phi i1 [ %v18, %bb14 ], [ %v18, %bb15 ]
  %v97 = phi i64 [ %v83, %bb14 ], [ %v30, %bb15 ]
  %v98 = phi i64 [ %v32, %bb14 ], [ %v32, %bb15 ]
  %v99 = phi i64 [ %v34, %bb14 ], [ %v34, %bb15 ]
  %v100 = phi i64 [ %v83, %bb14 ], [ %v83, %bb15 ]
  br label %bb10
bb14:
  br label %bb13
bb15:
  br label %bb13
}

define i8 @wf_map_cost_library_policy_result$instance$c7c8cd11e7f079bd(ptr %wf.arg.v0, ptr noalias nonnull captures(none) dereferenceable(32) %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.5591089753cba638, align 8
  %wf.slot.1 = alloca %wf.t.c5066f96ffdbc504, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v0, i64 ptrtoint (ptr getelementptr (%wf.t.5591089753cba638, ptr null, i32 1) to i64), i1 false)
  %t0 = load %wf.t.5591089753cba638, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.5591089753cba638 %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb2
    i32 1, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v3 = phi ptr [ %v1, %bb2 ], [ %v9, %bb4 ]
  %v20 = select i1 true, i8 0, i8 0
  ret i8 %v20
bb2:
  %v4 = select i1 true, i64 0, i64 0
  %v5 = call i8 @wf_map_cost_ordered(ptr %v1, i64 %v4)
  br label %bb1
bb3:
  %t2 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.slot.0, i32 0, i32 1
  %v6 = load i1, ptr %t2
  %t3 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.slot.0, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %t3, i64 ptrtoint (ptr getelementptr (%wf.t.c5066f96ffdbc504, ptr null, i32 1) to i64), i1 false)
  switch i1 %v6, label %invalid.tag.b3 [
    i1 0, label %bb5
    i1 1, label %bb6
  ]
invalid.tag.b3:
  unreachable
bb4:
  %v9 = phi ptr [ %v1, %bb5 ], [ %v1, %bb6 ]
  %v10 = phi i1 [ %v6, %bb5 ], [ %v6, %bb6 ]
  %t4 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.1, i32 0, i32 0
  %v16 = load i64, ptr %t4
  ; ownership-consuming projection
  %t5 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.1, i32 0, i32 1
  %v17 = load i64, ptr %t5
  ; ownership-consuming projection
  %v18 = call i64 @wf_map_cost_word_content(i64 %v16, i64 %v17)
  %v19 = call i8 @wf_map_cost_ordered(ptr %v9, i64 %v18)
  br label %bb1
bb5:
  %v12 = select i1 true, i64 1, i64 1
  %v13 = call i8 @wf_map_cost_ordered(ptr %v1, i64 %v12)
  br label %bb4
bb6:
  %v14 = select i1 true, i64 2, i64 2
  %v15 = call i8 @wf_map_cost_ordered(ptr %v1, i64 %v14)
  br label %bb4
}

define i8 @wf_std.collections.hash_map.hash_map_free$instance$5c6f40d0925a4760(ptr %wf.arg.v0, ptr noalias nonnull captures(none) dereferenceable(32) %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.fe1d7d6862eac796, align 8
  %wf.slot.1 = alloca %wf.t.a1df460b0959673f, align 8
  %wf.slot.2 = alloca { i64, i64, ptr }, align 8
  %v3 = alloca { i64, i64, ptr }, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v0, i64 ptrtoint (ptr getelementptr (%wf.t.fe1d7d6862eac796, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %wf.slot.0, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %v3, ptr %t0, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %t1 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %wf.slot.0, i32 0, i32 1
  %v4 = load i64, ptr %t1
  ; ownership-consuming projection
  %t2 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %wf.slot.0, i32 0, i32 2
  %v5 = load i64, ptr %t2
  ; ownership-consuming projection
  br label %bb1
bb1:
  %v7 = phi ptr [ %v1, %entry ], [ %v28, %bb6 ]
  %v8 = phi ptr [ %v3, %entry ], [ %v29, %bb6 ]
  %v9 = phi i64 [ %v4, %entry ], [ %v30, %bb6 ]
  %v10 = phi i64 [ %v5, %entry ], [ %v31, %bb6 ]
  %v16 = getelementptr i8, ptr %v8, i64 0
  %t4 = getelementptr inbounds { i64, i64, ptr }, ptr %v16, i32 0, i32 0
  %t3 = load i64, ptr %t4
  %v17 = add i64 %t3, 0
  %v18 = select i1 true, i64 0, i64 0
  %v19 = icmp eq i64 %v17, %v18
  switch i1 %v19, label %invalid.tag.b1 [
    i1 1, label %bb4
    i1 0, label %bb5
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v12 = phi ptr [ %v7, %bb4 ]
  %v13 = phi ptr [ %v8, %bb4 ]
  %v14 = phi i64 [ %v9, %bb4 ]
  %v15 = phi i64 [ %v10, %bb4 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %v13, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  %v37 = call i8 @wf_free_empty$instance$43608765810d87c7(ptr %wf.slot.2)
  %v38 = select i1 true, i8 0, i8 0
  ret i8 %v38
bb3:
  %v21 = phi ptr [ %v7, %bb5 ]
  %v22 = phi ptr [ %v8, %bb5 ]
  %v23 = phi i64 [ %v9, %bb5 ]
  %v24 = phi i64 [ %v10, %bb5 ]
  %v25 = getelementptr i8, ptr %v22, i64 0
  %v26 = call %wf.t.a1df460b0959673f @wf_take_back$instance$9985a87b1cb96650(ptr %v25)
  store %wf.t.a1df460b0959673f %v26, ptr %wf.slot.1
  %t5 = load %wf.t.a1df460b0959673f, ptr %wf.slot.1
  %t6 = extractvalue %wf.t.a1df460b0959673f %t5, 0
  switch i32 %t6, label %invalid.tag.b3 [
    i32 2, label %bb7
    i32 0, label %bb8
    i32 1, label %bb9
  ]
invalid.tag.b3:
  unreachable
bb4:
  br label %bb2
bb5:
  br label %bb3
bb6:
  %v28 = phi ptr [ %v21, %bb7 ], [ %v21, %bb8 ], [ %v21, %bb9 ]
  %v29 = phi ptr [ %v22, %bb7 ], [ %v22, %bb8 ], [ %v22, %bb9 ]
  %v30 = phi i64 [ %v23, %bb7 ], [ %v23, %bb8 ], [ %v23, %bb9 ]
  %v31 = phi i64 [ %v24, %bb7 ], [ %v24, %bb8 ], [ %v24, %bb9 ]
  br label %bb1
bb7:
  %t7 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %wf.slot.1, i32 0, i32 1
  %v33 = load i64, ptr %t7
  %t8 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %wf.slot.1, i32 0, i32 2
  %v34 = load i64, ptr %t8
  %v35 = call i8 @wf_map_cost_word_consume(ptr %v21, i64 %v33, i64 %v34)
  br label %bb6
bb8:
  br label %bb6
bb9:
  br label %bb6
}

define void @wf_std.collections.hash_map.hash_map_new$instance$820b2044b97e0fbd(ptr %wf.result, i64 %v0) #0 {
entry:
  %wf.slot.0 = alloca { i64, i64, ptr }, align 8
  %v2 = alloca { i64, i64, ptr }, align 8
  %v1 = call { i64, i64, ptr } @wf_box_slots_new$instance$b45b69d9d0c6bbd0(i64 %v0)
  store { i64, i64, ptr } %v1, ptr %v2
  %v3 = call i8 @wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd(ptr %v2, i64 %v0)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v2, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  %v5 = select i1 true, i64 0, i64 0
  %v6 = select i1 true, i64 0, i64 0
  store %wf.t.0a5f51efa7ad5b17 zeroinitializer, ptr %wf.result
  %t0 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %wf.result, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %t0, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  %t1 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %wf.result, i32 0, i32 1
  store i64 %v5, ptr %t1
  %t2 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %wf.result, i32 0, i32 2
  store i64 %v6, ptr %t2
  ret void
}

define void @wf_std.collections.hash_map.hash_map_put$instance$fde7c6722a8b0dad(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, i64 %v2, ptr noalias nonnull captures(none) dereferenceable(16) %v3) #0 {
entry:
  %wf.frame = alloca { %wf.t.0a5f51efa7ad5b17, %wf.t.0a5f51efa7ad5b17, %wf.t.0a5f51efa7ad5b17, %wf.t.7d7f918f7b4962fd }, align 8
  %wf.slot.0 = getelementptr inbounds { %wf.t.0a5f51efa7ad5b17, %wf.t.0a5f51efa7ad5b17, %wf.t.0a5f51efa7ad5b17, %wf.t.7d7f918f7b4962fd }, ptr %wf.frame, i32 0, i32 0
  %wf.slot.1 = getelementptr inbounds { %wf.t.0a5f51efa7ad5b17, %wf.t.0a5f51efa7ad5b17, %wf.t.0a5f51efa7ad5b17, %wf.t.7d7f918f7b4962fd }, ptr %wf.frame, i32 0, i32 1
  %wf.slot.2 = getelementptr inbounds { %wf.t.0a5f51efa7ad5b17, %wf.t.0a5f51efa7ad5b17, %wf.t.0a5f51efa7ad5b17, %wf.t.7d7f918f7b4962fd }, ptr %wf.frame, i32 0, i32 2
  %wf.slot.3 = getelementptr inbounds { %wf.t.0a5f51efa7ad5b17, %wf.t.0a5f51efa7ad5b17, %wf.t.0a5f51efa7ad5b17, %wf.t.7d7f918f7b4962fd }, ptr %wf.frame, i32 0, i32 3
  %t0 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v0, i32 0, i32 0
  %v4 = getelementptr i8, ptr %t0, i64 0
  %v5 = getelementptr i8, ptr %v4, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v5, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v6 = add i64 %t1, 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.0a5f51efa7ad5b17, ptr null, i32 1) to i64), i1 false)
  %t3 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %wf.slot.0, i32 0, i32 1
  %v8 = load i64, ptr %t3
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.0a5f51efa7ad5b17, ptr null, i32 1) to i64), i1 false)
  %t4 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %wf.slot.1, i32 0, i32 2
  %v10 = load i64, ptr %t4
  %v11 = call i64 @llvm.uadd.sat.i64(i64 %v8, i64 %v10)
  %v12 = select i1 true, i64 4, i64 4
  %v13 = udiv i64 %v6, %v12
  %v14 = sub nuw i64 %v6, %v13
  %v15 = icmp uge i64 %v11, %v14
  %v16 = select i1 true, i64 16384, i64 16384
  %v17 = icmp ult i64 %v6, %v16
  %v18 = and i1 %v15, %v17
  switch i1 %v18, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v19 = phi ptr [ %v0, %bb3 ], [ %v36, %bb4 ]
  %v20 = phi i64 [ %v1, %bb3 ], [ %v37, %bb4 ]
  %v21 = phi i64 [ %v2, %bb3 ], [ %v38, %bb4 ]
  %v22 = phi ptr [ %v3, %bb3 ], [ %v39, %bb4 ]
  %v23 = phi i64 [ %v6, %bb3 ], [ %v40, %bb4 ]
  %v24 = phi i64 [ %v11, %bb3 ], [ %v41, %bb4 ]
  %v25 = phi i64 [ %v13, %bb3 ], [ %v42, %bb4 ]
  %v26 = phi i64 [ %v14, %bb3 ], [ %v43, %bb4 ]
  %v27 = phi i1 [ %v15, %bb3 ], [ %v44, %bb4 ]
  %v28 = phi i1 [ %v17, %bb3 ], [ %v45, %bb4 ]
  %v29 = phi i1 [ %v18, %bb3 ], [ %v46, %bb4 ]
  call void @wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad(ptr %wf.result, ptr %v19, i64 %v20, i64 %v21, ptr %v22)
  ret void
bb2:
  %v30 = select i1 true, i64 16384, i64 16384
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.0a5f51efa7ad5b17, ptr null, i32 1) to i64), i1 false)
  %t5 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %wf.slot.2, i32 0, i32 1
  %v32 = load i64, ptr %t5
  %v33 = select i1 true, i64 2, i64 2
  %v34 = udiv i64 %v14, %v33
  %v35 = icmp ult i64 %v32, %v34
  switch i1 %v35, label %invalid.tag.b2 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b2:
  unreachable
bb3:
  br label %bb1
bb4:
  %v36 = phi ptr [ %v0, %bb5 ], [ %v52, %bb7 ]
  %v37 = phi i64 [ %v1, %bb5 ], [ %v53, %bb7 ]
  %v38 = phi i64 [ %v2, %bb5 ], [ %v54, %bb7 ]
  %v39 = phi ptr [ %v3, %bb5 ], [ %v55, %bb7 ]
  %v40 = phi i64 [ %v6, %bb5 ], [ %v56, %bb7 ]
  %v41 = phi i64 [ %v11, %bb5 ], [ %v57, %bb7 ]
  %v42 = phi i64 [ %v13, %bb5 ], [ %v58, %bb7 ]
  %v43 = phi i64 [ %v14, %bb5 ], [ %v59, %bb7 ]
  %v44 = phi i1 [ %v15, %bb5 ], [ %v60, %bb7 ]
  %v45 = phi i1 [ %v17, %bb5 ], [ %v61, %bb7 ]
  %v46 = phi i1 [ %v18, %bb5 ], [ %v62, %bb7 ]
  %v47 = phi i64 [ %v6, %bb5 ], [ %v63, %bb7 ]
  %v48 = phi i64 [ %v32, %bb5 ], [ %v64, %bb7 ]
  %v49 = phi i64 [ %v34, %bb5 ], [ %v65, %bb7 ]
  %v101 = call %wf.t.7d7f918f7b4962fd @wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad(ptr %v36, i64 %v47, ptr %v39)
  store %wf.t.7d7f918f7b4962fd %v101, ptr %wf.slot.3
  br label %bb1
bb5:
  br label %bb4
bb6:
  %v50 = select i1 true, i64 0, i64 0
  %v51 = icmp eq i64 %v6, %v50
  switch i1 %v51, label %invalid.tag.b6 [
    i1 1, label %bb8
    i1 0, label %bb9
  ]
invalid.tag.b6:
  unreachable
bb7:
  %v52 = phi ptr [ %v0, %bb8 ], [ %v69, %bb10 ]
  %v53 = phi i64 [ %v1, %bb8 ], [ %v70, %bb10 ]
  %v54 = phi i64 [ %v2, %bb8 ], [ %v71, %bb10 ]
  %v55 = phi ptr [ %v3, %bb8 ], [ %v72, %bb10 ]
  %v56 = phi i64 [ %v6, %bb8 ], [ %v73, %bb10 ]
  %v57 = phi i64 [ %v11, %bb8 ], [ %v74, %bb10 ]
  %v58 = phi i64 [ %v13, %bb8 ], [ %v75, %bb10 ]
  %v59 = phi i64 [ %v14, %bb8 ], [ %v76, %bb10 ]
  %v60 = phi i1 [ %v15, %bb8 ], [ %v77, %bb10 ]
  %v61 = phi i1 [ %v17, %bb8 ], [ %v78, %bb10 ]
  %v62 = phi i1 [ %v18, %bb8 ], [ %v79, %bb10 ]
  %v63 = phi i64 [ %v66, %bb8 ], [ %v80, %bb10 ]
  %v64 = phi i64 [ %v32, %bb8 ], [ %v81, %bb10 ]
  %v65 = phi i64 [ %v34, %bb8 ], [ %v82, %bb10 ]
  br label %bb4
bb8:
  %v66 = select i1 true, i64 1, i64 1
  br label %bb7
bb9:
  %v67 = select i1 true, i64 9223372036854775807, i64 9223372036854775807
  %v68 = icmp ule i64 %v6, %v67
  switch i1 %v68, label %invalid.tag.b9 [
    i1 1, label %bb11
    i1 0, label %bb12
  ]
invalid.tag.b9:
  unreachable
bb10:
  %v69 = phi ptr [ %v0, %bb12 ], [ %v86, %bb13 ]
  %v70 = phi i64 [ %v1, %bb12 ], [ %v87, %bb13 ]
  %v71 = phi i64 [ %v2, %bb12 ], [ %v88, %bb13 ]
  %v72 = phi ptr [ %v3, %bb12 ], [ %v89, %bb13 ]
  %v73 = phi i64 [ %v6, %bb12 ], [ %v90, %bb13 ]
  %v74 = phi i64 [ %v11, %bb12 ], [ %v91, %bb13 ]
  %v75 = phi i64 [ %v13, %bb12 ], [ %v92, %bb13 ]
  %v76 = phi i64 [ %v14, %bb12 ], [ %v93, %bb13 ]
  %v77 = phi i1 [ %v15, %bb12 ], [ %v94, %bb13 ]
  %v78 = phi i1 [ %v17, %bb12 ], [ %v95, %bb13 ]
  %v79 = phi i1 [ %v18, %bb12 ], [ %v96, %bb13 ]
  %v80 = phi i64 [ %v30, %bb12 ], [ %v97, %bb13 ]
  %v81 = phi i64 [ %v32, %bb12 ], [ %v98, %bb13 ]
  %v82 = phi i64 [ %v34, %bb12 ], [ %v99, %bb13 ]
  br label %bb7
bb11:
  %v83 = add nuw i64 %v6, %v6
  %v84 = select i1 true, i64 16384, i64 16384
  %v85 = icmp ule i64 %v83, %v84
  switch i1 %v85, label %invalid.tag.b11 [
    i1 1, label %bb14
    i1 0, label %bb15
  ]
invalid.tag.b11:
  unreachable
bb12:
  br label %bb10
bb13:
  %v86 = phi ptr [ %v0, %bb14 ], [ %v0, %bb15 ]
  %v87 = phi i64 [ %v1, %bb14 ], [ %v1, %bb15 ]
  %v88 = phi i64 [ %v2, %bb14 ], [ %v2, %bb15 ]
  %v89 = phi ptr [ %v3, %bb14 ], [ %v3, %bb15 ]
  %v90 = phi i64 [ %v6, %bb14 ], [ %v6, %bb15 ]
  %v91 = phi i64 [ %v11, %bb14 ], [ %v11, %bb15 ]
  %v92 = phi i64 [ %v13, %bb14 ], [ %v13, %bb15 ]
  %v93 = phi i64 [ %v14, %bb14 ], [ %v14, %bb15 ]
  %v94 = phi i1 [ %v15, %bb14 ], [ %v15, %bb15 ]
  %v95 = phi i1 [ %v17, %bb14 ], [ %v17, %bb15 ]
  %v96 = phi i1 [ %v18, %bb14 ], [ %v18, %bb15 ]
  %v97 = phi i64 [ %v83, %bb14 ], [ %v30, %bb15 ]
  %v98 = phi i64 [ %v32, %bb14 ], [ %v32, %bb15 ]
  %v99 = phi i64 [ %v34, %bb14 ], [ %v34, %bb15 ]
  %v100 = phi i64 [ %v83, %bb14 ], [ %v83, %bb15 ]
  br label %bb10
bb14:
  br label %bb13
bb15:
  br label %bb13
}

define internal void @wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.0a5f51efa7ad5b17, align 8
  %wf.slot.1 = alloca %wf.t.b7e1ed626c09888a, align 8
  %wf.slot.2 = alloca %wf.t.a1df460b0959673f, align 8
  %wf.slot.3 = alloca %wf.t.0a5f51efa7ad5b17, align 8
  %wf.slot.4 = alloca %wf.t.c5066f96ffdbc504, align 8
  %v15 = alloca %wf.t.a1df460b0959673f, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.0a5f51efa7ad5b17, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %wf.slot.0, i32 0, i32 1
  %v4 = load i64, ptr %t0
  %v5 = select i1 true, i64 0, i64 0
  %v6 = icmp eq i64 %v4, %v5
  switch i1 %v6, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v7 = phi ptr [ %v0, %bb3 ]
  %v8 = phi ptr [ %v1, %bb3 ]
  %v9 = phi ptr [ %v2, %bb3 ]
  %v10 = phi i64 [ %v4, %bb3 ]
  %v12 = call %wf.t.b7e1ed626c09888a @wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad(ptr %v7, ptr %v8, ptr %v9)
  store %wf.t.b7e1ed626c09888a %v12, ptr %wf.slot.1
  %t1 = load %wf.t.b7e1ed626c09888a, ptr %wf.slot.1
  %t2 = extractvalue %wf.t.b7e1ed626c09888a %t1, 0
  switch i32 %t2, label %invalid.tag.b1 [
    i32 0, label %bb4
    i32 1, label %bb5
  ]
invalid.tag.b1:
  unreachable
bb2:
  store %wf.t.84dc23e49b76868c zeroinitializer, ptr %wf.result
  %t3 = getelementptr inbounds %wf.t.84dc23e49b76868c, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t3
  ret void
bb3:
  br label %bb1
bb4:
  %t4 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.slot.1, i32 0, i32 1
  %v13 = load i64, ptr %t4
  store %wf.t.a1df460b0959673f zeroinitializer, ptr %v15
  %t5 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %v15, i32 0, i32 0
  store i32 1, ptr %t5
  %t6 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v7, i32 0, i32 0
  %v16 = getelementptr i8, ptr %t6, i64 0
  %v17 = getelementptr i8, ptr %v16, i64 0
  %t8 = getelementptr inbounds { i64, i64, ptr }, ptr %v17, i32 0, i32 2
  %t9 = load ptr, ptr %t8
  %t7.nonnegative = icmp sge i64 %v13, 0
  call void @llvm.assume(i1 %t7.nonnegative)
  %t7 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %t9, i64 %v13
  %v18 = getelementptr i8, ptr %t7, i64 0
  %v19 = call i8 @wf_swap$instance$b45b69d9d0c6bbd0(ptr %v18, ptr %v15)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %v15, i64 ptrtoint (ptr getelementptr (%wf.t.a1df460b0959673f, ptr null, i32 1) to i64), i1 false)
  %t10 = load %wf.t.a1df460b0959673f, ptr %wf.slot.2
  %t11 = extractvalue %wf.t.a1df460b0959673f %t10, 0
  switch i32 %t11, label %invalid.tag.b4 [
    i32 2, label %bb6
    i32 0, label %bb7
    i32 1, label %bb8
  ]
invalid.tag.b4:
  unreachable
bb5:
  %t12 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.slot.1, i32 0, i32 2
  %v35 = load i8, ptr %t12
  store %wf.t.84dc23e49b76868c zeroinitializer, ptr %wf.result
  %t13 = getelementptr inbounds %wf.t.84dc23e49b76868c, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t13
  ret void
bb6:
  %t14 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %wf.slot.2, i32 0, i32 1
  %v21 = load i64, ptr %t14
  %t15 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %wf.slot.2, i32 0, i32 2
  %v22 = load i64, ptr %t15
  %t16 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v7, i32 0, i32 1
  %v23 = getelementptr i8, ptr %t16, i64 0
  %v24 = select i1 true, i64 1, i64 1
  %v25 = sub nuw i64 %v10, %v24
  store i64 %v25, ptr %v23
  %t17 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v7, i32 0, i32 2
  %v26 = getelementptr i8, ptr %t17, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.3, ptr %v7, i64 ptrtoint (ptr getelementptr (%wf.t.0a5f51efa7ad5b17, ptr null, i32 1) to i64), i1 false)
  %t18 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %wf.slot.3, i32 0, i32 2
  %v28 = load i64, ptr %t18
  %v29 = select i1 true, i64 1, i64 1
  %v30 = call i64 @llvm.uadd.sat.i64(i64 %v28, i64 %v29)
  store i64 %v30, ptr %v26
  store %wf.t.c5066f96ffdbc504 zeroinitializer, ptr %wf.slot.4
  %t19 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.4, i32 0, i32 0
  store i64 %v21, ptr %t19
  %t20 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.4, i32 0, i32 1
  store i64 %v22, ptr %t20
  store %wf.t.84dc23e49b76868c zeroinitializer, ptr %wf.result
  %t21 = getelementptr inbounds %wf.t.84dc23e49b76868c, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t21
  %t22 = getelementptr inbounds %wf.t.84dc23e49b76868c, ptr %wf.result, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t22, ptr %wf.slot.4, i64 ptrtoint (ptr getelementptr (%wf.t.c5066f96ffdbc504, ptr null, i32 1) to i64), i1 false)
  ret void
bb7:
  store %wf.t.84dc23e49b76868c zeroinitializer, ptr %wf.result
  %t23 = getelementptr inbounds %wf.t.84dc23e49b76868c, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t23
  ret void
bb8:
  store %wf.t.84dc23e49b76868c zeroinitializer, ptr %wf.result
  %t24 = getelementptr inbounds %wf.t.84dc23e49b76868c, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t24
  ret void
}

define %wf.t.84dc23e49b76868c @wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad(ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.result = alloca %wf.t.84dc23e49b76868c, align 8
  call void @wf_std.collections.hash_map.hash_map_remove$instance$fde7c6722a8b0dad.body(ptr %wf.result, ptr %v0, ptr %v1, ptr %v2)
  %wf.returned = load %wf.t.84dc23e49b76868c, ptr %wf.result
  ret %wf.t.84dc23e49b76868c %wf.returned
}

define internal void @wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2, ptr noalias nonnull captures(none) dereferenceable(32) %v3) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.a1df460b0959673f, align 8
  %v4 = call i64 @wf_map_cost_hash(ptr %v2, ptr %v1)
  %t0 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v0, i32 0, i32 0
  %v5 = getelementptr i8, ptr %t0, i64 0
  %v6 = getelementptr i8, ptr %v5, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v6, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v7 = add i64 %t1, 0
  %v8 = select i1 true, i64 0, i64 0
  %v9 = icmp eq i64 %v7, %v8
  switch i1 %v9, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v10 = phi ptr [ %v0, %bb3 ]
  %v11 = phi ptr [ %v1, %bb3 ]
  %v12 = phi ptr [ %v2, %bb3 ]
  %v13 = phi ptr [ %v3, %bb3 ]
  %v14 = phi i64 [ %v4, %bb3 ]
  %v15 = phi i64 [ %v7, %bb3 ]
  %v18 = urem i64 %v14, %v15
  %v19 = select i1 true, i64 0, i64 0
  br label %bb4
bb2:
  %v16 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t3 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t3
  %t4 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v16, ptr %t4
  ret void
bb3:
  br label %bb1
bb4:
  %v20 = phi ptr [ %v10, %bb1 ], [ %v84, %bb18 ]
  %v21 = phi ptr [ %v11, %bb1 ], [ %v85, %bb18 ]
  %v22 = phi ptr [ %v12, %bb1 ], [ %v86, %bb18 ]
  %v23 = phi ptr [ %v13, %bb1 ], [ %v87, %bb18 ]
  %v24 = phi i64 [ %v14, %bb1 ], [ %v88, %bb18 ]
  %v25 = phi i64 [ %v15, %bb1 ], [ %v89, %bb18 ]
  %v26 = phi i64 [ %v18, %bb1 ], [ %v90, %bb18 ]
  %v27 = phi i64 [ %v19, %bb1 ], [ %v91, %bb18 ]
  %v28 = phi i64 [ %v15, %bb1 ], [ %v92, %bb18 ]
  %v29 = phi i64 [ %v19, %bb1 ], [ %v95, %bb18 ]
  %v37 = icmp ult i64 %v29, %v28
  switch i1 %v37, label %invalid.tag.b4 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b4:
  unreachable
bb5:
  %t5 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v20, i32 0, i32 0
  %v38 = getelementptr i8, ptr %t5, i64 0
  %v39 = getelementptr i8, ptr %v38, i64 0
  %t7 = getelementptr inbounds { i64, i64, ptr }, ptr %v39, i32 0, i32 2
  %t8 = load ptr, ptr %t7
  %t6.nonnegative = icmp sge i64 %v26, 0
  call void @llvm.assume(i1 %t6.nonnegative)
  %t6 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %t8, i64 %v26
  %v40 = getelementptr i8, ptr %t6, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v40, i64 ptrtoint (ptr getelementptr (%wf.t.a1df460b0959673f, ptr null, i32 1) to i64), i1 false)
  %t9 = load %wf.t.a1df460b0959673f, ptr %wf.slot.0
  %t10 = extractvalue %wf.t.a1df460b0959673f %t9, 0
  switch i32 %t10, label %invalid.tag.b5 [
    i32 2, label %bb9
    i32 0, label %bb10
    i32 1, label %bb11
  ]
invalid.tag.b5:
  unreachable
bb6:
  br label %bb7
bb7:
  %v30 = phi ptr [ %v20, %bb6 ]
  %v31 = phi ptr [ %v21, %bb6 ]
  %v32 = phi ptr [ %v22, %bb6 ]
  %v33 = phi ptr [ %v23, %bb6 ]
  %v34 = phi i64 [ %v24, %bb6 ]
  %v35 = phi i64 [ %v25, %bb6 ]
  %v36 = phi i64 [ %v26, %bb6 ]
  %v96 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t11 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t11
  %t12 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v96, ptr %t12
  ret void
bb8:
  %v42 = phi ptr [ %v20, %bb11 ], [ %v54, %bb12 ]
  %v43 = phi ptr [ %v21, %bb11 ], [ %v55, %bb12 ]
  %v44 = phi ptr [ %v22, %bb11 ], [ %v56, %bb12 ]
  %v45 = phi ptr [ %v23, %bb11 ], [ %v57, %bb12 ]
  %v46 = phi i64 [ %v24, %bb11 ], [ %v58, %bb12 ]
  %v47 = phi i64 [ %v25, %bb11 ], [ %v59, %bb12 ]
  %v48 = phi i64 [ %v26, %bb11 ], [ %v60, %bb12 ]
  %v49 = phi i64 [ %v29, %bb11 ], [ %v61, %bb12 ]
  %v50 = phi ptr [ %v40, %bb11 ], [ %v62, %bb12 ]
  %v70 = select i1 true, i64 1, i64 1
  %v71 = add nuw i64 %v48, %v70
  %v72 = icmp ult i64 %v71, %v47
  switch i1 %v72, label %invalid.tag.b8 [
    i1 1, label %bb16
    i1 0, label %bb17
  ]
invalid.tag.b8:
  unreachable
bb9:
  %t13 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %v40, i32 0, i32 1
  %v51 = getelementptr i8, ptr %t13, i64 0
  %t14 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %v40, i32 0, i32 2
  %v52 = getelementptr i8, ptr %t14, i64 0
  %v53 = call i1 @wf_map_cost_equal(ptr %v22, ptr %v51, ptr %v21)
  switch i1 %v53, label %invalid.tag.b9 [
    i1 1, label %bb13
    i1 0, label %bb14
  ]
invalid.tag.b9:
  unreachable
bb10:
  %v68 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t15 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t15
  %t16 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v68, ptr %t16
  ret void
bb11:
  br label %bb8
bb12:
  %v54 = phi ptr [ %v20, %bb14 ]
  %v55 = phi ptr [ %v21, %bb14 ]
  %v56 = phi ptr [ %v22, %bb14 ]
  %v57 = phi ptr [ %v23, %bb14 ]
  %v58 = phi i64 [ %v24, %bb14 ]
  %v59 = phi i64 [ %v25, %bb14 ]
  %v60 = phi i64 [ %v26, %bb14 ]
  %v61 = phi i64 [ %v29, %bb14 ]
  %v62 = phi ptr [ %v40, %bb14 ]
  %v63 = phi ptr [ %v51, %bb14 ]
  %v64 = phi ptr [ %v52, %bb14 ]
  %v65 = phi i1 [ %v53, %bb14 ]
  br label %bb8
bb13:
  %v66 = call i64 @wf_map_cost_word_observe(ptr %v23, ptr %v51, ptr %v52)
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t17 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t17
  %t18 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 1
  store i64 %v66, ptr %t18
  ret void
bb14:
  br label %bb12
bb15:
  %v73 = phi ptr [ %v42, %bb16 ], [ %v42, %bb17 ]
  %v74 = phi ptr [ %v43, %bb16 ], [ %v43, %bb17 ]
  %v75 = phi ptr [ %v44, %bb16 ], [ %v44, %bb17 ]
  %v76 = phi ptr [ %v45, %bb16 ], [ %v45, %bb17 ]
  %v77 = phi i64 [ %v46, %bb16 ], [ %v46, %bb17 ]
  %v78 = phi i64 [ %v47, %bb16 ], [ %v47, %bb17 ]
  %v79 = phi i64 [ %v71, %bb16 ], [ %v83, %bb17 ]
  %v80 = phi i64 [ %v49, %bb16 ], [ %v49, %bb17 ]
  %v81 = phi ptr [ %v50, %bb16 ], [ %v50, %bb17 ]
  %v82 = phi i64 [ %v71, %bb16 ], [ %v71, %bb17 ]
  br label %bb18
bb16:
  br label %bb15
bb17:
  %v83 = select i1 true, i64 0, i64 0
  br label %bb15
bb18:
  %v84 = phi ptr [ %v73, %bb15 ]
  %v85 = phi ptr [ %v74, %bb15 ]
  %v86 = phi ptr [ %v75, %bb15 ]
  %v87 = phi ptr [ %v76, %bb15 ]
  %v88 = phi i64 [ %v77, %bb15 ]
  %v89 = phi i64 [ %v78, %bb15 ]
  %v90 = phi i64 [ %v79, %bb15 ]
  %v91 = phi i64 [ %v27, %bb15 ]
  %v92 = phi i64 [ %v28, %bb15 ]
  %v93 = phi i64 [ %v29, %bb15 ]
  %v94 = select i1 true, i64 1, i64 1
  %v95 = add i64 %v93, %v94
  br label %bb4
}

define %wf.t.b7e1ed626c09888a @wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50(ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2, ptr noalias nonnull captures(none) dereferenceable(32) %v3) #0 {
entry:
  %wf.result = alloca %wf.t.b7e1ed626c09888a, align 8
  call void @wf_std.collections.hash_map.hash_map_lookup$instance$7bc36e4a3b19cd50.body(ptr %wf.result, ptr %v0, ptr %v1, ptr %v2, ptr %v3)
  %wf.returned = load %wf.t.b7e1ed626c09888a, ptr %wf.result
  ret %wf.t.b7e1ed626c09888a %wf.returned
}

define internal void @wf_std.collections.hash_map.hash_map_rehash$instance$fde7c6722a8b0dad.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(16) %v1) #0 {
entry:
  %t0 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v0, i32 0, i32 0
  %v2 = getelementptr i8, ptr %t0, i64 0
  %v3 = getelementptr i8, ptr %v2, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v3, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v4 = add i64 %t1, 0
  %v5 = call %wf.t.7d7f918f7b4962fd @wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad(ptr %v0, i64 %v4, ptr %v1)
  store %wf.t.7d7f918f7b4962fd %v5, ptr %wf.result
  ret void
}

define %wf.t.7d7f918f7b4962fd @wf_std.collections.hash_map.hash_map_rehash$instance$fde7c6722a8b0dad(ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(16) %v1) #0 {
entry:
  %wf.result = alloca %wf.t.7d7f918f7b4962fd, align 4
  call void @wf_std.collections.hash_map.hash_map_rehash$instance$fde7c6722a8b0dad.body(ptr %wf.result, ptr %v0, ptr %v1)
  %wf.returned = load %wf.t.7d7f918f7b4962fd, ptr %wf.result
  ret %wf.t.7d7f918f7b4962fd %wf.returned
}

define internal void @wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %v3 = select i1 true, i64 16384, i64 16384
  %v4 = icmp ugt i64 %v1, %v3
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v5 = phi ptr [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb3 ]
  %v7 = phi ptr [ %v2, %bb3 ]
  %t0 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v5, i32 0, i32 0
  %v10 = getelementptr i8, ptr %t0, i64 0
  %v11 = getelementptr i8, ptr %v10, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v11, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v12 = add i64 %t1, 0
  %v13 = icmp ule i64 %v6, %v12
  switch i1 %v13, label %invalid.tag.b1 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v8 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t3 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t3
  %t4 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 2
  store i8 %v8, ptr %t4
  ret void
bb3:
  br label %bb1
bb4:
  %v14 = phi ptr [ %v5, %bb6 ]
  %v15 = phi i64 [ %v6, %bb6 ]
  %v16 = phi ptr [ %v7, %bb6 ]
  %v19 = call %wf.t.7d7f918f7b4962fd @wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad(ptr %v14, i64 %v15, ptr %v16)
  store %wf.t.7d7f918f7b4962fd %v19, ptr %wf.result
  ret void
bb5:
  %v17 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t5 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t5
  %t6 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 1
  store i8 %v17, ptr %t6
  ret void
bb6:
  br label %bb4
}

define %wf.t.7d7f918f7b4962fd @wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad(ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.result = alloca %wf.t.7d7f918f7b4962fd, align 4
  call void @wf_std.collections.hash_map.hash_map_reserve$instance$fde7c6722a8b0dad.body(ptr %wf.result, ptr %v0, i64 %v1, ptr %v2)
  %wf.returned = load %wf.t.7d7f918f7b4962fd, ptr %wf.result
  ret %wf.t.7d7f918f7b4962fd %wf.returned
}

define i64 @wf_std.collections.hash_map.hash_map_capacity$instance$820b2044b97e0fbd(ptr noalias nonnull captures(none) dereferenceable(40) %v0) #0 {
entry:
  %t0 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v0, i32 0, i32 0
  %v1 = getelementptr i8, ptr %t0, i64 0
  %v2 = getelementptr i8, ptr %v1, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v2, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v3 = add i64 %t1, 0
  ret i64 %v3
}

define internal void @wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2, ptr noalias nonnull captures(none) dereferenceable(32) %v3) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.a1df460b0959673f, align 8
  %v4 = call i64 @wf_map_cost_hash(ptr %v2, ptr %v1)
  %t0 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v0, i32 0, i32 0
  %v5 = getelementptr i8, ptr %t0, i64 0
  %v6 = getelementptr i8, ptr %v5, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v6, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v7 = add i64 %t1, 0
  %v8 = select i1 true, i64 0, i64 0
  br label %bb1
bb1:
  %v9 = phi ptr [ %v0, %entry ], [ %v61, %bb12 ]
  %v10 = phi ptr [ %v1, %entry ], [ %v62, %bb12 ]
  %v11 = phi ptr [ %v2, %entry ], [ %v63, %bb12 ]
  %v12 = phi ptr [ %v3, %entry ], [ %v64, %bb12 ]
  %v13 = phi i64 [ %v4, %entry ], [ %v65, %bb12 ]
  %v14 = phi i64 [ %v7, %entry ], [ %v66, %bb12 ]
  %v15 = phi i64 [ %v8, %entry ], [ %v67, %bb12 ]
  %v16 = phi i64 [ %v7, %entry ], [ %v68, %bb12 ]
  %v17 = phi i64 [ %v8, %entry ], [ %v71, %bb12 ]
  %v24 = icmp ult i64 %v17, %v16
  switch i1 %v24, label %invalid.tag.b1 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v25 = urem i64 %v13, %v14
  %v26 = call i64 @wf_std.collections.hash_map.hash_map_probe(i64 %v25, i64 %v17, i64 %v14)
  %t3 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v9, i32 0, i32 0
  %v27 = getelementptr i8, ptr %t3, i64 0
  %v28 = getelementptr i8, ptr %v27, i64 0
  %t5 = getelementptr inbounds { i64, i64, ptr }, ptr %v28, i32 0, i32 2
  %t6 = load ptr, ptr %t5
  %t4.nonnegative = icmp sge i64 %v26, 0
  call void @llvm.assume(i1 %t4.nonnegative)
  %t4 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %t6, i64 %v26
  %v29 = getelementptr i8, ptr %t4, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v29, i64 ptrtoint (ptr getelementptr (%wf.t.a1df460b0959673f, ptr null, i32 1) to i64), i1 false)
  %t7 = load %wf.t.a1df460b0959673f, ptr %wf.slot.0
  %t8 = extractvalue %wf.t.a1df460b0959673f %t7, 0
  switch i32 %t8, label %invalid.tag.b2 [
    i32 2, label %bb6
    i32 0, label %bb7
    i32 1, label %bb8
  ]
invalid.tag.b2:
  unreachable
bb3:
  br label %bb4
bb4:
  %v18 = phi ptr [ %v9, %bb3 ]
  %v19 = phi ptr [ %v10, %bb3 ]
  %v20 = phi ptr [ %v11, %bb3 ]
  %v21 = phi ptr [ %v12, %bb3 ]
  %v22 = phi i64 [ %v13, %bb3 ]
  %v23 = phi i64 [ %v14, %bb3 ]
  %v72 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t9 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t9
  %t10 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v72, ptr %t10
  ret void
bb5:
  %v31 = phi ptr [ %v9, %bb8 ], [ %v44, %bb9 ]
  %v32 = phi ptr [ %v10, %bb8 ], [ %v45, %bb9 ]
  %v33 = phi ptr [ %v11, %bb8 ], [ %v46, %bb9 ]
  %v34 = phi ptr [ %v12, %bb8 ], [ %v47, %bb9 ]
  %v35 = phi i64 [ %v13, %bb8 ], [ %v48, %bb9 ]
  %v36 = phi i64 [ %v14, %bb8 ], [ %v49, %bb9 ]
  %v37 = phi i64 [ %v17, %bb8 ], [ %v50, %bb9 ]
  %v38 = phi i64 [ %v25, %bb8 ], [ %v51, %bb9 ]
  %v39 = phi i64 [ %v26, %bb8 ], [ %v52, %bb9 ]
  %v40 = phi ptr [ %v29, %bb8 ], [ %v53, %bb9 ]
  br label %bb12
bb6:
  %t11 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %v29, i32 0, i32 1
  %v41 = getelementptr i8, ptr %t11, i64 0
  %t12 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %v29, i32 0, i32 2
  %v42 = getelementptr i8, ptr %t12, i64 0
  %v43 = call i1 @wf_map_cost_equal(ptr %v11, ptr %v41, ptr %v10)
  switch i1 %v43, label %invalid.tag.b6 [
    i1 1, label %bb10
    i1 0, label %bb11
  ]
invalid.tag.b6:
  unreachable
bb7:
  %v59 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t13 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t13
  %t14 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v59, ptr %t14
  ret void
bb8:
  br label %bb5
bb9:
  %v44 = phi ptr [ %v9, %bb11 ]
  %v45 = phi ptr [ %v10, %bb11 ]
  %v46 = phi ptr [ %v11, %bb11 ]
  %v47 = phi ptr [ %v12, %bb11 ]
  %v48 = phi i64 [ %v13, %bb11 ]
  %v49 = phi i64 [ %v14, %bb11 ]
  %v50 = phi i64 [ %v17, %bb11 ]
  %v51 = phi i64 [ %v25, %bb11 ]
  %v52 = phi i64 [ %v26, %bb11 ]
  %v53 = phi ptr [ %v29, %bb11 ]
  %v54 = phi ptr [ %v41, %bb11 ]
  %v55 = phi ptr [ %v42, %bb11 ]
  %v56 = phi i1 [ %v43, %bb11 ]
  br label %bb5
bb10:
  %v57 = call i64 @wf_map_cost_word_edit(ptr %v12, ptr %v41, ptr %v42)
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t15 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t15
  %t16 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 1
  store i64 %v57, ptr %t16
  ret void
bb11:
  br label %bb9
bb12:
  %v61 = phi ptr [ %v31, %bb5 ]
  %v62 = phi ptr [ %v32, %bb5 ]
  %v63 = phi ptr [ %v33, %bb5 ]
  %v64 = phi ptr [ %v34, %bb5 ]
  %v65 = phi i64 [ %v35, %bb5 ]
  %v66 = phi i64 [ %v36, %bb5 ]
  %v67 = phi i64 [ %v15, %bb5 ]
  %v68 = phi i64 [ %v16, %bb5 ]
  %v69 = phi i64 [ %v17, %bb5 ]
  %v70 = select i1 true, i64 1, i64 1
  %v71 = add i64 %v69, %v70
  br label %bb1
}

define %wf.t.b7e1ed626c09888a @wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567(ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2, ptr noalias nonnull captures(none) dereferenceable(32) %v3) #0 {
entry:
  %wf.result = alloca %wf.t.b7e1ed626c09888a, align 8
  call void @wf_std.collections.hash_map.hash_map_edit$instance$25497bb333d90567.body(ptr %wf.result, ptr %v0, ptr %v1, ptr %v2, ptr %v3)
  %wf.returned = load %wf.t.b7e1ed626c09888a, ptr %wf.result
  ret %wf.t.b7e1ed626c09888a %wf.returned
}

define i8 @wf_std.collections.hash_map.hash_map_free$instance$001ff12ace7d7c19(ptr %wf.arg.v0, ptr noalias nonnull captures(none) dereferenceable(32) %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.0a5f51efa7ad5b17, align 8
  %wf.slot.1 = alloca %wf.t.a1df460b0959673f, align 8
  %wf.slot.2 = alloca { i64, i64, ptr }, align 8
  %v3 = alloca { i64, i64, ptr }, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v0, i64 ptrtoint (ptr getelementptr (%wf.t.0a5f51efa7ad5b17, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %wf.slot.0, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %v3, ptr %t0, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %t1 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %wf.slot.0, i32 0, i32 1
  %v4 = load i64, ptr %t1
  ; ownership-consuming projection
  %t2 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %wf.slot.0, i32 0, i32 2
  %v5 = load i64, ptr %t2
  ; ownership-consuming projection
  br label %bb1
bb1:
  %v7 = phi ptr [ %v1, %entry ], [ %v28, %bb6 ]
  %v8 = phi ptr [ %v3, %entry ], [ %v29, %bb6 ]
  %v9 = phi i64 [ %v4, %entry ], [ %v30, %bb6 ]
  %v10 = phi i64 [ %v5, %entry ], [ %v31, %bb6 ]
  %v16 = getelementptr i8, ptr %v8, i64 0
  %t4 = getelementptr inbounds { i64, i64, ptr }, ptr %v16, i32 0, i32 0
  %t3 = load i64, ptr %t4
  %v17 = add i64 %t3, 0
  %v18 = select i1 true, i64 0, i64 0
  %v19 = icmp eq i64 %v17, %v18
  switch i1 %v19, label %invalid.tag.b1 [
    i1 1, label %bb4
    i1 0, label %bb5
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v12 = phi ptr [ %v7, %bb4 ]
  %v13 = phi ptr [ %v8, %bb4 ]
  %v14 = phi i64 [ %v9, %bb4 ]
  %v15 = phi i64 [ %v10, %bb4 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %v13, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  %v37 = call i8 @wf_free_empty$instance$43608765810d87c7(ptr %wf.slot.2)
  %v38 = select i1 true, i8 0, i8 0
  ret i8 %v38
bb3:
  %v21 = phi ptr [ %v7, %bb5 ]
  %v22 = phi ptr [ %v8, %bb5 ]
  %v23 = phi i64 [ %v9, %bb5 ]
  %v24 = phi i64 [ %v10, %bb5 ]
  %v25 = getelementptr i8, ptr %v22, i64 0
  %v26 = call %wf.t.a1df460b0959673f @wf_take_back$instance$9985a87b1cb96650(ptr %v25)
  store %wf.t.a1df460b0959673f %v26, ptr %wf.slot.1
  %t5 = load %wf.t.a1df460b0959673f, ptr %wf.slot.1
  %t6 = extractvalue %wf.t.a1df460b0959673f %t5, 0
  switch i32 %t6, label %invalid.tag.b3 [
    i32 2, label %bb7
    i32 0, label %bb8
    i32 1, label %bb9
  ]
invalid.tag.b3:
  unreachable
bb4:
  br label %bb2
bb5:
  br label %bb3
bb6:
  %v28 = phi ptr [ %v21, %bb7 ], [ %v21, %bb8 ], [ %v21, %bb9 ]
  %v29 = phi ptr [ %v22, %bb7 ], [ %v22, %bb8 ], [ %v22, %bb9 ]
  %v30 = phi i64 [ %v23, %bb7 ], [ %v23, %bb8 ], [ %v23, %bb9 ]
  %v31 = phi i64 [ %v24, %bb7 ], [ %v24, %bb8 ], [ %v24, %bb9 ]
  br label %bb1
bb7:
  %t7 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %wf.slot.1, i32 0, i32 1
  %v33 = load i64, ptr %t7
  %t8 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %wf.slot.1, i32 0, i32 2
  %v34 = load i64, ptr %t8
  %v35 = call i8 @wf_map_cost_word_consume(ptr %v21, i64 %v33, i64 %v34)
  br label %bb6
bb8:
  br label %bb6
bb9:
  br label %bb6
}

define void @wf_std.collections.hash_map.hash_map_new$instance$96033bf6ddb80743(ptr %wf.result, i64 %v0) #0 {
entry:
  %wf.slot.0 = alloca { i64, i64, ptr }, align 8
  %v2 = alloca { i64, i64, ptr }, align 8
  %v1 = call { i64, i64, ptr } @wf_box_slots_new$instance$9eabc50a9cce2251(i64 %v0)
  store { i64, i64, ptr } %v1, ptr %v2
  %v3 = call i8 @wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743(ptr %v2, i64 %v0)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v2, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  %v5 = select i1 true, i64 0, i64 0
  %v6 = select i1 true, i64 0, i64 0
  store %wf.t.4380a1278c72e25d zeroinitializer, ptr %wf.result
  %t0 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %wf.result, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %t0, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  %t1 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %wf.result, i32 0, i32 1
  store i64 %v5, ptr %t1
  %t2 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %wf.result, i32 0, i32 2
  store i64 %v6, ptr %t2
  ret void
}

define void @wf_std.collections.hash_map.hash_map_put$instance$8d5197e2f00c3b07(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr %wf.arg.v2, ptr noalias nonnull captures(none) dereferenceable(16) %v3) #0 {
entry:
  %wf.frame = alloca { %wf.t.862971f7a971a883, %wf.t.4380a1278c72e25d, %wf.t.4380a1278c72e25d, %wf.t.4380a1278c72e25d, %wf.t.7d7f918f7b4962fd }, align 8
  %wf.slot.0 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.4380a1278c72e25d, %wf.t.4380a1278c72e25d, %wf.t.4380a1278c72e25d, %wf.t.7d7f918f7b4962fd }, ptr %wf.frame, i32 0, i32 0
  %wf.slot.1 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.4380a1278c72e25d, %wf.t.4380a1278c72e25d, %wf.t.4380a1278c72e25d, %wf.t.7d7f918f7b4962fd }, ptr %wf.frame, i32 0, i32 1
  %wf.slot.2 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.4380a1278c72e25d, %wf.t.4380a1278c72e25d, %wf.t.4380a1278c72e25d, %wf.t.7d7f918f7b4962fd }, ptr %wf.frame, i32 0, i32 2
  %wf.slot.3 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.4380a1278c72e25d, %wf.t.4380a1278c72e25d, %wf.t.4380a1278c72e25d, %wf.t.7d7f918f7b4962fd }, ptr %wf.frame, i32 0, i32 3
  %wf.slot.4 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.4380a1278c72e25d, %wf.t.4380a1278c72e25d, %wf.t.4380a1278c72e25d, %wf.t.7d7f918f7b4962fd }, ptr %wf.frame, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v2, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %v0, i32 0, i32 0
  %v4 = getelementptr i8, ptr %t0, i64 0
  %v5 = getelementptr i8, ptr %v4, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v5, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v6 = add i64 %t1, 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.4380a1278c72e25d, ptr null, i32 1) to i64), i1 false)
  %t3 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %wf.slot.1, i32 0, i32 1
  %v8 = load i64, ptr %t3
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.4380a1278c72e25d, ptr null, i32 1) to i64), i1 false)
  %t4 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %wf.slot.2, i32 0, i32 2
  %v10 = load i64, ptr %t4
  %v11 = call i64 @llvm.uadd.sat.i64(i64 %v8, i64 %v10)
  %v12 = select i1 true, i64 4, i64 4
  %v13 = udiv i64 %v6, %v12
  %v14 = sub nuw i64 %v6, %v13
  %v15 = icmp uge i64 %v11, %v14
  %v16 = select i1 true, i64 3, i64 3
  %v17 = icmp ult i64 %v6, %v16
  %v18 = and i1 %v15, %v17
  switch i1 %v18, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v19 = phi ptr [ %v0, %bb3 ], [ %v36, %bb4 ]
  %v20 = phi i64 [ %v1, %bb3 ], [ %v37, %bb4 ]
  %v22 = phi ptr [ %v3, %bb3 ], [ %v39, %bb4 ]
  %v23 = phi i64 [ %v6, %bb3 ], [ %v40, %bb4 ]
  %v24 = phi i64 [ %v11, %bb3 ], [ %v41, %bb4 ]
  %v25 = phi i64 [ %v13, %bb3 ], [ %v42, %bb4 ]
  %v26 = phi i64 [ %v14, %bb3 ], [ %v43, %bb4 ]
  %v27 = phi i1 [ %v15, %bb3 ], [ %v44, %bb4 ]
  %v28 = phi i1 [ %v17, %bb3 ], [ %v45, %bb4 ]
  %v29 = phi i1 [ %v18, %bb3 ], [ %v46, %bb4 ]
  call void @wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07(ptr %wf.result, ptr %v19, i64 %v20, ptr %wf.slot.0, ptr %v22)
  ret void
bb2:
  %v30 = select i1 true, i64 3, i64 3
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.3, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.4380a1278c72e25d, ptr null, i32 1) to i64), i1 false)
  %t5 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %wf.slot.3, i32 0, i32 1
  %v32 = load i64, ptr %t5
  %v33 = select i1 true, i64 2, i64 2
  %v34 = udiv i64 %v14, %v33
  %v35 = icmp ult i64 %v32, %v34
  switch i1 %v35, label %invalid.tag.b2 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b2:
  unreachable
bb3:
  br label %bb1
bb4:
  %v36 = phi ptr [ %v0, %bb5 ], [ %v52, %bb7 ]
  %v37 = phi i64 [ %v1, %bb5 ], [ %v53, %bb7 ]
  %v39 = phi ptr [ %v3, %bb5 ], [ %v55, %bb7 ]
  %v40 = phi i64 [ %v6, %bb5 ], [ %v56, %bb7 ]
  %v41 = phi i64 [ %v11, %bb5 ], [ %v57, %bb7 ]
  %v42 = phi i64 [ %v13, %bb5 ], [ %v58, %bb7 ]
  %v43 = phi i64 [ %v14, %bb5 ], [ %v59, %bb7 ]
  %v44 = phi i1 [ %v15, %bb5 ], [ %v60, %bb7 ]
  %v45 = phi i1 [ %v17, %bb5 ], [ %v61, %bb7 ]
  %v46 = phi i1 [ %v18, %bb5 ], [ %v62, %bb7 ]
  %v47 = phi i64 [ %v6, %bb5 ], [ %v63, %bb7 ]
  %v48 = phi i64 [ %v32, %bb5 ], [ %v64, %bb7 ]
  %v49 = phi i64 [ %v34, %bb5 ], [ %v65, %bb7 ]
  %v101 = call %wf.t.7d7f918f7b4962fd @wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07(ptr %v36, i64 %v47, ptr %v39)
  store %wf.t.7d7f918f7b4962fd %v101, ptr %wf.slot.4
  br label %bb1
bb5:
  br label %bb4
bb6:
  %v50 = select i1 true, i64 0, i64 0
  %v51 = icmp eq i64 %v6, %v50
  switch i1 %v51, label %invalid.tag.b6 [
    i1 1, label %bb8
    i1 0, label %bb9
  ]
invalid.tag.b6:
  unreachable
bb7:
  %v52 = phi ptr [ %v0, %bb8 ], [ %v69, %bb10 ]
  %v53 = phi i64 [ %v1, %bb8 ], [ %v70, %bb10 ]
  %v55 = phi ptr [ %v3, %bb8 ], [ %v72, %bb10 ]
  %v56 = phi i64 [ %v6, %bb8 ], [ %v73, %bb10 ]
  %v57 = phi i64 [ %v11, %bb8 ], [ %v74, %bb10 ]
  %v58 = phi i64 [ %v13, %bb8 ], [ %v75, %bb10 ]
  %v59 = phi i64 [ %v14, %bb8 ], [ %v76, %bb10 ]
  %v60 = phi i1 [ %v15, %bb8 ], [ %v77, %bb10 ]
  %v61 = phi i1 [ %v17, %bb8 ], [ %v78, %bb10 ]
  %v62 = phi i1 [ %v18, %bb8 ], [ %v79, %bb10 ]
  %v63 = phi i64 [ %v66, %bb8 ], [ %v80, %bb10 ]
  %v64 = phi i64 [ %v32, %bb8 ], [ %v81, %bb10 ]
  %v65 = phi i64 [ %v34, %bb8 ], [ %v82, %bb10 ]
  br label %bb4
bb8:
  %v66 = select i1 true, i64 1, i64 1
  br label %bb7
bb9:
  %v67 = select i1 true, i64 9223372036854775807, i64 9223372036854775807
  %v68 = icmp ule i64 %v6, %v67
  switch i1 %v68, label %invalid.tag.b9 [
    i1 1, label %bb11
    i1 0, label %bb12
  ]
invalid.tag.b9:
  unreachable
bb10:
  %v69 = phi ptr [ %v0, %bb12 ], [ %v86, %bb13 ]
  %v70 = phi i64 [ %v1, %bb12 ], [ %v87, %bb13 ]
  %v72 = phi ptr [ %v3, %bb12 ], [ %v89, %bb13 ]
  %v73 = phi i64 [ %v6, %bb12 ], [ %v90, %bb13 ]
  %v74 = phi i64 [ %v11, %bb12 ], [ %v91, %bb13 ]
  %v75 = phi i64 [ %v13, %bb12 ], [ %v92, %bb13 ]
  %v76 = phi i64 [ %v14, %bb12 ], [ %v93, %bb13 ]
  %v77 = phi i1 [ %v15, %bb12 ], [ %v94, %bb13 ]
  %v78 = phi i1 [ %v17, %bb12 ], [ %v95, %bb13 ]
  %v79 = phi i1 [ %v18, %bb12 ], [ %v96, %bb13 ]
  %v80 = phi i64 [ %v30, %bb12 ], [ %v97, %bb13 ]
  %v81 = phi i64 [ %v32, %bb12 ], [ %v98, %bb13 ]
  %v82 = phi i64 [ %v34, %bb12 ], [ %v99, %bb13 ]
  br label %bb7
bb11:
  %v83 = add nuw i64 %v6, %v6
  %v84 = select i1 true, i64 3, i64 3
  %v85 = icmp ule i64 %v83, %v84
  switch i1 %v85, label %invalid.tag.b11 [
    i1 1, label %bb14
    i1 0, label %bb15
  ]
invalid.tag.b11:
  unreachable
bb12:
  br label %bb10
bb13:
  %v86 = phi ptr [ %v0, %bb14 ], [ %v0, %bb15 ]
  %v87 = phi i64 [ %v1, %bb14 ], [ %v1, %bb15 ]
  %v89 = phi ptr [ %v3, %bb14 ], [ %v3, %bb15 ]
  %v90 = phi i64 [ %v6, %bb14 ], [ %v6, %bb15 ]
  %v91 = phi i64 [ %v11, %bb14 ], [ %v11, %bb15 ]
  %v92 = phi i64 [ %v13, %bb14 ], [ %v13, %bb15 ]
  %v93 = phi i64 [ %v14, %bb14 ], [ %v14, %bb15 ]
  %v94 = phi i1 [ %v15, %bb14 ], [ %v15, %bb15 ]
  %v95 = phi i1 [ %v17, %bb14 ], [ %v17, %bb15 ]
  %v96 = phi i1 [ %v18, %bb14 ], [ %v18, %bb15 ]
  %v97 = phi i64 [ %v83, %bb14 ], [ %v30, %bb15 ]
  %v98 = phi i64 [ %v32, %bb14 ], [ %v32, %bb15 ]
  %v99 = phi i64 [ %v34, %bb14 ], [ %v34, %bb15 ]
  %v100 = phi i64 [ %v83, %bb14 ], [ %v83, %bb15 ]
  br label %bb10
bb14:
  br label %bb13
bb15:
  br label %bb13
}

define i8 @wf_map_cost_library_policy_result$instance$4250cb78d3f44027(ptr %wf.arg.v0, ptr noalias nonnull captures(none) dereferenceable(32) %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.114ba5754d75c8d6, align 8
  %wf.slot.1 = alloca %wf.t.d72ca22fbd302a84, align 8
  %wf.slot.2 = alloca %wf.t.862971f7a971a883, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v0, i64 ptrtoint (ptr getelementptr (%wf.t.114ba5754d75c8d6, ptr null, i32 1) to i64), i1 false)
  %t0 = load %wf.t.114ba5754d75c8d6, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.114ba5754d75c8d6 %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb2
    i32 1, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v3 = phi ptr [ %v1, %bb2 ], [ %v9, %bb4 ]
  %v20 = select i1 true, i8 0, i8 0
  ret i8 %v20
bb2:
  %v4 = select i1 true, i64 0, i64 0
  %v5 = call i8 @wf_map_cost_ordered(ptr %v1, i64 %v4)
  br label %bb1
bb3:
  %t2 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.slot.0, i32 0, i32 1
  %v6 = load i1, ptr %t2
  %t3 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.slot.0, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %t3, i64 ptrtoint (ptr getelementptr (%wf.t.d72ca22fbd302a84, ptr null, i32 1) to i64), i1 false)
  switch i1 %v6, label %invalid.tag.b3 [
    i1 0, label %bb5
    i1 1, label %bb6
  ]
invalid.tag.b3:
  unreachable
bb4:
  %v9 = phi ptr [ %v1, %bb5 ], [ %v1, %bb6 ]
  %v10 = phi i1 [ %v6, %bb5 ], [ %v6, %bb6 ]
  %t4 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.1, i32 0, i32 0
  %v16 = load i64, ptr %t4
  ; ownership-consuming projection
  %t5 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.1, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %t5, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %v18 = call i64 @wf_map_cost_record_content(i64 %v16, ptr %wf.slot.2)
  %v19 = call i8 @wf_map_cost_ordered(ptr %v9, i64 %v18)
  br label %bb1
bb5:
  %v12 = select i1 true, i64 1, i64 1
  %v13 = call i8 @wf_map_cost_ordered(ptr %v1, i64 %v12)
  br label %bb4
bb6:
  %v14 = select i1 true, i64 2, i64 2
  %v15 = call i8 @wf_map_cost_ordered(ptr %v1, i64 %v14)
  br label %bb4
}

define i8 @wf_std.collections.hash_map.hash_map_free$instance$72d84b2e6d0b7146(ptr %wf.arg.v0, ptr noalias nonnull captures(none) dereferenceable(32) %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.4380a1278c72e25d, align 8
  %wf.slot.1 = alloca %wf.t.dceb7b9db1c9ad1d, align 8
  %wf.slot.2 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.3 = alloca { i64, i64, ptr }, align 8
  %v3 = alloca { i64, i64, ptr }, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v0, i64 ptrtoint (ptr getelementptr (%wf.t.4380a1278c72e25d, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %wf.slot.0, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %v3, ptr %t0, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %t1 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %wf.slot.0, i32 0, i32 1
  %v4 = load i64, ptr %t1
  ; ownership-consuming projection
  %t2 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %wf.slot.0, i32 0, i32 2
  %v5 = load i64, ptr %t2
  ; ownership-consuming projection
  br label %bb1
bb1:
  %v7 = phi ptr [ %v1, %entry ], [ %v28, %bb6 ]
  %v8 = phi ptr [ %v3, %entry ], [ %v29, %bb6 ]
  %v9 = phi i64 [ %v4, %entry ], [ %v30, %bb6 ]
  %v10 = phi i64 [ %v5, %entry ], [ %v31, %bb6 ]
  %v16 = getelementptr i8, ptr %v8, i64 0
  %t4 = getelementptr inbounds { i64, i64, ptr }, ptr %v16, i32 0, i32 0
  %t3 = load i64, ptr %t4
  %v17 = add i64 %t3, 0
  %v18 = select i1 true, i64 0, i64 0
  %v19 = icmp eq i64 %v17, %v18
  switch i1 %v19, label %invalid.tag.b1 [
    i1 1, label %bb4
    i1 0, label %bb5
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v12 = phi ptr [ %v7, %bb4 ]
  %v13 = phi ptr [ %v8, %bb4 ]
  %v14 = phi i64 [ %v9, %bb4 ]
  %v15 = phi i64 [ %v10, %bb4 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.3, ptr %v13, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  %v37 = call i8 @wf_free_empty$instance$d692d011b23a4a18(ptr %wf.slot.3)
  %v38 = select i1 true, i8 0, i8 0
  ret i8 %v38
bb3:
  %v21 = phi ptr [ %v7, %bb5 ]
  %v22 = phi ptr [ %v8, %bb5 ]
  %v23 = phi i64 [ %v9, %bb5 ]
  %v24 = phi i64 [ %v10, %bb5 ]
  %v25 = getelementptr i8, ptr %v22, i64 0
  call void @wf_take_back$instance$d5bb00f00cd669fb(ptr %wf.slot.1, ptr %v25)
  %t5 = load %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.1
  %t6 = extractvalue %wf.t.dceb7b9db1c9ad1d %t5, 0
  switch i32 %t6, label %invalid.tag.b3 [
    i32 2, label %bb7
    i32 0, label %bb8
    i32 1, label %bb9
  ]
invalid.tag.b3:
  unreachable
bb4:
  br label %bb2
bb5:
  br label %bb3
bb6:
  %v28 = phi ptr [ %v21, %bb7 ], [ %v21, %bb8 ], [ %v21, %bb9 ]
  %v29 = phi ptr [ %v22, %bb7 ], [ %v22, %bb8 ], [ %v22, %bb9 ]
  %v30 = phi i64 [ %v23, %bb7 ], [ %v23, %bb8 ], [ %v23, %bb9 ]
  %v31 = phi i64 [ %v24, %bb7 ], [ %v24, %bb8 ], [ %v24, %bb9 ]
  br label %bb1
bb7:
  %t7 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.1, i32 0, i32 1
  %v33 = load i64, ptr %t7
  %t8 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.1, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %t8, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %v35 = call i8 @wf_map_cost_record_consume(ptr %v21, i64 %v33, ptr %wf.slot.2)
  br label %bb6
bb8:
  br label %bb6
bb9:
  br label %bb6
}

define void @wf_std.collections.hash_map.hash_map_new$instance$0e108827ecbbe374(ptr %wf.result, i64 %v0) #0 {
entry:
  %wf.slot.0 = alloca { i64, i64, ptr }, align 8
  %v2 = alloca { i64, i64, ptr }, align 8
  %v1 = call { i64, i64, ptr } @wf_box_slots_new$instance$9eabc50a9cce2251(i64 %v0)
  store { i64, i64, ptr } %v1, ptr %v2
  %v3 = call i8 @wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374(ptr %v2, i64 %v0)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v2, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  %v5 = select i1 true, i64 0, i64 0
  %v6 = select i1 true, i64 0, i64 0
  store %wf.t.588b2641b8ac7d45 zeroinitializer, ptr %wf.result
  %t0 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %wf.result, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %t0, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  %t1 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %wf.result, i32 0, i32 1
  store i64 %v5, ptr %t1
  %t2 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %wf.result, i32 0, i32 2
  store i64 %v6, ptr %t2
  ret void
}

define void @wf_std.collections.hash_map.hash_map_put$instance$28da32efc51c2b65(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr %wf.arg.v2, ptr noalias nonnull captures(none) dereferenceable(16) %v3) #0 {
entry:
  %wf.frame = alloca { %wf.t.862971f7a971a883, %wf.t.588b2641b8ac7d45, %wf.t.588b2641b8ac7d45, %wf.t.588b2641b8ac7d45, %wf.t.7d7f918f7b4962fd }, align 8
  %wf.slot.0 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.588b2641b8ac7d45, %wf.t.588b2641b8ac7d45, %wf.t.588b2641b8ac7d45, %wf.t.7d7f918f7b4962fd }, ptr %wf.frame, i32 0, i32 0
  %wf.slot.1 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.588b2641b8ac7d45, %wf.t.588b2641b8ac7d45, %wf.t.588b2641b8ac7d45, %wf.t.7d7f918f7b4962fd }, ptr %wf.frame, i32 0, i32 1
  %wf.slot.2 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.588b2641b8ac7d45, %wf.t.588b2641b8ac7d45, %wf.t.588b2641b8ac7d45, %wf.t.7d7f918f7b4962fd }, ptr %wf.frame, i32 0, i32 2
  %wf.slot.3 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.588b2641b8ac7d45, %wf.t.588b2641b8ac7d45, %wf.t.588b2641b8ac7d45, %wf.t.7d7f918f7b4962fd }, ptr %wf.frame, i32 0, i32 3
  %wf.slot.4 = getelementptr inbounds { %wf.t.862971f7a971a883, %wf.t.588b2641b8ac7d45, %wf.t.588b2641b8ac7d45, %wf.t.588b2641b8ac7d45, %wf.t.7d7f918f7b4962fd }, ptr %wf.frame, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v2, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v0, i32 0, i32 0
  %v4 = getelementptr i8, ptr %t0, i64 0
  %v5 = getelementptr i8, ptr %v4, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v5, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v6 = add i64 %t1, 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.588b2641b8ac7d45, ptr null, i32 1) to i64), i1 false)
  %t3 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %wf.slot.1, i32 0, i32 1
  %v8 = load i64, ptr %t3
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.588b2641b8ac7d45, ptr null, i32 1) to i64), i1 false)
  %t4 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %wf.slot.2, i32 0, i32 2
  %v10 = load i64, ptr %t4
  %v11 = call i64 @llvm.uadd.sat.i64(i64 %v8, i64 %v10)
  %v12 = select i1 true, i64 4, i64 4
  %v13 = udiv i64 %v6, %v12
  %v14 = sub nuw i64 %v6, %v13
  %v15 = icmp uge i64 %v11, %v14
  %v16 = select i1 true, i64 16384, i64 16384
  %v17 = icmp ult i64 %v6, %v16
  %v18 = and i1 %v15, %v17
  switch i1 %v18, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v19 = phi ptr [ %v0, %bb3 ], [ %v36, %bb4 ]
  %v20 = phi i64 [ %v1, %bb3 ], [ %v37, %bb4 ]
  %v22 = phi ptr [ %v3, %bb3 ], [ %v39, %bb4 ]
  %v23 = phi i64 [ %v6, %bb3 ], [ %v40, %bb4 ]
  %v24 = phi i64 [ %v11, %bb3 ], [ %v41, %bb4 ]
  %v25 = phi i64 [ %v13, %bb3 ], [ %v42, %bb4 ]
  %v26 = phi i64 [ %v14, %bb3 ], [ %v43, %bb4 ]
  %v27 = phi i1 [ %v15, %bb3 ], [ %v44, %bb4 ]
  %v28 = phi i1 [ %v17, %bb3 ], [ %v45, %bb4 ]
  %v29 = phi i1 [ %v18, %bb3 ], [ %v46, %bb4 ]
  call void @wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65(ptr %wf.result, ptr %v19, i64 %v20, ptr %wf.slot.0, ptr %v22)
  ret void
bb2:
  %v30 = select i1 true, i64 16384, i64 16384
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.3, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.588b2641b8ac7d45, ptr null, i32 1) to i64), i1 false)
  %t5 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %wf.slot.3, i32 0, i32 1
  %v32 = load i64, ptr %t5
  %v33 = select i1 true, i64 2, i64 2
  %v34 = udiv i64 %v14, %v33
  %v35 = icmp ult i64 %v32, %v34
  switch i1 %v35, label %invalid.tag.b2 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b2:
  unreachable
bb3:
  br label %bb1
bb4:
  %v36 = phi ptr [ %v0, %bb5 ], [ %v52, %bb7 ]
  %v37 = phi i64 [ %v1, %bb5 ], [ %v53, %bb7 ]
  %v39 = phi ptr [ %v3, %bb5 ], [ %v55, %bb7 ]
  %v40 = phi i64 [ %v6, %bb5 ], [ %v56, %bb7 ]
  %v41 = phi i64 [ %v11, %bb5 ], [ %v57, %bb7 ]
  %v42 = phi i64 [ %v13, %bb5 ], [ %v58, %bb7 ]
  %v43 = phi i64 [ %v14, %bb5 ], [ %v59, %bb7 ]
  %v44 = phi i1 [ %v15, %bb5 ], [ %v60, %bb7 ]
  %v45 = phi i1 [ %v17, %bb5 ], [ %v61, %bb7 ]
  %v46 = phi i1 [ %v18, %bb5 ], [ %v62, %bb7 ]
  %v47 = phi i64 [ %v6, %bb5 ], [ %v63, %bb7 ]
  %v48 = phi i64 [ %v32, %bb5 ], [ %v64, %bb7 ]
  %v49 = phi i64 [ %v34, %bb5 ], [ %v65, %bb7 ]
  %v101 = call %wf.t.7d7f918f7b4962fd @wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65(ptr %v36, i64 %v47, ptr %v39)
  store %wf.t.7d7f918f7b4962fd %v101, ptr %wf.slot.4
  br label %bb1
bb5:
  br label %bb4
bb6:
  %v50 = select i1 true, i64 0, i64 0
  %v51 = icmp eq i64 %v6, %v50
  switch i1 %v51, label %invalid.tag.b6 [
    i1 1, label %bb8
    i1 0, label %bb9
  ]
invalid.tag.b6:
  unreachable
bb7:
  %v52 = phi ptr [ %v0, %bb8 ], [ %v69, %bb10 ]
  %v53 = phi i64 [ %v1, %bb8 ], [ %v70, %bb10 ]
  %v55 = phi ptr [ %v3, %bb8 ], [ %v72, %bb10 ]
  %v56 = phi i64 [ %v6, %bb8 ], [ %v73, %bb10 ]
  %v57 = phi i64 [ %v11, %bb8 ], [ %v74, %bb10 ]
  %v58 = phi i64 [ %v13, %bb8 ], [ %v75, %bb10 ]
  %v59 = phi i64 [ %v14, %bb8 ], [ %v76, %bb10 ]
  %v60 = phi i1 [ %v15, %bb8 ], [ %v77, %bb10 ]
  %v61 = phi i1 [ %v17, %bb8 ], [ %v78, %bb10 ]
  %v62 = phi i1 [ %v18, %bb8 ], [ %v79, %bb10 ]
  %v63 = phi i64 [ %v66, %bb8 ], [ %v80, %bb10 ]
  %v64 = phi i64 [ %v32, %bb8 ], [ %v81, %bb10 ]
  %v65 = phi i64 [ %v34, %bb8 ], [ %v82, %bb10 ]
  br label %bb4
bb8:
  %v66 = select i1 true, i64 1, i64 1
  br label %bb7
bb9:
  %v67 = select i1 true, i64 9223372036854775807, i64 9223372036854775807
  %v68 = icmp ule i64 %v6, %v67
  switch i1 %v68, label %invalid.tag.b9 [
    i1 1, label %bb11
    i1 0, label %bb12
  ]
invalid.tag.b9:
  unreachable
bb10:
  %v69 = phi ptr [ %v0, %bb12 ], [ %v86, %bb13 ]
  %v70 = phi i64 [ %v1, %bb12 ], [ %v87, %bb13 ]
  %v72 = phi ptr [ %v3, %bb12 ], [ %v89, %bb13 ]
  %v73 = phi i64 [ %v6, %bb12 ], [ %v90, %bb13 ]
  %v74 = phi i64 [ %v11, %bb12 ], [ %v91, %bb13 ]
  %v75 = phi i64 [ %v13, %bb12 ], [ %v92, %bb13 ]
  %v76 = phi i64 [ %v14, %bb12 ], [ %v93, %bb13 ]
  %v77 = phi i1 [ %v15, %bb12 ], [ %v94, %bb13 ]
  %v78 = phi i1 [ %v17, %bb12 ], [ %v95, %bb13 ]
  %v79 = phi i1 [ %v18, %bb12 ], [ %v96, %bb13 ]
  %v80 = phi i64 [ %v30, %bb12 ], [ %v97, %bb13 ]
  %v81 = phi i64 [ %v32, %bb12 ], [ %v98, %bb13 ]
  %v82 = phi i64 [ %v34, %bb12 ], [ %v99, %bb13 ]
  br label %bb7
bb11:
  %v83 = add nuw i64 %v6, %v6
  %v84 = select i1 true, i64 16384, i64 16384
  %v85 = icmp ule i64 %v83, %v84
  switch i1 %v85, label %invalid.tag.b11 [
    i1 1, label %bb14
    i1 0, label %bb15
  ]
invalid.tag.b11:
  unreachable
bb12:
  br label %bb10
bb13:
  %v86 = phi ptr [ %v0, %bb14 ], [ %v0, %bb15 ]
  %v87 = phi i64 [ %v1, %bb14 ], [ %v1, %bb15 ]
  %v89 = phi ptr [ %v3, %bb14 ], [ %v3, %bb15 ]
  %v90 = phi i64 [ %v6, %bb14 ], [ %v6, %bb15 ]
  %v91 = phi i64 [ %v11, %bb14 ], [ %v11, %bb15 ]
  %v92 = phi i64 [ %v13, %bb14 ], [ %v13, %bb15 ]
  %v93 = phi i64 [ %v14, %bb14 ], [ %v14, %bb15 ]
  %v94 = phi i1 [ %v15, %bb14 ], [ %v15, %bb15 ]
  %v95 = phi i1 [ %v17, %bb14 ], [ %v17, %bb15 ]
  %v96 = phi i1 [ %v18, %bb14 ], [ %v18, %bb15 ]
  %v97 = phi i64 [ %v83, %bb14 ], [ %v30, %bb15 ]
  %v98 = phi i64 [ %v32, %bb14 ], [ %v32, %bb15 ]
  %v99 = phi i64 [ %v34, %bb14 ], [ %v34, %bb15 ]
  %v100 = phi i64 [ %v83, %bb14 ], [ %v83, %bb15 ]
  br label %bb10
bb14:
  br label %bb13
bb15:
  br label %bb13
}

define void @wf_std.collections.hash_map.hash_map_remove$instance$28da32efc51c2b65(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.588b2641b8ac7d45, align 8
  %wf.slot.1 = alloca %wf.t.b7e1ed626c09888a, align 8
  %wf.slot.2 = alloca %wf.t.dceb7b9db1c9ad1d, align 8
  %wf.slot.3 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.4 = alloca %wf.t.588b2641b8ac7d45, align 8
  %wf.slot.5 = alloca %wf.t.d72ca22fbd302a84, align 8
  %v15 = alloca %wf.t.dceb7b9db1c9ad1d, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.588b2641b8ac7d45, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %wf.slot.0, i32 0, i32 1
  %v4 = load i64, ptr %t0
  %v5 = select i1 true, i64 0, i64 0
  %v6 = icmp eq i64 %v4, %v5
  switch i1 %v6, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v7 = phi ptr [ %v0, %bb3 ]
  %v8 = phi ptr [ %v1, %bb3 ]
  %v9 = phi ptr [ %v2, %bb3 ]
  %v10 = phi i64 [ %v4, %bb3 ]
  %v12 = call %wf.t.b7e1ed626c09888a @wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65(ptr %v7, ptr %v8, ptr %v9)
  store %wf.t.b7e1ed626c09888a %v12, ptr %wf.slot.1
  %t1 = load %wf.t.b7e1ed626c09888a, ptr %wf.slot.1
  %t2 = extractvalue %wf.t.b7e1ed626c09888a %t1, 0
  switch i32 %t2, label %invalid.tag.b1 [
    i32 0, label %bb4
    i32 1, label %bb5
  ]
invalid.tag.b1:
  unreachable
bb2:
  store %wf.t.aba8f6d9883dda3a zeroinitializer, ptr %wf.result
  %t3 = getelementptr inbounds %wf.t.aba8f6d9883dda3a, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t3
  ret void
bb3:
  br label %bb1
bb4:
  %t4 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.slot.1, i32 0, i32 1
  %v13 = load i64, ptr %t4
  store %wf.t.dceb7b9db1c9ad1d zeroinitializer, ptr %v15
  %t5 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %v15, i32 0, i32 0
  store i32 1, ptr %t5
  %t6 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v7, i32 0, i32 0
  %v16 = getelementptr i8, ptr %t6, i64 0
  %v17 = getelementptr i8, ptr %v16, i64 0
  %t8 = getelementptr inbounds { i64, i64, ptr }, ptr %v17, i32 0, i32 2
  %t9 = load ptr, ptr %t8
  %t7.nonnegative = icmp sge i64 %v13, 0
  call void @llvm.assume(i1 %t7.nonnegative)
  %t7 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %t9, i64 %v13
  %v18 = getelementptr i8, ptr %t7, i64 0
  %v19 = call i8 @wf_swap$instance$9eabc50a9cce2251(ptr %v18, ptr %v15)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %v15, i64 ptrtoint (ptr getelementptr (%wf.t.dceb7b9db1c9ad1d, ptr null, i32 1) to i64), i1 false)
  %t10 = load %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.2
  %t11 = extractvalue %wf.t.dceb7b9db1c9ad1d %t10, 0
  switch i32 %t11, label %invalid.tag.b4 [
    i32 2, label %bb6
    i32 0, label %bb7
    i32 1, label %bb8
  ]
invalid.tag.b4:
  unreachable
bb5:
  %t12 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.slot.1, i32 0, i32 2
  %v35 = load i8, ptr %t12
  store %wf.t.aba8f6d9883dda3a zeroinitializer, ptr %wf.result
  %t13 = getelementptr inbounds %wf.t.aba8f6d9883dda3a, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t13
  ret void
bb6:
  %t14 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.2, i32 0, i32 1
  %v21 = load i64, ptr %t14
  %t15 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.2, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.3, ptr %t15, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %t16 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v7, i32 0, i32 1
  %v23 = getelementptr i8, ptr %t16, i64 0
  %v24 = select i1 true, i64 1, i64 1
  %v25 = sub nuw i64 %v10, %v24
  store i64 %v25, ptr %v23
  %t17 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v7, i32 0, i32 2
  %v26 = getelementptr i8, ptr %t17, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.4, ptr %v7, i64 ptrtoint (ptr getelementptr (%wf.t.588b2641b8ac7d45, ptr null, i32 1) to i64), i1 false)
  %t18 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %wf.slot.4, i32 0, i32 2
  %v28 = load i64, ptr %t18
  %v29 = select i1 true, i64 1, i64 1
  %v30 = call i64 @llvm.uadd.sat.i64(i64 %v28, i64 %v29)
  store i64 %v30, ptr %v26
  store %wf.t.d72ca22fbd302a84 zeroinitializer, ptr %wf.slot.5
  %t19 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.5, i32 0, i32 0
  store i64 %v21, ptr %t19
  %t20 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.5, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t20, ptr %wf.slot.3, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  store %wf.t.aba8f6d9883dda3a zeroinitializer, ptr %wf.result
  %t21 = getelementptr inbounds %wf.t.aba8f6d9883dda3a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t21
  %t22 = getelementptr inbounds %wf.t.aba8f6d9883dda3a, ptr %wf.result, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t22, ptr %wf.slot.5, i64 ptrtoint (ptr getelementptr (%wf.t.d72ca22fbd302a84, ptr null, i32 1) to i64), i1 false)
  ret void
bb7:
  store %wf.t.aba8f6d9883dda3a zeroinitializer, ptr %wf.result
  %t23 = getelementptr inbounds %wf.t.aba8f6d9883dda3a, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t23
  ret void
bb8:
  store %wf.t.aba8f6d9883dda3a zeroinitializer, ptr %wf.result
  %t24 = getelementptr inbounds %wf.t.aba8f6d9883dda3a, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t24
  ret void
}

define internal void @wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2, ptr noalias nonnull captures(none) dereferenceable(32) %v3) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.dceb7b9db1c9ad1d, align 8
  %v4 = call i64 @wf_map_cost_hash(ptr %v2, ptr %v1)
  %t0 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v0, i32 0, i32 0
  %v5 = getelementptr i8, ptr %t0, i64 0
  %v6 = getelementptr i8, ptr %v5, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v6, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v7 = add i64 %t1, 0
  %v8 = select i1 true, i64 0, i64 0
  %v9 = icmp eq i64 %v7, %v8
  switch i1 %v9, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v10 = phi ptr [ %v0, %bb3 ]
  %v11 = phi ptr [ %v1, %bb3 ]
  %v12 = phi ptr [ %v2, %bb3 ]
  %v13 = phi ptr [ %v3, %bb3 ]
  %v14 = phi i64 [ %v4, %bb3 ]
  %v15 = phi i64 [ %v7, %bb3 ]
  %v18 = urem i64 %v14, %v15
  %v19 = select i1 true, i64 0, i64 0
  br label %bb4
bb2:
  %v16 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t3 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t3
  %t4 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v16, ptr %t4
  ret void
bb3:
  br label %bb1
bb4:
  %v20 = phi ptr [ %v10, %bb1 ], [ %v84, %bb18 ]
  %v21 = phi ptr [ %v11, %bb1 ], [ %v85, %bb18 ]
  %v22 = phi ptr [ %v12, %bb1 ], [ %v86, %bb18 ]
  %v23 = phi ptr [ %v13, %bb1 ], [ %v87, %bb18 ]
  %v24 = phi i64 [ %v14, %bb1 ], [ %v88, %bb18 ]
  %v25 = phi i64 [ %v15, %bb1 ], [ %v89, %bb18 ]
  %v26 = phi i64 [ %v18, %bb1 ], [ %v90, %bb18 ]
  %v27 = phi i64 [ %v19, %bb1 ], [ %v91, %bb18 ]
  %v28 = phi i64 [ %v15, %bb1 ], [ %v92, %bb18 ]
  %v29 = phi i64 [ %v19, %bb1 ], [ %v95, %bb18 ]
  %v37 = icmp ult i64 %v29, %v28
  switch i1 %v37, label %invalid.tag.b4 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b4:
  unreachable
bb5:
  %t5 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v20, i32 0, i32 0
  %v38 = getelementptr i8, ptr %t5, i64 0
  %v39 = getelementptr i8, ptr %v38, i64 0
  %t7 = getelementptr inbounds { i64, i64, ptr }, ptr %v39, i32 0, i32 2
  %t8 = load ptr, ptr %t7
  %t6.nonnegative = icmp sge i64 %v26, 0
  call void @llvm.assume(i1 %t6.nonnegative)
  %t6 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %t8, i64 %v26
  %v40 = getelementptr i8, ptr %t6, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v40, i64 ptrtoint (ptr getelementptr (%wf.t.dceb7b9db1c9ad1d, ptr null, i32 1) to i64), i1 false)
  %t9 = load %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.0
  %t10 = extractvalue %wf.t.dceb7b9db1c9ad1d %t9, 0
  switch i32 %t10, label %invalid.tag.b5 [
    i32 2, label %bb9
    i32 0, label %bb10
    i32 1, label %bb11
  ]
invalid.tag.b5:
  unreachable
bb6:
  br label %bb7
bb7:
  %v30 = phi ptr [ %v20, %bb6 ]
  %v31 = phi ptr [ %v21, %bb6 ]
  %v32 = phi ptr [ %v22, %bb6 ]
  %v33 = phi ptr [ %v23, %bb6 ]
  %v34 = phi i64 [ %v24, %bb6 ]
  %v35 = phi i64 [ %v25, %bb6 ]
  %v36 = phi i64 [ %v26, %bb6 ]
  %v96 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t11 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t11
  %t12 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v96, ptr %t12
  ret void
bb8:
  %v42 = phi ptr [ %v20, %bb11 ], [ %v54, %bb12 ]
  %v43 = phi ptr [ %v21, %bb11 ], [ %v55, %bb12 ]
  %v44 = phi ptr [ %v22, %bb11 ], [ %v56, %bb12 ]
  %v45 = phi ptr [ %v23, %bb11 ], [ %v57, %bb12 ]
  %v46 = phi i64 [ %v24, %bb11 ], [ %v58, %bb12 ]
  %v47 = phi i64 [ %v25, %bb11 ], [ %v59, %bb12 ]
  %v48 = phi i64 [ %v26, %bb11 ], [ %v60, %bb12 ]
  %v49 = phi i64 [ %v29, %bb11 ], [ %v61, %bb12 ]
  %v50 = phi ptr [ %v40, %bb11 ], [ %v62, %bb12 ]
  %v70 = select i1 true, i64 1, i64 1
  %v71 = add nuw i64 %v48, %v70
  %v72 = icmp ult i64 %v71, %v47
  switch i1 %v72, label %invalid.tag.b8 [
    i1 1, label %bb16
    i1 0, label %bb17
  ]
invalid.tag.b8:
  unreachable
bb9:
  %t13 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %v40, i32 0, i32 1
  %v51 = getelementptr i8, ptr %t13, i64 0
  %t14 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %v40, i32 0, i32 2
  %v52 = getelementptr i8, ptr %t14, i64 0
  %v53 = call i1 @wf_map_cost_equal(ptr %v22, ptr %v51, ptr %v21)
  switch i1 %v53, label %invalid.tag.b9 [
    i1 1, label %bb13
    i1 0, label %bb14
  ]
invalid.tag.b9:
  unreachable
bb10:
  %v68 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t15 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t15
  %t16 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v68, ptr %t16
  ret void
bb11:
  br label %bb8
bb12:
  %v54 = phi ptr [ %v20, %bb14 ]
  %v55 = phi ptr [ %v21, %bb14 ]
  %v56 = phi ptr [ %v22, %bb14 ]
  %v57 = phi ptr [ %v23, %bb14 ]
  %v58 = phi i64 [ %v24, %bb14 ]
  %v59 = phi i64 [ %v25, %bb14 ]
  %v60 = phi i64 [ %v26, %bb14 ]
  %v61 = phi i64 [ %v29, %bb14 ]
  %v62 = phi ptr [ %v40, %bb14 ]
  %v63 = phi ptr [ %v51, %bb14 ]
  %v64 = phi ptr [ %v52, %bb14 ]
  %v65 = phi i1 [ %v53, %bb14 ]
  br label %bb8
bb13:
  %v66 = call i64 @wf_map_cost_record_observe(ptr %v23, ptr %v51, ptr %v52)
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t17 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t17
  %t18 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 1
  store i64 %v66, ptr %t18
  ret void
bb14:
  br label %bb12
bb15:
  %v73 = phi ptr [ %v42, %bb16 ], [ %v42, %bb17 ]
  %v74 = phi ptr [ %v43, %bb16 ], [ %v43, %bb17 ]
  %v75 = phi ptr [ %v44, %bb16 ], [ %v44, %bb17 ]
  %v76 = phi ptr [ %v45, %bb16 ], [ %v45, %bb17 ]
  %v77 = phi i64 [ %v46, %bb16 ], [ %v46, %bb17 ]
  %v78 = phi i64 [ %v47, %bb16 ], [ %v47, %bb17 ]
  %v79 = phi i64 [ %v71, %bb16 ], [ %v83, %bb17 ]
  %v80 = phi i64 [ %v49, %bb16 ], [ %v49, %bb17 ]
  %v81 = phi ptr [ %v50, %bb16 ], [ %v50, %bb17 ]
  %v82 = phi i64 [ %v71, %bb16 ], [ %v71, %bb17 ]
  br label %bb18
bb16:
  br label %bb15
bb17:
  %v83 = select i1 true, i64 0, i64 0
  br label %bb15
bb18:
  %v84 = phi ptr [ %v73, %bb15 ]
  %v85 = phi ptr [ %v74, %bb15 ]
  %v86 = phi ptr [ %v75, %bb15 ]
  %v87 = phi ptr [ %v76, %bb15 ]
  %v88 = phi i64 [ %v77, %bb15 ]
  %v89 = phi i64 [ %v78, %bb15 ]
  %v90 = phi i64 [ %v79, %bb15 ]
  %v91 = phi i64 [ %v27, %bb15 ]
  %v92 = phi i64 [ %v28, %bb15 ]
  %v93 = phi i64 [ %v29, %bb15 ]
  %v94 = select i1 true, i64 1, i64 1
  %v95 = add i64 %v93, %v94
  br label %bb4
}

define %wf.t.b7e1ed626c09888a @wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe(ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2, ptr noalias nonnull captures(none) dereferenceable(32) %v3) #0 {
entry:
  %wf.result = alloca %wf.t.b7e1ed626c09888a, align 8
  call void @wf_std.collections.hash_map.hash_map_lookup$instance$000400fb603e42fe.body(ptr %wf.result, ptr %v0, ptr %v1, ptr %v2, ptr %v3)
  %wf.returned = load %wf.t.b7e1ed626c09888a, ptr %wf.result
  ret %wf.t.b7e1ed626c09888a %wf.returned
}

define internal void @wf_std.collections.hash_map.hash_map_rehash$instance$28da32efc51c2b65.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(16) %v1) #0 {
entry:
  %t0 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v0, i32 0, i32 0
  %v2 = getelementptr i8, ptr %t0, i64 0
  %v3 = getelementptr i8, ptr %v2, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v3, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v4 = add i64 %t1, 0
  %v5 = call %wf.t.7d7f918f7b4962fd @wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65(ptr %v0, i64 %v4, ptr %v1)
  store %wf.t.7d7f918f7b4962fd %v5, ptr %wf.result
  ret void
}

define %wf.t.7d7f918f7b4962fd @wf_std.collections.hash_map.hash_map_rehash$instance$28da32efc51c2b65(ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(16) %v1) #0 {
entry:
  %wf.result = alloca %wf.t.7d7f918f7b4962fd, align 4
  call void @wf_std.collections.hash_map.hash_map_rehash$instance$28da32efc51c2b65.body(ptr %wf.result, ptr %v0, ptr %v1)
  %wf.returned = load %wf.t.7d7f918f7b4962fd, ptr %wf.result
  ret %wf.t.7d7f918f7b4962fd %wf.returned
}

define internal void @wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %v3 = select i1 true, i64 16384, i64 16384
  %v4 = icmp ugt i64 %v1, %v3
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v5 = phi ptr [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb3 ]
  %v7 = phi ptr [ %v2, %bb3 ]
  %t0 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v5, i32 0, i32 0
  %v10 = getelementptr i8, ptr %t0, i64 0
  %v11 = getelementptr i8, ptr %v10, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v11, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v12 = add i64 %t1, 0
  %v13 = icmp ule i64 %v6, %v12
  switch i1 %v13, label %invalid.tag.b1 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v8 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t3 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t3
  %t4 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 2
  store i8 %v8, ptr %t4
  ret void
bb3:
  br label %bb1
bb4:
  %v14 = phi ptr [ %v5, %bb6 ]
  %v15 = phi i64 [ %v6, %bb6 ]
  %v16 = phi ptr [ %v7, %bb6 ]
  %v19 = call %wf.t.7d7f918f7b4962fd @wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65(ptr %v14, i64 %v15, ptr %v16)
  store %wf.t.7d7f918f7b4962fd %v19, ptr %wf.result
  ret void
bb5:
  %v17 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t5 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t5
  %t6 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 1
  store i8 %v17, ptr %t6
  ret void
bb6:
  br label %bb4
}

define %wf.t.7d7f918f7b4962fd @wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65(ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.result = alloca %wf.t.7d7f918f7b4962fd, align 4
  call void @wf_std.collections.hash_map.hash_map_reserve$instance$28da32efc51c2b65.body(ptr %wf.result, ptr %v0, i64 %v1, ptr %v2)
  %wf.returned = load %wf.t.7d7f918f7b4962fd, ptr %wf.result
  ret %wf.t.7d7f918f7b4962fd %wf.returned
}

define i64 @wf_std.collections.hash_map.hash_map_capacity$instance$0e108827ecbbe374(ptr noalias nonnull captures(none) dereferenceable(40) %v0) #0 {
entry:
  %t0 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v0, i32 0, i32 0
  %v1 = getelementptr i8, ptr %t0, i64 0
  %v2 = getelementptr i8, ptr %v1, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v2, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v3 = add i64 %t1, 0
  ret i64 %v3
}

define internal void @wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2, ptr noalias nonnull captures(none) dereferenceable(32) %v3) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.dceb7b9db1c9ad1d, align 8
  %v4 = call i64 @wf_map_cost_hash(ptr %v2, ptr %v1)
  %t0 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v0, i32 0, i32 0
  %v5 = getelementptr i8, ptr %t0, i64 0
  %v6 = getelementptr i8, ptr %v5, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v6, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v7 = add i64 %t1, 0
  %v8 = select i1 true, i64 0, i64 0
  br label %bb1
bb1:
  %v9 = phi ptr [ %v0, %entry ], [ %v61, %bb12 ]
  %v10 = phi ptr [ %v1, %entry ], [ %v62, %bb12 ]
  %v11 = phi ptr [ %v2, %entry ], [ %v63, %bb12 ]
  %v12 = phi ptr [ %v3, %entry ], [ %v64, %bb12 ]
  %v13 = phi i64 [ %v4, %entry ], [ %v65, %bb12 ]
  %v14 = phi i64 [ %v7, %entry ], [ %v66, %bb12 ]
  %v15 = phi i64 [ %v8, %entry ], [ %v67, %bb12 ]
  %v16 = phi i64 [ %v7, %entry ], [ %v68, %bb12 ]
  %v17 = phi i64 [ %v8, %entry ], [ %v71, %bb12 ]
  %v24 = icmp ult i64 %v17, %v16
  switch i1 %v24, label %invalid.tag.b1 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v25 = urem i64 %v13, %v14
  %v26 = call i64 @wf_std.collections.hash_map.hash_map_probe(i64 %v25, i64 %v17, i64 %v14)
  %t3 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v9, i32 0, i32 0
  %v27 = getelementptr i8, ptr %t3, i64 0
  %v28 = getelementptr i8, ptr %v27, i64 0
  %t5 = getelementptr inbounds { i64, i64, ptr }, ptr %v28, i32 0, i32 2
  %t6 = load ptr, ptr %t5
  %t4.nonnegative = icmp sge i64 %v26, 0
  call void @llvm.assume(i1 %t4.nonnegative)
  %t4 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %t6, i64 %v26
  %v29 = getelementptr i8, ptr %t4, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v29, i64 ptrtoint (ptr getelementptr (%wf.t.dceb7b9db1c9ad1d, ptr null, i32 1) to i64), i1 false)
  %t7 = load %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.0
  %t8 = extractvalue %wf.t.dceb7b9db1c9ad1d %t7, 0
  switch i32 %t8, label %invalid.tag.b2 [
    i32 2, label %bb6
    i32 0, label %bb7
    i32 1, label %bb8
  ]
invalid.tag.b2:
  unreachable
bb3:
  br label %bb4
bb4:
  %v18 = phi ptr [ %v9, %bb3 ]
  %v19 = phi ptr [ %v10, %bb3 ]
  %v20 = phi ptr [ %v11, %bb3 ]
  %v21 = phi ptr [ %v12, %bb3 ]
  %v22 = phi i64 [ %v13, %bb3 ]
  %v23 = phi i64 [ %v14, %bb3 ]
  %v72 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t9 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t9
  %t10 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v72, ptr %t10
  ret void
bb5:
  %v31 = phi ptr [ %v9, %bb8 ], [ %v44, %bb9 ]
  %v32 = phi ptr [ %v10, %bb8 ], [ %v45, %bb9 ]
  %v33 = phi ptr [ %v11, %bb8 ], [ %v46, %bb9 ]
  %v34 = phi ptr [ %v12, %bb8 ], [ %v47, %bb9 ]
  %v35 = phi i64 [ %v13, %bb8 ], [ %v48, %bb9 ]
  %v36 = phi i64 [ %v14, %bb8 ], [ %v49, %bb9 ]
  %v37 = phi i64 [ %v17, %bb8 ], [ %v50, %bb9 ]
  %v38 = phi i64 [ %v25, %bb8 ], [ %v51, %bb9 ]
  %v39 = phi i64 [ %v26, %bb8 ], [ %v52, %bb9 ]
  %v40 = phi ptr [ %v29, %bb8 ], [ %v53, %bb9 ]
  br label %bb12
bb6:
  %t11 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %v29, i32 0, i32 1
  %v41 = getelementptr i8, ptr %t11, i64 0
  %t12 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %v29, i32 0, i32 2
  %v42 = getelementptr i8, ptr %t12, i64 0
  %v43 = call i1 @wf_map_cost_equal(ptr %v11, ptr %v41, ptr %v10)
  switch i1 %v43, label %invalid.tag.b6 [
    i1 1, label %bb10
    i1 0, label %bb11
  ]
invalid.tag.b6:
  unreachable
bb7:
  %v59 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t13 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t13
  %t14 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v59, ptr %t14
  ret void
bb8:
  br label %bb5
bb9:
  %v44 = phi ptr [ %v9, %bb11 ]
  %v45 = phi ptr [ %v10, %bb11 ]
  %v46 = phi ptr [ %v11, %bb11 ]
  %v47 = phi ptr [ %v12, %bb11 ]
  %v48 = phi i64 [ %v13, %bb11 ]
  %v49 = phi i64 [ %v14, %bb11 ]
  %v50 = phi i64 [ %v17, %bb11 ]
  %v51 = phi i64 [ %v25, %bb11 ]
  %v52 = phi i64 [ %v26, %bb11 ]
  %v53 = phi ptr [ %v29, %bb11 ]
  %v54 = phi ptr [ %v41, %bb11 ]
  %v55 = phi ptr [ %v42, %bb11 ]
  %v56 = phi i1 [ %v43, %bb11 ]
  br label %bb5
bb10:
  %v57 = call i64 @wf_map_cost_record_edit(ptr %v12, ptr %v41, ptr %v42)
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t15 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t15
  %t16 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 1
  store i64 %v57, ptr %t16
  ret void
bb11:
  br label %bb9
bb12:
  %v61 = phi ptr [ %v31, %bb5 ]
  %v62 = phi ptr [ %v32, %bb5 ]
  %v63 = phi ptr [ %v33, %bb5 ]
  %v64 = phi ptr [ %v34, %bb5 ]
  %v65 = phi i64 [ %v35, %bb5 ]
  %v66 = phi i64 [ %v36, %bb5 ]
  %v67 = phi i64 [ %v15, %bb5 ]
  %v68 = phi i64 [ %v16, %bb5 ]
  %v69 = phi i64 [ %v17, %bb5 ]
  %v70 = select i1 true, i64 1, i64 1
  %v71 = add i64 %v69, %v70
  br label %bb1
}

define %wf.t.b7e1ed626c09888a @wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49(ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2, ptr noalias nonnull captures(none) dereferenceable(32) %v3) #0 {
entry:
  %wf.result = alloca %wf.t.b7e1ed626c09888a, align 8
  call void @wf_std.collections.hash_map.hash_map_edit$instance$ec3fd08e444cbe49.body(ptr %wf.result, ptr %v0, ptr %v1, ptr %v2, ptr %v3)
  %wf.returned = load %wf.t.b7e1ed626c09888a, ptr %wf.result
  ret %wf.t.b7e1ed626c09888a %wf.returned
}

define i8 @wf_std.collections.hash_map.hash_map_free$instance$d5f8785ab7665d71(ptr %wf.arg.v0, ptr noalias nonnull captures(none) dereferenceable(32) %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.588b2641b8ac7d45, align 8
  %wf.slot.1 = alloca %wf.t.dceb7b9db1c9ad1d, align 8
  %wf.slot.2 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.3 = alloca { i64, i64, ptr }, align 8
  %v3 = alloca { i64, i64, ptr }, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v0, i64 ptrtoint (ptr getelementptr (%wf.t.588b2641b8ac7d45, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %wf.slot.0, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %v3, ptr %t0, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %t1 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %wf.slot.0, i32 0, i32 1
  %v4 = load i64, ptr %t1
  ; ownership-consuming projection
  %t2 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %wf.slot.0, i32 0, i32 2
  %v5 = load i64, ptr %t2
  ; ownership-consuming projection
  br label %bb1
bb1:
  %v7 = phi ptr [ %v1, %entry ], [ %v28, %bb6 ]
  %v8 = phi ptr [ %v3, %entry ], [ %v29, %bb6 ]
  %v9 = phi i64 [ %v4, %entry ], [ %v30, %bb6 ]
  %v10 = phi i64 [ %v5, %entry ], [ %v31, %bb6 ]
  %v16 = getelementptr i8, ptr %v8, i64 0
  %t4 = getelementptr inbounds { i64, i64, ptr }, ptr %v16, i32 0, i32 0
  %t3 = load i64, ptr %t4
  %v17 = add i64 %t3, 0
  %v18 = select i1 true, i64 0, i64 0
  %v19 = icmp eq i64 %v17, %v18
  switch i1 %v19, label %invalid.tag.b1 [
    i1 1, label %bb4
    i1 0, label %bb5
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v12 = phi ptr [ %v7, %bb4 ]
  %v13 = phi ptr [ %v8, %bb4 ]
  %v14 = phi i64 [ %v9, %bb4 ]
  %v15 = phi i64 [ %v10, %bb4 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.3, ptr %v13, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  %v37 = call i8 @wf_free_empty$instance$d692d011b23a4a18(ptr %wf.slot.3)
  %v38 = select i1 true, i8 0, i8 0
  ret i8 %v38
bb3:
  %v21 = phi ptr [ %v7, %bb5 ]
  %v22 = phi ptr [ %v8, %bb5 ]
  %v23 = phi i64 [ %v9, %bb5 ]
  %v24 = phi i64 [ %v10, %bb5 ]
  %v25 = getelementptr i8, ptr %v22, i64 0
  call void @wf_take_back$instance$d5bb00f00cd669fb(ptr %wf.slot.1, ptr %v25)
  %t5 = load %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.1
  %t6 = extractvalue %wf.t.dceb7b9db1c9ad1d %t5, 0
  switch i32 %t6, label %invalid.tag.b3 [
    i32 2, label %bb7
    i32 0, label %bb8
    i32 1, label %bb9
  ]
invalid.tag.b3:
  unreachable
bb4:
  br label %bb2
bb5:
  br label %bb3
bb6:
  %v28 = phi ptr [ %v21, %bb7 ], [ %v21, %bb8 ], [ %v21, %bb9 ]
  %v29 = phi ptr [ %v22, %bb7 ], [ %v22, %bb8 ], [ %v22, %bb9 ]
  %v30 = phi i64 [ %v23, %bb7 ], [ %v23, %bb8 ], [ %v23, %bb9 ]
  %v31 = phi i64 [ %v24, %bb7 ], [ %v24, %bb8 ], [ %v24, %bb9 ]
  br label %bb1
bb7:
  %t7 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.1, i32 0, i32 1
  %v33 = load i64, ptr %t7
  %t8 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.1, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %t8, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %v35 = call i8 @wf_map_cost_record_consume(ptr %v21, i64 %v33, ptr %wf.slot.2)
  br label %bb6
bb8:
  br label %bb6
bb9:
  br label %bb6
}

define i64 @wf_std.collections.hash_map.hash_map_len$instance$820b2044b97e0fbd(ptr noalias nonnull captures(none) dereferenceable(40) %v0) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.0a5f51efa7ad5b17, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.0a5f51efa7ad5b17, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %wf.slot.0, i32 0, i32 1
  %v2 = load i64, ptr %t0
  ret i64 %v2
}

define i64 @wf_std.collections.hash_map.hash_map_len$instance$0e108827ecbbe374(ptr noalias nonnull captures(none) dereferenceable(40) %v0) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.588b2641b8ac7d45, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.588b2641b8ac7d45, ptr null, i32 1) to i64), i1 false)
  %t0 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %wf.slot.0, i32 0, i32 1
  %v2 = load i64, ptr %t0
  ret i64 %v2
}

define internal void @wf_box_slots_new$instance$b45b69d9d0c6bbd0.body(ptr %wf.result, i64 %v0) #0 {
entry:
  %t0 = mul nuw i64 %v0, ptrtoint (ptr getelementptr (%wf.t.a1df460b0959673f, ptr null, i64 1) to i64)
  %t1 = icmp eq i64 %t0, 0
  br i1 %t1, label %window.payload.empty.v1, label %window.payload.allocate.v1
window.payload.empty.v1:
  br label %window.block.ready.v1
window.payload.allocate.v1:
  %t3 = call ptr @malloc(i64 %t0)
  %t4 = icmp ne ptr %t3, null
  br i1 %t4, label %window.block.ready.v1, label %window.block.oom.v1
window.block.oom.v1:
  call void @wf_resource_abort()
  unreachable
window.block.ready.v1:
  %t2 = phi ptr [ @.wf.empty.slots.payload, %window.payload.empty.v1 ], [ %t3, %window.payload.allocate.v1 ]
  %t5 = getelementptr inbounds { i64, i64, ptr }, ptr %wf.result, i32 0, i32 0
  %t6 = getelementptr inbounds { i64, i64, ptr }, ptr %wf.result, i32 0, i32 1
  %t7 = getelementptr inbounds { i64, i64, ptr }, ptr %wf.result, i32 0, i32 2
  store i64 0, ptr %t5
  store i64 %v0, ptr %t6
  store ptr %t2, ptr %t7
  ret void
}

define { i64, i64, ptr } @wf_box_slots_new$instance$b45b69d9d0c6bbd0(i64 %v0) #0 {
entry:
  %wf.result = alloca { i64, i64, ptr }, align 8
  call void @wf_box_slots_new$instance$b45b69d9d0c6bbd0.body(ptr %wf.result, i64 %v0)
  %wf.returned = load { i64, i64, ptr }, ptr %wf.result
  ret { i64, i64, ptr } %wf.returned
}

define i8 @wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca(ptr noalias nonnull captures(none) dereferenceable(24) %v0, i64 %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.a1df460b0959673f, align 8
  %v2 = getelementptr i8, ptr %v0, i64 0
  %t1 = getelementptr inbounds { i64, i64, ptr }, ptr %v2, i32 0, i32 1
  %t0 = load i64, ptr %t1
  %v3 = add i64 %t0, 0
  %v4 = icmp ult i64 %v3, %v1
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v5 = phi ptr [ %v0, %bb2 ], [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb2 ], [ %v1, %bb3 ]
  %v8 = getelementptr i8, ptr %v5, i64 0
  %t3 = getelementptr inbounds { i64, i64, ptr }, ptr %v8, i32 0, i32 0
  %t2 = load i64, ptr %t3
  %v9 = add i64 %t2, 0
  br label %bb4
bb2:
  %v7 = call i8 @wf_grow$instance$b45b69d9d0c6bbd0(ptr %v0, i64 %v1)
  br label %bb1
bb3:
  br label %bb1
bb4:
  %v10 = phi ptr [ %v5, %bb1 ], [ %v23, %bb8 ]
  %v11 = phi i64 [ %v6, %bb1 ], [ %v24, %bb8 ]
  %v12 = phi i64 [ %v9, %bb1 ], [ %v25, %bb8 ]
  %v13 = phi i64 [ %v9, %bb1 ], [ %v26, %bb8 ]
  %v14 = phi i64 [ %v6, %bb1 ], [ %v27, %bb8 ]
  %v15 = phi i64 [ %v9, %bb1 ], [ %v30, %bb8 ]
  %v19 = icmp ult i64 %v15, %v14
  switch i1 %v19, label %invalid.tag.b4 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b4:
  unreachable
bb5:
  store %wf.t.a1df460b0959673f zeroinitializer, ptr %wf.slot.0
  %t4 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %wf.slot.0, i32 0, i32 0
  store i32 0, ptr %t4
  %v21 = getelementptr i8, ptr %v10, i64 0
  %v22 = call i8 @wf_place_back$instance$9985a87b1cb96650(ptr %v21, ptr %wf.slot.0)
  br label %bb8
bb6:
  br label %bb7
bb7:
  %v16 = phi ptr [ %v10, %bb6 ]
  %v17 = phi i64 [ %v11, %bb6 ]
  %v18 = phi i64 [ %v12, %bb6 ]
  %v31 = select i1 true, i8 0, i8 0
  ret i8 %v31
bb8:
  %v23 = phi ptr [ %v10, %bb5 ]
  %v24 = phi i64 [ %v11, %bb5 ]
  %v25 = phi i64 [ %v12, %bb5 ]
  %v26 = phi i64 [ %v13, %bb5 ]
  %v27 = phi i64 [ %v14, %bb5 ]
  %v28 = phi i64 [ %v15, %bb5 ]
  %v29 = select i1 true, i64 1, i64 1
  %v30 = add i64 %v28, %v29
  br label %bb4
}

define internal void @wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.a1df460b0959673f, align 8
  %wf.slot.1 = alloca { i64, [1 x %wf.t.c5066f96ffdbc504] }, align 8
  %wf.slot.2 = alloca %wf.t.c5066f96ffdbc504, align 8
  %wf.slot.3 = alloca %wf.t.c5066f96ffdbc504, align 8
  %wf.slot.4 = alloca %wf.t.5591089753cba638, align 8
  %wf.slot.5 = alloca %wf.t.c5066f96ffdbc504, align 8
  %wf.slot.6 = alloca { i64, [1 x %wf.t.c5066f96ffdbc504] }, align 8
  %wf.slot.7 = alloca { i64, i64, ptr }, align 8
  %v29 = alloca { i64, i64, ptr }, align 8
  %v63 = alloca { i64, [1 x %wf.t.c5066f96ffdbc504] }, align 8
  %v3 = select i1 true, i64 3, i64 3
  %v4 = icmp ugt i64 %v1, %v3
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v5 = phi ptr [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb3 ]
  %v7 = phi ptr [ %v2, %bb3 ]
  %t0 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %v5, i32 0, i32 0
  %v10 = getelementptr i8, ptr %t0, i64 0
  %v11 = getelementptr i8, ptr %v10, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v11, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v12 = add i64 %t1, 0
  %v13 = icmp ult i64 %v6, %v12
  switch i1 %v13, label %invalid.tag.b1 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v8 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t3 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t3
  %t4 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 2
  store i8 %v8, ptr %t4
  ret void
bb3:
  br label %bb1
bb4:
  %v14 = phi ptr [ %v5, %bb6 ]
  %v15 = phi i64 [ %v6, %bb6 ]
  %v16 = phi ptr [ %v7, %bb6 ]
  %v17 = phi i64 [ %v12, %bb6 ]
  %v20 = select i1 true, i64 0, i64 0
  %v21 = icmp eq i64 %v15, %v20
  switch i1 %v21, label %invalid.tag.b4 [
    i1 1, label %bb8
    i1 0, label %bb9
  ]
invalid.tag.b4:
  unreachable
bb5:
  %v18 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t5 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t5
  %t6 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 2
  store i8 %v18, ptr %t6
  ret void
bb6:
  br label %bb4
bb7:
  %v22 = phi ptr [ %v14, %bb9 ]
  %v23 = phi i64 [ %v15, %bb9 ]
  %v24 = phi ptr [ %v16, %bb9 ]
  %v25 = phi i64 [ %v17, %bb9 ]
  %v28 = call { i64, i64, ptr } @wf_box_slots_new$instance$b45b69d9d0c6bbd0(i64 %v23)
  store { i64, i64, ptr } %v28, ptr %v29
  %v30 = call i8 @wf_std.collections.hash_map.hash_map_extend$instance$a62a753cf2b0b5ca(ptr %v29, i64 %v23)
  %t7 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %v22, i32 0, i32 0
  %v31 = getelementptr i8, ptr %t7, i64 0
  %v32 = call i8 @wf_swap$instance$43608765810d87c7(ptr %v31, ptr %v29)
  br label %bb10
bb8:
  %v26 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t8 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t8
  %t9 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 1
  store i8 %v26, ptr %t9
  ret void
bb9:
  br label %bb7
bb10:
  %v33 = phi ptr [ %v22, %bb7 ], [ %v54, %bb15 ]
  %v34 = phi i64 [ %v23, %bb7 ], [ %v55, %bb15 ]
  %v35 = phi ptr [ %v24, %bb7 ], [ %v56, %bb15 ]
  %v36 = phi i64 [ %v25, %bb7 ], [ %v57, %bb15 ]
  %v37 = phi ptr [ %v29, %bb7 ], [ %v58, %bb15 ]
  %v43 = getelementptr i8, ptr %v37, i64 0
  %t11 = getelementptr inbounds { i64, i64, ptr }, ptr %v43, i32 0, i32 0
  %t10 = load i64, ptr %t11
  %v44 = add i64 %t10, 0
  %v45 = select i1 true, i64 0, i64 0
  %v46 = icmp eq i64 %v44, %v45
  switch i1 %v46, label %invalid.tag.b10 [
    i1 1, label %bb13
    i1 0, label %bb14
  ]
invalid.tag.b10:
  unreachable
bb11:
  %v38 = phi ptr [ %v33, %bb13 ]
  %v39 = phi i64 [ %v34, %bb13 ]
  %v40 = phi ptr [ %v35, %bb13 ]
  %v41 = phi i64 [ %v36, %bb13 ]
  %v42 = phi ptr [ %v37, %bb13 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.7, ptr %v42, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  %v205 = call i8 @wf_free_empty$instance$43608765810d87c7(ptr %wf.slot.7)
  %t12 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %v38, i32 0, i32 2
  %v206 = getelementptr i8, ptr %t12, i64 0
  %v207 = select i1 true, i64 0, i64 0
  store i64 %v207, ptr %v206
  %v208 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t13 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t13
  %t14 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 1
  store i8 %v208, ptr %t14
  ret void
bb12:
  %v47 = phi ptr [ %v33, %bb14 ]
  %v48 = phi i64 [ %v34, %bb14 ]
  %v49 = phi ptr [ %v35, %bb14 ]
  %v50 = phi i64 [ %v36, %bb14 ]
  %v51 = phi ptr [ %v37, %bb14 ]
  %v52 = getelementptr i8, ptr %v51, i64 0
  %v53 = call %wf.t.a1df460b0959673f @wf_take_back$instance$9985a87b1cb96650(ptr %v52)
  store %wf.t.a1df460b0959673f %v53, ptr %wf.slot.0
  %t15 = load %wf.t.a1df460b0959673f, ptr %wf.slot.0
  %t16 = extractvalue %wf.t.a1df460b0959673f %t15, 0
  switch i32 %t16, label %invalid.tag.b12 [
    i32 0, label %bb16
    i32 1, label %bb17
    i32 2, label %bb18
  ]
invalid.tag.b12:
  unreachable
bb13:
  br label %bb11
bb14:
  br label %bb12
bb15:
  %v54 = phi ptr [ %v47, %bb16 ], [ %v47, %bb17 ], [ %v76, %bb20 ]
  %v55 = phi i64 [ %v48, %bb16 ], [ %v48, %bb17 ], [ %v77, %bb20 ]
  %v56 = phi ptr [ %v49, %bb16 ], [ %v49, %bb17 ], [ %v78, %bb20 ]
  %v57 = phi i64 [ %v50, %bb16 ], [ %v50, %bb17 ], [ %v79, %bb20 ]
  %v58 = phi ptr [ %v51, %bb16 ], [ %v51, %bb17 ], [ %v80, %bb20 ]
  br label %bb10
bb16:
  br label %bb15
bb17:
  br label %bb15
bb18:
  %t17 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %wf.slot.0, i32 0, i32 1
  %v60 = load i64, ptr %t17
  %t18 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %wf.slot.0, i32 0, i32 2
  %v61 = load i64, ptr %t18
  %v62 = call { i64, [1 x %wf.t.c5066f96ffdbc504] } @wf_slots_new$instance$15df03c28018958d()
  store { i64, [1 x %wf.t.c5066f96ffdbc504] } %v62, ptr %wf.slot.1
  call void @llvm.memmove.p0.p0.i64(ptr %v63, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr ({ i64, [1 x %wf.t.c5066f96ffdbc504] }, ptr null, i32 1) to i64), i1 false)
  store %wf.t.c5066f96ffdbc504 zeroinitializer, ptr %wf.slot.2
  %t19 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.2, i32 0, i32 0
  store i64 %v60, ptr %t19
  %t20 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.2, i32 0, i32 1
  store i64 %v61, ptr %t20
  %v65 = call i8 @wf_place_back$instance$a6542e06bf5acd99(ptr %v63, ptr %wf.slot.2)
  br label %bb19
bb19:
  %v66 = phi ptr [ %v47, %bb18 ], [ %v122, %bb27 ]
  %v67 = phi i64 [ %v48, %bb18 ], [ %v123, %bb27 ]
  %v68 = phi ptr [ %v49, %bb18 ], [ %v124, %bb27 ]
  %v69 = phi i64 [ %v50, %bb18 ], [ %v125, %bb27 ]
  %v70 = phi ptr [ %v51, %bb18 ], [ %v126, %bb27 ]
  %v72 = phi i64 [ %v60, %bb18 ], [ %v128, %bb27 ]
  %v73 = phi i64 [ %v61, %bb18 ], [ %v129, %bb27 ]
  %v74 = phi ptr [ %v63, %bb18 ], [ %v130, %bb27 ]
  %t22 = getelementptr inbounds { i64, [1 x %wf.t.c5066f96ffdbc504] }, ptr %v74, i32 0, i32 0
  %t21 = load i64, ptr %t22
  %v86 = add i64 %t21, 0
  %v87 = select i1 true, i64 0, i64 0
  %v88 = icmp eq i64 %v86, %v87
  switch i1 %v88, label %invalid.tag.b19 [
    i1 1, label %bb22
    i1 0, label %bb23
  ]
invalid.tag.b19:
  unreachable
bb20:
  %v76 = phi ptr [ %v66, %bb22 ]
  %v77 = phi i64 [ %v67, %bb22 ]
  %v78 = phi ptr [ %v68, %bb22 ]
  %v79 = phi i64 [ %v69, %bb22 ]
  %v80 = phi ptr [ %v70, %bb22 ]
  %v82 = phi i64 [ %v72, %bb22 ]
  %v83 = phi i64 [ %v73, %bb22 ]
  %v84 = phi ptr [ %v74, %bb22 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.6, ptr %v84, i64 ptrtoint (ptr getelementptr ({ i64, [1 x %wf.t.c5066f96ffdbc504] }, ptr null, i32 1) to i64), i1 false)
  %v203 = call i8 @wf_free_empty$instance$bb96e2f57d31495e(ptr %wf.slot.6)
  br label %bb15
bb21:
  %v89 = phi ptr [ %v66, %bb23 ]
  %v90 = phi i64 [ %v67, %bb23 ]
  %v91 = phi ptr [ %v68, %bb23 ]
  %v92 = phi i64 [ %v69, %bb23 ]
  %v93 = phi ptr [ %v70, %bb23 ]
  %v95 = phi i64 [ %v72, %bb23 ]
  %v96 = phi i64 [ %v73, %bb23 ]
  %v97 = phi ptr [ %v74, %bb23 ]
  %v99 = select i1 true, i64 0, i64 0
  %t23.nonnegative = icmp sge i64 %v99, 0
  call void @llvm.assume(i1 %t23.nonnegative)
  %t23 = getelementptr inbounds { i64, [1 x %wf.t.c5066f96ffdbc504] }, ptr %v97, i64 0, i32 1, i64 %v99
  %v100 = getelementptr i8, ptr %t23, i64 0
  %t24 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %v100, i32 0, i32 0
  %v101 = getelementptr i8, ptr %t24, i64 0
  %v102 = call i64 @wf_map_cost_hash(ptr %v91, ptr %v101)
  %t25 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %v89, i32 0, i32 0
  %v103 = getelementptr i8, ptr %t25, i64 0
  %v104 = getelementptr i8, ptr %v103, i64 0
  %t27 = getelementptr inbounds { i64, i64, ptr }, ptr %v104, i32 0, i32 0
  %t26 = load i64, ptr %t27
  %v105 = add i64 %t26, 0
  %v106 = select i1 true, i64 0, i64 0
  br label %bb24
bb22:
  br label %bb20
bb23:
  br label %bb21
bb24:
  %v107 = phi ptr [ %v89, %bb21 ], [ %v185, %bb34 ]
  %v108 = phi i64 [ %v90, %bb21 ], [ %v186, %bb34 ]
  %v109 = phi ptr [ %v91, %bb21 ], [ %v187, %bb34 ]
  %v110 = phi i64 [ %v92, %bb21 ], [ %v188, %bb34 ]
  %v111 = phi ptr [ %v93, %bb21 ], [ %v189, %bb34 ]
  %v113 = phi i64 [ %v95, %bb21 ], [ %v191, %bb34 ]
  %v114 = phi i64 [ %v96, %bb21 ], [ %v192, %bb34 ]
  %v115 = phi ptr [ %v97, %bb21 ], [ %v193, %bb34 ]
  %v117 = phi i64 [ %v102, %bb21 ], [ %v195, %bb34 ]
  %v118 = phi i64 [ %v105, %bb21 ], [ %v196, %bb34 ]
  %v119 = phi i64 [ %v106, %bb21 ], [ %v197, %bb34 ]
  %v120 = phi i64 [ %v105, %bb21 ], [ %v198, %bb34 ]
  %v121 = phi i64 [ %v106, %bb21 ], [ %v201, %bb34 ]
  %v134 = icmp ult i64 %v121, %v120
  switch i1 %v134, label %invalid.tag.b24 [
    i1 1, label %bb25
    i1 0, label %bb26
  ]
invalid.tag.b24:
  unreachable
bb25:
  %v135 = urem i64 %v117, %v118
  %v136 = call i64 @wf_std.collections.hash_map.hash_map_probe(i64 %v135, i64 %v121, i64 %v118)
  %t28 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %v107, i32 0, i32 0
  %v137 = getelementptr i8, ptr %t28, i64 0
  %v138 = getelementptr i8, ptr %v137, i64 0
  %t30 = getelementptr inbounds { i64, i64, ptr }, ptr %v138, i32 0, i32 2
  %t31 = load ptr, ptr %t30
  %t29.nonnegative = icmp sge i64 %v136, 0
  call void @llvm.assume(i1 %t29.nonnegative)
  %t29 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %t31, i64 %v136
  %v139 = getelementptr i8, ptr %t29, i64 0
  %v140 = call i1 @wf_std.collections.hash_map.hash_map_is_available$instance$0ed342445dd803f3(ptr %v139)
  switch i1 %v140, label %invalid.tag.b25 [
    i1 1, label %bb29
    i1 0, label %bb30
  ]
invalid.tag.b25:
  unreachable
bb26:
  br label %bb27
bb27:
  %v122 = phi ptr [ %v107, %bb26 ], [ %v162, %bb31 ]
  %v123 = phi i64 [ %v108, %bb26 ], [ %v163, %bb31 ]
  %v124 = phi ptr [ %v109, %bb26 ], [ %v164, %bb31 ]
  %v125 = phi i64 [ %v110, %bb26 ], [ %v165, %bb31 ]
  %v126 = phi ptr [ %v111, %bb26 ], [ %v166, %bb31 ]
  %v128 = phi i64 [ %v113, %bb26 ], [ %v168, %bb31 ]
  %v129 = phi i64 [ %v114, %bb26 ], [ %v169, %bb31 ]
  %v130 = phi ptr [ %v115, %bb26 ], [ %v170, %bb31 ]
  %v132 = phi i64 [ %v117, %bb26 ], [ %v172, %bb31 ]
  %v133 = phi i64 [ %v118, %bb26 ], [ %v173, %bb31 ]
  br label %bb19
bb28:
  %v141 = phi ptr [ %v107, %bb30 ]
  %v142 = phi i64 [ %v108, %bb30 ]
  %v143 = phi ptr [ %v109, %bb30 ]
  %v144 = phi i64 [ %v110, %bb30 ]
  %v145 = phi ptr [ %v111, %bb30 ]
  %v147 = phi i64 [ %v113, %bb30 ]
  %v148 = phi i64 [ %v114, %bb30 ]
  %v149 = phi ptr [ %v115, %bb30 ]
  %v151 = phi i64 [ %v117, %bb30 ]
  %v152 = phi i64 [ %v118, %bb30 ]
  %v153 = phi i64 [ %v121, %bb30 ]
  %v154 = phi i64 [ %v135, %bb30 ]
  %v155 = phi i64 [ %v136, %bb30 ]
  %v156 = phi i1 [ %v140, %bb30 ]
  br label %bb34
bb29:
  %v157 = call %wf.t.c5066f96ffdbc504 @wf_take_back$instance$a6542e06bf5acd99(ptr %v115)
  store %wf.t.c5066f96ffdbc504 %v157, ptr %wf.slot.3
  %t32 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.3, i32 0, i32 0
  %v158 = load i64, ptr %t32
  ; ownership-consuming projection
  %t33 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.3, i32 0, i32 1
  %v159 = load i64, ptr %t33
  ; ownership-consuming projection
  %t34 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %v107, i32 0, i32 0
  %v160 = getelementptr i8, ptr %t34, i64 0
  call void @wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3(ptr %wf.slot.4, ptr %v160, i64 %v136, i64 %v158, i64 %v159)
  %t35 = load %wf.t.5591089753cba638, ptr %wf.slot.4
  %t36 = extractvalue %wf.t.5591089753cba638 %t35, 0
  switch i32 %t36, label %invalid.tag.b29 [
    i32 0, label %bb32
    i32 1, label %bb33
  ]
invalid.tag.b29:
  unreachable
bb30:
  br label %bb28
bb31:
  %v162 = phi ptr [ %v107, %bb32 ], [ %v107, %bb33 ]
  %v163 = phi i64 [ %v108, %bb32 ], [ %v108, %bb33 ]
  %v164 = phi ptr [ %v109, %bb32 ], [ %v109, %bb33 ]
  %v165 = phi i64 [ %v110, %bb32 ], [ %v110, %bb33 ]
  %v166 = phi ptr [ %v111, %bb32 ], [ %v111, %bb33 ]
  %v168 = phi i64 [ %v113, %bb32 ], [ %v113, %bb33 ]
  %v169 = phi i64 [ %v114, %bb32 ], [ %v114, %bb33 ]
  %v170 = phi ptr [ %v115, %bb32 ], [ %v115, %bb33 ]
  %v172 = phi i64 [ %v117, %bb32 ], [ %v117, %bb33 ]
  %v173 = phi i64 [ %v118, %bb32 ], [ %v118, %bb33 ]
  %v174 = phi i64 [ %v121, %bb32 ], [ %v121, %bb33 ]
  %v175 = phi i64 [ %v135, %bb32 ], [ %v135, %bb33 ]
  %v176 = phi i64 [ %v136, %bb32 ], [ %v136, %bb33 ]
  %v177 = phi i1 [ %v140, %bb32 ], [ %v140, %bb33 ]
  %v179 = phi i64 [ %v158, %bb32 ], [ %v158, %bb33 ]
  %v180 = phi i64 [ %v159, %bb32 ], [ %v159, %bb33 ]
  br label %bb27
bb32:
  br label %bb31
bb33:
  %t37 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.slot.4, i32 0, i32 1
  %v182 = load i1, ptr %t37
  %t38 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.slot.4, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.5, ptr %t38, i64 ptrtoint (ptr getelementptr (%wf.t.c5066f96ffdbc504, ptr null, i32 1) to i64), i1 false)
  %v184 = call i8 @wf_place_back$instance$a6542e06bf5acd99(ptr %v115, ptr %wf.slot.5)
  br label %bb31
bb34:
  %v185 = phi ptr [ %v141, %bb28 ]
  %v186 = phi i64 [ %v142, %bb28 ]
  %v187 = phi ptr [ %v143, %bb28 ]
  %v188 = phi i64 [ %v144, %bb28 ]
  %v189 = phi ptr [ %v145, %bb28 ]
  %v191 = phi i64 [ %v147, %bb28 ]
  %v192 = phi i64 [ %v148, %bb28 ]
  %v193 = phi ptr [ %v149, %bb28 ]
  %v195 = phi i64 [ %v151, %bb28 ]
  %v196 = phi i64 [ %v152, %bb28 ]
  %v197 = phi i64 [ %v119, %bb28 ]
  %v198 = phi i64 [ %v120, %bb28 ]
  %v199 = phi i64 [ %v121, %bb28 ]
  %v200 = select i1 true, i64 1, i64 1
  %v201 = add i64 %v199, %v200
  br label %bb24
}

define %wf.t.7d7f918f7b4962fd @wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6(ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.result = alloca %wf.t.7d7f918f7b4962fd, align 4
  call void @wf_std.collections.hash_map.hash_map_rebuild$instance$c7b22b9ef52855b6.body(ptr %wf.result, ptr %v0, i64 %v1, ptr %v2)
  %wf.returned = load %wf.t.7d7f918f7b4962fd, ptr %wf.result
  ret %wf.t.7d7f918f7b4962fd %wf.returned
}

define void @wf_std.collections.hash_map.hash_map_try_put$instance$c7b22b9ef52855b6(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, i64 %v2, ptr noalias nonnull captures(none) dereferenceable(16) %v3) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.fe1d7d6862eac796, align 8
  %wf.slot.1 = alloca %wf.t.fe1d7d6862eac796, align 8
  %wf.slot.2 = alloca %wf.t.c5066f96ffdbc504, align 8
  %v4 = alloca i64, align 8
  store i64 %v1, ptr %v4
  %v5 = call i64 @wf_map_cost_hash(ptr %v3, ptr %v4)
  %t0 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %v0, i32 0, i32 0
  %v6 = getelementptr i8, ptr %t0, i64 0
  %v7 = getelementptr i8, ptr %v6, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v7, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v8 = add i64 %t1, 0
  %v9 = select i1 true, i64 0, i64 0
  %v10 = icmp ugt i64 %v8, %v9
  switch i1 %v10, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v11 = phi ptr [ %v0, %bb3 ], [ %v31, %bb7 ]
  %v12 = phi ptr [ %v4, %bb3 ], [ %v32, %bb7 ]
  %v13 = phi i64 [ %v2, %bb3 ], [ %v33, %bb7 ]
  %v14 = phi ptr [ %v3, %bb3 ], [ %v34, %bb7 ]
  %v15 = phi i64 [ %v5, %bb3 ], [ %v35, %bb7 ]
  %v16 = phi i64 [ %v8, %bb3 ], [ %v36, %bb7 ]
  %v17 = phi i64 [ %v8, %bb3 ], [ %v37, %bb7 ]
  %v107 = icmp ult i64 %v17, %v16
  switch i1 %v107, label %invalid.tag.b1 [
    i1 1, label %bb24
    i1 0, label %bb25
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v18 = urem i64 %v5, %v8
  %v19 = select i1 true, i64 0, i64 0
  br label %bb4
bb3:
  br label %bb1
bb4:
  %v20 = phi ptr [ %v0, %bb2 ], [ %v94, %bb22 ]
  %v21 = phi ptr [ %v4, %bb2 ], [ %v95, %bb22 ]
  %v22 = phi i64 [ %v2, %bb2 ], [ %v96, %bb22 ]
  %v23 = phi ptr [ %v3, %bb2 ], [ %v97, %bb22 ]
  %v24 = phi i64 [ %v5, %bb2 ], [ %v98, %bb22 ]
  %v25 = phi i64 [ %v8, %bb2 ], [ %v99, %bb22 ]
  %v26 = phi i64 [ %v8, %bb2 ], [ %v100, %bb22 ]
  %v27 = phi i64 [ %v18, %bb2 ], [ %v101, %bb22 ]
  %v28 = phi i64 [ %v19, %bb2 ], [ %v102, %bb22 ]
  %v29 = phi i64 [ %v8, %bb2 ], [ %v103, %bb22 ]
  %v30 = phi i64 [ %v19, %bb2 ], [ %v106, %bb22 ]
  %v39 = icmp ult i64 %v30, %v29
  switch i1 %v39, label %invalid.tag.b4 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b4:
  unreachable
bb5:
  %t3 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %v20, i32 0, i32 0
  %v40 = getelementptr i8, ptr %t3, i64 0
  %v41 = getelementptr i8, ptr %v40, i64 0
  %t5 = getelementptr inbounds { i64, i64, ptr }, ptr %v41, i32 0, i32 2
  %t6 = load ptr, ptr %t5
  %t4.nonnegative = icmp sge i64 %v27, 0
  call void @llvm.assume(i1 %t4.nonnegative)
  %t4 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %t6, i64 %v27
  %v42 = getelementptr i8, ptr %t4, i64 0
  %v43 = call i32 @wf_std.collections.hash_map.hash_map_action$instance$fc5e3cb62bdf3601(ptr %v42, ptr %v21, ptr %v23)
  switch i32 %v43, label %invalid.tag.b5 [
    i32 3, label %bb9
    i32 0, label %bb10
    i32 1, label %bb11
    i32 2, label %bb12
  ]
invalid.tag.b5:
  unreachable
bb6:
  br label %bb7
bb7:
  %v31 = phi ptr [ %v20, %bb6 ], [ %v58, %bb13 ]
  %v32 = phi ptr [ %v21, %bb6 ], [ %v59, %bb13 ]
  %v33 = phi i64 [ %v22, %bb6 ], [ %v60, %bb13 ]
  %v34 = phi ptr [ %v23, %bb6 ], [ %v61, %bb13 ]
  %v35 = phi i64 [ %v24, %bb6 ], [ %v62, %bb13 ]
  %v36 = phi i64 [ %v25, %bb6 ], [ %v63, %bb13 ]
  %v37 = phi i64 [ %v26, %bb6 ], [ %v64, %bb13 ]
  %v38 = phi i64 [ %v27, %bb6 ], [ %v65, %bb13 ]
  br label %bb1
bb8:
  %v44 = phi ptr [ %v20, %bb12 ], [ %v69, %bb16 ]
  %v45 = phi ptr [ %v21, %bb12 ], [ %v70, %bb16 ]
  %v46 = phi i64 [ %v22, %bb12 ], [ %v71, %bb16 ]
  %v47 = phi ptr [ %v23, %bb12 ], [ %v72, %bb16 ]
  %v48 = phi i64 [ %v24, %bb12 ], [ %v73, %bb16 ]
  %v49 = phi i64 [ %v25, %bb12 ], [ %v74, %bb16 ]
  %v50 = phi i64 [ %v26, %bb12 ], [ %v75, %bb16 ]
  %v51 = phi i64 [ %v27, %bb12 ], [ %v76, %bb16 ]
  %v52 = phi i64 [ %v30, %bb12 ], [ %v77, %bb16 ]
  %v53 = phi i32 [ %v43, %bb12 ], [ %v78, %bb16 ]
  %v79 = select i1 true, i64 1, i64 1
  %v80 = add nuw i64 %v51, %v79
  %v81 = icmp ult i64 %v80, %v49
  switch i1 %v81, label %invalid.tag.b8 [
    i1 1, label %bb20
    i1 0, label %bb21
  ]
invalid.tag.b8:
  unreachable
bb9:
  %t7 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %v20, i32 0, i32 0
  %v54 = getelementptr i8, ptr %t7, i64 0
  %v55 = load i64, ptr %v21
  call void @wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3(ptr %wf.result, ptr %v54, i64 %v27, i64 %v55, i64 %v22)
  ret void
bb10:
  %v57 = icmp eq i64 %v26, %v25
  switch i1 %v57, label %invalid.tag.b10 [
    i1 1, label %bb14
    i1 0, label %bb15
  ]
invalid.tag.b10:
  unreachable
bb11:
  %v68 = icmp eq i64 %v26, %v25
  switch i1 %v68, label %invalid.tag.b11 [
    i1 1, label %bb17
    i1 0, label %bb18
  ]
invalid.tag.b11:
  unreachable
bb12:
  br label %bb8
bb13:
  %v58 = phi ptr [ %v20, %bb14 ], [ %v20, %bb15 ]
  %v59 = phi ptr [ %v21, %bb14 ], [ %v21, %bb15 ]
  %v60 = phi i64 [ %v22, %bb14 ], [ %v22, %bb15 ]
  %v61 = phi ptr [ %v23, %bb14 ], [ %v23, %bb15 ]
  %v62 = phi i64 [ %v24, %bb14 ], [ %v24, %bb15 ]
  %v63 = phi i64 [ %v25, %bb14 ], [ %v25, %bb15 ]
  %v64 = phi i64 [ %v27, %bb14 ], [ %v26, %bb15 ]
  %v65 = phi i64 [ %v27, %bb14 ], [ %v27, %bb15 ]
  %v66 = phi i64 [ %v30, %bb14 ], [ %v30, %bb15 ]
  %v67 = phi i32 [ %v43, %bb14 ], [ %v43, %bb15 ]
  br label %bb7
bb14:
  br label %bb13
bb15:
  br label %bb13
bb16:
  %v69 = phi ptr [ %v20, %bb17 ], [ %v20, %bb18 ]
  %v70 = phi ptr [ %v21, %bb17 ], [ %v21, %bb18 ]
  %v71 = phi i64 [ %v22, %bb17 ], [ %v22, %bb18 ]
  %v72 = phi ptr [ %v23, %bb17 ], [ %v23, %bb18 ]
  %v73 = phi i64 [ %v24, %bb17 ], [ %v24, %bb18 ]
  %v74 = phi i64 [ %v25, %bb17 ], [ %v25, %bb18 ]
  %v75 = phi i64 [ %v27, %bb17 ], [ %v26, %bb18 ]
  %v76 = phi i64 [ %v27, %bb17 ], [ %v27, %bb18 ]
  %v77 = phi i64 [ %v30, %bb17 ], [ %v30, %bb18 ]
  %v78 = phi i32 [ %v43, %bb17 ], [ %v43, %bb18 ]
  br label %bb8
bb17:
  br label %bb16
bb18:
  br label %bb16
bb19:
  %v82 = phi ptr [ %v44, %bb20 ], [ %v44, %bb21 ]
  %v83 = phi ptr [ %v45, %bb20 ], [ %v45, %bb21 ]
  %v84 = phi i64 [ %v46, %bb20 ], [ %v46, %bb21 ]
  %v85 = phi ptr [ %v47, %bb20 ], [ %v47, %bb21 ]
  %v86 = phi i64 [ %v48, %bb20 ], [ %v48, %bb21 ]
  %v87 = phi i64 [ %v49, %bb20 ], [ %v49, %bb21 ]
  %v88 = phi i64 [ %v50, %bb20 ], [ %v50, %bb21 ]
  %v89 = phi i64 [ %v80, %bb20 ], [ %v93, %bb21 ]
  %v90 = phi i64 [ %v52, %bb20 ], [ %v52, %bb21 ]
  %v91 = phi i32 [ %v53, %bb20 ], [ %v53, %bb21 ]
  %v92 = phi i64 [ %v80, %bb20 ], [ %v80, %bb21 ]
  br label %bb22
bb20:
  br label %bb19
bb21:
  %v93 = select i1 true, i64 0, i64 0
  br label %bb19
bb22:
  %v94 = phi ptr [ %v82, %bb19 ]
  %v95 = phi ptr [ %v83, %bb19 ]
  %v96 = phi i64 [ %v84, %bb19 ]
  %v97 = phi ptr [ %v85, %bb19 ]
  %v98 = phi i64 [ %v86, %bb19 ]
  %v99 = phi i64 [ %v87, %bb19 ]
  %v100 = phi i64 [ %v88, %bb19 ]
  %v101 = phi i64 [ %v89, %bb19 ]
  %v102 = phi i64 [ %v28, %bb19 ]
  %v103 = phi i64 [ %v29, %bb19 ]
  %v104 = phi i64 [ %v30, %bb19 ]
  %v105 = select i1 true, i64 1, i64 1
  %v106 = add i64 %v104, %v105
  br label %bb4
bb23:
  %v108 = phi ptr [ %v11, %bb25 ], [ %v119, %bb26 ]
  %v109 = phi ptr [ %v12, %bb25 ], [ %v120, %bb26 ]
  %v110 = phi i64 [ %v13, %bb25 ], [ %v121, %bb26 ]
  %v111 = phi ptr [ %v14, %bb25 ], [ %v122, %bb26 ]
  %v112 = phi i64 [ %v15, %bb25 ], [ %v123, %bb26 ]
  %v113 = phi i64 [ %v16, %bb25 ], [ %v124, %bb26 ]
  %v114 = phi i64 [ %v17, %bb25 ], [ %v125, %bb26 ]
  %v151 = load i64, ptr %v109
  store %wf.t.c5066f96ffdbc504 zeroinitializer, ptr %wf.slot.2
  %t8 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.2, i32 0, i32 0
  store i64 %v151, ptr %t8
  %t9 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.2, i32 0, i32 1
  store i64 %v110, ptr %t9
  %v153 = or i1 0, 1
  store %wf.t.5591089753cba638 zeroinitializer, ptr %wf.result
  %t10 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t10
  %t11 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.result, i32 0, i32 1
  store i1 %v153, ptr %t11
  %t12 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t12, ptr %wf.slot.2, i64 ptrtoint (ptr getelementptr (%wf.t.c5066f96ffdbc504, ptr null, i32 1) to i64), i1 false)
  ret void
bb24:
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v11, i64 ptrtoint (ptr getelementptr (%wf.t.fe1d7d6862eac796, ptr null, i32 1) to i64), i1 false)
  %t13 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %wf.slot.0, i32 0, i32 1
  %v116 = load i64, ptr %t13
  %v117 = select i1 true, i64 3, i64 3
  %v118 = icmp ult i64 %v116, %v117
  switch i1 %v118, label %invalid.tag.b24 [
    i1 1, label %bb27
    i1 0, label %bb28
  ]
invalid.tag.b24:
  unreachable
bb25:
  br label %bb23
bb26:
  %v119 = phi ptr [ %v11, %bb28 ]
  %v120 = phi ptr [ %v12, %bb28 ]
  %v121 = phi i64 [ %v13, %bb28 ]
  %v122 = phi ptr [ %v14, %bb28 ]
  %v123 = phi i64 [ %v15, %bb28 ]
  %v124 = phi i64 [ %v16, %bb28 ]
  %v125 = phi i64 [ %v17, %bb28 ]
  %v126 = phi i64 [ %v116, %bb28 ]
  br label %bb23
bb27:
  %t14 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %v11, i32 0, i32 1
  %v127 = getelementptr i8, ptr %t14, i64 0
  %v128 = select i1 true, i64 1, i64 1
  %v129 = add nuw i64 %v116, %v128
  store i64 %v129, ptr %v127
  %t15 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %v11, i32 0, i32 0
  %v130 = getelementptr i8, ptr %t15, i64 0
  %v131 = getelementptr i8, ptr %v130, i64 0
  %t17 = getelementptr inbounds { i64, i64, ptr }, ptr %v131, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  %t16.nonnegative = icmp sge i64 %v17, 0
  call void @llvm.assume(i1 %t16.nonnegative)
  %t16 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %t18, i64 %v17
  %v132 = getelementptr i8, ptr %t16, i64 0
  %v133 = call i1 @wf_std.collections.hash_map.hash_map_is_deleted$instance$0ed342445dd803f3(ptr %v132)
  switch i1 %v133, label %invalid.tag.b27 [
    i1 1, label %bb30
    i1 0, label %bb31
  ]
invalid.tag.b27:
  unreachable
bb28:
  br label %bb26
bb29:
  %v134 = phi ptr [ %v11, %bb30 ], [ %v11, %bb31 ]
  %v135 = phi ptr [ %v12, %bb30 ], [ %v12, %bb31 ]
  %v136 = phi i64 [ %v13, %bb30 ], [ %v13, %bb31 ]
  %v137 = phi ptr [ %v14, %bb30 ], [ %v14, %bb31 ]
  %v138 = phi i64 [ %v15, %bb30 ], [ %v15, %bb31 ]
  %v139 = phi i64 [ %v16, %bb30 ], [ %v16, %bb31 ]
  %v140 = phi i64 [ %v17, %bb30 ], [ %v17, %bb31 ]
  %v141 = phi i64 [ %v116, %bb30 ], [ %v116, %bb31 ]
  %v142 = phi i1 [ %v133, %bb30 ], [ %v133, %bb31 ]
  %t19 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %v134, i32 0, i32 0
  %v148 = getelementptr i8, ptr %t19, i64 0
  %v149 = load i64, ptr %v135
  call void @wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3(ptr %wf.result, ptr %v148, i64 %v140, i64 %v149, i64 %v136)
  ret void
bb30:
  %t20 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %v11, i32 0, i32 2
  %v143 = getelementptr i8, ptr %t20, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v11, i64 ptrtoint (ptr getelementptr (%wf.t.fe1d7d6862eac796, ptr null, i32 1) to i64), i1 false)
  %t21 = getelementptr inbounds %wf.t.fe1d7d6862eac796, ptr %wf.slot.1, i32 0, i32 2
  %v145 = load i64, ptr %t21
  %v146 = select i1 true, i64 1, i64 1
  %v147 = call i64 @llvm.usub.sat.i64(i64 %v145, i64 %v146)
  store i64 %v147, ptr %v143
  br label %bb29
bb31:
  br label %bb29
}

define i8 @wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd(ptr noalias nonnull captures(none) dereferenceable(24) %v0, i64 %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.a1df460b0959673f, align 8
  %v2 = getelementptr i8, ptr %v0, i64 0
  %t1 = getelementptr inbounds { i64, i64, ptr }, ptr %v2, i32 0, i32 1
  %t0 = load i64, ptr %t1
  %v3 = add i64 %t0, 0
  %v4 = icmp ult i64 %v3, %v1
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v5 = phi ptr [ %v0, %bb2 ], [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb2 ], [ %v1, %bb3 ]
  %v8 = getelementptr i8, ptr %v5, i64 0
  %t3 = getelementptr inbounds { i64, i64, ptr }, ptr %v8, i32 0, i32 0
  %t2 = load i64, ptr %t3
  %v9 = add i64 %t2, 0
  br label %bb4
bb2:
  %v7 = call i8 @wf_grow$instance$b45b69d9d0c6bbd0(ptr %v0, i64 %v1)
  br label %bb1
bb3:
  br label %bb1
bb4:
  %v10 = phi ptr [ %v5, %bb1 ], [ %v23, %bb8 ]
  %v11 = phi i64 [ %v6, %bb1 ], [ %v24, %bb8 ]
  %v12 = phi i64 [ %v9, %bb1 ], [ %v25, %bb8 ]
  %v13 = phi i64 [ %v9, %bb1 ], [ %v26, %bb8 ]
  %v14 = phi i64 [ %v6, %bb1 ], [ %v27, %bb8 ]
  %v15 = phi i64 [ %v9, %bb1 ], [ %v30, %bb8 ]
  %v19 = icmp ult i64 %v15, %v14
  switch i1 %v19, label %invalid.tag.b4 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b4:
  unreachable
bb5:
  store %wf.t.a1df460b0959673f zeroinitializer, ptr %wf.slot.0
  %t4 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %wf.slot.0, i32 0, i32 0
  store i32 0, ptr %t4
  %v21 = getelementptr i8, ptr %v10, i64 0
  %v22 = call i8 @wf_place_back$instance$9985a87b1cb96650(ptr %v21, ptr %wf.slot.0)
  br label %bb8
bb6:
  br label %bb7
bb7:
  %v16 = phi ptr [ %v10, %bb6 ]
  %v17 = phi i64 [ %v11, %bb6 ]
  %v18 = phi i64 [ %v12, %bb6 ]
  %v31 = select i1 true, i8 0, i8 0
  ret i8 %v31
bb8:
  %v23 = phi ptr [ %v10, %bb5 ]
  %v24 = phi i64 [ %v11, %bb5 ]
  %v25 = phi i64 [ %v12, %bb5 ]
  %v26 = phi i64 [ %v13, %bb5 ]
  %v27 = phi i64 [ %v14, %bb5 ]
  %v28 = phi i64 [ %v15, %bb5 ]
  %v29 = select i1 true, i64 1, i64 1
  %v30 = add i64 %v28, %v29
  br label %bb4
}

define internal void @wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.a1df460b0959673f, align 8
  %wf.slot.1 = alloca { i64, [1 x %wf.t.c5066f96ffdbc504] }, align 8
  %wf.slot.2 = alloca %wf.t.c5066f96ffdbc504, align 8
  %wf.slot.3 = alloca %wf.t.c5066f96ffdbc504, align 8
  %wf.slot.4 = alloca %wf.t.5591089753cba638, align 8
  %wf.slot.5 = alloca %wf.t.c5066f96ffdbc504, align 8
  %wf.slot.6 = alloca { i64, [1 x %wf.t.c5066f96ffdbc504] }, align 8
  %wf.slot.7 = alloca { i64, i64, ptr }, align 8
  %v29 = alloca { i64, i64, ptr }, align 8
  %v63 = alloca { i64, [1 x %wf.t.c5066f96ffdbc504] }, align 8
  %v3 = select i1 true, i64 16384, i64 16384
  %v4 = icmp ugt i64 %v1, %v3
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v5 = phi ptr [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb3 ]
  %v7 = phi ptr [ %v2, %bb3 ]
  %t0 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v5, i32 0, i32 0
  %v10 = getelementptr i8, ptr %t0, i64 0
  %v11 = getelementptr i8, ptr %v10, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v11, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v12 = add i64 %t1, 0
  %v13 = icmp ult i64 %v6, %v12
  switch i1 %v13, label %invalid.tag.b1 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v8 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t3 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t3
  %t4 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 2
  store i8 %v8, ptr %t4
  ret void
bb3:
  br label %bb1
bb4:
  %v14 = phi ptr [ %v5, %bb6 ]
  %v15 = phi i64 [ %v6, %bb6 ]
  %v16 = phi ptr [ %v7, %bb6 ]
  %v17 = phi i64 [ %v12, %bb6 ]
  %v20 = select i1 true, i64 0, i64 0
  %v21 = icmp eq i64 %v15, %v20
  switch i1 %v21, label %invalid.tag.b4 [
    i1 1, label %bb8
    i1 0, label %bb9
  ]
invalid.tag.b4:
  unreachable
bb5:
  %v18 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t5 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t5
  %t6 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 2
  store i8 %v18, ptr %t6
  ret void
bb6:
  br label %bb4
bb7:
  %v22 = phi ptr [ %v14, %bb9 ]
  %v23 = phi i64 [ %v15, %bb9 ]
  %v24 = phi ptr [ %v16, %bb9 ]
  %v25 = phi i64 [ %v17, %bb9 ]
  %v28 = call { i64, i64, ptr } @wf_box_slots_new$instance$b45b69d9d0c6bbd0(i64 %v23)
  store { i64, i64, ptr } %v28, ptr %v29
  %v30 = call i8 @wf_std.collections.hash_map.hash_map_extend$instance$820b2044b97e0fbd(ptr %v29, i64 %v23)
  %t7 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v22, i32 0, i32 0
  %v31 = getelementptr i8, ptr %t7, i64 0
  %v32 = call i8 @wf_swap$instance$43608765810d87c7(ptr %v31, ptr %v29)
  br label %bb10
bb8:
  %v26 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t8 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t8
  %t9 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 1
  store i8 %v26, ptr %t9
  ret void
bb9:
  br label %bb7
bb10:
  %v33 = phi ptr [ %v22, %bb7 ], [ %v54, %bb15 ]
  %v34 = phi i64 [ %v23, %bb7 ], [ %v55, %bb15 ]
  %v35 = phi ptr [ %v24, %bb7 ], [ %v56, %bb15 ]
  %v36 = phi i64 [ %v25, %bb7 ], [ %v57, %bb15 ]
  %v37 = phi ptr [ %v29, %bb7 ], [ %v58, %bb15 ]
  %v43 = getelementptr i8, ptr %v37, i64 0
  %t11 = getelementptr inbounds { i64, i64, ptr }, ptr %v43, i32 0, i32 0
  %t10 = load i64, ptr %t11
  %v44 = add i64 %t10, 0
  %v45 = select i1 true, i64 0, i64 0
  %v46 = icmp eq i64 %v44, %v45
  switch i1 %v46, label %invalid.tag.b10 [
    i1 1, label %bb13
    i1 0, label %bb14
  ]
invalid.tag.b10:
  unreachable
bb11:
  %v38 = phi ptr [ %v33, %bb13 ]
  %v39 = phi i64 [ %v34, %bb13 ]
  %v40 = phi ptr [ %v35, %bb13 ]
  %v41 = phi i64 [ %v36, %bb13 ]
  %v42 = phi ptr [ %v37, %bb13 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.7, ptr %v42, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  %v205 = call i8 @wf_free_empty$instance$43608765810d87c7(ptr %wf.slot.7)
  %t12 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v38, i32 0, i32 2
  %v206 = getelementptr i8, ptr %t12, i64 0
  %v207 = select i1 true, i64 0, i64 0
  store i64 %v207, ptr %v206
  %v208 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t13 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t13
  %t14 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 1
  store i8 %v208, ptr %t14
  ret void
bb12:
  %v47 = phi ptr [ %v33, %bb14 ]
  %v48 = phi i64 [ %v34, %bb14 ]
  %v49 = phi ptr [ %v35, %bb14 ]
  %v50 = phi i64 [ %v36, %bb14 ]
  %v51 = phi ptr [ %v37, %bb14 ]
  %v52 = getelementptr i8, ptr %v51, i64 0
  %v53 = call %wf.t.a1df460b0959673f @wf_take_back$instance$9985a87b1cb96650(ptr %v52)
  store %wf.t.a1df460b0959673f %v53, ptr %wf.slot.0
  %t15 = load %wf.t.a1df460b0959673f, ptr %wf.slot.0
  %t16 = extractvalue %wf.t.a1df460b0959673f %t15, 0
  switch i32 %t16, label %invalid.tag.b12 [
    i32 0, label %bb16
    i32 1, label %bb17
    i32 2, label %bb18
  ]
invalid.tag.b12:
  unreachable
bb13:
  br label %bb11
bb14:
  br label %bb12
bb15:
  %v54 = phi ptr [ %v47, %bb16 ], [ %v47, %bb17 ], [ %v76, %bb20 ]
  %v55 = phi i64 [ %v48, %bb16 ], [ %v48, %bb17 ], [ %v77, %bb20 ]
  %v56 = phi ptr [ %v49, %bb16 ], [ %v49, %bb17 ], [ %v78, %bb20 ]
  %v57 = phi i64 [ %v50, %bb16 ], [ %v50, %bb17 ], [ %v79, %bb20 ]
  %v58 = phi ptr [ %v51, %bb16 ], [ %v51, %bb17 ], [ %v80, %bb20 ]
  br label %bb10
bb16:
  br label %bb15
bb17:
  br label %bb15
bb18:
  %t17 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %wf.slot.0, i32 0, i32 1
  %v60 = load i64, ptr %t17
  %t18 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %wf.slot.0, i32 0, i32 2
  %v61 = load i64, ptr %t18
  %v62 = call { i64, [1 x %wf.t.c5066f96ffdbc504] } @wf_slots_new$instance$15df03c28018958d()
  store { i64, [1 x %wf.t.c5066f96ffdbc504] } %v62, ptr %wf.slot.1
  call void @llvm.memmove.p0.p0.i64(ptr %v63, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr ({ i64, [1 x %wf.t.c5066f96ffdbc504] }, ptr null, i32 1) to i64), i1 false)
  store %wf.t.c5066f96ffdbc504 zeroinitializer, ptr %wf.slot.2
  %t19 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.2, i32 0, i32 0
  store i64 %v60, ptr %t19
  %t20 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.2, i32 0, i32 1
  store i64 %v61, ptr %t20
  %v65 = call i8 @wf_place_back$instance$a6542e06bf5acd99(ptr %v63, ptr %wf.slot.2)
  br label %bb19
bb19:
  %v66 = phi ptr [ %v47, %bb18 ], [ %v122, %bb27 ]
  %v67 = phi i64 [ %v48, %bb18 ], [ %v123, %bb27 ]
  %v68 = phi ptr [ %v49, %bb18 ], [ %v124, %bb27 ]
  %v69 = phi i64 [ %v50, %bb18 ], [ %v125, %bb27 ]
  %v70 = phi ptr [ %v51, %bb18 ], [ %v126, %bb27 ]
  %v72 = phi i64 [ %v60, %bb18 ], [ %v128, %bb27 ]
  %v73 = phi i64 [ %v61, %bb18 ], [ %v129, %bb27 ]
  %v74 = phi ptr [ %v63, %bb18 ], [ %v130, %bb27 ]
  %t22 = getelementptr inbounds { i64, [1 x %wf.t.c5066f96ffdbc504] }, ptr %v74, i32 0, i32 0
  %t21 = load i64, ptr %t22
  %v86 = add i64 %t21, 0
  %v87 = select i1 true, i64 0, i64 0
  %v88 = icmp eq i64 %v86, %v87
  switch i1 %v88, label %invalid.tag.b19 [
    i1 1, label %bb22
    i1 0, label %bb23
  ]
invalid.tag.b19:
  unreachable
bb20:
  %v76 = phi ptr [ %v66, %bb22 ]
  %v77 = phi i64 [ %v67, %bb22 ]
  %v78 = phi ptr [ %v68, %bb22 ]
  %v79 = phi i64 [ %v69, %bb22 ]
  %v80 = phi ptr [ %v70, %bb22 ]
  %v82 = phi i64 [ %v72, %bb22 ]
  %v83 = phi i64 [ %v73, %bb22 ]
  %v84 = phi ptr [ %v74, %bb22 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.6, ptr %v84, i64 ptrtoint (ptr getelementptr ({ i64, [1 x %wf.t.c5066f96ffdbc504] }, ptr null, i32 1) to i64), i1 false)
  %v203 = call i8 @wf_free_empty$instance$bb96e2f57d31495e(ptr %wf.slot.6)
  br label %bb15
bb21:
  %v89 = phi ptr [ %v66, %bb23 ]
  %v90 = phi i64 [ %v67, %bb23 ]
  %v91 = phi ptr [ %v68, %bb23 ]
  %v92 = phi i64 [ %v69, %bb23 ]
  %v93 = phi ptr [ %v70, %bb23 ]
  %v95 = phi i64 [ %v72, %bb23 ]
  %v96 = phi i64 [ %v73, %bb23 ]
  %v97 = phi ptr [ %v74, %bb23 ]
  %v99 = select i1 true, i64 0, i64 0
  %t23.nonnegative = icmp sge i64 %v99, 0
  call void @llvm.assume(i1 %t23.nonnegative)
  %t23 = getelementptr inbounds { i64, [1 x %wf.t.c5066f96ffdbc504] }, ptr %v97, i64 0, i32 1, i64 %v99
  %v100 = getelementptr i8, ptr %t23, i64 0
  %t24 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %v100, i32 0, i32 0
  %v101 = getelementptr i8, ptr %t24, i64 0
  %v102 = call i64 @wf_map_cost_hash(ptr %v91, ptr %v101)
  %t25 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v89, i32 0, i32 0
  %v103 = getelementptr i8, ptr %t25, i64 0
  %v104 = getelementptr i8, ptr %v103, i64 0
  %t27 = getelementptr inbounds { i64, i64, ptr }, ptr %v104, i32 0, i32 0
  %t26 = load i64, ptr %t27
  %v105 = add i64 %t26, 0
  %v106 = select i1 true, i64 0, i64 0
  br label %bb24
bb22:
  br label %bb20
bb23:
  br label %bb21
bb24:
  %v107 = phi ptr [ %v89, %bb21 ], [ %v185, %bb34 ]
  %v108 = phi i64 [ %v90, %bb21 ], [ %v186, %bb34 ]
  %v109 = phi ptr [ %v91, %bb21 ], [ %v187, %bb34 ]
  %v110 = phi i64 [ %v92, %bb21 ], [ %v188, %bb34 ]
  %v111 = phi ptr [ %v93, %bb21 ], [ %v189, %bb34 ]
  %v113 = phi i64 [ %v95, %bb21 ], [ %v191, %bb34 ]
  %v114 = phi i64 [ %v96, %bb21 ], [ %v192, %bb34 ]
  %v115 = phi ptr [ %v97, %bb21 ], [ %v193, %bb34 ]
  %v117 = phi i64 [ %v102, %bb21 ], [ %v195, %bb34 ]
  %v118 = phi i64 [ %v105, %bb21 ], [ %v196, %bb34 ]
  %v119 = phi i64 [ %v106, %bb21 ], [ %v197, %bb34 ]
  %v120 = phi i64 [ %v105, %bb21 ], [ %v198, %bb34 ]
  %v121 = phi i64 [ %v106, %bb21 ], [ %v201, %bb34 ]
  %v134 = icmp ult i64 %v121, %v120
  switch i1 %v134, label %invalid.tag.b24 [
    i1 1, label %bb25
    i1 0, label %bb26
  ]
invalid.tag.b24:
  unreachable
bb25:
  %v135 = urem i64 %v117, %v118
  %v136 = call i64 @wf_std.collections.hash_map.hash_map_probe(i64 %v135, i64 %v121, i64 %v118)
  %t28 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v107, i32 0, i32 0
  %v137 = getelementptr i8, ptr %t28, i64 0
  %v138 = getelementptr i8, ptr %v137, i64 0
  %t30 = getelementptr inbounds { i64, i64, ptr }, ptr %v138, i32 0, i32 2
  %t31 = load ptr, ptr %t30
  %t29.nonnegative = icmp sge i64 %v136, 0
  call void @llvm.assume(i1 %t29.nonnegative)
  %t29 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %t31, i64 %v136
  %v139 = getelementptr i8, ptr %t29, i64 0
  %v140 = call i1 @wf_std.collections.hash_map.hash_map_is_available$instance$0ed342445dd803f3(ptr %v139)
  switch i1 %v140, label %invalid.tag.b25 [
    i1 1, label %bb29
    i1 0, label %bb30
  ]
invalid.tag.b25:
  unreachable
bb26:
  br label %bb27
bb27:
  %v122 = phi ptr [ %v107, %bb26 ], [ %v162, %bb31 ]
  %v123 = phi i64 [ %v108, %bb26 ], [ %v163, %bb31 ]
  %v124 = phi ptr [ %v109, %bb26 ], [ %v164, %bb31 ]
  %v125 = phi i64 [ %v110, %bb26 ], [ %v165, %bb31 ]
  %v126 = phi ptr [ %v111, %bb26 ], [ %v166, %bb31 ]
  %v128 = phi i64 [ %v113, %bb26 ], [ %v168, %bb31 ]
  %v129 = phi i64 [ %v114, %bb26 ], [ %v169, %bb31 ]
  %v130 = phi ptr [ %v115, %bb26 ], [ %v170, %bb31 ]
  %v132 = phi i64 [ %v117, %bb26 ], [ %v172, %bb31 ]
  %v133 = phi i64 [ %v118, %bb26 ], [ %v173, %bb31 ]
  br label %bb19
bb28:
  %v141 = phi ptr [ %v107, %bb30 ]
  %v142 = phi i64 [ %v108, %bb30 ]
  %v143 = phi ptr [ %v109, %bb30 ]
  %v144 = phi i64 [ %v110, %bb30 ]
  %v145 = phi ptr [ %v111, %bb30 ]
  %v147 = phi i64 [ %v113, %bb30 ]
  %v148 = phi i64 [ %v114, %bb30 ]
  %v149 = phi ptr [ %v115, %bb30 ]
  %v151 = phi i64 [ %v117, %bb30 ]
  %v152 = phi i64 [ %v118, %bb30 ]
  %v153 = phi i64 [ %v121, %bb30 ]
  %v154 = phi i64 [ %v135, %bb30 ]
  %v155 = phi i64 [ %v136, %bb30 ]
  %v156 = phi i1 [ %v140, %bb30 ]
  br label %bb34
bb29:
  %v157 = call %wf.t.c5066f96ffdbc504 @wf_take_back$instance$a6542e06bf5acd99(ptr %v115)
  store %wf.t.c5066f96ffdbc504 %v157, ptr %wf.slot.3
  %t32 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.3, i32 0, i32 0
  %v158 = load i64, ptr %t32
  ; ownership-consuming projection
  %t33 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.3, i32 0, i32 1
  %v159 = load i64, ptr %t33
  ; ownership-consuming projection
  %t34 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v107, i32 0, i32 0
  %v160 = getelementptr i8, ptr %t34, i64 0
  call void @wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3(ptr %wf.slot.4, ptr %v160, i64 %v136, i64 %v158, i64 %v159)
  %t35 = load %wf.t.5591089753cba638, ptr %wf.slot.4
  %t36 = extractvalue %wf.t.5591089753cba638 %t35, 0
  switch i32 %t36, label %invalid.tag.b29 [
    i32 0, label %bb32
    i32 1, label %bb33
  ]
invalid.tag.b29:
  unreachable
bb30:
  br label %bb28
bb31:
  %v162 = phi ptr [ %v107, %bb32 ], [ %v107, %bb33 ]
  %v163 = phi i64 [ %v108, %bb32 ], [ %v108, %bb33 ]
  %v164 = phi ptr [ %v109, %bb32 ], [ %v109, %bb33 ]
  %v165 = phi i64 [ %v110, %bb32 ], [ %v110, %bb33 ]
  %v166 = phi ptr [ %v111, %bb32 ], [ %v111, %bb33 ]
  %v168 = phi i64 [ %v113, %bb32 ], [ %v113, %bb33 ]
  %v169 = phi i64 [ %v114, %bb32 ], [ %v114, %bb33 ]
  %v170 = phi ptr [ %v115, %bb32 ], [ %v115, %bb33 ]
  %v172 = phi i64 [ %v117, %bb32 ], [ %v117, %bb33 ]
  %v173 = phi i64 [ %v118, %bb32 ], [ %v118, %bb33 ]
  %v174 = phi i64 [ %v121, %bb32 ], [ %v121, %bb33 ]
  %v175 = phi i64 [ %v135, %bb32 ], [ %v135, %bb33 ]
  %v176 = phi i64 [ %v136, %bb32 ], [ %v136, %bb33 ]
  %v177 = phi i1 [ %v140, %bb32 ], [ %v140, %bb33 ]
  %v179 = phi i64 [ %v158, %bb32 ], [ %v158, %bb33 ]
  %v180 = phi i64 [ %v159, %bb32 ], [ %v159, %bb33 ]
  br label %bb27
bb32:
  br label %bb31
bb33:
  %t37 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.slot.4, i32 0, i32 1
  %v182 = load i1, ptr %t37
  %t38 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.slot.4, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.5, ptr %t38, i64 ptrtoint (ptr getelementptr (%wf.t.c5066f96ffdbc504, ptr null, i32 1) to i64), i1 false)
  %v184 = call i8 @wf_place_back$instance$a6542e06bf5acd99(ptr %v115, ptr %wf.slot.5)
  br label %bb31
bb34:
  %v185 = phi ptr [ %v141, %bb28 ]
  %v186 = phi i64 [ %v142, %bb28 ]
  %v187 = phi ptr [ %v143, %bb28 ]
  %v188 = phi i64 [ %v144, %bb28 ]
  %v189 = phi ptr [ %v145, %bb28 ]
  %v191 = phi i64 [ %v147, %bb28 ]
  %v192 = phi i64 [ %v148, %bb28 ]
  %v193 = phi ptr [ %v149, %bb28 ]
  %v195 = phi i64 [ %v151, %bb28 ]
  %v196 = phi i64 [ %v152, %bb28 ]
  %v197 = phi i64 [ %v119, %bb28 ]
  %v198 = phi i64 [ %v120, %bb28 ]
  %v199 = phi i64 [ %v121, %bb28 ]
  %v200 = select i1 true, i64 1, i64 1
  %v201 = add i64 %v199, %v200
  br label %bb24
}

define %wf.t.7d7f918f7b4962fd @wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad(ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.result = alloca %wf.t.7d7f918f7b4962fd, align 4
  call void @wf_std.collections.hash_map.hash_map_rebuild$instance$fde7c6722a8b0dad.body(ptr %wf.result, ptr %v0, i64 %v1, ptr %v2)
  %wf.returned = load %wf.t.7d7f918f7b4962fd, ptr %wf.result
  ret %wf.t.7d7f918f7b4962fd %wf.returned
}

define void @wf_std.collections.hash_map.hash_map_try_put$instance$fde7c6722a8b0dad(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, i64 %v2, ptr noalias nonnull captures(none) dereferenceable(16) %v3) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.0a5f51efa7ad5b17, align 8
  %wf.slot.1 = alloca %wf.t.0a5f51efa7ad5b17, align 8
  %wf.slot.2 = alloca %wf.t.c5066f96ffdbc504, align 8
  %v4 = alloca i64, align 8
  store i64 %v1, ptr %v4
  %v5 = call i64 @wf_map_cost_hash(ptr %v3, ptr %v4)
  %t0 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v0, i32 0, i32 0
  %v6 = getelementptr i8, ptr %t0, i64 0
  %v7 = getelementptr i8, ptr %v6, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v7, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v8 = add i64 %t1, 0
  %v9 = select i1 true, i64 0, i64 0
  %v10 = icmp ugt i64 %v8, %v9
  switch i1 %v10, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v11 = phi ptr [ %v0, %bb3 ], [ %v31, %bb7 ]
  %v12 = phi ptr [ %v4, %bb3 ], [ %v32, %bb7 ]
  %v13 = phi i64 [ %v2, %bb3 ], [ %v33, %bb7 ]
  %v14 = phi ptr [ %v3, %bb3 ], [ %v34, %bb7 ]
  %v15 = phi i64 [ %v5, %bb3 ], [ %v35, %bb7 ]
  %v16 = phi i64 [ %v8, %bb3 ], [ %v36, %bb7 ]
  %v17 = phi i64 [ %v8, %bb3 ], [ %v37, %bb7 ]
  %v107 = icmp ult i64 %v17, %v16
  switch i1 %v107, label %invalid.tag.b1 [
    i1 1, label %bb24
    i1 0, label %bb25
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v18 = urem i64 %v5, %v8
  %v19 = select i1 true, i64 0, i64 0
  br label %bb4
bb3:
  br label %bb1
bb4:
  %v20 = phi ptr [ %v0, %bb2 ], [ %v94, %bb22 ]
  %v21 = phi ptr [ %v4, %bb2 ], [ %v95, %bb22 ]
  %v22 = phi i64 [ %v2, %bb2 ], [ %v96, %bb22 ]
  %v23 = phi ptr [ %v3, %bb2 ], [ %v97, %bb22 ]
  %v24 = phi i64 [ %v5, %bb2 ], [ %v98, %bb22 ]
  %v25 = phi i64 [ %v8, %bb2 ], [ %v99, %bb22 ]
  %v26 = phi i64 [ %v8, %bb2 ], [ %v100, %bb22 ]
  %v27 = phi i64 [ %v18, %bb2 ], [ %v101, %bb22 ]
  %v28 = phi i64 [ %v19, %bb2 ], [ %v102, %bb22 ]
  %v29 = phi i64 [ %v8, %bb2 ], [ %v103, %bb22 ]
  %v30 = phi i64 [ %v19, %bb2 ], [ %v106, %bb22 ]
  %v39 = icmp ult i64 %v30, %v29
  switch i1 %v39, label %invalid.tag.b4 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b4:
  unreachable
bb5:
  %t3 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v20, i32 0, i32 0
  %v40 = getelementptr i8, ptr %t3, i64 0
  %v41 = getelementptr i8, ptr %v40, i64 0
  %t5 = getelementptr inbounds { i64, i64, ptr }, ptr %v41, i32 0, i32 2
  %t6 = load ptr, ptr %t5
  %t4.nonnegative = icmp sge i64 %v27, 0
  call void @llvm.assume(i1 %t4.nonnegative)
  %t4 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %t6, i64 %v27
  %v42 = getelementptr i8, ptr %t4, i64 0
  %v43 = call i32 @wf_std.collections.hash_map.hash_map_action$instance$fc5e3cb62bdf3601(ptr %v42, ptr %v21, ptr %v23)
  switch i32 %v43, label %invalid.tag.b5 [
    i32 3, label %bb9
    i32 0, label %bb10
    i32 1, label %bb11
    i32 2, label %bb12
  ]
invalid.tag.b5:
  unreachable
bb6:
  br label %bb7
bb7:
  %v31 = phi ptr [ %v20, %bb6 ], [ %v58, %bb13 ]
  %v32 = phi ptr [ %v21, %bb6 ], [ %v59, %bb13 ]
  %v33 = phi i64 [ %v22, %bb6 ], [ %v60, %bb13 ]
  %v34 = phi ptr [ %v23, %bb6 ], [ %v61, %bb13 ]
  %v35 = phi i64 [ %v24, %bb6 ], [ %v62, %bb13 ]
  %v36 = phi i64 [ %v25, %bb6 ], [ %v63, %bb13 ]
  %v37 = phi i64 [ %v26, %bb6 ], [ %v64, %bb13 ]
  %v38 = phi i64 [ %v27, %bb6 ], [ %v65, %bb13 ]
  br label %bb1
bb8:
  %v44 = phi ptr [ %v20, %bb12 ], [ %v69, %bb16 ]
  %v45 = phi ptr [ %v21, %bb12 ], [ %v70, %bb16 ]
  %v46 = phi i64 [ %v22, %bb12 ], [ %v71, %bb16 ]
  %v47 = phi ptr [ %v23, %bb12 ], [ %v72, %bb16 ]
  %v48 = phi i64 [ %v24, %bb12 ], [ %v73, %bb16 ]
  %v49 = phi i64 [ %v25, %bb12 ], [ %v74, %bb16 ]
  %v50 = phi i64 [ %v26, %bb12 ], [ %v75, %bb16 ]
  %v51 = phi i64 [ %v27, %bb12 ], [ %v76, %bb16 ]
  %v52 = phi i64 [ %v30, %bb12 ], [ %v77, %bb16 ]
  %v53 = phi i32 [ %v43, %bb12 ], [ %v78, %bb16 ]
  %v79 = select i1 true, i64 1, i64 1
  %v80 = add nuw i64 %v51, %v79
  %v81 = icmp ult i64 %v80, %v49
  switch i1 %v81, label %invalid.tag.b8 [
    i1 1, label %bb20
    i1 0, label %bb21
  ]
invalid.tag.b8:
  unreachable
bb9:
  %t7 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v20, i32 0, i32 0
  %v54 = getelementptr i8, ptr %t7, i64 0
  %v55 = load i64, ptr %v21
  call void @wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3(ptr %wf.result, ptr %v54, i64 %v27, i64 %v55, i64 %v22)
  ret void
bb10:
  %v57 = icmp eq i64 %v26, %v25
  switch i1 %v57, label %invalid.tag.b10 [
    i1 1, label %bb14
    i1 0, label %bb15
  ]
invalid.tag.b10:
  unreachable
bb11:
  %v68 = icmp eq i64 %v26, %v25
  switch i1 %v68, label %invalid.tag.b11 [
    i1 1, label %bb17
    i1 0, label %bb18
  ]
invalid.tag.b11:
  unreachable
bb12:
  br label %bb8
bb13:
  %v58 = phi ptr [ %v20, %bb14 ], [ %v20, %bb15 ]
  %v59 = phi ptr [ %v21, %bb14 ], [ %v21, %bb15 ]
  %v60 = phi i64 [ %v22, %bb14 ], [ %v22, %bb15 ]
  %v61 = phi ptr [ %v23, %bb14 ], [ %v23, %bb15 ]
  %v62 = phi i64 [ %v24, %bb14 ], [ %v24, %bb15 ]
  %v63 = phi i64 [ %v25, %bb14 ], [ %v25, %bb15 ]
  %v64 = phi i64 [ %v27, %bb14 ], [ %v26, %bb15 ]
  %v65 = phi i64 [ %v27, %bb14 ], [ %v27, %bb15 ]
  %v66 = phi i64 [ %v30, %bb14 ], [ %v30, %bb15 ]
  %v67 = phi i32 [ %v43, %bb14 ], [ %v43, %bb15 ]
  br label %bb7
bb14:
  br label %bb13
bb15:
  br label %bb13
bb16:
  %v69 = phi ptr [ %v20, %bb17 ], [ %v20, %bb18 ]
  %v70 = phi ptr [ %v21, %bb17 ], [ %v21, %bb18 ]
  %v71 = phi i64 [ %v22, %bb17 ], [ %v22, %bb18 ]
  %v72 = phi ptr [ %v23, %bb17 ], [ %v23, %bb18 ]
  %v73 = phi i64 [ %v24, %bb17 ], [ %v24, %bb18 ]
  %v74 = phi i64 [ %v25, %bb17 ], [ %v25, %bb18 ]
  %v75 = phi i64 [ %v27, %bb17 ], [ %v26, %bb18 ]
  %v76 = phi i64 [ %v27, %bb17 ], [ %v27, %bb18 ]
  %v77 = phi i64 [ %v30, %bb17 ], [ %v30, %bb18 ]
  %v78 = phi i32 [ %v43, %bb17 ], [ %v43, %bb18 ]
  br label %bb8
bb17:
  br label %bb16
bb18:
  br label %bb16
bb19:
  %v82 = phi ptr [ %v44, %bb20 ], [ %v44, %bb21 ]
  %v83 = phi ptr [ %v45, %bb20 ], [ %v45, %bb21 ]
  %v84 = phi i64 [ %v46, %bb20 ], [ %v46, %bb21 ]
  %v85 = phi ptr [ %v47, %bb20 ], [ %v47, %bb21 ]
  %v86 = phi i64 [ %v48, %bb20 ], [ %v48, %bb21 ]
  %v87 = phi i64 [ %v49, %bb20 ], [ %v49, %bb21 ]
  %v88 = phi i64 [ %v50, %bb20 ], [ %v50, %bb21 ]
  %v89 = phi i64 [ %v80, %bb20 ], [ %v93, %bb21 ]
  %v90 = phi i64 [ %v52, %bb20 ], [ %v52, %bb21 ]
  %v91 = phi i32 [ %v53, %bb20 ], [ %v53, %bb21 ]
  %v92 = phi i64 [ %v80, %bb20 ], [ %v80, %bb21 ]
  br label %bb22
bb20:
  br label %bb19
bb21:
  %v93 = select i1 true, i64 0, i64 0
  br label %bb19
bb22:
  %v94 = phi ptr [ %v82, %bb19 ]
  %v95 = phi ptr [ %v83, %bb19 ]
  %v96 = phi i64 [ %v84, %bb19 ]
  %v97 = phi ptr [ %v85, %bb19 ]
  %v98 = phi i64 [ %v86, %bb19 ]
  %v99 = phi i64 [ %v87, %bb19 ]
  %v100 = phi i64 [ %v88, %bb19 ]
  %v101 = phi i64 [ %v89, %bb19 ]
  %v102 = phi i64 [ %v28, %bb19 ]
  %v103 = phi i64 [ %v29, %bb19 ]
  %v104 = phi i64 [ %v30, %bb19 ]
  %v105 = select i1 true, i64 1, i64 1
  %v106 = add i64 %v104, %v105
  br label %bb4
bb23:
  %v108 = phi ptr [ %v11, %bb25 ], [ %v119, %bb26 ]
  %v109 = phi ptr [ %v12, %bb25 ], [ %v120, %bb26 ]
  %v110 = phi i64 [ %v13, %bb25 ], [ %v121, %bb26 ]
  %v111 = phi ptr [ %v14, %bb25 ], [ %v122, %bb26 ]
  %v112 = phi i64 [ %v15, %bb25 ], [ %v123, %bb26 ]
  %v113 = phi i64 [ %v16, %bb25 ], [ %v124, %bb26 ]
  %v114 = phi i64 [ %v17, %bb25 ], [ %v125, %bb26 ]
  %v151 = load i64, ptr %v109
  store %wf.t.c5066f96ffdbc504 zeroinitializer, ptr %wf.slot.2
  %t8 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.2, i32 0, i32 0
  store i64 %v151, ptr %t8
  %t9 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.2, i32 0, i32 1
  store i64 %v110, ptr %t9
  %v153 = or i1 0, 1
  store %wf.t.5591089753cba638 zeroinitializer, ptr %wf.result
  %t10 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t10
  %t11 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.result, i32 0, i32 1
  store i1 %v153, ptr %t11
  %t12 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t12, ptr %wf.slot.2, i64 ptrtoint (ptr getelementptr (%wf.t.c5066f96ffdbc504, ptr null, i32 1) to i64), i1 false)
  ret void
bb24:
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v11, i64 ptrtoint (ptr getelementptr (%wf.t.0a5f51efa7ad5b17, ptr null, i32 1) to i64), i1 false)
  %t13 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %wf.slot.0, i32 0, i32 1
  %v116 = load i64, ptr %t13
  %v117 = select i1 true, i64 16384, i64 16384
  %v118 = icmp ult i64 %v116, %v117
  switch i1 %v118, label %invalid.tag.b24 [
    i1 1, label %bb27
    i1 0, label %bb28
  ]
invalid.tag.b24:
  unreachable
bb25:
  br label %bb23
bb26:
  %v119 = phi ptr [ %v11, %bb28 ]
  %v120 = phi ptr [ %v12, %bb28 ]
  %v121 = phi i64 [ %v13, %bb28 ]
  %v122 = phi ptr [ %v14, %bb28 ]
  %v123 = phi i64 [ %v15, %bb28 ]
  %v124 = phi i64 [ %v16, %bb28 ]
  %v125 = phi i64 [ %v17, %bb28 ]
  %v126 = phi i64 [ %v116, %bb28 ]
  br label %bb23
bb27:
  %t14 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v11, i32 0, i32 1
  %v127 = getelementptr i8, ptr %t14, i64 0
  %v128 = select i1 true, i64 1, i64 1
  %v129 = add nuw i64 %v116, %v128
  store i64 %v129, ptr %v127
  %t15 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v11, i32 0, i32 0
  %v130 = getelementptr i8, ptr %t15, i64 0
  %v131 = getelementptr i8, ptr %v130, i64 0
  %t17 = getelementptr inbounds { i64, i64, ptr }, ptr %v131, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  %t16.nonnegative = icmp sge i64 %v17, 0
  call void @llvm.assume(i1 %t16.nonnegative)
  %t16 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %t18, i64 %v17
  %v132 = getelementptr i8, ptr %t16, i64 0
  %v133 = call i1 @wf_std.collections.hash_map.hash_map_is_deleted$instance$0ed342445dd803f3(ptr %v132)
  switch i1 %v133, label %invalid.tag.b27 [
    i1 1, label %bb30
    i1 0, label %bb31
  ]
invalid.tag.b27:
  unreachable
bb28:
  br label %bb26
bb29:
  %v134 = phi ptr [ %v11, %bb30 ], [ %v11, %bb31 ]
  %v135 = phi ptr [ %v12, %bb30 ], [ %v12, %bb31 ]
  %v136 = phi i64 [ %v13, %bb30 ], [ %v13, %bb31 ]
  %v137 = phi ptr [ %v14, %bb30 ], [ %v14, %bb31 ]
  %v138 = phi i64 [ %v15, %bb30 ], [ %v15, %bb31 ]
  %v139 = phi i64 [ %v16, %bb30 ], [ %v16, %bb31 ]
  %v140 = phi i64 [ %v17, %bb30 ], [ %v17, %bb31 ]
  %v141 = phi i64 [ %v116, %bb30 ], [ %v116, %bb31 ]
  %v142 = phi i1 [ %v133, %bb30 ], [ %v133, %bb31 ]
  %t19 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v134, i32 0, i32 0
  %v148 = getelementptr i8, ptr %t19, i64 0
  %v149 = load i64, ptr %v135
  call void @wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3(ptr %wf.result, ptr %v148, i64 %v140, i64 %v149, i64 %v136)
  ret void
bb30:
  %t20 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v11, i32 0, i32 2
  %v143 = getelementptr i8, ptr %t20, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v11, i64 ptrtoint (ptr getelementptr (%wf.t.0a5f51efa7ad5b17, ptr null, i32 1) to i64), i1 false)
  %t21 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %wf.slot.1, i32 0, i32 2
  %v145 = load i64, ptr %t21
  %v146 = select i1 true, i64 1, i64 1
  %v147 = call i64 @llvm.usub.sat.i64(i64 %v145, i64 %v146)
  store i64 %v147, ptr %v143
  br label %bb29
bb31:
  br label %bb29
}

define internal void @wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %v3 = call i64 @wf_map_cost_hash(ptr %v2, ptr %v1)
  %t0 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v0, i32 0, i32 0
  %v4 = getelementptr i8, ptr %t0, i64 0
  %v5 = getelementptr i8, ptr %v4, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v5, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v6 = add i64 %t1, 0
  %v7 = select i1 true, i64 0, i64 0
  %v8 = icmp eq i64 %v6, %v7
  switch i1 %v8, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v9 = phi ptr [ %v0, %bb3 ]
  %v10 = phi ptr [ %v1, %bb3 ]
  %v11 = phi ptr [ %v2, %bb3 ]
  %v12 = phi i64 [ %v3, %bb3 ]
  %v13 = phi i64 [ %v6, %bb3 ]
  %v16 = urem i64 %v12, %v13
  %v17 = select i1 true, i64 0, i64 0
  br label %bb4
bb2:
  %v14 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t3 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t3
  %t4 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v14, ptr %t4
  ret void
bb3:
  br label %bb1
bb4:
  %v18 = phi ptr [ %v9, %bb1 ], [ %v62, %bb16 ]
  %v19 = phi ptr [ %v10, %bb1 ], [ %v63, %bb16 ]
  %v20 = phi ptr [ %v11, %bb1 ], [ %v64, %bb16 ]
  %v21 = phi i64 [ %v12, %bb1 ], [ %v65, %bb16 ]
  %v22 = phi i64 [ %v13, %bb1 ], [ %v66, %bb16 ]
  %v23 = phi i64 [ %v16, %bb1 ], [ %v67, %bb16 ]
  %v24 = phi i64 [ %v17, %bb1 ], [ %v68, %bb16 ]
  %v25 = phi i64 [ %v13, %bb1 ], [ %v69, %bb16 ]
  %v26 = phi i64 [ %v17, %bb1 ], [ %v72, %bb16 ]
  %v33 = icmp ult i64 %v26, %v25
  switch i1 %v33, label %invalid.tag.b4 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b4:
  unreachable
bb5:
  %t5 = getelementptr inbounds %wf.t.0a5f51efa7ad5b17, ptr %v18, i32 0, i32 0
  %v34 = getelementptr i8, ptr %t5, i64 0
  %v35 = getelementptr i8, ptr %v34, i64 0
  %t7 = getelementptr inbounds { i64, i64, ptr }, ptr %v35, i32 0, i32 2
  %t8 = load ptr, ptr %t7
  %t6.nonnegative = icmp sge i64 %v23, 0
  call void @llvm.assume(i1 %t6.nonnegative)
  %t6 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %t8, i64 %v23
  %v36 = getelementptr i8, ptr %t6, i64 0
  %v37 = call i32 @wf_std.collections.hash_map.hash_map_action$instance$fc5e3cb62bdf3601(ptr %v36, ptr %v19, ptr %v20)
  switch i32 %v37, label %invalid.tag.b5 [
    i32 3, label %bb9
    i32 0, label %bb10
    i32 1, label %bb11
    i32 2, label %bb12
  ]
invalid.tag.b5:
  unreachable
bb6:
  br label %bb7
bb7:
  %v27 = phi ptr [ %v18, %bb6 ]
  %v28 = phi ptr [ %v19, %bb6 ]
  %v29 = phi ptr [ %v20, %bb6 ]
  %v30 = phi i64 [ %v21, %bb6 ]
  %v31 = phi i64 [ %v22, %bb6 ]
  %v32 = phi i64 [ %v23, %bb6 ]
  %v73 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t9 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t9
  %t10 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v73, ptr %t10
  ret void
bb8:
  %v38 = phi ptr [ %v18, %bb11 ], [ %v18, %bb12 ]
  %v39 = phi ptr [ %v19, %bb11 ], [ %v19, %bb12 ]
  %v40 = phi ptr [ %v20, %bb11 ], [ %v20, %bb12 ]
  %v41 = phi i64 [ %v21, %bb11 ], [ %v21, %bb12 ]
  %v42 = phi i64 [ %v22, %bb11 ], [ %v22, %bb12 ]
  %v43 = phi i64 [ %v23, %bb11 ], [ %v23, %bb12 ]
  %v44 = phi i64 [ %v26, %bb11 ], [ %v26, %bb12 ]
  %v45 = phi i32 [ %v37, %bb11 ], [ %v37, %bb12 ]
  %v49 = select i1 true, i64 1, i64 1
  %v50 = add nuw i64 %v43, %v49
  %v51 = icmp ult i64 %v50, %v42
  switch i1 %v51, label %invalid.tag.b8 [
    i1 1, label %bb14
    i1 0, label %bb15
  ]
invalid.tag.b8:
  unreachable
bb9:
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t11 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t11
  %t12 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 1
  store i64 %v23, ptr %t12
  ret void
bb10:
  %v47 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t13 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t13
  %t14 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v47, ptr %t14
  ret void
bb11:
  br label %bb8
bb12:
  br label %bb8
bb13:
  %v52 = phi ptr [ %v38, %bb14 ], [ %v38, %bb15 ]
  %v53 = phi ptr [ %v39, %bb14 ], [ %v39, %bb15 ]
  %v54 = phi ptr [ %v40, %bb14 ], [ %v40, %bb15 ]
  %v55 = phi i64 [ %v41, %bb14 ], [ %v41, %bb15 ]
  %v56 = phi i64 [ %v42, %bb14 ], [ %v42, %bb15 ]
  %v57 = phi i64 [ %v50, %bb14 ], [ %v61, %bb15 ]
  %v58 = phi i64 [ %v44, %bb14 ], [ %v44, %bb15 ]
  %v59 = phi i32 [ %v45, %bb14 ], [ %v45, %bb15 ]
  %v60 = phi i64 [ %v50, %bb14 ], [ %v50, %bb15 ]
  br label %bb16
bb14:
  br label %bb13
bb15:
  %v61 = select i1 true, i64 0, i64 0
  br label %bb13
bb16:
  %v62 = phi ptr [ %v52, %bb13 ]
  %v63 = phi ptr [ %v53, %bb13 ]
  %v64 = phi ptr [ %v54, %bb13 ]
  %v65 = phi i64 [ %v55, %bb13 ]
  %v66 = phi i64 [ %v56, %bb13 ]
  %v67 = phi i64 [ %v57, %bb13 ]
  %v68 = phi i64 [ %v24, %bb13 ]
  %v69 = phi i64 [ %v25, %bb13 ]
  %v70 = phi i64 [ %v26, %bb13 ]
  %v71 = select i1 true, i64 1, i64 1
  %v72 = add i64 %v70, %v71
  br label %bb4
}

define %wf.t.b7e1ed626c09888a @wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad(ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.result = alloca %wf.t.b7e1ed626c09888a, align 8
  call void @wf_std.collections.hash_map.hash_map_find$instance$fde7c6722a8b0dad.body(ptr %wf.result, ptr %v0, ptr %v1, ptr %v2)
  %wf.returned = load %wf.t.b7e1ed626c09888a, ptr %wf.result
  ret %wf.t.b7e1ed626c09888a %wf.returned
}

define internal void @wf_box_slots_new$instance$9eabc50a9cce2251.body(ptr %wf.result, i64 %v0) #0 {
entry:
  %t0 = mul nuw i64 %v0, ptrtoint (ptr getelementptr (%wf.t.dceb7b9db1c9ad1d, ptr null, i64 1) to i64)
  %t1 = icmp eq i64 %t0, 0
  br i1 %t1, label %window.payload.empty.v1, label %window.payload.allocate.v1
window.payload.empty.v1:
  br label %window.block.ready.v1
window.payload.allocate.v1:
  %t3 = call ptr @malloc(i64 %t0)
  %t4 = icmp ne ptr %t3, null
  br i1 %t4, label %window.block.ready.v1, label %window.block.oom.v1
window.block.oom.v1:
  call void @wf_resource_abort()
  unreachable
window.block.ready.v1:
  %t2 = phi ptr [ @.wf.empty.slots.payload, %window.payload.empty.v1 ], [ %t3, %window.payload.allocate.v1 ]
  %t5 = getelementptr inbounds { i64, i64, ptr }, ptr %wf.result, i32 0, i32 0
  %t6 = getelementptr inbounds { i64, i64, ptr }, ptr %wf.result, i32 0, i32 1
  %t7 = getelementptr inbounds { i64, i64, ptr }, ptr %wf.result, i32 0, i32 2
  store i64 0, ptr %t5
  store i64 %v0, ptr %t6
  store ptr %t2, ptr %t7
  ret void
}

define { i64, i64, ptr } @wf_box_slots_new$instance$9eabc50a9cce2251(i64 %v0) #0 {
entry:
  %wf.result = alloca { i64, i64, ptr }, align 8
  call void @wf_box_slots_new$instance$9eabc50a9cce2251.body(ptr %wf.result, i64 %v0)
  %wf.returned = load { i64, i64, ptr }, ptr %wf.result
  ret { i64, i64, ptr } %wf.returned
}

define i8 @wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743(ptr noalias nonnull captures(none) dereferenceable(24) %v0, i64 %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.dceb7b9db1c9ad1d, align 8
  %v2 = getelementptr i8, ptr %v0, i64 0
  %t1 = getelementptr inbounds { i64, i64, ptr }, ptr %v2, i32 0, i32 1
  %t0 = load i64, ptr %t1
  %v3 = add i64 %t0, 0
  %v4 = icmp ult i64 %v3, %v1
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v5 = phi ptr [ %v0, %bb2 ], [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb2 ], [ %v1, %bb3 ]
  %v8 = getelementptr i8, ptr %v5, i64 0
  %t3 = getelementptr inbounds { i64, i64, ptr }, ptr %v8, i32 0, i32 0
  %t2 = load i64, ptr %t3
  %v9 = add i64 %t2, 0
  br label %bb4
bb2:
  %v7 = call i8 @wf_grow$instance$9eabc50a9cce2251(ptr %v0, i64 %v1)
  br label %bb1
bb3:
  br label %bb1
bb4:
  %v10 = phi ptr [ %v5, %bb1 ], [ %v23, %bb8 ]
  %v11 = phi i64 [ %v6, %bb1 ], [ %v24, %bb8 ]
  %v12 = phi i64 [ %v9, %bb1 ], [ %v25, %bb8 ]
  %v13 = phi i64 [ %v9, %bb1 ], [ %v26, %bb8 ]
  %v14 = phi i64 [ %v6, %bb1 ], [ %v27, %bb8 ]
  %v15 = phi i64 [ %v9, %bb1 ], [ %v30, %bb8 ]
  %v19 = icmp ult i64 %v15, %v14
  switch i1 %v19, label %invalid.tag.b4 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b4:
  unreachable
bb5:
  store %wf.t.dceb7b9db1c9ad1d zeroinitializer, ptr %wf.slot.0
  %t4 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.0, i32 0, i32 0
  store i32 0, ptr %t4
  %v21 = getelementptr i8, ptr %v10, i64 0
  %v22 = call i8 @wf_place_back$instance$d5bb00f00cd669fb(ptr %v21, ptr %wf.slot.0)
  br label %bb8
bb6:
  br label %bb7
bb7:
  %v16 = phi ptr [ %v10, %bb6 ]
  %v17 = phi i64 [ %v11, %bb6 ]
  %v18 = phi i64 [ %v12, %bb6 ]
  %v31 = select i1 true, i8 0, i8 0
  ret i8 %v31
bb8:
  %v23 = phi ptr [ %v10, %bb5 ]
  %v24 = phi i64 [ %v11, %bb5 ]
  %v25 = phi i64 [ %v12, %bb5 ]
  %v26 = phi i64 [ %v13, %bb5 ]
  %v27 = phi i64 [ %v14, %bb5 ]
  %v28 = phi i64 [ %v15, %bb5 ]
  %v29 = select i1 true, i64 1, i64 1
  %v30 = add i64 %v28, %v29
  br label %bb4
}

define internal void @wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.dceb7b9db1c9ad1d, align 8
  %wf.slot.1 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.2 = alloca { i64, [1 x %wf.t.d72ca22fbd302a84] }, align 8
  %wf.slot.3 = alloca %wf.t.d72ca22fbd302a84, align 8
  %wf.slot.4 = alloca %wf.t.d72ca22fbd302a84, align 8
  %wf.slot.5 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.6 = alloca %wf.t.114ba5754d75c8d6, align 8
  %wf.slot.7 = alloca %wf.t.d72ca22fbd302a84, align 8
  %wf.slot.8 = alloca { i64, [1 x %wf.t.d72ca22fbd302a84] }, align 8
  %wf.slot.9 = alloca { i64, i64, ptr }, align 8
  %v29 = alloca { i64, i64, ptr }, align 8
  %v63 = alloca { i64, [1 x %wf.t.d72ca22fbd302a84] }, align 8
  %v3 = select i1 true, i64 3, i64 3
  %v4 = icmp ugt i64 %v1, %v3
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v5 = phi ptr [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb3 ]
  %v7 = phi ptr [ %v2, %bb3 ]
  %t0 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %v5, i32 0, i32 0
  %v10 = getelementptr i8, ptr %t0, i64 0
  %v11 = getelementptr i8, ptr %v10, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v11, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v12 = add i64 %t1, 0
  %v13 = icmp ult i64 %v6, %v12
  switch i1 %v13, label %invalid.tag.b1 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v8 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t3 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t3
  %t4 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 2
  store i8 %v8, ptr %t4
  ret void
bb3:
  br label %bb1
bb4:
  %v14 = phi ptr [ %v5, %bb6 ]
  %v15 = phi i64 [ %v6, %bb6 ]
  %v16 = phi ptr [ %v7, %bb6 ]
  %v17 = phi i64 [ %v12, %bb6 ]
  %v20 = select i1 true, i64 0, i64 0
  %v21 = icmp eq i64 %v15, %v20
  switch i1 %v21, label %invalid.tag.b4 [
    i1 1, label %bb8
    i1 0, label %bb9
  ]
invalid.tag.b4:
  unreachable
bb5:
  %v18 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t5 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t5
  %t6 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 2
  store i8 %v18, ptr %t6
  ret void
bb6:
  br label %bb4
bb7:
  %v22 = phi ptr [ %v14, %bb9 ]
  %v23 = phi i64 [ %v15, %bb9 ]
  %v24 = phi ptr [ %v16, %bb9 ]
  %v25 = phi i64 [ %v17, %bb9 ]
  %v28 = call { i64, i64, ptr } @wf_box_slots_new$instance$9eabc50a9cce2251(i64 %v23)
  store { i64, i64, ptr } %v28, ptr %v29
  %v30 = call i8 @wf_std.collections.hash_map.hash_map_extend$instance$96033bf6ddb80743(ptr %v29, i64 %v23)
  %t7 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %v22, i32 0, i32 0
  %v31 = getelementptr i8, ptr %t7, i64 0
  %v32 = call i8 @wf_swap$instance$d692d011b23a4a18(ptr %v31, ptr %v29)
  br label %bb10
bb8:
  %v26 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t8 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t8
  %t9 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 1
  store i8 %v26, ptr %t9
  ret void
bb9:
  br label %bb7
bb10:
  %v33 = phi ptr [ %v22, %bb7 ], [ %v54, %bb15 ]
  %v34 = phi i64 [ %v23, %bb7 ], [ %v55, %bb15 ]
  %v35 = phi ptr [ %v24, %bb7 ], [ %v56, %bb15 ]
  %v36 = phi i64 [ %v25, %bb7 ], [ %v57, %bb15 ]
  %v37 = phi ptr [ %v29, %bb7 ], [ %v58, %bb15 ]
  %v43 = getelementptr i8, ptr %v37, i64 0
  %t11 = getelementptr inbounds { i64, i64, ptr }, ptr %v43, i32 0, i32 0
  %t10 = load i64, ptr %t11
  %v44 = add i64 %t10, 0
  %v45 = select i1 true, i64 0, i64 0
  %v46 = icmp eq i64 %v44, %v45
  switch i1 %v46, label %invalid.tag.b10 [
    i1 1, label %bb13
    i1 0, label %bb14
  ]
invalid.tag.b10:
  unreachable
bb11:
  %v38 = phi ptr [ %v33, %bb13 ]
  %v39 = phi i64 [ %v34, %bb13 ]
  %v40 = phi ptr [ %v35, %bb13 ]
  %v41 = phi i64 [ %v36, %bb13 ]
  %v42 = phi ptr [ %v37, %bb13 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.9, ptr %v42, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  %v205 = call i8 @wf_free_empty$instance$d692d011b23a4a18(ptr %wf.slot.9)
  %t12 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %v38, i32 0, i32 2
  %v206 = getelementptr i8, ptr %t12, i64 0
  %v207 = select i1 true, i64 0, i64 0
  store i64 %v207, ptr %v206
  %v208 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t13 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t13
  %t14 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 1
  store i8 %v208, ptr %t14
  ret void
bb12:
  %v47 = phi ptr [ %v33, %bb14 ]
  %v48 = phi i64 [ %v34, %bb14 ]
  %v49 = phi ptr [ %v35, %bb14 ]
  %v50 = phi i64 [ %v36, %bb14 ]
  %v51 = phi ptr [ %v37, %bb14 ]
  %v52 = getelementptr i8, ptr %v51, i64 0
  call void @wf_take_back$instance$d5bb00f00cd669fb(ptr %wf.slot.0, ptr %v52)
  %t15 = load %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.0
  %t16 = extractvalue %wf.t.dceb7b9db1c9ad1d %t15, 0
  switch i32 %t16, label %invalid.tag.b12 [
    i32 0, label %bb16
    i32 1, label %bb17
    i32 2, label %bb18
  ]
invalid.tag.b12:
  unreachable
bb13:
  br label %bb11
bb14:
  br label %bb12
bb15:
  %v54 = phi ptr [ %v47, %bb16 ], [ %v47, %bb17 ], [ %v76, %bb20 ]
  %v55 = phi i64 [ %v48, %bb16 ], [ %v48, %bb17 ], [ %v77, %bb20 ]
  %v56 = phi ptr [ %v49, %bb16 ], [ %v49, %bb17 ], [ %v78, %bb20 ]
  %v57 = phi i64 [ %v50, %bb16 ], [ %v50, %bb17 ], [ %v79, %bb20 ]
  %v58 = phi ptr [ %v51, %bb16 ], [ %v51, %bb17 ], [ %v80, %bb20 ]
  br label %bb10
bb16:
  br label %bb15
bb17:
  br label %bb15
bb18:
  %t17 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.0, i32 0, i32 1
  %v60 = load i64, ptr %t17
  %t18 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.0, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %t18, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  call void @wf_slots_new$instance$8ac6e57475a1cbbb(ptr %wf.slot.2)
  call void @llvm.memmove.p0.p0.i64(ptr %v63, ptr %wf.slot.2, i64 ptrtoint (ptr getelementptr ({ i64, [1 x %wf.t.d72ca22fbd302a84] }, ptr null, i32 1) to i64), i1 false)
  store %wf.t.d72ca22fbd302a84 zeroinitializer, ptr %wf.slot.3
  %t19 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.3, i32 0, i32 0
  store i64 %v60, ptr %t19
  %t20 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.3, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t20, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %v65 = call i8 @wf_place_back$instance$c189ec082e7c2a1f(ptr %v63, ptr %wf.slot.3)
  br label %bb19
bb19:
  %v66 = phi ptr [ %v47, %bb18 ], [ %v122, %bb27 ]
  %v67 = phi i64 [ %v48, %bb18 ], [ %v123, %bb27 ]
  %v68 = phi ptr [ %v49, %bb18 ], [ %v124, %bb27 ]
  %v69 = phi i64 [ %v50, %bb18 ], [ %v125, %bb27 ]
  %v70 = phi ptr [ %v51, %bb18 ], [ %v126, %bb27 ]
  %v72 = phi i64 [ %v60, %bb18 ], [ %v128, %bb27 ]
  %v74 = phi ptr [ %v63, %bb18 ], [ %v130, %bb27 ]
  %t22 = getelementptr inbounds { i64, [1 x %wf.t.d72ca22fbd302a84] }, ptr %v74, i32 0, i32 0
  %t21 = load i64, ptr %t22
  %v86 = add i64 %t21, 0
  %v87 = select i1 true, i64 0, i64 0
  %v88 = icmp eq i64 %v86, %v87
  switch i1 %v88, label %invalid.tag.b19 [
    i1 1, label %bb22
    i1 0, label %bb23
  ]
invalid.tag.b19:
  unreachable
bb20:
  %v76 = phi ptr [ %v66, %bb22 ]
  %v77 = phi i64 [ %v67, %bb22 ]
  %v78 = phi ptr [ %v68, %bb22 ]
  %v79 = phi i64 [ %v69, %bb22 ]
  %v80 = phi ptr [ %v70, %bb22 ]
  %v82 = phi i64 [ %v72, %bb22 ]
  %v84 = phi ptr [ %v74, %bb22 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.8, ptr %v84, i64 ptrtoint (ptr getelementptr ({ i64, [1 x %wf.t.d72ca22fbd302a84] }, ptr null, i32 1) to i64), i1 false)
  %v203 = call i8 @wf_free_empty$instance$41f1fc367c8c34ad(ptr %wf.slot.8)
  br label %bb15
bb21:
  %v89 = phi ptr [ %v66, %bb23 ]
  %v90 = phi i64 [ %v67, %bb23 ]
  %v91 = phi ptr [ %v68, %bb23 ]
  %v92 = phi i64 [ %v69, %bb23 ]
  %v93 = phi ptr [ %v70, %bb23 ]
  %v95 = phi i64 [ %v72, %bb23 ]
  %v97 = phi ptr [ %v74, %bb23 ]
  %v99 = select i1 true, i64 0, i64 0
  %t23.nonnegative = icmp sge i64 %v99, 0
  call void @llvm.assume(i1 %t23.nonnegative)
  %t23 = getelementptr inbounds { i64, [1 x %wf.t.d72ca22fbd302a84] }, ptr %v97, i64 0, i32 1, i64 %v99
  %v100 = getelementptr i8, ptr %t23, i64 0
  %t24 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %v100, i32 0, i32 0
  %v101 = getelementptr i8, ptr %t24, i64 0
  %v102 = call i64 @wf_map_cost_hash(ptr %v91, ptr %v101)
  %t25 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %v89, i32 0, i32 0
  %v103 = getelementptr i8, ptr %t25, i64 0
  %v104 = getelementptr i8, ptr %v103, i64 0
  %t27 = getelementptr inbounds { i64, i64, ptr }, ptr %v104, i32 0, i32 0
  %t26 = load i64, ptr %t27
  %v105 = add i64 %t26, 0
  %v106 = select i1 true, i64 0, i64 0
  br label %bb24
bb22:
  br label %bb20
bb23:
  br label %bb21
bb24:
  %v107 = phi ptr [ %v89, %bb21 ], [ %v185, %bb34 ]
  %v108 = phi i64 [ %v90, %bb21 ], [ %v186, %bb34 ]
  %v109 = phi ptr [ %v91, %bb21 ], [ %v187, %bb34 ]
  %v110 = phi i64 [ %v92, %bb21 ], [ %v188, %bb34 ]
  %v111 = phi ptr [ %v93, %bb21 ], [ %v189, %bb34 ]
  %v113 = phi i64 [ %v95, %bb21 ], [ %v191, %bb34 ]
  %v115 = phi ptr [ %v97, %bb21 ], [ %v193, %bb34 ]
  %v117 = phi i64 [ %v102, %bb21 ], [ %v195, %bb34 ]
  %v118 = phi i64 [ %v105, %bb21 ], [ %v196, %bb34 ]
  %v119 = phi i64 [ %v106, %bb21 ], [ %v197, %bb34 ]
  %v120 = phi i64 [ %v105, %bb21 ], [ %v198, %bb34 ]
  %v121 = phi i64 [ %v106, %bb21 ], [ %v201, %bb34 ]
  %v134 = icmp ult i64 %v121, %v120
  switch i1 %v134, label %invalid.tag.b24 [
    i1 1, label %bb25
    i1 0, label %bb26
  ]
invalid.tag.b24:
  unreachable
bb25:
  %v135 = urem i64 %v117, %v118
  %v136 = call i64 @wf_std.collections.hash_map.hash_map_probe(i64 %v135, i64 %v121, i64 %v118)
  %t28 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %v107, i32 0, i32 0
  %v137 = getelementptr i8, ptr %t28, i64 0
  %v138 = getelementptr i8, ptr %v137, i64 0
  %t30 = getelementptr inbounds { i64, i64, ptr }, ptr %v138, i32 0, i32 2
  %t31 = load ptr, ptr %t30
  %t29.nonnegative = icmp sge i64 %v136, 0
  call void @llvm.assume(i1 %t29.nonnegative)
  %t29 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %t31, i64 %v136
  %v139 = getelementptr i8, ptr %t29, i64 0
  %v140 = call i1 @wf_std.collections.hash_map.hash_map_is_available$instance$d7a1a90c27bba449(ptr %v139)
  switch i1 %v140, label %invalid.tag.b25 [
    i1 1, label %bb29
    i1 0, label %bb30
  ]
invalid.tag.b25:
  unreachable
bb26:
  br label %bb27
bb27:
  %v122 = phi ptr [ %v107, %bb26 ], [ %v162, %bb31 ]
  %v123 = phi i64 [ %v108, %bb26 ], [ %v163, %bb31 ]
  %v124 = phi ptr [ %v109, %bb26 ], [ %v164, %bb31 ]
  %v125 = phi i64 [ %v110, %bb26 ], [ %v165, %bb31 ]
  %v126 = phi ptr [ %v111, %bb26 ], [ %v166, %bb31 ]
  %v128 = phi i64 [ %v113, %bb26 ], [ %v168, %bb31 ]
  %v130 = phi ptr [ %v115, %bb26 ], [ %v170, %bb31 ]
  %v132 = phi i64 [ %v117, %bb26 ], [ %v172, %bb31 ]
  %v133 = phi i64 [ %v118, %bb26 ], [ %v173, %bb31 ]
  br label %bb19
bb28:
  %v141 = phi ptr [ %v107, %bb30 ]
  %v142 = phi i64 [ %v108, %bb30 ]
  %v143 = phi ptr [ %v109, %bb30 ]
  %v144 = phi i64 [ %v110, %bb30 ]
  %v145 = phi ptr [ %v111, %bb30 ]
  %v147 = phi i64 [ %v113, %bb30 ]
  %v149 = phi ptr [ %v115, %bb30 ]
  %v151 = phi i64 [ %v117, %bb30 ]
  %v152 = phi i64 [ %v118, %bb30 ]
  %v153 = phi i64 [ %v121, %bb30 ]
  %v154 = phi i64 [ %v135, %bb30 ]
  %v155 = phi i64 [ %v136, %bb30 ]
  %v156 = phi i1 [ %v140, %bb30 ]
  br label %bb34
bb29:
  call void @wf_take_back$instance$c189ec082e7c2a1f(ptr %wf.slot.4, ptr %v115)
  %t32 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.4, i32 0, i32 0
  %v158 = load i64, ptr %t32
  ; ownership-consuming projection
  %t33 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.4, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.5, ptr %t33, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %t34 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %v107, i32 0, i32 0
  %v160 = getelementptr i8, ptr %t34, i64 0
  call void @wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449(ptr %wf.slot.6, ptr %v160, i64 %v136, i64 %v158, ptr %wf.slot.5)
  %t35 = load %wf.t.114ba5754d75c8d6, ptr %wf.slot.6
  %t36 = extractvalue %wf.t.114ba5754d75c8d6 %t35, 0
  switch i32 %t36, label %invalid.tag.b29 [
    i32 0, label %bb32
    i32 1, label %bb33
  ]
invalid.tag.b29:
  unreachable
bb30:
  br label %bb28
bb31:
  %v162 = phi ptr [ %v107, %bb32 ], [ %v107, %bb33 ]
  %v163 = phi i64 [ %v108, %bb32 ], [ %v108, %bb33 ]
  %v164 = phi ptr [ %v109, %bb32 ], [ %v109, %bb33 ]
  %v165 = phi i64 [ %v110, %bb32 ], [ %v110, %bb33 ]
  %v166 = phi ptr [ %v111, %bb32 ], [ %v111, %bb33 ]
  %v168 = phi i64 [ %v113, %bb32 ], [ %v113, %bb33 ]
  %v170 = phi ptr [ %v115, %bb32 ], [ %v115, %bb33 ]
  %v172 = phi i64 [ %v117, %bb32 ], [ %v117, %bb33 ]
  %v173 = phi i64 [ %v118, %bb32 ], [ %v118, %bb33 ]
  %v174 = phi i64 [ %v121, %bb32 ], [ %v121, %bb33 ]
  %v175 = phi i64 [ %v135, %bb32 ], [ %v135, %bb33 ]
  %v176 = phi i64 [ %v136, %bb32 ], [ %v136, %bb33 ]
  %v177 = phi i1 [ %v140, %bb32 ], [ %v140, %bb33 ]
  %v179 = phi i64 [ %v158, %bb32 ], [ %v158, %bb33 ]
  br label %bb27
bb32:
  br label %bb31
bb33:
  %t37 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.slot.6, i32 0, i32 1
  %v182 = load i1, ptr %t37
  %t38 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.slot.6, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.7, ptr %t38, i64 ptrtoint (ptr getelementptr (%wf.t.d72ca22fbd302a84, ptr null, i32 1) to i64), i1 false)
  %v184 = call i8 @wf_place_back$instance$c189ec082e7c2a1f(ptr %v115, ptr %wf.slot.7)
  br label %bb31
bb34:
  %v185 = phi ptr [ %v141, %bb28 ]
  %v186 = phi i64 [ %v142, %bb28 ]
  %v187 = phi ptr [ %v143, %bb28 ]
  %v188 = phi i64 [ %v144, %bb28 ]
  %v189 = phi ptr [ %v145, %bb28 ]
  %v191 = phi i64 [ %v147, %bb28 ]
  %v193 = phi ptr [ %v149, %bb28 ]
  %v195 = phi i64 [ %v151, %bb28 ]
  %v196 = phi i64 [ %v152, %bb28 ]
  %v197 = phi i64 [ %v119, %bb28 ]
  %v198 = phi i64 [ %v120, %bb28 ]
  %v199 = phi i64 [ %v121, %bb28 ]
  %v200 = select i1 true, i64 1, i64 1
  %v201 = add i64 %v199, %v200
  br label %bb24
}

define %wf.t.7d7f918f7b4962fd @wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07(ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.result = alloca %wf.t.7d7f918f7b4962fd, align 4
  call void @wf_std.collections.hash_map.hash_map_rebuild$instance$8d5197e2f00c3b07.body(ptr %wf.result, ptr %v0, i64 %v1, ptr %v2)
  %wf.returned = load %wf.t.7d7f918f7b4962fd, ptr %wf.result
  ret %wf.t.7d7f918f7b4962fd %wf.returned
}

define void @wf_std.collections.hash_map.hash_map_try_put$instance$8d5197e2f00c3b07(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr %wf.arg.v2, ptr noalias nonnull captures(none) dereferenceable(16) %v3) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.4380a1278c72e25d, align 8
  %wf.slot.1 = alloca %wf.t.4380a1278c72e25d, align 8
  %wf.slot.2 = alloca %wf.t.d72ca22fbd302a84, align 8
  %v4 = alloca i64, align 8
  store i64 %v1, ptr %v4
  %v5 = call i64 @wf_map_cost_hash(ptr %v3, ptr %v4)
  %t0 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %v0, i32 0, i32 0
  %v6 = getelementptr i8, ptr %t0, i64 0
  %v7 = getelementptr i8, ptr %v6, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v7, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v8 = add i64 %t1, 0
  %v9 = select i1 true, i64 0, i64 0
  %v10 = icmp ugt i64 %v8, %v9
  switch i1 %v10, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v11 = phi ptr [ %v0, %bb3 ], [ %v31, %bb7 ]
  %v12 = phi ptr [ %v4, %bb3 ], [ %v32, %bb7 ]
  %v14 = phi ptr [ %v3, %bb3 ], [ %v34, %bb7 ]
  %v15 = phi i64 [ %v5, %bb3 ], [ %v35, %bb7 ]
  %v16 = phi i64 [ %v8, %bb3 ], [ %v36, %bb7 ]
  %v17 = phi i64 [ %v8, %bb3 ], [ %v37, %bb7 ]
  %v107 = icmp ult i64 %v17, %v16
  switch i1 %v107, label %invalid.tag.b1 [
    i1 1, label %bb24
    i1 0, label %bb25
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v18 = urem i64 %v5, %v8
  %v19 = select i1 true, i64 0, i64 0
  br label %bb4
bb3:
  br label %bb1
bb4:
  %v20 = phi ptr [ %v0, %bb2 ], [ %v94, %bb22 ]
  %v21 = phi ptr [ %v4, %bb2 ], [ %v95, %bb22 ]
  %v23 = phi ptr [ %v3, %bb2 ], [ %v97, %bb22 ]
  %v24 = phi i64 [ %v5, %bb2 ], [ %v98, %bb22 ]
  %v25 = phi i64 [ %v8, %bb2 ], [ %v99, %bb22 ]
  %v26 = phi i64 [ %v8, %bb2 ], [ %v100, %bb22 ]
  %v27 = phi i64 [ %v18, %bb2 ], [ %v101, %bb22 ]
  %v28 = phi i64 [ %v19, %bb2 ], [ %v102, %bb22 ]
  %v29 = phi i64 [ %v8, %bb2 ], [ %v103, %bb22 ]
  %v30 = phi i64 [ %v19, %bb2 ], [ %v106, %bb22 ]
  %v39 = icmp ult i64 %v30, %v29
  switch i1 %v39, label %invalid.tag.b4 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b4:
  unreachable
bb5:
  %t3 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %v20, i32 0, i32 0
  %v40 = getelementptr i8, ptr %t3, i64 0
  %v41 = getelementptr i8, ptr %v40, i64 0
  %t5 = getelementptr inbounds { i64, i64, ptr }, ptr %v41, i32 0, i32 2
  %t6 = load ptr, ptr %t5
  %t4.nonnegative = icmp sge i64 %v27, 0
  call void @llvm.assume(i1 %t4.nonnegative)
  %t4 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %t6, i64 %v27
  %v42 = getelementptr i8, ptr %t4, i64 0
  %v43 = call i32 @wf_std.collections.hash_map.hash_map_action$instance$c6df3d8464f8cde0(ptr %v42, ptr %v21, ptr %v23)
  switch i32 %v43, label %invalid.tag.b5 [
    i32 3, label %bb9
    i32 0, label %bb10
    i32 1, label %bb11
    i32 2, label %bb12
  ]
invalid.tag.b5:
  unreachable
bb6:
  br label %bb7
bb7:
  %v31 = phi ptr [ %v20, %bb6 ], [ %v58, %bb13 ]
  %v32 = phi ptr [ %v21, %bb6 ], [ %v59, %bb13 ]
  %v34 = phi ptr [ %v23, %bb6 ], [ %v61, %bb13 ]
  %v35 = phi i64 [ %v24, %bb6 ], [ %v62, %bb13 ]
  %v36 = phi i64 [ %v25, %bb6 ], [ %v63, %bb13 ]
  %v37 = phi i64 [ %v26, %bb6 ], [ %v64, %bb13 ]
  %v38 = phi i64 [ %v27, %bb6 ], [ %v65, %bb13 ]
  br label %bb1
bb8:
  %v44 = phi ptr [ %v20, %bb12 ], [ %v69, %bb16 ]
  %v45 = phi ptr [ %v21, %bb12 ], [ %v70, %bb16 ]
  %v47 = phi ptr [ %v23, %bb12 ], [ %v72, %bb16 ]
  %v48 = phi i64 [ %v24, %bb12 ], [ %v73, %bb16 ]
  %v49 = phi i64 [ %v25, %bb12 ], [ %v74, %bb16 ]
  %v50 = phi i64 [ %v26, %bb12 ], [ %v75, %bb16 ]
  %v51 = phi i64 [ %v27, %bb12 ], [ %v76, %bb16 ]
  %v52 = phi i64 [ %v30, %bb12 ], [ %v77, %bb16 ]
  %v53 = phi i32 [ %v43, %bb12 ], [ %v78, %bb16 ]
  %v79 = select i1 true, i64 1, i64 1
  %v80 = add nuw i64 %v51, %v79
  %v81 = icmp ult i64 %v80, %v49
  switch i1 %v81, label %invalid.tag.b8 [
    i1 1, label %bb20
    i1 0, label %bb21
  ]
invalid.tag.b8:
  unreachable
bb9:
  %t7 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %v20, i32 0, i32 0
  %v54 = getelementptr i8, ptr %t7, i64 0
  %v55 = load i64, ptr %v21
  call void @wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449(ptr %wf.result, ptr %v54, i64 %v27, i64 %v55, ptr %wf.arg.v2)
  ret void
bb10:
  %v57 = icmp eq i64 %v26, %v25
  switch i1 %v57, label %invalid.tag.b10 [
    i1 1, label %bb14
    i1 0, label %bb15
  ]
invalid.tag.b10:
  unreachable
bb11:
  %v68 = icmp eq i64 %v26, %v25
  switch i1 %v68, label %invalid.tag.b11 [
    i1 1, label %bb17
    i1 0, label %bb18
  ]
invalid.tag.b11:
  unreachable
bb12:
  br label %bb8
bb13:
  %v58 = phi ptr [ %v20, %bb14 ], [ %v20, %bb15 ]
  %v59 = phi ptr [ %v21, %bb14 ], [ %v21, %bb15 ]
  %v61 = phi ptr [ %v23, %bb14 ], [ %v23, %bb15 ]
  %v62 = phi i64 [ %v24, %bb14 ], [ %v24, %bb15 ]
  %v63 = phi i64 [ %v25, %bb14 ], [ %v25, %bb15 ]
  %v64 = phi i64 [ %v27, %bb14 ], [ %v26, %bb15 ]
  %v65 = phi i64 [ %v27, %bb14 ], [ %v27, %bb15 ]
  %v66 = phi i64 [ %v30, %bb14 ], [ %v30, %bb15 ]
  %v67 = phi i32 [ %v43, %bb14 ], [ %v43, %bb15 ]
  br label %bb7
bb14:
  br label %bb13
bb15:
  br label %bb13
bb16:
  %v69 = phi ptr [ %v20, %bb17 ], [ %v20, %bb18 ]
  %v70 = phi ptr [ %v21, %bb17 ], [ %v21, %bb18 ]
  %v72 = phi ptr [ %v23, %bb17 ], [ %v23, %bb18 ]
  %v73 = phi i64 [ %v24, %bb17 ], [ %v24, %bb18 ]
  %v74 = phi i64 [ %v25, %bb17 ], [ %v25, %bb18 ]
  %v75 = phi i64 [ %v27, %bb17 ], [ %v26, %bb18 ]
  %v76 = phi i64 [ %v27, %bb17 ], [ %v27, %bb18 ]
  %v77 = phi i64 [ %v30, %bb17 ], [ %v30, %bb18 ]
  %v78 = phi i32 [ %v43, %bb17 ], [ %v43, %bb18 ]
  br label %bb8
bb17:
  br label %bb16
bb18:
  br label %bb16
bb19:
  %v82 = phi ptr [ %v44, %bb20 ], [ %v44, %bb21 ]
  %v83 = phi ptr [ %v45, %bb20 ], [ %v45, %bb21 ]
  %v85 = phi ptr [ %v47, %bb20 ], [ %v47, %bb21 ]
  %v86 = phi i64 [ %v48, %bb20 ], [ %v48, %bb21 ]
  %v87 = phi i64 [ %v49, %bb20 ], [ %v49, %bb21 ]
  %v88 = phi i64 [ %v50, %bb20 ], [ %v50, %bb21 ]
  %v89 = phi i64 [ %v80, %bb20 ], [ %v93, %bb21 ]
  %v90 = phi i64 [ %v52, %bb20 ], [ %v52, %bb21 ]
  %v91 = phi i32 [ %v53, %bb20 ], [ %v53, %bb21 ]
  %v92 = phi i64 [ %v80, %bb20 ], [ %v80, %bb21 ]
  br label %bb22
bb20:
  br label %bb19
bb21:
  %v93 = select i1 true, i64 0, i64 0
  br label %bb19
bb22:
  %v94 = phi ptr [ %v82, %bb19 ]
  %v95 = phi ptr [ %v83, %bb19 ]
  %v97 = phi ptr [ %v85, %bb19 ]
  %v98 = phi i64 [ %v86, %bb19 ]
  %v99 = phi i64 [ %v87, %bb19 ]
  %v100 = phi i64 [ %v88, %bb19 ]
  %v101 = phi i64 [ %v89, %bb19 ]
  %v102 = phi i64 [ %v28, %bb19 ]
  %v103 = phi i64 [ %v29, %bb19 ]
  %v104 = phi i64 [ %v30, %bb19 ]
  %v105 = select i1 true, i64 1, i64 1
  %v106 = add i64 %v104, %v105
  br label %bb4
bb23:
  %v108 = phi ptr [ %v11, %bb25 ], [ %v119, %bb26 ]
  %v109 = phi ptr [ %v12, %bb25 ], [ %v120, %bb26 ]
  %v111 = phi ptr [ %v14, %bb25 ], [ %v122, %bb26 ]
  %v112 = phi i64 [ %v15, %bb25 ], [ %v123, %bb26 ]
  %v113 = phi i64 [ %v16, %bb25 ], [ %v124, %bb26 ]
  %v114 = phi i64 [ %v17, %bb25 ], [ %v125, %bb26 ]
  %v151 = load i64, ptr %v109
  store %wf.t.d72ca22fbd302a84 zeroinitializer, ptr %wf.slot.2
  %t8 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.2, i32 0, i32 0
  store i64 %v151, ptr %t8
  %t9 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.2, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t9, ptr %wf.arg.v2, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %v153 = or i1 0, 1
  store %wf.t.114ba5754d75c8d6 zeroinitializer, ptr %wf.result
  %t10 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t10
  %t11 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.result, i32 0, i32 1
  store i1 %v153, ptr %t11
  %t12 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t12, ptr %wf.slot.2, i64 ptrtoint (ptr getelementptr (%wf.t.d72ca22fbd302a84, ptr null, i32 1) to i64), i1 false)
  ret void
bb24:
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v11, i64 ptrtoint (ptr getelementptr (%wf.t.4380a1278c72e25d, ptr null, i32 1) to i64), i1 false)
  %t13 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %wf.slot.0, i32 0, i32 1
  %v116 = load i64, ptr %t13
  %v117 = select i1 true, i64 3, i64 3
  %v118 = icmp ult i64 %v116, %v117
  switch i1 %v118, label %invalid.tag.b24 [
    i1 1, label %bb27
    i1 0, label %bb28
  ]
invalid.tag.b24:
  unreachable
bb25:
  br label %bb23
bb26:
  %v119 = phi ptr [ %v11, %bb28 ]
  %v120 = phi ptr [ %v12, %bb28 ]
  %v122 = phi ptr [ %v14, %bb28 ]
  %v123 = phi i64 [ %v15, %bb28 ]
  %v124 = phi i64 [ %v16, %bb28 ]
  %v125 = phi i64 [ %v17, %bb28 ]
  %v126 = phi i64 [ %v116, %bb28 ]
  br label %bb23
bb27:
  %t14 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %v11, i32 0, i32 1
  %v127 = getelementptr i8, ptr %t14, i64 0
  %v128 = select i1 true, i64 1, i64 1
  %v129 = add nuw i64 %v116, %v128
  store i64 %v129, ptr %v127
  %t15 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %v11, i32 0, i32 0
  %v130 = getelementptr i8, ptr %t15, i64 0
  %v131 = getelementptr i8, ptr %v130, i64 0
  %t17 = getelementptr inbounds { i64, i64, ptr }, ptr %v131, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  %t16.nonnegative = icmp sge i64 %v17, 0
  call void @llvm.assume(i1 %t16.nonnegative)
  %t16 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %t18, i64 %v17
  %v132 = getelementptr i8, ptr %t16, i64 0
  %v133 = call i1 @wf_std.collections.hash_map.hash_map_is_deleted$instance$d7a1a90c27bba449(ptr %v132)
  switch i1 %v133, label %invalid.tag.b27 [
    i1 1, label %bb30
    i1 0, label %bb31
  ]
invalid.tag.b27:
  unreachable
bb28:
  br label %bb26
bb29:
  %v134 = phi ptr [ %v11, %bb30 ], [ %v11, %bb31 ]
  %v135 = phi ptr [ %v12, %bb30 ], [ %v12, %bb31 ]
  %v137 = phi ptr [ %v14, %bb30 ], [ %v14, %bb31 ]
  %v138 = phi i64 [ %v15, %bb30 ], [ %v15, %bb31 ]
  %v139 = phi i64 [ %v16, %bb30 ], [ %v16, %bb31 ]
  %v140 = phi i64 [ %v17, %bb30 ], [ %v17, %bb31 ]
  %v141 = phi i64 [ %v116, %bb30 ], [ %v116, %bb31 ]
  %v142 = phi i1 [ %v133, %bb30 ], [ %v133, %bb31 ]
  %t19 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %v134, i32 0, i32 0
  %v148 = getelementptr i8, ptr %t19, i64 0
  %v149 = load i64, ptr %v135
  call void @wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449(ptr %wf.result, ptr %v148, i64 %v140, i64 %v149, ptr %wf.arg.v2)
  ret void
bb30:
  %t20 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %v11, i32 0, i32 2
  %v143 = getelementptr i8, ptr %t20, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v11, i64 ptrtoint (ptr getelementptr (%wf.t.4380a1278c72e25d, ptr null, i32 1) to i64), i1 false)
  %t21 = getelementptr inbounds %wf.t.4380a1278c72e25d, ptr %wf.slot.1, i32 0, i32 2
  %v145 = load i64, ptr %t21
  %v146 = select i1 true, i64 1, i64 1
  %v147 = call i64 @llvm.usub.sat.i64(i64 %v145, i64 %v146)
  store i64 %v147, ptr %v143
  br label %bb29
bb31:
  br label %bb29
}

define i8 @wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374(ptr noalias nonnull captures(none) dereferenceable(24) %v0, i64 %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.dceb7b9db1c9ad1d, align 8
  %v2 = getelementptr i8, ptr %v0, i64 0
  %t1 = getelementptr inbounds { i64, i64, ptr }, ptr %v2, i32 0, i32 1
  %t0 = load i64, ptr %t1
  %v3 = add i64 %t0, 0
  %v4 = icmp ult i64 %v3, %v1
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v5 = phi ptr [ %v0, %bb2 ], [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb2 ], [ %v1, %bb3 ]
  %v8 = getelementptr i8, ptr %v5, i64 0
  %t3 = getelementptr inbounds { i64, i64, ptr }, ptr %v8, i32 0, i32 0
  %t2 = load i64, ptr %t3
  %v9 = add i64 %t2, 0
  br label %bb4
bb2:
  %v7 = call i8 @wf_grow$instance$9eabc50a9cce2251(ptr %v0, i64 %v1)
  br label %bb1
bb3:
  br label %bb1
bb4:
  %v10 = phi ptr [ %v5, %bb1 ], [ %v23, %bb8 ]
  %v11 = phi i64 [ %v6, %bb1 ], [ %v24, %bb8 ]
  %v12 = phi i64 [ %v9, %bb1 ], [ %v25, %bb8 ]
  %v13 = phi i64 [ %v9, %bb1 ], [ %v26, %bb8 ]
  %v14 = phi i64 [ %v6, %bb1 ], [ %v27, %bb8 ]
  %v15 = phi i64 [ %v9, %bb1 ], [ %v30, %bb8 ]
  %v19 = icmp ult i64 %v15, %v14
  switch i1 %v19, label %invalid.tag.b4 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b4:
  unreachable
bb5:
  store %wf.t.dceb7b9db1c9ad1d zeroinitializer, ptr %wf.slot.0
  %t4 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.0, i32 0, i32 0
  store i32 0, ptr %t4
  %v21 = getelementptr i8, ptr %v10, i64 0
  %v22 = call i8 @wf_place_back$instance$d5bb00f00cd669fb(ptr %v21, ptr %wf.slot.0)
  br label %bb8
bb6:
  br label %bb7
bb7:
  %v16 = phi ptr [ %v10, %bb6 ]
  %v17 = phi i64 [ %v11, %bb6 ]
  %v18 = phi i64 [ %v12, %bb6 ]
  %v31 = select i1 true, i8 0, i8 0
  ret i8 %v31
bb8:
  %v23 = phi ptr [ %v10, %bb5 ]
  %v24 = phi i64 [ %v11, %bb5 ]
  %v25 = phi i64 [ %v12, %bb5 ]
  %v26 = phi i64 [ %v13, %bb5 ]
  %v27 = phi i64 [ %v14, %bb5 ]
  %v28 = phi i64 [ %v15, %bb5 ]
  %v29 = select i1 true, i64 1, i64 1
  %v30 = add i64 %v28, %v29
  br label %bb4
}

define internal void @wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.dceb7b9db1c9ad1d, align 8
  %wf.slot.1 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.2 = alloca { i64, [1 x %wf.t.d72ca22fbd302a84] }, align 8
  %wf.slot.3 = alloca %wf.t.d72ca22fbd302a84, align 8
  %wf.slot.4 = alloca %wf.t.d72ca22fbd302a84, align 8
  %wf.slot.5 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.6 = alloca %wf.t.114ba5754d75c8d6, align 8
  %wf.slot.7 = alloca %wf.t.d72ca22fbd302a84, align 8
  %wf.slot.8 = alloca { i64, [1 x %wf.t.d72ca22fbd302a84] }, align 8
  %wf.slot.9 = alloca { i64, i64, ptr }, align 8
  %v29 = alloca { i64, i64, ptr }, align 8
  %v63 = alloca { i64, [1 x %wf.t.d72ca22fbd302a84] }, align 8
  %v3 = select i1 true, i64 16384, i64 16384
  %v4 = icmp ugt i64 %v1, %v3
  switch i1 %v4, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v5 = phi ptr [ %v0, %bb3 ]
  %v6 = phi i64 [ %v1, %bb3 ]
  %v7 = phi ptr [ %v2, %bb3 ]
  %t0 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v5, i32 0, i32 0
  %v10 = getelementptr i8, ptr %t0, i64 0
  %v11 = getelementptr i8, ptr %v10, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v11, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v12 = add i64 %t1, 0
  %v13 = icmp ult i64 %v6, %v12
  switch i1 %v13, label %invalid.tag.b1 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v8 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t3 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t3
  %t4 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 2
  store i8 %v8, ptr %t4
  ret void
bb3:
  br label %bb1
bb4:
  %v14 = phi ptr [ %v5, %bb6 ]
  %v15 = phi i64 [ %v6, %bb6 ]
  %v16 = phi ptr [ %v7, %bb6 ]
  %v17 = phi i64 [ %v12, %bb6 ]
  %v20 = select i1 true, i64 0, i64 0
  %v21 = icmp eq i64 %v15, %v20
  switch i1 %v21, label %invalid.tag.b4 [
    i1 1, label %bb8
    i1 0, label %bb9
  ]
invalid.tag.b4:
  unreachable
bb5:
  %v18 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t5 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t5
  %t6 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 2
  store i8 %v18, ptr %t6
  ret void
bb6:
  br label %bb4
bb7:
  %v22 = phi ptr [ %v14, %bb9 ]
  %v23 = phi i64 [ %v15, %bb9 ]
  %v24 = phi ptr [ %v16, %bb9 ]
  %v25 = phi i64 [ %v17, %bb9 ]
  %v28 = call { i64, i64, ptr } @wf_box_slots_new$instance$9eabc50a9cce2251(i64 %v23)
  store { i64, i64, ptr } %v28, ptr %v29
  %v30 = call i8 @wf_std.collections.hash_map.hash_map_extend$instance$0e108827ecbbe374(ptr %v29, i64 %v23)
  %t7 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v22, i32 0, i32 0
  %v31 = getelementptr i8, ptr %t7, i64 0
  %v32 = call i8 @wf_swap$instance$d692d011b23a4a18(ptr %v31, ptr %v29)
  br label %bb10
bb8:
  %v26 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t8 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t8
  %t9 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 1
  store i8 %v26, ptr %t9
  ret void
bb9:
  br label %bb7
bb10:
  %v33 = phi ptr [ %v22, %bb7 ], [ %v54, %bb15 ]
  %v34 = phi i64 [ %v23, %bb7 ], [ %v55, %bb15 ]
  %v35 = phi ptr [ %v24, %bb7 ], [ %v56, %bb15 ]
  %v36 = phi i64 [ %v25, %bb7 ], [ %v57, %bb15 ]
  %v37 = phi ptr [ %v29, %bb7 ], [ %v58, %bb15 ]
  %v43 = getelementptr i8, ptr %v37, i64 0
  %t11 = getelementptr inbounds { i64, i64, ptr }, ptr %v43, i32 0, i32 0
  %t10 = load i64, ptr %t11
  %v44 = add i64 %t10, 0
  %v45 = select i1 true, i64 0, i64 0
  %v46 = icmp eq i64 %v44, %v45
  switch i1 %v46, label %invalid.tag.b10 [
    i1 1, label %bb13
    i1 0, label %bb14
  ]
invalid.tag.b10:
  unreachable
bb11:
  %v38 = phi ptr [ %v33, %bb13 ]
  %v39 = phi i64 [ %v34, %bb13 ]
  %v40 = phi ptr [ %v35, %bb13 ]
  %v41 = phi i64 [ %v36, %bb13 ]
  %v42 = phi ptr [ %v37, %bb13 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.9, ptr %v42, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  %v205 = call i8 @wf_free_empty$instance$d692d011b23a4a18(ptr %wf.slot.9)
  %t12 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v38, i32 0, i32 2
  %v206 = getelementptr i8, ptr %t12, i64 0
  %v207 = select i1 true, i64 0, i64 0
  store i64 %v207, ptr %v206
  %v208 = select i1 true, i8 0, i8 0
  store %wf.t.7d7f918f7b4962fd zeroinitializer, ptr %wf.result
  %t13 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t13
  %t14 = getelementptr inbounds %wf.t.7d7f918f7b4962fd, ptr %wf.result, i32 0, i32 1
  store i8 %v208, ptr %t14
  ret void
bb12:
  %v47 = phi ptr [ %v33, %bb14 ]
  %v48 = phi i64 [ %v34, %bb14 ]
  %v49 = phi ptr [ %v35, %bb14 ]
  %v50 = phi i64 [ %v36, %bb14 ]
  %v51 = phi ptr [ %v37, %bb14 ]
  %v52 = getelementptr i8, ptr %v51, i64 0
  call void @wf_take_back$instance$d5bb00f00cd669fb(ptr %wf.slot.0, ptr %v52)
  %t15 = load %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.0
  %t16 = extractvalue %wf.t.dceb7b9db1c9ad1d %t15, 0
  switch i32 %t16, label %invalid.tag.b12 [
    i32 0, label %bb16
    i32 1, label %bb17
    i32 2, label %bb18
  ]
invalid.tag.b12:
  unreachable
bb13:
  br label %bb11
bb14:
  br label %bb12
bb15:
  %v54 = phi ptr [ %v47, %bb16 ], [ %v47, %bb17 ], [ %v76, %bb20 ]
  %v55 = phi i64 [ %v48, %bb16 ], [ %v48, %bb17 ], [ %v77, %bb20 ]
  %v56 = phi ptr [ %v49, %bb16 ], [ %v49, %bb17 ], [ %v78, %bb20 ]
  %v57 = phi i64 [ %v50, %bb16 ], [ %v50, %bb17 ], [ %v79, %bb20 ]
  %v58 = phi ptr [ %v51, %bb16 ], [ %v51, %bb17 ], [ %v80, %bb20 ]
  br label %bb10
bb16:
  br label %bb15
bb17:
  br label %bb15
bb18:
  %t17 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.0, i32 0, i32 1
  %v60 = load i64, ptr %t17
  %t18 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.0, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %t18, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  call void @wf_slots_new$instance$8ac6e57475a1cbbb(ptr %wf.slot.2)
  call void @llvm.memmove.p0.p0.i64(ptr %v63, ptr %wf.slot.2, i64 ptrtoint (ptr getelementptr ({ i64, [1 x %wf.t.d72ca22fbd302a84] }, ptr null, i32 1) to i64), i1 false)
  store %wf.t.d72ca22fbd302a84 zeroinitializer, ptr %wf.slot.3
  %t19 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.3, i32 0, i32 0
  store i64 %v60, ptr %t19
  %t20 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.3, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t20, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %v65 = call i8 @wf_place_back$instance$c189ec082e7c2a1f(ptr %v63, ptr %wf.slot.3)
  br label %bb19
bb19:
  %v66 = phi ptr [ %v47, %bb18 ], [ %v122, %bb27 ]
  %v67 = phi i64 [ %v48, %bb18 ], [ %v123, %bb27 ]
  %v68 = phi ptr [ %v49, %bb18 ], [ %v124, %bb27 ]
  %v69 = phi i64 [ %v50, %bb18 ], [ %v125, %bb27 ]
  %v70 = phi ptr [ %v51, %bb18 ], [ %v126, %bb27 ]
  %v72 = phi i64 [ %v60, %bb18 ], [ %v128, %bb27 ]
  %v74 = phi ptr [ %v63, %bb18 ], [ %v130, %bb27 ]
  %t22 = getelementptr inbounds { i64, [1 x %wf.t.d72ca22fbd302a84] }, ptr %v74, i32 0, i32 0
  %t21 = load i64, ptr %t22
  %v86 = add i64 %t21, 0
  %v87 = select i1 true, i64 0, i64 0
  %v88 = icmp eq i64 %v86, %v87
  switch i1 %v88, label %invalid.tag.b19 [
    i1 1, label %bb22
    i1 0, label %bb23
  ]
invalid.tag.b19:
  unreachable
bb20:
  %v76 = phi ptr [ %v66, %bb22 ]
  %v77 = phi i64 [ %v67, %bb22 ]
  %v78 = phi ptr [ %v68, %bb22 ]
  %v79 = phi i64 [ %v69, %bb22 ]
  %v80 = phi ptr [ %v70, %bb22 ]
  %v82 = phi i64 [ %v72, %bb22 ]
  %v84 = phi ptr [ %v74, %bb22 ]
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.8, ptr %v84, i64 ptrtoint (ptr getelementptr ({ i64, [1 x %wf.t.d72ca22fbd302a84] }, ptr null, i32 1) to i64), i1 false)
  %v203 = call i8 @wf_free_empty$instance$41f1fc367c8c34ad(ptr %wf.slot.8)
  br label %bb15
bb21:
  %v89 = phi ptr [ %v66, %bb23 ]
  %v90 = phi i64 [ %v67, %bb23 ]
  %v91 = phi ptr [ %v68, %bb23 ]
  %v92 = phi i64 [ %v69, %bb23 ]
  %v93 = phi ptr [ %v70, %bb23 ]
  %v95 = phi i64 [ %v72, %bb23 ]
  %v97 = phi ptr [ %v74, %bb23 ]
  %v99 = select i1 true, i64 0, i64 0
  %t23.nonnegative = icmp sge i64 %v99, 0
  call void @llvm.assume(i1 %t23.nonnegative)
  %t23 = getelementptr inbounds { i64, [1 x %wf.t.d72ca22fbd302a84] }, ptr %v97, i64 0, i32 1, i64 %v99
  %v100 = getelementptr i8, ptr %t23, i64 0
  %t24 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %v100, i32 0, i32 0
  %v101 = getelementptr i8, ptr %t24, i64 0
  %v102 = call i64 @wf_map_cost_hash(ptr %v91, ptr %v101)
  %t25 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v89, i32 0, i32 0
  %v103 = getelementptr i8, ptr %t25, i64 0
  %v104 = getelementptr i8, ptr %v103, i64 0
  %t27 = getelementptr inbounds { i64, i64, ptr }, ptr %v104, i32 0, i32 0
  %t26 = load i64, ptr %t27
  %v105 = add i64 %t26, 0
  %v106 = select i1 true, i64 0, i64 0
  br label %bb24
bb22:
  br label %bb20
bb23:
  br label %bb21
bb24:
  %v107 = phi ptr [ %v89, %bb21 ], [ %v185, %bb34 ]
  %v108 = phi i64 [ %v90, %bb21 ], [ %v186, %bb34 ]
  %v109 = phi ptr [ %v91, %bb21 ], [ %v187, %bb34 ]
  %v110 = phi i64 [ %v92, %bb21 ], [ %v188, %bb34 ]
  %v111 = phi ptr [ %v93, %bb21 ], [ %v189, %bb34 ]
  %v113 = phi i64 [ %v95, %bb21 ], [ %v191, %bb34 ]
  %v115 = phi ptr [ %v97, %bb21 ], [ %v193, %bb34 ]
  %v117 = phi i64 [ %v102, %bb21 ], [ %v195, %bb34 ]
  %v118 = phi i64 [ %v105, %bb21 ], [ %v196, %bb34 ]
  %v119 = phi i64 [ %v106, %bb21 ], [ %v197, %bb34 ]
  %v120 = phi i64 [ %v105, %bb21 ], [ %v198, %bb34 ]
  %v121 = phi i64 [ %v106, %bb21 ], [ %v201, %bb34 ]
  %v134 = icmp ult i64 %v121, %v120
  switch i1 %v134, label %invalid.tag.b24 [
    i1 1, label %bb25
    i1 0, label %bb26
  ]
invalid.tag.b24:
  unreachable
bb25:
  %v135 = urem i64 %v117, %v118
  %v136 = call i64 @wf_std.collections.hash_map.hash_map_probe(i64 %v135, i64 %v121, i64 %v118)
  %t28 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v107, i32 0, i32 0
  %v137 = getelementptr i8, ptr %t28, i64 0
  %v138 = getelementptr i8, ptr %v137, i64 0
  %t30 = getelementptr inbounds { i64, i64, ptr }, ptr %v138, i32 0, i32 2
  %t31 = load ptr, ptr %t30
  %t29.nonnegative = icmp sge i64 %v136, 0
  call void @llvm.assume(i1 %t29.nonnegative)
  %t29 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %t31, i64 %v136
  %v139 = getelementptr i8, ptr %t29, i64 0
  %v140 = call i1 @wf_std.collections.hash_map.hash_map_is_available$instance$d7a1a90c27bba449(ptr %v139)
  switch i1 %v140, label %invalid.tag.b25 [
    i1 1, label %bb29
    i1 0, label %bb30
  ]
invalid.tag.b25:
  unreachable
bb26:
  br label %bb27
bb27:
  %v122 = phi ptr [ %v107, %bb26 ], [ %v162, %bb31 ]
  %v123 = phi i64 [ %v108, %bb26 ], [ %v163, %bb31 ]
  %v124 = phi ptr [ %v109, %bb26 ], [ %v164, %bb31 ]
  %v125 = phi i64 [ %v110, %bb26 ], [ %v165, %bb31 ]
  %v126 = phi ptr [ %v111, %bb26 ], [ %v166, %bb31 ]
  %v128 = phi i64 [ %v113, %bb26 ], [ %v168, %bb31 ]
  %v130 = phi ptr [ %v115, %bb26 ], [ %v170, %bb31 ]
  %v132 = phi i64 [ %v117, %bb26 ], [ %v172, %bb31 ]
  %v133 = phi i64 [ %v118, %bb26 ], [ %v173, %bb31 ]
  br label %bb19
bb28:
  %v141 = phi ptr [ %v107, %bb30 ]
  %v142 = phi i64 [ %v108, %bb30 ]
  %v143 = phi ptr [ %v109, %bb30 ]
  %v144 = phi i64 [ %v110, %bb30 ]
  %v145 = phi ptr [ %v111, %bb30 ]
  %v147 = phi i64 [ %v113, %bb30 ]
  %v149 = phi ptr [ %v115, %bb30 ]
  %v151 = phi i64 [ %v117, %bb30 ]
  %v152 = phi i64 [ %v118, %bb30 ]
  %v153 = phi i64 [ %v121, %bb30 ]
  %v154 = phi i64 [ %v135, %bb30 ]
  %v155 = phi i64 [ %v136, %bb30 ]
  %v156 = phi i1 [ %v140, %bb30 ]
  br label %bb34
bb29:
  call void @wf_take_back$instance$c189ec082e7c2a1f(ptr %wf.slot.4, ptr %v115)
  %t32 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.4, i32 0, i32 0
  %v158 = load i64, ptr %t32
  ; ownership-consuming projection
  %t33 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.4, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.5, ptr %t33, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  ; ownership-consuming projection
  %t34 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v107, i32 0, i32 0
  %v160 = getelementptr i8, ptr %t34, i64 0
  call void @wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449(ptr %wf.slot.6, ptr %v160, i64 %v136, i64 %v158, ptr %wf.slot.5)
  %t35 = load %wf.t.114ba5754d75c8d6, ptr %wf.slot.6
  %t36 = extractvalue %wf.t.114ba5754d75c8d6 %t35, 0
  switch i32 %t36, label %invalid.tag.b29 [
    i32 0, label %bb32
    i32 1, label %bb33
  ]
invalid.tag.b29:
  unreachable
bb30:
  br label %bb28
bb31:
  %v162 = phi ptr [ %v107, %bb32 ], [ %v107, %bb33 ]
  %v163 = phi i64 [ %v108, %bb32 ], [ %v108, %bb33 ]
  %v164 = phi ptr [ %v109, %bb32 ], [ %v109, %bb33 ]
  %v165 = phi i64 [ %v110, %bb32 ], [ %v110, %bb33 ]
  %v166 = phi ptr [ %v111, %bb32 ], [ %v111, %bb33 ]
  %v168 = phi i64 [ %v113, %bb32 ], [ %v113, %bb33 ]
  %v170 = phi ptr [ %v115, %bb32 ], [ %v115, %bb33 ]
  %v172 = phi i64 [ %v117, %bb32 ], [ %v117, %bb33 ]
  %v173 = phi i64 [ %v118, %bb32 ], [ %v118, %bb33 ]
  %v174 = phi i64 [ %v121, %bb32 ], [ %v121, %bb33 ]
  %v175 = phi i64 [ %v135, %bb32 ], [ %v135, %bb33 ]
  %v176 = phi i64 [ %v136, %bb32 ], [ %v136, %bb33 ]
  %v177 = phi i1 [ %v140, %bb32 ], [ %v140, %bb33 ]
  %v179 = phi i64 [ %v158, %bb32 ], [ %v158, %bb33 ]
  br label %bb27
bb32:
  br label %bb31
bb33:
  %t37 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.slot.6, i32 0, i32 1
  %v182 = load i1, ptr %t37
  %t38 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.slot.6, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.7, ptr %t38, i64 ptrtoint (ptr getelementptr (%wf.t.d72ca22fbd302a84, ptr null, i32 1) to i64), i1 false)
  %v184 = call i8 @wf_place_back$instance$c189ec082e7c2a1f(ptr %v115, ptr %wf.slot.7)
  br label %bb31
bb34:
  %v185 = phi ptr [ %v141, %bb28 ]
  %v186 = phi i64 [ %v142, %bb28 ]
  %v187 = phi ptr [ %v143, %bb28 ]
  %v188 = phi i64 [ %v144, %bb28 ]
  %v189 = phi ptr [ %v145, %bb28 ]
  %v191 = phi i64 [ %v147, %bb28 ]
  %v193 = phi ptr [ %v149, %bb28 ]
  %v195 = phi i64 [ %v151, %bb28 ]
  %v196 = phi i64 [ %v152, %bb28 ]
  %v197 = phi i64 [ %v119, %bb28 ]
  %v198 = phi i64 [ %v120, %bb28 ]
  %v199 = phi i64 [ %v121, %bb28 ]
  %v200 = select i1 true, i64 1, i64 1
  %v201 = add i64 %v199, %v200
  br label %bb24
}

define %wf.t.7d7f918f7b4962fd @wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65(ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.result = alloca %wf.t.7d7f918f7b4962fd, align 4
  call void @wf_std.collections.hash_map.hash_map_rebuild$instance$28da32efc51c2b65.body(ptr %wf.result, ptr %v0, i64 %v1, ptr %v2)
  %wf.returned = load %wf.t.7d7f918f7b4962fd, ptr %wf.result
  ret %wf.t.7d7f918f7b4962fd %wf.returned
}

define void @wf_std.collections.hash_map.hash_map_try_put$instance$28da32efc51c2b65(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, i64 %v1, ptr %wf.arg.v2, ptr noalias nonnull captures(none) dereferenceable(16) %v3) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.588b2641b8ac7d45, align 8
  %wf.slot.1 = alloca %wf.t.588b2641b8ac7d45, align 8
  %wf.slot.2 = alloca %wf.t.d72ca22fbd302a84, align 8
  %v4 = alloca i64, align 8
  store i64 %v1, ptr %v4
  %v5 = call i64 @wf_map_cost_hash(ptr %v3, ptr %v4)
  %t0 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v0, i32 0, i32 0
  %v6 = getelementptr i8, ptr %t0, i64 0
  %v7 = getelementptr i8, ptr %v6, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v7, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v8 = add i64 %t1, 0
  %v9 = select i1 true, i64 0, i64 0
  %v10 = icmp ugt i64 %v8, %v9
  switch i1 %v10, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v11 = phi ptr [ %v0, %bb3 ], [ %v31, %bb7 ]
  %v12 = phi ptr [ %v4, %bb3 ], [ %v32, %bb7 ]
  %v14 = phi ptr [ %v3, %bb3 ], [ %v34, %bb7 ]
  %v15 = phi i64 [ %v5, %bb3 ], [ %v35, %bb7 ]
  %v16 = phi i64 [ %v8, %bb3 ], [ %v36, %bb7 ]
  %v17 = phi i64 [ %v8, %bb3 ], [ %v37, %bb7 ]
  %v107 = icmp ult i64 %v17, %v16
  switch i1 %v107, label %invalid.tag.b1 [
    i1 1, label %bb24
    i1 0, label %bb25
  ]
invalid.tag.b1:
  unreachable
bb2:
  %v18 = urem i64 %v5, %v8
  %v19 = select i1 true, i64 0, i64 0
  br label %bb4
bb3:
  br label %bb1
bb4:
  %v20 = phi ptr [ %v0, %bb2 ], [ %v94, %bb22 ]
  %v21 = phi ptr [ %v4, %bb2 ], [ %v95, %bb22 ]
  %v23 = phi ptr [ %v3, %bb2 ], [ %v97, %bb22 ]
  %v24 = phi i64 [ %v5, %bb2 ], [ %v98, %bb22 ]
  %v25 = phi i64 [ %v8, %bb2 ], [ %v99, %bb22 ]
  %v26 = phi i64 [ %v8, %bb2 ], [ %v100, %bb22 ]
  %v27 = phi i64 [ %v18, %bb2 ], [ %v101, %bb22 ]
  %v28 = phi i64 [ %v19, %bb2 ], [ %v102, %bb22 ]
  %v29 = phi i64 [ %v8, %bb2 ], [ %v103, %bb22 ]
  %v30 = phi i64 [ %v19, %bb2 ], [ %v106, %bb22 ]
  %v39 = icmp ult i64 %v30, %v29
  switch i1 %v39, label %invalid.tag.b4 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b4:
  unreachable
bb5:
  %t3 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v20, i32 0, i32 0
  %v40 = getelementptr i8, ptr %t3, i64 0
  %v41 = getelementptr i8, ptr %v40, i64 0
  %t5 = getelementptr inbounds { i64, i64, ptr }, ptr %v41, i32 0, i32 2
  %t6 = load ptr, ptr %t5
  %t4.nonnegative = icmp sge i64 %v27, 0
  call void @llvm.assume(i1 %t4.nonnegative)
  %t4 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %t6, i64 %v27
  %v42 = getelementptr i8, ptr %t4, i64 0
  %v43 = call i32 @wf_std.collections.hash_map.hash_map_action$instance$c6df3d8464f8cde0(ptr %v42, ptr %v21, ptr %v23)
  switch i32 %v43, label %invalid.tag.b5 [
    i32 3, label %bb9
    i32 0, label %bb10
    i32 1, label %bb11
    i32 2, label %bb12
  ]
invalid.tag.b5:
  unreachable
bb6:
  br label %bb7
bb7:
  %v31 = phi ptr [ %v20, %bb6 ], [ %v58, %bb13 ]
  %v32 = phi ptr [ %v21, %bb6 ], [ %v59, %bb13 ]
  %v34 = phi ptr [ %v23, %bb6 ], [ %v61, %bb13 ]
  %v35 = phi i64 [ %v24, %bb6 ], [ %v62, %bb13 ]
  %v36 = phi i64 [ %v25, %bb6 ], [ %v63, %bb13 ]
  %v37 = phi i64 [ %v26, %bb6 ], [ %v64, %bb13 ]
  %v38 = phi i64 [ %v27, %bb6 ], [ %v65, %bb13 ]
  br label %bb1
bb8:
  %v44 = phi ptr [ %v20, %bb12 ], [ %v69, %bb16 ]
  %v45 = phi ptr [ %v21, %bb12 ], [ %v70, %bb16 ]
  %v47 = phi ptr [ %v23, %bb12 ], [ %v72, %bb16 ]
  %v48 = phi i64 [ %v24, %bb12 ], [ %v73, %bb16 ]
  %v49 = phi i64 [ %v25, %bb12 ], [ %v74, %bb16 ]
  %v50 = phi i64 [ %v26, %bb12 ], [ %v75, %bb16 ]
  %v51 = phi i64 [ %v27, %bb12 ], [ %v76, %bb16 ]
  %v52 = phi i64 [ %v30, %bb12 ], [ %v77, %bb16 ]
  %v53 = phi i32 [ %v43, %bb12 ], [ %v78, %bb16 ]
  %v79 = select i1 true, i64 1, i64 1
  %v80 = add nuw i64 %v51, %v79
  %v81 = icmp ult i64 %v80, %v49
  switch i1 %v81, label %invalid.tag.b8 [
    i1 1, label %bb20
    i1 0, label %bb21
  ]
invalid.tag.b8:
  unreachable
bb9:
  %t7 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v20, i32 0, i32 0
  %v54 = getelementptr i8, ptr %t7, i64 0
  %v55 = load i64, ptr %v21
  call void @wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449(ptr %wf.result, ptr %v54, i64 %v27, i64 %v55, ptr %wf.arg.v2)
  ret void
bb10:
  %v57 = icmp eq i64 %v26, %v25
  switch i1 %v57, label %invalid.tag.b10 [
    i1 1, label %bb14
    i1 0, label %bb15
  ]
invalid.tag.b10:
  unreachable
bb11:
  %v68 = icmp eq i64 %v26, %v25
  switch i1 %v68, label %invalid.tag.b11 [
    i1 1, label %bb17
    i1 0, label %bb18
  ]
invalid.tag.b11:
  unreachable
bb12:
  br label %bb8
bb13:
  %v58 = phi ptr [ %v20, %bb14 ], [ %v20, %bb15 ]
  %v59 = phi ptr [ %v21, %bb14 ], [ %v21, %bb15 ]
  %v61 = phi ptr [ %v23, %bb14 ], [ %v23, %bb15 ]
  %v62 = phi i64 [ %v24, %bb14 ], [ %v24, %bb15 ]
  %v63 = phi i64 [ %v25, %bb14 ], [ %v25, %bb15 ]
  %v64 = phi i64 [ %v27, %bb14 ], [ %v26, %bb15 ]
  %v65 = phi i64 [ %v27, %bb14 ], [ %v27, %bb15 ]
  %v66 = phi i64 [ %v30, %bb14 ], [ %v30, %bb15 ]
  %v67 = phi i32 [ %v43, %bb14 ], [ %v43, %bb15 ]
  br label %bb7
bb14:
  br label %bb13
bb15:
  br label %bb13
bb16:
  %v69 = phi ptr [ %v20, %bb17 ], [ %v20, %bb18 ]
  %v70 = phi ptr [ %v21, %bb17 ], [ %v21, %bb18 ]
  %v72 = phi ptr [ %v23, %bb17 ], [ %v23, %bb18 ]
  %v73 = phi i64 [ %v24, %bb17 ], [ %v24, %bb18 ]
  %v74 = phi i64 [ %v25, %bb17 ], [ %v25, %bb18 ]
  %v75 = phi i64 [ %v27, %bb17 ], [ %v26, %bb18 ]
  %v76 = phi i64 [ %v27, %bb17 ], [ %v27, %bb18 ]
  %v77 = phi i64 [ %v30, %bb17 ], [ %v30, %bb18 ]
  %v78 = phi i32 [ %v43, %bb17 ], [ %v43, %bb18 ]
  br label %bb8
bb17:
  br label %bb16
bb18:
  br label %bb16
bb19:
  %v82 = phi ptr [ %v44, %bb20 ], [ %v44, %bb21 ]
  %v83 = phi ptr [ %v45, %bb20 ], [ %v45, %bb21 ]
  %v85 = phi ptr [ %v47, %bb20 ], [ %v47, %bb21 ]
  %v86 = phi i64 [ %v48, %bb20 ], [ %v48, %bb21 ]
  %v87 = phi i64 [ %v49, %bb20 ], [ %v49, %bb21 ]
  %v88 = phi i64 [ %v50, %bb20 ], [ %v50, %bb21 ]
  %v89 = phi i64 [ %v80, %bb20 ], [ %v93, %bb21 ]
  %v90 = phi i64 [ %v52, %bb20 ], [ %v52, %bb21 ]
  %v91 = phi i32 [ %v53, %bb20 ], [ %v53, %bb21 ]
  %v92 = phi i64 [ %v80, %bb20 ], [ %v80, %bb21 ]
  br label %bb22
bb20:
  br label %bb19
bb21:
  %v93 = select i1 true, i64 0, i64 0
  br label %bb19
bb22:
  %v94 = phi ptr [ %v82, %bb19 ]
  %v95 = phi ptr [ %v83, %bb19 ]
  %v97 = phi ptr [ %v85, %bb19 ]
  %v98 = phi i64 [ %v86, %bb19 ]
  %v99 = phi i64 [ %v87, %bb19 ]
  %v100 = phi i64 [ %v88, %bb19 ]
  %v101 = phi i64 [ %v89, %bb19 ]
  %v102 = phi i64 [ %v28, %bb19 ]
  %v103 = phi i64 [ %v29, %bb19 ]
  %v104 = phi i64 [ %v30, %bb19 ]
  %v105 = select i1 true, i64 1, i64 1
  %v106 = add i64 %v104, %v105
  br label %bb4
bb23:
  %v108 = phi ptr [ %v11, %bb25 ], [ %v119, %bb26 ]
  %v109 = phi ptr [ %v12, %bb25 ], [ %v120, %bb26 ]
  %v111 = phi ptr [ %v14, %bb25 ], [ %v122, %bb26 ]
  %v112 = phi i64 [ %v15, %bb25 ], [ %v123, %bb26 ]
  %v113 = phi i64 [ %v16, %bb25 ], [ %v124, %bb26 ]
  %v114 = phi i64 [ %v17, %bb25 ], [ %v125, %bb26 ]
  %v151 = load i64, ptr %v109
  store %wf.t.d72ca22fbd302a84 zeroinitializer, ptr %wf.slot.2
  %t8 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.2, i32 0, i32 0
  store i64 %v151, ptr %t8
  %t9 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.2, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t9, ptr %wf.arg.v2, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %v153 = or i1 0, 1
  store %wf.t.114ba5754d75c8d6 zeroinitializer, ptr %wf.result
  %t10 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t10
  %t11 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.result, i32 0, i32 1
  store i1 %v153, ptr %t11
  %t12 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t12, ptr %wf.slot.2, i64 ptrtoint (ptr getelementptr (%wf.t.d72ca22fbd302a84, ptr null, i32 1) to i64), i1 false)
  ret void
bb24:
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v11, i64 ptrtoint (ptr getelementptr (%wf.t.588b2641b8ac7d45, ptr null, i32 1) to i64), i1 false)
  %t13 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %wf.slot.0, i32 0, i32 1
  %v116 = load i64, ptr %t13
  %v117 = select i1 true, i64 16384, i64 16384
  %v118 = icmp ult i64 %v116, %v117
  switch i1 %v118, label %invalid.tag.b24 [
    i1 1, label %bb27
    i1 0, label %bb28
  ]
invalid.tag.b24:
  unreachable
bb25:
  br label %bb23
bb26:
  %v119 = phi ptr [ %v11, %bb28 ]
  %v120 = phi ptr [ %v12, %bb28 ]
  %v122 = phi ptr [ %v14, %bb28 ]
  %v123 = phi i64 [ %v15, %bb28 ]
  %v124 = phi i64 [ %v16, %bb28 ]
  %v125 = phi i64 [ %v17, %bb28 ]
  %v126 = phi i64 [ %v116, %bb28 ]
  br label %bb23
bb27:
  %t14 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v11, i32 0, i32 1
  %v127 = getelementptr i8, ptr %t14, i64 0
  %v128 = select i1 true, i64 1, i64 1
  %v129 = add nuw i64 %v116, %v128
  store i64 %v129, ptr %v127
  %t15 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v11, i32 0, i32 0
  %v130 = getelementptr i8, ptr %t15, i64 0
  %v131 = getelementptr i8, ptr %v130, i64 0
  %t17 = getelementptr inbounds { i64, i64, ptr }, ptr %v131, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  %t16.nonnegative = icmp sge i64 %v17, 0
  call void @llvm.assume(i1 %t16.nonnegative)
  %t16 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %t18, i64 %v17
  %v132 = getelementptr i8, ptr %t16, i64 0
  %v133 = call i1 @wf_std.collections.hash_map.hash_map_is_deleted$instance$d7a1a90c27bba449(ptr %v132)
  switch i1 %v133, label %invalid.tag.b27 [
    i1 1, label %bb30
    i1 0, label %bb31
  ]
invalid.tag.b27:
  unreachable
bb28:
  br label %bb26
bb29:
  %v134 = phi ptr [ %v11, %bb30 ], [ %v11, %bb31 ]
  %v135 = phi ptr [ %v12, %bb30 ], [ %v12, %bb31 ]
  %v137 = phi ptr [ %v14, %bb30 ], [ %v14, %bb31 ]
  %v138 = phi i64 [ %v15, %bb30 ], [ %v15, %bb31 ]
  %v139 = phi i64 [ %v16, %bb30 ], [ %v16, %bb31 ]
  %v140 = phi i64 [ %v17, %bb30 ], [ %v17, %bb31 ]
  %v141 = phi i64 [ %v116, %bb30 ], [ %v116, %bb31 ]
  %v142 = phi i1 [ %v133, %bb30 ], [ %v133, %bb31 ]
  %t19 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v134, i32 0, i32 0
  %v148 = getelementptr i8, ptr %t19, i64 0
  %v149 = load i64, ptr %v135
  call void @wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449(ptr %wf.result, ptr %v148, i64 %v140, i64 %v149, ptr %wf.arg.v2)
  ret void
bb30:
  %t20 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v11, i32 0, i32 2
  %v143 = getelementptr i8, ptr %t20, i64 0
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v11, i64 ptrtoint (ptr getelementptr (%wf.t.588b2641b8ac7d45, ptr null, i32 1) to i64), i1 false)
  %t21 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %wf.slot.1, i32 0, i32 2
  %v145 = load i64, ptr %t21
  %v146 = select i1 true, i64 1, i64 1
  %v147 = call i64 @llvm.usub.sat.i64(i64 %v145, i64 %v146)
  store i64 %v147, ptr %v143
  br label %bb29
bb31:
  br label %bb29
}

define internal void @wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %v3 = call i64 @wf_map_cost_hash(ptr %v2, ptr %v1)
  %t0 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v0, i32 0, i32 0
  %v4 = getelementptr i8, ptr %t0, i64 0
  %v5 = getelementptr i8, ptr %v4, i64 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v5, i32 0, i32 0
  %t1 = load i64, ptr %t2
  %v6 = add i64 %t1, 0
  %v7 = select i1 true, i64 0, i64 0
  %v8 = icmp eq i64 %v6, %v7
  switch i1 %v8, label %invalid.tag.b0 [
    i1 1, label %bb2
    i1 0, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v9 = phi ptr [ %v0, %bb3 ]
  %v10 = phi ptr [ %v1, %bb3 ]
  %v11 = phi ptr [ %v2, %bb3 ]
  %v12 = phi i64 [ %v3, %bb3 ]
  %v13 = phi i64 [ %v6, %bb3 ]
  %v16 = urem i64 %v12, %v13
  %v17 = select i1 true, i64 0, i64 0
  br label %bb4
bb2:
  %v14 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t3 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t3
  %t4 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v14, ptr %t4
  ret void
bb3:
  br label %bb1
bb4:
  %v18 = phi ptr [ %v9, %bb1 ], [ %v62, %bb16 ]
  %v19 = phi ptr [ %v10, %bb1 ], [ %v63, %bb16 ]
  %v20 = phi ptr [ %v11, %bb1 ], [ %v64, %bb16 ]
  %v21 = phi i64 [ %v12, %bb1 ], [ %v65, %bb16 ]
  %v22 = phi i64 [ %v13, %bb1 ], [ %v66, %bb16 ]
  %v23 = phi i64 [ %v16, %bb1 ], [ %v67, %bb16 ]
  %v24 = phi i64 [ %v17, %bb1 ], [ %v68, %bb16 ]
  %v25 = phi i64 [ %v13, %bb1 ], [ %v69, %bb16 ]
  %v26 = phi i64 [ %v17, %bb1 ], [ %v72, %bb16 ]
  %v33 = icmp ult i64 %v26, %v25
  switch i1 %v33, label %invalid.tag.b4 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b4:
  unreachable
bb5:
  %t5 = getelementptr inbounds %wf.t.588b2641b8ac7d45, ptr %v18, i32 0, i32 0
  %v34 = getelementptr i8, ptr %t5, i64 0
  %v35 = getelementptr i8, ptr %v34, i64 0
  %t7 = getelementptr inbounds { i64, i64, ptr }, ptr %v35, i32 0, i32 2
  %t8 = load ptr, ptr %t7
  %t6.nonnegative = icmp sge i64 %v23, 0
  call void @llvm.assume(i1 %t6.nonnegative)
  %t6 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %t8, i64 %v23
  %v36 = getelementptr i8, ptr %t6, i64 0
  %v37 = call i32 @wf_std.collections.hash_map.hash_map_action$instance$c6df3d8464f8cde0(ptr %v36, ptr %v19, ptr %v20)
  switch i32 %v37, label %invalid.tag.b5 [
    i32 3, label %bb9
    i32 0, label %bb10
    i32 1, label %bb11
    i32 2, label %bb12
  ]
invalid.tag.b5:
  unreachable
bb6:
  br label %bb7
bb7:
  %v27 = phi ptr [ %v18, %bb6 ]
  %v28 = phi ptr [ %v19, %bb6 ]
  %v29 = phi ptr [ %v20, %bb6 ]
  %v30 = phi i64 [ %v21, %bb6 ]
  %v31 = phi i64 [ %v22, %bb6 ]
  %v32 = phi i64 [ %v23, %bb6 ]
  %v73 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t9 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t9
  %t10 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v73, ptr %t10
  ret void
bb8:
  %v38 = phi ptr [ %v18, %bb11 ], [ %v18, %bb12 ]
  %v39 = phi ptr [ %v19, %bb11 ], [ %v19, %bb12 ]
  %v40 = phi ptr [ %v20, %bb11 ], [ %v20, %bb12 ]
  %v41 = phi i64 [ %v21, %bb11 ], [ %v21, %bb12 ]
  %v42 = phi i64 [ %v22, %bb11 ], [ %v22, %bb12 ]
  %v43 = phi i64 [ %v23, %bb11 ], [ %v23, %bb12 ]
  %v44 = phi i64 [ %v26, %bb11 ], [ %v26, %bb12 ]
  %v45 = phi i32 [ %v37, %bb11 ], [ %v37, %bb12 ]
  %v49 = select i1 true, i64 1, i64 1
  %v50 = add nuw i64 %v43, %v49
  %v51 = icmp ult i64 %v50, %v42
  switch i1 %v51, label %invalid.tag.b8 [
    i1 1, label %bb14
    i1 0, label %bb15
  ]
invalid.tag.b8:
  unreachable
bb9:
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t11 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t11
  %t12 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 1
  store i64 %v23, ptr %t12
  ret void
bb10:
  %v47 = select i1 true, i8 0, i8 0
  store %wf.t.b7e1ed626c09888a zeroinitializer, ptr %wf.result
  %t13 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t13
  %t14 = getelementptr inbounds %wf.t.b7e1ed626c09888a, ptr %wf.result, i32 0, i32 2
  store i8 %v47, ptr %t14
  ret void
bb11:
  br label %bb8
bb12:
  br label %bb8
bb13:
  %v52 = phi ptr [ %v38, %bb14 ], [ %v38, %bb15 ]
  %v53 = phi ptr [ %v39, %bb14 ], [ %v39, %bb15 ]
  %v54 = phi ptr [ %v40, %bb14 ], [ %v40, %bb15 ]
  %v55 = phi i64 [ %v41, %bb14 ], [ %v41, %bb15 ]
  %v56 = phi i64 [ %v42, %bb14 ], [ %v42, %bb15 ]
  %v57 = phi i64 [ %v50, %bb14 ], [ %v61, %bb15 ]
  %v58 = phi i64 [ %v44, %bb14 ], [ %v44, %bb15 ]
  %v59 = phi i32 [ %v45, %bb14 ], [ %v45, %bb15 ]
  %v60 = phi i64 [ %v50, %bb14 ], [ %v50, %bb15 ]
  br label %bb16
bb14:
  br label %bb13
bb15:
  %v61 = select i1 true, i64 0, i64 0
  br label %bb13
bb16:
  %v62 = phi ptr [ %v52, %bb13 ]
  %v63 = phi ptr [ %v53, %bb13 ]
  %v64 = phi ptr [ %v54, %bb13 ]
  %v65 = phi i64 [ %v55, %bb13 ]
  %v66 = phi i64 [ %v56, %bb13 ]
  %v67 = phi i64 [ %v57, %bb13 ]
  %v68 = phi i64 [ %v24, %bb13 ]
  %v69 = phi i64 [ %v25, %bb13 ]
  %v70 = phi i64 [ %v26, %bb13 ]
  %v71 = select i1 true, i64 1, i64 1
  %v72 = add i64 %v70, %v71
  br label %bb4
}

define %wf.t.b7e1ed626c09888a @wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65(ptr noalias nonnull captures(none) dereferenceable(40) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.result = alloca %wf.t.b7e1ed626c09888a, align 8
  call void @wf_std.collections.hash_map.hash_map_find$instance$28da32efc51c2b65.body(ptr %wf.result, ptr %v0, ptr %v1, ptr %v2)
  %wf.returned = load %wf.t.b7e1ed626c09888a, ptr %wf.result
  ret %wf.t.b7e1ed626c09888a %wf.returned
}

define internal void @wf_slots_new$instance$15df03c28018958d.body(ptr %wf.result) #0 {
entry:
  store { i64, [1 x %wf.t.c5066f96ffdbc504] } zeroinitializer, ptr %wf.result
  ret void
}

define { i64, [1 x %wf.t.c5066f96ffdbc504] } @wf_slots_new$instance$15df03c28018958d() #0 {
entry:
  %wf.result = alloca { i64, [1 x %wf.t.c5066f96ffdbc504] }, align 8
  call void @wf_slots_new$instance$15df03c28018958d.body(ptr %wf.result)
  %wf.returned = load { i64, [1 x %wf.t.c5066f96ffdbc504] }, ptr %wf.result
  ret { i64, [1 x %wf.t.c5066f96ffdbc504] } %wf.returned
}

define i1 @wf_std.collections.hash_map.hash_map_is_available$instance$0ed342445dd803f3(ptr noalias nonnull captures(none) dereferenceable(24) %v0) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.a1df460b0959673f, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.a1df460b0959673f, ptr null, i32 1) to i64), i1 false)
  %t0 = load %wf.t.a1df460b0959673f, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.a1df460b0959673f %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb1
    i32 1, label %bb2
    i32 2, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v2 = select i1 true, i1 1, i1 1
  ret i1 %v2
bb2:
  %v3 = select i1 true, i1 1, i1 1
  ret i1 %v3
bb3:
  %t2 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %v0, i32 0, i32 1
  %v4 = getelementptr i8, ptr %t2, i64 0
  %t3 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %v0, i32 0, i32 2
  %v5 = getelementptr i8, ptr %t3, i64 0
  %v6 = select i1 true, i1 0, i1 0
  ret i1 %v6
}

define void @wf_std.collections.hash_map.hash_map_exchange$instance$0ed342445dd803f3(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(24) %v0, i64 %v1, i64 %v2, i64 %v3) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.a1df460b0959673f, align 8
  %wf.slot.1 = alloca %wf.t.c5066f96ffdbc504, align 8
  %v5 = alloca %wf.t.a1df460b0959673f, align 8
  store %wf.t.a1df460b0959673f zeroinitializer, ptr %v5
  %t0 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %v5, i32 0, i32 0
  store i32 2, ptr %t0
  %t1 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %v5, i32 0, i32 1
  store i64 %v2, ptr %t1
  %t2 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %v5, i32 0, i32 2
  store i64 %v3, ptr %t2
  %v6 = getelementptr i8, ptr %v0, i64 0
  %t4 = getelementptr inbounds { i64, i64, ptr }, ptr %v6, i32 0, i32 2
  %t5 = load ptr, ptr %t4
  %t3.nonnegative = icmp sge i64 %v1, 0
  call void @llvm.assume(i1 %t3.nonnegative)
  %t3 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %t5, i64 %v1
  %v7 = getelementptr i8, ptr %t3, i64 0
  %v8 = call i8 @wf_swap$instance$b45b69d9d0c6bbd0(ptr %v7, ptr %v5)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v5, i64 ptrtoint (ptr getelementptr (%wf.t.a1df460b0959673f, ptr null, i32 1) to i64), i1 false)
  %t6 = load %wf.t.a1df460b0959673f, ptr %wf.slot.0
  %t7 = extractvalue %wf.t.a1df460b0959673f %t6, 0
  switch i32 %t7, label %invalid.tag.b0 [
    i32 0, label %bb1
    i32 1, label %bb2
    i32 2, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  store %wf.t.5591089753cba638 zeroinitializer, ptr %wf.result
  %t8 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t8
  ret void
bb2:
  store %wf.t.5591089753cba638 zeroinitializer, ptr %wf.result
  %t9 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t9
  ret void
bb3:
  %t10 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %wf.slot.0, i32 0, i32 1
  %v12 = load i64, ptr %t10
  %t11 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %wf.slot.0, i32 0, i32 2
  %v13 = load i64, ptr %t11
  store %wf.t.c5066f96ffdbc504 zeroinitializer, ptr %wf.slot.1
  %t12 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.1, i32 0, i32 0
  store i64 %v12, ptr %t12
  %t13 = getelementptr inbounds %wf.t.c5066f96ffdbc504, ptr %wf.slot.1, i32 0, i32 1
  store i64 %v13, ptr %t13
  %v15 = or i1 0, 0
  store %wf.t.5591089753cba638 zeroinitializer, ptr %wf.result
  %t14 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t14
  %t15 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.result, i32 0, i32 1
  store i1 %v15, ptr %t15
  %t16 = getelementptr inbounds %wf.t.5591089753cba638, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr (%wf.t.c5066f96ffdbc504, ptr null, i32 1) to i64), i1 false)
  ret void
}

define i32 @wf_std.collections.hash_map.hash_map_action$instance$fc5e3cb62bdf3601(ptr noalias nonnull captures(none) dereferenceable(24) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.a1df460b0959673f, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.a1df460b0959673f, ptr null, i32 1) to i64), i1 false)
  %t0 = load %wf.t.a1df460b0959673f, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.a1df460b0959673f %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb1
    i32 1, label %bb2
    i32 2, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v4 = or i32 0, 0
  ret i32 %v4
bb2:
  %v5 = or i32 0, 1
  ret i32 %v5
bb3:
  %t2 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %v0, i32 0, i32 1
  %v6 = getelementptr i8, ptr %t2, i64 0
  %t3 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %v0, i32 0, i32 2
  %v7 = getelementptr i8, ptr %t3, i64 0
  %v8 = call i1 @wf_map_cost_equal(ptr %v2, ptr %v6, ptr %v1)
  switch i1 %v8, label %invalid.tag.b3 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b3:
  unreachable
bb4:
  %v9 = phi ptr [ %v0, %bb6 ]
  %v10 = phi ptr [ %v1, %bb6 ]
  %v11 = phi ptr [ %v2, %bb6 ]
  %v12 = phi ptr [ %v6, %bb6 ]
  %v13 = phi ptr [ %v7, %bb6 ]
  %v14 = phi i1 [ %v8, %bb6 ]
  %v16 = or i32 0, 2
  ret i32 %v16
bb5:
  %v15 = or i32 0, 3
  ret i32 %v15
bb6:
  br label %bb4
}

define i1 @wf_std.collections.hash_map.hash_map_is_deleted$instance$0ed342445dd803f3(ptr noalias nonnull captures(none) dereferenceable(24) %v0) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.a1df460b0959673f, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.a1df460b0959673f, ptr null, i32 1) to i64), i1 false)
  %t0 = load %wf.t.a1df460b0959673f, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.a1df460b0959673f %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 1, label %bb1
    i32 0, label %bb2
    i32 2, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v2 = select i1 true, i1 1, i1 1
  ret i1 %v2
bb2:
  %v3 = select i1 true, i1 0, i1 0
  ret i1 %v3
bb3:
  %t2 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %v0, i32 0, i32 1
  %v4 = getelementptr i8, ptr %t2, i64 0
  %t3 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %v0, i32 0, i32 2
  %v5 = getelementptr i8, ptr %t3, i64 0
  %v6 = select i1 true, i1 0, i1 0
  ret i1 %v6
}

define void @wf_slots_new$instance$8ac6e57475a1cbbb(ptr %wf.result) #0 {
entry:
  store { i64, [1 x %wf.t.d72ca22fbd302a84] } zeroinitializer, ptr %wf.result
  ret void
}

define i1 @wf_std.collections.hash_map.hash_map_is_available$instance$d7a1a90c27bba449(ptr noalias nonnull captures(none) dereferenceable(272) %v0) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.dceb7b9db1c9ad1d, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.dceb7b9db1c9ad1d, ptr null, i32 1) to i64), i1 false)
  %t0 = load %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.dceb7b9db1c9ad1d %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb1
    i32 1, label %bb2
    i32 2, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v2 = select i1 true, i1 1, i1 1
  ret i1 %v2
bb2:
  %v3 = select i1 true, i1 1, i1 1
  ret i1 %v3
bb3:
  %t2 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %v0, i32 0, i32 1
  %v4 = getelementptr i8, ptr %t2, i64 0
  %t3 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %v0, i32 0, i32 2
  %v5 = getelementptr i8, ptr %t3, i64 0
  %v6 = select i1 true, i1 0, i1 0
  ret i1 %v6
}

define void @wf_std.collections.hash_map.hash_map_exchange$instance$d7a1a90c27bba449(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(24) %v0, i64 %v1, i64 %v2, ptr %wf.arg.v3) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.1 = alloca %wf.t.dceb7b9db1c9ad1d, align 8
  %wf.slot.2 = alloca %wf.t.862971f7a971a883, align 8
  %wf.slot.3 = alloca %wf.t.d72ca22fbd302a84, align 8
  %v5 = alloca %wf.t.dceb7b9db1c9ad1d, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v3, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  store %wf.t.dceb7b9db1c9ad1d zeroinitializer, ptr %v5
  %t0 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %v5, i32 0, i32 0
  store i32 2, ptr %t0
  %t1 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %v5, i32 0, i32 1
  store i64 %v2, ptr %t1
  %t2 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %v5, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t2, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %v6 = getelementptr i8, ptr %v0, i64 0
  %t4 = getelementptr inbounds { i64, i64, ptr }, ptr %v6, i32 0, i32 2
  %t5 = load ptr, ptr %t4
  %t3.nonnegative = icmp sge i64 %v1, 0
  call void @llvm.assume(i1 %t3.nonnegative)
  %t3 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %t5, i64 %v1
  %v7 = getelementptr i8, ptr %t3, i64 0
  %v8 = call i8 @wf_swap$instance$9eabc50a9cce2251(ptr %v7, ptr %v5)
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.1, ptr %v5, i64 ptrtoint (ptr getelementptr (%wf.t.dceb7b9db1c9ad1d, ptr null, i32 1) to i64), i1 false)
  %t6 = load %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.1
  %t7 = extractvalue %wf.t.dceb7b9db1c9ad1d %t6, 0
  switch i32 %t7, label %invalid.tag.b0 [
    i32 0, label %bb1
    i32 1, label %bb2
    i32 2, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  store %wf.t.114ba5754d75c8d6 zeroinitializer, ptr %wf.result
  %t8 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t8
  ret void
bb2:
  store %wf.t.114ba5754d75c8d6 zeroinitializer, ptr %wf.result
  %t9 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.result, i32 0, i32 0
  store i32 0, ptr %t9
  ret void
bb3:
  %t10 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.1, i32 0, i32 1
  %v12 = load i64, ptr %t10
  %t11 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.1, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.2, ptr %t11, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  store %wf.t.d72ca22fbd302a84 zeroinitializer, ptr %wf.slot.3
  %t12 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.3, i32 0, i32 0
  store i64 %v12, ptr %t12
  %t13 = getelementptr inbounds %wf.t.d72ca22fbd302a84, ptr %wf.slot.3, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %wf.slot.2, i64 ptrtoint (ptr getelementptr (%wf.t.862971f7a971a883, ptr null, i32 1) to i64), i1 false)
  %v15 = or i1 0, 0
  store %wf.t.114ba5754d75c8d6 zeroinitializer, ptr %wf.result
  %t14 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.result, i32 0, i32 0
  store i32 1, ptr %t14
  %t15 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.result, i32 0, i32 1
  store i1 %v15, ptr %t15
  %t16 = getelementptr inbounds %wf.t.114ba5754d75c8d6, ptr %wf.result, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %wf.slot.3, i64 ptrtoint (ptr getelementptr (%wf.t.d72ca22fbd302a84, ptr null, i32 1) to i64), i1 false)
  ret void
}

define i32 @wf_std.collections.hash_map.hash_map_action$instance$c6df3d8464f8cde0(ptr noalias nonnull captures(none) dereferenceable(272) %v0, ptr noalias nonnull captures(none) dereferenceable(8) %v1, ptr noalias nonnull captures(none) dereferenceable(16) %v2) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.dceb7b9db1c9ad1d, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.dceb7b9db1c9ad1d, ptr null, i32 1) to i64), i1 false)
  %t0 = load %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.dceb7b9db1c9ad1d %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 0, label %bb1
    i32 1, label %bb2
    i32 2, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v4 = or i32 0, 0
  ret i32 %v4
bb2:
  %v5 = or i32 0, 1
  ret i32 %v5
bb3:
  %t2 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %v0, i32 0, i32 1
  %v6 = getelementptr i8, ptr %t2, i64 0
  %t3 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %v0, i32 0, i32 2
  %v7 = getelementptr i8, ptr %t3, i64 0
  %v8 = call i1 @wf_map_cost_equal(ptr %v2, ptr %v6, ptr %v1)
  switch i1 %v8, label %invalid.tag.b3 [
    i1 1, label %bb5
    i1 0, label %bb6
  ]
invalid.tag.b3:
  unreachable
bb4:
  %v9 = phi ptr [ %v0, %bb6 ]
  %v10 = phi ptr [ %v1, %bb6 ]
  %v11 = phi ptr [ %v2, %bb6 ]
  %v12 = phi ptr [ %v6, %bb6 ]
  %v13 = phi ptr [ %v7, %bb6 ]
  %v14 = phi i1 [ %v8, %bb6 ]
  %v16 = or i32 0, 2
  ret i32 %v16
bb5:
  %v15 = or i32 0, 3
  ret i32 %v15
bb6:
  br label %bb4
}

define i1 @wf_std.collections.hash_map.hash_map_is_deleted$instance$d7a1a90c27bba449(ptr noalias nonnull captures(none) dereferenceable(272) %v0) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.dceb7b9db1c9ad1d, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.dceb7b9db1c9ad1d, ptr null, i32 1) to i64), i1 false)
  %t0 = load %wf.t.dceb7b9db1c9ad1d, ptr %wf.slot.0
  %t1 = extractvalue %wf.t.dceb7b9db1c9ad1d %t0, 0
  switch i32 %t1, label %invalid.tag.b0 [
    i32 1, label %bb1
    i32 0, label %bb2
    i32 2, label %bb3
  ]
invalid.tag.b0:
  unreachable
bb1:
  %v2 = select i1 true, i1 1, i1 1
  ret i1 %v2
bb2:
  %v3 = select i1 true, i1 0, i1 0
  ret i1 %v3
bb3:
  %t2 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %v0, i32 0, i32 1
  %v4 = getelementptr i8, ptr %t2, i64 0
  %t3 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %v0, i32 0, i32 2
  %v5 = getelementptr i8, ptr %t3, i64 0
  %v6 = select i1 true, i1 0, i1 0
  ret i1 %v6
}

define internal void @wf_take_back$instance$9985a87b1cb96650.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(24) %v0) #0 {
entry:
  %t1 = getelementptr inbounds { i64, i64, ptr }, ptr %v0, i32 0, i32 0
  %t0 = load i64, ptr %t1
  %t2 = sub i64 %t0, 1
  %t4 = getelementptr inbounds { i64, i64, ptr }, ptr %v0, i32 0, i32 2
  %t5 = load ptr, ptr %t4
  %t3.nonnegative = icmp sge i64 %t2, 0
  call void @llvm.assume(i1 %t3.nonnegative)
  %t3 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %t5, i64 %t2
  %t6 = sub i64 %t0, 1
  %t7 = getelementptr inbounds { i64, i64, ptr }, ptr %v0, i32 0, i32 0
  store i64 %t6, ptr %t7
  call void @llvm.memmove.p0.p0.i64(ptr %wf.result, ptr %t3, i64 ptrtoint (ptr getelementptr (%wf.t.a1df460b0959673f, ptr null, i32 1) to i64), i1 false)
  ret void
}

define %wf.t.a1df460b0959673f @wf_take_back$instance$9985a87b1cb96650(ptr noalias nonnull captures(none) dereferenceable(24) %v0) #0 {
entry:
  %wf.result = alloca %wf.t.a1df460b0959673f, align 8
  call void @wf_take_back$instance$9985a87b1cb96650.body(ptr %wf.result, ptr %v0)
  %wf.returned = load %wf.t.a1df460b0959673f, ptr %wf.result
  ret %wf.t.a1df460b0959673f %wf.returned
}

define i8 @wf_free_empty$instance$43608765810d87c7(ptr %wf.arg.v0) #0 {
entry:
  %wf.slot.0 = alloca { i64, i64, ptr }, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v0, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  %t0 = load { i64, i64, ptr }, ptr %wf.slot.0
  %t1 = getelementptr inbounds { i64, i64, ptr }, ptr %wf.slot.0, i32 0, i32 1
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %wf.slot.0, i32 0, i32 2
  %t3 = load i64, ptr %t1
  %t4 = load ptr, ptr %t2
  %drop.5 = mul nuw i64 %t3, ptrtoint (ptr getelementptr (%wf.t.a1df460b0959673f, ptr null, i64 1) to i64)
  %drop.6 = icmp ne i64 %drop.5, 0
  br i1 %drop.6, label %slots.release.drop.6, label %slots.release.done.drop.6
slots.release.drop.6:
  call void @free(ptr %t4)
  br label %slots.release.done.drop.6
slots.release.done.drop.6:
  %v1 = select i1 true, i8 0, i8 0
  %v2 = select i1 true, i8 0, i8 0
  ret i8 %v2
}

define i8 @wf_swap$instance$b45b69d9d0c6bbd0(ptr nonnull captures(none) dereferenceable(24) %v0, ptr nonnull captures(none) dereferenceable(24) %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.a1df460b0959673f, align 8
  %wf.slot.1 = alloca %wf.t.a1df460b0959673f, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.a1df460b0959673f, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %wf.slot.1, ptr %v1, i64 ptrtoint (ptr getelementptr (%wf.t.a1df460b0959673f, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %v0, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr (%wf.t.a1df460b0959673f, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %v1, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.a1df460b0959673f, ptr null, i32 1) to i64), i1 false)
  %v4 = select i1 true, i8 0, i8 0
  ret i8 %v4
}

define void @wf_take_back$instance$d5bb00f00cd669fb(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(24) %v0) #0 {
entry:
  %t1 = getelementptr inbounds { i64, i64, ptr }, ptr %v0, i32 0, i32 0
  %t0 = load i64, ptr %t1
  %t2 = sub i64 %t0, 1
  %t4 = getelementptr inbounds { i64, i64, ptr }, ptr %v0, i32 0, i32 2
  %t5 = load ptr, ptr %t4
  %t3.nonnegative = icmp sge i64 %t2, 0
  call void @llvm.assume(i1 %t3.nonnegative)
  %t3 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %t5, i64 %t2
  %t6 = sub i64 %t0, 1
  %t7 = getelementptr inbounds { i64, i64, ptr }, ptr %v0, i32 0, i32 0
  store i64 %t6, ptr %t7
  call void @llvm.memmove.p0.p0.i64(ptr %wf.result, ptr %t3, i64 ptrtoint (ptr getelementptr (%wf.t.dceb7b9db1c9ad1d, ptr null, i32 1) to i64), i1 false)
  ret void
}

define i8 @wf_free_empty$instance$d692d011b23a4a18(ptr %wf.arg.v0) #0 {
entry:
  %wf.slot.0 = alloca { i64, i64, ptr }, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v0, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  %t0 = load { i64, i64, ptr }, ptr %wf.slot.0
  %t1 = getelementptr inbounds { i64, i64, ptr }, ptr %wf.slot.0, i32 0, i32 1
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %wf.slot.0, i32 0, i32 2
  %t3 = load i64, ptr %t1
  %t4 = load ptr, ptr %t2
  %drop.5 = mul nuw i64 %t3, ptrtoint (ptr getelementptr (%wf.t.dceb7b9db1c9ad1d, ptr null, i64 1) to i64)
  %drop.6 = icmp ne i64 %drop.5, 0
  br i1 %drop.6, label %slots.release.drop.6, label %slots.release.done.drop.6
slots.release.drop.6:
  call void @free(ptr %t4)
  br label %slots.release.done.drop.6
slots.release.done.drop.6:
  %v1 = select i1 true, i8 0, i8 0
  %v2 = select i1 true, i8 0, i8 0
  ret i8 %v2
}

define i8 @wf_swap$instance$9eabc50a9cce2251(ptr nonnull captures(none) dereferenceable(272) %v0, ptr nonnull captures(none) dereferenceable(272) %v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.dceb7b9db1c9ad1d, align 8
  %wf.slot.1 = alloca %wf.t.dceb7b9db1c9ad1d, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr (%wf.t.dceb7b9db1c9ad1d, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %wf.slot.1, ptr %v1, i64 ptrtoint (ptr getelementptr (%wf.t.dceb7b9db1c9ad1d, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %v0, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr (%wf.t.dceb7b9db1c9ad1d, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %v1, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.dceb7b9db1c9ad1d, ptr null, i32 1) to i64), i1 false)
  %v4 = select i1 true, i8 0, i8 0
  ret i8 %v4
}

define i8 @wf_grow$instance$b45b69d9d0c6bbd0(ptr noalias nonnull captures(none) dereferenceable(24) %v0, i64 %v1) #0 {
entry:
  %t0 = getelementptr inbounds { i64, i64, ptr }, ptr %v0, i32 0, i32 1
  %t1 = getelementptr inbounds { i64, i64, ptr }, ptr %v0, i32 0, i32 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v0, i32 0, i32 2
  %t3 = load i64, ptr %t1
  %t4 = load i64, ptr %t0
  %t5 = load ptr, ptr %t2
  %t6 = mul nuw i64 %t4, ptrtoint (ptr getelementptr (%wf.t.a1df460b0959673f, ptr null, i64 1) to i64)
  %t7 = mul nuw i64 %v1, ptrtoint (ptr getelementptr (%wf.t.a1df460b0959673f, ptr null, i64 1) to i64)
  %t13 = icmp eq i64 %t7, 0
  br i1 %t13, label %window.grow.empty.v2, label %window.grow.positive.v2
window.grow.empty.v2:
  br label %window.block.ready.v2
window.grow.positive.v2:
  %t8 = icmp eq i64 %t3, %t4
  %t9 = icmp ne i64 %t6, 0
  %t10 = and i1 %t8, %t9
  br i1 %t10, label %window.grow.reallocate.v2, label %window.grow.copy.v2
window.grow.reallocate.v2:
  %t11 = call ptr @realloc(ptr %t5, i64 %t7)
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %window.block.ready.v2, label %window.block.oom.v2
window.grow.copy.v2:
  %t14 = call ptr @malloc(i64 %t7)
  %t15 = icmp ne ptr %t14, null
  br i1 %t15, label %window.grow.copy.ready.v2, label %window.block.oom.v2
window.grow.copy.ready.v2:
  br i1 %t9, label %window.grow.copy.old.v2, label %window.grow.copy.empty.v2
window.grow.copy.empty.v2:
  br label %window.block.ready.v2
window.grow.copy.old.v2:
  %t16 = mul nuw i64 %t3, ptrtoint (ptr getelementptr (%wf.t.a1df460b0959673f, ptr null, i64 1) to i64)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t5, i64 %t16, i1 false)
  call void @free(ptr %t5)
  br label %window.block.ready.v2
window.block.oom.v2:
  call void @wf_resource_abort()
  unreachable
window.block.ready.v2:
  %t17 = phi ptr [ %t11, %window.grow.reallocate.v2 ], [ %t14, %window.grow.copy.old.v2 ], [ %t14, %window.grow.copy.empty.v2 ], [ %t5, %window.grow.empty.v2 ]
  store ptr %t17, ptr %t2
  store i64 %v1, ptr %t0
  %v2 = select i1 true, i8 0, i8 0
  %v3 = select i1 true, i8 0, i8 0
  ret i8 %v3
}

define i8 @wf_place_back$instance$9985a87b1cb96650(ptr noalias nonnull captures(none) dereferenceable(24) %v0, ptr %wf.arg.v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.a1df460b0959673f, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v1, i64 ptrtoint (ptr getelementptr (%wf.t.a1df460b0959673f, ptr null, i32 1) to i64), i1 false)
  %t1 = getelementptr inbounds { i64, i64, ptr }, ptr %v0, i32 0, i32 0
  %t0 = load i64, ptr %t1
  %t3 = getelementptr inbounds { i64, i64, ptr }, ptr %v0, i32 0, i32 2
  %t4 = load ptr, ptr %t3
  %t2.nonnegative = icmp sge i64 %t0, 0
  call void @llvm.assume(i1 %t2.nonnegative)
  %t2 = getelementptr inbounds %wf.t.a1df460b0959673f, ptr %t4, i64 %t0
  call void @llvm.memmove.p0.p0.i64(ptr %t2, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.a1df460b0959673f, ptr null, i32 1) to i64), i1 false)
  %t5 = add i64 %t0, 1
  %t6 = getelementptr inbounds { i64, i64, ptr }, ptr %v0, i32 0, i32 0
  store i64 %t5, ptr %t6
  %v2 = select i1 true, i8 0, i8 0
  ret i8 %v2
}

define i8 @wf_swap$instance$43608765810d87c7(ptr nonnull captures(none) dereferenceable(24) %v0, ptr nonnull captures(none) dereferenceable(24) %v1) #0 {
entry:
  %wf.slot.0 = alloca { i64, i64, ptr }, align 8
  %wf.slot.1 = alloca { i64, i64, ptr }, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %wf.slot.1, ptr %v1, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %v0, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %v1, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  %v4 = select i1 true, i8 0, i8 0
  ret i8 %v4
}

define i8 @wf_place_back$instance$a6542e06bf5acd99(ptr noalias nonnull captures(none) dereferenceable(24) %v0, ptr %wf.arg.v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.c5066f96ffdbc504, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v1, i64 ptrtoint (ptr getelementptr (%wf.t.c5066f96ffdbc504, ptr null, i32 1) to i64), i1 false)
  %t1 = getelementptr inbounds { i64, [1 x %wf.t.c5066f96ffdbc504] }, ptr %v0, i32 0, i32 0
  %t0 = load i64, ptr %t1
  %t2.nonnegative = icmp sge i64 %t0, 0
  call void @llvm.assume(i1 %t2.nonnegative)
  %t2 = getelementptr inbounds { i64, [1 x %wf.t.c5066f96ffdbc504] }, ptr %v0, i64 0, i32 1, i64 %t0
  call void @llvm.memmove.p0.p0.i64(ptr %t2, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.c5066f96ffdbc504, ptr null, i32 1) to i64), i1 false)
  %t3 = add i64 %t0, 1
  %t4 = getelementptr inbounds { i64, [1 x %wf.t.c5066f96ffdbc504] }, ptr %v0, i32 0, i32 0
  store i64 %t3, ptr %t4
  %v2 = select i1 true, i8 0, i8 0
  ret i8 %v2
}

define internal void @wf_take_back$instance$a6542e06bf5acd99.body(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(24) %v0) #0 {
entry:
  %t1 = getelementptr inbounds { i64, [1 x %wf.t.c5066f96ffdbc504] }, ptr %v0, i32 0, i32 0
  %t0 = load i64, ptr %t1
  %t2 = sub i64 %t0, 1
  %t3.nonnegative = icmp sge i64 %t2, 0
  call void @llvm.assume(i1 %t3.nonnegative)
  %t3 = getelementptr inbounds { i64, [1 x %wf.t.c5066f96ffdbc504] }, ptr %v0, i64 0, i32 1, i64 %t2
  %t4 = sub i64 %t0, 1
  %t5 = getelementptr inbounds { i64, [1 x %wf.t.c5066f96ffdbc504] }, ptr %v0, i32 0, i32 0
  store i64 %t4, ptr %t5
  call void @llvm.memmove.p0.p0.i64(ptr %wf.result, ptr %t3, i64 ptrtoint (ptr getelementptr (%wf.t.c5066f96ffdbc504, ptr null, i32 1) to i64), i1 false)
  ret void
}

define %wf.t.c5066f96ffdbc504 @wf_take_back$instance$a6542e06bf5acd99(ptr noalias nonnull captures(none) dereferenceable(24) %v0) #0 {
entry:
  %wf.result = alloca %wf.t.c5066f96ffdbc504, align 8
  call void @wf_take_back$instance$a6542e06bf5acd99.body(ptr %wf.result, ptr %v0)
  %wf.returned = load %wf.t.c5066f96ffdbc504, ptr %wf.result
  ret %wf.t.c5066f96ffdbc504 %wf.returned
}

define i8 @wf_free_empty$instance$bb96e2f57d31495e(ptr %wf.arg.v0) #0 {
entry:
  %v1 = select i1 true, i8 0, i8 0
  ret i8 %v1
}

define i8 @wf_grow$instance$9eabc50a9cce2251(ptr noalias nonnull captures(none) dereferenceable(24) %v0, i64 %v1) #0 {
entry:
  %t0 = getelementptr inbounds { i64, i64, ptr }, ptr %v0, i32 0, i32 1
  %t1 = getelementptr inbounds { i64, i64, ptr }, ptr %v0, i32 0, i32 0
  %t2 = getelementptr inbounds { i64, i64, ptr }, ptr %v0, i32 0, i32 2
  %t3 = load i64, ptr %t1
  %t4 = load i64, ptr %t0
  %t5 = load ptr, ptr %t2
  %t6 = mul nuw i64 %t4, ptrtoint (ptr getelementptr (%wf.t.dceb7b9db1c9ad1d, ptr null, i64 1) to i64)
  %t7 = mul nuw i64 %v1, ptrtoint (ptr getelementptr (%wf.t.dceb7b9db1c9ad1d, ptr null, i64 1) to i64)
  %t13 = icmp eq i64 %t7, 0
  br i1 %t13, label %window.grow.empty.v2, label %window.grow.positive.v2
window.grow.empty.v2:
  br label %window.block.ready.v2
window.grow.positive.v2:
  %t8 = icmp eq i64 %t3, %t4
  %t9 = icmp ne i64 %t6, 0
  %t10 = and i1 %t8, %t9
  br i1 %t10, label %window.grow.reallocate.v2, label %window.grow.copy.v2
window.grow.reallocate.v2:
  %t11 = call ptr @realloc(ptr %t5, i64 %t7)
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %window.block.ready.v2, label %window.block.oom.v2
window.grow.copy.v2:
  %t14 = call ptr @malloc(i64 %t7)
  %t15 = icmp ne ptr %t14, null
  br i1 %t15, label %window.grow.copy.ready.v2, label %window.block.oom.v2
window.grow.copy.ready.v2:
  br i1 %t9, label %window.grow.copy.old.v2, label %window.grow.copy.empty.v2
window.grow.copy.empty.v2:
  br label %window.block.ready.v2
window.grow.copy.old.v2:
  %t16 = mul nuw i64 %t3, ptrtoint (ptr getelementptr (%wf.t.dceb7b9db1c9ad1d, ptr null, i64 1) to i64)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t5, i64 %t16, i1 false)
  call void @free(ptr %t5)
  br label %window.block.ready.v2
window.block.oom.v2:
  call void @wf_resource_abort()
  unreachable
window.block.ready.v2:
  %t17 = phi ptr [ %t11, %window.grow.reallocate.v2 ], [ %t14, %window.grow.copy.old.v2 ], [ %t14, %window.grow.copy.empty.v2 ], [ %t5, %window.grow.empty.v2 ]
  store ptr %t17, ptr %t2
  store i64 %v1, ptr %t0
  %v2 = select i1 true, i8 0, i8 0
  %v3 = select i1 true, i8 0, i8 0
  ret i8 %v3
}

define i8 @wf_place_back$instance$d5bb00f00cd669fb(ptr noalias nonnull captures(none) dereferenceable(24) %v0, ptr %wf.arg.v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.dceb7b9db1c9ad1d, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v1, i64 ptrtoint (ptr getelementptr (%wf.t.dceb7b9db1c9ad1d, ptr null, i32 1) to i64), i1 false)
  %t1 = getelementptr inbounds { i64, i64, ptr }, ptr %v0, i32 0, i32 0
  %t0 = load i64, ptr %t1
  %t3 = getelementptr inbounds { i64, i64, ptr }, ptr %v0, i32 0, i32 2
  %t4 = load ptr, ptr %t3
  %t2.nonnegative = icmp sge i64 %t0, 0
  call void @llvm.assume(i1 %t2.nonnegative)
  %t2 = getelementptr inbounds %wf.t.dceb7b9db1c9ad1d, ptr %t4, i64 %t0
  call void @llvm.memmove.p0.p0.i64(ptr %t2, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.dceb7b9db1c9ad1d, ptr null, i32 1) to i64), i1 false)
  %t5 = add i64 %t0, 1
  %t6 = getelementptr inbounds { i64, i64, ptr }, ptr %v0, i32 0, i32 0
  store i64 %t5, ptr %t6
  %v2 = select i1 true, i8 0, i8 0
  ret i8 %v2
}

define i8 @wf_swap$instance$d692d011b23a4a18(ptr nonnull captures(none) dereferenceable(24) %v0, ptr nonnull captures(none) dereferenceable(24) %v1) #0 {
entry:
  %wf.slot.0 = alloca { i64, i64, ptr }, align 8
  %wf.slot.1 = alloca { i64, i64, ptr }, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr %wf.slot.0, ptr %v0, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %wf.slot.1, ptr %v1, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %v0, ptr %wf.slot.1, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr %v1, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr ({ i64, i64, ptr }, ptr null, i32 1) to i64), i1 false)
  %v4 = select i1 true, i8 0, i8 0
  ret i8 %v4
}

define i8 @wf_place_back$instance$c189ec082e7c2a1f(ptr noalias nonnull captures(none) dereferenceable(272) %v0, ptr %wf.arg.v1) #0 {
entry:
  %wf.slot.0 = alloca %wf.t.d72ca22fbd302a84, align 8
  call void @llvm.memmove.p0.p0.i64(ptr %wf.slot.0, ptr %wf.arg.v1, i64 ptrtoint (ptr getelementptr (%wf.t.d72ca22fbd302a84, ptr null, i32 1) to i64), i1 false)
  %t1 = getelementptr inbounds { i64, [1 x %wf.t.d72ca22fbd302a84] }, ptr %v0, i32 0, i32 0
  %t0 = load i64, ptr %t1
  %t2.nonnegative = icmp sge i64 %t0, 0
  call void @llvm.assume(i1 %t2.nonnegative)
  %t2 = getelementptr inbounds { i64, [1 x %wf.t.d72ca22fbd302a84] }, ptr %v0, i64 0, i32 1, i64 %t0
  call void @llvm.memmove.p0.p0.i64(ptr %t2, ptr %wf.slot.0, i64 ptrtoint (ptr getelementptr (%wf.t.d72ca22fbd302a84, ptr null, i32 1) to i64), i1 false)
  %t3 = add i64 %t0, 1
  %t4 = getelementptr inbounds { i64, [1 x %wf.t.d72ca22fbd302a84] }, ptr %v0, i32 0, i32 0
  store i64 %t3, ptr %t4
  %v2 = select i1 true, i8 0, i8 0
  ret i8 %v2
}

define void @wf_take_back$instance$c189ec082e7c2a1f(ptr %wf.result, ptr noalias nonnull captures(none) dereferenceable(272) %v0) #0 {
entry:
  %t1 = getelementptr inbounds { i64, [1 x %wf.t.d72ca22fbd302a84] }, ptr %v0, i32 0, i32 0
  %t0 = load i64, ptr %t1
  %t2 = sub i64 %t0, 1
  %t3.nonnegative = icmp sge i64 %t2, 0
  call void @llvm.assume(i1 %t3.nonnegative)
  %t3 = getelementptr inbounds { i64, [1 x %wf.t.d72ca22fbd302a84] }, ptr %v0, i64 0, i32 1, i64 %t2
  %t4 = sub i64 %t0, 1
  %t5 = getelementptr inbounds { i64, [1 x %wf.t.d72ca22fbd302a84] }, ptr %v0, i32 0, i32 0
  store i64 %t4, ptr %t5
  call void @llvm.memmove.p0.p0.i64(ptr %wf.result, ptr %t3, i64 ptrtoint (ptr getelementptr (%wf.t.d72ca22fbd302a84, ptr null, i32 1) to i64), i1 false)
  ret void
}

define i8 @wf_free_empty$instance$41f1fc367c8c34ad(ptr %wf.arg.v0) #0 {
entry:
  %v1 = select i1 true, i8 0, i8 0
  ret i8 %v1
}


attributes #0 = { "probe-stack"="__chkstk_darwin" }
define weak i32 @wf__floor_run(i32 %argc, ptr %argv) #0 {
entry:
  %status = call i32 @wf__main_body(i32 %argc, ptr %argv) noinline
  ret i32 %status
}


declare i8 @wf__ordinary_exit_code(ptr)

define i32 @wf__main_body(i32 %argc, ptr %argv) #0 {
entry:
  %status = alloca { i128, i128 }, align 16
  call void @"wf_main"(ptr %status)
  %code = call i8 @wf__ordinary_exit_code(ptr %status)
  %exit = zext i8 %code to i32
  ret i32 %exit
}

define i32 @wf_fixture_main(i32 %argc, ptr %argv) #0 {
entry:
  %status = call i32 @wf__floor_run(i32 %argc, ptr %argv)
  ret i32 %status
}
