# Indexed composite cost experiment

This explicit experiment implements the discriminator registered in
[X1](../../../investigations/containers-and-resources/X1-LIBRARY.md#indexed-composite-trial).
It bundles the maintained `tests/programs/containers/indexed-store.wf` operation
implementation with a research-only trace caller. The formal caller does not
depend on this directory. The Makefile, controls and samples exist to test the
complete indexed consumer and shared-sift cost; retire them when superseded
and no maintained claim needs their replay.

## Prospective protocol, recorded before timing

The initial compiler is the frozen main `345e2966a` CLI, SHA-256
`cbffd4dd1ae8641ef03790457181188988bf70cc4af1a53c50c1f406307bb7f9`.
The plain queue source at `c3c2a50fd` is the original comparison image. The
candidate uses the shared indexed core and its ordinary no-op specialization.
The indexed comparison uses the same maintained composite and trace with a
bounded standalone indexed sift control. Neither the standalone source nor
the C controls replace the maintained application implementation. Admission
subsequently exposed the compiler's effect-row refinement defect: it rejects a
callback's `reads(env)` actual against a `writes(env)` formal even though EFF-1
makes that formal permission include reads. Two later blockers were an OP-9
layout query treating nested symbolic nominal arguments as concrete, and an
unused formal's symbolic nominal escaping into the executable inventory.
The three current-specification repairs are published at `3f85b1030`; no
language rule changed. Every new comparison image uses its frozen CLI,
SHA-256 `c71aaf16fdf175b9c269e07b18fa45b82b2a54d0a3cd4d4443b1eb185454cb8f`.
This is a source-architecture comparison using one compiler, not a comparison
between baseline and repaired compilers. The reconstructed original queue's
raw LLVM is byte-identical to the preserved `345e2966a` artifact (SHA-256
`dfceb1385f84124146c0458fcebcf4e734c3a09d0f76001cf28042f81661a4f5`);
both optimized modes differ only in their ModuleID path line.

Before any costs are used to choose, require the complete outcome transcript
to match an independent array/ordered-sequence model in every matrix cell.
Each offered owner has a distinct identity; every returned/consumed payload
word, status, handle and observed identity is compared, with per-owner offered
and consumed counts. The maintained corpus separately owns the droppable and
nodrop, wrong-store, refusal/retry, bounded-generation, malformed-position and
parallel-lowering witnesses. Inspect the original/plain no-op optimized code
before timing; an unexplained material change is reported before proceeding.

The indexed matrix is fixed at 24 cells:

| Axis | Values |
| --- | --- |
| Initial live records | 16, 256, 4096 |
| Slab payload size | 8 or 256 bytes; every heap entry has the same layout |
| Membership policy | weak, retained |
| Trace | reserved mixed operations, growth and ordered cleanup |
| Public boundaries | normally optimized, retained public operations and real callbacks |
| Implementations per image | Whitefoot, source-shaped swap C, direct indexed hole C |
| Repetitions | seeds 101 through 107; two reversed-order cohorts |

The Slab capacity is the initial record count, with ceiling 8192 and generation
limit `UINT64_MAX`. The reserved trace starts with map and heap capacity twice
that count; growth starts both indexes at zero. Slab has no growth operation.
The hash callback is ID modulo 8192. Record `i` has ID `2*i+1`, except indices
congruent to one modulo eight use the preceding ID plus 8192. This gives one
deliberate colliding pair per eight records. No collision distribution or
population is selected after observing timings.

Both traces insert, attach and schedule every initial owner, check a refused
extra Slab owner, and consume it explicitly. The growth trace then expires all
entries in deadline/ID/index/generation order and destroys the empty store.
The reserved mixed trace looks up and replaces every payload, reschedules even
records earlier and odd records later, cancels and reschedules every fourth
record, and deletes/reuses every eighth record. Weak deletion leaves exactly
`n/8` stale heap entries at that point; retained deletion first observes Busy
and retires both memberships in alternating orders. Both policies reuse the
same slot and ID with a new generation. Partial expiry consumes the remaining
early records (indices congruent to two modulo four), which are then reinserted
under the same IDs. A second expiry at `9*n-1` processes the weak stale
generations, protects replacement ID associations, and consumes exactly `n/2`
live even records under both policies. Final destruction retires both indexes
and consumes the `n/2` remaining odd Slab owners. Each step records its explicit
success/refusal/expiry
outcome; setup and final cleanup are included in elapsed time.

One timed sample repeats the complete trace `max(1, 2048/n)` times for small
payloads and `max(1, 512/n)` for wide payloads. There is one mixed-operation
round per trace. The trace seed is sample seed plus repetition index. Initial
deadlines are `4*n + ((LCG(seed) >> 32) % (4*n))`, with the existing unsigned
LCG multiplier 6364136223846793005 and increment 1442695040888963407.
Earlier deadlines are the record index; later deadlines are `16*n+i`;
cancelled/reused records use `8*n+i`; the two expiry boundaries are `4*n-1`
and `9*n-1`.
Payload word zero is its unique owner number; remaining words are a fixed
seed/owner/word-index pattern. There is no checksum-only correctness oracle.

The independent model and full log are outside the timed interval. Each timed
implementation retains the same digest work, but uses a zero-capacity outcome
log. Diagnostic operation counts use a separate image: comparison, swap or
assignment, position-report, handle-validation and hash-probe counts are not
silently added to only one timed implementation. Report actual layouts,
payload transfers, allocation/release identity and requested/peak bytes,
including stale entries and old/new growth overlap.
The diagnostic byte columns multiply explicit heap/payload assignment counts
by their payload extents. They describe algorithm-level movement, excluding
parameter/result temporaries, callback spills, inactive-field initialization
and cache traffic; optimized code inspection accounts for those lowering costs.
That separate diagnostic image runs seed 101 once in every cell for both C
controls, yielding 48 rows; its counts are not timing samples or averages over
the seven timing seeds.

For the indexed retained mode, the retained public boundary is the composite's
15 `record_store_*` operations, including its validation/position accessors,
plus actual ordering, hash/equality, borrowed observation, edit, position-report
and owner-consumption callbacks. Retention means a `noinline` boundary, not
dynamic export: both indexed WF images internalize non-bridge definitions to
match static C helper scope, preserving the two C-called trace bridges and
ordinary runtime declarations. This experiment-only instrument permits the
same unused-argument and result optimization in both languages; production
compiler linkage is unchanged. Underlying library helpers remain normally
optimizable in both languages. The separate plain-PQ comparison preserves its
existing public queue and payload-callback policy and exact reference images.
That preserved pair has static C helpers and external WF definitions, so its
WF/native ratio includes different ABI optimization opportunities and is not
an isolation of same-ABI lowering. In particular, an empty
position callback is not forced out of line: the original plain queue has no
corresponding callback boundary.

The independent backing formula uses a 16-byte header, 32-byte ID buckets and
32-byte heap entries. Slab cell strides are 56/304 bytes for 8/256-byte payloads.
The source-shaped C public results retain the backend's separate variant
payload fields rather than overlaying them in unions. Their extents are
40 bytes for handle and record-info lookups, 24 for a position result, 12 for
a unit visit result, 40/288 for insertion and 48/296 for deletion. Membership
booleans occupy one byte. Static C assertions check these extents; the admitted
WF module remains the concrete-layout cross-check before timing.
For the reserved trace, three allocations request and peak at
`48+n*(SlabStride+128)` bytes. For growth, each index allocates capacities
0, 1, 2, ..., n: requests are `3+2*(log2(n)+1)`, requested bytes are
`48+n*SlabStride+2*sum(16+32*c)` over positive growth capacities, and peak bytes
are `64+n*(SlabStride+80)`, including the old and new final heap backings.
These formulas are checked after each trace or timed batch, outside its timed
interval, in addition to the allocation/release identity ledger.

Each image contributes 2,016 rows (24 cells × 3 implementations × 7 seeds ×
2 cohorts × 2 boundary modes). Run one fresh A/A unchanged-image pair and one
A/B standalone/shared pair. Preserve the existing complete plain-PriorityQueue
matrix: 2,520 rows per image, seven seeds, both cohorts/modes, all five paths,
both payload sizes and both C controls. Run fresh original/original and
original/no-op pairs, preserving original sources and actual image identities.
The unchanged C controls remain in every image. Within an image rotate
implementation order by sample and reverse it in cohort one; reverse both
image order and normal/retained mode order between cohorts.

For each cell and cohort, pair equal-seed elapsed times and normalize the WF
A/B ratio by the matching unchanged swap-C ratio. Report raw and normalized
ratios, both C controls, medians, full ranges and individual tails. A material
change must exceed the maximum of 3%, that cell's observed unchanged-image/C
variation, and measured clock quantum relative to its sample time. Agreement
inside that band permits sharing on maintenance grounds; it does not establish
native parity. An indexed benefit must repeat beyond that band in both
cohorts and have algorithmic or emitted-code attribution. Any unexplained
material indexed or plain-no-op regression leaves the shared-core selection
open. Policies and workload cells are not averaged together.

Concretely, compute seven equal-seed ratios in each cohort and take their
median. The cell's variation band is the maximum absolute departure from one
among its two null normalized-WF medians and its unchanged swap-C and hole-C
medians in both null and A/B runs. The clock term is four times the smallest
observed positive monotonic-clock increment divided by the smallest median
sample interval in the cell. These terms and 3% define one band for the cell;
individual tails remain visible but do not replace a seven-sample median.
A benefit or regression repeats only when both cohort medians exceed that band
in the same direction. A one-cohort excursion remains unresolved and can
trigger only the complete fixed repeat below.

At most one complete fixed repeat of both paired matrices is allowed if the
initial result is ambiguous from noise. Keep every initial/repeat sample and
tail; no narrower rerun is selected to remove a regression. If the full repeat
cannot fit the remaining budget, report the ambiguity. The combined budgets
are 120 seconds for artifact construction, 40 seconds for native correctness
execution and 60 seconds for timing, including null runs and that repeat.
Compiler construction and the canonical gate are separate guarded stages.
No timing has been run for this record yet.

The repeat, if used, includes A/A and A/B for both the indexed and plain-queue
matrices, with unchanged seeds, trace sizes and ordering. The initial protocol
therefore retains 18,144 rows, and the sole permitted full repeat would add
another 18,144. No tail, mode or policy is sampled separately to choose a result.

## Admission and correctness progress

The first construction stage took 1.08 seconds. Both native C modes compiled;
the shared WF bundle stopped in the maintained helper at a reserved `entry`
local name, before admission. This is a source parser failure, not a measured
cost or a changed acceptance verdict. The helper owner corrected the local
names; its subsequent formal admission exposed the compiler blockers described
above. The full maintained bundle subsequently passed sequential and parallel
native execution, with both allocation observers reporting exactly 129.

The native execution stage took 2.60 seconds. Each mode passed 832 unique
complete matrix inputs and 1,664 swap/hole executions against every transcript
word and per-owner ledger, with matching backing counts, requested bytes and
peak overlap. Those inputs cover every seed used by every timed repetition;
overlapping seed/repetition combinations are checked once. This initial native
precheck preceded the static-review addition of the second expiry boundary
described above, which ensures stale generations are processed before
destruction. No timing preceded that change. Subsequent edits
to a control or helper require affected checks before timing.

Static fairness review also corrected the native controls' callback argument
shapes, result extents and one-byte booleans, and added the independent backing
formulas above. The initial native precheck does not certify those later edits.
The maintained constructor now states the ordinary OP-9 upper bound for its
32-byte heap element; all registered capacities satisfy that source
precondition, so the C controls need no extra runtime assertion for it.

The repaired-compiler construction attempts include the research caller's
canonical formatting correction and an explicit verified upper bound on its
reserved capacity. These preserve the registered trace. The shared image and
both plain images are built. Their native execution took 5.51 seconds: each
indexed boundary mode passed 832 complete inputs and 2,496 full-transcript and
owner-ledger executions; each of the four plain original/no-op boundary modes
passed the existing 2,160 complete scalar/owning traces and four refusal/retry
chains. The composite retained-operation call checks also passed.

The concrete standalone control required the ordinary Copy spelling:
`swap(first: &queue_slot, second: &other_slot)` is refused under OP-11 for
`RecordDue`; its temporary/read/assignment form preserves the same three
assignments and position reports. FN-2 permits the generic source's explicit
ownership operations to specialize over a Copy type. OWN-1 likewise removes
explicit `move` from concrete Copy operands. Direct comparison reads no empty
environment, so EFF-2 removes that unused read from the concrete rise/push rows.
Its next admission stops after `priority_queue_make_room<RecordDue, ceiling>`:
the following `place_back` does not recover `len < cap`. The 0.21-second
diagnostic isolated this before any timing: an immediate `room: len < cap`
invariant fails with a symbolic ceiling, also fails after adding
`requires ceiling <= 576460752303423487_u64`, and admits with literal 8192.
Thus adding the ordinary OP-9 bound to the caller does not recover this symbolic
call summary. Read-only diagnosis supports a missing callee proof: reserve's
own contract supplies only `total <= ceiling`, while its known 32-byte element
requires `total <= UINT64_MAX/32`. ENT-2 does not import the caller's extra
premise into that callee body. Literal substitution supplies the bound locally.
This is not evidence of a compiler publication defect; no language acceptance
verdict is revised by the experiment.

The unadmitted concrete control is replaced before measurement by seven bounded
generic functions: rise, sink, repair, push, peek-at, remove-at and replace-at.
They preserve the shared candidate's element opacity, ordinary comparison and
placement formals, bodies and contracts, but are bundled beside the frozen
original plain queue. The maintained consumer is byte-identical in both arms;
the four experimental generic-binding substitutions are removed. This is still
one standalone/shared comparison, with no additional measured variant. It
tests sharing against a viable duplicated indexed core without charging only
one arm for the concrete Copy spelling or unavailable symbolic call summary.
The rejected concrete spelling is source-admission evidence, not a timing
result or a new language restriction.

Current spent budgets, including failed source attempts, are 25.87/120 seconds
construction, 8.11/40 seconds correctness and 0/60 seconds timing. All earlier
attempts remain retained; these totals do not reset after source corrections.

**Design suitability.** Reusing the maintained composite keeps the measured
protocol aligned with formal ownership tests. The standalone indexed control
tests the cost of sharing while preserving a viable bounded alternative; the
source-shaped and hole C controls distinguish lowering costs from algorithmic
transfer differences. Full transcript checks and separate counting are needed
because equal checksums and equal heap sizes alone cannot establish ownership
or membership equivalence.
