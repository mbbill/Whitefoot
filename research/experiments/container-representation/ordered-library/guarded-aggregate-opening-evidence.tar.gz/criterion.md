#### Prospective guarded aggregate-opening trial

The next isolated factor addresses the empty-transfer mechanism above. It
keeps exactly `open && Slots && is_stored_aggregate`, adds the original
`len > index` zero-trip guard around the stride-span move, and statically
omits RunShift's address/extent/copy emission when the existing selected-target
layout helper establishes zero stride. Both paths join before the unchanged
single length increment. Incoming-value capture and RunInsert placement,
including their existing zero-sized copies, stay unchanged. No byte threshold,
container/count dispatch, public representation or language rule changes.

Freeze the same `7abd6bb34746b7b983b83103c68ee429b24859bb` compiler plus
selected cleanup, with a separate guarded patch over the retained unguarded
factor. The ordinary Ordered pkg carrier and all 23 fixture/carrier input files
are byte-identical to the preceding screen. Preserve its adverse raw samples
and candidate image. Scratch preparation is under
`<scratch-root>`; `IDENTITIES.json`,
`source-freeze.json` and both the full candidate and incremental delta patches
pin the proposal before construction. No native or execution result is asserted.

Before execution, require the selected-cleanup baseline module/object to
reproduce. Empty-suffix paths in fixed/runtime wrappers and both Ordered leaf
insertions must bypass shift transfers in optimized native control flow.
Zero-stride raw shift blocks must contain no transfer or shift address/extent,
while the final bodies preserve logical length. Positive wide openings must
retain one overlap-safe `stride * (len - index)` move with no per-entry loop.
Compare all prior scalar/Box-pointer/Ring controls, true closing kernels and
selected cleanup bodies; inventory every changed caller, including executed
scalar insert/remove frames and spills. The previous +32-byte Vector frames
and +16-byte Ordered frame remain competing costs, not promised removals.
Any surviving empty shift call, restored wide per-entry copy, changed owner or
length outcome, or altered unaffected body refuses this code screen.

Then require the existing padded owning, endpoint and huge zero-stride tests
with both address-fact choices, alongside normal/parallel lowering. A native
shift observer must reject an independent guard-bypass fault that calls it for
zero bytes; omitted positive transfer and omitted length-update faults must
still fail their existing observers. Preserve maintained Vector/Ordered owner
and chronology tests, both complete ecosystem oracles, normal/retained/structural
checks, checksum/cleanup faults and byte-equal allocation accounting. Reuse
verified native peers/runtime; record construction and execution separately.

Only after those screens, use the original full Vector 42-cell and Ordered
30-cell pair, cohort order, warmup handling, duration/stability qualifications
and disjoint-range rule. Selection still requires at least one qualified useful
gain and zero qualified useful losses across both matrices. Report every prior
gain/loss cell, all adverse medians and both peer/target results. Overlap remains
inconclusive. A remaining churn loss may expose small positive-transfer or
caller-layout cost; it does not authorize a tuned size threshold or another
timing run. This proposal remains pending in the existing amendment.
