"""The prospective balanced full Vector/Ordered comparison; no construction or retries."""
from pathlib import Path
import csv,datetime,hashlib,json,os,subprocess,time,traceback
D=Path(__file__).resolve().parent
T=D.parent
PLAN=json.loads((D/'plan.json').read_text())
EXPECTED=json.loads((D/'inputs.json').read_text())
RUNS=[]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n')
def verify():
    actual={p:sha(p) for p in EXPECTED}
    assert actual==EXPECTED,{p:[EXPECTED[p],actual[p]] for p in EXPECTED if actual[p]!=EXPECTED[p]}
    frozen=json.loads((T/'source-freeze.json').read_text())
    assert {p:sha(T/'candidate'/p) for p in frozen}==frozen
    return actual

def main():
    assert not (D/'execution.json').exists() and not (D/'active.json').exists(),'refuse repeated timing'
    save(D/'inputs-before.json',verify())
    environment={k:os.environ.get(k) for k in ['WF_WORKERS','DYLD_INSERT_LIBRARIES','MallocNanoZone']}
    assert all(v is None for v in environment.values()),environment
    for stage in PLAN['commands']:
        record=dict(stage,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        save(D/'active.json',record)
        out=D/stage['stdout'];err=D/stage['stderr']
        print('START',stage['label'],flush=True)
        start=time.perf_counter();timed_out=False
        with out.open('xb') as stdout,err.open('xb') as stderr:
            child=subprocess.Popen(stage['argv'],cwd=T,stdout=stdout,stderr=stderr)
            try:status=child.wait(timeout=PLAN['per_command_overrun_seconds'])
            except subprocess.TimeoutExpired:
                timed_out=True;child.terminate()
                try:status=child.wait(timeout=5)
                except subprocess.TimeoutExpired:child.kill();status=child.wait()
        record.update(status=status,seconds=time.perf_counter()-start,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),overrun=timed_out,stdout_sha256=sha(out),stderr_sha256=sha(err))
        RUNS.append(record)
        save(D/'execution.json',{'commands':RUNS,'environment':environment,'construction_seconds':0,'complete':False})
        print(json.dumps({k:record[k] for k in ['label','status','seconds','overrun']}),flush=True)
        assert status==0 and not timed_out,record
        assert err.stat().st_size==0,'unexpected measurement stderr'
        with out.open() as stream:rows=list(csv.DictReader(stream))
        assert len(rows)==stage['expected_rows'],(stage['label'],len(rows))
    for arm in ['baseline','candidate']:
        a=(D/('ordered-'+arm+'-cohort-0.csv')).read_bytes()
        b=(D/('ordered-'+arm+'-cohort-1.csv')).read_bytes()
        first,body=b.split(b'\n',1);assert a.split(b'\n',1)[0]==first
        (D/('ordered-'+arm+'-samples.csv')).write_bytes(a+body)
    groups=[['vector-'+arm+'-'+replicate+'-samples.csv' for replicate in ['first','second'] for arm in ['baseline','candidate']],['ordered-'+arm+'-samples.csv' for arm in ['baseline','candidate']]]
    for family,files in zip(['vector','ordered'],groups,strict=True):
        reference=None
        for name in files:
            with (D/name).open() as f:rows=list(csv.DictReader(f))
            assert len(rows)==PLAN['families'][family]['rows_per_arm']
            semantic=[{k:v for k,v in x.items() if k!='elapsed_ns'} for x in rows]
            if reference is None:reference=semantic
            else:assert semantic==reference,(family,name,'work/checksum/order mismatch')
    save(D/'inputs-after.json',verify())
    summary={'commands':RUNS,'environment':environment,'construction_seconds':0,'execution_seconds':sum(r['seconds'] for r in RUNS),'complete':True,'sources_and_images_unchanged':True,'raw_sample_sha256':{stage['label']:sha(D/stage['stdout']) for stage in PLAN['commands']},'derived_ordered_sample_sha256':{arm:sha(D/('ordered-'+arm+'-samples.csv')) for arm in ['baseline','candidate']}}
    save(D/'execution.json',summary);(D/'active.json').unlink()
    print(json.dumps({k:v for k,v in summary.items() if k!='commands'}),flush=True)
try:main()
except Exception:
    (D/'failure.txt').write_text(traceback.format_exc());raise
