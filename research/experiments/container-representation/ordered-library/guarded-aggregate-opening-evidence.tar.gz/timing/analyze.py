"""Balanced frozen-image comparison; every invocation remains a separate sample set.

One-shot reader for the registered guarded Slots trial. No timing or construction.
"""
from collections import Counter,defaultdict
from fractions import Fraction
from pathlib import Path
import csv,hashlib,itertools,json,statistics,subprocess,time
D=Path(__file__).resolve().parent
PLAN=json.loads((D/'plan.json').read_text())
EXECUTION=json.loads((D/'execution.json').read_text())
assert EXECUTION['complete']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n')
def table(name,rows):
    assert rows
    with (D/name).open('w',newline='') as out:
        w=csv.DictWriter(out,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)

DATASETS={}
for replicate in ['first','second']:
    for arm in ['baseline','candidate']:
        label='vector-'+arm+'-'+replicate
        DATASETS[label]={'family':'vector','arm':arm,'replicate':replicate,'source':D/(label+'-samples.csv')}
for arm in ['baseline','candidate']:
    label='ordered-'+arm
    DATASETS[label]={'family':'ordered','arm':arm,'replicate':'single','source':D/(label+'-samples.csv')}
for stage in EXECUTION['commands']:
    assert stage['status']==0 and not stage['overrun']
    assert sha(D/stage['stdout'])==stage['stdout_sha256']
    assert sha(D/stage['stderr'])==stage['stderr_sha256']
assert sha(PLAN['reducer'])==PLAN['reducer_origin']['sha256']

phases=[];TARGETS={};G={}
for label,dataset in DATASETS.items():
    family=dataset['family'];contract=PLAN['families'][family]
    for option,name in [('--complete','summary'),('--targets','targets')]:
        command=['perl',PLAN['reducer'],option,family+'='+str(dataset['source'])]
        start=time.perf_counter();process=subprocess.run(command,capture_output=True)
        (D/(label+'-'+name+'.csv')).write_bytes(process.stdout)
        (D/(label+'-'+name+'.stderr')).write_bytes(process.stderr)
        phases.append({'argv':command,'status':process.returncode,'seconds':time.perf_counter()-start})
        save(D/'reduction-stages.json',phases)
        assert process.returncode==0 and process.stderr==b''
        if name=='targets':
            rows=list(csv.DictReader(process.stdout.decode().splitlines()))
            assert len(rows)==contract['cells']
            TARGETS[label]={'counts':dict(Counter(r['status'] for r in rows)),'rows':rows}
    with dataset['source'].open() as source:rows=list(csv.DictReader(source))
    assert len(rows)==contract['rows_per_arm']
    groups=defaultdict(list)
    for row in rows:
        key=(int(row[contract['width_column']]),row['path'],int(row['count']),int(row['cohort']),row['variant'])
        groups[key].append(row)
    expected=set(itertools.product(contract['widths'],contract['paths'],contract['counts'],[0,1],contract['variants']))
    assert set(groups)==expected
    for key,group in groups.items():
        assert sorted(int(r['sample']) for r in group)==contract['raw_sample_ids']
        selected=[int(r['elapsed_ns']) for r in group if int(r['sample']) in contract['ranked_sample_ids']]
        assert all(x>0 for x in selected)
        G[(label,)+key]={'min':min(selected),'median':int(statistics.median(selected)),'max':max(selected)}

def compare(a,b):
    ratios=[Fraction(y['median'],x['median']) for x,y in zip(a,b,strict=True)]
    dirs=['gain' if y['max']<x['min'] else 'loss' if y['min']>x['max'] else 'overlap' for x,y in zip(a,b,strict=True)]
    raw=dirs[0] if dirs[0]==dirs[1] else 'overlap'
    minimum=min(x['min'] for x in a+b)
    spread=max(ratios)/min(ratios)-1
    reasons=[]
    if minimum<1000000:reasons.append('sub-1ms')
    if spread>Fraction(1,10):reasons.append('cohort-unstable')
    result='inconclusive' if reasons else raw
    row={'ratio_0':float(ratios[0]),'ratio_1':float(ratios[1]),'minimum_ns':minimum,'cohort_spread_pct':float(spread*100),'raw_result':raw,'qualified_result':result,'qualification_reason':';'.join(reasons)}
    for cohort,(x,y) in enumerate(zip(a,b,strict=True)):
        row[f'raw_direction_{cohort}']=dirs[cohort]
        for arm,z in [('reference',x),('compared',y)]:
            for stat,value in z.items():row[f'{arm}_{stat}_ns_{cohort}']=value
        row[f'observed_lower_{cohort}']=y['min']/x['max'];row[f'observed_upper_{cohort}']=y['max']/x['min']
    return row

def series(label,width,path,count,variant):
    return [G[(label,width,path,count,c,variant)] for c in [0,1]]

def cell_keys(family):
    contract=PLAN['families'][family]
    for width,path,count in itertools.product(contract['widths'],contract['paths'],contract['counts']):
        yield {'family':family,'payload_bytes':width,'path':path,'count':count,'useful':int(not(family=='vector' and path=='suffix-0'))}

def values(label,key,variant):
    return series(label,key['payload_bytes'],key['path'],key['count'],variant)

paired=[];peer=[];native=[];repeats=[]
for family in ['vector','ordered']:
    contract=PLAN['families'][family]
    for replicate in (['first','second'] if family=='vector' else ['single']):
        labels={arm:family+'-'+arm+('-'+replicate if family=='vector' else '') for arm in ['baseline','candidate']}
        for key in cell_keys(family):
            a=values(labels['baseline'],key,'whitefoot');b=values(labels['candidate'],key,'whitefoot')
            paired.append(dict(key,replicate=replicate,**compare(a,b)))
            for variant in contract['variants'][1:]:
                x=values(labels['baseline'],key,variant);y=values(labels['candidate'],key,variant)
                native.append(dict(key,replicate=replicate,variant=variant,**compare(x,y)))
            for arm,wf in [('baseline',a),('candidate',b)]:
                for name,variant in contract['standard_peers'].items():
                    ref=values(labels[arm],key,variant);r=compare(ref,wf)
                    status={'gain':'pass','loss':'deficit','overlap':'inconclusive','inconclusive':'inconclusive'}[r['qualified_result']]
                    peer.append(dict(key,replicate=replicate,arm=arm,peer=name,status=status if key['useful'] else 'unranked',**r))
for arm in ['baseline','candidate']:
    for key in cell_keys('vector'):
        for variant in PLAN['families']['vector']['variants']:
            a=values('vector-'+arm+'-first',key,variant);b=values('vector-'+arm+'-second',key,variant)
            repeats.append(dict(key,arm=arm,variant=variant,**compare(a,b)))
assert len(paired)==114 and len(peer)==456 and len(native)==684 and len(repeats)==588

collapsed=[]
for family in ['vector','ordered']:
    for key in cell_keys(family):
        rows=[r for r in paired if all(r[k]==v for k,v in key.items())]
        assert len(rows)==(2 if family=='vector' else 1)
        statuses=[r['qualified_result'] for r in rows]
        stable_gain=all(s=='gain' for s in statuses)
        loss_veto=any(s=='loss' for s in statuses)
        status='qualified-loss-observed' if loss_veto else 'gain' if stable_gain else 'overlap' if all(s=='overlap' for s in statuses) else 'inconclusive'
        collapsed.append(dict(key,selection_status=status,stable_gain=int(stable_gain),qualified_loss_observed=int(loss_veto),replicate_conflict=int('gain' in statuses and 'loss' in statuses),first_result=statuses[0],second_result=statuses[1] if len(statuses)>1 else '',first_qualification_reason=rows[0]['qualification_reason'],second_qualification_reason=rows[1]['qualification_reason'] if len(rows)>1 else ''))
assert len(collapsed)==72
for name,rows in [('paired-replicates.csv',paired),('paired-cells.csv',collapsed),('standard-peer-cells.csv',peer),('native-peer-drift.csv',native),('vector-same-image-drift.csv',repeats)]:table(name,rows)
useful=[r for r in collapsed if r['useful']]
summary={
 'criterion_met':any(r['stable_gain'] for r in useful) and not any(r['qualified_loss_observed'] for r in useful),
 'stable_useful_gains':sum(r['stable_gain'] for r in useful),'useful_cells_with_qualified_loss':sum(r['qualified_loss_observed'] for r in useful),
 'paired_replicate_rows':len(paired),'collapsed_cells':len(collapsed),'useful_cells':len(useful),'raw_rows':sum(c['expected_rows'] for c in PLAN['commands']),
 'families':{},'standard_peers':{},'targets_by_invocation':{k:v['counts'] for k,v in TARGETS.items()},
 'native_peer_drift_rows':len(native),'same_image_drift_rows':len(repeats),
 'construction_seconds':0,'timing_execution_seconds':EXECUTION['execution_seconds'],
 'raw_sample_sha256':EXECUTION['raw_sample_sha256'],'reducer_sha256':sha(PLAN['reducer']),'analysis_sha256':sha(__file__),
 'method':'No pooling, sample renumbering, outlier removal or peer-drift subtraction. Every invocation and adverse replicate remains separate; a qualified useful loss in either Vector pair vetoes selection.'
}
for family in ['vector','ordered']:
    rows=[r for r in collapsed if r['family']==family]
    summary['families'][family]={str(useful):dict(Counter(r['selection_status'] for r in rows if bool(r['useful'])==useful)) for useful in [True,False]}
    summary['families'][family]['replicates']={replicate:dict(Counter(r['qualified_result'] for r in paired if r['family']==family and r['replicate']==replicate and r['useful'])) for replicate in (['first','second'] if family=='vector' else ['single'])}
for label,dataset in DATASETS.items():
    summary['standard_peers'][label]={p:dict(Counter(r['status'] for r in peer if r['family']==dataset['family'] and r['arm']==dataset['arm'] and r['replicate']==dataset['replicate'] and r['peer']==p)) for p in ['rust','cpp']}
save(D/'reduction.json',summary)
print(json.dumps(summary,indent=2))
