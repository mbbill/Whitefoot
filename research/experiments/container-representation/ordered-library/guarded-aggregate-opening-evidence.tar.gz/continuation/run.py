"""One-shot authorized paired correctness for the guarded aggregate-opening factor.

Reuse verified native peers/runtime; retire with this isolated experiment.
No performance timing commands occur here.
"""
from pathlib import Path
import csv,hashlib,itertools,json,os,re,subprocess,time,traceback
T=Path(__file__).resolve().parents[1]
D=T/'continuation'
O=Path('<ordered-baseline-root>')
V=Path('<vector-baseline-root>/research/experiments/container-representation/vector-library/.build/actual-ablation/terminal')
F=D/'sources/research/experiments/container-representation'
U=Path('<unguarded-root>/continuation')
REUSED=json.loads((U/'images.json').read_text())
LINKS=json.loads((D/'link-commands.json').read_text())
INPUTS=json.loads((D/'inputs.json').read_text())
STAGES=[]
IMAGES={}
AUDITS={}

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):Path(path).write_text(json.dumps(value,indent=2)+'\n')
def verify():
    observed={path:sha(path) for path in INPUTS}
    assert observed==INPUTS,{p:[INPUTS[p],observed[p]] for p in INPUTS if observed[p]!=INPUTS[p]}
    source=json.loads((T/'source-freeze.json').read_text())
    assert {p:sha(T/'candidate'/p) for p in source}==source
    return observed

def run(label,category,argv,status=0,cwd=None,timeout=45):
    log=D/category;log.mkdir(exist_ok=True)
    out=log/(label+'.stdout');err=log/(label+'.stderr')
    assert not out.exists() and not err.exists(),('repeated stage',label)
    argv=[str(a) for a in argv]
    record={'label':label,'category':category,'argv':argv,'cwd':str(cwd or D),'expected_status':status}
    print('START',label,flush=True)
    start=time.perf_counter()
    env=os.environ.copy();env.pop('WF_WORKERS',None)
    with out.open('wb') as stdout,err.open('wb') as stderr:
        process=subprocess.run(argv,cwd=cwd or D,stdout=stdout,stderr=stderr,env=env,timeout=timeout)
    record.update(status=process.returncode,seconds=time.perf_counter()-start,stdout=str(out),stderr=str(err))
    STAGES.append(record);save(D/'stages.json',STAGES)
    print(json.dumps({k:record[k] for k in ['label','status','seconds']}),flush=True)
    assert process.returncode==status,record
    return out.read_bytes(),err.read_bytes()

def account(text,nonnull):
    assert '@malloc(' in text and '@free(' in text
    text=text.replace('@malloc(','@wf_cost_allocate(').replace('@free(','@wf_cost_release(')
    if nonnull:
        decl='declare ptr @wf_cost_allocate(i64)'
        assert text.splitlines().count(decl)==1
        text=text.replace(decl,'declare noalias nonnull ptr @wf_cost_allocate(i64)')
    return text

def retain(text,family):
    if family=='vector':
        pattern=r'^define .* @"?wf_(std[.]collections[.]vector[.]grow_vector_|vector_library_(work|round|tail_work)|vector_(word|record)_(make|accept))'
    else:
        pattern=r'^define .* @"?wf_(?:(?:std[.])?collections[.]ordered_map[.]ordered_map_(?:new|len|put|lookup|edit|remove|each|range|free)(?:[$(]|[ \t])|ordered_cost_(?:compare|(?:word|record)_(?:make|observe|visit|edit|consume))[$(])'
    changed=0;lines=[]
    for line in text.splitlines(True):
        if re.search(pattern,line) and not re.search(r'[.]body"?[(]',line):
            assert line.endswith(' #0 {\n'),line
            line=line.replace(' #0 {\n',' noinline #0 {\n');changed+=1
        lines.append(line)
    assert changed>0
    AUDITS[family+'-retained-definitions']=changed
    return ''.join(lines)

def build():
    for family,old in [('vector',V/'ecosystem'),('ordered',O/'build/candidate/ecosystem')]:
        for arm in ['baseline','candidate']:
            work=D/arm/family;work.mkdir(parents=True)
            native=T/'native'/arm/(family+'-library')
            timed=(native/'timed.ll').read_text()
            assert not re.search(r'@wf_(cost_allocate|cost_release|ecosystem_note_)',timed)
            observed=account(timed,True)
            (work/'account.ll').write_text(observed)
            if arm=='baseline':
                assert timed==(old/'whitefoot-timed.ll').read_text()
                assert (native/'native.o').read_bytes()==(old/'whitefoot-timed.o').read_bytes()
                assert observed==(old/'whitefoot-account.ll').read_text()
            else:
                run(family+'-account-object','construction',['/usr/bin/clang','-O3','-Wno-override-module','-x','ir','-c',work/'account.ll','-o',work/'account.o'])
            for mode in ['timed','account']:
                name=('vector-costs-' if family=='vector' else 'ordered-ecosystem-')+mode
                if arm=='baseline':image=old/name
                else:
                    command=list(LINKS['vector'][mode]['command'] if family=='vector' else LINKS[name])
                    index=next(i for i,x in enumerate(command) if Path(x).name=='whitefoot-'+mode+'.o')
                    command[index]=str(native/'native.o' if mode=='timed' else work/'account.o')
                    image=work/name;command[command.index('-o')+1]=str(image)
                    run(family+'-'+mode+'-link','construction',command)
                IMAGES[family+'-'+arm+'-'+mode]=str(image)
                out,_=run(family+'-'+arm+'-'+mode+'-symbols','construction',['/usr/bin/nm','-n','-m',image])
                floor=[line for line in out.decode().splitlines() if line.endswith(' _wf__floor_run')]
                assert len(floor)==1 and 'weak' not in floor[0],floor
                if mode=='timed':assert not re.search(r'wf_(cost_allocate|cost_release|ecosystem_note_)',out.decode())
        # Keep the historical ordinary and explicitly retained O2 contracts.
        for arm in ['baseline','candidate']:
            work=D/arm/family
            normal=account((T/'native'/arm/(family+'-library')/'timed.ll').read_text(),family=='ordered')
            retained=retain(normal,family)
            for mode,text in [('normal',normal),('retained',retained)]:
                llvm=work/(mode+'.ll');llvm.write_text(text)
                opt=work/(mode+'.opt.ll')
                if arm=='baseline':
                    if family=='ordered':
                        assert text==(O/'build/candidate'/('ordered-library-'+mode+'.ll')).read_text()
                        opt=O/'build/candidate'/('ordered-library-'+mode+'.opt.ll')
                    else:
                        assert text==(U/'baseline/vector'/(mode+'.ll')).read_text()
                        opt=U/'baseline/vector'/(mode+'.opt.ll')
                    image=Path(REUSED[family+'-baseline-'+mode]['path'])
                    assert sha(image)==REUSED[family+'-baseline-'+mode]['sha256']
                else:
                    run(family+'-'+arm+'-'+mode+'-opt','construction',['/usr/bin/clang','-O2','-Wno-override-module','-x','ir','-S','-emit-llvm',llvm,'-o',opt])
                    image=work/(family+'-costs-'+mode)
                    if family=='ordered':
                        command=list(LINKS['ordered-costs-'+mode])
                        command[command.index('ordered-costs.c')]=str(F/'ordered-library/ordered-costs.c')
                        index=next(i for i,x in enumerate(command) if Path(x).name=='ordered-library-'+mode+'.ll')
                        command[index]=str(llvm);command[command.index('-o')+1]=str(image)
                    else:
                        runtime=[x for x in LINKS['vector']['timed']['unchanged_inputs'] if '/native/' in x]
                        command=['/usr/bin/clang','-std=c11','-O2','-Wall','-Wextra','-Werror','-Wno-override-module']
                        if mode=='retained':command+=['-DRETAIN_HELPERS']
                        command+=[str(F/'vector-library/vector-costs.c'),str(llvm)]+runtime+['-pthread','-lm','-o',str(image)]
                    run(family+'-'+arm+'-'+mode+'-link','construction',command)
                IMAGES[family+'-'+arm+'-'+mode]=str(image)
                pattern=r'call .*@"?wf_std[.]collections[.]vector[.]grow_vector_' if family=='vector' else r'call .*@"?wf_(?:std[.])?collections[.]ordered_map[.]ordered_map_(put|lookup|edit|remove|each|range|free)[$(]'
                count=sum(bool(re.search(pattern,line)) and (family=='vector' or not re.search(r'[.]body"?[(]',line)) for line in opt.read_text().splitlines())
                AUDITS[family+'-'+arm+'-'+mode+'-call-sites']=count
                if mode=='retained':assert count>0
    # C helper-retention checks are independent of the compiler factor.
    for mode in ['normal','retained']:
        out=U/('vector-control-'+mode+'.opt.ll')
        assert sha(out)==INPUTS[str(out)]
        if mode=='retained':
            count=len(re.findall(r'call .*@(word|record)_(reverse|direct)_(append|truncate)',out.read_text()))
            assert count>0;AUDITS['vector-c-retained-call-sites']=count
    for control in sorted((O/'build/candidate').glob('control-*-retained.ll')):
        count=len(re.findall(r'call .*@(word|record)_(source|direct|avl)_(put|lookup|edit|remove|each|range|free)[(]',control.read_text()))
        assert count>0;AUDITS[control.name+'-call-sites']=count
    build_owners()
    build_vector_owner()
    save(D/'images.json',{name:{'path':path,'sha256':sha(path)} for name,path in IMAGES.items()})
    save(D/'native-audits.json',AUDITS)

def build_owners():
    runtime=[str(p) for p in sorted((O/'shared/native').glob('*.o'))]+[str(p) for p in sorted((O/'shared/native/sched').glob('*.o'))]+[str(p) for p in sorted((O/'shared/native/completion').glob('*.o'))]
    native=T/'candidate/compiler/src/backend'
    for kind,source_arm in [('program','candidate'),('chronology','candidate'),('chronology','callback-order-fault'),('chronology','release-order-fault')]:
        label=kind if source_arm=='candidate' else source_arm
        carrier=O/'carriers'/source_arm/kind
        observer=T/'candidate/tests/programs/containers'/('container-allocation-observer.c' if kind=='program' else 'ordered-map-cleanup-observer.c')
        for mode in ['sequential','parallel']:
            stem=label+'-'+mode;old_stem=kind+'-'+source_arm+'-'+mode
            output=D/'candidate/owners';output.mkdir(exist_ok=True)
            raw=output/(stem+'.ll')
            command=[T/'frozen/whitefootc','--emit-llvm']
            if mode=='parallel':command+=['--par']
            command+=['--graph',carrier/'modules.wfg','--entry','experiment','-o',raw]
            run(stem+'-emit','construction',command)
            text=raw.read_text();assert '@malloc(' in text and '@free(' in text and text.count('define i32 @main(')==1
            observed=output/(stem+'-observed.ll')
            observed.write_text(text.replace('@malloc(','@wf_observe_allocate(').replace('@free(','@wf_observe_release(').replace('@main(','@wf_fixture_main('))
            for suffix,llvm in [('',raw),('-observed',observed)]:
                image=output/(stem+suffix)
                command=['/usr/bin/clang','-O2','-pthread','-Wno-override-module']
                if suffix:command+=['-std=c11','-Wall','-Wextra','-Werror','-I'+str(native),'-I'+str(native/'completion')]
                command+=[str(llvm)]
                if suffix:command+=[str(observer)]
                command+=runtime+['-lm','-o',str(image)]
                run(stem+suffix+'-link','construction',command)
                IMAGES['owner-candidate-'+stem+suffix]=str(image)
                IMAGES['owner-baseline-'+stem+suffix]=str(O/'programs'/(old_stem+suffix))

def build_vector_owner():
    runtime=[str(p) for p in sorted((O/'shared/native').glob('*.o'))]+[str(p) for p in sorted((O/'shared/native/sched').glob('*.o'))]+[str(p) for p in sorted((O/'shared/native/completion').glob('*.o'))]
    native=T/'candidate/compiler/src/backend'
    source=T/'candidate/tests/programs/containers/grow-vector-program.wf'
    observer=T/'candidate/tests/programs/containers/container-allocation-observer.c'
    output=D/'candidate/vector-owner';output.mkdir(exist_ok=False)
    for mode in ['sequential','parallel']:
        raw=output/(mode+'.ll')
        command=[T/'frozen/whitefootc','--emit-llvm']
        if mode=='parallel':command+=['--par']
        command+=[source,'-o',raw]
        run('vector-owner-'+mode+'-emit','construction',command)
        text=raw.read_text();assert '@malloc(' in text and '@free(' in text and text.count('define i32 @main(')==1
        observed=output/(mode+'-observed.ll')
        observed.write_text(text.replace('@malloc(','@wf_observe_allocate(').replace('@free(','@wf_observe_release(').replace('@main(','@wf_fixture_main('))
        for suffix,llvm in [('',raw),('-observed',observed)]:
            image=output/(mode+suffix)
            command=['/usr/bin/clang','-O2','-pthread','-Wno-override-module']
            if suffix:command+=['-std=c11','-Wall','-Wextra','-Werror','-I'+str(native),'-I'+str(native/'completion')]
            command+=[str(llvm)]
            if suffix:command+=[str(observer)]
            command+=runtime+['-lm','-o',str(image)]
            run('vector-owner-'+mode+suffix+'-link','construction',command)
            IMAGES['vector-owner-'+mode+suffix]=str(image)

def execute():
    image_hashes={name:sha(path) for name,path in IMAGES.items()}
    for family in ['vector','ordered']:
        for arm in ['baseline','candidate']:
            for mode in ['timed','account','normal','retained']:
                out,err=run(family+'-'+arm+'-'+mode+'-check','execution',[IMAGES[family+'-'+arm+'-'+mode],'check'])
                if family=='vector':expected=(b'vector ecosystem: 1260 configurations, 8820 executions passed\n' if mode in ['timed','account'] else b'vector library costs: 1260 five-way configurations, 6300 executions passed\n')
                else:expected=(b'ordered ecosystem: 330 configurations, 2310 executions, 6 C tree audits and 3 native container audits passed\n' if mode in ['timed','account'] else ('ordered library costs: 330 configurations, 1320 executions and 6 complete native structural audits passed ('+mode+')\n').encode())
                assert out==expected and err==b'',(family,arm,mode,out,err)
            if family=='vector':
                for mode in ['timed','account']:
                    out,err=run(family+'-'+arm+'-'+mode+'-checksum-fault','execution',[IMAGES[family+'-'+arm+'-'+mode],'fail-checksum'],1)
                    assert out==b'' and err==b'vector library costs: independent logical-order checksum\n'
                out,err=run(family+'-'+arm+'-cleanup-fault','execution',[IMAGES[family+'-'+arm+'-account'],'fail-cleanup'],1)
                assert out==b'' and err==b'vector library costs: complete cleanup\n'
            else:
                for fault,reason in [('checksum','ecosystem independent sorted sequence checksum'),('cleanup','ecosystem complete allocation cleanup')]:
                    out,err=run(family+'-'+arm+'-'+fault+'-fault','execution',[IMAGES[family+'-'+arm+'-account'],'check-fault-'+fault],1)
                    assert out==b'' and reason.encode() in err
            out,err=run(family+'-'+arm+'-account-ledger','execution',[IMAGES[family+'-'+arm+'-account'],'account'])
            old=(V/'ecosystem/accounting.csv' if family=='vector' else O/'build/candidate/ecosystem/accounting.csv').read_bytes()
            assert out==old and err==b'',(family,arm,'accounting differs')
            rows=list(csv.DictReader(out.decode().splitlines()))
            if family=='vector':
                keys=[(r['element_bytes'],r['path'],r['count'],r['variant']) for r in rows]
                expected=set(itertools.product(('8','256'),('reserved','growth','reuse','suffix-0','suffix-1','suffix-2','suffix-3'),('16','256','4096'),('whitefoot','reverse-c','direct-c','swap-take-c','take-swap-c','rust-vec','cpp-std-vector')))
            else:
                keys=[(r['pair_bytes'],r['path'],r['count'],r['variant']) for r in rows]
                expected=set(itertools.product(('16','264'),('build-cleanup','hit-miss','range-16','replace-only','replace-edit-remove-insert'),('8','256','4096'),('whitefoot','source-c','direct-c','avl-c','rust-btree-map','cpp-map','absl-btree-map')))
            assert len(keys)==len(set(keys))==len(expected) and set(keys)==expected
    out,err=run('ordered-structural','execution',[O/'build/candidate/structural-costs','structure'])
    assert err==b'' and out==(O/'build/candidate/structural-paths.csv').read_bytes()
    rows=list(csv.DictReader(out.decode().splitlines()))
    assert len(rows)==11 and all(int(r['count'])>0 if r['path']!='predecessor' else int(r['count'])==0 for r in rows)
    for arm in ['baseline','candidate']:
        for label in ['program','chronology','callback-order-fault','release-order-fault']:
            for mode in ['sequential','parallel']:
                for observed in [False,True]:
                    stem=label+'-'+mode+('-observed' if observed else '')
                    status=1 if label=='callback-order-fault' or label=='release-order-fault' and observed else 0
                    out,err=run(arm+'-'+stem,'execution',[IMAGES['owner-'+arm+'-'+stem]],status)
                    expected_out=expected_err=b''
                    if observed:
                        if label=='program':expected_out=b'container allocation observer: 103 allocations, each released exactly once\n'
                        elif label=='chronology':expected_out=b'ordered cleanup observer: 16 callbacks and 3 node releases preserve order\n'
                        elif label=='callback-order-fault':expected_err=b'ordered cleanup observer: callback order\n'
                        else:expected_err=b'ordered cleanup observer: parent release before leading callback\n'
                    assert out==expected_out and err==expected_err,(arm,stem,out,err)
    for mode in ['sequential','parallel']:
        for observed in [False,True]:
            name='vector-owner-'+mode+('-observed' if observed else '')
            out,err=run(name,'execution',[IMAGES[name]])
            assert out==(b'container allocation observer: 25 allocations, each released exactly once\n' if observed else b'') and err==b''
    assert image_hashes=={name:sha(path) for name,path in IMAGES.items()}
    save(D/'result.json',{'all_checks_passed':True,'images':len(IMAGES),'ecosystem_images_checked':8,'normal_retained_images_checked':8,'vector_accounting_rows_per_arm':294,'ordered_accounting_rows_per_arm':210,'accounting_byte_equal_to_baseline':True,'ordered_owner_and_chronology_commands':32,'vector_owner_commands':4,'construction_seconds':sum(s['seconds'] for s in STAGES if s['category']=='construction'),'execution_seconds':sum(s['seconds'] for s in STAGES if s['category']=='execution'),'image_hashes':image_hashes,'timing_executed':False})

try:
    INPUTS[str(D/'run.py')]=sha(D/'run.py')
    save(D/'inputs-before.json',verify())
    build()
    save(D/'inputs-after-construction.json',verify())
    execute()
    save(D/'inputs-after.json',verify())
    print((D/'result.json').read_text(),flush=True)
except Exception:
    (D/'failure.txt').write_text(traceback.format_exc());raise
finally:
    save(D/'artifacts.json',{str(p.relative_to(D)):sha(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name not in ['artifacts.json','guard.stdout','guard.stderr']})
