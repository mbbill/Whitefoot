_wf_std.collections.ordered_map.ordered_map_lookup_link$instance$11eb30e8dabe0f7e: ; @"wf_std.collections.ordered_map.ordered_map_lookup_link$instance$11eb30e8dabe0f7e"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB32_6
; %bb.1:                                ; %bb2.i
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	mov	x19, x1
	ldr	x20, [x0, #8]
	ldr	x24, [x20, #16]
	cbz	x24, LBB32_12
; %bb.2:                                ; %bb2.lr.ph.i.i
	mov	x25, x2
	mov	x23, #0                         ; =0x0
	add	x21, x20, #32
LBB32_3:                                ; %bb2.i.i1
                                        ; =>This Inner Loop Header: Depth=1
	sub	x22, x21, #8
	mov	x0, x19
	mov	x1, x22
	bl	_wf_ordered_cost_compare
	cmp	w0, #1
	b.lt	LBB32_7
; %bb.4:                                ; %bb8.i.i2
                                        ;   in Loop: Header=BB32_3 Depth=1
	add	x23, x23, #1
	add	x21, x21, #32
	cmp	x24, x23
	b.ne	LBB32_3
; %bb.5:
	mov	x23, x24
	mov	x2, x25
	b	LBB32_11
LBB32_6:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	ret
LBB32_7:                                ; %"wf_std.collections.ordered_map.ordered_map_search$instance$5046b787ff5cdb3f.exit"
	cmp	x23, x24
	mov	x2, x25
	b.hs	LBB32_10
; %bb.8:                                ; %"wf_std.collections.ordered_map.ordered_map_search$instance$5046b787ff5cdb3f.exit"
	cbnz	w0, LBB32_10
; %bb.9:                                ; %bb5.i.i
	mov	x0, x2
	mov	x1, x22
	mov	x2, x21
	bl	_wf_ordered_cost_word_observe
	mov	x1, x0
	mov	w0, #0                          ; =0x0
	b	LBB32_14
LBB32_10:                               ; %bb1.i.i
	cbz	x23, LBB32_12
LBB32_11:                               ; %bb9.i.i
	add	x8, x20, x23, lsl #5
	add	x0, x8, #8
	b	LBB32_13
LBB32_12:                               ; %bb8.i.i
	mov	x0, x20
LBB32_13:
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_lookup_link$instance$11eb30e8dabe0f7e
LBB32_14:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	mov	w2, #0                          ; =0x0
	ret
                                        ; -- End function