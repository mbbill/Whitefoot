_wf_std.collections.ordered_map.ordered_map_lookup_link$instance$11eb30e8dabe0f7e: ; @"wf_std.collections.ordered_map.ordered_map_lookup_link$instance$11eb30e8dabe0f7e"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB32_6
; %bb.1:                                ; %bb2.i
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	mov	x19, x2
	mov	x20, x1
	ldr	x21, [x0, #8]
	mov	x23, x21
	ldr	x25, [x23, #16]!
	cbz	x25, LBB32_7
; %bb.2:                                ; %bb2.lr.ph.i
	mov	x24, #0                         ; =0x0
	add	x22, x21, #24
LBB32_3:                                ; %bb2.i2
                                        ; =>This Inner Loop Header: Depth=1
	mov	x0, x20
	mov	x1, x22
	bl	_wf_ordered_cost_compare
	cmp	w0, #1
	b.lt	LBB32_8
; %bb.4:                                ; %bb8.i
                                        ;   in Loop: Header=BB32_3 Depth=1
	add	x24, x24, #1
	add	x22, x22, #32
	cmp	x25, x24
	b.ne	LBB32_3
; %bb.5:
	mov	x24, x25
	b	LBB32_11
LBB32_6:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	ret
LBB32_7:
	mov	x24, #0                         ; =0x0
LBB32_8:                                ; %"wf_std.collections.ordered_map.ordered_map_search$instance$5046b787ff5cdb3f.exit"
	cmp	x24, x25
	b.hs	LBB32_10
; %bb.9:                                ; %bb2.i.i
	add	x22, x23, x24, lsl #5
	add	x1, x22, #8
	mov	x0, x20
	bl	_wf_ordered_cost_compare
	cbz	w0, LBB32_15
LBB32_10:                               ; %bb1.i.i
	cbz	x24, LBB32_12
LBB32_11:                               ; %bb9.i.i
	add	x8, x23, x24, lsl #5
	sub	x0, x8, #8
	b	LBB32_13
LBB32_12:                               ; %bb8.i.i
	mov	x0, x21
LBB32_13:
	mov	x1, x20
	mov	x2, x19
	bl	_wf_std.collections.ordered_map.ordered_map_lookup_link$instance$11eb30e8dabe0f7e
LBB32_14:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	mov	w2, #0                          ; =0x0
	ret
LBB32_15:                               ; %bb5.i.i
	add	x1, x22, #8
	add	x2, x22, #16
	mov	x0, x19
	bl	_wf_ordered_cost_word_observe
	mov	x1, x0
	mov	w0, #0                          ; =0x0
	b	LBB32_14
                                        ; -- End function