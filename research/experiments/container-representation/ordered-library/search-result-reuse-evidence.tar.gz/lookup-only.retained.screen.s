	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function wf_ordered_cost_compare
_wf_ordered_cost_compare:               ; @wf_ordered_cost_compare
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x9, [x1]
	cmp	x8, x9
	mov	w8, #9                          ; =0x9
	csel	w8, w8, wzr, hi
	mov	w9, #-7                         ; =0xfffffff9
	csel	w0, w9, w8, lo
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_ordered_cost_word_observe
_wf_ordered_cost_word_observe:          ; @wf_ordered_cost_word_observe
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	mov	w9, #131                        ; =0x83
	ldr	x10, [x2]
	madd	x8, x8, x9, x10
	ldr	x10, [x0]
	madd	x9, x10, x9, x8
	str	x9, [x0]
	mov	x0, x8
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_ordered_cost_word_visit
_wf_ordered_cost_word_visit:            ; @wf_ordered_cost_word_visit
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x2]
	ldr	x10, [x0]
	add	x8, x10, x8
	mov	w10, #131                       ; =0x83
	madd	x8, x8, x10, x9
	str	x8, [x0]
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_ordered_cost_word_edit
_wf_ordered_cost_word_edit:             ; @wf_ordered_cost_word_edit
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	add	x8, x8, #1
	str	x8, [x2]
	ldr	x9, [x1]
	mov	w10, #131                       ; =0x83
	madd	x8, x9, x10, x8
	ldr	x9, [x0]
	madd	x9, x9, x10, x8
	str	x9, [x0]
	mov	x0, x8
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_ordered_cost_word_consume
_wf_ordered_cost_word_consume:          ; @wf_ordered_cost_word_consume
; %bb.0:                                ; %entry
	mov	w8, #131                        ; =0x83
	madd	x8, x1, x8, x2
	ldp	x9, x10, [x0, #8]
	add	x9, x9, x8
	eor	x8, x8, x8, lsr #30
	mov	x11, #58809                     ; =0xe5b9
	movk	x11, #7396, lsl #16
	movk	x11, #18285, lsl #32
	movk	x11, #48984, lsl #48
	mul	x8, x8, x11
	eor	x8, x8, x8, lsr #27
	mov	x11, #4587                      ; =0x11eb
	movk	x11, #4913, lsl #16
	movk	x11, #18875, lsl #32
	movk	x11, #38096, lsl #48
	mul	x8, x8, x11
	eor	x10, x10, x8, lsr #31
	eor	x8, x10, x8
	stp	x9, x8, [x0, #8]
	ldr	x8, [x0, #24]
	add	x8, x8, #1
	str	x8, [x0, #24]
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_ordered_cost_record_make
lCPI5_0:
	.quad	1                               ; 0x1
	.quad	2                               ; 0x2
lCPI5_1:
	.quad	3                               ; 0x3
	.quad	4                               ; 0x4
lCPI5_2:
	.quad	5                               ; 0x5
	.quad	6                               ; 0x6
lCPI5_3:
	.quad	7                               ; 0x7
	.quad	8                               ; 0x8
lCPI5_4:
	.quad	9                               ; 0x9
	.quad	10                              ; 0xa
lCPI5_5:
	.quad	11                              ; 0xb
	.quad	12                              ; 0xc
lCPI5_6:
	.quad	13                              ; 0xd
	.quad	14                              ; 0xe
lCPI5_7:
	.quad	15                              ; 0xf
	.quad	16                              ; 0x10
lCPI5_8:
	.quad	17                              ; 0x11
	.quad	18                              ; 0x12
lCPI5_9:
	.quad	19                              ; 0x13
	.quad	20                              ; 0x14
lCPI5_10:
	.quad	21                              ; 0x15
	.quad	22                              ; 0x16
lCPI5_11:
	.quad	23                              ; 0x17
	.quad	24                              ; 0x18
lCPI5_12:
	.quad	25                              ; 0x19
	.quad	26                              ; 0x1a
lCPI5_13:
	.quad	27                              ; 0x1b
	.quad	28                              ; 0x1c
lCPI5_14:
	.quad	29                              ; 0x1d
	.quad	30                              ; 0x1e
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_wf_ordered_cost_record_make:           ; @wf_ordered_cost_record_make
; %bb.0:                                ; %entry
	dup.2d	v0, x1
Lloh0:
	adrp	x8, lCPI5_0@PAGE
Lloh1:
	ldr	q1, [x8, lCPI5_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI5_1@PAGE
Lloh3:
	ldr	q2, [x8, lCPI5_1@PAGEOFF]
	add.2d	v1, v0, v1
Lloh4:
	adrp	x8, lCPI5_2@PAGE
Lloh5:
	ldr	q3, [x8, lCPI5_2@PAGEOFF]
	add.2d	v2, v0, v2
Lloh6:
	adrp	x8, lCPI5_3@PAGE
Lloh7:
	ldr	q4, [x8, lCPI5_3@PAGEOFF]
	add.2d	v3, v0, v3
Lloh8:
	adrp	x8, lCPI5_4@PAGE
Lloh9:
	ldr	q5, [x8, lCPI5_4@PAGEOFF]
	add.2d	v4, v0, v4
Lloh10:
	adrp	x8, lCPI5_5@PAGE
Lloh11:
	ldr	q6, [x8, lCPI5_5@PAGEOFF]
	add.2d	v5, v0, v5
Lloh12:
	adrp	x8, lCPI5_6@PAGE
Lloh13:
	ldr	q7, [x8, lCPI5_6@PAGEOFF]
	add.2d	v6, v0, v6
Lloh14:
	adrp	x8, lCPI5_7@PAGE
Lloh15:
	ldr	q16, [x8, lCPI5_7@PAGEOFF]
	add.2d	v7, v0, v7
Lloh16:
	adrp	x8, lCPI5_8@PAGE
Lloh17:
	ldr	q17, [x8, lCPI5_8@PAGEOFF]
	add.2d	v16, v0, v16
Lloh18:
	adrp	x8, lCPI5_9@PAGE
Lloh19:
	ldr	q18, [x8, lCPI5_9@PAGEOFF]
	add.2d	v17, v0, v17
Lloh20:
	adrp	x8, lCPI5_10@PAGE
Lloh21:
	ldr	q19, [x8, lCPI5_10@PAGEOFF]
	add.2d	v18, v0, v18
Lloh22:
	adrp	x8, lCPI5_11@PAGE
Lloh23:
	ldr	q20, [x8, lCPI5_11@PAGEOFF]
	add.2d	v19, v0, v19
Lloh24:
	adrp	x8, lCPI5_12@PAGE
Lloh25:
	ldr	q21, [x8, lCPI5_12@PAGEOFF]
	add.2d	v20, v0, v20
Lloh26:
	adrp	x8, lCPI5_13@PAGE
Lloh27:
	ldr	q22, [x8, lCPI5_13@PAGEOFF]
	add.2d	v21, v0, v21
Lloh28:
	adrp	x8, lCPI5_14@PAGE
Lloh29:
	ldr	q23, [x8, lCPI5_14@PAGEOFF]
	add.2d	v22, v0, v22
	add.2d	v0, v0, v23
	str	x1, [x0]
	add	x8, x1, #31
	stur	q1, [x0, #8]
	stur	q2, [x0, #24]
	stur	q3, [x0, #40]
	stur	q4, [x0, #56]
	stur	q5, [x0, #72]
	stur	q6, [x0, #88]
	stur	q7, [x0, #104]
	stur	q16, [x0, #120]
	stur	q17, [x0, #136]
	stur	q18, [x0, #152]
	stur	q19, [x0, #168]
	stur	q20, [x0, #184]
	stur	q21, [x0, #200]
	stur	q22, [x0, #216]
	stur	q0, [x0, #232]
	str	x8, [x0, #248]
	ret
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_ordered_cost_record_content
_wf_ordered_cost_record_content:        ; @wf_ordered_cost_record_content
; %bb.0:                                ; %entry
	ldr	x9, [x0]
	mov	w8, #131                        ; =0x83
	ldp	x10, x11, [x1]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #16]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #32]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #48]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #64]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #80]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #96]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #112]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #128]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #144]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #160]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #176]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #192]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #208]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #224]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #240]
	madd	x9, x9, x8, x10
	madd	x0, x9, x8, x11
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_ordered_cost_record_observe
_wf_ordered_cost_record_observe:        ; @wf_ordered_cost_record_observe
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	mov	x19, x0
	mov	x0, x1
	mov	x1, x2
	bl	_wf_ordered_cost_record_content
	ldr	x8, [x19]
	mov	w9, #131                        ; =0x83
	madd	x8, x8, x9, x0
	str	x8, [x19]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_ordered_cost_record_visit
_wf_ordered_cost_record_visit:          ; @wf_ordered_cost_record_visit
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	mov	x19, x0
	mov	x0, x1
	mov	x1, x2
	bl	_wf_ordered_cost_record_content
	ldr	x8, [x19]
	mov	w9, #131                        ; =0x83
	madd	x8, x8, x9, x0
	str	x8, [x19]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_ordered_cost_record_edit
_wf_ordered_cost_record_edit:           ; @wf_ordered_cost_record_edit
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	mov	x19, x0
	mov	w8, #1                          ; =0x1
	dup.2d	v0, x8
	ldp	q1, q2, [x2]
	add.2d	v1, v1, v0
	add.2d	v2, v2, v0
	stp	q1, q2, [x2]
	ldp	q1, q2, [x2, #32]
	add.2d	v1, v1, v0
	add.2d	v2, v2, v0
	stp	q1, q2, [x2, #32]
	ldp	q1, q2, [x2, #64]
	add.2d	v1, v1, v0
	add.2d	v2, v2, v0
	stp	q1, q2, [x2, #64]
	ldp	q1, q2, [x2, #96]
	add.2d	v1, v1, v0
	add.2d	v2, v2, v0
	stp	q1, q2, [x2, #96]
	ldp	q1, q2, [x2, #128]
	add.2d	v1, v1, v0
	add.2d	v2, v2, v0
	stp	q1, q2, [x2, #128]
	ldp	q1, q2, [x2, #160]
	add.2d	v1, v1, v0
	add.2d	v2, v2, v0
	stp	q1, q2, [x2, #160]
	ldp	q1, q2, [x2, #192]
	add.2d	v1, v1, v0
	add.2d	v2, v2, v0
	stp	q1, q2, [x2, #192]
	ldp	q1, q2, [x2, #224]
	add.2d	v1, v1, v0
	add.2d	v0, v2, v0
	stp	q1, q0, [x2, #224]
	mov	x0, x1
	mov	x1, x2
	bl	_wf_ordered_cost_record_content
	ldr	x8, [x19]
	mov	w9, #131                        ; =0x83
	madd	x8, x8, x9, x0
	str	x8, [x19]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_ordered_cost_record_consume
_wf_ordered_cost_record_consume:        ; @wf_ordered_cost_record_consume
; %bb.0:                                ; %entry
	ldp	x9, x10, [x2]
	mov	w8, #131                        ; =0x83
	madd	x9, x1, x8, x9
	madd	x9, x9, x8, x10
	ldp	x10, x11, [x2, #16]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #32]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #48]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #64]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #80]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #96]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #112]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #128]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #144]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #160]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #176]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #192]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #208]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #224]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #240]
	madd	x9, x9, x8, x10
	madd	x8, x9, x8, x11
	ldp	x9, x10, [x0, #8]
	add	x9, x8, x9
	eor	x8, x8, x8, lsr #30
	mov	x11, #58809                     ; =0xe5b9
	movk	x11, #7396, lsl #16
	movk	x11, #18285, lsl #32
	movk	x11, #48984, lsl #48
	mul	x8, x8, x11
	eor	x8, x8, x8, lsr #27
	mov	x11, #4587                      ; =0x11eb
	movk	x11, #4913, lsl #16
	movk	x11, #18875, lsl #32
	movk	x11, #38096, lsl #48
	mul	x8, x8, x11
	eor	x10, x10, x8, lsr #31
	eor	x8, x10, x8
	stp	x9, x8, [x0, #8]
	ldr	x8, [x0, #24]
	add	x8, x8, #1
	str	x8, [x0, #24]
	ret
                                        ; -- End function
	.globl	_wf_ordered_cost_word_trace     ; -- Begin function wf_ordered_cost_word_trace
	.p2align	2
_wf_ordered_cost_word_trace:            ; @wf_ordered_cost_word_trace
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #480
	stp	x28, x27, [sp, #384]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #400]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #416]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #432]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #448]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #464]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 480
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x3
	mov	x23, x2
	str	x1, [sp, #16]                   ; 8-byte Folded Spill
	mov	x21, x0
	add	x25, sp, #40
	add	x19, x25, #280
	bl	_wf_std.collections.ordered_map.ordered_map_new$instance$e85fc351f8333b14
	stp	x0, x1, [sp, #288]
	str	x2, [sp, #304]
	strb	wzr, [sp, #312]
	stp	x23, xzr, [sp, #320]
	stp	xzr, xzr, [sp, #336]
	cbz	x21, LBB11_31
; %bb.1:                                ; %bb4.preheader.i
	mov	x22, #0                         ; =0x0
	mov	w26, #1                         ; =0x1
	mov	w27, #131                       ; =0x83
	mov	x24, x23
	mov	x28, x21
	b	LBB11_4
LBB11_2:                                ; %bb3.i.i
                                        ;   in Loop: Header=BB11_4 Depth=1
	ldp	x1, x2, [sp, #48]
	ldrb	w8, [sp, #44]
	ldr	x9, [sp, #320]
	tst	w8, #0x1
	cinc	x8, x26, ne
	madd	x8, x9, x27, x8
	str	x8, [sp, #320]
	mov	x0, x19
	bl	_wf_ordered_cost_word_consume
LBB11_3:                                ; %"wf_ordered_cost_put_result$instance$fa3caca27a003293.exit.i"
                                        ;   in Loop: Header=BB11_4 Depth=1
	add	x24, x24, #1
	add	x22, x22, #73
	subs	x28, x28, #1
	b.eq	LBB11_6
LBB11_4:                                ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	udiv	x8, x22, x21
	msub	x8, x8, x21, x22
	orr	x2, x26, x8, lsl #1
	add	x0, sp, #40
	add	x1, x25, #248
	mov	x3, x24
	bl	_wf_std.collections.ordered_map.ordered_map_put$instance$c2a7dc263c55706f
	ldr	w8, [sp, #40]
	cbnz	w8, LBB11_2
; %bb.5:                                ; %bb2.i.i
                                        ;   in Loop: Header=BB11_4 Depth=1
	ldr	x8, [sp, #320]
	mul	x8, x8, x27
	str	x8, [sp, #320]
	b	LBB11_3
LBB11_6:                                ; %bb7.i
	add	x0, x25, #248
	bl	_wf_std.collections.ordered_map.ordered_map_len$instance$e85fc351f8333b14
	ldr	x8, [sp, #320]
	mov	w9, #131                        ; =0x83
	madd	x22, x8, x9, x0
	str	x22, [sp, #320]
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	cbz	x8, LBB11_32
; %bb.7:                                ; %bb13.preheader.lr.ph.i
	mov	x9, #0                          ; =0x0
	add	x23, x23, x21
	lsl	x8, x21, #1
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	w28, #131                       ; =0x83
	mov	x27, x23
	b	LBB11_9
LBB11_8:                                ; %bb30.i
                                        ;   in Loop: Header=BB11_9 Depth=1
	ldp	x23, x9, [sp, #24]              ; 16-byte Folded Reload
	add	x9, x9, #1
	ldp	x10, x8, [sp, #8]               ; 16-byte Folded Reload
	add	x27, x27, x10
	add	x23, x23, x21
	cmp	x9, x8
	b.eq	LBB11_30
LBB11_9:                                ; %bb13.preheader.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB11_12 Depth 2
	stp	x23, x9, [sp, #24]              ; 16-byte Folded Spill
	mov	x26, #0                         ; =0x0
	mov	x22, x21
	mov	x24, x27
	b	LBB11_12
LBB11_10:                               ; %bb24.i
                                        ;   in Loop: Header=BB11_12 Depth=2
	add	x8, x8, #32
	str	x8, [sp, #376]
	add	x0, x25, #248
	add	x1, x25, #312
	add	x2, x25, #336
	mov	x3, x19
	bl	_wf_std.collections.ordered_map.ordered_map_range$instance$3d3b1c83ce351b3d
LBB11_11:                               ; %bb29.i
                                        ;   in Loop: Header=BB11_12 Depth=2
	add	x24, x24, #2
	add	x23, x23, #1
	add	x26, x26, #73
	subs	x22, x22, #1
	b.eq	LBB11_8
LBB11_12:                               ; %bb14.i
                                        ;   Parent Loop BB11_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	udiv	x8, x26, x21
	msub	x9, x8, x21, x26
	lsl	x8, x9, #1
	mov	w2, #1                          ; =0x1
	bfi	x2, x9, #1, #63
	stp	x8, x2, [sp, #352]
	cmp	x20, #2
	b.gt	LBB11_17
; %bb.13:                               ; %bb14.i
                                        ;   in Loop: Header=BB11_12 Depth=2
	cmp	x20, #1
	b.eq	LBB11_21
; %bb.14:                               ; %bb14.i
                                        ;   in Loop: Header=BB11_12 Depth=2
	cmp	x20, #2
	b.ne	LBB11_11
; %bb.15:                               ; %bb21.i
                                        ;   in Loop: Header=BB11_12 Depth=2
	add	x0, x25, #72
	add	x1, x25, #248
	mov	x3, x24
	bl	_wf_std.collections.ordered_map.ordered_map_put$instance$c2a7dc263c55706f
	ldr	w8, [sp, #112]
	cbz	w8, LBB11_22
; %bb.16:                               ; %bb3.i33.i
                                        ;   in Loop: Header=BB11_12 Depth=2
	ldp	x1, x2, [sp, #120]
	ldrb	w8, [sp, #116]
	ldr	x9, [sp, #320]
	tst	w8, #0x1
	mov	w8, #1                          ; =0x1
	cinc	x8, x8, ne
	madd	x8, x9, x28, x8
	str	x8, [sp, #320]
	mov	x0, x19
	bl	_wf_ordered_cost_word_consume
	b	LBB11_23
LBB11_17:                               ; %bb14.i
                                        ;   in Loop: Header=BB11_12 Depth=2
	cmp	x20, #3
	b.eq	LBB11_10
; %bb.18:                               ; %bb14.i
                                        ;   in Loop: Header=BB11_12 Depth=2
	cmp	x20, #4
	b.ne	LBB11_11
; %bb.19:                               ; %bb27.i
                                        ;   in Loop: Header=BB11_12 Depth=2
	add	x0, x25, #168
	add	x1, x25, #248
	mov	x3, x23
	bl	_wf_std.collections.ordered_map.ordered_map_put$instance$c2a7dc263c55706f
	ldr	w8, [sp, #208]
	cbz	w8, LBB11_29
; %bb.20:                               ; %bb3.i83.i
                                        ;   in Loop: Header=BB11_12 Depth=2
	ldp	x1, x2, [sp, #216]
	ldrb	w8, [sp, #212]
	b	LBB11_28
LBB11_21:                               ; %bb18.i
                                        ;   in Loop: Header=BB11_12 Depth=2
	add	x0, x25, #248
	add	x1, x25, #320
	mov	x2, x19
	bl	_wf_std.collections.ordered_map.ordered_map_lookup$instance$107186e54bef911a
	str	w0, [sp, #64]
	str	x1, [sp, #72]
	strb	w2, [sp, #80]
	cmp	w0, #0
	ldr	x8, [sp, #320]
	ldr	x9, [sp, #360]
	mul	x8, x8, x28
	cinc	x8, x8, eq
	sub	x9, x9, #1
	str	x8, [sp, #320]
	str	x9, [sp, #368]
	add	x0, x25, #248
	add	x1, x25, #328
	mov	x2, x19
	bl	_wf_std.collections.ordered_map.ordered_map_lookup$instance$107186e54bef911a
	str	w0, [sp, #88]
	str	x1, [sp, #96]
	strb	w2, [sp, #104]
	cmp	w0, #0
	ldr	x8, [sp, #320]
	mul	x8, x8, x28
	cinc	x8, x8, eq
	str	x8, [sp, #320]
	b	LBB11_11
LBB11_22:                               ; %bb2.i44.i
                                        ;   in Loop: Header=BB11_12 Depth=2
	ldr	x8, [sp, #320]
	mul	x8, x8, x28
	str	x8, [sp, #320]
LBB11_23:                               ; %"wf_ordered_cost_put_result$instance$fa3caca27a003293.exit47.i"
                                        ;   in Loop: Header=BB11_12 Depth=2
	add	x0, x25, #248
	add	x1, x25, #320
	mov	x2, x19
	bl	_wf_std.collections.ordered_map.ordered_map_edit$instance$2c340453a2bb7cf7
	str	w0, [sp, #136]
	str	x1, [sp, #144]
	strb	w2, [sp, #152]
	cmp	w0, #0
	ldr	x8, [sp, #320]
	mul	x8, x8, x28
	cinc	x8, x8, eq
	str	x8, [sp, #320]
	add	x0, x25, #248
	add	x1, x25, #320
	bl	_wf_std.collections.ordered_map.ordered_map_remove$instance$c2a7dc263c55706f
	str	w0, [sp, #160]
	stp	x1, x2, [sp, #168]
	ldr	x8, [sp, #320]
	mul	x8, x8, x28
	cmp	w0, #1
	b.ne	LBB11_25
; %bb.24:                               ; %bb2.i58.i
                                        ;   in Loop: Header=BB11_12 Depth=2
	add	x8, x8, #1
	str	x8, [sp, #320]
	mov	x0, x19
	bl	_wf_ordered_cost_word_consume
	b	LBB11_26
LBB11_25:                               ; %bb3.i56.i
                                        ;   in Loop: Header=BB11_12 Depth=2
	str	x8, [sp, #320]
LBB11_26:                               ; %"wf_ordered_cost_taken_result$instance$fa3caca27a003293.exit.i"
                                        ;   in Loop: Header=BB11_12 Depth=2
	ldr	x2, [sp, #360]
	add	x0, x25, #144
	add	x1, x25, #248
	add	x3, x24, #1
	bl	_wf_std.collections.ordered_map.ordered_map_put$instance$c2a7dc263c55706f
	ldr	w8, [sp, #184]
	cbz	w8, LBB11_29
; %bb.27:                               ; %bb3.i66.i
                                        ;   in Loop: Header=BB11_12 Depth=2
	ldp	x1, x2, [sp, #192]
	ldrb	w8, [sp, #188]
LBB11_28:                               ; %bb29.i
                                        ;   in Loop: Header=BB11_12 Depth=2
	ldr	x9, [sp, #320]
	tst	w8, #0x1
	mov	w8, #1                          ; =0x1
	cinc	x8, x8, ne
	madd	x8, x9, x28, x8
	str	x8, [sp, #320]
	mov	x0, x19
	bl	_wf_ordered_cost_word_consume
	b	LBB11_11
LBB11_29:                               ; %bb2.i77.i
                                        ;   in Loop: Header=BB11_12 Depth=2
	ldr	x8, [sp, #320]
	mul	x8, x8, x28
	str	x8, [sp, #320]
	b	LBB11_11
LBB11_30:                               ; %bb1.loopexit.i
	ldr	x22, [sp, #320]
	b	LBB11_32
LBB11_31:                               ; %bb3.i
	add	x0, x25, #248
	bl	_wf_std.collections.ordered_map.ordered_map_len$instance$e85fc351f8333b14
	mov	w8, #131                        ; =0x83
	madd	x22, x23, x8, x0
	str	x22, [sp, #320]
LBB11_32:                               ; %"wf_ordered_cost_trace$instance$fa3caca27a003293.exit"
	add	x20, sp, #40
	add	x0, x25, #248
	bl	_wf_std.collections.ordered_map.ordered_map_len$instance$e85fc351f8333b14
	mov	w8, #131                        ; =0x83
	madd	x8, x22, x8, x0
	str	x8, [sp, #320]
	add	x0, x25, #248
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_each$instance$341ef9419761ecf9
	ldur	q0, [x25, #248]
	stur	q0, [sp, #232]
	ldr	x8, [x25, #264]
	str	x8, [sp, #248]
	add	x0, x20, #192
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_free$instance$5b3375fb2964755f
	ldp	q0, q1, [x19]
	stur	q0, [x25, #216]
	stur	q1, [x25, #232]
	ldp	x8, x9, [sp, #256]
	ldp	x10, x11, [sp, #272]
	eor	x8, x8, x8, lsr #30
	mov	x12, #58809                     ; =0xe5b9
	movk	x12, #7396, lsl #16
	movk	x12, #18285, lsl #32
	movk	x12, #48984, lsl #48
	mul	x8, x8, x12
	eor	x8, x8, x8, lsr #27
	mov	x13, #4587                      ; =0x11eb
	movk	x13, #4913, lsl #16
	movk	x13, #18875, lsl #32
	movk	x13, #38096, lsl #48
	mul	x8, x8, x13
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x12
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x13
	eor	x12, x9, x8
	mov	x13, #31765                     ; =0x7c15
	movk	x13, #32586, lsl #16
	movk	x13, #31161, lsl #32
	movk	x13, #40503, lsl #48
	mul	x11, x11, x13
	eor	x10, x10, x11
	eor	x10, x10, x12, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	ldp	x29, x30, [sp, #464]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #448]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #432]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #416]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #400]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #384]            ; 16-byte Folded Reload
	add	sp, sp, #480
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_ordered_cost_record_trace   ; -- Begin function wf_ordered_cost_record_trace
	.p2align	2
_wf_ordered_cost_record_trace:          ; @wf_ordered_cost_record_trace
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #2960
	.cfi_def_cfa_offset 3056
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x21, x3
	mov	x25, x2
	str	x1, [sp, #16]                   ; 8-byte Folded Spill
	mov	x27, x0
	add	x8, sp, #96
	add	x20, x8, #2512
	add	x28, x8, #2544
	bl	_wf_std.collections.ordered_map.ordered_map_new$instance$a36c254d11d20619
	str	x0, [sp, #2608]
	str	x1, [sp, #2616]
	str	x2, [sp, #2624]
	strb	wzr, [sp, #2632]
	str	x25, [sp, #2640]
	str	xzr, [sp, #2648]
	str	xzr, [sp, #2664]
	str	xzr, [sp, #2656]
	cbz	x27, LBB12_31
; %bb.1:                                ; %bb4.preheader.i
	str	x20, [sp, #88]                  ; 8-byte Folded Spill
	mov	x19, #0                         ; =0x0
	mov	w20, #1                         ; =0x1
	mov	w22, #131                       ; =0x83
	str	x25, [sp, #72]                  ; 8-byte Folded Spill
	mov	x23, x27
	b	LBB12_4
LBB12_2:                                ; %bb3.i.i
                                        ;   in Loop: Header=BB12_4 Depth=1
	ldrb	w8, [sp, #356]
	ldr	x1, [sp, #360]
	ldr	x9, [sp, #2640]
	tst	w8, #0x1
	cinc	x8, x20, ne
	madd	x8, x9, x22, x8
	str	x8, [sp, #2640]
	ldp	q0, q1, [x24, #464]
	str	q0, [sp, #2896]
	str	q1, [sp, #2912]
	ldp	q0, q1, [x24, #496]
	str	q0, [sp, #2928]
	str	q1, [sp, #2944]
	ldp	q0, q1, [x24, #400]
	str	q0, [sp, #2832]
	str	q1, [sp, #2848]
	ldp	q0, q1, [x24, #432]
	str	q0, [sp, #2864]
	str	q1, [sp, #2880]
	ldp	q0, q1, [x24, #336]
	str	q0, [sp, #2768]
	str	q1, [sp, #2784]
	ldp	q0, q1, [x24, #368]
	str	q0, [sp, #2800]
	str	q1, [sp, #2816]
	ldp	q0, q1, [x24, #272]
	str	q0, [sp, #2704]
	str	q1, [sp, #2720]
	ldp	q0, q1, [x24, #304]
	str	q0, [sp, #2736]
	str	q1, [sp, #2752]
	add	x2, sp, #2704
	mov	x0, x28
	bl	_wf_ordered_cost_record_consume
LBB12_3:                                ; %"wf_ordered_cost_put_result$instance$ff5e39efec5d08ee.exit.i"
                                        ;   in Loop: Header=BB12_4 Depth=1
	add	x25, x25, #1
	add	x19, x19, #73
	subs	x23, x23, #1
	b.eq	LBB12_6
LBB12_4:                                ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	udiv	x8, x19, x27
	msub	x8, x8, x27, x19
	orr	x26, x20, x8, lsl #1
	add	x0, sp, #96
	mov	x1, x25
	bl	_wf_ordered_cost_record_make
	add	x24, sp, #96
	add	x0, x24, #256
	add	x3, sp, #96
	ldr	x1, [sp, #88]                   ; 8-byte Folded Reload
	mov	x2, x26
	bl	_wf_std.collections.ordered_map.ordered_map_put$instance$912c4c551bcb3786
	ldr	w8, [sp, #352]
	cbnz	w8, LBB12_2
; %bb.5:                                ; %bb2.i.i
                                        ;   in Loop: Header=BB12_4 Depth=1
	ldr	x8, [sp, #2640]
	mul	x8, x8, x22
	str	x8, [sp, #2640]
	b	LBB12_3
LBB12_6:                                ; %bb7.i
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	bl	_wf_std.collections.ordered_map.ordered_map_len$instance$a36c254d11d20619
	ldr	x8, [sp, #2640]
	mov	w9, #131                        ; =0x83
	madd	x19, x8, x9, x0
	str	x19, [sp, #2640]
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	cbz	x8, LBB12_32
; %bb.7:                                ; %bb13.preheader.lr.ph.i
	str	x28, [sp, #80]                  ; 8-byte Folded Spill
	mov	x9, #0                          ; =0x0
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	add	x24, x8, x27
	add	x8, sp, #96
	add	x11, x8, #2200
	add	x10, x8, #848
	stp	x10, x11, [sp, #56]             ; 16-byte Folded Spill
	add	x10, x8, #1144
	str	x10, [sp, #48]                  ; 8-byte Folded Spill
	add	x19, x8, #1672
	lsl	x8, x27, #1
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	w22, #131                       ; =0x83
	mov	x25, x24
	ldr	x28, [sp, #88]                  ; 8-byte Folded Reload
	str	x27, [sp, #72]                  ; 8-byte Folded Spill
	b	LBB12_9
LBB12_8:                                ; %bb30.i
                                        ;   in Loop: Header=BB12_9 Depth=1
	ldp	x24, x9, [sp, #32]              ; 16-byte Folded Reload
	add	x9, x9, #1
	ldp	x10, x8, [sp, #8]               ; 16-byte Folded Reload
	ldr	x25, [sp, #24]                  ; 8-byte Folded Reload
	add	x25, x25, x10
	add	x24, x24, x27
	cmp	x9, x8
	b.eq	LBB12_30
LBB12_9:                                ; %bb13.preheader.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB12_12 Depth 2
	stp	x24, x9, [sp, #32]              ; 16-byte Folded Spill
	mov	x20, #0                         ; =0x0
	mov	x23, x27
	str	x25, [sp, #24]                  ; 8-byte Folded Spill
	b	LBB12_12
LBB12_10:                               ; %bb24.i
                                        ;   in Loop: Header=BB12_12 Depth=2
	add	x8, x8, #32
	str	x8, [sp, #2696]
	add	x8, sp, #96
	add	x1, x8, #2576
	add	x2, x8, #2600
	mov	x0, x28
	ldr	x3, [sp, #80]                   ; 8-byte Folded Reload
	bl	_wf_std.collections.ordered_map.ordered_map_range$instance$e886f4eb776d75c0
LBB12_11:                               ; %bb29.i
                                        ;   in Loop: Header=BB12_12 Depth=2
	add	x25, x25, #2
	add	x24, x24, #1
	add	x20, x20, #73
	subs	x23, x23, #1
	b.eq	LBB12_8
LBB12_12:                               ; %bb14.i
                                        ;   Parent Loop BB12_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	udiv	x8, x20, x27
	msub	x9, x8, x27, x20
	lsl	x8, x9, #1
	str	x8, [sp, #2672]
	mov	w10, #1                         ; =0x1
	bfi	x10, x9, #1, #63
	str	x10, [sp, #2680]
	cmp	x21, #2
	b.gt	LBB12_17
; %bb.13:                               ; %bb14.i
                                        ;   in Loop: Header=BB12_12 Depth=2
	cmp	x21, #1
	b.eq	LBB12_21
; %bb.14:                               ; %bb14.i
                                        ;   in Loop: Header=BB12_12 Depth=2
	cmp	x21, #2
	b.ne	LBB12_11
; %bb.15:                               ; %bb21.i
                                        ;   in Loop: Header=BB12_12 Depth=2
	add	x27, sp, #96
	add	x0, x27, #576
	mov	x1, x25
	bl	_wf_ordered_cost_record_make
	ldr	x2, [sp, #2680]
	add	x0, x27, #832
	add	x3, x27, #576
	mov	x1, x28
	bl	_wf_std.collections.ordered_map.ordered_map_put$instance$912c4c551bcb3786
	ldr	w8, [sp, #928]
	cbz	w8, LBB12_22
; %bb.16:                               ; %bb3.i33.i
                                        ;   in Loop: Header=BB12_12 Depth=2
	ldr	x1, [sp, #936]
	ldrb	w8, [sp, #932]
	ldr	x9, [sp, #2640]
	tst	w8, #0x1
	mov	w8, #1                          ; =0x1
	cinc	x8, x8, ne
	madd	x8, x9, x22, x8
	str	x8, [sp, #2640]
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	ldp	q0, q1, [x8, #192]
	str	q0, [sp, #2896]
	str	q1, [sp, #2912]
	ldp	q0, q1, [x8, #224]
	str	q0, [sp, #2928]
	str	q1, [sp, #2944]
	ldp	q0, q1, [x8, #128]
	str	q0, [sp, #2832]
	str	q1, [sp, #2848]
	ldp	q0, q1, [x8, #160]
	str	q0, [sp, #2864]
	str	q1, [sp, #2880]
	ldp	q0, q1, [x8, #64]
	str	q0, [sp, #2768]
	str	q1, [sp, #2784]
	ldp	q0, q1, [x8, #96]
	str	q0, [sp, #2800]
	str	q1, [sp, #2816]
	ldp	q0, q1, [x8]
	str	q0, [sp, #2704]
	str	q1, [sp, #2720]
	ldp	q0, q1, [x8, #32]
	str	q0, [sp, #2736]
	str	q1, [sp, #2752]
	add	x2, sp, #2704
	ldr	x28, [sp, #80]                  ; 8-byte Folded Reload
	mov	x0, x28
	bl	_wf_ordered_cost_record_consume
	b	LBB12_23
LBB12_17:                               ; %bb14.i
                                        ;   in Loop: Header=BB12_12 Depth=2
	cmp	x21, #3
	b.eq	LBB12_10
; %bb.18:                               ; %bb14.i
                                        ;   in Loop: Header=BB12_12 Depth=2
	cmp	x21, #4
	b.ne	LBB12_11
; %bb.19:                               ; %bb27.i
                                        ;   in Loop: Header=BB12_12 Depth=2
	add	x22, sp, #96
	add	x0, x22, #1928
	mov	x1, x24
	bl	_wf_ordered_cost_record_make
	ldr	x2, [sp, #2680]
	add	x0, x22, #2184
	add	x3, x22, #1928
	mov	x1, x28
	bl	_wf_std.collections.ordered_map.ordered_map_put$instance$912c4c551bcb3786
	ldr	w8, [sp, #2280]
	cbz	w8, LBB12_29
; %bb.20:                               ; %bb3.i83.i
                                        ;   in Loop: Header=BB12_12 Depth=2
	ldr	x1, [sp, #2288]
	ldrb	w8, [sp, #2284]
	ldr	x9, [sp, #2640]
	tst	w8, #0x1
	mov	w8, #1                          ; =0x1
	cinc	x8, x8, ne
	mov	w22, #131                       ; =0x83
	madd	x8, x9, x22, x8
	str	x8, [sp, #2640]
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	ldp	q0, q1, [x8, #192]
	str	q0, [sp, #2896]
	str	q1, [sp, #2912]
	ldp	q0, q1, [x8, #224]
	str	q0, [sp, #2928]
	str	q1, [sp, #2944]
	ldp	q0, q1, [x8, #128]
	str	q0, [sp, #2832]
	str	q1, [sp, #2848]
	ldp	q0, q1, [x8, #160]
	str	q0, [sp, #2864]
	str	q1, [sp, #2880]
	ldp	q0, q1, [x8, #64]
	str	q0, [sp, #2768]
	str	q1, [sp, #2784]
	ldp	q0, q1, [x8, #96]
	str	q0, [sp, #2800]
	str	q1, [sp, #2816]
	ldp	q0, q1, [x8]
	str	q0, [sp, #2704]
	str	q1, [sp, #2720]
	ldp	q0, q1, [x8, #32]
	b	LBB12_28
LBB12_21:                               ; %bb18.i
                                        ;   in Loop: Header=BB12_12 Depth=2
	mov	w26, #131                       ; =0x83
	add	x22, sp, #96
	add	x1, x22, #2584
	mov	x0, x28
	ldr	x28, [sp, #80]                  ; 8-byte Folded Reload
	mov	x2, x28
	bl	_wf_std.collections.ordered_map.ordered_map_lookup$instance$27c9a7455d5e3844
	str	w0, [sp, #624]
	str	x1, [sp, #632]
	strb	w2, [sp, #640]
	cmp	w0, #0
	ldr	x8, [sp, #2640]
	mul	x8, x8, x26
	cinc	x8, x8, eq
	str	x8, [sp, #2640]
	ldr	x8, [sp, #2680]
	sub	x8, x8, #1
	str	x8, [sp, #2688]
	add	x1, x22, #2592
	mov	w22, #131                       ; =0x83
	ldr	x0, [sp, #88]                   ; 8-byte Folded Reload
	mov	x2, x28
	ldr	x28, [sp, #88]                  ; 8-byte Folded Reload
	bl	_wf_std.collections.ordered_map.ordered_map_lookup$instance$27c9a7455d5e3844
	str	w0, [sp, #648]
	str	x1, [sp, #656]
	strb	w2, [sp, #664]
	cmp	w0, #0
	ldr	x8, [sp, #2640]
	mul	x8, x8, x22
	cinc	x8, x8, eq
	str	x8, [sp, #2640]
	b	LBB12_11
LBB12_22:                               ; %bb2.i43.i
                                        ;   in Loop: Header=BB12_12 Depth=2
	ldr	x8, [sp, #2640]
	mul	x8, x8, x22
	str	x8, [sp, #2640]
	ldr	x28, [sp, #80]                  ; 8-byte Folded Reload
LBB12_23:                               ; %"wf_ordered_cost_put_result$instance$ff5e39efec5d08ee.exit46.i"
                                        ;   in Loop: Header=BB12_12 Depth=2
	mov	w26, #131                       ; =0x83
	add	x1, x27, #2584
	add	x22, sp, #96
	ldr	x27, [sp, #88]                  ; 8-byte Folded Reload
	mov	x0, x27
	mov	x2, x28
	bl	_wf_std.collections.ordered_map.ordered_map_edit$instance$374d92b1aa276be7
	str	w0, [sp, #1200]
	str	x1, [sp, #1208]
	strb	w2, [sp, #1216]
	cmp	w0, #0
	ldr	x8, [sp, #2640]
	mul	x8, x8, x26
	cinc	x8, x8, eq
	str	x8, [sp, #2640]
	add	x0, x22, #1128
	add	x2, x22, #2584
	mov	x1, x27
	bl	_wf_std.collections.ordered_map.ordered_map_remove$instance$912c4c551bcb3786
	ldr	w8, [sp, #1224]
	cmp	w8, #1
	b.ne	LBB12_25
; %bb.24:                               ; %bb2.i58.i
                                        ;   in Loop: Header=BB12_12 Depth=2
	ldr	x1, [sp, #1232]
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	ldp	q0, q1, [x8, #192]
	str	q0, [sp, #2896]
	str	q1, [sp, #2912]
	ldp	q0, q1, [x8, #224]
	str	q0, [sp, #2928]
	str	q1, [sp, #2944]
	ldp	q0, q1, [x8, #128]
	str	q0, [sp, #2832]
	str	q1, [sp, #2848]
	ldp	q0, q1, [x8, #160]
	str	q0, [sp, #2864]
	str	q1, [sp, #2880]
	ldp	q0, q1, [x8, #64]
	str	q0, [sp, #2768]
	str	q1, [sp, #2784]
	ldp	q0, q1, [x8, #96]
	str	q0, [sp, #2800]
	str	q1, [sp, #2816]
	ldp	q0, q1, [x8]
	str	q0, [sp, #2704]
	str	q1, [sp, #2720]
	ldp	q0, q1, [x8, #32]
	str	q0, [sp, #2736]
	str	q1, [sp, #2752]
	ldr	x8, [sp, #2640]
	mov	x9, #1                          ; =0x1
	madd	x8, x8, x26, x9
	str	x8, [sp, #2640]
	add	x2, sp, #2704
	mov	x0, x28
	bl	_wf_ordered_cost_record_consume
	b	LBB12_26
LBB12_25:                               ; %bb3.i56.i
                                        ;   in Loop: Header=BB12_12 Depth=2
	ldr	x8, [sp, #2640]
	mul	x8, x8, x26
	str	x8, [sp, #2640]
LBB12_26:                               ; %"wf_ordered_cost_taken_result$instance$ff5e39efec5d08ee.exit.i"
                                        ;   in Loop: Header=BB12_12 Depth=2
	ldr	x27, [sp, #72]                  ; 8-byte Folded Reload
	add	x22, sp, #96
	add	x0, x22, #1400
	add	x1, x25, #1
	bl	_wf_ordered_cost_record_make
	ldr	x2, [sp, #2680]
	add	x0, x22, #1656
	add	x3, x22, #1400
	ldr	x28, [sp, #88]                  ; 8-byte Folded Reload
	mov	x1, x28
	bl	_wf_std.collections.ordered_map.ordered_map_put$instance$912c4c551bcb3786
	ldr	w8, [sp, #1752]
	cbz	w8, LBB12_29
; %bb.27:                               ; %bb3.i66.i
                                        ;   in Loop: Header=BB12_12 Depth=2
	ldr	x1, [sp, #1760]
	ldrb	w8, [sp, #1756]
	ldr	x9, [sp, #2640]
	tst	w8, #0x1
	mov	w8, #1                          ; =0x1
	cinc	x8, x8, ne
	mov	w22, #131                       ; =0x83
	madd	x8, x9, x22, x8
	str	x8, [sp, #2640]
	ldp	q0, q1, [x19, #192]
	str	q0, [sp, #2896]
	str	q1, [sp, #2912]
	ldp	q0, q1, [x19, #224]
	str	q0, [sp, #2928]
	str	q1, [sp, #2944]
	ldp	q0, q1, [x19, #128]
	str	q0, [sp, #2832]
	str	q1, [sp, #2848]
	ldp	q0, q1, [x19, #160]
	str	q0, [sp, #2864]
	str	q1, [sp, #2880]
	ldp	q0, q1, [x19, #64]
	str	q0, [sp, #2768]
	str	q1, [sp, #2784]
	ldp	q0, q1, [x19, #96]
	str	q0, [sp, #2800]
	str	q1, [sp, #2816]
	ldp	q0, q1, [x19]
	str	q0, [sp, #2704]
	str	q1, [sp, #2720]
	ldp	q0, q1, [x19, #32]
LBB12_28:                               ; %bb29.i
                                        ;   in Loop: Header=BB12_12 Depth=2
	str	q0, [sp, #2736]
	str	q1, [sp, #2752]
	add	x2, sp, #2704
	ldr	x0, [sp, #80]                   ; 8-byte Folded Reload
	bl	_wf_ordered_cost_record_consume
	b	LBB12_11
LBB12_29:                               ; %bb2.i76.i
                                        ;   in Loop: Header=BB12_12 Depth=2
	ldr	x8, [sp, #2640]
	mov	w22, #131                       ; =0x83
	mul	x8, x8, x22
	str	x8, [sp, #2640]
	b	LBB12_11
LBB12_30:                               ; %bb1.loopexit.i
	ldr	x19, [sp, #2640]
	mov	x20, x28
	ldr	x28, [sp, #80]                  ; 8-byte Folded Reload
	b	LBB12_33
LBB12_31:                               ; %bb3.i
	mov	x0, x20
	bl	_wf_std.collections.ordered_map.ordered_map_len$instance$a36c254d11d20619
	mov	w8, #131                        ; =0x83
	madd	x19, x25, x8, x0
	str	x19, [sp, #2640]
	b	LBB12_33
LBB12_32:
	ldr	x20, [sp, #88]                  ; 8-byte Folded Reload
LBB12_33:                               ; %"wf_ordered_cost_trace$instance$ff5e39efec5d08ee.exit"
	add	x8, sp, #96
	add	x21, x8, #2456
	mov	x0, x20
	bl	_wf_std.collections.ordered_map.ordered_map_len$instance$a36c254d11d20619
	mov	w8, #131                        ; =0x83
	madd	x8, x19, x8, x0
	str	x8, [sp, #2640]
	mov	x0, x20
	mov	x1, x28
	bl	_wf_std.collections.ordered_map.ordered_map_each$instance$960d100d77757702
	ldr	q0, [x20]
	str	q0, [x21]
	ldr	x8, [x20, #16]
	str	x8, [sp, #2568]
	mov	x0, x21
	mov	x1, x28
	bl	_wf_std.collections.ordered_map.ordered_map_free$instance$56a8ddd8129b5d48
	ldp	q0, q1, [x28]
	str	q0, [sp, #2576]
	str	q1, [sp, #2592]
	ldr	x8, [sp, #2576]
	ldr	x9, [sp, #2584]
	ldr	x10, [sp, #2592]
	ldr	x11, [sp, #2600]
	eor	x8, x8, x8, lsr #30
	mov	x12, #58809                     ; =0xe5b9
	movk	x12, #7396, lsl #16
	movk	x12, #18285, lsl #32
	movk	x12, #48984, lsl #48
	mul	x8, x8, x12
	eor	x8, x8, x8, lsr #27
	mov	x13, #4587                      ; =0x11eb
	movk	x13, #4913, lsl #16
	movk	x13, #18875, lsl #32
	movk	x13, #38096, lsl #48
	mul	x8, x8, x13
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x12
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x13
	eor	x12, x9, x8
	mov	x13, #31765                     ; =0x7c15
	movk	x13, #32586, lsl #16
	movk	x13, #31161, lsl #32
	movk	x13, #40503, lsl #48
	mul	x11, x11, x13
	eor	x10, x10, x11
	eor	x10, x10, x12, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	add	sp, sp, #2960
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_new$instance$e85fc351f8333b14
_wf_std.collections.ordered_map.ordered_map_new$instance$e85fc351f8333b14: ; @"wf_std.collections.ordered_map.ordered_map_new$instance$e85fc351f8333b14"
; %bb.0:                                ; %entry
	mov	x0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_put$instance$c2a7dc263c55706f
_wf_std.collections.ordered_map.ordered_map_put$instance$c2a7dc263c55706f: ; @"wf_std.collections.ordered_map.ordered_map_put$instance$c2a7dc263c55706f"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #176
	stp	x26, x25, [sp, #96]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #112]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 176
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x20, x1
	mov	x19, x0
	stp	x2, x3, [sp, #16]
	ldr	x22, [x1]
	cbz	x22, LBB14_14
; %bb.1:                                ; %bb2
	add	x8, x20, #8
	b	LBB14_4
LBB14_2:                                ; %bb2.i
                                        ;   in Loop: Header=BB14_4 Depth=1
	cbz	x25, LBB14_12
LBB14_3:                                ; %bb10.i
                                        ;   in Loop: Header=BB14_4 Depth=1
	add	x8, x24, x25, lsl #5
	ldur	x9, [x8, #-8]
	cbz	x9, LBB14_14
LBB14_4:                                ; %bb1.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB14_6 Depth 2
	ldr	x23, [x8]
	mov	x24, x23
	ldr	x26, [x24, #16]!
	cbz	x26, LBB14_9
; %bb.5:                                ; %bb2.lr.ph.i.i.i.i
                                        ;   in Loop: Header=BB14_4 Depth=1
	mov	x25, #0                         ; =0x0
	add	x21, x23, #24
LBB14_6:                                ; %bb2.i.i.i.i
                                        ;   Parent Loop BB14_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x0, sp, #16
	mov	x1, x21
	bl	_wf_ordered_cost_compare
	cmp	w0, #1
	b.lt	LBB14_10
; %bb.7:                                ; %bb8.i.i.i.i
                                        ;   in Loop: Header=BB14_6 Depth=2
	add	x25, x25, #1
	add	x21, x21, #32
	cmp	x26, x25
	b.ne	LBB14_6
; %bb.8:                                ;   in Loop: Header=BB14_4 Depth=1
	mov	x25, x26
	b	LBB14_3
LBB14_9:                                ;   in Loop: Header=BB14_4 Depth=1
	mov	x25, #0                         ; =0x0
LBB14_10:                               ; %"wf_std.collections.ordered_map.ordered_map_search$instance$5046b787ff5cdb3f.exit.i"
                                        ;   in Loop: Header=BB14_4 Depth=1
	cmp	x25, x26
	b.hs	LBB14_2
; %bb.11:                               ; %bb3.i
                                        ;   in Loop: Header=BB14_4 Depth=1
	add	x21, x24, x25, lsl #5
	add	x0, sp, #16
	add	x1, x21, #8
	bl	_wf_ordered_cost_compare
	cbnz	w0, LBB14_2
	b	LBB14_19
LBB14_12:                               ; %bb9.i
                                        ;   in Loop: Header=BB14_4 Depth=1
	ldr	x8, [x23]
	cbz	x8, LBB14_14
; %bb.13:                               ; %bb12.i
                                        ;   in Loop: Header=BB14_4 Depth=1
	add	x8, x23, #8
	b	LBB14_4
LBB14_14:                               ; %bb1
	ldr	x21, [x20, #16]
	lsr	x8, x21, #13
	cbz	x8, LBB14_16
; %bb.15:                               ; %bb8
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	strb	w8, [x19, #4]
	ldr	q0, [sp, #16]
	b	LBB14_20
LBB14_16:                               ; %bb9
	add	x0, sp, #40
	add	x2, sp, #16
	mov	x1, x20
	bl	_wf_std.collections.ordered_map.ordered_map_insert_link$instance$5046b787ff5cdb3f
	ldr	w8, [sp, #40]
	cbz	w8, LBB14_23
; %bb.17:                               ; %bb12
	ldp	x21, x23, [sp, #48]
	ldp	x24, x25, [sp, #64]
	str	xzr, [sp, #8]
	cbz	x22, LBB14_21
; %bb.18:                               ; %run.move.body.v3.preheader.i
	lsl	x2, x22, #3
	add	x0, sp, #8
	add	x1, x20, #8
	bl	_memcpy
	ldr	x26, [sp, #8]
	b	LBB14_22
LBB14_19:                               ; %bb6.i
	ldur	q0, [x21, #8]
	ldr	q1, [sp, #16]
	stur	q1, [x21, #8]
	str	q0, [sp, #16]
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
LBB14_20:                               ; %common.ret
	stur	q0, [x19, #8]
	b	LBB14_24
LBB14_21:
	mov	x26, #0                         ; =0x0
LBB14_22:                               ; %"wf_append$instance$48c61fa9751a6936.exit"
	str	xzr, [x20]
	mov	w0, #504                        ; =0x1f8
	bl	_wf_cost_allocate
	stp	x22, x26, [x0]
	mov	w8, #1                          ; =0x1
	stp	x8, x21, [x0, #16]
	stp	x23, x24, [x0, #32]
	str	x25, [x0, #48]
	movi.2d	v0, #0000000000000000
	stur	q0, [x0, #72]
	stur	q0, [x0, #88]
	stur	q0, [x0, #104]
	stur	q0, [x0, #120]
	stur	q0, [x0, #136]
	stur	q0, [x0, #152]
	stur	q0, [x0, #168]
	stur	q0, [x0, #184]
	stur	q0, [x0, #200]
	stur	q0, [x0, #216]
	stur	q0, [x0, #232]
	stur	q0, [x0, #248]
	mov	x9, x0
	str	q0, [x9, #56]!
	stp	q0, q0, [x9, #208]
	stp	q0, q0, [x9, #240]
	stp	q0, q0, [x9, #272]
	stp	q0, q0, [x9, #304]
	stp	q0, q0, [x9, #336]
	stp	q0, q0, [x9, #368]
	stp	q0, q0, [x9, #400]
	str	q0, [x9, #432]
	stp	x8, x0, [x20]
	ldr	x21, [x20, #16]
LBB14_23:                               ; %bb10
	add	x8, x21, #1
	str	x8, [x20, #16]
	stp	xzr, xzr, [x19, #8]
	str	xzr, [x19]
LBB14_24:                               ; %common.ret
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #144]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_len$instance$e85fc351f8333b14
_wf_std.collections.ordered_map.ordered_map_len$instance$e85fc351f8333b14: ; @"wf_std.collections.ordered_map.ordered_map_len$instance$e85fc351f8333b14"
; %bb.0:                                ; %entry
	ldr	x0, [x0, #16]
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_lookup$instance$107186e54bef911a
_wf_std.collections.ordered_map.ordered_map_lookup$instance$107186e54bef911a: ; @"wf_std.collections.ordered_map.ordered_map_lookup$instance$107186e54bef911a"
; %bb.0:                                ; %entry
	b	_wf_std.collections.ordered_map.ordered_map_lookup_link$instance$11eb30e8dabe0f7e
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_edit$instance$2c340453a2bb7cf7
_wf_std.collections.ordered_map.ordered_map_edit$instance$2c340453a2bb7cf7: ; @"wf_std.collections.ordered_map.ordered_map_edit$instance$2c340453a2bb7cf7"
; %bb.0:                                ; %entry
	b	_wf_std.collections.ordered_map.ordered_map_edit_link$instance$41f33845185638b6
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_remove$instance$c2a7dc263c55706f
_wf_std.collections.ordered_map.ordered_map_remove$instance$c2a7dc263c55706f: ; @"wf_std.collections.ordered_map.ordered_map_remove$instance$c2a7dc263c55706f"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #96
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 96
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x0
	bl	_wf_std.collections.ordered_map.ordered_map_remove_link$instance$5046b787ff5cdb3f
	cbz	w0, LBB18_10
; %bb.1:                                ; %bb2.i
	ldr	x8, [x19]
	cbz	x8, LBB18_7
; %bb.2:                                ; %bb2.i.i
	sub	x20, x8, #1
	add	x23, x19, x20, lsl #3
	str	x20, [x19]
	ldr	x0, [x23, #8]
	ldr	x9, [x0, #16]
	cbnz	x9, LBB18_6
; %bb.3:                                ; %bb5.i.i
	mov	x21, x2
	mov	x22, x1
	ldp	x24, x25, [x0]
	bl	_wf_cost_release
	str	x25, [sp, #8]
	cbz	x24, LBB18_5
; %bb.4:                                ; %run.move.body.v3.preheader.i.i.i
	lsl	x2, x24, #3
	add	x0, x23, #8
	add	x1, sp, #8
	bl	_memcpy
LBB18_5:                                ; %"wf_append$instance$48c61fa9751a6936.exit.i.i"
	add	x8, x24, x20
	mov	x1, x22
	mov	x2, x21
LBB18_6:                                ; %bb1.sink.split.i.i
	str	x8, [x19]
LBB18_7:                                ; %"wf_std.collections.ordered_map.ordered_map_contract_root$instance$0ed342445dd803f3.exit.i"
	ldr	x8, [x19, #16]
	cbz	x8, LBB18_9
; %bb.8:                                ; %bb4.i
	sub	x8, x8, #1
	str	x8, [x19, #16]
LBB18_9:                                ; %"wf_std.collections.ordered_map.ordered_map_remove$instance$c2a7dc263c55706f.body.exit"
	mov	w0, #1                          ; =0x1
	b	LBB18_11
LBB18_10:
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
LBB18_11:                               ; %"wf_std.collections.ordered_map.ordered_map_remove$instance$c2a7dc263c55706f.body.exit"
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_range$instance$3d3b1c83ce351b3d
_wf_std.collections.ordered_map.ordered_map_range$instance$3d3b1c83ce351b3d: ; @"wf_std.collections.ordered_map.ordered_map_range$instance$3d3b1c83ce351b3d"
; %bb.0:                                ; %entry
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x1
	mov	x22, x0
	mov	x0, x1
	mov	x1, x2
	bl	_wf_ordered_cost_compare
	tbnz	w0, #31, LBB19_2
; %bb.1:                                ; %bb1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB19_2:                                ; %bb2
	mov	x0, x22
	mov	x1, x21
	mov	x2, x20
	mov	x3, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_wf_std.collections.ordered_map.ordered_map_range_link$instance$171ecc1fc526bab5
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_each$instance$341ef9419761ecf9
_wf_std.collections.ordered_map.ordered_map_each$instance$341ef9419761ecf9: ; @"wf_std.collections.ordered_map.ordered_map_each$instance$341ef9419761ecf9"
; %bb.0:                                ; %entry
	b	_wf_std.collections.ordered_map.ordered_map_each_link$instance$5fa8e8b3d971a72b
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_free$instance$5b3375fb2964755f
_wf_std.collections.ordered_map.ordered_map_free$instance$5b3375fb2964755f: ; @"wf_std.collections.ordered_map.ordered_map_free$instance$5b3375fb2964755f"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	q0, [x0]
	str	q0, [sp]
	mov	x0, sp
	bl	_wf_std.collections.ordered_map.ordered_map_free_link$instance$a14f6fad6bd909bd
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_new$instance$a36c254d11d20619
_wf_std.collections.ordered_map.ordered_map_new$instance$a36c254d11d20619: ; @"wf_std.collections.ordered_map.ordered_map_new$instance$a36c254d11d20619"
; %bb.0:                                ; %entry
	mov	x0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_put$instance$912c4c551bcb3786
_wf_std.collections.ordered_map.ordered_map_put$instance$912c4c551bcb3786: ; @"wf_std.collections.ordered_map.ordered_map_put$instance$912c4c551bcb3786"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #1088
	.cfi_def_cfa_offset 1184
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x1
	mov	x19, x0
	ldp	q0, q1, [x3, #192]
	add	x8, sp, #272
	stur	q0, [x8, #200]
	stur	q1, [x8, #216]
	ldp	q0, q1, [x3, #224]
	stur	q0, [x8, #232]
	stur	q1, [x8, #248]
	ldp	q0, q1, [x3, #128]
	stur	q0, [x8, #136]
	stur	q1, [x8, #152]
	ldp	q0, q1, [x3, #160]
	stur	q0, [x8, #168]
	stur	q1, [x8, #184]
	ldp	q0, q1, [x3, #64]
	add	x9, sp, #89
	stur	q0, [x9, #255]
	add	x9, sp, #105
	stur	q1, [x9, #255]
	ldp	q0, q1, [x3, #96]
	add	x9, sp, #121
	stur	q0, [x9, #255]
	stur	q1, [x8, #120]
	ldp	q0, q1, [x3]
	add	x8, sp, #25
	stur	q0, [x8, #255]
	add	x8, sp, #41
	stur	q1, [x8, #255]
	ldp	q0, q1, [x3, #32]
	add	x8, sp, #57
	stur	q0, [x8, #255]
	str	x2, [sp, #272]
	add	x8, sp, #73
	stur	q1, [x8, #255]
	ldr	x22, [x1]
	cbz	x22, LBB23_14
; %bb.1:                                ; %bb2
	add	x8, x20, #8
	mov	w23, #280                       ; =0x118
	b	LBB23_4
LBB23_2:                                ; %bb2.i
                                        ;   in Loop: Header=BB23_4 Depth=1
	cbz	x26, LBB23_12
LBB23_3:                                ; %bb10.i
                                        ;   in Loop: Header=BB23_4 Depth=1
	madd	x8, x26, x23, x25
	ldur	x9, [x8, #-8]
	cbz	x9, LBB23_14
LBB23_4:                                ; %bb1.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB23_6 Depth 2
	ldr	x24, [x8]
	mov	x25, x24
	ldr	x27, [x25, #16]!
	cbz	x27, LBB23_9
; %bb.5:                                ; %bb2.lr.ph.i.i.i.i
                                        ;   in Loop: Header=BB23_4 Depth=1
	mov	x26, #0                         ; =0x0
	add	x21, x24, #24
LBB23_6:                                ; %bb2.i.i.i.i
                                        ;   Parent Loop BB23_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x0, sp, #272
	mov	x1, x21
	bl	_wf_ordered_cost_compare
	cmp	w0, #1
	b.lt	LBB23_10
; %bb.7:                                ; %bb8.i.i.i.i
                                        ;   in Loop: Header=BB23_6 Depth=2
	add	x26, x26, #1
	add	x21, x21, #280
	cmp	x27, x26
	b.ne	LBB23_6
; %bb.8:                                ;   in Loop: Header=BB23_4 Depth=1
	mov	x26, x27
	b	LBB23_3
LBB23_9:                                ;   in Loop: Header=BB23_4 Depth=1
	mov	x26, #0                         ; =0x0
LBB23_10:                               ; %"wf_std.collections.ordered_map.ordered_map_search$instance$43c0c30766ba2e8b.exit.i"
                                        ;   in Loop: Header=BB23_4 Depth=1
	cmp	x26, x27
	b.hs	LBB23_2
; %bb.11:                               ; %bb3.i
                                        ;   in Loop: Header=BB23_4 Depth=1
	madd	x21, x26, x23, x25
	add	x0, sp, #272
	add	x1, x21, #8
	bl	_wf_ordered_cost_compare
	cbnz	w0, LBB23_2
	b	LBB23_19
LBB23_12:                               ; %bb9.i
                                        ;   in Loop: Header=BB23_4 Depth=1
	ldr	x8, [x24]
	cbz	x8, LBB23_14
; %bb.13:                               ; %bb12.i
                                        ;   in Loop: Header=BB23_4 Depth=1
	add	x8, x24, #8
	b	LBB23_4
LBB23_14:                               ; %bb1
	ldr	x21, [x20, #16]
	lsr	x8, x21, #13
	cbz	x8, LBB23_16
; %bb.15:                               ; %bb8
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	strb	w8, [x19, #4]
	add	x0, x19, #8
	add	x1, sp, #272
	b	LBB23_20
LBB23_16:                               ; %bb9
	add	x0, sp, #536
	add	x2, sp, #272
	mov	x1, x20
	bl	_wf_std.collections.ordered_map.ordered_map_insert_link$instance$43c0c30766ba2e8b
	ldr	w8, [sp, #536]
	cbz	w8, LBB23_23
; %bb.17:                               ; %bb12
	add	x8, sp, #536
	ldur	q1, [x8, #24]
	ldur	q0, [x8, #8]
	stp	q1, q0, [sp, #208]              ; 32-byte Folded Spill
	ldur	q1, [x8, #56]
	ldur	q0, [x8, #40]
	stp	q1, q0, [sp, #176]              ; 32-byte Folded Spill
	ldur	q1, [x8, #88]
	ldur	q0, [x8, #72]
	stp	q1, q0, [sp, #144]              ; 32-byte Folded Spill
	ldur	q1, [x8, #120]
	ldur	q0, [x8, #104]
	stp	q1, q0, [sp, #112]              ; 32-byte Folded Spill
	ldur	q1, [x8, #152]
	ldur	q0, [x8, #136]
	stp	q1, q0, [sp, #80]               ; 32-byte Folded Spill
	ldur	q1, [x8, #184]
	ldur	q0, [x8, #168]
	stp	q1, q0, [sp, #48]               ; 32-byte Folded Spill
	ldur	q1, [x8, #216]
	ldur	q0, [x8, #200]
	stp	q1, q0, [sp, #16]               ; 32-byte Folded Spill
	ldur	q0, [x8, #248]
	str	q0, [sp, #240]                  ; 16-byte Folded Spill
	ldur	q0, [x8, #232]
	str	q0, [sp]                        ; 16-byte Folded Spill
	ldr	x23, [sp, #800]
	ldr	x24, [sp, #808]
	ldr	x25, [sp, #816]
	str	xzr, [sp, #264]
	cbz	x22, LBB23_21
; %bb.18:                               ; %run.move.body.v3.preheader.i
	lsl	x2, x22, #3
	add	x0, sp, #264
	add	x1, x20, #8
	bl	_memcpy
	ldr	x26, [sp, #264]
	b	LBB23_22
LBB23_19:                               ; %bb6.i
	add	x0, sp, #824
	add	x1, x21, #8
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	x0, x21, #8
	add	x1, sp, #272
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	x0, sp, #272
	add	x1, sp, #824
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19], #8
	add	x1, sp, #272
	mov	x0, x19
LBB23_20:                               ; %common.ret
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	b	LBB23_24
LBB23_21:
	mov	x26, #0                         ; =0x0
LBB23_22:                               ; %"wf_append$instance$42f33d80f30f592c.exit"
	str	xzr, [x20]
	mov	w0, #4224                       ; =0x1080
	bl	_wf_cost_allocate
	mov	x21, x0
	stp	x22, x26, [x0]
	mov	w8, #1                          ; =0x1
	str	x8, [x0, #16]
	ldp	q1, q0, [sp, #208]              ; 32-byte Folded Reload
	stur	q1, [x0, #40]
	stur	q0, [x0, #24]
	ldp	q1, q0, [sp, #176]              ; 32-byte Folded Reload
	stur	q1, [x0, #72]
	stur	q0, [x0, #56]
	ldp	q1, q0, [sp, #144]              ; 32-byte Folded Reload
	stur	q1, [x0, #104]
	stur	q0, [x0, #88]
	ldp	q1, q0, [sp, #112]              ; 32-byte Folded Reload
	stur	q1, [x0, #136]
	stur	q0, [x0, #120]
	ldp	q1, q0, [sp, #80]               ; 32-byte Folded Reload
	stur	q1, [x0, #168]
	stur	q0, [x0, #152]
	ldp	q1, q0, [sp, #48]               ; 32-byte Folded Reload
	stur	q1, [x0, #200]
	stur	q0, [x0, #184]
	ldp	q1, q0, [sp, #16]               ; 32-byte Folded Reload
	stur	q1, [x0, #232]
	stur	q0, [x0, #216]
	mov	x8, x0
	ldr	q0, [sp]                        ; 16-byte Folded Reload
	str	q0, [x8, #248]!
	ldr	q0, [sp, #240]                  ; 16-byte Folded Reload
	str	q0, [x8, #16]
	stp	x23, x24, [x0, #280]
	str	x25, [x0, #296]
	add	x0, x0, #304
	mov	w1, #3920                       ; =0xf50
	bl	_bzero
	ldr	x8, [x20]
	add	x9, x20, x8, lsl #3
	str	x21, [x9, #8]
	add	x8, x8, #1
	str	x8, [x20]
	ldr	x21, [x20, #16]
LBB23_23:                               ; %bb10
	add	x8, x21, #1
	str	x8, [x20, #16]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	stp	q0, q0, [x19, #32]
	stp	q0, q0, [x19, #64]
	stp	q0, q0, [x19, #96]
	stp	q0, q0, [x19, #128]
	stp	q0, q0, [x19, #160]
	stp	q0, q0, [x19, #192]
	stp	q0, q0, [x19, #224]
	str	q0, [x19, #256]
LBB23_24:                               ; %common.ret
	add	sp, sp, #1088
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_len$instance$a36c254d11d20619
_wf_std.collections.ordered_map.ordered_map_len$instance$a36c254d11d20619: ; @"wf_std.collections.ordered_map.ordered_map_len$instance$a36c254d11d20619"
; %bb.0:                                ; %entry
	ldr	x0, [x0, #16]
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_lookup$instance$27c9a7455d5e3844
_wf_std.collections.ordered_map.ordered_map_lookup$instance$27c9a7455d5e3844: ; @"wf_std.collections.ordered_map.ordered_map_lookup$instance$27c9a7455d5e3844"
; %bb.0:                                ; %entry
	b	_wf_std.collections.ordered_map.ordered_map_lookup_link$instance$768bf1dd9f398f38
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_edit$instance$374d92b1aa276be7
_wf_std.collections.ordered_map.ordered_map_edit$instance$374d92b1aa276be7: ; @"wf_std.collections.ordered_map.ordered_map_edit$instance$374d92b1aa276be7"
; %bb.0:                                ; %entry
	b	_wf_std.collections.ordered_map.ordered_map_edit_link$instance$887d1b484f24fc68
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_remove$instance$912c4c551bcb3786
_wf_std.collections.ordered_map.ordered_map_remove$instance$912c4c551bcb3786: ; @"wf_std.collections.ordered_map.ordered_map_remove$instance$912c4c551bcb3786"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #368
	stp	x26, x25, [sp, #288]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #304]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #320]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #336]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #352]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 368
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x20, x1
	mov	x19, x0
	add	x21, sp, #8
	add	x0, sp, #8
	bl	_wf_std.collections.ordered_map.ordered_map_remove_link$instance$43c0c30766ba2e8b
	ldr	w8, [sp, #8]
	cbz	w8, LBB27_10
; %bb.1:                                ; %bb2
	ldr	x8, [x20]
	cbz	x8, LBB27_7
; %bb.2:                                ; %bb2.i
	sub	x22, x8, #1
	add	x23, x20, x22, lsl #3
	str	x22, [x20]
	ldr	x0, [x23, #8]
	ldr	x9, [x0, #16]
	cbnz	x9, LBB27_6
; %bb.3:                                ; %bb5.i
	ldp	x24, x25, [x0]
	bl	_wf_cost_release
	str	x25, [sp, #280]
	cbz	x24, LBB27_5
; %bb.4:                                ; %run.move.body.v3.preheader.i.i
	lsl	x2, x24, #3
	add	x0, x23, #8
	add	x1, sp, #280
	bl	_memcpy
LBB27_5:                                ; %"wf_append$instance$42f33d80f30f592c.exit.i"
	add	x8, x24, x22
LBB27_6:                                ; %bb1.sink.split.i
	str	x8, [x20]
LBB27_7:                                ; %"wf_std.collections.ordered_map.ordered_map_contract_root$instance$d883f474bea0047c.exit"
	ldr	x8, [x20, #16]
	cbz	x8, LBB27_9
; %bb.8:                                ; %bb4
	sub	x8, x8, #1
	str	x8, [x20, #16]
LBB27_9:                                ; %bb3
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19], #8
	add	x1, x21, #8
	mov	x0, x19
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	b	LBB27_11
LBB27_10:                               ; %bb1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #240]
	stp	q0, q0, [x19, #208]
	stp	q0, q0, [x19, #176]
	stp	q0, q0, [x19, #144]
	stp	q0, q0, [x19, #112]
	stp	q0, q0, [x19, #80]
	stp	q0, q0, [x19, #48]
	stp	q0, q0, [x19, #16]
	str	q0, [x19]
LBB27_11:                               ; %bb3
	ldp	x29, x30, [sp, #352]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #336]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #320]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #304]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #288]            ; 16-byte Folded Reload
	add	sp, sp, #368
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_range$instance$e886f4eb776d75c0
_wf_std.collections.ordered_map.ordered_map_range$instance$e886f4eb776d75c0: ; @"wf_std.collections.ordered_map.ordered_map_range$instance$e886f4eb776d75c0"
; %bb.0:                                ; %entry
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x1
	mov	x22, x0
	mov	x0, x1
	mov	x1, x2
	bl	_wf_ordered_cost_compare
	tbnz	w0, #31, LBB28_2
; %bb.1:                                ; %bb1
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB28_2:                                ; %bb2
	mov	x0, x22
	mov	x1, x21
	mov	x2, x20
	mov	x3, x19
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	b	_wf_std.collections.ordered_map.ordered_map_range_link$instance$475e4daed49f96af
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_each$instance$960d100d77757702
_wf_std.collections.ordered_map.ordered_map_each$instance$960d100d77757702: ; @"wf_std.collections.ordered_map.ordered_map_each$instance$960d100d77757702"
; %bb.0:                                ; %entry
	b	_wf_std.collections.ordered_map.ordered_map_each_link$instance$5703a7a9bf1884ed
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_free$instance$56a8ddd8129b5d48
_wf_std.collections.ordered_map.ordered_map_free$instance$56a8ddd8129b5d48: ; @"wf_std.collections.ordered_map.ordered_map_free$instance$56a8ddd8129b5d48"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	q0, [x0]
	str	q0, [sp]
	mov	x0, sp
	bl	_wf_std.collections.ordered_map.ordered_map_free_link$instance$40650b236ee646e0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_insert_link$instance$5046b787ff5cdb3f
_wf_std.collections.ordered_map.ordered_map_insert_link$instance$5046b787ff5cdb3f: ; @"wf_std.collections.ordered_map.ordered_map_insert_link$instance$5046b787ff5cdb3f"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #1056
	.cfi_def_cfa_offset 1152
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x21, x2
	mov	x19, x0
	ldr	x8, [x1]
	cbz	x8, LBB31_6
; %bb.1:                                ; %bb2
	ldr	x20, [x1, #8]
	ldr	q0, [x21]
	str	q0, [sp, #448]
	mov	x23, x20
	ldr	x25, [x23, #16]!
	cbz	x25, LBB31_9
; %bb.2:                                ; %bb2.lr.ph.i.i.i
	mov	x24, #0                         ; =0x0
	add	x22, x20, #24
LBB31_3:                                ; %bb2.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x0, sp, #448
	mov	x1, x22
	bl	_wf_ordered_cost_compare
	cmp	w0, #1
	b.lt	LBB31_7
; %bb.4:                                ; %bb8.i.i.i
                                        ;   in Loop: Header=BB31_3 Depth=1
	add	x24, x24, #1
	add	x22, x22, #32
	cmp	x25, x24
	b.ne	LBB31_3
; %bb.5:
	mov	x24, x25
	b	LBB31_8
LBB31_6:                                ; %bb3
	ldr	q0, [x21]
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	stur	q0, [x19, #8]
	stp	xzr, xzr, [x19, #24]
	b	LBB31_20
LBB31_7:                                ; %"wf_std.collections.ordered_map.ordered_map_search$instance$5046b787ff5cdb3f.exit"
	cbz	x24, LBB31_9
LBB31_8:                                ; %bb3.i
	add	x8, x20, x24, lsl #5
	ldr	q0, [x21]
	str	q0, [sp, #464]
	add	x0, sp, #480
	add	x1, x8, #8
	add	x2, sp, #464
	bl	_wf_std.collections.ordered_map.ordered_map_insert_link$instance$5046b787ff5cdb3f
	ldr	w8, [sp, #480]
	cbnz	w8, LBB31_10
	b	LBB31_12
LBB31_9:                                ; %bb2.i
	ldr	q0, [x21]
	str	q0, [sp, #464]
	add	x0, sp, #480
	add	x2, sp, #464
	mov	x1, x20
	bl	_wf_std.collections.ordered_map.ordered_map_insert_link$instance$5046b787ff5cdb3f
	mov	x24, #0                         ; =0x0
	ldr	w8, [sp, #480]
	cbz	w8, LBB31_12
LBB31_10:                               ; %bb5.i
	add	x22, sp, #480
	ldr	x25, [x23]
	cmp	x25, #14
	b.hi	LBB31_13
; %bb.11:                               ; %bb2.i3
	sub	x8, x25, x24
	add	x20, x23, x24, lsl #5
	lsl	x2, x8, #5
	add	x0, x20, #40
	add	x1, x20, #8
	bl	_memmove
	add	x8, x25, #1
	str	x8, [x23]
	ldur	q0, [x22, #24]
	stur	q0, [x20, #24]
	ldur	q0, [x22, #8]
	stur	q0, [x20, #8]
LBB31_12:                               ; %bb4.i
	str	xzr, [x19, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	b	LBB31_20
LBB31_13:                               ; %bb3.i2
	add	x21, sp, #536
	add	x8, sp, #536
	add	x9, x8, #232
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9, #224]
	stp	q0, q0, [x9, #192]
	stp	q0, q0, [x9, #160]
	stp	q0, q0, [x9, #128]
	stp	q0, q0, [x9, #96]
	stp	q0, q0, [x9, #64]
	stp	q0, q0, [x9, #32]
	stur	q0, [x21, #248]
	stur	q0, [x21, #232]
	add	x9, x20, #24
	sub	x10, x25, #1
	add	x11, x9, x10, lsl #5
	str	x10, [x20, #16]
	ldp	q0, q1, [x11]
	add	x10, sp, #305
	stur	q1, [x10, #255]
	add	x10, sp, #289
	stur	q0, [x10, #255]
	sub	x10, x25, #2
	add	x11, x9, x10, lsl #5
	str	x10, [x20, #16]
	ldp	q0, q1, [x11]
	stur	q1, [x21, #56]
	stur	q0, [x21, #40]
	sub	x10, x25, #3
	add	x11, x9, x10, lsl #5
	str	x10, [x20, #16]
	ldp	q0, q1, [x11]
	stur	q1, [x21, #88]
	stur	q0, [x21, #72]
	sub	x10, x25, #4
	add	x11, x9, x10, lsl #5
	str	x10, [x20, #16]
	ldp	q0, q1, [x11]
	stur	q1, [x21, #120]
	stur	q0, [x21, #104]
	sub	x10, x25, #5
	add	x11, x9, x10, lsl #5
	str	x10, [x20, #16]
	ldp	q0, q1, [x11]
	stur	q1, [x21, #152]
	stur	q0, [x21, #136]
	sub	x10, x25, #6
	add	x11, x9, x10, lsl #5
	str	x10, [x20, #16]
	ldp	q0, q1, [x11]
	stur	q1, [x21, #184]
	stur	q0, [x21, #168]
	sub	x26, x25, #7
	add	x9, x9, x26, lsl #5
	str	x26, [x20, #16]
	mov	w10, #7                         ; =0x7
	str	x10, [sp, #536]
	add	x10, sp, #305
	ldur	q0, [x10, #255]
	add	x10, sp, #289
	ldur	q1, [x10, #255]
	ldp	q3, q2, [x9]
	add	x9, sp, #289
	stur	q3, [x9, #255]
	add	x9, sp, #305
	stur	q2, [x9, #255]
	stur	q1, [x21, #200]
	stur	q0, [x21, #216]
	ldur	q0, [x21, #40]
	ldur	q1, [x21, #56]
	str	q0, [sp, #1024]
	str	q1, [sp, #1040]
	ldur	q2, [x21, #168]
	ldur	q3, [x21, #184]
	stur	q3, [x21, #56]
	stur	q2, [x21, #40]
	stur	q1, [x21, #184]
	stur	q0, [x21, #168]
	ldur	q0, [x21, #72]
	ldur	q1, [x21, #88]
	str	q0, [sp, #1024]
	str	q1, [sp, #1040]
	ldur	q2, [x21, #136]
	ldur	q3, [x21, #152]
	stur	q3, [x21, #88]
	stur	q2, [x21, #72]
	stur	q1, [x21, #152]
	stur	q0, [x21, #136]
	sub	x9, x25, #8
	add	x10, x23, x9, lsl #5
	str	x9, [x20, #16]
	ldur	q0, [x10, #8]
	str	q0, [sp, #1024]
	ldp	x25, x10, [x10, #24]
	str	x10, [sp, #528]
	cmp	x24, #8
	b.hs	LBB31_15
; %bb.14:                               ; %bb15.i
	sub	x8, x9, x24
	add	x9, x23, x24, lsl #5
	add	x20, x9, #8
	lsl	x2, x8, #5
	add	x0, x9, #40
	mov	x1, x20
	bl	_memmove
	str	x26, [x23]
	b	LBB31_16
LBB31_15:                               ; %bb16.i
	lsl	x9, x24, #5
	add	x8, x8, x9
	sub	x20, x8, #248
	sub	x0, x8, #216
	mov	w8, #480                        ; =0x1e0
	sub	x2, x8, x9
	mov	x1, x20
	bl	_memmove
	mov	w8, #8                          ; =0x8
	str	x8, [sp, #536]
LBB31_16:                               ; %bb14.i
	ldur	q0, [x22, #8]
	ldur	q1, [x22, #24]
	stp	q0, q1, [x20]
	str	xzr, [sp, #520]
	cbz	x25, LBB31_18
; %bb.17:                               ; %run.move.body.v3.preheader.i.i
	lsl	x2, x25, #3
	add	x0, sp, #520
	add	x1, sp, #528
	bl	_memcpy
	ldr	x20, [sp, #520]
	b	LBB31_19
LBB31_18:
	mov	x20, #0                         ; =0x0
LBB31_19:                               ; %"wf_append$instance$48c61fa9751a6936.exit.i"
	add	x8, sp, #313
	ldur	q1, [x8, #255]
	ldp	q2, q3, [x21, #48]
	stp	q2, q1, [sp, #416]              ; 32-byte Folded Spill
	ldp	q1, q2, [x21, #80]
	stp	q1, q3, [sp, #384]              ; 32-byte Folded Spill
	ldp	q1, q3, [x21, #112]
	stp	q1, q2, [sp, #352]              ; 32-byte Folded Spill
	ldp	q1, q2, [x21, #144]
	stp	q1, q3, [sp, #320]              ; 32-byte Folded Spill
	ldp	q1, q3, [x21, #176]
	stp	q1, q2, [sp, #288]              ; 32-byte Folded Spill
	ldp	q1, q2, [x21, #208]
	stp	q1, q3, [sp, #256]              ; 32-byte Folded Spill
	ldp	q1, q3, [x21, #240]
	stp	q1, q2, [sp, #224]              ; 32-byte Folded Spill
	ldp	q1, q2, [x21, #272]
	stp	q1, q3, [sp, #192]              ; 32-byte Folded Spill
	ldp	q1, q3, [x21, #304]
	stp	q1, q2, [sp, #160]              ; 32-byte Folded Spill
	ldp	q1, q2, [x21, #336]
	stp	q1, q3, [sp, #128]              ; 32-byte Folded Spill
	ldp	q1, q3, [x21, #368]
	stp	q1, q2, [sp, #96]               ; 32-byte Folded Spill
	ldp	q1, q2, [x21, #400]
	stp	q1, q3, [sp, #64]               ; 32-byte Folded Spill
	ldp	q1, q3, [x21, #432]
	stp	q1, q2, [sp, #32]               ; 32-byte Folded Spill
	ldr	q0, [x21, #464]
	stp	q0, q3, [sp]                    ; 32-byte Folded Spill
	ldr	x21, [sp, #1016]
	mov	w0, #504                        ; =0x1f8
	bl	_wf_cost_allocate
	stp	x25, x20, [x0]
	add	x8, sp, #281
	ldur	q0, [x8, #255]
	add	x8, sp, #297
	ldur	q1, [x8, #255]
	stp	q0, q1, [x0, #16]
	ldp	q0, q1, [sp, #416]              ; 32-byte Folded Reload
	stp	q1, q0, [x0, #48]
	ldp	q0, q1, [sp, #384]              ; 32-byte Folded Reload
	stp	q1, q0, [x0, #80]
	ldp	q0, q1, [sp, #352]              ; 32-byte Folded Reload
	stp	q1, q0, [x0, #112]
	ldp	q0, q1, [sp, #320]              ; 32-byte Folded Reload
	stp	q1, q0, [x0, #144]
	ldp	q0, q1, [sp, #288]              ; 32-byte Folded Reload
	stp	q1, q0, [x0, #176]
	ldp	q0, q1, [sp, #256]              ; 32-byte Folded Reload
	stp	q1, q0, [x0, #208]
	ldp	q0, q1, [sp, #224]              ; 32-byte Folded Reload
	stp	q1, q0, [x0, #240]
	ldp	q0, q1, [sp, #192]              ; 32-byte Folded Reload
	stp	q1, q0, [x0, #272]
	ldp	q0, q1, [sp, #160]              ; 32-byte Folded Reload
	stp	q1, q0, [x0, #304]
	ldp	q0, q1, [sp, #128]              ; 32-byte Folded Reload
	stp	q1, q0, [x0, #336]
	ldp	q0, q1, [sp, #96]               ; 32-byte Folded Reload
	stp	q1, q0, [x0, #368]
	ldp	q0, q1, [sp, #64]               ; 32-byte Folded Reload
	stp	q1, q0, [x0, #400]
	ldp	q0, q1, [sp, #32]               ; 32-byte Folded Reload
	stp	q1, q0, [x0, #432]
	ldp	q0, q1, [sp]                    ; 32-byte Folded Reload
	stp	q1, q0, [x0, #464]
	str	x21, [x0, #496]
	mov	w8, #1                          ; =0x1
	str	x8, [x19]
	ldr	q0, [sp, #1024]
	stur	q0, [x19, #8]
	stp	x8, x0, [x19, #24]
LBB31_20:                               ; %bb4.i
	add	sp, sp, #1056
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_lookup_link$instance$11eb30e8dabe0f7e
_wf_std.collections.ordered_map.ordered_map_lookup_link$instance$11eb30e8dabe0f7e: ; @"wf_std.collections.ordered_map.ordered_map_lookup_link$instance$11eb30e8dabe0f7e"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB32_6
; %bb.1:                                ; %bb2.i
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	mov	x19, x1
	ldr	x20, [x0, #8]
	ldr	x24, [x20, #16]
	cbz	x24, LBB32_12
; %bb.2:                                ; %bb2.lr.ph.i.i
	mov	x25, x2
	mov	x23, #0                         ; =0x0
	add	x21, x20, #32
LBB32_3:                                ; %bb2.i.i1
                                        ; =>This Inner Loop Header: Depth=1
	sub	x22, x21, #8
	mov	x0, x19
	mov	x1, x22
	bl	_wf_ordered_cost_compare
	cmp	w0, #1
	b.lt	LBB32_7
; %bb.4:                                ; %bb8.i.i2
                                        ;   in Loop: Header=BB32_3 Depth=1
	add	x23, x23, #1
	add	x21, x21, #32
	cmp	x24, x23
	b.ne	LBB32_3
; %bb.5:
	mov	x23, x24
	mov	x2, x25
	b	LBB32_11
LBB32_6:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	ret
LBB32_7:                                ; %"wf_std.collections.ordered_map.ordered_map_search_result$instance$5046b787ff5cdb3f.exit"
	cmp	x23, x24
	mov	x2, x25
	b.hs	LBB32_10
; %bb.8:                                ; %"wf_std.collections.ordered_map.ordered_map_search_result$instance$5046b787ff5cdb3f.exit"
	cbnz	w0, LBB32_10
; %bb.9:                                ; %bb5.i.i
	mov	x0, x2
	mov	x1, x22
	mov	x2, x21
	bl	_wf_ordered_cost_word_observe
	mov	x1, x0
	mov	w0, #0                          ; =0x0
	b	LBB32_14
LBB32_10:                               ; %bb1.i.i
	cbz	x23, LBB32_12
LBB32_11:                               ; %bb9.i.i
	add	x8, x20, x23, lsl #5
	add	x0, x8, #8
	b	LBB32_13
LBB32_12:                               ; %bb8.i.i
	mov	x0, x20
LBB32_13:
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_lookup_link$instance$11eb30e8dabe0f7e
LBB32_14:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	mov	w2, #0                          ; =0x0
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_edit_link$instance$41f33845185638b6
_wf_std.collections.ordered_map.ordered_map_edit_link$instance$41f33845185638b6: ; @"wf_std.collections.ordered_map.ordered_map_edit_link$instance$41f33845185638b6"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB33_6
; %bb.1:                                ; %bb2.i
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	mov	x19, x2
	mov	x20, x1
	ldr	x21, [x0, #8]
	mov	x23, x21
	ldr	x25, [x23, #16]!
	cbz	x25, LBB33_7
; %bb.2:                                ; %bb2.lr.ph.i.i.i
	mov	x24, #0                         ; =0x0
	add	x22, x21, #24
LBB33_3:                                ; %bb2.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	mov	x0, x20
	mov	x1, x22
	bl	_wf_ordered_cost_compare
	cmp	w0, #1
	b.lt	LBB33_8
; %bb.4:                                ; %bb8.i.i.i
                                        ;   in Loop: Header=BB33_3 Depth=1
	add	x24, x24, #1
	add	x22, x22, #32
	cmp	x25, x24
	b.ne	LBB33_3
; %bb.5:
	mov	x24, x25
	b	LBB33_11
LBB33_6:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	ret
LBB33_7:
	mov	x24, #0                         ; =0x0
LBB33_8:                                ; %"wf_std.collections.ordered_map.ordered_map_search$instance$5046b787ff5cdb3f.exit"
	cmp	x24, x25
	b.hs	LBB33_10
; %bb.9:                                ; %bb2.i.i
	add	x22, x23, x24, lsl #5
	add	x1, x22, #8
	mov	x0, x20
	bl	_wf_ordered_cost_compare
	cbz	w0, LBB33_15
LBB33_10:                               ; %bb1.i.i
	cbz	x24, LBB33_12
LBB33_11:                               ; %bb9.i.i
	add	x8, x23, x24, lsl #5
	sub	x0, x8, #8
	b	LBB33_13
LBB33_12:                               ; %bb8.i.i
	mov	x0, x21
LBB33_13:
	mov	x1, x20
	mov	x2, x19
	bl	_wf_std.collections.ordered_map.ordered_map_edit_link$instance$41f33845185638b6
LBB33_14:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	mov	w2, #0                          ; =0x0
	ret
LBB33_15:                               ; %bb5.i.i
	add	x1, x22, #8
	add	x2, x22, #16
	mov	x0, x19
	bl	_wf_ordered_cost_word_edit
	mov	x1, x0
	mov	w0, #0                          ; =0x0
	b	LBB33_14
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_remove_link$instance$5046b787ff5cdb3f
_wf_std.collections.ordered_map.ordered_map_remove_link$instance$5046b787ff5cdb3f: ; @"wf_std.collections.ordered_map.ordered_map_remove_link$instance$5046b787ff5cdb3f"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #176
	stp	x28, x27, [sp, #80]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #96]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #112]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 176
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	ldr	x8, [x0]
	cbz	x8, LBB34_6
; %bb.1:                                ; %bb2.i
	mov	x21, x1
	ldr	x19, [x0, #8]
	mov	x25, x19
	ldr	x26, [x25, #16]!
	cbz	x26, LBB34_7
; %bb.2:                                ; %bb2.lr.ph.i.i.i
	mov	x20, #0                         ; =0x0
	add	x22, x19, #24
LBB34_3:                                ; %bb2.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	mov	x0, x21
	mov	x1, x22
	bl	_wf_ordered_cost_compare
	cmp	w0, #1
	b.lt	LBB34_8
; %bb.4:                                ; %bb8.i.i.i
                                        ;   in Loop: Header=BB34_3 Depth=1
	add	x20, x20, #1
	add	x22, x22, #32
	cmp	x26, x20
	b.ne	LBB34_3
; %bb.5:
	mov	x20, x26
	b	LBB34_11
LBB34_6:
	mov	x21, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
	mov	w0, #0                          ; =0x0
	b	LBB34_18
LBB34_7:
	mov	x20, #0                         ; =0x0
LBB34_8:                                ; %"wf_std.collections.ordered_map.ordered_map_search$instance$5046b787ff5cdb3f.exit"
	cmp	x20, x26
	b.hs	LBB34_10
; %bb.9:                                ; %bb2.i.i
	add	x22, x25, x20, lsl #5
	add	x1, x22, #8
	mov	x0, x21
	bl	_wf_ordered_cost_compare
	cbz	w0, LBB34_19
LBB34_10:                               ; %bb1.i.i
	cbz	x20, LBB34_12
LBB34_11:                               ; %bb9.i.i
	add	x8, x25, x20, lsl #5
	sub	x0, x8, #8
	b	LBB34_13
LBB34_12:
	mov	x0, x19
LBB34_13:                               ; %bb7.i.i
	mov	x1, x21
	bl	_wf_std.collections.ordered_map.ordered_map_remove_link$instance$5046b787ff5cdb3f
	cbz	w0, LBB34_17
; %bb.14:                               ; %bb11.i.i
	mov	x22, x1
	mov	x21, x2
	mov	x0, x19
	mov	x1, x20
LBB34_15:                               ; %"wf_std.collections.ordered_map.ordered_map_remove_link$instance$5046b787ff5cdb3f.body.exit"
	bl	_wf_std.collections.ordered_map.ordered_map_repair_child$instance$0ed342445dd803f3
LBB34_16:                               ; %"wf_std.collections.ordered_map.ordered_map_remove_link$instance$5046b787ff5cdb3f.body.exit"
	mov	w0, #1                          ; =0x1
	b	LBB34_18
LBB34_17:
	mov	x21, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
LBB34_18:                               ; %"wf_std.collections.ordered_map.ordered_map_remove_link$instance$5046b787ff5cdb3f.body.exit"
	mov	x1, x22
	mov	x2, x21
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #144]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #96]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
LBB34_19:                               ; %bb5.i.i
	mov	x9, x22
	ldr	x22, [x22, #8]
	ldp	x21, x23, [x9, #16]
	ldr	x24, [x9, #32]
	add	x10, x20, #1
	mvn	x8, x20
	add	x8, x26, x8
	stp	x10, x9, [sp, #24]              ; 16-byte Folded Spill
	add	x10, x25, x10, lsl #5
	lsl	x2, x8, #5
	add	x0, x9, #8
	stp	x19, x10, [sp, #8]              ; 16-byte Folded Spill
	add	x1, x10, #8
	bl	_memmove
	sub	x8, x26, #1
	str	x8, [x25]
	stp	x22, x21, [sp, #40]
	stp	x23, x24, [sp, #56]
	cbz	x23, LBB34_16
; %bb.20:                               ; %bb4.i.i.i.i.preheader
	str	x8, [sp]                        ; 8-byte Folded Spill
	add	x8, sp, #40
	add	x19, x8, #24
	b	LBB34_23
LBB34_21:                               ; %"wf_append$instance$48c61fa9751a6936.exit.i.i.i.i.i"
                                        ;   in Loop: Header=BB34_23 Depth=1
	add	x23, x23, x27
LBB34_22:                               ; %"wf_std.collections.ordered_map.ordered_map_contract_root$instance$0ed342445dd803f3.exit.i.i.i.i"
                                        ;   in Loop: Header=BB34_23 Depth=1
	stp	x21, x23, [sp, #48]
	str	x24, [sp, #64]
	cbz	x23, LBB34_16
LBB34_23:                               ; %bb4.i.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x8, [x24, #16]
	cbnz	x8, LBB34_27
; %bb.24:                               ; %bb2.i.i.i.i.i
                                        ;   in Loop: Header=BB34_23 Depth=1
	sub	x27, x23, #1
	add	x25, x19, x27, lsl #3
	str	x27, [sp, #56]
	ldr	x0, [x25]
	ldr	x8, [x0, #16]
	cbnz	x8, LBB34_22
; %bb.25:                               ; %bb5.i.i.i.i.i
                                        ;   in Loop: Header=BB34_23 Depth=1
	ldp	x23, x28, [x0]
	bl	_wf_cost_release
	str	x28, [sp, #72]
	cbz	x23, LBB34_21
; %bb.26:                               ; %run.move.body.v3.preheader.i.i.i.i.i.i
                                        ;   in Loop: Header=BB34_23 Depth=1
	lsl	x2, x23, #3
	add	x1, sp, #72
	mov	x0, x25
	bl	_memcpy
	ldr	x24, [sp, #64]
	ldp	x22, x21, [sp, #40]
	b	LBB34_21
LBB34_27:                               ; %bb6.i.i.i.i
	mov	x0, x24
	bl	_wf_std.collections.ordered_map.ordered_map_take_min$instance$0ed342445dd803f3
	stp	x0, x1, [sp, #40]
	ldr	x8, [sp]                        ; 8-byte Folded Reload
	sub	x8, x8, x20
	lsl	x2, x8, #5
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	add	x0, x8, #8
	ldr	x20, [sp, #32]                  ; 8-byte Folded Reload
	add	x1, x20, #8
	bl	_memmove
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	str	x26, [x0, #16]
	ldur	q0, [sp, #40]
	ldur	q1, [sp, #56]
	stur	q0, [x20, #8]
	stur	q1, [x20, #24]
	ldr	x1, [sp, #24]                   ; 8-byte Folded Reload
	b	LBB34_15
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_range_link$instance$171ecc1fc526bab5
_wf_std.collections.ordered_map.ordered_map_range_link$instance$171ecc1fc526bab5: ; @"wf_std.collections.ordered_map.ordered_map_range_link$instance$171ecc1fc526bab5"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB35_15
; %bb.1:                                ; %bb2
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x1
	ldr	x23, [x0, #8]
	ldr	x25, [x23, #16]
	cbz	x25, LBB35_6
; %bb.2:                                ; %bb2.lr.ph.i.i.i
	mov	x24, #0                         ; =0x0
	add	x22, x23, #24
LBB35_3:                                ; %bb2.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	mov	x0, x21
	mov	x1, x22
	bl	_wf_ordered_cost_compare
	cmp	w0, #1
	b.lt	LBB35_7
; %bb.4:                                ; %bb8.i.i.i
                                        ;   in Loop: Header=BB35_3 Depth=1
	add	x24, x24, #1
	add	x22, x22, #32
	cmp	x25, x24
	b.ne	LBB35_3
; %bb.5:
	mov	x24, x25
	b	LBB35_8
LBB35_6:
	mov	x24, #0                         ; =0x0
	b	LBB35_9
LBB35_7:                                ; %"wf_std.collections.ordered_map.ordered_map_search$instance$5046b787ff5cdb3f.exit"
	cbz	x24, LBB35_9
LBB35_8:                                ; %bb3.i
	add	x8, x23, x24, lsl #5
	add	x0, x8, #8
	b	LBB35_10
LBB35_9:
	mov	x0, x23
LBB35_10:                               ; %bb1.i
	mov	x1, x21
	mov	x2, x20
	mov	x3, x19
	bl	_wf_std.collections.ordered_map.ordered_map_range_link$instance$171ecc1fc526bab5
	ldr	x25, [x23, #16]
	cmp	x24, x25
	b.hs	LBB35_14
; %bb.11:                               ; %bb5.i.preheader
	add	x8, x23, x24, lsl #5
	add	x22, x8, #40
LBB35_12:                               ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	sub	x23, x22, #16
	mov	x0, x23
	mov	x1, x20
	bl	_wf_ordered_cost_compare
	tbz	w0, #31, LBB35_14
; %bb.13:                               ; %bb10.i
                                        ;   in Loop: Header=BB35_12 Depth=1
	sub	x2, x22, #8
	mov	x0, x19
	mov	x1, x23
	bl	_wf_ordered_cost_word_visit
	mov	x0, x22
	mov	x1, x21
	mov	x2, x20
	mov	x3, x19
	bl	_wf_std.collections.ordered_map.ordered_map_range_link$instance$171ecc1fc526bab5
	add	x24, x24, #1
	add	x22, x22, #32
	cmp	x25, x24
	b.ne	LBB35_12
LBB35_14:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
LBB35_15:                               ; %bb1
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_each_link$instance$5fa8e8b3d971a72b
_wf_std.collections.ordered_map.ordered_map_each_link$instance$5fa8e8b3d971a72b: ; @"wf_std.collections.ordered_map.ordered_map_each_link$instance$5fa8e8b3d971a72b"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB36_5
; %bb.1:                                ; %bb2
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	mov	x19, x1
	ldr	x20, [x0, #8]
	mov	x0, x20
	bl	_wf_std.collections.ordered_map.ordered_map_each_link$instance$5fa8e8b3d971a72b
	ldr	x21, [x20, #16]
	cbz	x21, LBB36_4
; %bb.2:                                ; %bb2.i.preheader
	mov	x22, #0                         ; =0x0
	add	x20, x20, #40
LBB36_3:                                ; %bb2.i
                                        ; =>This Inner Loop Header: Depth=1
	sub	x1, x20, #16
	sub	x2, x20, #8
	mov	x0, x19
	bl	_wf_ordered_cost_word_visit
	mov	x0, x20
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_each_link$instance$5fa8e8b3d971a72b
	add	x22, x22, #1
	add	x20, x20, #32
	cmp	x21, x22
	b.ne	LBB36_3
LBB36_4:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB36_5:                                ; %bb1
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_free_link$instance$a14f6fad6bd909bd
_wf_std.collections.ordered_map.ordered_map_free_link$instance$a14f6fad6bd909bd: ; @"wf_std.collections.ordered_map.ordered_map_free_link$instance$a14f6fad6bd909bd"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #112
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 112
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	ldr	q0, [x0]
	str	q0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB37_7
; %bb.1:                                ; %bb2
	mov	x19, x1
	sub	x8, x8, #1
	mov	x9, sp
	add	x9, x9, x8, lsl #3
	str	x8, [sp]
	ldr	x20, [x9, #8]
	mov	x21, x20
	ldr	x8, [x21, #16]!
	cbz	x8, LBB37_3
LBB37_2:                                ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	sub	x8, x8, #1
	add	x9, x21, x8, lsl #5
	str	x8, [x21]
	ldp	x1, x2, [x9, #8]
	ldur	q0, [x9, #24]
	str	q0, [sp, #48]
	mov	x0, x19
	bl	_wf_ordered_cost_word_consume
	add	x0, sp, #48
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_free_link$instance$a14f6fad6bd909bd
	ldr	x8, [x21]
	cbnz	x8, LBB37_2
LBB37_3:                                ; %"wf_std.collections.ordered_map.ordered_map_free_node$instance$a14f6fad6bd909bd.exit"
	str	xzr, [sp, #24]
	ldr	x21, [x20]
	cbz	x21, LBB37_5
; %bb.4:                                ; %run.move.body.v3.preheader.i
	lsl	x2, x21, #3
	add	x0, sp, #24
	add	x1, x20, #8
	bl	_memcpy
	ldr	x22, [sp, #24]
	b	LBB37_6
LBB37_5:
	mov	x22, #0                         ; =0x0
LBB37_6:                                ; %"wf_append$instance$48c61fa9751a6936.exit"
	str	xzr, [x20]
	mov	x0, x20
	bl	_wf_cost_release
	stp	x21, x22, [sp, #32]
	add	x0, sp, #32
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_free_link$instance$a14f6fad6bd909bd
LBB37_7:                                ; %bb1
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_insert_link$instance$43c0c30766ba2e8b
_wf_std.collections.ordered_map.ordered_map_insert_link$instance$43c0c30766ba2e8b: ; @"wf_std.collections.ordered_map.ordered_map_insert_link$instance$43c0c30766ba2e8b"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #816
	.cfi_def_cfa_offset 896
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	mov	x21, x2
	mov	x19, x0
	ldr	x8, [x1]
	cbz	x8, LBB38_6
; %bb.1:                                ; %bb2
	ldr	x20, [x1, #8]
	mov	x0, sp
	mov	x1, x21
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	ldr	x24, [x20, #16]
	cbz	x24, LBB38_10
; %bb.2:                                ; %bb2.lr.ph.i.i.i
	mov	x22, #0                         ; =0x0
	add	x23, x20, #24
LBB38_3:                                ; %bb2.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	mov	x0, sp
	mov	x1, x23
	bl	_wf_ordered_cost_compare
	cmp	w0, #1
	b.lt	LBB38_7
; %bb.4:                                ; %bb8.i.i.i
                                        ;   in Loop: Header=BB38_3 Depth=1
	add	x22, x22, #1
	add	x23, x23, #280
	cmp	x24, x22
	b.ne	LBB38_3
; %bb.5:
	mov	x22, x24
	b	LBB38_8
LBB38_6:                                ; %bb3
	ldr	x8, [x21, #256]
	ldp	q0, q1, [x21]
	ldp	q2, q3, [x21, #32]
	ldp	q4, q5, [x21, #64]
	ldp	q6, q7, [x21, #96]
	ldp	q16, q17, [x21, #128]
	ldp	q18, q19, [x21, #160]
	ldp	q20, q21, [x21, #192]
	ldp	q22, q23, [x21, #224]
	str	xzr, [x19]
	mov	w9, #1                          ; =0x1
	str	w9, [x19]
	stur	q0, [x19, #8]
	stur	q1, [x19, #24]
	stur	q2, [x19, #40]
	stur	q3, [x19, #56]
	stur	q4, [x19, #72]
	stur	q5, [x19, #88]
	stur	q6, [x19, #104]
	stur	q7, [x19, #120]
	stur	q16, [x19, #136]
	stur	q17, [x19, #152]
	stur	q18, [x19, #168]
	stur	q19, [x19, #184]
	stur	q20, [x19, #200]
	stur	q21, [x19, #216]
	stur	q22, [x19, #232]
	stur	q23, [x19, #248]
	stp	xzr, xzr, [x19, #272]
	str	x8, [x19, #264]
	b	LBB38_12
LBB38_7:                                ; %"wf_std.collections.ordered_map.ordered_map_search$instance$43c0c30766ba2e8b.exit"
	cbz	x22, LBB38_10
LBB38_8:                                ; %bb3.i
	mov	w8, #280                        ; =0x118
	madd	x23, x22, x8, x20
	add	x0, sp, #264
	mov	x1, x21
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	x0, sp, #528
	add	x1, x23, #8
	add	x2, sp, #264
	bl	_wf_std.collections.ordered_map.ordered_map_insert_link$instance$43c0c30766ba2e8b
	ldr	w8, [sp, #528]
	cbz	w8, LBB38_11
LBB38_9:                                ; %bb5.i
	add	x8, sp, #528
	add	x3, x8, #8
	mov	x0, x19
	mov	x1, x20
	mov	x2, x22
	bl	_wf_std.collections.ordered_map.ordered_map_insert_item$instance$d883f474bea0047c
	b	LBB38_12
LBB38_10:                               ; %bb2.i
	add	x0, sp, #264
	mov	x1, x21
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	x0, sp, #528
	add	x2, sp, #264
	mov	x1, x20
	bl	_wf_std.collections.ordered_map.ordered_map_insert_link$instance$43c0c30766ba2e8b
	mov	x22, #0                         ; =0x0
	ldr	w8, [sp, #528]
	cbnz	w8, LBB38_9
LBB38_11:                               ; %bb4.i
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #256]
	stp	q0, q0, [x19, #224]
	stp	q0, q0, [x19, #192]
	stp	q0, q0, [x19, #160]
	stp	q0, q0, [x19, #128]
	stp	q0, q0, [x19, #96]
	stp	q0, q0, [x19, #64]
	stp	q0, q0, [x19, #32]
	stp	q0, q0, [x19]
LBB38_12:                               ; %bb5.i
	add	sp, sp, #816
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_lookup_link$instance$768bf1dd9f398f38
_wf_std.collections.ordered_map.ordered_map_lookup_link$instance$768bf1dd9f398f38: ; @"wf_std.collections.ordered_map.ordered_map_lookup_link$instance$768bf1dd9f398f38"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB39_6
; %bb.1:                                ; %bb2.i
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	mov	x19, x1
	ldr	x20, [x0, #8]
	ldr	x24, [x20, #16]
	cbz	x24, LBB39_12
; %bb.2:                                ; %bb2.lr.ph.i.i
	mov	x25, x2
	mov	x23, #0                         ; =0x0
	add	x21, x20, #32
LBB39_3:                                ; %bb2.i.i1
                                        ; =>This Inner Loop Header: Depth=1
	sub	x22, x21, #8
	mov	x0, x19
	mov	x1, x22
	bl	_wf_ordered_cost_compare
	cmp	w0, #1
	b.lt	LBB39_7
; %bb.4:                                ; %bb8.i.i2
                                        ;   in Loop: Header=BB39_3 Depth=1
	add	x23, x23, #1
	add	x21, x21, #280
	cmp	x24, x23
	b.ne	LBB39_3
; %bb.5:
	mov	x23, x24
	mov	x2, x25
	b	LBB39_11
LBB39_6:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	ret
LBB39_7:                                ; %"wf_std.collections.ordered_map.ordered_map_search_result$instance$43c0c30766ba2e8b.exit"
	cmp	x23, x24
	mov	x2, x25
	b.hs	LBB39_10
; %bb.8:                                ; %"wf_std.collections.ordered_map.ordered_map_search_result$instance$43c0c30766ba2e8b.exit"
	cbnz	w0, LBB39_10
; %bb.9:                                ; %bb5.i.i
	mov	x0, x2
	mov	x1, x22
	mov	x2, x21
	bl	_wf_ordered_cost_record_observe
	mov	x1, x0
	mov	w0, #0                          ; =0x0
	b	LBB39_14
LBB39_10:                               ; %bb1.i.i
	cbz	x23, LBB39_12
LBB39_11:                               ; %bb9.i.i
	mov	w8, #280                        ; =0x118
	madd	x8, x23, x8, x20
	add	x0, x8, #8
	b	LBB39_13
LBB39_12:                               ; %bb8.i.i
	mov	x0, x20
LBB39_13:
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_lookup_link$instance$768bf1dd9f398f38
LBB39_14:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	mov	w2, #0                          ; =0x0
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_edit_link$instance$887d1b484f24fc68
_wf_std.collections.ordered_map.ordered_map_edit_link$instance$887d1b484f24fc68: ; @"wf_std.collections.ordered_map.ordered_map_edit_link$instance$887d1b484f24fc68"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB40_6
; %bb.1:                                ; %bb2.i
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	mov	x19, x2
	mov	x20, x1
	ldr	x21, [x0, #8]
	mov	x23, x21
	ldr	x25, [x23, #16]!
	cbz	x25, LBB40_7
; %bb.2:                                ; %bb2.lr.ph.i.i.i
	mov	x24, #0                         ; =0x0
	add	x22, x21, #24
LBB40_3:                                ; %bb2.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	mov	x0, x20
	mov	x1, x22
	bl	_wf_ordered_cost_compare
	cmp	w0, #1
	b.lt	LBB40_8
; %bb.4:                                ; %bb8.i.i.i
                                        ;   in Loop: Header=BB40_3 Depth=1
	add	x24, x24, #1
	add	x22, x22, #280
	cmp	x25, x24
	b.ne	LBB40_3
; %bb.5:
	mov	x24, x25
	b	LBB40_11
LBB40_6:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	ret
LBB40_7:
	mov	x24, #0                         ; =0x0
LBB40_8:                                ; %"wf_std.collections.ordered_map.ordered_map_search$instance$43c0c30766ba2e8b.exit"
	cmp	x24, x25
	b.hs	LBB40_10
; %bb.9:                                ; %bb2.i.i
	mov	w8, #280                        ; =0x118
	madd	x22, x24, x8, x23
	add	x1, x22, #8
	mov	x0, x20
	bl	_wf_ordered_cost_compare
	cbz	w0, LBB40_15
LBB40_10:                               ; %bb1.i.i
	cbz	x24, LBB40_12
LBB40_11:                               ; %bb9.i.i
	mov	w8, #280                        ; =0x118
	madd	x8, x24, x8, x23
	sub	x0, x8, #8
	b	LBB40_13
LBB40_12:                               ; %bb8.i.i
	mov	x0, x21
LBB40_13:
	mov	x1, x20
	mov	x2, x19
	bl	_wf_std.collections.ordered_map.ordered_map_edit_link$instance$887d1b484f24fc68
LBB40_14:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	mov	w2, #0                          ; =0x0
	ret
LBB40_15:                               ; %bb5.i.i
	add	x1, x22, #8
	add	x2, x22, #16
	mov	x0, x19
	bl	_wf_ordered_cost_record_edit
	mov	x1, x0
	mov	w0, #0                          ; =0x0
	b	LBB40_14
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_remove_link$instance$43c0c30766ba2e8b
_wf_std.collections.ordered_map.ordered_map_remove_link$instance$43c0c30766ba2e8b: ; @"wf_std.collections.ordered_map.ordered_map_remove_link$instance$43c0c30766ba2e8b"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #1120
	.cfi_def_cfa_offset 1216
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
	ldr	x8, [x1]
	cbz	x8, LBB41_15
; %bb.1:                                ; %bb2
	mov	x22, x2
	ldr	x25, [x1, #8]
	mov	x26, x25
	ldr	x24, [x26, #16]!
	cbz	x24, LBB41_6
; %bb.2:                                ; %bb2.lr.ph.i.i.i
	mov	x21, #0                         ; =0x0
	add	x23, x25, #24
LBB41_3:                                ; %bb2.i.i.i2
                                        ; =>This Inner Loop Header: Depth=1
	mov	x0, x22
	mov	x1, x23
	bl	_wf_ordered_cost_compare
	cmp	w0, #1
	b.lt	LBB41_7
; %bb.4:                                ; %bb8.i.i.i
                                        ;   in Loop: Header=BB41_3 Depth=1
	add	x21, x21, #1
	add	x23, x23, #280
	cmp	x24, x21
	b.ne	LBB41_3
; %bb.5:
	mov	x21, x24
	b	LBB41_10
LBB41_6:
	mov	x21, #0                         ; =0x0
LBB41_7:                                ; %"wf_std.collections.ordered_map.ordered_map_search$instance$43c0c30766ba2e8b.exit"
	cmp	x21, x24
	b.hs	LBB41_9
; %bb.8:                                ; %bb2.i
	mov	w8, #280                        ; =0x118
	madd	x20, x21, x8, x26
	add	x1, x20, #8
	mov	x0, x22
	bl	_wf_ordered_cost_compare
	cbz	w0, LBB41_17
LBB41_9:                                ; %bb1.i
	cbz	x21, LBB41_11
LBB41_10:                               ; %bb9.i
	mov	w8, #280                        ; =0x118
	madd	x8, x21, x8, x26
	sub	x1, x8, #8
	b	LBB41_12
LBB41_11:
	mov	x1, x25
LBB41_12:                               ; %bb7.i
	add	x20, sp, #576
	add	x0, sp, #576
	mov	x2, x22
	bl	_wf_std.collections.ordered_map.ordered_map_remove_link$instance$43c0c30766ba2e8b
	ldr	w8, [sp, #576]
	cbz	w8, LBB41_15
; %bb.13:                               ; %bb11.i
	mov	x0, x25
	mov	x1, x21
	bl	_wf_std.collections.ordered_map.ordered_map_repair_child$instance$d883f474bea0047c
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19], #8
	add	x1, x20, #8
LBB41_14:                               ; %"wf_std.collections.ordered_map.ordered_map_remove_node$instance$43c0c30766ba2e8b.exit"
	mov	x0, x19
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	b	LBB41_16
LBB41_15:                               ; %bb10.i
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #240]
	stp	q0, q0, [x19, #208]
	stp	q0, q0, [x19, #176]
	stp	q0, q0, [x19, #144]
	stp	q0, q0, [x19, #112]
	stp	q0, q0, [x19, #80]
	stp	q0, q0, [x19, #48]
	stp	q0, q0, [x19, #16]
	str	q0, [x19]
LBB41_16:                               ; %"wf_std.collections.ordered_map.ordered_map_remove_node$instance$43c0c30766ba2e8b.exit"
	add	sp, sp, #1120
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB41_17:                               ; %bb5.i
	str	x25, [sp, #32]                  ; 8-byte Folded Spill
	add	x27, sp, #576
	ldur	q1, [x20, #8]
	ldur	q2, [x20, #24]
	ldur	q3, [x20, #40]
	ldur	q0, [x20, #56]
	stp	q0, q3, [sp, #272]              ; 32-byte Folded Spill
	ldur	q3, [x20, #72]
	ldur	q0, [x20, #88]
	stp	q0, q3, [sp, #240]              ; 32-byte Folded Spill
	ldur	q3, [x20, #104]
	ldur	q0, [x20, #120]
	stp	q0, q3, [sp, #208]              ; 32-byte Folded Spill
	ldur	q0, [x20, #136]
	str	q0, [sp, #192]                  ; 16-byte Folded Spill
	ldur	q0, [x20, #152]
	stp	q2, q0, [sp, #160]              ; 32-byte Folded Spill
	ldur	q0, [x20, #168]
	stp	q1, q0, [sp, #128]              ; 32-byte Folded Spill
	ldur	q1, [x20, #184]
	ldur	q0, [x20, #200]
	stp	q0, q1, [sp, #96]               ; 32-byte Folded Spill
	ldur	q1, [x20, #216]
	mvn	x8, x21
	add	x8, x24, x8
	mov	w9, #280                        ; =0x118
	ldur	q0, [x20, #232]
	stp	q0, q1, [sp, #64]               ; 32-byte Folded Spill
	ldur	q0, [x20, #248]
	str	q0, [sp, #48]                   ; 16-byte Folded Spill
	madd	x11, x21, x9, x26
	mov	x10, x20
	ldp	x28, x20, [x20, #264]
	mul	x2, x8, x9
	ldr	x22, [x10, #280]
	stp	x11, x10, [sp, #16]             ; 16-byte Folded Spill
	add	x0, x10, #8
	add	x1, x11, #288
	bl	_memmove
	ldp	q23, q22, [sp, #48]             ; 32-byte Folded Reload
	ldp	q21, q20, [sp, #80]             ; 32-byte Folded Reload
	ldp	q19, q18, [sp, #112]            ; 32-byte Folded Reload
	ldp	q17, q16, [sp, #144]            ; 32-byte Folded Reload
	ldp	q7, q6, [sp, #176]              ; 32-byte Folded Reload
	ldp	q5, q4, [sp, #208]              ; 32-byte Folded Reload
	ldp	q3, q2, [sp, #240]              ; 32-byte Folded Reload
	ldp	q1, q0, [sp, #272]              ; 32-byte Folded Reload
	sub	x8, x24, #1
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	str	x8, [x26]
	add	x8, sp, #576
	add	x9, x8, #272
	str	x9, [sp, #40]                   ; 8-byte Folded Spill
	b	LBB41_20
LBB41_18:                               ; %"wf_append$instance$42f33d80f30f592c.exit.i.i.i"
                                        ;   in Loop: Header=BB41_20 Depth=1
	add	x20, x20, x26
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
LBB41_19:                               ; %"wf_std.collections.ordered_map.ordered_map_contract_root$instance$d883f474bea0047c.exit.i.i"
                                        ;   in Loop: Header=BB41_20 Depth=1
	str	x20, [sp, #840]
LBB41_20:                               ; %bb1.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stp	q18, q16, [x27]
	stp	q0, q1, [x27, #32]
	stp	q2, q3, [x27, #64]
	stp	q4, q5, [x27, #96]
	stp	q6, q7, [x27, #128]
	stp	q17, q19, [x27, #160]
	stp	q20, q21, [x27, #192]
	stp	q22, q23, [x27, #224]
	str	x28, [sp, #832]
	str	x20, [sp, #840]
	str	x22, [sp, #848]
	cbz	x20, LBB41_25
; %bb.21:                               ; %bb4.i.i
                                        ;   in Loop: Header=BB41_20 Depth=1
	ldr	x8, [x22, #16]
	cbnz	x8, LBB41_26
; %bb.22:                               ; %bb2.i.i.i
                                        ;   in Loop: Header=BB41_20 Depth=1
	sub	x26, x20, #1
	add	x23, x9, x26, lsl #3
	str	x26, [sp, #840]
	ldr	x0, [x23]
	ldr	x8, [x0, #16]
	cbnz	x8, LBB41_19
; %bb.23:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB41_20 Depth=1
	ldp	x20, x25, [x0]
	stp	q1, q0, [sp, #272]              ; 32-byte Folded Spill
	stp	q3, q2, [sp, #240]              ; 32-byte Folded Spill
	stp	q5, q4, [sp, #208]              ; 32-byte Folded Spill
	stp	q7, q6, [sp, #176]              ; 32-byte Folded Spill
	stp	q17, q16, [sp, #144]            ; 32-byte Folded Spill
	stp	q19, q18, [sp, #112]            ; 32-byte Folded Spill
	stp	q21, q20, [sp, #80]             ; 32-byte Folded Spill
	stp	q23, q22, [sp, #48]             ; 32-byte Folded Spill
	bl	_wf_cost_release
	ldp	q23, q22, [sp, #48]             ; 32-byte Folded Reload
	ldp	q21, q20, [sp, #80]             ; 32-byte Folded Reload
	ldp	q19, q18, [sp, #112]            ; 32-byte Folded Reload
	ldp	q17, q16, [sp, #144]            ; 32-byte Folded Reload
	ldp	q7, q6, [sp, #176]              ; 32-byte Folded Reload
	ldp	q5, q4, [sp, #208]              ; 32-byte Folded Reload
	ldp	q3, q2, [sp, #240]              ; 32-byte Folded Reload
	ldp	q1, q0, [sp, #272]              ; 32-byte Folded Reload
	str	x25, [sp, #856]
	cbz	x20, LBB41_18
; %bb.24:                               ; %run.move.body.v3.preheader.i.i.i.i
                                        ;   in Loop: Header=BB41_20 Depth=1
	lsl	x2, x20, #3
	add	x1, sp, #856
	mov	x0, x23
	bl	_memcpy
	ldp	q0, q1, [x27, #32]
	ldp	q2, q3, [x27, #64]
	ldp	q4, q5, [x27, #96]
	ldp	q6, q7, [x27, #128]
	ldp	q17, q19, [x27, #160]
	ldp	q20, q21, [x27, #192]
	ldp	q22, q23, [x27, #224]
	ldr	x28, [sp, #832]
	ldr	x22, [sp, #848]
	ldp	q18, q16, [x27]
	b	LBB41_18
LBB41_25:
	add	x23, sp, #576
	b	LBB41_27
LBB41_26:                               ; %bb6.i.i
	add	x23, sp, #312
	add	x0, sp, #312
	mov	x1, x22
	bl	_wf_std.collections.ordered_map.ordered_map_take_min$instance$d883f474bea0047c
	add	x0, sp, #856
	add	x1, sp, #312
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	x0, sp, #312
	add	x1, sp, #576
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	x0, sp, #576
	add	x1, sp, #856
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	sub	x8, x8, x21
	mov	w9, #280                        ; =0x118
	mul	x2, x8, x9
	ldp	x8, x22, [sp, #16]              ; 16-byte Folded Reload
	add	x0, x8, #288
	add	x1, x22, #8
	bl	_memmove
	ldr	x20, [sp, #32]                  ; 8-byte Folded Reload
	str	x24, [x20, #16]
	add	x0, x22, #8
	add	x1, sp, #576
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	add	x1, x21, #1
	mov	x0, x20
	bl	_wf_std.collections.ordered_map.ordered_map_repair_child$instance$d883f474bea0047c
LBB41_27:                               ; %"wf_std.collections.ordered_map.ordered_map_remove_item$instance$d883f474bea0047c.exit"
	add	x0, sp, #856
	mov	x1, x23
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19], #8
	add	x1, sp, #856
	b	LBB41_14
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_range_link$instance$475e4daed49f96af
_wf_std.collections.ordered_map.ordered_map_range_link$instance$475e4daed49f96af: ; @"wf_std.collections.ordered_map.ordered_map_range_link$instance$475e4daed49f96af"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB42_15
; %bb.1:                                ; %bb2
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x1
	ldr	x23, [x0, #8]
	ldr	x25, [x23, #16]
	cbz	x25, LBB42_6
; %bb.2:                                ; %bb2.lr.ph.i.i.i
	mov	x24, #0                         ; =0x0
	add	x22, x23, #24
LBB42_3:                                ; %bb2.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	mov	x0, x21
	mov	x1, x22
	bl	_wf_ordered_cost_compare
	cmp	w0, #1
	b.lt	LBB42_7
; %bb.4:                                ; %bb8.i.i.i
                                        ;   in Loop: Header=BB42_3 Depth=1
	add	x24, x24, #1
	add	x22, x22, #280
	cmp	x25, x24
	b.ne	LBB42_3
; %bb.5:
	mov	x24, x25
	b	LBB42_8
LBB42_6:
	mov	x24, #0                         ; =0x0
	b	LBB42_9
LBB42_7:                                ; %"wf_std.collections.ordered_map.ordered_map_search$instance$43c0c30766ba2e8b.exit"
	cbz	x24, LBB42_9
LBB42_8:                                ; %bb3.i
	mov	w8, #280                        ; =0x118
	madd	x8, x24, x8, x23
	add	x0, x8, #8
	b	LBB42_10
LBB42_9:
	mov	x0, x23
LBB42_10:                               ; %bb1.i
	mov	x1, x21
	mov	x2, x20
	mov	x3, x19
	bl	_wf_std.collections.ordered_map.ordered_map_range_link$instance$475e4daed49f96af
	ldr	x25, [x23, #16]
	cmp	x24, x25
	b.hs	LBB42_14
; %bb.11:                               ; %bb5.i.preheader
	mov	w8, #280                        ; =0x118
	madd	x8, x24, x8, x23
	add	x22, x8, #288
LBB42_12:                               ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	sub	x23, x22, #264
	mov	x0, x23
	mov	x1, x20
	bl	_wf_ordered_cost_compare
	tbz	w0, #31, LBB42_14
; %bb.13:                               ; %bb10.i
                                        ;   in Loop: Header=BB42_12 Depth=1
	sub	x2, x22, #256
	mov	x0, x19
	mov	x1, x23
	bl	_wf_ordered_cost_record_visit
	mov	x0, x22
	mov	x1, x21
	mov	x2, x20
	mov	x3, x19
	bl	_wf_std.collections.ordered_map.ordered_map_range_link$instance$475e4daed49f96af
	add	x24, x24, #1
	add	x22, x22, #280
	cmp	x25, x24
	b.ne	LBB42_12
LBB42_14:
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
LBB42_15:                               ; %bb1
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_each_link$instance$5703a7a9bf1884ed
_wf_std.collections.ordered_map.ordered_map_each_link$instance$5703a7a9bf1884ed: ; @"wf_std.collections.ordered_map.ordered_map_each_link$instance$5703a7a9bf1884ed"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB43_5
; %bb.1:                                ; %bb2
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	mov	x19, x1
	ldr	x20, [x0, #8]
	mov	x0, x20
	bl	_wf_std.collections.ordered_map.ordered_map_each_link$instance$5703a7a9bf1884ed
	ldr	x21, [x20, #16]
	cbz	x21, LBB43_4
; %bb.2:                                ; %bb2.i.preheader
	mov	x22, #0                         ; =0x0
	add	x20, x20, #288
LBB43_3:                                ; %bb2.i
                                        ; =>This Inner Loop Header: Depth=1
	sub	x1, x20, #264
	sub	x2, x20, #256
	mov	x0, x19
	bl	_wf_ordered_cost_record_visit
	mov	x0, x20
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_each_link$instance$5703a7a9bf1884ed
	add	x22, x22, #1
	add	x20, x20, #280
	cmp	x21, x22
	b.ne	LBB43_3
LBB43_4:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
LBB43_5:                                ; %bb1
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_free_link$instance$40650b236ee646e0
_wf_std.collections.ordered_map.ordered_map_free_link$instance$40650b236ee646e0: ; @"wf_std.collections.ordered_map.ordered_map_free_link$instance$40650b236ee646e0"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #384
	stp	x28, x27, [sp, #320]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #336]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #352]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #368]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 384
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w27, -56
	.cfi_offset w28, -64
	ldr	q0, [x0]
	str	q0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB44_8
; %bb.1:                                ; %bb2
	mov	x19, x1
	sub	x8, x8, #1
	mov	x9, sp
	add	x9, x9, x8, lsl #3
	str	x8, [sp]
	ldr	x20, [x9, #8]
	mov	x21, x20
	ldr	x8, [x21, #16]!
	cbz	x8, LBB44_4
; %bb.2:                                ; %bb5.i.preheader
	mov	w22, #280                       ; =0x118
LBB44_3:                                ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	sub	x8, x8, #1
	str	x8, [x21]
	madd	x8, x8, x22, x21
	ldr	x1, [x8, #8]
	ldp	q0, q1, [x8, #208]
	stp	q0, q1, [sp, #240]
	ldp	q0, q1, [x8, #240]
	stp	q0, q1, [sp, #272]
	ldp	q0, q1, [x8, #144]
	stp	q0, q1, [sp, #176]
	ldp	q0, q1, [x8, #176]
	stp	q0, q1, [sp, #208]
	ldp	q0, q1, [x8, #80]
	stp	q0, q1, [sp, #112]
	ldp	q0, q1, [x8, #112]
	stp	q0, q1, [sp, #144]
	ldp	q0, q1, [x8, #16]
	stp	q0, q1, [sp, #48]
	ldp	q0, q1, [x8, #48]
	stp	q0, q1, [sp, #80]
	ldr	q0, [x8, #272]
	str	q0, [sp, #304]
	add	x2, sp, #48
	mov	x0, x19
	bl	_wf_ordered_cost_record_consume
	add	x0, sp, #304
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_free_link$instance$40650b236ee646e0
	ldr	x8, [x21]
	cbnz	x8, LBB44_3
LBB44_4:                                ; %"wf_std.collections.ordered_map.ordered_map_free_node$instance$40650b236ee646e0.exit"
	str	xzr, [sp, #24]
	ldr	x21, [x20]
	cbz	x21, LBB44_6
; %bb.5:                                ; %run.move.body.v3.preheader.i
	lsl	x2, x21, #3
	add	x0, sp, #24
	add	x1, x20, #8
	bl	_memcpy
	ldr	x22, [sp, #24]
	b	LBB44_7
LBB44_6:
	mov	x22, #0                         ; =0x0
LBB44_7:                                ; %"wf_append$instance$42f33d80f30f592c.exit"
	str	xzr, [x20]
	mov	x0, x20
	bl	_wf_cost_release
	stp	x21, x22, [sp, #32]
	add	x0, sp, #32
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_free_link$instance$40650b236ee646e0
LBB44_8:                                ; %bb1
	ldp	x29, x30, [sp, #368]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #352]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #336]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #320]            ; 16-byte Folded Reload
	add	sp, sp, #384
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_repair_child$instance$0ed342445dd803f3
_wf_std.collections.ordered_map.ordered_map_repair_child$instance$0ed342445dd803f3: ; @"wf_std.collections.ordered_map.ordered_map_repair_child$instance$0ed342445dd803f3"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #144
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 144
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x21, x0
	ldr	x22, [x21, #16]!
	cbz	x22, LBB45_10
; %bb.1:                                ; %bb3
	cbz	x1, LBB45_6
; %bb.2:                                ; %bb6
	sub	x23, x1, #1
	add	x20, x21, x23, lsl #5
	ldr	x8, [x20, #24]
	cbz	x8, LBB45_10
; %bb.3:                                ; %bb14
	ldr	x8, [x20, #32]
	ldr	x8, [x8, #16]
	cmp	x8, #6
	b.hi	LBB45_10
; %bb.4:                                ; %bb17
	ldur	q0, [x20, #8]
	ldur	q1, [x20, #24]
	stp	q0, q1, [sp, #48]
	sub	x8, x22, x1
	lsl	x19, x8, #5
	mov	x24, x0
	add	x0, x20, #8
	add	x1, x20, #40
	mov	x2, x19
	bl	_memmove
	sub	x8, x22, #1
	str	x8, [x24, #16]
	sub	x8, x20, #8
	cmp	x23, #0
	csel	x1, x24, x8, eq
	add	x0, sp, #8
	add	x2, sp, #48
	bl	_wf_std.collections.ordered_map.ordered_map_repair_separator$instance$0ed342445dd803f3
	ldr	w8, [sp, #8]
	cbz	w8, LBB45_10
; %bb.5:                                ; %bb6.i18
	add	x0, x20, #40
	add	x1, x20, #8
	mov	x2, x19
	bl	_memmove
	str	x22, [x21]
	ldp	q0, q1, [sp, #16]
	stur	q1, [x20, #24]
	stur	q0, [x20, #8]
	b	LBB45_10
LBB45_6:                                ; %bb5
	ldr	x8, [x0]
	cbz	x8, LBB45_10
; %bb.7:                                ; %bb8
	ldr	x8, [x0, #8]
	ldr	x8, [x8, #16]
	cmp	x8, #6
	b.hi	LBB45_10
; %bb.8:                                ; %bb11
	ldur	q0, [x0, #24]
	ldur	q1, [x0, #40]
	stp	q0, q1, [sp, #48]
	sub	x23, x22, #1
	lsl	x19, x23, #5
	mov	x20, x0
	add	x0, x0, #24
	add	x1, x20, #56
	mov	x2, x19
	bl	_memmove
	str	x23, [x20, #16]
	add	x0, sp, #8
	add	x2, sp, #48
	mov	x23, x20
	mov	x1, x20
	bl	_wf_std.collections.ordered_map.ordered_map_repair_separator$instance$0ed342445dd803f3
	ldr	w8, [sp, #8]
	cbz	w8, LBB45_10
; %bb.9:                                ; %bb6.i
	add	x0, x23, #56
	add	x1, x23, #24
	mov	x2, x19
	bl	_memmove
	str	x22, [x21]
	ldp	q1, q0, [sp, #16]
	stur	q1, [x23, #24]
	stur	q0, [x23, #40]
LBB45_10:                               ; %common.ret
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_insert_item$instance$d883f474bea0047c
_wf_std.collections.ordered_map.ordered_map_insert_item$instance$d883f474bea0047c: ; @"wf_std.collections.ordered_map.ordered_map_insert_item$instance$d883f474bea0047c"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	mov	w9, #8960                       ; =0x2300
Lloh30:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh31:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #2, lsl #12             ; =8192
	sub	sp, sp, #768
	.cfi_def_cfa_offset 9056
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x3
	mov	x21, x2
	mov	x19, x0
	mov	x25, x1
	ldr	x27, [x25, #16]!
	cmp	x27, #14
	b.hi	LBB46_2
; %bb.1:                                ; %bb2
	sub	x8, x27, x21
	mov	w9, #280                        ; =0x118
	madd	x21, x21, x9, x25
	mul	x2, x8, x9
	add	x0, x21, #288
	add	x1, x21, #8
	bl	_memmove
	add	x8, x27, #1
	str	x8, [x25]
	add	x0, x21, #8
	mov	x1, x20
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	stp	q0, q0, [x19, #32]
	stp	q0, q0, [x19, #64]
	stp	q0, q0, [x19, #96]
	stp	q0, q0, [x19, #128]
	stp	q0, q0, [x19, #160]
	stp	q0, q0, [x19, #192]
	stp	q0, q0, [x19, #224]
	stp	q0, q0, [x19, #256]
	b	LBB46_10
LBB46_2:                                ; %bb3
	mov	x22, x1
	add	x26, sp, #1, lsl #12            ; =4096
	add	x26, x26, #376
	add	x0, x26, #1968
	mov	w1, #2240                       ; =0x8c0
	bl	_bzero
	mov	w8, #280                        ; =0x118
	mul	x28, x27, x8
	add	x23, x22, x28
	sub	x8, x27, #1
	sub	x1, x23, #256
	str	x8, [x22, #16]
	add	x0, x26, #8
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	sub	x8, x27, #2
	sub	x1, x23, #536
	str	x8, [x22, #16]
	add	x0, x26, #288
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	sub	x8, x27, #3
	sub	x1, x23, #816
	str	x8, [x22, #16]
	add	x0, x26, #568
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	sub	x8, x27, #4
	sub	x1, x23, #1096
	str	x8, [x22, #16]
	add	x0, x26, #848
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	sub	x8, x27, #5
	sub	x1, x23, #1376
	str	x8, [x22, #16]
	add	x0, x26, #1128
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	sub	x8, x27, #6
	sub	x1, x23, #1656
	str	x8, [x22, #16]
	add	x0, x26, #1408
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	sub	x24, x27, #7
	sub	x23, x23, #1936
	str	x24, [x22, #16]
	mov	w8, #7                          ; =0x7
	str	x8, [sp, #4472]
	add	x0, sp, #2, lsl #12             ; =8192
	add	x0, x0, #488
	add	x1, x26, #8
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	add	x0, x26, #8
	mov	x1, x23
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	add	x0, x26, #1688
	add	x1, sp, #2, lsl #12             ; =8192
	add	x1, x1, #488
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	add	x0, sp, #2, lsl #12             ; =8192
	add	x0, x0, #488
	add	x1, x26, #288
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	add	x0, x26, #288
	add	x1, x26, #1408
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	add	x0, x26, #1408
	add	x1, sp, #2, lsl #12             ; =8192
	add	x1, x1, #488
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	add	x0, sp, #2, lsl #12             ; =8192
	add	x0, x0, #488
	add	x1, x26, #568
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	add	x0, x26, #568
	add	x1, x26, #1128
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	add	x0, x26, #1128
	add	x1, sp, #2, lsl #12             ; =8192
	add	x1, x1, #488
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	sub	x23, x27, #8
	add	x8, x28, x25
	sub	x1, x8, #2232
	str	x23, [x22, #16]
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #96
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	cmp	x21, #8
	b.hs	LBB46_4
; %bb.3:                                ; %bb15
	sub	x8, x23, x21
	mov	w9, #280                        ; =0x118
	madd	x21, x21, x9, x25
	mul	x2, x8, x9
	add	x0, x21, #288
	add	x1, x21, #8
	bl	_memmove
	str	x24, [x25]
	add	x0, x21, #8
	b	LBB46_5
LBB46_4:                                ; %bb16
	mov	w8, #280                        ; =0x118
	mov	w9, #15                         ; =0xf
	sub	x9, x9, x21
	madd	x10, x21, x8, x26
	sub	x21, x10, #2232
	sub	x0, x10, #1952
	mul	x2, x9, x8
	mov	x1, x21
	bl	_memmove
	mov	w8, #8                          ; =0x8
	str	x8, [sp, #4472]
	mov	x0, x21
LBB46_5:                                ; %bb14
	mov	x1, x20
	mov	w2, #280                        ; =0x118
	bl	_memcpy
; %bb.6:                                ; %bb14
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #96
	add	x8, x8, #264
	str	x8, [sp, #4176]                 ; 8-byte Folded Spill
	str	xzr, [sp, #4184]
	ldr	x9, [sp, #4456]
	str	x9, [sp, #3168]                 ; 8-byte Folded Spill
	cbz	x9, LBB46_8
; %bb.7:                                ; %run.move.body.v3.preheader.i
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #96
	lsl	x2, x9, #3
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #88
	add	x1, x8, #272
	bl	_memcpy
	ldr	x8, [sp, #4184]
	str	x8, [sp, #3160]                 ; 8-byte Folded Spill
	b	LBB46_9
LBB46_8:
	str	xzr, [sp, #3160]                ; 8-byte Folded Spill
LBB46_9:                                ; %"wf_append$instance$42f33d80f30f592c.exit"
	str	xzr, [sp, #4456]
	ldr	x8, [sp, #4728]
	str	x8, [sp, #3200]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #4736]
	str	x8, [sp, #3192]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #4744]
	str	x8, [sp, #3184]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #4752]
	str	x8, [sp, #3176]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5016]
	str	x8, [sp, #3216]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5024]
	str	x8, [sp, #3208]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5032]
	str	x8, [sp, #3416]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5040]
	str	x8, [sp, #3408]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5048]
	str	x8, [sp, #3400]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5056]
	str	x8, [sp, #3392]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5064]
	str	x8, [sp, #3384]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5072]
	str	x8, [sp, #3376]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5080]
	str	x8, [sp, #3368]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5088]
	str	x8, [sp, #3360]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5096]
	str	x8, [sp, #3352]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5104]
	str	x8, [sp, #3344]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5112]
	str	x8, [sp, #3336]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5120]
	str	x8, [sp, #3328]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5128]
	str	x8, [sp, #3320]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5136]
	str	x8, [sp, #3312]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5144]
	str	x8, [sp, #3304]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5152]
	str	x8, [sp, #3296]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5160]
	str	x8, [sp, #3288]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5168]
	str	x8, [sp, #3280]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5176]
	str	x8, [sp, #3272]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5184]
	str	x8, [sp, #3264]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5192]
	str	x8, [sp, #3256]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5200]
	str	x8, [sp, #3248]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5208]
	str	x8, [sp, #3240]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5216]
	str	x8, [sp, #3232]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5224]
	str	x8, [sp, #3224]                 ; 8-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #121
	ldur	q0, [x8, #255]
	str	q0, [sp, #4160]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #137
	ldur	q0, [x8, #255]
	str	q0, [sp, #4144]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #153
	ldur	q0, [x8, #255]
	str	q0, [sp, #4128]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #169
	ldur	q0, [x8, #255]
	str	q0, [sp, #4112]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #185
	ldur	q0, [x8, #255]
	str	q0, [sp, #4096]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #201
	ldur	q0, [x8, #255]
	str	q0, [sp, #4080]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #217
	ldur	q0, [x8, #255]
	str	q0, [sp, #4064]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #233
	ldur	q0, [x8, #255]
	str	q0, [sp, #4032]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #249
	ldur	q0, [x8, #255]
	str	q0, [sp, #4016]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #265
	ldur	q0, [x8, #255]
	str	q0, [sp, #4000]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #281
	ldur	q0, [x8, #255]
	str	q0, [sp, #3984]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #297
	ldur	q0, [x8, #255]
	str	q0, [sp, #3968]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #313
	ldur	q0, [x8, #255]
	str	q0, [sp, #3952]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #329
	ldur	q0, [x8, #255]
	str	q0, [sp, #3712]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #345
	ldur	q0, [x8, #255]
	str	q0, [sp, #3696]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #361
	ldur	q0, [x8, #255]
	str	q0, [sp, #3680]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #409
	ldur	q0, [x8, #255]
	str	q0, [sp, #3664]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #425
	ldur	q0, [x8, #255]
	str	q0, [sp, #3648]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #441
	ldur	q0, [x8, #255]
	str	q0, [sp, #3632]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #457
	ldur	q0, [x8, #255]
	str	q0, [sp, #3616]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #473
	ldur	q0, [x8, #255]
	str	q0, [sp, #3600]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #489
	ldur	q0, [x8, #255]
	str	q0, [sp, #3584]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #505
	ldur	q0, [x8, #255]
	str	q0, [sp, #3568]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #521
	ldur	q0, [x8, #255]
	str	q0, [sp, #3552]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #537
	ldur	q0, [x8, #255]
	str	q0, [sp, #3536]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #553
	ldur	q0, [x8, #255]
	str	q0, [sp, #3520]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #569
	ldur	q0, [x8, #255]
	str	q0, [sp, #3504]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #585
	ldur	q0, [x8, #255]
	str	q0, [sp, #3488]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #601
	ldur	q0, [x8, #255]
	str	q0, [sp, #3472]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #617
	ldur	q0, [x8, #255]
	str	q0, [sp, #3456]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #633
	ldur	q0, [x8, #255]
	str	q0, [sp, #3440]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #649
	ldur	q0, [x8, #255]
	str	q0, [sp, #3424]                 ; 16-byte Folded Spill
	ldr	x8, [sp, #5232]
	str	x8, [sp, #3152]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5240]
	str	x8, [sp, #3144]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5248]
	str	x8, [sp, #3136]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5256]
	str	x8, [sp, #3128]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5264]
	str	x8, [sp, #3120]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5272]
	str	x8, [sp, #3112]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5280]
	str	x8, [sp, #3104]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5288]
	str	x8, [sp, #3096]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5296]
	str	x8, [sp, #3088]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5304]
	str	x8, [sp, #3080]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5312]
	str	x8, [sp, #3072]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5320]
	str	x8, [sp, #3064]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5328]
	str	x8, [sp, #3056]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5336]
	str	x8, [sp, #3048]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5344]
	str	x8, [sp, #3040]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5352]
	str	x8, [sp, #3032]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5360]
	str	x8, [sp, #3024]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5368]
	str	x8, [sp, #3016]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5376]
	str	x8, [sp, #3008]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5384]
	str	x8, [sp, #3000]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5392]
	str	x8, [sp, #2992]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5400]
	str	x8, [sp, #2984]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5408]
	str	x8, [sp, #2976]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5416]
	str	x8, [sp, #2968]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5424]
	str	x8, [sp, #2960]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5432]
	str	x8, [sp, #2952]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5440]
	str	x8, [sp, #2944]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5448]
	str	x8, [sp, #2936]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5456]
	str	x8, [sp, #2928]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5464]
	str	x8, [sp, #2920]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5472]
	str	x8, [sp, #2912]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5480]
	str	x8, [sp, #2904]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5488]
	str	x8, [sp, #2896]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5496]
	str	x8, [sp, #2888]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5504]
	str	x8, [sp, #2880]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5512]
	str	x8, [sp, #2872]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5520]
	str	x8, [sp, #2864]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5528]
	str	x8, [sp, #2856]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5536]
	str	x8, [sp, #2848]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5544]
	str	x8, [sp, #2840]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5552]
	str	x8, [sp, #2832]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5560]
	str	x8, [sp, #2824]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5568]
	str	x8, [sp, #2816]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5576]
	str	x8, [sp, #2808]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5584]
	str	x8, [sp, #2800]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5592]
	str	x8, [sp, #2792]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5600]
	str	x8, [sp, #2784]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5608]
	str	x8, [sp, #2776]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5616]
	str	x8, [sp, #2768]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5624]
	str	x8, [sp, #2760]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5632]
	str	x8, [sp, #2752]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5640]
	str	x8, [sp, #2744]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5648]
	str	x8, [sp, #2736]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5656]
	str	x8, [sp, #2728]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5664]
	str	x8, [sp, #2720]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5672]
	str	x8, [sp, #2712]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5680]
	str	x8, [sp, #2704]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5688]
	str	x8, [sp, #2696]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5696]
	str	x8, [sp, #2688]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5704]
	str	x8, [sp, #2680]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5712]
	str	x8, [sp, #2672]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5720]
	str	x8, [sp, #2664]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5728]
	str	x8, [sp, #2656]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5736]
	str	x8, [sp, #2648]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5744]
	str	x8, [sp, #2640]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5752]
	str	x8, [sp, #2632]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5760]
	str	x8, [sp, #2624]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5768]
	str	x8, [sp, #2616]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5776]
	str	x8, [sp, #2608]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5784]
	str	x8, [sp, #2600]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5792]
	str	x8, [sp, #2592]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5800]
	str	x8, [sp, #2584]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5808]
	str	x8, [sp, #2576]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5816]
	str	x8, [sp, #2568]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5824]
	str	x8, [sp, #2560]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5832]
	str	x8, [sp, #2552]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5840]
	str	x8, [sp, #2544]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5848]
	str	x8, [sp, #2536]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5856]
	str	x8, [sp, #2528]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5864]
	str	x8, [sp, #2520]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5872]
	str	x8, [sp, #2512]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5880]
	str	x8, [sp, #2504]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5888]
	str	x8, [sp, #2496]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5896]
	str	x8, [sp, #2488]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5904]
	str	x8, [sp, #2480]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5912]
	str	x8, [sp, #2472]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5920]
	str	x8, [sp, #2464]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5928]
	str	x8, [sp, #2456]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5936]
	str	x8, [sp, #2448]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5944]
	str	x8, [sp, #2440]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5952]
	str	x8, [sp, #2432]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5960]
	str	x8, [sp, #2424]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5968]
	str	x8, [sp, #2416]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5976]
	str	x8, [sp, #2408]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5984]
	str	x8, [sp, #2400]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5992]
	str	x8, [sp, #2392]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6000]
	str	x8, [sp, #2384]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6008]
	str	x8, [sp, #2376]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6016]
	str	x8, [sp, #2368]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6024]
	str	x8, [sp, #2360]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6032]
	str	x8, [sp, #2352]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6040]
	str	x8, [sp, #2344]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6048]
	str	x8, [sp, #2336]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6056]
	str	x8, [sp, #2328]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6064]
	str	x8, [sp, #2320]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6072]
	str	x8, [sp, #2312]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6080]
	str	x8, [sp, #2304]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6088]
	str	x8, [sp, #2296]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6096]
	str	x8, [sp, #2288]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6104]
	str	x8, [sp, #2280]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6112]
	str	x8, [sp, #2272]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6120]
	str	x8, [sp, #2264]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6128]
	str	x8, [sp, #2256]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6136]
	str	x8, [sp, #2248]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6144]
	str	x8, [sp, #2240]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6152]
	str	x8, [sp, #2232]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6160]
	str	x8, [sp, #2224]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6168]
	str	x8, [sp, #2216]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6176]
	str	x8, [sp, #2208]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6184]
	str	x8, [sp, #2200]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6192]
	str	x8, [sp, #2192]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6200]
	str	x8, [sp, #2184]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6208]
	str	x8, [sp, #2176]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6216]
	str	x8, [sp, #2168]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6224]
	str	x8, [sp, #2160]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6232]
	str	x8, [sp, #2152]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6240]
	str	x8, [sp, #2144]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6248]
	str	x8, [sp, #2136]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6256]
	str	x8, [sp, #2128]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6264]
	str	x8, [sp, #2120]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6272]
	str	x8, [sp, #2112]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6280]
	str	x8, [sp, #2104]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6288]
	str	x8, [sp, #2096]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6296]
	str	x8, [sp, #2088]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6304]
	str	x8, [sp, #2080]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6312]
	str	x8, [sp, #2072]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6320]
	str	x8, [sp, #2064]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6328]
	str	x8, [sp, #2056]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6336]
	str	x8, [sp, #2048]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6344]
	str	x8, [sp, #2040]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6352]
	str	x8, [sp, #2032]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6360]
	str	x8, [sp, #2024]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6368]
	str	x8, [sp, #2016]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6376]
	str	x8, [sp, #2008]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6384]
	str	x8, [sp, #2000]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6392]
	str	x8, [sp, #1992]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6400]
	str	x8, [sp, #1984]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6408]
	str	x8, [sp, #1976]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6416]
	str	x8, [sp, #1968]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6424]
	str	x8, [sp, #1960]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6432]
	str	x8, [sp, #1952]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6440]
	str	x8, [sp, #1944]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6448]
	str	x8, [sp, #1936]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6456]
	str	x8, [sp, #1928]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6464]
	str	x8, [sp, #1920]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6472]
	str	x8, [sp, #1912]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6480]
	str	x8, [sp, #1904]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6488]
	str	x8, [sp, #1896]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6496]
	str	x8, [sp, #1888]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6504]
	str	x8, [sp, #1880]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6512]
	str	x8, [sp, #1872]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6520]
	str	x8, [sp, #1864]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6528]
	str	x8, [sp, #1856]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6536]
	str	x8, [sp, #1848]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6544]
	str	x8, [sp, #1840]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6552]
	str	x8, [sp, #1832]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6560]
	str	x8, [sp, #1824]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6568]
	str	x8, [sp, #1816]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6576]
	str	x8, [sp, #1808]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6584]
	str	x8, [sp, #1800]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6592]
	str	x8, [sp, #1792]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6600]
	str	x8, [sp, #1784]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6608]
	str	x8, [sp, #1776]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6616]
	str	x8, [sp, #1768]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6624]
	str	x8, [sp, #1760]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6632]
	str	x8, [sp, #1752]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6640]
	str	x8, [sp, #1744]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6648]
	str	x8, [sp, #216]                  ; 8-byte Folded Spill
	ldr	x20, [sp, #6656]
	ldr	x21, [sp, #6664]
	ldr	x22, [sp, #6672]
	ldr	x23, [sp, #6680]
	ldr	x24, [sp, #6688]
	ldr	x9, [sp, #6696]
	ldr	x8, [sp, #6704]
	stp	x8, x9, [sp, #88]               ; 16-byte Folded Spill
	ldr	x9, [sp, #6712]
	ldr	x8, [sp, #6720]
	stp	x8, x9, [sp, #72]               ; 16-byte Folded Spill
	ldr	x9, [sp, #6728]
	ldr	x25, [sp, #6736]
	ldr	x26, [sp, #6744]
	ldr	x27, [sp, #6752]
	ldr	x28, [sp, #6760]
	ldr	x8, [sp, #6768]
	stp	x8, x9, [sp, #56]               ; 16-byte Folded Spill
	ldr	x9, [sp, #6776]
	ldr	x8, [sp, #6784]
	stp	x8, x9, [sp, #40]               ; 16-byte Folded Spill
	ldr	x9, [sp, #6792]
	ldr	x8, [sp, #6800]
	stp	x8, x9, [sp, #24]               ; 16-byte Folded Spill
	ldr	x8, [sp, #6808]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	ldr	x9, [sp, #6816]
	ldr	x8, [sp, #6824]
	stp	x8, x9, [sp, #200]              ; 16-byte Folded Spill
	ldr	x9, [sp, #6832]
	ldr	x8, [sp, #6840]
	stp	x8, x9, [sp, #184]              ; 16-byte Folded Spill
	ldr	x9, [sp, #6848]
	ldr	x8, [sp, #6856]
	stp	x8, x9, [sp, #168]              ; 16-byte Folded Spill
	ldr	x9, [sp, #6864]
	ldr	x8, [sp, #6872]
	stp	x8, x9, [sp, #152]              ; 16-byte Folded Spill
	ldr	x9, [sp, #6880]
	ldr	x8, [sp, #6888]
	stp	x8, x9, [sp, #136]              ; 16-byte Folded Spill
	ldr	x9, [sp, #6896]
	ldr	x8, [sp, #6904]
	stp	x8, x9, [sp, #120]              ; 16-byte Folded Spill
	ldr	x9, [sp, #6912]
	ldr	x8, [sp, #6920]
	stp	x8, x9, [sp, #104]              ; 16-byte Folded Spill
	ldr	x9, [sp, #6928]
	ldr	x8, [sp, #6936]
	stp	x8, x9, [sp, #240]              ; 16-byte Folded Spill
	ldr	x9, [sp, #6944]
	ldr	x8, [sp, #6952]
	stp	x8, x9, [sp, #224]              ; 16-byte Folded Spill
	ldr	x8, [sp, #6960]
	str	x8, [sp, #1736]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6968]
	str	x8, [sp, #1728]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6976]
	str	x8, [sp, #1720]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6984]
	str	x8, [sp, #1712]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6992]
	str	x8, [sp, #1704]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7000]
	str	x8, [sp, #1696]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7008]
	str	x8, [sp, #1688]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7016]
	str	x8, [sp, #1680]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7024]
	str	x8, [sp, #1672]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7032]
	str	x8, [sp, #1664]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7040]
	str	x8, [sp, #1656]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7048]
	str	x8, [sp, #1648]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7056]
	str	x8, [sp, #1640]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7064]
	str	x8, [sp, #1632]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7072]
	str	x8, [sp, #1624]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7080]
	str	x8, [sp, #1616]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7088]
	str	x8, [sp, #1608]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7096]
	str	x8, [sp, #1600]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7104]
	str	x8, [sp, #1592]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7112]
	str	x8, [sp, #1584]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7120]
	str	x8, [sp, #1576]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7128]
	str	x8, [sp, #1568]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7136]
	str	x8, [sp, #1560]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7144]
	str	x8, [sp, #1552]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7152]
	str	x8, [sp, #1544]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7160]
	str	x8, [sp, #1536]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7168]
	str	x8, [sp, #1528]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7176]
	str	x8, [sp, #1520]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7184]
	str	x8, [sp, #1512]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7192]
	str	x8, [sp, #1504]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7200]
	str	x8, [sp, #1496]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7208]
	str	x8, [sp, #1488]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7216]
	str	x8, [sp, #1480]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7224]
	str	x8, [sp, #1472]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7232]
	str	x8, [sp, #1464]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7240]
	str	x8, [sp, #1456]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7248]
	str	x8, [sp, #1448]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7256]
	str	x8, [sp, #1440]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7264]
	str	x8, [sp, #1432]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7272]
	str	x8, [sp, #1424]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7280]
	str	x8, [sp, #1416]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7288]
	str	x8, [sp, #1408]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7296]
	str	x8, [sp, #1400]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7304]
	str	x8, [sp, #1392]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7312]
	str	x8, [sp, #1384]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7320]
	str	x8, [sp, #1376]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7328]
	str	x8, [sp, #1368]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7336]
	str	x8, [sp, #1360]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7344]
	str	x8, [sp, #1352]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7352]
	str	x8, [sp, #1344]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7360]
	str	x8, [sp, #1336]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7368]
	str	x8, [sp, #1328]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7376]
	str	x8, [sp, #1320]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7384]
	str	x8, [sp, #1312]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7392]
	str	x8, [sp, #1304]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7400]
	str	x8, [sp, #1296]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7408]
	str	x8, [sp, #1288]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7416]
	str	x8, [sp, #1280]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7424]
	str	x8, [sp, #1272]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7432]
	str	x8, [sp, #1264]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7440]
	str	x8, [sp, #1256]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7448]
	str	x8, [sp, #1248]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7456]
	str	x8, [sp, #1240]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7464]
	str	x8, [sp, #1232]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7472]
	str	x8, [sp, #1224]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7480]
	str	x8, [sp, #1216]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7488]
	str	x8, [sp, #1208]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7496]
	str	x8, [sp, #1200]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7504]
	str	x8, [sp, #1192]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7512]
	str	x8, [sp, #1184]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7520]
	str	x8, [sp, #1176]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7528]
	str	x8, [sp, #1168]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7536]
	str	x8, [sp, #1160]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7544]
	str	x8, [sp, #1152]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7552]
	str	x8, [sp, #1144]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7560]
	str	x8, [sp, #1136]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7568]
	str	x8, [sp, #1128]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7576]
	str	x8, [sp, #1120]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7584]
	str	x8, [sp, #1112]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7592]
	str	x8, [sp, #1104]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7600]
	str	x8, [sp, #1096]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7608]
	str	x8, [sp, #1088]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7616]
	str	x8, [sp, #1080]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7624]
	str	x8, [sp, #1072]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7632]
	str	x8, [sp, #1064]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7640]
	str	x8, [sp, #1056]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7648]
	str	x8, [sp, #1048]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7656]
	str	x8, [sp, #1040]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7664]
	str	x8, [sp, #1032]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7672]
	str	x8, [sp, #1024]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7680]
	str	x8, [sp, #1016]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7688]
	str	x8, [sp, #1008]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7696]
	str	x8, [sp, #1000]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7704]
	str	x8, [sp, #992]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7712]
	str	x8, [sp, #984]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7720]
	str	x8, [sp, #976]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7728]
	str	x8, [sp, #968]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7736]
	str	x8, [sp, #960]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7744]
	str	x8, [sp, #952]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7752]
	str	x8, [sp, #944]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7760]
	str	x8, [sp, #936]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7768]
	str	x8, [sp, #928]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7776]
	str	x8, [sp, #920]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7784]
	str	x8, [sp, #912]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7792]
	str	x8, [sp, #904]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7800]
	str	x8, [sp, #896]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7808]
	str	x8, [sp, #888]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7816]
	str	x8, [sp, #880]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7824]
	str	x8, [sp, #872]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7832]
	str	x8, [sp, #864]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7840]
	str	x8, [sp, #856]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7848]
	str	x8, [sp, #848]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7856]
	str	x8, [sp, #840]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7864]
	str	x8, [sp, #832]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7872]
	str	x8, [sp, #824]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7880]
	str	x8, [sp, #816]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7888]
	str	x8, [sp, #808]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7896]
	str	x8, [sp, #800]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7904]
	str	x8, [sp, #792]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7912]
	str	x8, [sp, #784]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7920]
	str	x8, [sp, #776]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7928]
	str	x8, [sp, #768]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7936]
	str	x8, [sp, #760]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7944]
	str	x8, [sp, #752]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7952]
	str	x8, [sp, #744]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7960]
	str	x8, [sp, #736]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7968]
	str	x8, [sp, #728]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7976]
	str	x8, [sp, #720]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7984]
	str	x8, [sp, #712]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #7992]
	str	x8, [sp, #704]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #8000]
	str	x8, [sp, #696]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #8008]
	str	x8, [sp, #688]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #8016]
	str	x8, [sp, #680]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #8024]
	str	x8, [sp, #672]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #8032]
	str	x8, [sp, #664]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #8040]
	str	x8, [sp, #656]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #8048]
	str	x8, [sp, #648]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #8056]
	str	x8, [sp, #640]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #8064]
	str	x8, [sp, #632]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #8072]
	str	x8, [sp, #624]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #8080]
	str	x8, [sp, #616]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #8088]
	str	x8, [sp, #608]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #8096]
	str	x8, [sp, #600]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #8104]
	str	x8, [sp, #592]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #8112]
	str	x8, [sp, #584]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #8120]
	str	x8, [sp, #576]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #8128]
	str	x8, [sp, #568]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #8136]
	str	x8, [sp, #560]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #8144]
	str	x8, [sp, #552]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #8152]
	str	x8, [sp, #544]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #8160]
	str	x8, [sp, #536]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #8168]
	str	x8, [sp, #528]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #8176]
	str	x8, [sp, #520]                  ; 8-byte Folded Spill
	ldr	x9, [sp, #8184]
	ldr	x8, [sp, #8192]
	stp	x8, x9, [sp, #504]              ; 16-byte Folded Spill
	ldr	x9, [sp, #8200]
	ldr	x8, [sp, #8208]
	stp	x8, x9, [sp, #488]              ; 16-byte Folded Spill
	ldr	x9, [sp, #8216]
	ldr	x8, [sp, #8224]
	stp	x8, x9, [sp, #472]              ; 16-byte Folded Spill
	ldr	x9, [sp, #8232]
	ldr	x8, [sp, #8240]
	stp	x8, x9, [sp, #456]              ; 16-byte Folded Spill
	ldr	x9, [sp, #8248]
	ldr	x8, [sp, #8256]
	stp	x8, x9, [sp, #440]              ; 16-byte Folded Spill
	ldr	x9, [sp, #8264]
	ldr	x8, [sp, #8272]
	stp	x8, x9, [sp, #424]              ; 16-byte Folded Spill
	ldr	x9, [sp, #8280]
	ldr	x8, [sp, #8288]
	stp	x8, x9, [sp, #408]              ; 16-byte Folded Spill
	ldr	x9, [sp, #8296]
	ldr	x8, [sp, #8304]
	stp	x8, x9, [sp, #392]              ; 16-byte Folded Spill
	ldr	x9, [sp, #8312]
	ldr	x8, [sp, #8320]
	stp	x8, x9, [sp, #376]              ; 16-byte Folded Spill
	ldr	x9, [sp, #8328]
	ldr	x8, [sp, #8336]
	stp	x8, x9, [sp, #360]              ; 16-byte Folded Spill
	ldr	x9, [sp, #8344]
	ldr	x8, [sp, #8352]
	stp	x8, x9, [sp, #344]              ; 16-byte Folded Spill
	ldr	x9, [sp, #8360]
	ldr	x8, [sp, #8368]
	stp	x8, x9, [sp, #328]              ; 16-byte Folded Spill
	ldr	x9, [sp, #8376]
	ldr	x8, [sp, #8384]
	stp	x8, x9, [sp, #312]              ; 16-byte Folded Spill
	ldr	x9, [sp, #8392]
	ldr	x8, [sp, #8400]
	stp	x8, x9, [sp, #296]              ; 16-byte Folded Spill
	ldr	x9, [sp, #8408]
	ldr	x8, [sp, #8416]
	stp	x8, x9, [sp, #280]              ; 16-byte Folded Spill
	ldr	x9, [sp, #8424]
	ldr	x8, [sp, #8432]
	stp	x8, x9, [sp, #264]              ; 16-byte Folded Spill
	ldr	x8, [sp, #8440]
	str	x8, [sp, #256]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #8448]
	str	x8, [sp, #3944]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8456]
	str	x8, [sp, #3936]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8464]
	str	x8, [sp, #3928]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8472]
	str	x8, [sp, #3920]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8480]
	str	x8, [sp, #3912]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8488]
	str	x8, [sp, #3904]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8496]
	str	x8, [sp, #3896]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8504]
	str	x8, [sp, #3888]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8512]
	str	x8, [sp, #3880]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8520]
	str	x8, [sp, #3872]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8528]
	str	x8, [sp, #3864]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8536]
	str	x8, [sp, #3856]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8544]
	str	x8, [sp, #3848]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8552]
	str	x8, [sp, #3840]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8560]
	str	x8, [sp, #3832]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8568]
	str	x8, [sp, #3824]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8576]
	str	x8, [sp, #3816]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8584]
	str	x8, [sp, #3808]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8592]
	str	x8, [sp, #3800]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8600]
	str	x8, [sp, #3792]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8608]
	str	x8, [sp, #3784]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8616]
	str	x8, [sp, #3776]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8624]
	str	x8, [sp, #3768]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8632]
	str	x8, [sp, #3760]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8640]
	str	x8, [sp, #3752]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8648]
	str	x8, [sp, #3744]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8656]
	str	x8, [sp, #3736]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8664]
	str	x8, [sp, #3728]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #8672]
	str	x8, [sp, #4056]                 ; 8-byte Folded Spill
	mov	w0, #4224                       ; =0x1080
	bl	_wf_cost_allocate
	str	x20, [x0, #2200]
	str	x21, [x0, #2208]
	str	x22, [x0, #2216]
	str	x23, [x0, #2224]
	str	x24, [x0, #2232]
	ldr	x9, [sp, #3168]                 ; 8-byte Folded Reload
	ldr	x8, [sp, #3160]                 ; 8-byte Folded Reload
	stp	x9, x8, [x0]
	ldr	x8, [sp, #216]                  ; 8-byte Folded Reload
	str	x8, [x0, #2192]
	ldp	x8, x9, [sp, #88]               ; 16-byte Folded Reload
	str	x9, [x0, #2240]
	str	x8, [x0, #2248]
	ldp	x8, x9, [sp, #72]               ; 16-byte Folded Reload
	str	x9, [x0, #2256]
	str	x8, [x0, #2264]
	ldp	x8, x9, [sp, #56]               ; 16-byte Folded Reload
	str	x9, [x0, #2272]
	str	x25, [x0, #2280]
	str	x26, [x0, #2288]
	str	x27, [x0, #2296]
	str	x28, [x0, #2304]
	str	x8, [x0, #2312]
	ldp	x8, x9, [sp, #40]               ; 16-byte Folded Reload
	str	x9, [x0, #2320]
	str	x8, [x0, #2328]
	ldp	x8, x9, [sp, #24]               ; 16-byte Folded Reload
	str	x9, [x0, #2336]
	str	x8, [x0, #2344]
	ldr	x8, [sp, #16]                   ; 8-byte Folded Reload
	str	x8, [x0, #2352]
	ldr	x9, [sp, #3200]                 ; 8-byte Folded Reload
	ldr	x8, [sp, #3192]                 ; 8-byte Folded Reload
	stp	x9, x8, [x0, #272]
	ldr	x9, [sp, #3184]                 ; 8-byte Folded Reload
	ldr	x8, [sp, #3176]                 ; 8-byte Folded Reload
	stp	x9, x8, [x0, #288]
	ldp	x8, x9, [sp, #200]              ; 16-byte Folded Reload
	str	x9, [x0, #2360]
	str	x8, [x0, #2368]
	ldp	x8, x9, [sp, #184]              ; 16-byte Folded Reload
	str	x9, [x0, #2376]
	str	x8, [x0, #2384]
	ldp	x8, x9, [sp, #168]              ; 16-byte Folded Reload
	str	x9, [x0, #2392]
	str	x8, [x0, #2400]
	ldp	x8, x9, [sp, #152]              ; 16-byte Folded Reload
	str	x9, [x0, #2408]
	str	x8, [x0, #2416]
	ldp	x8, x9, [sp, #136]              ; 16-byte Folded Reload
	str	x9, [x0, #2424]
	str	x8, [x0, #2432]
	ldp	x8, x9, [sp, #120]              ; 16-byte Folded Reload
	str	x9, [x0, #2440]
	str	x8, [x0, #2448]
	ldp	x8, x9, [sp, #104]              ; 16-byte Folded Reload
	str	x9, [x0, #2456]
	str	x8, [x0, #2464]
	ldr	x8, [sp, #3216]                 ; 8-byte Folded Reload
	str	x8, [x0, #560]
	ldr	x8, [sp, #3208]                 ; 8-byte Folded Reload
	str	x8, [x0, #568]
	ldp	x8, x9, [sp, #240]              ; 16-byte Folded Reload
	str	x9, [x0, #2472]
	str	x8, [x0, #2480]
	ldp	x8, x9, [sp, #224]              ; 16-byte Folded Reload
	str	x9, [x0, #2488]
	str	x8, [x0, #2496]
	ldr	x8, [sp, #3416]                 ; 8-byte Folded Reload
	str	x8, [x0, #576]
	ldr	x8, [sp, #3408]                 ; 8-byte Folded Reload
	str	x8, [x0, #584]
	ldr	x8, [sp, #3400]                 ; 8-byte Folded Reload
	str	x8, [x0, #592]
	ldr	x8, [sp, #3392]                 ; 8-byte Folded Reload
	str	x8, [x0, #600]
	ldr	x8, [sp, #3384]                 ; 8-byte Folded Reload
	str	x8, [x0, #608]
	ldr	x8, [sp, #3376]                 ; 8-byte Folded Reload
	str	x8, [x0, #616]
	ldr	x8, [sp, #3368]                 ; 8-byte Folded Reload
	str	x8, [x0, #624]
	ldr	x8, [sp, #3360]                 ; 8-byte Folded Reload
	str	x8, [x0, #632]
	ldr	x8, [sp, #3352]                 ; 8-byte Folded Reload
	str	x8, [x0, #640]
	ldr	x8, [sp, #3344]                 ; 8-byte Folded Reload
	str	x8, [x0, #648]
	ldr	x8, [sp, #3336]                 ; 8-byte Folded Reload
	str	x8, [x0, #656]
	ldr	x8, [sp, #3328]                 ; 8-byte Folded Reload
	str	x8, [x0, #664]
	ldr	x8, [sp, #3320]                 ; 8-byte Folded Reload
	str	x8, [x0, #672]
	ldr	x8, [sp, #3312]                 ; 8-byte Folded Reload
	str	x8, [x0, #680]
	ldr	x8, [sp, #3304]                 ; 8-byte Folded Reload
	str	x8, [x0, #688]
	ldr	x8, [sp, #3296]                 ; 8-byte Folded Reload
	str	x8, [x0, #696]
	ldr	x8, [sp, #3288]                 ; 8-byte Folded Reload
	str	x8, [x0, #704]
	ldr	x8, [sp, #3280]                 ; 8-byte Folded Reload
	str	x8, [x0, #712]
	ldr	x8, [sp, #3272]                 ; 8-byte Folded Reload
	str	x8, [x0, #720]
	ldr	x8, [sp, #3264]                 ; 8-byte Folded Reload
	str	x8, [x0, #728]
	ldr	x8, [sp, #3256]                 ; 8-byte Folded Reload
	str	x8, [x0, #736]
	ldr	x8, [sp, #3248]                 ; 8-byte Folded Reload
	str	x8, [x0, #744]
	ldr	x8, [sp, #3240]                 ; 8-byte Folded Reload
	str	x8, [x0, #752]
	ldr	x8, [sp, #3232]                 ; 8-byte Folded Reload
	str	x8, [x0, #760]
	ldr	x8, [sp, #3224]                 ; 8-byte Folded Reload
	str	x8, [x0, #768]
	ldr	x8, [sp, #3152]                 ; 8-byte Folded Reload
	str	x8, [x0, #776]
	ldr	x8, [sp, #3144]                 ; 8-byte Folded Reload
	str	x8, [x0, #784]
	ldr	x8, [sp, #3136]                 ; 8-byte Folded Reload
	str	x8, [x0, #792]
	ldr	x8, [sp, #3128]                 ; 8-byte Folded Reload
	str	x8, [x0, #800]
	ldr	x8, [sp, #3120]                 ; 8-byte Folded Reload
	str	x8, [x0, #808]
	ldr	x8, [sp, #3112]                 ; 8-byte Folded Reload
	str	x8, [x0, #816]
	ldr	x8, [sp, #3104]                 ; 8-byte Folded Reload
	str	x8, [x0, #824]
	ldr	x8, [sp, #3096]                 ; 8-byte Folded Reload
	str	x8, [x0, #832]
	ldr	x8, [sp, #3088]                 ; 8-byte Folded Reload
	str	x8, [x0, #840]
	ldr	x8, [sp, #3080]                 ; 8-byte Folded Reload
	str	x8, [x0, #848]
	ldr	x8, [sp, #3072]                 ; 8-byte Folded Reload
	str	x8, [x0, #856]
	ldr	x8, [sp, #3064]                 ; 8-byte Folded Reload
	str	x8, [x0, #864]
	ldr	x8, [sp, #3056]                 ; 8-byte Folded Reload
	str	x8, [x0, #872]
	ldr	x8, [sp, #3048]                 ; 8-byte Folded Reload
	str	x8, [x0, #880]
	ldr	x8, [sp, #3040]                 ; 8-byte Folded Reload
	str	x8, [x0, #888]
	ldr	x8, [sp, #3032]                 ; 8-byte Folded Reload
	str	x8, [x0, #896]
	ldr	x8, [sp, #3024]                 ; 8-byte Folded Reload
	str	x8, [x0, #904]
	ldr	x8, [sp, #3016]                 ; 8-byte Folded Reload
	str	x8, [x0, #912]
	ldr	x8, [sp, #3008]                 ; 8-byte Folded Reload
	str	x8, [x0, #920]
	ldr	x8, [sp, #3000]                 ; 8-byte Folded Reload
	str	x8, [x0, #928]
	ldr	x8, [sp, #2992]                 ; 8-byte Folded Reload
	str	x8, [x0, #936]
	ldr	x8, [sp, #2984]                 ; 8-byte Folded Reload
	str	x8, [x0, #944]
	ldr	x8, [sp, #2976]                 ; 8-byte Folded Reload
	str	x8, [x0, #952]
	ldr	x8, [sp, #2968]                 ; 8-byte Folded Reload
	str	x8, [x0, #960]
	ldr	x8, [sp, #2960]                 ; 8-byte Folded Reload
	str	x8, [x0, #968]
	ldr	x8, [sp, #2952]                 ; 8-byte Folded Reload
	str	x8, [x0, #976]
	ldr	x8, [sp, #2944]                 ; 8-byte Folded Reload
	str	x8, [x0, #984]
	ldr	x8, [sp, #2936]                 ; 8-byte Folded Reload
	str	x8, [x0, #992]
	ldr	x8, [sp, #2928]                 ; 8-byte Folded Reload
	str	x8, [x0, #1000]
	ldr	x8, [sp, #2920]                 ; 8-byte Folded Reload
	str	x8, [x0, #1008]
	ldr	x8, [sp, #2912]                 ; 8-byte Folded Reload
	str	x8, [x0, #1016]
	ldr	x8, [sp, #2904]                 ; 8-byte Folded Reload
	str	x8, [x0, #1024]
	ldr	x8, [sp, #2896]                 ; 8-byte Folded Reload
	str	x8, [x0, #1032]
	ldr	x8, [sp, #2888]                 ; 8-byte Folded Reload
	str	x8, [x0, #1040]
	ldr	x8, [sp, #2880]                 ; 8-byte Folded Reload
	str	x8, [x0, #1048]
	ldr	x8, [sp, #2872]                 ; 8-byte Folded Reload
	str	x8, [x0, #1056]
	ldr	x8, [sp, #2864]                 ; 8-byte Folded Reload
	str	x8, [x0, #1064]
	ldr	x8, [sp, #2856]                 ; 8-byte Folded Reload
	str	x8, [x0, #1072]
	ldr	x8, [sp, #2848]                 ; 8-byte Folded Reload
	str	x8, [x0, #1080]
	ldr	x8, [sp, #2840]                 ; 8-byte Folded Reload
	str	x8, [x0, #1088]
	ldr	x8, [sp, #2832]                 ; 8-byte Folded Reload
	str	x8, [x0, #1096]
	ldr	x8, [sp, #2824]                 ; 8-byte Folded Reload
	str	x8, [x0, #1104]
	ldr	x8, [sp, #2816]                 ; 8-byte Folded Reload
	str	x8, [x0, #1112]
	ldr	x8, [sp, #2808]                 ; 8-byte Folded Reload
	str	x8, [x0, #1120]
	ldr	x8, [sp, #2800]                 ; 8-byte Folded Reload
	str	x8, [x0, #1128]
	ldr	x8, [sp, #2792]                 ; 8-byte Folded Reload
	str	x8, [x0, #1136]
	ldr	x8, [sp, #2784]                 ; 8-byte Folded Reload
	str	x8, [x0, #1144]
	ldr	x8, [sp, #2776]                 ; 8-byte Folded Reload
	str	x8, [x0, #1152]
	ldr	x8, [sp, #2768]                 ; 8-byte Folded Reload
	str	x8, [x0, #1160]
	ldr	x8, [sp, #2760]                 ; 8-byte Folded Reload
	str	x8, [x0, #1168]
	ldr	x8, [sp, #2752]                 ; 8-byte Folded Reload
	str	x8, [x0, #1176]
	ldr	x8, [sp, #2744]                 ; 8-byte Folded Reload
	str	x8, [x0, #1184]
	ldr	x8, [sp, #2736]                 ; 8-byte Folded Reload
	str	x8, [x0, #1192]
	ldr	x8, [sp, #2728]                 ; 8-byte Folded Reload
	str	x8, [x0, #1200]
	ldr	x8, [sp, #2720]                 ; 8-byte Folded Reload
	str	x8, [x0, #1208]
	ldr	x8, [sp, #2712]                 ; 8-byte Folded Reload
	str	x8, [x0, #1216]
	ldr	x8, [sp, #2704]                 ; 8-byte Folded Reload
	str	x8, [x0, #1224]
	ldr	x8, [sp, #2696]                 ; 8-byte Folded Reload
	str	x8, [x0, #1232]
	ldr	x8, [sp, #2688]                 ; 8-byte Folded Reload
	str	x8, [x0, #1240]
	ldr	x8, [sp, #2680]                 ; 8-byte Folded Reload
	str	x8, [x0, #1248]
	ldr	x8, [sp, #2672]                 ; 8-byte Folded Reload
	str	x8, [x0, #1256]
	ldr	x8, [sp, #2664]                 ; 8-byte Folded Reload
	str	x8, [x0, #1264]
	ldr	x8, [sp, #2656]                 ; 8-byte Folded Reload
	str	x8, [x0, #1272]
	ldr	x8, [sp, #2648]                 ; 8-byte Folded Reload
	str	x8, [x0, #1280]
	ldr	x8, [sp, #2640]                 ; 8-byte Folded Reload
	str	x8, [x0, #1288]
	ldr	x8, [sp, #2632]                 ; 8-byte Folded Reload
	str	x8, [x0, #1296]
	ldr	x8, [sp, #2624]                 ; 8-byte Folded Reload
	str	x8, [x0, #1304]
	ldr	x8, [sp, #2616]                 ; 8-byte Folded Reload
	str	x8, [x0, #1312]
	ldr	x8, [sp, #2608]                 ; 8-byte Folded Reload
	str	x8, [x0, #1320]
	ldr	x8, [sp, #2600]                 ; 8-byte Folded Reload
	str	x8, [x0, #1328]
	ldr	x8, [sp, #2592]                 ; 8-byte Folded Reload
	str	x8, [x0, #1336]
	ldr	x8, [sp, #2584]                 ; 8-byte Folded Reload
	str	x8, [x0, #1344]
	ldr	x8, [sp, #2576]                 ; 8-byte Folded Reload
	str	x8, [x0, #1352]
	ldr	x8, [sp, #2568]                 ; 8-byte Folded Reload
	str	x8, [x0, #1360]
	ldr	x8, [sp, #2560]                 ; 8-byte Folded Reload
	str	x8, [x0, #1368]
	ldr	x8, [sp, #2552]                 ; 8-byte Folded Reload
	str	x8, [x0, #1376]
	ldr	x8, [sp, #2544]                 ; 8-byte Folded Reload
	str	x8, [x0, #1384]
	ldr	x8, [sp, #2536]                 ; 8-byte Folded Reload
	str	x8, [x0, #1392]
	ldr	x8, [sp, #2528]                 ; 8-byte Folded Reload
	str	x8, [x0, #1400]
	ldr	x8, [sp, #2520]                 ; 8-byte Folded Reload
	str	x8, [x0, #1408]
	ldr	x8, [sp, #2512]                 ; 8-byte Folded Reload
	str	x8, [x0, #1416]
	ldr	x8, [sp, #2504]                 ; 8-byte Folded Reload
	str	x8, [x0, #1424]
	ldr	x8, [sp, #2496]                 ; 8-byte Folded Reload
	str	x8, [x0, #1432]
	ldr	x8, [sp, #2488]                 ; 8-byte Folded Reload
	str	x8, [x0, #1440]
	ldr	x8, [sp, #2480]                 ; 8-byte Folded Reload
	str	x8, [x0, #1448]
	ldr	x8, [sp, #2472]                 ; 8-byte Folded Reload
	str	x8, [x0, #1456]
	ldr	x8, [sp, #2464]                 ; 8-byte Folded Reload
	str	x8, [x0, #1464]
	ldr	x8, [sp, #2456]                 ; 8-byte Folded Reload
	str	x8, [x0, #1472]
	ldr	x8, [sp, #2448]                 ; 8-byte Folded Reload
	str	x8, [x0, #1480]
	ldr	x8, [sp, #2440]                 ; 8-byte Folded Reload
	str	x8, [x0, #1488]
	ldr	x8, [sp, #2432]                 ; 8-byte Folded Reload
	str	x8, [x0, #1496]
	ldr	x8, [sp, #2424]                 ; 8-byte Folded Reload
	str	x8, [x0, #1504]
	ldr	x8, [sp, #2416]                 ; 8-byte Folded Reload
	str	x8, [x0, #1512]
	ldr	x8, [sp, #2408]                 ; 8-byte Folded Reload
	str	x8, [x0, #1520]
	ldr	x8, [sp, #2400]                 ; 8-byte Folded Reload
	str	x8, [x0, #1528]
	ldr	x8, [sp, #2392]                 ; 8-byte Folded Reload
	str	x8, [x0, #1536]
	ldr	x8, [sp, #2384]                 ; 8-byte Folded Reload
	str	x8, [x0, #1544]
	ldr	x8, [sp, #2376]                 ; 8-byte Folded Reload
	str	x8, [x0, #1552]
	ldr	x8, [sp, #2368]                 ; 8-byte Folded Reload
	str	x8, [x0, #1560]
	ldr	x8, [sp, #2360]                 ; 8-byte Folded Reload
	str	x8, [x0, #1568]
	ldr	x8, [sp, #2352]                 ; 8-byte Folded Reload
	str	x8, [x0, #1576]
	ldr	x8, [sp, #2344]                 ; 8-byte Folded Reload
	str	x8, [x0, #1584]
	ldr	x8, [sp, #2336]                 ; 8-byte Folded Reload
	str	x8, [x0, #1592]
	ldr	x8, [sp, #2328]                 ; 8-byte Folded Reload
	str	x8, [x0, #1600]
	ldr	x8, [sp, #2320]                 ; 8-byte Folded Reload
	str	x8, [x0, #1608]
	ldr	x8, [sp, #2312]                 ; 8-byte Folded Reload
	str	x8, [x0, #1616]
	ldr	x8, [sp, #2304]                 ; 8-byte Folded Reload
	str	x8, [x0, #1624]
	ldr	x8, [sp, #2296]                 ; 8-byte Folded Reload
	str	x8, [x0, #1632]
	ldr	x8, [sp, #2288]                 ; 8-byte Folded Reload
	str	x8, [x0, #1640]
	ldr	x8, [sp, #2280]                 ; 8-byte Folded Reload
	str	x8, [x0, #1648]
	ldr	x8, [sp, #2272]                 ; 8-byte Folded Reload
	str	x8, [x0, #1656]
	ldr	x8, [sp, #2264]                 ; 8-byte Folded Reload
	str	x8, [x0, #1664]
	ldr	x8, [sp, #2256]                 ; 8-byte Folded Reload
	str	x8, [x0, #1672]
	ldr	x8, [sp, #2248]                 ; 8-byte Folded Reload
	str	x8, [x0, #1680]
	ldr	x8, [sp, #2240]                 ; 8-byte Folded Reload
	str	x8, [x0, #1688]
	ldr	x8, [sp, #2232]                 ; 8-byte Folded Reload
	str	x8, [x0, #1696]
	ldr	x8, [sp, #2224]                 ; 8-byte Folded Reload
	str	x8, [x0, #1704]
	ldr	x8, [sp, #2216]                 ; 8-byte Folded Reload
	str	x8, [x0, #1712]
	ldr	x8, [sp, #2208]                 ; 8-byte Folded Reload
	str	x8, [x0, #1720]
	ldr	x8, [sp, #2200]                 ; 8-byte Folded Reload
	str	x8, [x0, #1728]
	ldr	x8, [sp, #2192]                 ; 8-byte Folded Reload
	str	x8, [x0, #1736]
	ldr	x8, [sp, #2184]                 ; 8-byte Folded Reload
	str	x8, [x0, #1744]
	ldr	x8, [sp, #2176]                 ; 8-byte Folded Reload
	str	x8, [x0, #1752]
	ldr	x8, [sp, #2168]                 ; 8-byte Folded Reload
	str	x8, [x0, #1760]
	ldr	x8, [sp, #2160]                 ; 8-byte Folded Reload
	str	x8, [x0, #1768]
	ldr	x8, [sp, #2152]                 ; 8-byte Folded Reload
	str	x8, [x0, #1776]
	ldr	x8, [sp, #2144]                 ; 8-byte Folded Reload
	str	x8, [x0, #1784]
	ldr	x8, [sp, #2136]                 ; 8-byte Folded Reload
	str	x8, [x0, #1792]
	ldr	x8, [sp, #2128]                 ; 8-byte Folded Reload
	str	x8, [x0, #1800]
	ldr	x8, [sp, #2120]                 ; 8-byte Folded Reload
	str	x8, [x0, #1808]
	ldr	x8, [sp, #2112]                 ; 8-byte Folded Reload
	str	x8, [x0, #1816]
	ldr	x8, [sp, #2104]                 ; 8-byte Folded Reload
	str	x8, [x0, #1824]
	ldr	x8, [sp, #2096]                 ; 8-byte Folded Reload
	str	x8, [x0, #1832]
	ldr	x8, [sp, #2088]                 ; 8-byte Folded Reload
	str	x8, [x0, #1840]
	ldr	x8, [sp, #2080]                 ; 8-byte Folded Reload
	str	x8, [x0, #1848]
	ldr	x8, [sp, #2072]                 ; 8-byte Folded Reload
	str	x8, [x0, #1856]
	ldr	x8, [sp, #2064]                 ; 8-byte Folded Reload
	str	x8, [x0, #1864]
	ldr	x8, [sp, #2056]                 ; 8-byte Folded Reload
	str	x8, [x0, #1872]
	ldr	x8, [sp, #2048]                 ; 8-byte Folded Reload
	str	x8, [x0, #1880]
	ldr	x8, [sp, #2040]                 ; 8-byte Folded Reload
	str	x8, [x0, #1888]
	ldr	x8, [sp, #2032]                 ; 8-byte Folded Reload
	str	x8, [x0, #1896]
	ldr	x8, [sp, #2024]                 ; 8-byte Folded Reload
	str	x8, [x0, #1904]
	ldr	x8, [sp, #2016]                 ; 8-byte Folded Reload
	str	x8, [x0, #1912]
	ldr	x8, [sp, #2008]                 ; 8-byte Folded Reload
	str	x8, [x0, #1920]
	ldr	x8, [sp, #2000]                 ; 8-byte Folded Reload
	str	x8, [x0, #1928]
	ldr	x8, [sp, #1992]                 ; 8-byte Folded Reload
	str	x8, [x0, #1936]
	ldr	x8, [sp, #1984]                 ; 8-byte Folded Reload
	str	x8, [x0, #1944]
	ldr	x8, [sp, #1976]                 ; 8-byte Folded Reload
	str	x8, [x0, #1952]
	ldr	x8, [sp, #1968]                 ; 8-byte Folded Reload
	str	x8, [x0, #1960]
	ldr	x8, [sp, #1960]                 ; 8-byte Folded Reload
	str	x8, [x0, #1968]
	ldr	x8, [sp, #1952]                 ; 8-byte Folded Reload
	str	x8, [x0, #1976]
	ldr	x8, [sp, #1944]                 ; 8-byte Folded Reload
	str	x8, [x0, #1984]
	ldr	x8, [sp, #1936]                 ; 8-byte Folded Reload
	str	x8, [x0, #1992]
	ldr	x8, [sp, #1928]                 ; 8-byte Folded Reload
	str	x8, [x0, #2000]
	ldr	x8, [sp, #1920]                 ; 8-byte Folded Reload
	str	x8, [x0, #2008]
	ldr	x8, [sp, #1912]                 ; 8-byte Folded Reload
	str	x8, [x0, #2016]
	ldr	x8, [sp, #1904]                 ; 8-byte Folded Reload
	str	x8, [x0, #2024]
	ldr	x8, [sp, #1896]                 ; 8-byte Folded Reload
	str	x8, [x0, #2032]
	ldr	x8, [sp, #1888]                 ; 8-byte Folded Reload
	str	x8, [x0, #2040]
	ldr	x8, [sp, #1880]                 ; 8-byte Folded Reload
	str	x8, [x0, #2048]
	ldr	x8, [sp, #1872]                 ; 8-byte Folded Reload
	str	x8, [x0, #2056]
	ldr	x8, [sp, #1864]                 ; 8-byte Folded Reload
	str	x8, [x0, #2064]
	ldr	x8, [sp, #1856]                 ; 8-byte Folded Reload
	str	x8, [x0, #2072]
	ldr	x8, [sp, #1848]                 ; 8-byte Folded Reload
	str	x8, [x0, #2080]
	ldr	x8, [sp, #1840]                 ; 8-byte Folded Reload
	str	x8, [x0, #2088]
	ldr	x8, [sp, #1832]                 ; 8-byte Folded Reload
	str	x8, [x0, #2096]
	ldr	x8, [sp, #1824]                 ; 8-byte Folded Reload
	str	x8, [x0, #2104]
	ldr	x8, [sp, #1816]                 ; 8-byte Folded Reload
	str	x8, [x0, #2112]
	ldr	x8, [sp, #1808]                 ; 8-byte Folded Reload
	str	x8, [x0, #2120]
	ldr	x8, [sp, #1800]                 ; 8-byte Folded Reload
	str	x8, [x0, #2128]
	ldr	x8, [sp, #1792]                 ; 8-byte Folded Reload
	str	x8, [x0, #2136]
	ldr	x8, [sp, #1784]                 ; 8-byte Folded Reload
	str	x8, [x0, #2144]
	ldr	x8, [sp, #1776]                 ; 8-byte Folded Reload
	str	x8, [x0, #2152]
	ldr	x8, [sp, #1768]                 ; 8-byte Folded Reload
	str	x8, [x0, #2160]
	ldr	x8, [sp, #1760]                 ; 8-byte Folded Reload
	str	x8, [x0, #2168]
	ldr	x8, [sp, #1752]                 ; 8-byte Folded Reload
	str	x8, [x0, #2176]
	ldr	x8, [sp, #1744]                 ; 8-byte Folded Reload
	str	x8, [x0, #2184]
	ldr	x8, [sp, #1736]                 ; 8-byte Folded Reload
	str	x8, [x0, #2504]
	ldr	x8, [sp, #1728]                 ; 8-byte Folded Reload
	str	x8, [x0, #2512]
	ldr	x8, [sp, #1720]                 ; 8-byte Folded Reload
	str	x8, [x0, #2520]
	ldr	x8, [sp, #1712]                 ; 8-byte Folded Reload
	str	x8, [x0, #2528]
	ldr	x8, [sp, #1704]                 ; 8-byte Folded Reload
	str	x8, [x0, #2536]
	ldr	x8, [sp, #1696]                 ; 8-byte Folded Reload
	str	x8, [x0, #2544]
	ldr	x8, [sp, #1688]                 ; 8-byte Folded Reload
	str	x8, [x0, #2552]
	ldr	x8, [sp, #1680]                 ; 8-byte Folded Reload
	str	x8, [x0, #2560]
	ldr	x8, [sp, #1672]                 ; 8-byte Folded Reload
	str	x8, [x0, #2568]
	ldr	x8, [sp, #1664]                 ; 8-byte Folded Reload
	str	x8, [x0, #2576]
	ldr	x8, [sp, #1656]                 ; 8-byte Folded Reload
	str	x8, [x0, #2584]
	ldr	x8, [sp, #1648]                 ; 8-byte Folded Reload
	str	x8, [x0, #2592]
	ldr	x8, [sp, #1640]                 ; 8-byte Folded Reload
	str	x8, [x0, #2600]
	ldr	x8, [sp, #1632]                 ; 8-byte Folded Reload
	str	x8, [x0, #2608]
	ldr	x8, [sp, #1624]                 ; 8-byte Folded Reload
	str	x8, [x0, #2616]
	ldr	x8, [sp, #1616]                 ; 8-byte Folded Reload
	str	x8, [x0, #2624]
	ldr	x8, [sp, #1608]                 ; 8-byte Folded Reload
	str	x8, [x0, #2632]
	ldr	x8, [sp, #1600]                 ; 8-byte Folded Reload
	str	x8, [x0, #2640]
	ldr	x8, [sp, #1592]                 ; 8-byte Folded Reload
	str	x8, [x0, #2648]
	ldr	x8, [sp, #1584]                 ; 8-byte Folded Reload
	str	x8, [x0, #2656]
	ldr	x8, [sp, #1576]                 ; 8-byte Folded Reload
	str	x8, [x0, #2664]
	ldr	x8, [sp, #1568]                 ; 8-byte Folded Reload
	str	x8, [x0, #2672]
	ldr	x8, [sp, #1560]                 ; 8-byte Folded Reload
	str	x8, [x0, #2680]
	ldr	x8, [sp, #1552]                 ; 8-byte Folded Reload
	str	x8, [x0, #2688]
	ldr	x8, [sp, #1544]                 ; 8-byte Folded Reload
	str	x8, [x0, #2696]
	ldr	x8, [sp, #1536]                 ; 8-byte Folded Reload
	str	x8, [x0, #2704]
	ldr	x8, [sp, #1528]                 ; 8-byte Folded Reload
	str	x8, [x0, #2712]
	ldr	x8, [sp, #1520]                 ; 8-byte Folded Reload
	str	x8, [x0, #2720]
	ldr	x8, [sp, #1512]                 ; 8-byte Folded Reload
	str	x8, [x0, #2728]
	ldr	x8, [sp, #1504]                 ; 8-byte Folded Reload
	str	x8, [x0, #2736]
	ldr	x8, [sp, #1496]                 ; 8-byte Folded Reload
	str	x8, [x0, #2744]
	ldr	x8, [sp, #1488]                 ; 8-byte Folded Reload
	str	x8, [x0, #2752]
	ldr	x8, [sp, #1480]                 ; 8-byte Folded Reload
	str	x8, [x0, #2760]
	ldr	x8, [sp, #1472]                 ; 8-byte Folded Reload
	str	x8, [x0, #2768]
	ldr	x8, [sp, #1464]                 ; 8-byte Folded Reload
	str	x8, [x0, #2776]
	ldr	x8, [sp, #1456]                 ; 8-byte Folded Reload
	str	x8, [x0, #2784]
	ldr	x8, [sp, #1448]                 ; 8-byte Folded Reload
	str	x8, [x0, #2792]
	ldr	x8, [sp, #1440]                 ; 8-byte Folded Reload
	str	x8, [x0, #2800]
	ldr	x8, [sp, #1432]                 ; 8-byte Folded Reload
	str	x8, [x0, #2808]
	ldr	x8, [sp, #1424]                 ; 8-byte Folded Reload
	str	x8, [x0, #2816]
	ldr	x8, [sp, #1416]                 ; 8-byte Folded Reload
	str	x8, [x0, #2824]
	ldr	x8, [sp, #1408]                 ; 8-byte Folded Reload
	str	x8, [x0, #2832]
	ldr	x8, [sp, #1400]                 ; 8-byte Folded Reload
	str	x8, [x0, #2840]
	ldr	x8, [sp, #1392]                 ; 8-byte Folded Reload
	str	x8, [x0, #2848]
	ldr	x8, [sp, #1384]                 ; 8-byte Folded Reload
	str	x8, [x0, #2856]
	ldr	x8, [sp, #1376]                 ; 8-byte Folded Reload
	str	x8, [x0, #2864]
	ldr	x8, [sp, #1368]                 ; 8-byte Folded Reload
	str	x8, [x0, #2872]
	ldr	x8, [sp, #1360]                 ; 8-byte Folded Reload
	str	x8, [x0, #2880]
	ldr	x8, [sp, #1352]                 ; 8-byte Folded Reload
	str	x8, [x0, #2888]
	ldr	x8, [sp, #1344]                 ; 8-byte Folded Reload
	str	x8, [x0, #2896]
	ldr	x8, [sp, #1336]                 ; 8-byte Folded Reload
	str	x8, [x0, #2904]
	ldr	x8, [sp, #1328]                 ; 8-byte Folded Reload
	str	x8, [x0, #2912]
	ldr	x8, [sp, #1320]                 ; 8-byte Folded Reload
	str	x8, [x0, #2920]
	ldr	x8, [sp, #1312]                 ; 8-byte Folded Reload
	str	x8, [x0, #2928]
	ldr	x8, [sp, #1304]                 ; 8-byte Folded Reload
	str	x8, [x0, #2936]
	ldr	x8, [sp, #1296]                 ; 8-byte Folded Reload
	str	x8, [x0, #2944]
	ldr	x8, [sp, #1288]                 ; 8-byte Folded Reload
	str	x8, [x0, #2952]
	ldr	x8, [sp, #1280]                 ; 8-byte Folded Reload
	str	x8, [x0, #2960]
	ldr	x8, [sp, #1272]                 ; 8-byte Folded Reload
	str	x8, [x0, #2968]
	ldr	x8, [sp, #1264]                 ; 8-byte Folded Reload
	str	x8, [x0, #2976]
	ldr	x8, [sp, #1256]                 ; 8-byte Folded Reload
	str	x8, [x0, #2984]
	ldr	x8, [sp, #1248]                 ; 8-byte Folded Reload
	str	x8, [x0, #2992]
	ldr	x8, [sp, #1240]                 ; 8-byte Folded Reload
	str	x8, [x0, #3000]
	ldr	x8, [sp, #1232]                 ; 8-byte Folded Reload
	str	x8, [x0, #3008]
	ldr	x8, [sp, #1224]                 ; 8-byte Folded Reload
	str	x8, [x0, #3016]
	ldr	x8, [sp, #1216]                 ; 8-byte Folded Reload
	str	x8, [x0, #3024]
	ldr	x8, [sp, #1208]                 ; 8-byte Folded Reload
	str	x8, [x0, #3032]
	ldr	x8, [sp, #1200]                 ; 8-byte Folded Reload
	str	x8, [x0, #3040]
	ldr	x8, [sp, #1192]                 ; 8-byte Folded Reload
	str	x8, [x0, #3048]
	ldr	x8, [sp, #1184]                 ; 8-byte Folded Reload
	str	x8, [x0, #3056]
	ldr	x8, [sp, #1176]                 ; 8-byte Folded Reload
	str	x8, [x0, #3064]
	ldr	x8, [sp, #1168]                 ; 8-byte Folded Reload
	str	x8, [x0, #3072]
	ldr	x8, [sp, #1160]                 ; 8-byte Folded Reload
	str	x8, [x0, #3080]
	ldr	x8, [sp, #1152]                 ; 8-byte Folded Reload
	str	x8, [x0, #3088]
	ldr	x8, [sp, #1144]                 ; 8-byte Folded Reload
	str	x8, [x0, #3096]
	ldr	x8, [sp, #1136]                 ; 8-byte Folded Reload
	str	x8, [x0, #3104]
	ldr	x8, [sp, #1128]                 ; 8-byte Folded Reload
	str	x8, [x0, #3112]
	ldr	x8, [sp, #1120]                 ; 8-byte Folded Reload
	str	x8, [x0, #3120]
	ldr	x8, [sp, #1112]                 ; 8-byte Folded Reload
	str	x8, [x0, #3128]
	ldr	x8, [sp, #1104]                 ; 8-byte Folded Reload
	str	x8, [x0, #3136]
	ldr	x8, [sp, #1096]                 ; 8-byte Folded Reload
	str	x8, [x0, #3144]
	ldr	x8, [sp, #1088]                 ; 8-byte Folded Reload
	str	x8, [x0, #3152]
	ldr	x8, [sp, #1080]                 ; 8-byte Folded Reload
	str	x8, [x0, #3160]
	ldr	x8, [sp, #1072]                 ; 8-byte Folded Reload
	str	x8, [x0, #3168]
	ldr	x8, [sp, #1064]                 ; 8-byte Folded Reload
	str	x8, [x0, #3176]
	ldr	x8, [sp, #1056]                 ; 8-byte Folded Reload
	str	x8, [x0, #3184]
	ldr	x8, [sp, #1048]                 ; 8-byte Folded Reload
	str	x8, [x0, #3192]
	ldr	x8, [sp, #1040]                 ; 8-byte Folded Reload
	str	x8, [x0, #3200]
	ldr	x8, [sp, #1032]                 ; 8-byte Folded Reload
	str	x8, [x0, #3208]
	ldr	x8, [sp, #1024]                 ; 8-byte Folded Reload
	str	x8, [x0, #3216]
	ldr	x8, [sp, #1016]                 ; 8-byte Folded Reload
	str	x8, [x0, #3224]
	ldr	x8, [sp, #1008]                 ; 8-byte Folded Reload
	str	x8, [x0, #3232]
	ldr	x8, [sp, #1000]                 ; 8-byte Folded Reload
	str	x8, [x0, #3240]
	ldr	x8, [sp, #992]                  ; 8-byte Folded Reload
	str	x8, [x0, #3248]
	ldr	x8, [sp, #984]                  ; 8-byte Folded Reload
	str	x8, [x0, #3256]
	ldr	x8, [sp, #976]                  ; 8-byte Folded Reload
	str	x8, [x0, #3264]
	ldr	x8, [sp, #968]                  ; 8-byte Folded Reload
	str	x8, [x0, #3272]
	ldr	x8, [sp, #960]                  ; 8-byte Folded Reload
	str	x8, [x0, #3280]
	ldr	x8, [sp, #952]                  ; 8-byte Folded Reload
	str	x8, [x0, #3288]
	ldr	x8, [sp, #944]                  ; 8-byte Folded Reload
	str	x8, [x0, #3296]
	ldr	x8, [sp, #936]                  ; 8-byte Folded Reload
	str	x8, [x0, #3304]
	ldr	x8, [sp, #928]                  ; 8-byte Folded Reload
	str	x8, [x0, #3312]
	ldr	x8, [sp, #920]                  ; 8-byte Folded Reload
	str	x8, [x0, #3320]
	ldr	x8, [sp, #912]                  ; 8-byte Folded Reload
	str	x8, [x0, #3328]
	ldr	x8, [sp, #904]                  ; 8-byte Folded Reload
	str	x8, [x0, #3336]
	ldr	x8, [sp, #896]                  ; 8-byte Folded Reload
	str	x8, [x0, #3344]
	ldr	x8, [sp, #888]                  ; 8-byte Folded Reload
	str	x8, [x0, #3352]
	ldr	x8, [sp, #880]                  ; 8-byte Folded Reload
	str	x8, [x0, #3360]
	ldr	x8, [sp, #872]                  ; 8-byte Folded Reload
	str	x8, [x0, #3368]
	ldr	x8, [sp, #864]                  ; 8-byte Folded Reload
	str	x8, [x0, #3376]
	ldr	x8, [sp, #856]                  ; 8-byte Folded Reload
	str	x8, [x0, #3384]
	ldr	x8, [sp, #848]                  ; 8-byte Folded Reload
	str	x8, [x0, #3392]
	ldr	x8, [sp, #840]                  ; 8-byte Folded Reload
	str	x8, [x0, #3400]
	ldr	x8, [sp, #832]                  ; 8-byte Folded Reload
	str	x8, [x0, #3408]
	ldr	x8, [sp, #824]                  ; 8-byte Folded Reload
	str	x8, [x0, #3416]
	ldr	x8, [sp, #816]                  ; 8-byte Folded Reload
	str	x8, [x0, #3424]
	ldr	x8, [sp, #808]                  ; 8-byte Folded Reload
	str	x8, [x0, #3432]
	ldr	x8, [sp, #800]                  ; 8-byte Folded Reload
	str	x8, [x0, #3440]
	ldr	x8, [sp, #792]                  ; 8-byte Folded Reload
	str	x8, [x0, #3448]
	ldr	x8, [sp, #784]                  ; 8-byte Folded Reload
	str	x8, [x0, #3456]
	ldr	x8, [sp, #776]                  ; 8-byte Folded Reload
	str	x8, [x0, #3464]
	ldr	x8, [sp, #768]                  ; 8-byte Folded Reload
	str	x8, [x0, #3472]
	ldr	x8, [sp, #760]                  ; 8-byte Folded Reload
	str	x8, [x0, #3480]
	ldr	x8, [sp, #752]                  ; 8-byte Folded Reload
	str	x8, [x0, #3488]
	ldr	x8, [sp, #744]                  ; 8-byte Folded Reload
	str	x8, [x0, #3496]
	ldr	x8, [sp, #736]                  ; 8-byte Folded Reload
	str	x8, [x0, #3504]
	ldr	x8, [sp, #728]                  ; 8-byte Folded Reload
	str	x8, [x0, #3512]
	ldr	x8, [sp, #720]                  ; 8-byte Folded Reload
	str	x8, [x0, #3520]
	ldr	x8, [sp, #712]                  ; 8-byte Folded Reload
	str	x8, [x0, #3528]
	ldr	x8, [sp, #704]                  ; 8-byte Folded Reload
	str	x8, [x0, #3536]
	ldr	x8, [sp, #696]                  ; 8-byte Folded Reload
	str	x8, [x0, #3544]
	ldr	x8, [sp, #688]                  ; 8-byte Folded Reload
	str	x8, [x0, #3552]
	ldr	x8, [sp, #680]                  ; 8-byte Folded Reload
	str	x8, [x0, #3560]
	ldr	x8, [sp, #672]                  ; 8-byte Folded Reload
	str	x8, [x0, #3568]
	ldr	x8, [sp, #664]                  ; 8-byte Folded Reload
	str	x8, [x0, #3576]
	ldr	x8, [sp, #656]                  ; 8-byte Folded Reload
	str	x8, [x0, #3584]
	ldr	x8, [sp, #648]                  ; 8-byte Folded Reload
	str	x8, [x0, #3592]
	ldr	x8, [sp, #640]                  ; 8-byte Folded Reload
	str	x8, [x0, #3600]
	ldr	x8, [sp, #632]                  ; 8-byte Folded Reload
	str	x8, [x0, #3608]
	ldr	x8, [sp, #624]                  ; 8-byte Folded Reload
	str	x8, [x0, #3616]
	ldr	x8, [sp, #616]                  ; 8-byte Folded Reload
	str	x8, [x0, #3624]
	ldr	x8, [sp, #608]                  ; 8-byte Folded Reload
	str	x8, [x0, #3632]
	ldr	x8, [sp, #600]                  ; 8-byte Folded Reload
	str	x8, [x0, #3640]
	ldr	x8, [sp, #592]                  ; 8-byte Folded Reload
	str	x8, [x0, #3648]
	ldr	x8, [sp, #584]                  ; 8-byte Folded Reload
	str	x8, [x0, #3656]
	ldr	x8, [sp, #576]                  ; 8-byte Folded Reload
	str	x8, [x0, #3664]
	ldr	x8, [sp, #568]                  ; 8-byte Folded Reload
	str	x8, [x0, #3672]
	ldr	x8, [sp, #560]                  ; 8-byte Folded Reload
	str	x8, [x0, #3680]
	ldr	x8, [sp, #552]                  ; 8-byte Folded Reload
	str	x8, [x0, #3688]
	ldr	x8, [sp, #544]                  ; 8-byte Folded Reload
	str	x8, [x0, #3696]
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	str	x8, [x0, #3704]
	ldr	x8, [sp, #528]                  ; 8-byte Folded Reload
	str	x8, [x0, #3712]
	ldr	x8, [sp, #520]                  ; 8-byte Folded Reload
	str	x8, [x0, #3720]
	ldp	x8, x9, [sp, #504]              ; 16-byte Folded Reload
	str	x9, [x0, #3728]
	str	x8, [x0, #3736]
	ldp	x8, x9, [sp, #488]              ; 16-byte Folded Reload
	str	x9, [x0, #3744]
	str	x8, [x0, #3752]
	ldp	x8, x9, [sp, #472]              ; 16-byte Folded Reload
	str	x9, [x0, #3760]
	str	x8, [x0, #3768]
	ldp	x8, x9, [sp, #456]              ; 16-byte Folded Reload
	str	x9, [x0, #3776]
	str	x8, [x0, #3784]
	ldp	x8, x9, [sp, #440]              ; 16-byte Folded Reload
	str	x9, [x0, #3792]
	str	x8, [x0, #3800]
	ldp	x8, x9, [sp, #424]              ; 16-byte Folded Reload
	str	x9, [x0, #3808]
	str	x8, [x0, #3816]
	ldp	x8, x9, [sp, #408]              ; 16-byte Folded Reload
	str	x9, [x0, #3824]
	str	x8, [x0, #3832]
	ldp	x8, x9, [sp, #392]              ; 16-byte Folded Reload
	str	x9, [x0, #3840]
	str	x8, [x0, #3848]
	ldp	x8, x9, [sp, #376]              ; 16-byte Folded Reload
	str	x9, [x0, #3856]
	str	x8, [x0, #3864]
	ldp	x8, x9, [sp, #360]              ; 16-byte Folded Reload
	str	x9, [x0, #3872]
	str	x8, [x0, #3880]
	ldp	x8, x9, [sp, #344]              ; 16-byte Folded Reload
	str	x9, [x0, #3888]
	str	x8, [x0, #3896]
	ldp	x8, x9, [sp, #328]              ; 16-byte Folded Reload
	str	x9, [x0, #3904]
	str	x8, [x0, #3912]
	ldp	x8, x9, [sp, #312]              ; 16-byte Folded Reload
	str	x9, [x0, #3920]
	str	x8, [x0, #3928]
	ldp	x8, x9, [sp, #296]              ; 16-byte Folded Reload
	str	x9, [x0, #3936]
	str	x8, [x0, #3944]
	ldp	x8, x9, [sp, #280]              ; 16-byte Folded Reload
	str	x9, [x0, #3952]
	str	x8, [x0, #3960]
	ldp	x8, x9, [sp, #264]              ; 16-byte Folded Reload
	str	x9, [x0, #3968]
	str	x8, [x0, #3976]
	ldr	x8, [sp, #256]                  ; 8-byte Folded Reload
	str	x8, [x0, #3984]
	ldr	q1, [sp, #4144]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #4160]                 ; 16-byte Folded Reload
	stp	q0, q1, [x0, #16]
	ldr	q1, [sp, #4112]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #4128]                 ; 16-byte Folded Reload
	stp	q0, q1, [x0, #48]
	ldr	q1, [sp, #4080]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #4096]                 ; 16-byte Folded Reload
	stp	q0, q1, [x0, #80]
	ldr	q1, [sp, #4032]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #4064]                 ; 16-byte Folded Reload
	stp	q0, q1, [x0, #112]
	ldr	q1, [sp, #4000]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #4016]                 ; 16-byte Folded Reload
	stp	q0, q1, [x0, #144]
	ldr	q1, [sp, #3968]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3984]                 ; 16-byte Folded Reload
	stp	q0, q1, [x0, #176]
	ldr	q1, [sp, #3712]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3952]                 ; 16-byte Folded Reload
	stp	q0, q1, [x0, #208]
	ldr	q1, [sp, #3680]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3696]                 ; 16-byte Folded Reload
	stp	q0, q1, [x0, #240]
	ldr	q1, [sp, #3648]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3664]                 ; 16-byte Folded Reload
	stp	q0, q1, [x0, #304]
	ldr	q1, [sp, #3616]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3632]                 ; 16-byte Folded Reload
	stp	q0, q1, [x0, #336]
	ldr	q1, [sp, #3584]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3600]                 ; 16-byte Folded Reload
	stp	q0, q1, [x0, #368]
	ldr	q1, [sp, #3552]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3568]                 ; 16-byte Folded Reload
	stp	q0, q1, [x0, #400]
	ldr	q1, [sp, #3520]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3536]                 ; 16-byte Folded Reload
	stp	q0, q1, [x0, #432]
	ldr	q1, [sp, #3488]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3504]                 ; 16-byte Folded Reload
	stp	q0, q1, [x0, #464]
	ldr	q1, [sp, #3456]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3472]                 ; 16-byte Folded Reload
	stp	q0, q1, [x0, #496]
	ldr	q1, [sp, #3424]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3440]                 ; 16-byte Folded Reload
	stp	q0, q1, [x0, #528]
	ldr	x8, [sp, #3944]                 ; 8-byte Folded Reload
	str	x8, [x0, #3992]
	ldr	x8, [sp, #3936]                 ; 8-byte Folded Reload
	str	x8, [x0, #4000]
	ldr	x8, [sp, #3928]                 ; 8-byte Folded Reload
	str	x8, [x0, #4008]
	ldr	x8, [sp, #3920]                 ; 8-byte Folded Reload
	str	x8, [x0, #4016]
	ldr	x8, [sp, #3912]                 ; 8-byte Folded Reload
	str	x8, [x0, #4024]
	ldr	x8, [sp, #3904]                 ; 8-byte Folded Reload
	str	x8, [x0, #4032]
	ldr	x8, [sp, #3896]                 ; 8-byte Folded Reload
	str	x8, [x0, #4040]
	ldr	x8, [sp, #3888]                 ; 8-byte Folded Reload
	str	x8, [x0, #4048]
	ldr	x8, [sp, #3880]                 ; 8-byte Folded Reload
	str	x8, [x0, #4056]
	ldr	x8, [sp, #3872]                 ; 8-byte Folded Reload
	str	x8, [x0, #4064]
	ldr	x8, [sp, #3864]                 ; 8-byte Folded Reload
	str	x8, [x0, #4072]
	ldr	x8, [sp, #3856]                 ; 8-byte Folded Reload
	str	x8, [x0, #4080]
	ldr	x8, [sp, #3848]                 ; 8-byte Folded Reload
	str	x8, [x0, #4088]
	ldr	x8, [sp, #3840]                 ; 8-byte Folded Reload
	str	x8, [x0, #4096]
	ldr	x8, [sp, #3832]                 ; 8-byte Folded Reload
	str	x8, [x0, #4104]
	ldr	x8, [sp, #3824]                 ; 8-byte Folded Reload
	str	x8, [x0, #4112]
	ldr	x8, [sp, #3816]                 ; 8-byte Folded Reload
	str	x8, [x0, #4120]
	ldr	x8, [sp, #3808]                 ; 8-byte Folded Reload
	str	x8, [x0, #4128]
	ldr	x8, [sp, #3800]                 ; 8-byte Folded Reload
	str	x8, [x0, #4136]
	ldr	x8, [sp, #3792]                 ; 8-byte Folded Reload
	str	x8, [x0, #4144]
	ldr	x8, [sp, #3784]                 ; 8-byte Folded Reload
	str	x8, [x0, #4152]
	ldr	x8, [sp, #3776]                 ; 8-byte Folded Reload
	str	x8, [x0, #4160]
	ldr	x8, [sp, #3768]                 ; 8-byte Folded Reload
	str	x8, [x0, #4168]
	ldr	x8, [sp, #3760]                 ; 8-byte Folded Reload
	str	x8, [x0, #4176]
	ldr	x8, [sp, #3752]                 ; 8-byte Folded Reload
	str	x8, [x0, #4184]
	ldr	x8, [sp, #3744]                 ; 8-byte Folded Reload
	str	x8, [x0, #4192]
	ldr	x8, [sp, #3736]                 ; 8-byte Folded Reload
	str	x8, [x0, #4200]
	ldr	x8, [sp, #3728]                 ; 8-byte Folded Reload
	str	x8, [x0, #4208]
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19], #8
	ldr	x8, [sp, #4056]                 ; 8-byte Folded Reload
	str	x8, [x0, #4216]
	ldr	x8, [sp, #4456]
	ldr	x9, [sp, #4176]                 ; 8-byte Folded Reload
	add	x9, x9, x8, lsl #3
	str	x0, [x9, #8]
	add	x8, x8, #1
	str	x8, [sp, #4456]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #96
	mov	x0, x19
	mov	w2, #280                        ; =0x118
	bl	_memcpy
LBB46_10:                               ; %bb2
	add	sp, sp, #2, lsl #12             ; =8192
	add	sp, sp, #768
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
	.loh AdrpLdrGot	Lloh30, Lloh31
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_repair_child$instance$d883f474bea0047c
_wf_std.collections.ordered_map.ordered_map_repair_child$instance$d883f474bea0047c: ; @"wf_std.collections.ordered_map.ordered_map_repair_child$instance$d883f474bea0047c"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #576
	.cfi_def_cfa_offset 656
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x21, x0
	ldr	x22, [x21, #16]!
	cbz	x22, LBB47_11
; %bb.1:                                ; %bb3
	cbz	x1, LBB47_6
; %bb.2:                                ; %bb6
	sub	x23, x1, #1
	mov	w8, #280                        ; =0x118
	madd	x20, x23, x8, x21
	ldr	x8, [x20, #272]
	cbz	x8, LBB47_11
; %bb.3:                                ; %bb14
	ldr	x8, [x20, #280]
	ldr	x8, [x8, #16]
	cmp	x8, #6
	b.hi	LBB47_11
; %bb.4:                                ; %bb17
	mov	w19, #280                       ; =0x118
	mov	x24, x0
	add	x0, sp, #296
	mov	x25, x1
	add	x1, x20, #8
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	sub	x8, x22, x25
	mul	x19, x8, x19
	add	x0, x20, #8
	add	x1, x20, #288
	mov	x2, x19
	bl	_memmove
	sub	x8, x22, #1
	str	x8, [x24, #16]
	sub	x8, x20, #8
	cmp	x23, #0
	csel	x1, x24, x8, eq
	add	x23, sp, #8
	add	x0, sp, #8
	add	x2, sp, #296
	bl	_wf_std.collections.ordered_map.ordered_map_repair_separator$instance$d883f474bea0047c
	ldr	w8, [sp, #8]
	cbz	w8, LBB47_11
; %bb.5:                                ; %bb6.i18
	add	x0, x20, #288
	add	x1, x20, #8
	mov	x2, x19
	bl	_memmove
	str	x22, [x21]
	add	x0, x20, #8
	b	LBB47_10
LBB47_6:                                ; %bb5
	ldr	x8, [x0]
	cbz	x8, LBB47_11
; %bb.7:                                ; %bb8
	ldr	x8, [x0, #8]
	ldr	x8, [x8, #16]
	cmp	x8, #6
	b.hi	LBB47_11
; %bb.8:                                ; %bb11
	mov	w19, #280                       ; =0x118
	mov	x20, x0
	add	x0, sp, #296
	add	x1, x20, #24
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	sub	x23, x22, #1
	mul	x19, x23, x19
	add	x0, x20, #24
	add	x1, x20, #304
	mov	x2, x19
	bl	_memmove
	str	x23, [x20, #16]
	add	x23, sp, #8
	add	x0, sp, #8
	add	x2, sp, #296
	mov	x24, x20
	mov	x1, x20
	bl	_wf_std.collections.ordered_map.ordered_map_repair_separator$instance$d883f474bea0047c
	ldr	w8, [sp, #8]
	cbz	w8, LBB47_11
; %bb.9:                                ; %bb6.i
	add	x0, x24, #304
	add	x1, x24, #24
	mov	x2, x19
	bl	_memmove
	str	x22, [x21]
	add	x0, x24, #24
LBB47_10:                               ; %common.ret
	add	x1, x23, #8
	mov	w2, #280                        ; =0x118
	bl	_memcpy
LBB47_11:                               ; %common.ret
	add	sp, sp, #576
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_take_min$instance$0ed342445dd803f3
_wf_std.collections.ordered_map.ordered_map_take_min$instance$0ed342445dd803f3: ; @"wf_std.collections.ordered_map.ordered_map_take_min$instance$0ed342445dd803f3"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #160
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 160
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x0
	mov	x22, x0
	ldr	x8, [x22], #8
	cbnz	x8, LBB48_7
LBB48_1:                                ; %bb3.i
	mov	x23, x19
	ldp	x20, x21, [x23, #24]!
	ldp	x24, x25, [x23, #16]
	ldur	x8, [x23, #-8]
	sub	x26, x8, #1
	lsl	x2, x26, #5
	add	x1, x23, #32
	mov	x0, x23
	bl	_memmove
	stur	x26, [x23, #-8]
	str	x25, [sp, #8]
	cbz	x24, LBB48_3
; %bb.2:                                ; %run.move.body.v3.preheader.i
	lsl	x2, x24, #3
	add	x1, sp, #8
	mov	x0, x22
	bl	_memcpy
LBB48_3:                                ; %"wf_append$instance$48c61fa9751a6936.exit"
	str	x24, [x19]
LBB48_4:                                ; %"wf_std.collections.ordered_map.ordered_map_take_min$instance$0ed342445dd803f3.body.exit"
	mov	x0, x20
	mov	x1, x21
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB48_5:                                ; %"wf_append$instance$48c61fa9751a6936.exit.i"
                                        ;   in Loop: Header=BB48_7 Depth=1
	add	x8, x21, x20
LBB48_6:                                ; %"wf_std.collections.ordered_map.ordered_map_contract_root$instance$0ed342445dd803f3.exit"
                                        ;   in Loop: Header=BB48_7 Depth=1
	str	x8, [x19]
	cbz	x8, LBB48_1
LBB48_7:                                ; %bb4.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x23, [x22]
	ldr	x9, [x23, #16]
	cbnz	x9, LBB48_11
; %bb.8:                                ; %bb2.i
                                        ;   in Loop: Header=BB48_7 Depth=1
	sub	x20, x8, #1
	add	x9, x19, x20, lsl #3
	str	x20, [x19]
	ldr	x0, [x9, #8]
	ldr	x9, [x0, #16]
	cbnz	x9, LBB48_6
; %bb.9:                                ; %bb5.i
                                        ;   in Loop: Header=BB48_7 Depth=1
	ldp	x21, x23, [x0]
	bl	_wf_cost_release
	str	x23, [sp, #8]
	cbz	x21, LBB48_5
; %bb.10:                               ; %run.move.body.v3.preheader.i.i
                                        ;   in Loop: Header=BB48_7 Depth=1
	lsl	x2, x21, #3
	add	x0, x22, x20, lsl #3
	add	x1, sp, #8
	bl	_memcpy
	b	LBB48_5
LBB48_11:                               ; %bb6.i
	mov	x0, x23
	bl	_wf_std.collections.ordered_map.ordered_map_take_min$instance$0ed342445dd803f3
	mov	x20, x0
	mov	x21, x1
	ldr	x24, [x19, #16]
	cbz	x24, LBB48_4
; %bb.12:                               ; %bb8.i
	ldr	x8, [x23, #16]
	cmp	x8, #6
	b.hi	LBB48_4
; %bb.13:                               ; %bb11.i
	ldur	q0, [x19, #24]
	ldur	q1, [x19, #40]
	stp	q0, q1, [sp, #48]
	sub	x23, x24, #1
	lsl	x22, x23, #5
	add	x0, x19, #24
	add	x1, x19, #56
	mov	x2, x22
	bl	_memmove
	str	x23, [x19, #16]
	add	x0, sp, #8
	add	x2, sp, #48
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_repair_separator$instance$0ed342445dd803f3
	ldr	w8, [sp, #8]
	cbz	w8, LBB48_4
; %bb.14:                               ; %bb6.i.i
	add	x0, x19, #56
	add	x1, x19, #24
	mov	x2, x22
	bl	_memmove
	str	x24, [x19, #16]
	ldp	q1, q0, [sp, #16]
	stur	q1, [x19, #24]
	stur	q0, [x19, #40]
	b	LBB48_4
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_repair_separator$instance$0ed342445dd803f3
_wf_std.collections.ordered_map.ordered_map_repair_separator$instance$0ed342445dd803f3: ; @"wf_std.collections.ordered_map.ordered_map_repair_separator$instance$0ed342445dd803f3"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #240
	stp	x26, x25, [sp, #160]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #176]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #192]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #208]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #224]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 240
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	ldp	q0, q1, [x2]
	stp	q0, q1, [sp]
	ldr	x8, [x1]
	cbz	x8, LBB49_5
; %bb.1:                                ; %bb3
	ldr	x21, [sp, #16]
	cbz	x21, LBB49_6
; %bb.2:                                ; %bb6
	mov	x8, sp
	add	x8, x8, #16
	sub	x9, x21, #1
	add	x25, x8, x9, lsl #3
	str	x9, [sp, #16]
	ldr	x19, [x25, #8]
	ldr	x23, [x1, #8]
	mov	x20, x23
	ldr	x22, [x20, #16]!
	ldr	x26, [x19, #16]
	cmp	x22, #7
	b.hs	LBB49_8
; %bb.3:                                ; %bb8
	mov	x24, x0
	cmp	x26, #7
	b.ls	LBB49_15
; %bb.4:                                ; %bb11
	ldur	q0, [x19, #24]
	ldur	q1, [x19, #40]
	stp	q0, q1, [sp, #128]
	sub	x23, x26, #1
	lsl	x2, x23, #5
	add	x0, x19, #24
	add	x1, x19, #56
	bl	_memmove
	str	x23, [x19, #16]
	ldr	q0, [sp]
	ldp	q1, q2, [sp, #128]
	str	q1, [sp]
	ldr	q1, [x19]
	stp	q0, q1, [sp, #128]
	str	q2, [x19]
	add	x8, x20, x22, lsl #5
	ldp	q0, q1, [sp, #128]
	stur	q0, [x8, #8]
	stur	q1, [x8, #24]
	add	x8, x22, #1
	str	x8, [x20]
	b	LBB49_22
LBB49_5:                                ; %bb2
	ldp	q0, q1, [x2]
	stp	q0, q1, [sp, #64]
	b	LBB49_7
LBB49_6:                                ; %bb5
	ldp	q0, q1, [x2]
	stp	q0, q1, [sp, #32]
LBB49_7:                                ; %common.ret
	str	xzr, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	b	LBB49_24
LBB49_8:                                ; %bb9
	cmp	x26, #7
	b.hs	LBB49_23
; %bb.9:                                ; %bb14
	mov	x24, x0
	cmp	x22, #7
	b.ne	LBB49_21
; %bb.10:                               ; %bb18
	ldp	q1, q0, [sp]
	stp	q1, q0, [sp, #128]
	ldr	x21, [x19]
	ldr	x22, [sp, #144]
	cbz	x21, LBB49_12
; %bb.11:                               ; %run.move.body.v3.preheader.i.i33
	add	x8, sp, #128
	add	x8, x8, #16
	add	x8, x8, x22, lsl #3
	lsl	x2, x21, #3
	add	x0, x8, #8
	add	x1, x19, #8
	bl	_memcpy
LBB49_12:                               ; %"wf_append$instance$48c61fa9751a6936.exit.i36"
	add	x8, x22, x21
	str	xzr, [x19]
	str	x8, [sp, #144]
	add	x8, x23, #248
	ldp	q0, q1, [sp, #128]
	stur	q0, [x23, #248]
	str	q1, [x8, #16]
	ldr	x21, [x19, #16]
	cbz	x21, LBB49_14
; %bb.13:                               ; %run.move.body.v3.i.preheader.i46
	lsl	x2, x21, #5
	add	x0, x23, #280
	add	x1, x19, #24
	bl	_memcpy
LBB49_14:                               ; %"wf_std.collections.ordered_map.ordered_map_merge$instance$0ed342445dd803f3.exit51"
	add	x8, x21, #8
	b	LBB49_20
LBB49_15:                               ; %bb12
	ldp	q1, q0, [sp]
	stp	q1, q0, [sp, #128]
	ldr	x21, [x19]
	ldr	x25, [sp, #144]
	cbz	x21, LBB49_17
; %bb.16:                               ; %run.move.body.v3.preheader.i.i
	add	x8, sp, #128
	add	x8, x8, #16
	add	x8, x8, x25, lsl #3
	lsl	x2, x21, #3
	add	x0, x8, #8
	add	x1, x19, #8
	bl	_memcpy
LBB49_17:                               ; %"wf_append$instance$48c61fa9751a6936.exit.i"
	add	x8, x25, x21
	str	xzr, [x19]
	str	x8, [sp, #144]
	lsl	x8, x22, #5
	add	x9, x20, x8
	ldp	q0, q1, [sp, #128]
	stur	q0, [x9, #8]
	stur	q1, [x9, #24]
	ldr	x21, [x19, #16]
	cbz	x21, LBB49_19
; %bb.18:                               ; %run.move.body.v3.i.preheader.i
	add	x8, x23, x8
	lsl	x2, x21, #5
	add	x0, x8, #56
	add	x1, x19, #24
	bl	_memcpy
LBB49_19:                               ; %"wf_std.collections.ordered_map.ordered_map_merge$instance$0ed342445dd803f3.exit"
	add	x8, x22, x21
	add	x8, x8, #1
LBB49_20:                               ; %"wf_std.collections.ordered_map.ordered_map_merge$instance$0ed342445dd803f3.exit51"
	str	xzr, [x19, #16]
	str	x8, [x20]
	mov	x0, x19
	bl	_wf_cost_release
	str	xzr, [x24, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x24]
	b	LBB49_25
LBB49_21:                               ; %bb17
	sub	x8, x22, #1
	add	x9, x20, x8, lsl #5
	str	x8, [x20]
	ldr	q0, [sp]
	ldur	q1, [x9, #8]
	str	q1, [sp]
	ldr	q1, [x19]
	stp	q0, q1, [sp, #128]
	ldur	q0, [x9, #24]
	str	q0, [x19]
	lsl	x2, x26, #5
	add	x0, x19, #56
	add	x1, x19, #24
	bl	_memmove
	add	x8, x26, #1
	str	x8, [x19, #16]
	ldp	q0, q1, [sp, #128]
	stur	q0, [x19, #24]
	stur	q1, [x19, #40]
LBB49_22:                               ; %bb7
	mov	x0, x24
LBB49_23:                               ; %bb7
	str	x19, [x25, #8]
	str	x21, [sp, #16]
	str	xzr, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	ldp	q0, q1, [sp]
LBB49_24:                               ; %common.ret
	stur	q0, [x0, #8]
	stur	q1, [x0, #24]
LBB49_25:                               ; %common.ret
	ldp	x29, x30, [sp, #224]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #208]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #192]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #176]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #160]            ; 16-byte Folded Reload
	add	sp, sp, #240
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_take_min$instance$d883f474bea0047c
_wf_std.collections.ordered_map.ordered_map_take_min$instance$d883f474bea0047c: ; @"wf_std.collections.ordered_map.ordered_map_take_min$instance$d883f474bea0047c"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #368
	stp	x28, x27, [sp, #288]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #304]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #320]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #336]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #352]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 368
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	mov	x19, x1
	mov	x21, x0
	mov	x20, x1
	ldr	x8, [x20], #8
	cbnz	x8, LBB50_6
LBB50_1:                                ; %bb3
	add	x0, sp, #16
	add	x1, x19, #24
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	ldp	x22, x23, [x19, #288]
	ldr	x8, [x19, #16]
	sub	x24, x8, #1
	mov	w8, #280                        ; =0x118
	mul	x2, x24, x8
	add	x0, x19, #24
	add	x1, x19, #304
	bl	_memmove
	str	x24, [x19, #16]
	add	x1, sp, #16
	mov	x0, x21
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	str	x23, [sp, #8]
	cbz	x22, LBB50_3
; %bb.2:                                ; %run.move.body.v3.preheader.i
	lsl	x2, x22, #3
	add	x1, sp, #8
	mov	x0, x20
	bl	_memcpy
LBB50_3:                                ; %"wf_append$instance$42f33d80f30f592c.exit"
	str	x22, [x19]
	ldp	x29, x30, [sp, #352]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #336]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #320]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #304]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #288]            ; 16-byte Folded Reload
	add	sp, sp, #368
	ret
LBB50_4:                                ; %"wf_append$instance$42f33d80f30f592c.exit.i"
                                        ;   in Loop: Header=BB50_6 Depth=1
	add	x8, x23, x22
LBB50_5:                                ; %"wf_std.collections.ordered_map.ordered_map_contract_root$instance$d883f474bea0047c.exit"
                                        ;   in Loop: Header=BB50_6 Depth=1
	str	x8, [x19]
	cbz	x8, LBB50_1
LBB50_6:                                ; %bb4
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x1, [x20]
	ldr	x9, [x1, #16]
	cbnz	x9, LBB50_10
; %bb.7:                                ; %bb2.i
                                        ;   in Loop: Header=BB50_6 Depth=1
	sub	x22, x8, #1
	add	x9, x19, x22, lsl #3
	str	x22, [x19]
	ldr	x0, [x9, #8]
	ldr	x9, [x0, #16]
	cbnz	x9, LBB50_5
; %bb.8:                                ; %bb5.i
                                        ;   in Loop: Header=BB50_6 Depth=1
	ldp	x23, x24, [x0]
	bl	_wf_cost_release
	str	x24, [sp, #280]
	cbz	x23, LBB50_4
; %bb.9:                                ; %run.move.body.v3.preheader.i.i
                                        ;   in Loop: Header=BB50_6 Depth=1
	lsl	x2, x23, #3
	add	x0, x20, x22, lsl #3
	add	x1, sp, #280
	bl	_memcpy
	b	LBB50_4
LBB50_10:                               ; %bb6
	mov	x0, x21
	bl	_wf_std.collections.ordered_map.ordered_map_take_min$instance$d883f474bea0047c
	mov	x0, x19
	mov	x1, #0                          ; =0x0
	ldp	x29, x30, [sp, #352]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #336]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #320]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #304]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #288]            ; 16-byte Folded Reload
	add	sp, sp, #368
	b	_wf_std.collections.ordered_map.ordered_map_repair_child$instance$d883f474bea0047c
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_std.collections.ordered_map.ordered_map_repair_separator$instance$d883f474bea0047c
_wf_std.collections.ordered_map.ordered_map_repair_separator$instance$d883f474bea0047c: ; @"wf_std.collections.ordered_map.ordered_map_repair_separator$instance$d883f474bea0047c"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #1408
	.cfi_def_cfa_offset 1504
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x2
	mov	x21, x1
	mov	x19, x0
	mov	x23, sp
	mov	x0, sp
	mov	x1, x2
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	ldr	x8, [x21]
	cbz	x8, LBB51_5
; %bb.1:                                ; %bb3
	ldr	x22, [sp, #264]
	cbz	x22, LBB51_6
; %bb.2:                                ; %bb6
	add	x8, x23, #264
	sub	x9, x22, #1
	add	x24, x8, x9, lsl #3
	str	x9, [sp, #264]
	ldr	x20, [x24, #8]
	ldr	x25, [x21, #8]
	mov	x21, x25
	ldr	x23, [x21, #16]!
	ldr	x26, [x20, #16]
	cmp	x23, #7
	b.hs	LBB51_7
; %bb.3:                                ; %bb8
	cmp	x26, #7
	b.ls	LBB51_14
; %bb.4:                                ; %bb11
	mov	w25, #280                       ; =0x118
	add	x27, sp, #1128
	add	x0, sp, #1128
	add	x1, x20, #24
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	sub	x26, x26, #1
	mul	x2, x26, x25
	add	x0, x20, #24
	add	x1, x20, #304
	bl	_memmove
	str	x26, [x20, #16]
	add	x0, sp, #840
	add	x1, sp, #1128
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	x0, sp, #1128
	mov	x1, sp
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	mov	x0, sp
	add	x1, sp, #840
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	x8, x27, #264
	ldr	q0, [x8]
	ldr	q1, [x20]
	str	q1, [x8]
	str	q0, [x20]
	madd	x8, x23, x25, x21
	add	x0, x8, #8
	add	x1, sp, #1128
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	add	x8, x23, #1
	str	x8, [x21]
	b	LBB51_21
LBB51_5:                                ; %bb2
	add	x0, sp, #560
	mov	x1, x20
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19], #8
	add	x1, sp, #560
	b	LBB51_22
LBB51_6:                                ; %bb5
	add	x0, sp, #280
	mov	x1, x20
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19], #8
	add	x1, sp, #280
	b	LBB51_22
LBB51_7:                                ; %bb9
	cmp	x26, #7
	b.hs	LBB51_21
; %bb.8:                                ; %bb14
	cmp	x23, #7
	b.ne	LBB51_20
; %bb.9:                                ; %bb18
	add	x24, sp, #1128
	add	x0, sp, #1128
	mov	x1, sp
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	ldr	x22, [x20]
	ldr	x23, [sp, #1392]
	cbz	x22, LBB51_11
; %bb.10:                               ; %run.move.body.v3.preheader.i.i33
	add	x8, x24, #264
	add	x8, x8, x23, lsl #3
	lsl	x2, x22, #3
	add	x0, x8, #8
	add	x1, x20, #8
	bl	_memcpy
LBB51_11:                               ; %"wf_append$instance$42f33d80f30f592c.exit.i36"
	add	x8, x23, x22
	str	xzr, [x20]
	str	x8, [sp, #1392]
	add	x0, x25, #1984
	add	x1, sp, #1128
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	ldr	x22, [x20, #16]
	cbz	x22, LBB51_13
; %bb.12:                               ; %run.move.body.v3.i.preheader.i46
	mov	w8, #280                        ; =0x118
	mul	x2, x22, x8
	add	x0, x25, #2264
	add	x1, x20, #24
	bl	_memcpy
LBB51_13:                               ; %"wf_std.collections.ordered_map.ordered_map_merge$instance$d883f474bea0047c.exit51"
	add	x8, x22, #8
	b	LBB51_19
LBB51_14:                               ; %bb12
	add	x26, sp, #1128
	add	x0, sp, #1128
	mov	x1, sp
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	ldr	x22, [x20]
	ldr	x24, [sp, #1392]
	cbz	x22, LBB51_16
; %bb.15:                               ; %run.move.body.v3.preheader.i.i
	add	x8, x26, #264
	add	x8, x8, x24, lsl #3
	lsl	x2, x22, #3
	add	x0, x8, #8
	add	x1, x20, #8
	bl	_memcpy
LBB51_16:                               ; %"wf_append$instance$42f33d80f30f592c.exit.i"
	add	x8, x24, x22
	str	xzr, [x20]
	str	x8, [sp, #1392]
	mov	w8, #280                        ; =0x118
	mul	x24, x23, x8
	add	x8, x21, x24
	add	x0, x8, #8
	add	x1, sp, #1128
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	ldr	x22, [x20, #16]
	cbz	x22, LBB51_18
; %bb.17:                               ; %run.move.body.v3.i.preheader.i
	add	x8, x25, x24
	mov	w9, #280                        ; =0x118
	mul	x2, x22, x9
	add	x0, x8, #304
	add	x1, x20, #24
	bl	_memcpy
LBB51_18:                               ; %"wf_std.collections.ordered_map.ordered_map_merge$instance$d883f474bea0047c.exit"
	add	x8, x23, x22
	add	x8, x8, #1
LBB51_19:                               ; %"wf_std.collections.ordered_map.ordered_map_merge$instance$d883f474bea0047c.exit51"
	str	xzr, [x20, #16]
	str	x8, [x21]
	mov	x0, x20
	bl	_wf_cost_release
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #256]
	stp	q0, q0, [x19, #224]
	stp	q0, q0, [x19, #192]
	stp	q0, q0, [x19, #160]
	stp	q0, q0, [x19, #128]
	stp	q0, q0, [x19, #96]
	stp	q0, q0, [x19, #64]
	stp	q0, q0, [x19, #32]
	stp	q0, q0, [x19]
	b	LBB51_23
LBB51_20:                               ; %bb17
	sub	x8, x23, #1
	mov	w23, #280                       ; =0x118
	madd	x25, x8, x23, x21
	str	x8, [x21]
	add	x21, sp, #1128
	add	x0, sp, #1128
	mov	x1, sp
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	mov	x0, sp
	add	x1, x25, #8
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	x8, x21, #264
	ldr	q0, [x20]
	str	q0, [x8]
	ldr	q0, [x25, #272]
	str	q0, [x20]
	mul	x2, x26, x23
	add	x0, x20, #304
	add	x1, x20, #24
	bl	_memmove
	add	x8, x26, #1
	str	x8, [x20, #16]
	add	x0, x20, #24
	add	x1, sp, #1128
	mov	w2, #280                        ; =0x118
	bl	_memcpy
LBB51_21:                               ; %bb7
	str	x20, [x24, #8]
	str	x22, [sp, #264]
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19], #8
	mov	x1, sp
LBB51_22:                               ; %common.ret
	mov	x0, x19
	mov	w2, #280                        ; =0x118
	bl	_memcpy
LBB51_23:                               ; %common.ret
	add	sp, sp, #1408
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf__floor_run                  ; -- Begin function wf__floor_run
	.weak_definition	_wf__floor_run
	.p2align	2
_wf__floor_run:                         ; @wf__floor_run
	.cfi_startproc
; %bb.0:                                ; %entry
	b	_wf__main_body
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf__main_body
_wf__main_body:                         ; @wf__main_body
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	sub	sp, sp, #2640
	.cfi_def_cfa_offset 2704
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w27, -56
	.cfi_offset w28, -64
	add	x21, sp, #32
	add	x19, x21, #280
	bl	_wf_std.collections.ordered_map.ordered_map_new$instance$e85fc351f8333b14
	stp	x0, x1, [sp, #280]
	str	x2, [sp, #296]
	strb	wzr, [sp, #304]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	add	x0, x21, #248
	bl	_wf_std.collections.ordered_map.ordered_map_len$instance$e85fc351f8333b14
	mov	x20, x0
	str	x0, [sp, #312]
	add	x0, x21, #248
	bl	_wf_std.collections.ordered_map.ordered_map_len$instance$e85fc351f8333b14
	mov	w22, #131                       ; =0x83
	madd	x8, x20, x22, x0
	str	x8, [sp, #312]
	add	x0, x21, #248
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_each$instance$341ef9419761ecf9
	add	x8, sp, #25
	ldur	q0, [x8, #255]
	str	q0, [sp, #224]
	ldr	x8, [sp, #296]
	str	x8, [sp, #240]
	add	x0, x21, #192
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_free$instance$5b3375fb2964755f
	bl	_wf_std.collections.ordered_map.ordered_map_new$instance$a36c254d11d20619
	str	x0, [sp, #2544]
	str	x1, [sp, #2552]
	str	x2, [sp, #2560]
	strb	wzr, [sp, #2568]
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #2576]
	str	q0, [sp, #2592]
	add	x0, x21, #2512
	bl	_wf_std.collections.ordered_map.ordered_map_len$instance$a36c254d11d20619
	mov	x19, x0
	str	x0, [sp, #2576]
	add	x20, x21, #2456
	add	x0, x21, #2512
	bl	_wf_std.collections.ordered_map.ordered_map_len$instance$a36c254d11d20619
	madd	x8, x19, x22, x0
	str	x8, [sp, #2576]
	add	x0, x21, #2512
	add	x1, x21, #2544
	bl	_wf_std.collections.ordered_map.ordered_map_each$instance$960d100d77757702
	ldr	q0, [sp, #2544]
	str	q0, [x20]
	ldr	x8, [sp, #2560]
	str	x8, [sp, #2504]
	add	x1, x21, #2544
	mov	x0, x20
	bl	_wf_std.collections.ordered_map.ordered_map_free$instance$56a8ddd8129b5d48
	mov	x0, sp
	mov	w1, #0                          ; =0x0
	bl	_wf_std.process.exit_status
	mov	x0, sp
	bl	_wf__ordinary_exit_code
	and	w0, w0, #0xff
	add	sp, sp, #2640
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #64             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
.subsections_via_symbols
