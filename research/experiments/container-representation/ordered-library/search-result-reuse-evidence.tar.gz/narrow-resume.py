from pathlib import Path
import subprocess,json
p=Path(__file__).resolve().parent
statuses=[]
def run(label,cmd):
 q=subprocess.run(cmd,capture_output=True,text=True)
 (p/(label+'.stdout')).write_text(q.stdout)
 (p/(label+'.stderr')).write_text(q.stderr)
 statuses.append({'label':label,'command':cmd,'exit':q.returncode})
 (p/'narrow-status.json').write_text(json.dumps(statuses,indent=2))
 print(label,q.returncode,flush=True)
 if q.returncode:raise SystemExit(q.returncode)
 return q.stdout

import re
def lookup_bodies(path):
 result=[]
 for b in re.findall(r'^_wf_[^\n]+:.*?; -- End function',path.read_text(),re.M|re.S):
  if 'ordered_map_lookup' not in b.splitlines()[0]:continue
  code='\n'.join(line.split(';')[0].rstrip() for line in b.splitlines() if line.split(';')[0].strip())
  labs={v:f'BB{i}' for i,v in enumerate(re.findall(r'^(LBB\d+_\d+):',code,re.M))}
  for old in sorted(labs,key=len,reverse=True):code=re.sub(r'\b'+old+r'\b',labs[old],code)
  result.append(code)
 return result
prior=lookup_bodies(p/'prior-candidate.normal.screen.s');narrow=lookup_bodies(p/'lookup-only.normal.screen.s')
assert len(prior)==len(narrow)==2 and prior==narrow
(p/'lookup-only-normal-match.json').write_text(json.dumps({'lookup_bodies':2,'matches_prior_candidate':True}))
for arm in ['candidate']:
 b=p/'benchmark-control'
 for mode in ['normal','retained']:
  out=p/(arm+'-'+mode+'-narrow')
  inputs=[str(p/'ordered-costs-narrow.c')]+[str(f) for f in sorted(b.glob('control-*-'+mode+'.ll'))]+[str(b/('ordered-library-'+mode+'.ll') if arm=='control' else p/('lookup-only.'+mode+'.ll'))]+[str(f) for f in sorted((b/'native').rglob('*.o'))]
  cmd=['clang','-std=c11','-O2','-Wall','-Wextra','-Werror','-Wno-override-module']+(['-DRETAIN_PUBLIC'] if mode=='retained' else [])+inputs+['-pthread','-lm','-o',str(out)]
  run(arm+'-'+mode+'-narrow-build',cmd)
  run(arm+'-'+mode+'-narrow-check',[str(out),'check'])
  clock=run(arm+'-'+mode+'-narrow-clock',[str(out),'clock-resolution'])
  (p/(arm+'-'+mode+'-narrow-clock.csv')).write_text(clock)
for cohort,arms,command in [(0,['control','candidate'],'measure'),(1,['candidate','control'],'measure-reversed')]:
 for arm in arms:
  for mode in ['normal','retained']:
   stem=f'{arm}-{mode}-narrow-cohort{cohort}'
   output=run(stem,[str(p/(arm+'-'+mode+'-narrow')),command])
   (p/(stem+'.csv')).write_text(output)
