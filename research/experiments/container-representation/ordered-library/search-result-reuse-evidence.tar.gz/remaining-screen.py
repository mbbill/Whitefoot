from pathlib import Path
import subprocess,json
p=Path(__file__).resolve().parent
statuses=[]
def run(label,cmd):
 q=subprocess.run(cmd,capture_output=True,text=True)
 (p/(label+'.stdout')).write_text(q.stdout)
 (p/(label+'.stderr')).write_text(q.stderr)
 statuses.append({'label':label,'command':cmd,'exit':q.returncode})
 (p/'remaining-status.json').write_text(json.dumps(statuses,indent=2))
 print(label,q.returncode,flush=True)
 if q.returncode:raise SystemExit(q.returncode)
 return q.stdout
for arm in ['control','candidate']:
 b=p/('benchmark-'+arm)
 for mode in ['normal','retained']:
  out=p/(arm+'-'+mode+'-remaining')
  inputs=[str(p/'ordered-costs-remaining.c')]+[str(f) for f in sorted(b.glob('control-*-'+mode+'.ll'))]+[str(b/('ordered-library-'+mode+'.ll'))]+[str(f) for f in sorted((b/'native').rglob('*.o'))]
  cmd=['clang','-std=c11','-O2','-Wall','-Wextra','-Werror','-Wno-override-module']+(['-DRETAIN_PUBLIC'] if mode=='retained' else [])+inputs+['-pthread','-lm','-o',str(out)]
  run(arm+'-'+mode+'-remaining-build',cmd)
  run(arm+'-'+mode+'-remaining-check',[str(out),'check'])
  clock=run(arm+'-'+mode+'-remaining-clock',[str(out),'clock-resolution'])
  (p/(arm+'-'+mode+'-remaining-clock.csv')).write_text(clock)
for cohort,arms,command in [(0,['control','candidate'],'measure'),(1,['candidate','control'],'measure-reversed')]:
 for arm in arms:
  for mode in ['normal','retained']:
   stem=f'{arm}-{mode}-remaining-cohort{cohort}'
   output=run(stem,[str(p/(arm+'-'+mode+'-remaining')),command])
   (p/(stem+'.csv')).write_text(output)
