_wf_collections.ordered_map.ordered_map_lookup_node$instance$11eb30e8dabe0f7e: ; @"wf_collections.ordered_map.ordered_map_lookup_node$instance$11eb30e8dabe0f7e"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x8, x0
	ldr	x10, [x8, #16]!
	cbz	x10, LBB74_5
; %bb.1:                                ; %bb2.lr.ph.i
	mov	x9, #0                          ; =0x0
	add	x11, x0, #24
	ldr	x12, [x1]
LBB74_2:                                ; %bb2.i25
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x13, [x11], #32
	cmp	x12, x13
	b.ls	LBB74_6
; %bb.3:                                ; %bb8.i31
                                        ;   in Loop: Header=BB74_2 Depth=1
	add	x9, x9, #1
	cmp	x10, x9
	b.ne	LBB74_2
; %bb.4:
	mov	x9, x10
	b	LBB74_10
LBB74_5:
	mov	x9, #0                          ; =0x0
LBB74_6:                                ; %"wf_collections.ordered_map.ordered_map_search$instance$5046b787ff5cdb3f.exit"
	cmp	x9, x10
	b.hs	LBB74_9
; %bb.7:                                ; %bb2.i
	add	x10, x8, x9, lsl #5
	ldr	x11, [x1]
	ldr	x12, [x10, #8]
	cmp	x11, x12
	b.ne	LBB74_9
; %bb.8:                                ; %bb5.i
	mov	w0, #0                          ; =0x0
	mov	w8, #131                        ; =0x83
	ldr	x9, [x10, #16]
	madd	x1, x11, x8, x9
	ldr	x9, [x3]
	madd	x8, x9, x8, x1
	str	x8, [x3]
	b	LBB74_16
LBB74_9:                                ; %bb1.i
	cbz	x9, LBB74_12
LBB74_10:                               ; %bb9.i
	add	x8, x8, x9, lsl #5
	ldur	x9, [x8, #-8]
	cbz	x9, LBB74_15
; %bb.11:                               ; %bb2.i.i
	ldr	x0, [x8]
	b	LBB74_14
LBB74_12:                               ; %bb8.i
	ldr	x8, [x0]
	cbz	x8, LBB74_15
; %bb.13:                               ; %bb2.i.i16
	ldr	x0, [x0, #8]
LBB74_14:                               ; %"wf_collections.ordered_map.ordered_map_lookup_node$instance$11eb30e8dabe0f7e.body.exit"
	bl	_wf_collections.ordered_map.ordered_map_lookup_node$instance$11eb30e8dabe0f7e
	b	LBB74_16
LBB74_15:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
LBB74_16:                               ; %"wf_collections.ordered_map.ordered_map_lookup_node$instance$11eb30e8dabe0f7e.body.exit"
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function