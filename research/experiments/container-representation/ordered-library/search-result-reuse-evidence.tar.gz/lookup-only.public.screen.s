	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function wf_resource_record_abort
l_wf_resource_record_abort:             ; @wf_resource_record_abort
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
Lloh0:
	adrp	x19, l_.wf_resource.heap@PAGE
Lloh1:
	add	x19, x19, l_.wf_resource.heap@PAGEOFF
	mov	w20, #20                        ; =0x14
	b	LBB0_2
LBB0_1:                                 ; %error.i
                                        ;   in Loop: Header=BB0_2 Depth=1
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #4
	b.ne	LBB0_6
LBB0_2:                                 ; %write.i
                                        ; =>This Inner Loop Header: Depth=1
	mov	w0, #2                          ; =0x2
	mov	x1, x19
	mov	x2, x20
	bl	_write
	tbnz	x0, #63, LBB0_1
; %bb.3:                                ; %wf_resource_write.exit
                                        ;   in Loop: Header=BB0_2 Depth=1
	subs	x20, x20, x0
	b.eq	LBB0_6
; %bb.4:                                ; %wf_resource_write.exit
                                        ;   in Loop: Header=BB0_2 Depth=1
	cbz	x0, LBB0_6
; %bb.5:                                ; %write.more
                                        ;   in Loop: Header=BB0_2 Depth=1
	add	x19, x19, x0
	b	LBB0_2
LBB0_6:                                 ; %abort
	bl	_abort
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_resource_abort
l_wf_resource_abort:                    ; @wf_resource_abort
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	l_wf_resource_record_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_ordered_cost_mix            ; -- Begin function wf_ordered_cost_mix
	.p2align	2
_wf_ordered_cost_mix:                   ; @wf_ordered_cost_mix
; %bb.0:                                ; %entry
	eor	x8, x0, x0, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	eor	x0, x8, x8, lsr #31
	ret
                                        ; -- End function
	.globl	_wf_ordered_cost_ordered        ; -- Begin function wf_ordered_cost_ordered
	.p2align	2
_wf_ordered_cost_ordered:               ; @wf_ordered_cost_ordered
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	mov	w9, #131                        ; =0x83
	madd	x8, x8, x9, x1
	str	x8, [x0]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_ordered_cost_consumed       ; -- Begin function wf_ordered_cost_consumed
	.p2align	2
_wf_ordered_cost_consumed:              ; @wf_ordered_cost_consumed
; %bb.0:                                ; %entry
	ldp	x8, x9, [x0, #8]
	add	x8, x8, x1
	eor	x10, x1, x1, lsr #30
	mov	x11, #58809                     ; =0xe5b9
	movk	x11, #7396, lsl #16
	movk	x11, #18285, lsl #32
	movk	x11, #48984, lsl #48
	mul	x10, x10, x11
	eor	x10, x10, x10, lsr #27
	mov	x11, #4587                      ; =0x11eb
	movk	x11, #4913, lsl #16
	movk	x11, #18875, lsl #32
	movk	x11, #38096, lsl #48
	mul	x10, x10, x11
	eor	x9, x9, x10, lsr #31
	eor	x9, x9, x10
	stp	x8, x9, [x0, #8]
	ldr	x8, [x0, #24]
	add	x8, x8, #1
	str	x8, [x0, #24]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_ordered_cost_finish         ; -- Begin function wf_ordered_cost_finish
	.p2align	2
_wf_ordered_cost_finish:                ; @wf_ordered_cost_finish
; %bb.0:                                ; %entry
	ldp	x8, x9, [x0]
	ldp	x10, x11, [x0, #16]
	eor	x8, x8, x8, lsr #30
	mov	x12, #58809                     ; =0xe5b9
	movk	x12, #7396, lsl #16
	movk	x12, #18285, lsl #32
	movk	x12, #48984, lsl #48
	mul	x8, x8, x12
	eor	x8, x8, x8, lsr #27
	mov	x13, #4587                      ; =0x11eb
	movk	x13, #4913, lsl #16
	movk	x13, #18875, lsl #32
	movk	x13, #38096, lsl #48
	mul	x8, x8, x13
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x12
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x13
	eor	x12, x9, x8
	mov	x13, #31765                     ; =0x7c15
	movk	x13, #32586, lsl #16
	movk	x13, #31161, lsl #32
	movk	x13, #40503, lsl #48
	mul	x11, x11, x13
	eor	x10, x10, x11
	eor	x10, x10, x12, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	ret
                                        ; -- End function
	.globl	_wf_ordered_cost_compare        ; -- Begin function wf_ordered_cost_compare
	.p2align	2
_wf_ordered_cost_compare:               ; @wf_ordered_cost_compare
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x2]
	cmp	x8, x9
	mov	w8, #9                          ; =0x9
	csel	w8, w8, wzr, hi
	mov	w9, #-7                         ; =0xfffffff9
	csel	w0, w9, w8, lo
	ret
                                        ; -- End function
	.globl	_wf_ordered_cost_word_make      ; -- Begin function wf_ordered_cost_word_make
	.p2align	2
_wf_ordered_cost_word_make:             ; @wf_ordered_cost_word_make
; %bb.0:                                ; %entry
	ret
                                        ; -- End function
	.globl	_wf_ordered_cost_word_content   ; -- Begin function wf_ordered_cost_word_content
	.p2align	2
_wf_ordered_cost_word_content:          ; @wf_ordered_cost_word_content
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	mov	w9, #131                        ; =0x83
	ldr	x10, [x1]
	madd	x0, x8, x9, x10
	ret
                                        ; -- End function
	.globl	_wf_ordered_cost_word_observe   ; -- Begin function wf_ordered_cost_word_observe
	.p2align	2
_wf_ordered_cost_word_observe:          ; @wf_ordered_cost_word_observe
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	mov	w9, #131                        ; =0x83
	ldr	x10, [x2]
	madd	x8, x8, x9, x10
	ldr	x10, [x0]
	madd	x9, x10, x9, x8
	str	x9, [x0]
	mov	x0, x8
	ret
                                        ; -- End function
	.globl	_wf_ordered_cost_word_visit     ; -- Begin function wf_ordered_cost_word_visit
	.p2align	2
_wf_ordered_cost_word_visit:            ; @wf_ordered_cost_word_visit
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x2]
	ldr	x10, [x0]
	add	x8, x10, x8
	mov	w10, #131                       ; =0x83
	madd	x8, x8, x10, x9
	str	x8, [x0]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_ordered_cost_word_edit      ; -- Begin function wf_ordered_cost_word_edit
	.p2align	2
_wf_ordered_cost_word_edit:             ; @wf_ordered_cost_word_edit
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	add	x8, x8, #1
	str	x8, [x2]
	ldr	x9, [x1]
	mov	w10, #131                       ; =0x83
	madd	x8, x9, x10, x8
	ldr	x9, [x0]
	madd	x9, x9, x10, x8
	str	x9, [x0]
	mov	x0, x8
	ret
                                        ; -- End function
	.globl	_wf_ordered_cost_word_consume   ; -- Begin function wf_ordered_cost_word_consume
	.p2align	2
_wf_ordered_cost_word_consume:          ; @wf_ordered_cost_word_consume
; %bb.0:                                ; %entry
	mov	w8, #131                        ; =0x83
	madd	x8, x1, x8, x2
	ldp	x9, x10, [x0, #8]
	add	x9, x9, x8
	eor	x8, x8, x8, lsr #30
	mov	x11, #58809                     ; =0xe5b9
	movk	x11, #7396, lsl #16
	movk	x11, #18285, lsl #32
	movk	x11, #48984, lsl #48
	mul	x8, x8, x11
	eor	x8, x8, x8, lsr #27
	mov	x11, #4587                      ; =0x11eb
	movk	x11, #4913, lsl #16
	movk	x11, #18875, lsl #32
	movk	x11, #38096, lsl #48
	mul	x8, x8, x11
	eor	x10, x10, x8, lsr #31
	eor	x8, x10, x8
	stp	x9, x8, [x0, #8]
	ldr	x8, [x0, #24]
	add	x8, x8, #1
	str	x8, [x0, #24]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_ordered_cost_record_make
lCPI13_0:
	.quad	1                               ; 0x1
	.quad	2                               ; 0x2
lCPI13_1:
	.quad	3                               ; 0x3
	.quad	4                               ; 0x4
lCPI13_2:
	.quad	5                               ; 0x5
	.quad	6                               ; 0x6
lCPI13_3:
	.quad	7                               ; 0x7
	.quad	8                               ; 0x8
lCPI13_4:
	.quad	9                               ; 0x9
	.quad	10                              ; 0xa
lCPI13_5:
	.quad	11                              ; 0xb
	.quad	12                              ; 0xc
lCPI13_6:
	.quad	13                              ; 0xd
	.quad	14                              ; 0xe
lCPI13_7:
	.quad	15                              ; 0xf
	.quad	16                              ; 0x10
lCPI13_8:
	.quad	17                              ; 0x11
	.quad	18                              ; 0x12
lCPI13_9:
	.quad	19                              ; 0x13
	.quad	20                              ; 0x14
lCPI13_10:
	.quad	21                              ; 0x15
	.quad	22                              ; 0x16
lCPI13_11:
	.quad	23                              ; 0x17
	.quad	24                              ; 0x18
lCPI13_12:
	.quad	25                              ; 0x19
	.quad	26                              ; 0x1a
lCPI13_13:
	.quad	27                              ; 0x1b
	.quad	28                              ; 0x1c
lCPI13_14:
	.quad	29                              ; 0x1d
	.quad	30                              ; 0x1e
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_ordered_cost_record_make
	.p2align	2
_wf_ordered_cost_record_make:           ; @wf_ordered_cost_record_make
; %bb.0:                                ; %entry
	dup.2d	v0, x1
Lloh2:
	adrp	x8, lCPI13_0@PAGE
Lloh3:
	ldr	q1, [x8, lCPI13_0@PAGEOFF]
Lloh4:
	adrp	x8, lCPI13_1@PAGE
Lloh5:
	ldr	q2, [x8, lCPI13_1@PAGEOFF]
	add.2d	v1, v0, v1
Lloh6:
	adrp	x8, lCPI13_2@PAGE
Lloh7:
	ldr	q3, [x8, lCPI13_2@PAGEOFF]
	add.2d	v2, v0, v2
Lloh8:
	adrp	x8, lCPI13_3@PAGE
Lloh9:
	ldr	q4, [x8, lCPI13_3@PAGEOFF]
	add.2d	v3, v0, v3
Lloh10:
	adrp	x8, lCPI13_4@PAGE
Lloh11:
	ldr	q5, [x8, lCPI13_4@PAGEOFF]
	add.2d	v4, v0, v4
Lloh12:
	adrp	x8, lCPI13_5@PAGE
Lloh13:
	ldr	q6, [x8, lCPI13_5@PAGEOFF]
	add.2d	v5, v0, v5
Lloh14:
	adrp	x8, lCPI13_6@PAGE
Lloh15:
	ldr	q7, [x8, lCPI13_6@PAGEOFF]
	add.2d	v6, v0, v6
Lloh16:
	adrp	x8, lCPI13_7@PAGE
Lloh17:
	ldr	q16, [x8, lCPI13_7@PAGEOFF]
	add.2d	v7, v0, v7
Lloh18:
	adrp	x8, lCPI13_8@PAGE
Lloh19:
	ldr	q17, [x8, lCPI13_8@PAGEOFF]
	add.2d	v16, v0, v16
Lloh20:
	adrp	x8, lCPI13_9@PAGE
Lloh21:
	ldr	q18, [x8, lCPI13_9@PAGEOFF]
	add.2d	v17, v0, v17
Lloh22:
	adrp	x8, lCPI13_10@PAGE
Lloh23:
	ldr	q19, [x8, lCPI13_10@PAGEOFF]
	add.2d	v18, v0, v18
Lloh24:
	adrp	x8, lCPI13_11@PAGE
Lloh25:
	ldr	q20, [x8, lCPI13_11@PAGEOFF]
	add.2d	v19, v0, v19
Lloh26:
	adrp	x8, lCPI13_12@PAGE
Lloh27:
	ldr	q21, [x8, lCPI13_12@PAGEOFF]
	add.2d	v20, v0, v20
Lloh28:
	adrp	x8, lCPI13_13@PAGE
Lloh29:
	ldr	q22, [x8, lCPI13_13@PAGEOFF]
	add.2d	v21, v0, v21
Lloh30:
	adrp	x8, lCPI13_14@PAGE
Lloh31:
	ldr	q23, [x8, lCPI13_14@PAGEOFF]
	add.2d	v22, v0, v22
	add.2d	v0, v0, v23
	str	x1, [x0]
	add	x8, x1, #31
	stur	q1, [x0, #8]
	stur	q2, [x0, #24]
	stur	q3, [x0, #40]
	stur	q4, [x0, #56]
	stur	q5, [x0, #72]
	stur	q6, [x0, #88]
	stur	q7, [x0, #104]
	stur	q16, [x0, #120]
	stur	q17, [x0, #136]
	stur	q18, [x0, #152]
	stur	q19, [x0, #168]
	stur	q20, [x0, #184]
	stur	q21, [x0, #200]
	stur	q22, [x0, #216]
	stur	q0, [x0, #232]
	str	x8, [x0, #248]
	ret
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdrp	Lloh28, Lloh30
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
                                        ; -- End function
	.globl	_wf_ordered_cost_record_content ; -- Begin function wf_ordered_cost_record_content
	.p2align	2
_wf_ordered_cost_record_content:        ; @wf_ordered_cost_record_content
; %bb.0:                                ; %entry
	ldr	x9, [x0]
	mov	w8, #131                        ; =0x83
	ldp	x10, x11, [x1]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #16]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #32]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #48]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #64]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #80]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #96]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #112]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #128]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #144]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #160]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #176]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #192]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #208]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #224]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x1, #240]
	madd	x9, x9, x8, x10
	madd	x0, x9, x8, x11
	ret
                                        ; -- End function
	.globl	_wf_ordered_cost_record_observe ; -- Begin function wf_ordered_cost_record_observe
	.p2align	2
_wf_ordered_cost_record_observe:        ; @wf_ordered_cost_record_observe
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	mov	x19, x0
	mov	x0, x1
	mov	x1, x2
	bl	_wf_ordered_cost_record_content
	ldr	x8, [x19]
	mov	w9, #131                        ; =0x83
	madd	x8, x8, x9, x0
	str	x8, [x19]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_ordered_cost_record_visit   ; -- Begin function wf_ordered_cost_record_visit
	.p2align	2
_wf_ordered_cost_record_visit:          ; @wf_ordered_cost_record_visit
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	mov	x19, x0
	mov	x0, x1
	mov	x1, x2
	bl	_wf_ordered_cost_record_content
	ldr	x8, [x19]
	mov	w9, #131                        ; =0x83
	madd	x8, x8, x9, x0
	str	x8, [x19]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_ordered_cost_record_edit    ; -- Begin function wf_ordered_cost_record_edit
	.p2align	2
_wf_ordered_cost_record_edit:           ; @wf_ordered_cost_record_edit
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	mov	x19, x0
	mov	w8, #1                          ; =0x1
	dup.2d	v0, x8
	ldp	q1, q2, [x2]
	add.2d	v1, v1, v0
	add.2d	v2, v2, v0
	stp	q1, q2, [x2]
	ldp	q1, q2, [x2, #32]
	add.2d	v1, v1, v0
	add.2d	v2, v2, v0
	stp	q1, q2, [x2, #32]
	ldp	q1, q2, [x2, #64]
	add.2d	v1, v1, v0
	add.2d	v2, v2, v0
	stp	q1, q2, [x2, #64]
	ldp	q1, q2, [x2, #96]
	add.2d	v1, v1, v0
	add.2d	v2, v2, v0
	stp	q1, q2, [x2, #96]
	ldp	q1, q2, [x2, #128]
	add.2d	v1, v1, v0
	add.2d	v2, v2, v0
	stp	q1, q2, [x2, #128]
	ldp	q1, q2, [x2, #160]
	add.2d	v1, v1, v0
	add.2d	v2, v2, v0
	stp	q1, q2, [x2, #160]
	ldp	q1, q2, [x2, #192]
	add.2d	v1, v1, v0
	add.2d	v2, v2, v0
	stp	q1, q2, [x2, #192]
	ldp	q1, q2, [x2, #224]
	add.2d	v1, v1, v0
	add.2d	v0, v2, v0
	stp	q1, q0, [x2, #224]
	mov	x0, x1
	mov	x1, x2
	bl	_wf_ordered_cost_record_content
	ldr	x8, [x19]
	mov	w9, #131                        ; =0x83
	madd	x8, x8, x9, x0
	str	x8, [x19]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_ordered_cost_record_consume ; -- Begin function wf_ordered_cost_record_consume
	.p2align	2
_wf_ordered_cost_record_consume:        ; @wf_ordered_cost_record_consume
; %bb.0:                                ; %entry
	ldp	x9, x10, [x2]
	mov	w8, #131                        ; =0x83
	madd	x9, x1, x8, x9
	madd	x9, x9, x8, x10
	ldp	x10, x11, [x2, #16]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #32]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #48]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #64]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #80]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #96]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #112]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #128]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #144]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #160]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #176]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #192]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #208]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #224]
	madd	x9, x9, x8, x10
	madd	x9, x9, x8, x11
	ldp	x10, x11, [x2, #240]
	madd	x9, x9, x8, x10
	madd	x8, x9, x8, x11
	ldp	x9, x10, [x0, #8]
	add	x9, x8, x9
	eor	x8, x8, x8, lsr #30
	mov	x11, #58809                     ; =0xe5b9
	movk	x11, #7396, lsl #16
	movk	x11, #18285, lsl #32
	movk	x11, #48984, lsl #48
	mul	x8, x8, x11
	eor	x8, x8, x8, lsr #27
	mov	x11, #4587                      ; =0x11eb
	movk	x11, #4913, lsl #16
	movk	x11, #18875, lsl #32
	movk	x11, #38096, lsl #48
	mul	x8, x8, x11
	eor	x10, x10, x8, lsr #31
	eor	x8, x10, x8
	stp	x9, x8, [x0, #8]
	ldr	x8, [x0, #24]
	add	x8, x8, #1
	str	x8, [x0, #24]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_ordered_cost_lookup_result  ; -- Begin function wf_ordered_cost_lookup_result
	.p2align	2
_wf_ordered_cost_lookup_result:         ; @wf_ordered_cost_lookup_result
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cmp	w8, #0
	ldr	x8, [x1]
	mov	w9, #131                        ; =0x83
	mul	x8, x8, x9
	cinc	x8, x8, eq
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_ordered_cost_word_trace     ; -- Begin function wf_ordered_cost_word_trace
	.p2align	2
_wf_ordered_cost_word_trace:            ; @wf_ordered_cost_word_trace
	.cfi_startproc
; %bb.0:                                ; %entry
	b	_wf_ordered_cost_trace$instance$fa3caca27a003293
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_ordered_cost_record_trace   ; -- Begin function wf_ordered_cost_record_trace
	.p2align	2
_wf_ordered_cost_record_trace:          ; @wf_ordered_cost_record_trace
	.cfi_startproc
; %bb.0:                                ; %entry
	b	_wf_ordered_cost_trace$instance$ff5e39efec5d08ee
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_main                        ; -- Begin function wf_main
	.p2align	2
_wf_main:                               ; @wf_main
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	x0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	bl	_wf_ordered_cost_trace$instance$fa3caca27a003293
	mov	x0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	bl	_wf_ordered_cost_trace$instance$ff5e39efec5d08ee
	mov	x0, x19
	mov	w1, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_wf_std.process.exit_status
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_array_filled$instance$581665c886d1d2c8 ; -- Begin function wf_array_filled$instance$581665c886d1d2c8
	.p2align	2
_wf_array_filled$instance$581665c886d1d2c8: ; @"wf_array_filled$instance$581665c886d1d2c8"
; %bb.0:                                ; %entry
	dup.2d	v0, x1
	stp	q0, q0, [x0]
	stp	q0, q0, [x0, #32]
	stp	q0, q0, [x0, #64]
	stp	q0, q0, [x0, #96]
	stp	q0, q0, [x0, #128]
	stp	q0, q0, [x0, #160]
	stp	q0, q0, [x0, #192]
	stp	q0, q0, [x0, #224]
	ret
                                        ; -- End function
	.globl	_wf_ordered_cost_trace$instance$fa3caca27a003293 ; -- Begin function wf_ordered_cost_trace$instance$fa3caca27a003293
	.p2align	2
_wf_ordered_cost_trace$instance$fa3caca27a003293: ; @"wf_ordered_cost_trace$instance$fa3caca27a003293"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #448
	.cfi_def_cfa_offset 544
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x23, x2
	str	x1, [sp, #24]                   ; 8-byte Folded Spill
	stp	xzr, xzr, [sp, #336]
	add	x28, sp, #88
	strb	wzr, [sp, #360]
	mov	x25, #58809                     ; =0xe5b9
	movk	x25, #7396, lsl #16
	movk	x25, #18285, lsl #32
	movk	x25, #48984, lsl #48
	mov	x21, #4587                      ; =0x11eb
	movk	x21, #4913, lsl #16
	movk	x21, #18875, lsl #32
	movk	x21, #38096, lsl #48
	str	xzr, [sp, #352]
	add	x19, x28, #280
	stp	x2, xzr, [sp, #368]
	stp	xzr, xzr, [sp, #384]
	cbz	x0, LBB24_51
; %bb.1:                                ; %bb4.preheader
	mov	x20, x3
	mov	x27, x0
	mov	x21, #0                         ; =0x0
	add	x8, x28, #256
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	mov	w22, #1                         ; =0x1
	mov	w25, #131                       ; =0x83
	mov	x26, x0
	mov	x24, x23
	b	LBB24_4
LBB24_2:                                ; %bb3.i
                                        ;   in Loop: Header=BB24_4 Depth=1
	ldp	x10, x9, [sp, #96]
	ldrb	w8, [sp, #92]
	tst	w8, #0x1
	cinc	x8, x22, ne
	ldp	x11, x12, [sp, #368]
	madd	x8, x11, x25, x8
	madd	x9, x10, x25, x9
	add	x10, x12, x9
	eor	x9, x9, x9, lsr #30
	mov	x11, #58809                     ; =0xe5b9
	movk	x11, #7396, lsl #16
	movk	x11, #18285, lsl #32
	movk	x11, #48984, lsl #48
	mul	x9, x9, x11
	eor	x9, x9, x9, lsr #27
	mov	x11, #4587                      ; =0x11eb
	movk	x11, #4913, lsl #16
	movk	x11, #18875, lsl #32
	movk	x11, #38096, lsl #48
	mul	x9, x9, x11
	ldp	x11, x12, [sp, #384]
	eor	x11, x11, x9, lsr #31
	eor	x9, x11, x9
	stp	x10, x9, [sp, #376]
	add	x9, x12, #1
	str	x9, [sp, #392]
LBB24_3:                                ; %"wf_ordered_cost_put_result$instance$fa3caca27a003293.exit"
                                        ;   in Loop: Header=BB24_4 Depth=1
	str	x8, [sp, #368]
	add	x21, x21, #73
	add	x24, x24, #1
	subs	x26, x26, #1
	b.eq	LBB24_6
LBB24_4:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	udiv	x8, x21, x27
	msub	x8, x8, x27, x21
	orr	x2, x22, x8, lsl #1
	add	x0, sp, #88
	add	x1, x28, #248
	add	x4, x28, #272
	mov	x3, x24
	bl	_wf_std.collections.ordered_map.ordered_map_put$instance$c2a7dc263c55706f
	ldr	w8, [sp, #88]
	cbnz	w8, LBB24_2
; %bb.5:                                ; %bb2.i
                                        ;   in Loop: Header=BB24_4 Depth=1
	ldr	x8, [sp, #368]
	mul	x8, x8, x25
	b	LBB24_3
LBB24_6:                                ; %bb7
	ldr	x9, [sp, #352]
	mov	w10, #131                       ; =0x83
	madd	x8, x8, x10, x9
	str	x8, [sp, #368]
	ldr	x10, [sp, #24]                  ; 8-byte Folded Reload
	cbz	x10, LBB24_52
; %bb.7:                                ; %bb13.preheader.lr.ph
	mov	x9, #0                          ; =0x0
	add	x23, x23, x27
	lsl	x8, x27, #1
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	mov	w28, #131                       ; =0x83
	mov	x24, x23
	mov	x21, #4587                      ; =0x11eb
	movk	x21, #4913, lsl #16
	movk	x21, #18875, lsl #32
	movk	x21, #38096, lsl #48
	mov	x25, #58809                     ; =0xe5b9
	movk	x25, #7396, lsl #16
	movk	x25, #18285, lsl #32
	movk	x25, #48984, lsl #48
	str	x19, [sp, #80]                  ; 8-byte Folded Spill
	b	LBB24_9
LBB24_8:                                ; %bb30
                                        ;   in Loop: Header=BB24_9 Depth=1
	ldp	x23, x9, [sp, #56]              ; 16-byte Folded Reload
	add	x9, x9, #1
	ldp	x10, x8, [sp, #16]              ; 16-byte Folded Reload
	ldr	x24, [sp, #48]                  ; 8-byte Folded Reload
	add	x24, x24, x10
	add	x23, x23, x27
	cmp	x9, x8
	b.eq	LBB24_50
LBB24_9:                                ; %bb13.preheader
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB24_13 Depth 2
	stp	x23, x9, [sp, #56]              ; 16-byte Folded Spill
	mov	x26, #0                         ; =0x0
	mov	x22, x27
	str	x24, [sp, #48]                  ; 8-byte Folded Spill
	b	LBB24_13
LBB24_10:                               ; %bb2.i169
                                        ;   in Loop: Header=BB24_13 Depth=2
	ldr	x8, [sp, #368]
	mul	x8, x8, x28
LBB24_11:                               ; %bb29
                                        ;   in Loop: Header=BB24_13 Depth=2
	str	x8, [sp, #368]
LBB24_12:                               ; %bb29
                                        ;   in Loop: Header=BB24_13 Depth=2
	add	x26, x26, #73
	add	x24, x24, #2
	add	x23, x23, #1
	subs	x22, x22, #1
	b.eq	LBB24_8
LBB24_13:                               ; %bb14
                                        ;   Parent Loop BB24_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	udiv	x8, x26, x27
	msub	x9, x8, x27, x26
	lsl	x8, x9, #1
	mov	w2, #1                          ; =0x1
	bfi	x2, x9, #1, #63
	stp	x8, x2, [sp, #400]
	cmp	x20, #2
	b.gt	LBB24_18
; %bb.14:                               ; %bb14
                                        ;   in Loop: Header=BB24_13 Depth=2
	cmp	x20, #1
	b.eq	LBB24_22
; %bb.15:                               ; %bb14
                                        ;   in Loop: Header=BB24_13 Depth=2
	cmp	x20, #2
	b.ne	LBB24_12
; %bb.16:                               ; %bb21
                                        ;   in Loop: Header=BB24_13 Depth=2
	add	x8, sp, #88
	add	x0, x8, #72
	add	x1, x8, #248
	add	x4, x8, #272
	mov	x3, x24
	bl	_wf_std.collections.ordered_map.ordered_map_put$instance$c2a7dc263c55706f
	ldr	w8, [sp, #160]
	cbz	w8, LBB24_27
; %bb.17:                               ; %bb3.i54
                                        ;   in Loop: Header=BB24_13 Depth=2
	ldp	x10, x9, [sp, #168]
	ldrb	w8, [sp, #164]
	tst	w8, #0x1
	mov	w8, #1                          ; =0x1
	cinc	x8, x8, ne
	ldp	x11, x12, [sp, #368]
	mov	w13, #131                       ; =0x83
	madd	x8, x11, x13, x8
	mov	w28, #131                       ; =0x83
	madd	x9, x10, x13, x9
	add	x10, x12, x9
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x25
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x21
	ldp	x11, x12, [sp, #384]
	eor	x11, x11, x9, lsr #31
	eor	x9, x11, x9
	stp	x10, x9, [sp, #376]
	add	x9, x12, #1
	str	x9, [sp, #392]
	b	LBB24_28
LBB24_18:                               ; %bb14
                                        ;   in Loop: Header=BB24_13 Depth=2
	cmp	x20, #3
	b.eq	LBB24_24
; %bb.19:                               ; %bb14
                                        ;   in Loop: Header=BB24_13 Depth=2
	cmp	x20, #4
	b.ne	LBB24_12
; %bb.20:                               ; %bb27
                                        ;   in Loop: Header=BB24_13 Depth=2
	add	x8, sp, #88
	add	x0, x8, #168
	add	x1, x8, #248
	add	x4, x8, #272
	mov	x3, x23
	bl	_wf_std.collections.ordered_map.ordered_map_put$instance$c2a7dc263c55706f
	ldr	w8, [sp, #256]
	cbz	w8, LBB24_10
; %bb.21:                               ; %bb3.i179
                                        ;   in Loop: Header=BB24_13 Depth=2
	ldrb	w8, [sp, #260]
	tst	w8, #0x1
	mov	w8, #1                          ; =0x1
	cinc	x8, x8, ne
	ldp	x9, x10, [sp, #368]
	mov	w12, #131                       ; =0x83
	madd	x8, x9, x12, x8
	ldp	x11, x9, [sp, #264]
	b	LBB24_49
LBB24_22:                               ; %bb18
                                        ;   in Loop: Header=BB24_13 Depth=2
	ldr	x8, [sp, #336]
	cbz	x8, LBB24_40
; %bb.23:                               ; %bb2.i.i.i.i
                                        ;   in Loop: Header=BB24_13 Depth=2
	ldr	x0, [sp, #344]
	add	x8, sp, #88
	add	x1, x8, #320
	add	x2, x8, #272
	mov	x3, x19
	bl	_wf_std.collections.ordered_map.ordered_map_lookup_node$instance$11eb30e8dabe0f7e
	mov	x8, x2
	ldr	x2, [sp, #408]
	ldr	x9, [sp, #336]
	cmp	x9, #0
	cset	w9, eq
	b	LBB24_41
LBB24_24:                               ; %bb24
                                        ;   in Loop: Header=BB24_13 Depth=2
	add	x9, x8, #32
	str	x9, [sp, #424]
	cmn	x8, #33
	b.hi	LBB24_12
; %bb.25:                               ; %bb2.i174
                                        ;   in Loop: Header=BB24_13 Depth=2
	ldr	x8, [sp, #336]
	cbz	x8, LBB24_12
; %bb.26:                               ; %bb2.i.i176
                                        ;   in Loop: Header=BB24_13 Depth=2
	ldr	x0, [sp, #344]
	add	x8, sp, #88
	add	x1, x8, #312
	add	x2, x8, #336
	add	x3, x8, #272
	mov	x4, x19
	bl	_wf_std.collections.ordered_map.ordered_map_range_node$instance$171ecc1fc526bab5
	b	LBB24_12
LBB24_27:                               ; %bb2.i82
                                        ;   in Loop: Header=BB24_13 Depth=2
	ldr	x8, [sp, #368]
	mul	x8, x8, x28
LBB24_28:                               ; %"wf_ordered_cost_put_result$instance$fa3caca27a003293.exit85"
                                        ;   in Loop: Header=BB24_13 Depth=2
	str	x8, [sp, #368]
	ldr	x9, [sp, #336]
	cbz	x9, LBB24_30
; %bb.29:                               ; %bb2.i.i.i.i88
                                        ;   in Loop: Header=BB24_13 Depth=2
	ldr	x0, [sp, #344]
	add	x8, sp, #88
	add	x1, x8, #320
	add	x2, x8, #272
	mov	x3, x19
	bl	_wf_std.collections.ordered_map.ordered_map_edit_node$instance$41f33845185638b6
	ldr	x8, [sp, #368]
	ldr	x19, [sp, #336]
	b	LBB24_31
LBB24_30:                               ;   in Loop: Header=BB24_13 Depth=2
	mov	x19, #0                         ; =0x0
	mov	w2, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
LBB24_31:                               ; %"wf_std.collections.ordered_map.ordered_map_edit$instance$2c340453a2bb7cf7.exit"
                                        ;   in Loop: Header=BB24_13 Depth=2
	str	w0, [sp, #184]
	str	x1, [sp, #192]
	strb	w2, [sp, #200]
	cmp	w0, #0
	mul	x8, x8, x28
	cinc	x8, x8, eq
	str	x8, [sp, #368]
	cbz	x19, LBB24_46
; %bb.32:                               ; %"wf_std.collections.ordered_map.ordered_map_remove_link$instance$5046b787ff5cdb3f.exit.i.i"
                                        ;   in Loop: Header=BB24_13 Depth=2
	ldr	x0, [sp, #344]
	add	x8, sp, #88
	add	x1, x8, #320
	add	x2, x8, #272
	bl	_wf_std.collections.ordered_map.ordered_map_remove_node$instance$5046b787ff5cdb3f
	cbz	w0, LBB24_45
; %bb.33:                               ; %bb2.i.i.i
                                        ;   in Loop: Header=BB24_13 Depth=2
	sub	x21, x19, #1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	add	x25, x8, x21, lsl #3
	str	x21, [sp, #336]
	ldr	x0, [x25]
	ldr	x8, [x0, #16]
	cbnz	x8, LBB24_37
; %bb.34:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB24_13 Depth=2
	stp	x1, x2, [sp, #32]               ; 16-byte Folded Spill
	ldp	x19, x28, [x0]
	bl	_free
	str	x28, [sp, #432]
	cbz	x19, LBB24_36
; %bb.35:                               ; %run.move.body.v3.preheader.i.i.i.i
                                        ;   in Loop: Header=BB24_13 Depth=2
	lsl	x2, x19, #3
	add	x1, sp, #432
	mov	x0, x25
	bl	_memcpy
LBB24_36:                               ; %"wf_append$instance$48c61fa9751a6936.exit.i.i.i"
                                        ;   in Loop: Header=BB24_13 Depth=2
	add	x19, x19, x21
	ldp	x1, x2, [sp, #32]               ; 16-byte Folded Reload
LBB24_37:                               ; %"wf_std.collections.ordered_map.ordered_map_contract_root$instance$0ed342445dd803f3.exit.i.i"
                                        ;   in Loop: Header=BB24_13 Depth=2
	str	x19, [sp, #336]
	ldr	x8, [sp, #352]
	cbz	x8, LBB24_39
; %bb.38:                               ; %bb4.i.i
                                        ;   in Loop: Header=BB24_13 Depth=2
	sub	x8, x8, #1
	str	x8, [sp, #352]
LBB24_39:                               ; %"wf_std.collections.ordered_map.ordered_map_remove$instance$c2a7dc263c55706f.exit"
                                        ;   in Loop: Header=BB24_13 Depth=2
	stp	x1, x2, [sp, #216]
	mov	w13, #131                       ; =0x83
	madd	x8, x1, x13, x2
	ldp	x9, x10, [sp, #368]
	add	x10, x10, x8
	eor	x8, x8, x8, lsr #30
	mov	x25, #58809                     ; =0xe5b9
	movk	x25, #7396, lsl #16
	movk	x25, #18285, lsl #32
	movk	x25, #48984, lsl #48
	mul	x8, x8, x25
	eor	x8, x8, x8, lsr #27
	mov	x21, #4587                      ; =0x11eb
	movk	x21, #4913, lsl #16
	movk	x21, #18875, lsl #32
	movk	x21, #38096, lsl #48
	mul	x8, x8, x21
	ldp	x11, x12, [sp, #384]
	eor	x11, x11, x8, lsr #31
	eor	x11, x11, x8
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #208]
	mov	w28, #131                       ; =0x83
	mov	x8, #1                          ; =0x1
	madd	x8, x9, x13, x8
	stp	x10, x11, [sp, #376]
	add	x9, x12, #1
	str	x9, [sp, #392]
	b	LBB24_47
LBB24_40:                               ;   in Loop: Header=BB24_13 Depth=2
	mov	x1, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	mov	w0, #1                          ; =0x1
LBB24_41:                               ; %"wf_std.collections.ordered_map.ordered_map_lookup$instance$107186e54bef911a.exit"
                                        ;   in Loop: Header=BB24_13 Depth=2
	str	w0, [sp, #112]
	str	x1, [sp, #120]
	strb	w8, [sp, #128]
	cmp	w0, #0
	ldr	x8, [sp, #368]
	mul	x8, x8, x28
	cinc	x8, x8, eq
	sub	x10, x2, #1
	str	x8, [sp, #368]
	str	x10, [sp, #416]
	tbz	w9, #0, LBB24_43
; %bb.42:                               ;   in Loop: Header=BB24_13 Depth=2
	mov	w2, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	b	LBB24_44
LBB24_43:                               ; %bb2.i.i.i.i32
                                        ;   in Loop: Header=BB24_13 Depth=2
	ldr	x0, [sp, #344]
	add	x8, sp, #88
	add	x1, x8, #328
	add	x2, x8, #272
	mov	x3, x19
	bl	_wf_std.collections.ordered_map.ordered_map_lookup_node$instance$11eb30e8dabe0f7e
	ldr	x8, [sp, #368]
LBB24_44:                               ; %"wf_std.collections.ordered_map.ordered_map_lookup$instance$107186e54bef911a.exit45"
                                        ;   in Loop: Header=BB24_13 Depth=2
	str	w0, [sp, #136]
	str	x1, [sp, #144]
	strb	w2, [sp, #152]
	cmp	w0, #0
	mul	x8, x8, x28
	cinc	x8, x8, eq
	b	LBB24_11
LBB24_45:                               ; %"wf_std.collections.ordered_map.ordered_map_remove_link$instance$5046b787ff5cdb3f.exit.i.i.bb3.i113.critedge_crit_edge"
                                        ;   in Loop: Header=BB24_13 Depth=2
	ldr	x8, [sp, #368]
LBB24_46:                               ; %bb3.i113.critedge
                                        ;   in Loop: Header=BB24_13 Depth=2
	str	wzr, [sp, #208]
	mul	x8, x8, x28
	add	x9, sp, #88
	stp	xzr, xzr, [x9, #128]
LBB24_47:                               ; %"wf_ordered_cost_taken_result$instance$fa3caca27a003293.exit"
                                        ;   in Loop: Header=BB24_13 Depth=2
	ldr	x19, [sp, #80]                  ; 8-byte Folded Reload
	str	x8, [sp, #368]
	ldr	x2, [sp, #408]
	add	x8, sp, #88
	add	x0, x8, #144
	add	x1, x8, #248
	add	x3, x24, #1
	add	x4, x8, #272
	bl	_wf_std.collections.ordered_map.ordered_map_put$instance$c2a7dc263c55706f
	ldr	w8, [sp, #232]
	cbz	w8, LBB24_10
; %bb.48:                               ; %bb3.i141
                                        ;   in Loop: Header=BB24_13 Depth=2
	ldrb	w8, [sp, #236]
	tst	w8, #0x1
	mov	w8, #1                          ; =0x1
	cinc	x8, x8, ne
	ldp	x9, x10, [sp, #368]
	mov	w12, #131                       ; =0x83
	madd	x8, x9, x12, x8
	ldp	x11, x9, [sp, #240]
LBB24_49:                               ; %bb29
                                        ;   in Loop: Header=BB24_13 Depth=2
	mov	w28, #131                       ; =0x83
	madd	x9, x11, x12, x9
	add	x10, x10, x9
	stp	x8, x10, [sp, #368]
	eor	x8, x9, x9, lsr #30
	mul	x8, x8, x25
	eor	x8, x8, x8, lsr #27
	mul	x8, x8, x21
	ldp	x9, x10, [sp, #384]
	eor	x9, x9, x8, lsr #31
	eor	x8, x9, x8
	add	x9, x10, #1
	stp	x8, x9, [sp, #384]
	b	LBB24_12
LBB24_50:                               ; %bb1.loopexit
	ldr	x9, [sp, #352]
	ldr	x8, [sp, #368]
	add	x28, sp, #88
	b	LBB24_53
LBB24_51:                               ; %bb3
	mov	x9, #0                          ; =0x0
	mov	w8, #131                        ; =0x83
	mul	x8, x23, x8
	b	LBB24_53
LBB24_52:
	mov	x21, #4587                      ; =0x11eb
	movk	x21, #4913, lsl #16
	movk	x21, #18875, lsl #32
	movk	x21, #38096, lsl #48
	mov	x25, #58809                     ; =0xe5b9
	movk	x25, #7396, lsl #16
	movk	x25, #18285, lsl #32
	movk	x25, #48984, lsl #48
LBB24_53:                               ; %bb1
	mov	w10, #131                       ; =0x83
	madd	x8, x8, x10, x9
	str	x8, [sp, #368]
	add	x0, x28, #248
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_each_link$instance$5fa8e8b3d971a72b
	ldur	q0, [x28, #248]
	add	x8, sp, #25
	stur	q0, [x8, #255]
	ldr	x8, [x28, #264]
	str	x8, [sp, #296]
	ldur	q0, [x28, #248]
	str	q0, [sp, #432]
	ldr	x8, [sp, #432]
	cbz	x8, LBB24_55
; %bb.54:                               ; %bb2.i.i
	sub	x8, x8, #1
	add	x9, sp, #432
	add	x9, x9, x8, lsl #3
	str	x8, [sp, #432]
	ldr	x0, [x9, #8]
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_free_node$instance$a14f6fad6bd909bd
LBB24_55:                               ; %"wf_std.collections.ordered_map.ordered_map_free$instance$5b3375fb2964755f.exit"
	ldp	q0, q1, [x19]
	stur	q0, [x28, #216]
	stur	q1, [x28, #232]
	ldp	x8, x9, [sp, #304]
	ldp	x10, x11, [sp, #320]
	eor	x8, x8, x8, lsr #30
	mul	x8, x8, x25
	eor	x8, x8, x8, lsr #27
	mul	x8, x8, x21
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x25
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x21
	eor	x12, x9, x8
	mov	x13, #31765                     ; =0x7c15
	movk	x13, #32586, lsl #16
	movk	x13, #31161, lsl #32
	movk	x13, #40503, lsl #48
	mul	x11, x11, x13
	eor	x10, x10, x11
	eor	x10, x10, x12, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	add	sp, sp, #448
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_ordered_cost_trace$instance$ff5e39efec5d08ee
lCPI25_0:
	.quad	1                               ; 0x1
	.quad	2                               ; 0x2
lCPI25_1:
	.quad	3                               ; 0x3
	.quad	4                               ; 0x4
lCPI25_2:
	.quad	5                               ; 0x5
	.quad	6                               ; 0x6
lCPI25_3:
	.quad	7                               ; 0x7
	.quad	8                               ; 0x8
lCPI25_4:
	.quad	9                               ; 0x9
	.quad	10                              ; 0xa
lCPI25_5:
	.quad	11                              ; 0xb
	.quad	12                              ; 0xc
lCPI25_6:
	.quad	13                              ; 0xd
	.quad	14                              ; 0xe
lCPI25_7:
	.quad	15                              ; 0xf
	.quad	16                              ; 0x10
lCPI25_8:
	.quad	17                              ; 0x11
	.quad	18                              ; 0x12
lCPI25_9:
	.quad	19                              ; 0x13
	.quad	20                              ; 0x14
lCPI25_10:
	.quad	21                              ; 0x15
	.quad	22                              ; 0x16
lCPI25_11:
	.quad	23                              ; 0x17
	.quad	24                              ; 0x18
lCPI25_12:
	.quad	25                              ; 0x19
	.quad	26                              ; 0x1a
lCPI25_13:
	.quad	27                              ; 0x1b
	.quad	28                              ; 0x1c
lCPI25_14:
	.quad	29                              ; 0x1d
	.quad	30                              ; 0x1e
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_ordered_cost_trace$instance$ff5e39efec5d08ee
	.p2align	2
_wf_ordered_cost_trace$instance$ff5e39efec5d08ee: ; @"wf_ordered_cost_trace$instance$ff5e39efec5d08ee"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #3472
	.cfi_def_cfa_offset 3568
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	str	x1, [sp, #16]                   ; 8-byte Folded Spill
	add	x27, sp, #576
	mov	x22, #58809                     ; =0xe5b9
	movk	x22, #7396, lsl #16
	movk	x22, #18285, lsl #32
	movk	x22, #48984, lsl #48
	strb	wzr, [sp, #3112]
	str	xzr, [sp, #3104]
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #3088]
	str	x2, [sp, #3120]
	mov	x23, #4587                      ; =0x11eb
	movk	x23, #4913, lsl #16
	movk	x23, #18875, lsl #32
	movk	x23, #38096, lsl #48
	add	x28, x27, #2512
	add	x25, x27, #2544
	str	xzr, [sp, #3128]
	str	q0, [sp, #3136]
	cbz	x0, LBB25_51
; %bb.1:                                ; %bb4.preheader
	mov	x24, x0
	str	x3, [sp, #568]                  ; 8-byte Folded Spill
	str	x25, [sp, #56]                  ; 8-byte Folded Spill
	mov	x19, #0                         ; =0x0
Lloh32:
	adrp	x8, lCPI25_0@PAGE
Lloh33:
	ldr	q0, [x8, lCPI25_0@PAGEOFF]
	str	q0, [sp, #304]                  ; 16-byte Folded Spill
Lloh34:
	adrp	x8, lCPI25_1@PAGE
Lloh35:
	ldr	q0, [x8, lCPI25_1@PAGEOFF]
	str	q0, [sp, #288]                  ; 16-byte Folded Spill
	add	x8, x27, #1128
	str	x8, [sp, #64]                   ; 8-byte Folded Spill
Lloh36:
	adrp	x8, lCPI25_2@PAGE
Lloh37:
	ldr	q0, [x8, lCPI25_2@PAGEOFF]
	str	q0, [sp, #272]                  ; 16-byte Folded Spill
	add	x8, x27, #2520
	str	x8, [sp, #48]                   ; 8-byte Folded Spill
Lloh38:
	adrp	x8, lCPI25_3@PAGE
Lloh39:
	ldr	q0, [x8, lCPI25_3@PAGEOFF]
	str	q0, [sp, #256]                  ; 16-byte Folded Spill
	mov	w20, #1                         ; =0x1
Lloh40:
	adrp	x8, lCPI25_4@PAGE
Lloh41:
	ldr	q0, [x8, lCPI25_4@PAGEOFF]
	str	q0, [sp, #240]                  ; 16-byte Folded Spill
Lloh42:
	adrp	x8, lCPI25_5@PAGE
Lloh43:
	ldr	q0, [x8, lCPI25_5@PAGEOFF]
	str	q0, [sp, #224]                  ; 16-byte Folded Spill
Lloh44:
	adrp	x8, lCPI25_6@PAGE
Lloh45:
	ldr	q0, [x8, lCPI25_6@PAGEOFF]
	str	q0, [sp, #208]                  ; 16-byte Folded Spill
Lloh46:
	adrp	x8, lCPI25_7@PAGE
Lloh47:
	ldr	q0, [x8, lCPI25_7@PAGEOFF]
	str	q0, [sp, #192]                  ; 16-byte Folded Spill
Lloh48:
	adrp	x8, lCPI25_8@PAGE
Lloh49:
	ldr	q0, [x8, lCPI25_8@PAGEOFF]
	str	q0, [sp, #176]                  ; 16-byte Folded Spill
Lloh50:
	adrp	x8, lCPI25_9@PAGE
Lloh51:
	ldr	q0, [x8, lCPI25_9@PAGEOFF]
	str	q0, [sp, #160]                  ; 16-byte Folded Spill
Lloh52:
	adrp	x8, lCPI25_10@PAGE
Lloh53:
	ldr	q0, [x8, lCPI25_10@PAGEOFF]
	str	q0, [sp, #144]                  ; 16-byte Folded Spill
Lloh54:
	adrp	x8, lCPI25_11@PAGE
Lloh55:
	ldr	q0, [x8, lCPI25_11@PAGEOFF]
	str	q0, [sp, #128]                  ; 16-byte Folded Spill
Lloh56:
	adrp	x8, lCPI25_12@PAGE
Lloh57:
	ldr	q0, [x8, lCPI25_12@PAGEOFF]
	str	q0, [sp, #112]                  ; 16-byte Folded Spill
	mov	w21, #131                       ; =0x83
Lloh58:
	adrp	x8, lCPI25_13@PAGE
Lloh59:
	ldr	q0, [x8, lCPI25_13@PAGEOFF]
	str	q0, [sp, #96]                   ; 16-byte Folded Spill
	mov	x25, x0
Lloh60:
	adrp	x8, lCPI25_14@PAGE
Lloh61:
	ldr	q0, [x8, lCPI25_14@PAGEOFF]
	str	q0, [sp, #80]                   ; 16-byte Folded Spill
	str	x2, [sp, #40]                   ; 8-byte Folded Spill
	mov	x26, x2
	b	LBB25_4
LBB25_2:                                ; %bb3.i
                                        ;   in Loop: Header=BB25_4 Depth=1
	ldrb	w8, [sp, #836]
	ldr	x9, [sp, #3120]
	tst	w8, #0x1
	cinc	x8, x20, ne
	madd	x8, x9, x21, x8
	ldr	x9, [sp, #840]
	ldr	x10, [sp, #848]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #856]
	ldr	x11, [sp, #864]
	madd	x9, x9, x21, x10
	madd	x9, x9, x21, x11
	ldr	x10, [sp, #872]
	ldr	x11, [sp, #880]
	madd	x9, x9, x21, x10
	madd	x9, x9, x21, x11
	ldr	x10, [sp, #888]
	ldr	x11, [sp, #896]
	madd	x9, x9, x21, x10
	madd	x9, x9, x21, x11
	ldr	x10, [sp, #904]
	ldr	x11, [sp, #912]
	madd	x9, x9, x21, x10
	madd	x9, x9, x21, x11
	ldr	x10, [sp, #920]
	ldr	x11, [sp, #928]
	madd	x9, x9, x21, x10
	madd	x9, x9, x21, x11
	ldr	x10, [sp, #936]
	ldr	x11, [sp, #944]
	madd	x9, x9, x21, x10
	madd	x9, x9, x21, x11
	ldr	x10, [sp, #952]
	ldr	x11, [sp, #960]
	madd	x9, x9, x21, x10
	madd	x9, x9, x21, x11
	ldr	x10, [sp, #968]
	ldr	x11, [sp, #976]
	madd	x9, x9, x21, x10
	madd	x9, x9, x21, x11
	ldr	x10, [sp, #984]
	ldr	x11, [sp, #992]
	madd	x9, x9, x21, x10
	madd	x9, x9, x21, x11
	ldr	x10, [sp, #1000]
	ldr	x11, [sp, #1008]
	madd	x9, x9, x21, x10
	madd	x9, x9, x21, x11
	ldr	x10, [sp, #1016]
	ldr	x11, [sp, #1024]
	madd	x9, x9, x21, x10
	madd	x9, x9, x21, x11
	ldr	x10, [sp, #1032]
	ldr	x11, [sp, #1040]
	madd	x9, x9, x21, x10
	madd	x9, x9, x21, x11
	ldr	x10, [sp, #1048]
	ldr	x11, [sp, #1056]
	madd	x9, x9, x21, x10
	madd	x9, x9, x21, x11
	ldr	x10, [sp, #1064]
	ldr	x11, [sp, #1072]
	madd	x9, x9, x21, x10
	madd	x9, x9, x21, x11
	ldr	x10, [sp, #1080]
	ldr	x11, [sp, #1088]
	madd	x9, x9, x21, x10
	madd	x9, x9, x21, x11
	ldr	x10, [sp, #1096]
	madd	x9, x9, x21, x10
	ldr	x10, [sp, #3128]
	add	x10, x9, x10
	str	x10, [sp, #3128]
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x22
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x23
	ldr	x10, [sp, #3136]
	eor	x10, x10, x9, lsr #31
	eor	x9, x10, x9
	str	x9, [sp, #3136]
	ldr	x9, [sp, #3144]
	add	x9, x9, #1
	str	x9, [sp, #3144]
LBB25_3:                                ; %"wf_ordered_cost_put_result$instance$ff5e39efec5d08ee.exit"
                                        ;   in Loop: Header=BB25_4 Depth=1
	str	x8, [sp, #3120]
	add	x19, x19, #73
	add	x26, x26, #1
	subs	x25, x25, #1
	b.eq	LBB25_6
LBB25_4:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v0, x26
	str	x26, [sp, #576]
	ldr	q1, [sp, #304]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x8, sp, #329
	stur	q1, [x8, #255]
	ldr	q1, [sp, #288]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x8, sp, #345
	stur	q1, [x8, #255]
	udiv	x8, x19, x24
	ldr	q1, [sp, #272]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #361
	stur	q1, [x9, #255]
	ldr	q1, [sp, #256]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #377
	stur	q1, [x9, #255]
	ldr	q1, [sp, #240]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #393
	stur	q1, [x9, #255]
	ldr	q1, [sp, #224]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #409
	stur	q1, [x9, #255]
	ldr	q1, [sp, #208]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #425
	stur	q1, [x9, #255]
	ldr	q1, [sp, #192]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	add	x9, sp, #441
	stur	q1, [x9, #255]
	ldr	q1, [sp, #176]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x27, #136]
	ldr	q1, [sp, #160]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x27, #152]
	msub	x8, x8, x24, x19
	orr	x2, x20, x8, lsl #1
	add	x8, x26, #31
	ldr	q1, [sp, #144]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x27, #168]
	ldr	q1, [sp, #128]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x27, #184]
	ldr	q1, [sp, #112]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x27, #200]
	ldr	q1, [sp, #96]                   ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	stur	q1, [x27, #216]
	ldr	q1, [sp, #80]                   ; 16-byte Folded Reload
	add.2d	v0, v0, v1
	stur	q0, [x27, #232]
	str	x8, [sp, #824]
	add	x0, x27, #256
	add	x3, sp, #576
	add	x4, x27, #2536
	mov	x1, x28
	bl	_wf_std.collections.ordered_map.ordered_map_put$instance$912c4c551bcb3786
	ldr	w8, [sp, #832]
	cbnz	w8, LBB25_2
; %bb.5:                                ; %bb2.i
                                        ;   in Loop: Header=BB25_4 Depth=1
	ldr	x8, [sp, #3120]
	mul	x8, x8, x21
	b	LBB25_3
LBB25_6:                                ; %bb7
	ldr	x9, [sp, #3104]
	mov	w10, #131                       ; =0x83
	madd	x8, x8, x10, x9
	str	x8, [sp, #3120]
	ldr	x10, [sp, #16]                  ; 8-byte Folded Reload
	cbz	x10, LBB25_52
; %bb.7:                                ; %bb13.preheader.lr.ph
	mov	x9, #0                          ; =0x0
	lsl	x8, x24, #1
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	mov	w27, #131                       ; =0x83
	ldr	x19, [sp, #40]                  ; 8-byte Folded Reload
	mov	x20, x19
	ldr	x25, [sp, #56]                  ; 8-byte Folded Reload
	ldr	x10, [sp, #568]                 ; 8-byte Folded Reload
	str	x28, [sp, #72]                  ; 8-byte Folded Spill
	b	LBB25_9
LBB25_8:                                ; %bb30
                                        ;   in Loop: Header=BB25_9 Depth=1
	ldp	x20, x9, [sp, #24]              ; 16-byte Folded Reload
	add	x9, x9, #1
	ldp	x11, x8, [sp, #8]               ; 16-byte Folded Reload
	add	x20, x20, x11
	ldr	x19, [sp, #40]                  ; 8-byte Folded Reload
	add	x19, x19, x24
	cmp	x9, x8
	b.eq	LBB25_50
LBB25_9:                                ; %bb13.preheader
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB25_13 Depth 2
	stp	x9, x19, [sp, #32]              ; 16-byte Folded Spill
	mov	x21, #0                         ; =0x0
	mov	x26, #0                         ; =0x0
	str	x20, [sp, #24]                  ; 8-byte Folded Spill
	b	LBB25_13
LBB25_10:                               ; %bb2.i246
                                        ;   in Loop: Header=BB25_13 Depth=2
	ldr	x8, [sp, #3120]
	mul	x8, x8, x27
	str	x8, [sp, #3120]
LBB25_11:                               ; %bb29
                                        ;   in Loop: Header=BB25_13 Depth=2
	ldr	x10, [sp, #568]                 ; 8-byte Folded Reload
LBB25_12:                               ; %bb29
                                        ;   in Loop: Header=BB25_13 Depth=2
	add	x26, x26, #1
	add	x21, x21, #73
	add	x20, x20, #2
	add	x19, x19, #1
	cmp	x24, x26
	b.eq	LBB25_8
LBB25_13:                               ; %bb14
                                        ;   Parent Loop BB25_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	udiv	x8, x21, x24
	msub	x9, x8, x24, x21
	lsl	x8, x9, #1
	str	x8, [sp, #3152]
	mov	w2, #1                          ; =0x1
	bfi	x2, x9, #1, #63
	str	x2, [sp, #3160]
	cmp	x10, #2
	b.gt	LBB25_18
; %bb.14:                               ; %bb14
                                        ;   in Loop: Header=BB25_13 Depth=2
	cmp	x10, #1
	b.eq	LBB25_22
; %bb.15:                               ; %bb14
                                        ;   in Loop: Header=BB25_13 Depth=2
	cmp	x10, #2
	b.ne	LBB25_12
; %bb.16:                               ; %bb21
                                        ;   in Loop: Header=BB25_13 Depth=2
	add	x8, x24, x20
	str	x8, [sp, #1152]
	add	x9, x8, #1
	add	x10, x8, #2
	str	x9, [sp, #560]                  ; 8-byte Folded Spill
	str	x9, [sp, #1160]
	add	x9, x8, #3
	add	x11, x8, #4
	str	x10, [sp, #552]                 ; 8-byte Folded Spill
	str	x10, [sp, #1168]
	add	x10, x8, #5
	add	x12, x8, #6
	str	x9, [sp, #544]                  ; 8-byte Folded Spill
	str	x9, [sp, #1176]
	add	x9, x8, #7
	add	x13, x8, #8
	str	x11, [sp, #536]                 ; 8-byte Folded Spill
	str	x11, [sp, #1184]
	add	x11, x8, #9
	add	x14, x8, #10
	str	x10, [sp, #528]                 ; 8-byte Folded Spill
	str	x10, [sp, #1192]
	add	x10, x8, #11
	add	x15, x8, #12
	str	x12, [sp, #520]                 ; 8-byte Folded Spill
	str	x12, [sp, #1200]
	add	x12, x8, #13
	add	x16, x8, #14
	stp	x13, x9, [sp, #504]             ; 16-byte Folded Spill
	str	x9, [sp, #1208]
	add	x9, x8, #15
	add	x17, x8, #16
	str	x13, [sp, #1216]
	add	x13, x8, #17
	add	x0, x8, #18
	stp	x14, x11, [sp, #488]            ; 16-byte Folded Spill
	str	x11, [sp, #1224]
	add	x11, x8, #19
	add	x1, x8, #20
	str	x14, [sp, #1232]
	add	x14, x8, #21
	add	x3, x8, #22
	stp	x15, x10, [sp, #472]            ; 16-byte Folded Spill
	str	x10, [sp, #1240]
	add	x10, x8, #23
	add	x4, x8, #24
	str	x15, [sp, #1248]
	add	x15, x8, #25
	add	x5, x8, #26
	stp	x16, x12, [sp, #456]            ; 16-byte Folded Spill
	str	x12, [sp, #1256]
	add	x12, x8, #27
	add	x6, x8, #28
	str	x16, [sp, #1264]
	add	x16, x8, #29
	add	x7, x8, #30
	stp	x17, x9, [sp, #440]             ; 16-byte Folded Spill
	str	x9, [sp, #1272]
	add	x8, x8, #31
	str	x17, [sp, #1280]
	stp	x0, x13, [sp, #424]             ; 16-byte Folded Spill
	str	x13, [sp, #1288]
	str	x0, [sp, #1296]
	stp	x1, x11, [sp, #408]             ; 16-byte Folded Spill
	str	x11, [sp, #1304]
	str	x1, [sp, #1312]
	stp	x3, x14, [sp, #392]             ; 16-byte Folded Spill
	str	x14, [sp, #1320]
	str	x3, [sp, #1328]
	stp	x4, x10, [sp, #376]             ; 16-byte Folded Spill
	str	x10, [sp, #1336]
	str	x4, [sp, #1344]
	stp	x5, x15, [sp, #360]             ; 16-byte Folded Spill
	str	x15, [sp, #1352]
	str	x5, [sp, #1360]
	stp	x6, x12, [sp, #344]             ; 16-byte Folded Spill
	str	x12, [sp, #1368]
	str	x6, [sp, #1376]
	stp	x7, x16, [sp, #328]             ; 16-byte Folded Spill
	str	x16, [sp, #1384]
	str	x7, [sp, #1392]
	str	x8, [sp, #320]                  ; 8-byte Folded Spill
	str	x8, [sp, #1400]
	add	x8, sp, #576
	add	x0, x8, #832
	add	x3, x8, #576
	add	x4, x8, #2536
	mov	x1, x28
	bl	_wf_std.collections.ordered_map.ordered_map_put$instance$912c4c551bcb3786
	ldr	w8, [sp, #1408]
	cbz	w8, LBB25_27
; %bb.17:                               ; %bb3.i116
                                        ;   in Loop: Header=BB25_13 Depth=2
	ldr	x9, [sp, #1416]
	ldrb	w8, [sp, #1412]
	ldr	x10, [sp, #3120]
	tst	w8, #0x1
	mov	w8, #1                          ; =0x1
	cinc	x8, x8, ne
	madd	x8, x10, x27, x8
	ldr	x10, [sp, #1424]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1432]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1440]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1448]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1456]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1464]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1472]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1480]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1488]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1496]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1504]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1512]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1520]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1528]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1536]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1544]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1552]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1560]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1568]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1576]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1584]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1592]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1600]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1608]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1616]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1624]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1632]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1640]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1648]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1656]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1664]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #1672]
	madd	x9, x9, x27, x10
	ldr	x10, [sp, #3128]
	add	x10, x9, x10
	str	x10, [sp, #3128]
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x22
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x23
	ldr	x10, [sp, #3136]
	eor	x10, x10, x9, lsr #31
	eor	x9, x10, x9
	str	x9, [sp, #3136]
	ldr	x9, [sp, #3144]
	add	x9, x9, #1
	str	x9, [sp, #3144]
	b	LBB25_28
LBB25_18:                               ; %bb14
                                        ;   in Loop: Header=BB25_13 Depth=2
	cmp	x10, #3
	b.eq	LBB25_24
; %bb.19:                               ; %bb14
                                        ;   in Loop: Header=BB25_13 Depth=2
	cmp	x10, #4
	b.ne	LBB25_12
; %bb.20:                               ; %bb27
                                        ;   in Loop: Header=BB25_13 Depth=2
	add	x8, x24, x19
	add	x9, x8, #31
	str	x8, [sp, #2504]
	dup.2d	v0, x8
	ldr	q1, [sp, #304]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2512]
	ldr	q1, [sp, #288]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2528]
	ldr	q1, [sp, #272]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2544]
	ldr	q1, [sp, #256]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2560]
	ldr	q1, [sp, #240]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2576]
	ldr	q1, [sp, #224]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2592]
	ldr	q1, [sp, #208]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2608]
	ldr	q1, [sp, #192]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2624]
	ldr	q1, [sp, #176]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2640]
	ldr	q1, [sp, #160]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2656]
	ldr	q1, [sp, #144]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2672]
	ldr	q1, [sp, #128]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2688]
	ldr	q1, [sp, #112]                  ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2704]
	ldr	q1, [sp, #96]                   ; 16-byte Folded Reload
	add.2d	v1, v0, v1
	str	q1, [sp, #2720]
	ldr	q1, [sp, #80]                   ; 16-byte Folded Reload
	add.2d	v0, v0, v1
	str	q0, [sp, #2736]
	str	x9, [sp, #2752]
	add	x8, sp, #576
	add	x0, x8, #2184
	add	x3, x8, #1928
	add	x4, x8, #2536
	mov	x1, x28
	bl	_wf_std.collections.ordered_map.ordered_map_put$instance$912c4c551bcb3786
	ldr	w8, [sp, #2760]
	cbz	w8, LBB25_10
; %bb.21:                               ; %bb3.i321
                                        ;   in Loop: Header=BB25_13 Depth=2
	ldrb	w8, [sp, #2764]
	ldr	x9, [sp, #3120]
	tst	w8, #0x1
	mov	w8, #1                          ; =0x1
	cinc	x8, x8, ne
	madd	x8, x9, x27, x8
	ldr	x9, [sp, #2768]
	str	x8, [sp, #3120]
	ldr	x8, [sp, #2776]
	madd	x8, x9, x27, x8
	ldr	x9, [sp, #2784]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2792]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2800]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2808]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2816]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2824]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2832]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2840]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2848]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2856]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2864]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2872]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2880]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2888]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2896]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2904]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2912]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2920]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2928]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2936]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2944]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2952]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2960]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2968]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2976]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2984]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2992]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #3000]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #3008]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #3016]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #3024]
	b	LBB25_49
LBB25_22:                               ; %bb18
                                        ;   in Loop: Header=BB25_13 Depth=2
	ldr	x8, [sp, #3088]
	cbz	x8, LBB25_40
; %bb.23:                               ; %bb2.i.i.i.i
                                        ;   in Loop: Header=BB25_13 Depth=2
	ldr	x0, [sp, #3096]
	add	x8, sp, #576
	add	x1, x8, #2584
	add	x2, x8, #2536
	mov	x3, x25
	bl	_wf_std.collections.ordered_map.ordered_map_lookup_node$instance$768bf1dd9f398f38
	mov	x8, x2
	ldr	x2, [sp, #3160]
	ldr	x9, [sp, #3088]
	cmp	x9, #0
	cset	w9, eq
	b	LBB25_41
LBB25_24:                               ; %bb24
                                        ;   in Loop: Header=BB25_13 Depth=2
	add	x9, x8, #32
	str	x9, [sp, #3176]
	cmn	x8, #33
	b.hi	LBB25_12
; %bb.25:                               ; %bb2.i252
                                        ;   in Loop: Header=BB25_13 Depth=2
	ldr	x8, [sp, #3088]
	cbz	x8, LBB25_12
; %bb.26:                               ; %bb2.i.i254
                                        ;   in Loop: Header=BB25_13 Depth=2
	ldr	x0, [sp, #3096]
	add	x8, sp, #576
	add	x1, x8, #2576
	add	x2, x8, #2600
	add	x3, x8, #2536
	mov	x4, x25
	bl	_wf_std.collections.ordered_map.ordered_map_range_node$instance$475e4daed49f96af
	b	LBB25_11
LBB25_27:                               ; %bb2.i126
                                        ;   in Loop: Header=BB25_13 Depth=2
	ldr	x8, [sp, #3120]
	mul	x8, x8, x27
LBB25_28:                               ; %"wf_ordered_cost_put_result$instance$ff5e39efec5d08ee.exit129"
                                        ;   in Loop: Header=BB25_13 Depth=2
	str	x8, [sp, #3120]
	ldr	x9, [sp, #3088]
	cbz	x9, LBB25_30
; %bb.29:                               ; %bb2.i.i.i.i132
                                        ;   in Loop: Header=BB25_13 Depth=2
	ldr	x0, [sp, #3096]
	add	x8, sp, #576
	add	x1, x8, #2584
	add	x2, x8, #2536
	mov	x3, x25
	bl	_wf_std.collections.ordered_map.ordered_map_edit_node$instance$887d1b484f24fc68
	ldr	x8, [sp, #3120]
	ldr	x28, [sp, #3088]
	b	LBB25_31
LBB25_30:                               ;   in Loop: Header=BB25_13 Depth=2
	mov	x28, #0                         ; =0x0
	mov	w2, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
LBB25_31:                               ; %"wf_std.collections.ordered_map.ordered_map_edit$instance$374d92b1aa276be7.exit"
                                        ;   in Loop: Header=BB25_13 Depth=2
	str	w0, [sp, #1680]
	str	x1, [sp, #1688]
	strb	w2, [sp, #1696]
	cmp	w0, #0
	mul	x8, x8, x27
	cinc	x8, x8, eq
	str	x8, [sp, #3120]
	cbz	x28, LBB25_46
; %bb.32:                               ; %"wf_std.collections.ordered_map.ordered_map_remove_link$instance$43c0c30766ba2e8b.exit.i"
                                        ;   in Loop: Header=BB25_13 Depth=2
	ldr	x1, [sp, #3096]
	add	x0, sp, #3184
	add	x8, sp, #576
	add	x2, x8, #2584
	add	x3, x8, #2536
	bl	_wf_std.collections.ordered_map.ordered_map_remove_node$instance$43c0c30766ba2e8b
	ldr	w8, [sp, #3184]
	cbz	w8, LBB25_45
; %bb.33:                               ; %bb2.i3.i
                                        ;   in Loop: Header=BB25_13 Depth=2
	sub	x23, x28, #1
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	add	x25, x8, x23, lsl #3
	str	x23, [sp, #3088]
	ldr	x0, [x25]
	ldr	x8, [x0, #16]
	cbnz	x8, LBB25_37
; %bb.34:                               ; %bb5.i.i
                                        ;   in Loop: Header=BB25_13 Depth=2
	ldp	x28, x22, [x0]
	bl	_free
	str	x22, [sp, #3464]
	cbz	x28, LBB25_36
; %bb.35:                               ; %run.move.body.v3.preheader.i.i.i
                                        ;   in Loop: Header=BB25_13 Depth=2
	lsl	x2, x28, #3
	add	x1, sp, #3464
	mov	x0, x25
	bl	_memcpy
LBB25_36:                               ; %"wf_append$instance$42f33d80f30f592c.exit.i.i"
                                        ;   in Loop: Header=BB25_13 Depth=2
	add	x28, x28, x23
	mov	x22, #58809                     ; =0xe5b9
	movk	x22, #7396, lsl #16
	movk	x22, #18285, lsl #32
	movk	x22, #48984, lsl #48
LBB25_37:                               ; %"wf_std.collections.ordered_map.ordered_map_contract_root$instance$d883f474bea0047c.exit.i"
                                        ;   in Loop: Header=BB25_13 Depth=2
	str	x28, [sp, #3088]
	ldr	x8, [sp, #3104]
	cbz	x8, LBB25_39
; %bb.38:                               ; %bb4.i
                                        ;   in Loop: Header=BB25_13 Depth=2
	sub	x8, x8, #1
	str	x8, [sp, #3104]
LBB25_39:                               ; %bb2.i165
                                        ;   in Loop: Header=BB25_13 Depth=2
	mov	w8, #1                          ; =0x1
	str	x8, [sp, #1704]
	add	x8, sp, #576
	add	x0, x8, #1136
	add	x8, sp, #3184
	add	x1, x8, #8
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	ldr	x8, [sp, #1712]
	ldr	x9, [sp, #3120]
	mov	x10, #1                         ; =0x1
	madd	x9, x9, x27, x10
	str	x9, [sp, #3120]
	ldr	x9, [sp, #1720]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1728]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1736]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1744]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1752]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1760]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1768]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1776]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1784]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1792]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1800]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1808]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1816]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1824]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1832]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1840]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1848]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1856]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1864]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1872]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1880]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1888]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1896]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1904]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1912]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1920]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1928]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1936]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1944]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1952]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1960]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #1968]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #3128]
	add	x9, x8, x9
	str	x9, [sp, #3128]
	eor	x8, x8, x8, lsr #30
	mul	x8, x8, x22
	eor	x8, x8, x8, lsr #27
	mov	x23, #4587                      ; =0x11eb
	movk	x23, #4913, lsl #16
	movk	x23, #18875, lsl #32
	movk	x23, #38096, lsl #48
	mul	x8, x8, x23
	ldr	x9, [sp, #3136]
	eor	x9, x9, x8, lsr #31
	eor	x8, x9, x8
	str	x8, [sp, #3136]
	ldr	x8, [sp, #3144]
	add	x8, x8, #1
	str	x8, [sp, #3144]
	ldr	x25, [sp, #56]                  ; 8-byte Folded Reload
	b	LBB25_47
LBB25_40:                               ;   in Loop: Header=BB25_13 Depth=2
	mov	x1, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	mov	w0, #1                          ; =0x1
LBB25_41:                               ; %"wf_std.collections.ordered_map.ordered_map_lookup$instance$27c9a7455d5e3844.exit"
                                        ;   in Loop: Header=BB25_13 Depth=2
	str	w0, [sp, #1104]
	str	x1, [sp, #1112]
	strb	w8, [sp, #1120]
	cmp	w0, #0
	ldr	x8, [sp, #3120]
	mul	x8, x8, x27
	cinc	x8, x8, eq
	str	x8, [sp, #3120]
	sub	x10, x2, #1
	str	x10, [sp, #3168]
	tbz	w9, #0, LBB25_43
; %bb.42:                               ;   in Loop: Header=BB25_13 Depth=2
	mov	w2, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	b	LBB25_44
LBB25_43:                               ; %bb2.i.i.i.i31
                                        ;   in Loop: Header=BB25_13 Depth=2
	ldr	x0, [sp, #3096]
	add	x8, sp, #576
	add	x1, x8, #2592
	add	x2, x8, #2536
	mov	x3, x25
	bl	_wf_std.collections.ordered_map.ordered_map_lookup_node$instance$768bf1dd9f398f38
	ldr	x8, [sp, #3120]
LBB25_44:                               ; %"wf_std.collections.ordered_map.ordered_map_lookup$instance$27c9a7455d5e3844.exit44"
                                        ;   in Loop: Header=BB25_13 Depth=2
	ldr	x10, [sp, #568]                 ; 8-byte Folded Reload
	str	w0, [sp, #1128]
	str	x1, [sp, #1136]
	strb	w2, [sp, #1144]
	cmp	w0, #0
	mul	x8, x8, x27
	cinc	x8, x8, eq
	str	x8, [sp, #3120]
	b	LBB25_12
LBB25_45:                               ; %"wf_std.collections.ordered_map.ordered_map_remove_link$instance$43c0c30766ba2e8b.exit.i.bb3.i162_crit_edge"
                                        ;   in Loop: Header=BB25_13 Depth=2
	ldr	x8, [sp, #3120]
LBB25_46:                               ; %bb3.i162
                                        ;   in Loop: Header=BB25_13 Depth=2
	ldr	x9, [sp, #64]                   ; 8-byte Folded Reload
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9, #240]
	stp	q0, q0, [x9, #208]
	stp	q0, q0, [x9, #176]
	stp	q0, q0, [x9, #144]
	stp	q0, q0, [x9, #112]
	stp	q0, q0, [x9, #80]
	stp	q0, q0, [x9, #48]
	stp	q0, q0, [x9, #16]
	str	q0, [x9]
	mul	x8, x8, x27
	str	x8, [sp, #3120]
LBB25_47:                               ; %"wf_ordered_cost_taken_result$instance$ff5e39efec5d08ee.exit"
                                        ;   in Loop: Header=BB25_13 Depth=2
	ldr	x28, [sp, #72]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #560]                  ; 8-byte Folded Reload
	str	x8, [sp, #1976]
	ldr	x8, [sp, #552]                  ; 8-byte Folded Reload
	str	x8, [sp, #1984]
	ldr	x8, [sp, #544]                  ; 8-byte Folded Reload
	str	x8, [sp, #1992]
	ldr	x8, [sp, #536]                  ; 8-byte Folded Reload
	str	x8, [sp, #2000]
	ldr	x8, [sp, #528]                  ; 8-byte Folded Reload
	str	x8, [sp, #2008]
	ldr	x8, [sp, #520]                  ; 8-byte Folded Reload
	str	x8, [sp, #2016]
	ldp	x8, x9, [sp, #504]              ; 16-byte Folded Reload
	str	x9, [sp, #2024]
	str	x8, [sp, #2032]
	ldp	x8, x9, [sp, #488]              ; 16-byte Folded Reload
	str	x9, [sp, #2040]
	str	x8, [sp, #2048]
	ldp	x8, x9, [sp, #472]              ; 16-byte Folded Reload
	str	x9, [sp, #2056]
	str	x8, [sp, #2064]
	ldp	x8, x9, [sp, #456]              ; 16-byte Folded Reload
	str	x9, [sp, #2072]
	str	x8, [sp, #2080]
	ldp	x8, x9, [sp, #440]              ; 16-byte Folded Reload
	str	x9, [sp, #2088]
	str	x8, [sp, #2096]
	ldp	x8, x9, [sp, #424]              ; 16-byte Folded Reload
	str	x9, [sp, #2104]
	str	x8, [sp, #2112]
	ldp	x8, x9, [sp, #408]              ; 16-byte Folded Reload
	str	x9, [sp, #2120]
	str	x8, [sp, #2128]
	ldp	x8, x9, [sp, #392]              ; 16-byte Folded Reload
	str	x9, [sp, #2136]
	str	x8, [sp, #2144]
	ldp	x8, x9, [sp, #376]              ; 16-byte Folded Reload
	str	x9, [sp, #2152]
	str	x8, [sp, #2160]
	ldp	x8, x9, [sp, #360]              ; 16-byte Folded Reload
	str	x9, [sp, #2168]
	str	x8, [sp, #2176]
	ldp	x8, x9, [sp, #344]              ; 16-byte Folded Reload
	str	x9, [sp, #2184]
	str	x8, [sp, #2192]
	ldp	x8, x9, [sp, #328]              ; 16-byte Folded Reload
	str	x9, [sp, #2200]
	str	x8, [sp, #2208]
	ldr	x8, [sp, #320]                  ; 8-byte Folded Reload
	str	x8, [sp, #2216]
	add	x8, x24, x20
	add	x8, x8, #32
	str	x8, [sp, #2224]
	ldr	x2, [sp, #3160]
	add	x8, sp, #576
	add	x0, x8, #1656
	add	x3, x8, #1400
	add	x4, x8, #2536
	mov	x1, x28
	bl	_wf_std.collections.ordered_map.ordered_map_put$instance$912c4c551bcb3786
	ldr	w8, [sp, #2232]
	cbz	w8, LBB25_10
; %bb.48:                               ; %bb3.i235
                                        ;   in Loop: Header=BB25_13 Depth=2
	ldrb	w8, [sp, #2236]
	ldr	x9, [sp, #3120]
	tst	w8, #0x1
	mov	w8, #1                          ; =0x1
	cinc	x8, x8, ne
	madd	x8, x9, x27, x8
	ldr	x9, [sp, #2240]
	str	x8, [sp, #3120]
	ldr	x8, [sp, #2248]
	madd	x8, x9, x27, x8
	ldr	x9, [sp, #2256]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2264]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2272]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2280]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2288]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2296]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2304]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2312]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2320]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2328]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2336]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2344]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2352]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2360]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2368]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2376]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2384]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2392]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2400]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2408]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2416]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2424]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2432]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2440]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2448]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2456]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2464]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2472]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2480]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2488]
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #2496]
LBB25_49:                               ; %bb29
                                        ;   in Loop: Header=BB25_13 Depth=2
	madd	x8, x8, x27, x9
	ldr	x9, [sp, #3128]
	add	x9, x8, x9
	str	x9, [sp, #3128]
	eor	x8, x8, x8, lsr #30
	mul	x8, x8, x22
	eor	x8, x8, x8, lsr #27
	mul	x8, x8, x23
	ldr	x9, [sp, #3136]
	eor	x9, x9, x8, lsr #31
	eor	x8, x9, x8
	str	x8, [sp, #3136]
	ldr	x8, [sp, #3144]
	add	x8, x8, #1
	str	x8, [sp, #3144]
	b	LBB25_11
LBB25_50:                               ; %bb1.loopexit
	ldr	x9, [sp, #3104]
	ldr	x8, [sp, #3120]
	b	LBB25_53
LBB25_51:                               ; %bb3
	mov	x9, #0                          ; =0x0
	mov	w8, #131                        ; =0x83
	mul	x8, x2, x8
	b	LBB25_53
LBB25_52:
	ldr	x25, [sp, #56]                  ; 8-byte Folded Reload
LBB25_53:                               ; %bb1
	add	x10, sp, #576
	add	x19, x10, #2456
	mov	w10, #131                       ; =0x83
	madd	x8, x8, x10, x9
	str	x8, [sp, #3120]
	mov	x0, x28
	mov	x1, x25
	bl	_wf_std.collections.ordered_map.ordered_map_each_link$instance$5703a7a9bf1884ed
	ldr	q0, [x28]
	str	q0, [x19]
	ldr	x8, [x28, #16]
	str	x8, [sp, #3048]
	ldr	q0, [x28]
	str	q0, [sp, #3184]
	ldr	x8, [sp, #3184]
	cbz	x8, LBB25_55
; %bb.54:                               ; %bb2.i.i
	sub	x8, x8, #1
	add	x9, sp, #3184
	add	x9, x9, x8, lsl #3
	str	x8, [sp, #3184]
	ldr	x0, [x9, #8]
	mov	x1, x25
	bl	_wf_std.collections.ordered_map.ordered_map_free_node$instance$40650b236ee646e0
LBB25_55:                               ; %"wf_std.collections.ordered_map.ordered_map_free$instance$56a8ddd8129b5d48.exit"
	ldp	q0, q1, [x25]
	str	q0, [sp, #3056]
	str	q1, [sp, #3072]
	ldr	x8, [sp, #3056]
	ldr	x9, [sp, #3064]
	ldr	x10, [sp, #3072]
	ldr	x11, [sp, #3080]
	eor	x8, x8, x8, lsr #30
	mul	x8, x8, x22
	eor	x8, x8, x8, lsr #27
	mul	x8, x8, x23
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x22
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x23
	eor	x12, x9, x8
	mov	x13, #31765                     ; =0x7c15
	movk	x13, #32586, lsl #16
	movk	x13, #31161, lsl #32
	movk	x13, #40503, lsl #48
	mul	x11, x11, x13
	eor	x10, x10, x11
	eor	x10, x10, x12, lsr #31
	eor	x8, x8, x9
	eor	x0, x10, x8
	add	sp, sp, #3472
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh60, Lloh61
	.loh AdrpAdrp	Lloh58, Lloh60
	.loh AdrpLdr	Lloh58, Lloh59
	.loh AdrpAdrp	Lloh56, Lloh58
	.loh AdrpLdr	Lloh56, Lloh57
	.loh AdrpAdrp	Lloh54, Lloh56
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpAdrp	Lloh52, Lloh54
	.loh AdrpLdr	Lloh52, Lloh53
	.loh AdrpAdrp	Lloh50, Lloh52
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpAdrp	Lloh48, Lloh50
	.loh AdrpLdr	Lloh48, Lloh49
	.loh AdrpAdrp	Lloh46, Lloh48
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpAdrp	Lloh44, Lloh46
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpAdrp	Lloh42, Lloh44
	.loh AdrpLdr	Lloh42, Lloh43
	.loh AdrpAdrp	Lloh40, Lloh42
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpAdrp	Lloh38, Lloh40
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpAdrp	Lloh32, Lloh34
	.loh AdrpLdr	Lloh32, Lloh33
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_new$instance$e85fc351f8333b14 ; -- Begin function wf_std.collections.ordered_map.ordered_map_new$instance$e85fc351f8333b14
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_new$instance$e85fc351f8333b14: ; @"wf_std.collections.ordered_map.ordered_map_new$instance$e85fc351f8333b14"
; %bb.0:                                ; %entry
	mov	x0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_put$instance$c2a7dc263c55706f ; -- Begin function wf_std.collections.ordered_map.ordered_map_put$instance$c2a7dc263c55706f
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_put$instance$c2a7dc263c55706f: ; @"wf_std.collections.ordered_map.ordered_map_put$instance$c2a7dc263c55706f"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #160
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 160
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x1
	mov	x19, x0
	ldr	x22, [x1]
	cbz	x22, LBB27_17
; %bb.1:                                ; %bb2
	add	x21, x20, #8
	mov	x8, x21
	b	LBB27_4
LBB27_2:                                ; %bb2.i
                                        ;   in Loop: Header=BB27_4 Depth=1
	cbz	x10, LBB27_12
LBB27_3:                                ; %bb10.i
                                        ;   in Loop: Header=BB27_4 Depth=1
	add	x8, x9, x10, lsl #5
	ldur	x9, [x8, #-8]
	cbz	x9, LBB27_14
LBB27_4:                                ; %bb1.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB27_6 Depth 2
	ldr	x8, [x8]
	mov	x9, x8
	ldr	x11, [x9, #16]!
	cbz	x11, LBB27_9
; %bb.5:                                ; %bb2.lr.ph.i.i.i.i
                                        ;   in Loop: Header=BB27_4 Depth=1
	mov	x10, #0                         ; =0x0
	add	x12, x8, #24
LBB27_6:                                ; %bb2.i.i.i.i
                                        ;   Parent Loop BB27_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x13, [x12], #32
	cmp	x2, x13
	b.ls	LBB27_10
; %bb.7:                                ; %bb8.i.i.i.i
                                        ;   in Loop: Header=BB27_6 Depth=2
	add	x10, x10, #1
	cmp	x11, x10
	b.ne	LBB27_6
; %bb.8:                                ;   in Loop: Header=BB27_4 Depth=1
	mov	x10, x11
	b	LBB27_3
LBB27_9:                                ;   in Loop: Header=BB27_4 Depth=1
	mov	x10, #0                         ; =0x0
LBB27_10:                               ; %"wf_std.collections.ordered_map.ordered_map_search$instance$5046b787ff5cdb3f.exit.i"
                                        ;   in Loop: Header=BB27_4 Depth=1
	cmp	x10, x11
	b.hs	LBB27_2
; %bb.11:                               ; %bb3.i
                                        ;   in Loop: Header=BB27_4 Depth=1
	add	x11, x9, x10, lsl #5
	ldr	x12, [x11, #8]
	cmp	x2, x12
	b.ne	LBB27_2
	b	LBB27_23
LBB27_12:                               ; %bb9.i
                                        ;   in Loop: Header=BB27_4 Depth=1
	ldr	x9, [x8], #8
	cbz	x9, LBB27_14
; %bb.13:                               ; %bb12.i
                                        ;   in Loop: Header=BB27_4 Depth=1
	b	LBB27_4
LBB27_14:                               ; %bb1
	mov	x23, x20
	ldr	x24, [x23, #16]!
	lsr	x8, x24, #13
	cbnz	x8, LBB27_18
; %bb.15:                               ; %bb9
	stp	x2, x3, [sp, #48]
	ldr	x1, [x21]
	add	x0, sp, #8
	add	x2, sp, #48
	mov	x3, x4
	bl	_wf_std.collections.ordered_map.ordered_map_insert_node$instance$5046b787ff5cdb3f
	ldr	w8, [sp, #8]
	cbz	w8, LBB27_22
; %bb.16:                               ; %run.move.body.v3.preheader.i
	ldp	x26, x27, [sp, #16]
	ldp	x24, x25, [sp, #32]
	lsl	x2, x22, #3
	str	xzr, [sp]
	mov	x0, sp
	mov	x1, x21
	bl	_memcpy
	ldr	x21, [sp]
	b	LBB27_20
LBB27_17:                               ; %bb1.thread
	mov	x23, x20
	ldr	x8, [x23, #16]!
	lsr	x8, x8, #13
	cbz	x8, LBB27_19
LBB27_18:                               ; %bb8
	stp	xzr, x2, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	strb	w8, [x19, #4]
	str	x3, [x19, #16]
	b	LBB27_24
LBB27_19:                               ; %bb9.thread
	mov	x21, #0                         ; =0x0
	mov	x24, #0                         ; =0x0
	mov	x25, #0                         ; =0x0
	stp	x2, x3, [sp, #48]
	mov	w8, #1                          ; =0x1
	stp	x8, x2, [sp, #8]
	mov	x26, x2
	stp	xzr, xzr, [sp, #32]
	mov	x27, x3
	str	x3, [sp, #24]
	str	xzr, [sp]
LBB27_20:                               ; %"wf_append$instance$48c61fa9751a6936.exit"
	str	xzr, [x20]
	mov	w0, #504                        ; =0x1f8
	bl	_malloc
	cbz	x0, LBB27_25
; %bb.21:                               ; %"wf_box_new$instance$dc0681021cdc805e.exit"
	stp	x22, x21, [x0]
	mov	w8, #1                          ; =0x1
	stp	x8, x26, [x0, #16]
	stp	x27, x24, [x0, #32]
	str	x25, [x0, #48]
	movi.2d	v0, #0000000000000000
	stur	q0, [x0, #72]
	stur	q0, [x0, #88]
	stur	q0, [x0, #104]
	stur	q0, [x0, #120]
	stur	q0, [x0, #136]
	stur	q0, [x0, #152]
	stur	q0, [x0, #168]
	stur	q0, [x0, #184]
	stur	q0, [x0, #200]
	stur	q0, [x0, #216]
	stur	q0, [x0, #232]
	stur	q0, [x0, #248]
	mov	x9, x0
	str	q0, [x9, #56]!
	stp	q0, q0, [x9, #208]
	stp	q0, q0, [x9, #240]
	stp	q0, q0, [x9, #272]
	stp	q0, q0, [x9, #304]
	stp	q0, q0, [x9, #336]
	stp	q0, q0, [x9, #368]
	stp	q0, q0, [x9, #400]
	str	q0, [x9, #432]
	stp	x8, x0, [x20]
	ldr	x24, [x20, #16]
LBB27_22:                               ; %bb10
	add	x8, x24, #1
	str	x8, [x23]
	stp	xzr, xzr, [x19]
	str	xzr, [x19, #16]
	b	LBB27_24
LBB27_23:                               ; %bb5
	ldr	x8, [x11, #16]
	str	x3, [x11, #16]
	stp	xzr, x2, [x19]
	mov	w9, #1                          ; =0x1
	str	w9, [x19]
	str	x8, [x19, #16]
LBB27_24:                               ; %common.ret
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB27_25:                               ; %box.new.oom.v1.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_ordered_cost_put_result$instance$fa3caca27a003293 ; -- Begin function wf_ordered_cost_put_result$instance$fa3caca27a003293
	.p2align	2
_wf_ordered_cost_put_result$instance$fa3caca27a003293: ; @"wf_ordered_cost_put_result$instance$fa3caca27a003293"
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cbz	w8, LBB28_2
; %bb.1:                                ; %bb3
	ldrb	w8, [x0, #4]
	mov	w9, #131                        ; =0x83
	tst	w8, #0x1
	mov	w8, #1                          ; =0x1
	cinc	x8, x8, ne
	ldp	x10, x11, [x1]
	madd	x8, x10, x9, x8
	ldp	x12, x10, [x0, #8]
	madd	x9, x12, x9, x10
	add	x10, x11, x9
	stp	x8, x10, [x1]
	eor	x8, x9, x9, lsr #30
	mov	x9, #58809                      ; =0xe5b9
	movk	x9, #7396, lsl #16
	movk	x9, #18285, lsl #32
	movk	x9, #48984, lsl #48
	mul	x8, x8, x9
	eor	x8, x8, x8, lsr #27
	mov	x9, #4587                       ; =0x11eb
	movk	x9, #4913, lsl #16
	movk	x9, #18875, lsl #32
	movk	x9, #38096, lsl #48
	mul	x8, x8, x9
	ldp	x9, x10, [x1, #16]
	eor	x9, x9, x8, lsr #31
	eor	x8, x9, x8
	add	x9, x10, #1
	stp	x8, x9, [x1, #16]
	mov	w0, #0                          ; =0x0
	ret
LBB28_2:                                ; %bb2
	ldr	x8, [x1]
	mov	w9, #131                        ; =0x83
	mul	x8, x8, x9
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_len$instance$e85fc351f8333b14 ; -- Begin function wf_std.collections.ordered_map.ordered_map_len$instance$e85fc351f8333b14
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_len$instance$e85fc351f8333b14: ; @"wf_std.collections.ordered_map.ordered_map_len$instance$e85fc351f8333b14"
; %bb.0:                                ; %entry
	ldr	x0, [x0, #16]
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_lookup$instance$107186e54bef911a ; -- Begin function wf_std.collections.ordered_map.ordered_map_lookup$instance$107186e54bef911a
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_lookup$instance$107186e54bef911a: ; @"wf_std.collections.ordered_map.ordered_map_lookup$instance$107186e54bef911a"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB30_2
; %bb.1:                                ; %bb2.i.i.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #8]
	bl	_wf_std.collections.ordered_map.ordered_map_lookup_node$instance$11eb30e8dabe0f7e
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB30_2:
	mov	w2, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_edit$instance$2c340453a2bb7cf7 ; -- Begin function wf_std.collections.ordered_map.ordered_map_edit$instance$2c340453a2bb7cf7
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_edit$instance$2c340453a2bb7cf7: ; @"wf_std.collections.ordered_map.ordered_map_edit$instance$2c340453a2bb7cf7"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB31_2
; %bb.1:                                ; %bb2.i.i.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #8]
	bl	_wf_std.collections.ordered_map.ordered_map_edit_node$instance$41f33845185638b6
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB31_2:
	mov	w2, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_remove$instance$c2a7dc263c55706f ; -- Begin function wf_std.collections.ordered_map.ordered_map_remove$instance$c2a7dc263c55706f
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_remove$instance$c2a7dc263c55706f: ; @"wf_std.collections.ordered_map.ordered_map_remove$instance$c2a7dc263c55706f"
; %bb.0:                                ; %entry
	sub	sp, sp, #96
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	ldr	x20, [x0]
	cbz	x20, LBB32_9
; %bb.1:                                ; %"wf_std.collections.ordered_map.ordered_map_remove_link$instance$5046b787ff5cdb3f.exit.i"
	mov	x19, x0
	ldr	x0, [x0, #8]
	bl	_wf_std.collections.ordered_map.ordered_map_remove_node$instance$5046b787ff5cdb3f
	cbz	w0, LBB32_10
; %bb.2:                                ; %bb2.i.i
	sub	x21, x20, #1
	add	x24, x19, x21, lsl #3
	str	x21, [x19]
	ldr	x0, [x24, #8]
	ldr	x8, [x0, #16]
	cbnz	x8, LBB32_6
; %bb.3:                                ; %bb5.i.i
	mov	x22, x2
	mov	x23, x1
	ldp	x20, x25, [x0]
	bl	_free
	str	x25, [sp, #8]
	cbz	x20, LBB32_5
; %bb.4:                                ; %run.move.body.v3.preheader.i.i.i
	lsl	x2, x20, #3
	add	x0, x24, #8
	add	x1, sp, #8
	bl	_memcpy
LBB32_5:                                ; %"wf_append$instance$48c61fa9751a6936.exit.i.i"
	add	x20, x20, x21
	mov	x1, x23
	mov	x2, x22
LBB32_6:                                ; %"wf_std.collections.ordered_map.ordered_map_contract_root$instance$0ed342445dd803f3.exit.i"
	str	x20, [x19]
	ldr	x8, [x19, #16]
	cbz	x8, LBB32_8
; %bb.7:                                ; %bb4.i
	sub	x8, x8, #1
	str	x8, [x19, #16]
LBB32_8:                                ; %"wf_std.collections.ordered_map.ordered_map_remove$instance$c2a7dc263c55706f.body.exit"
	mov	w0, #1                          ; =0x1
	b	LBB32_11
LBB32_9:
	mov	w0, #0                          ; =0x0
LBB32_10:
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
LBB32_11:                               ; %"wf_std.collections.ordered_map.ordered_map_remove$instance$c2a7dc263c55706f.body.exit"
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
                                        ; -- End function
	.globl	_wf_ordered_cost_taken_result$instance$fa3caca27a003293 ; -- Begin function wf_ordered_cost_taken_result$instance$fa3caca27a003293
	.p2align	2
_wf_ordered_cost_taken_result$instance$fa3caca27a003293: ; @"wf_ordered_cost_taken_result$instance$fa3caca27a003293"
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cmp	w8, #1
	b.ne	LBB33_2
; %bb.1:                                ; %bb2
	mov	w9, #131                        ; =0x83
	mov	x8, #1                          ; =0x1
	ldp	x10, x11, [x1]
	madd	x8, x10, x9, x8
	ldp	x12, x10, [x0, #8]
	madd	x9, x12, x9, x10
	add	x10, x11, x9
	eor	x9, x9, x9, lsr #30
	mov	x11, #58809                     ; =0xe5b9
	movk	x11, #7396, lsl #16
	movk	x11, #18285, lsl #32
	movk	x11, #48984, lsl #48
	mul	x9, x9, x11
	eor	x9, x9, x9, lsr #27
	mov	x11, #4587                      ; =0x11eb
	movk	x11, #4913, lsl #16
	movk	x11, #18875, lsl #32
	movk	x11, #38096, lsl #48
	mul	x9, x9, x11
	ldp	x11, x12, [x1, #16]
	eor	x11, x11, x9, lsr #31
	eor	x9, x11, x9
	stp	x10, x9, [x1, #8]
	add	x9, x12, #1
	str	x9, [x1, #24]
	b	LBB33_3
LBB33_2:                                ; %bb3
	ldr	x8, [x1]
	mov	w9, #131                        ; =0x83
	mul	x8, x8, x9
LBB33_3:                                ; %bb1
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_range$instance$3d3b1c83ce351b3d ; -- Begin function wf_std.collections.ordered_map.ordered_map_range$instance$3d3b1c83ce351b3d
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_range$instance$3d3b1c83ce351b3d: ; @"wf_std.collections.ordered_map.ordered_map_range$instance$3d3b1c83ce351b3d"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x2]
	cmp	x8, x9
	b.hs	LBB34_3
; %bb.1:                                ; %bb2
	ldr	x8, [x0]
	cbz	x8, LBB34_3
; %bb.2:                                ; %bb2.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #8]
	bl	_wf_std.collections.ordered_map.ordered_map_range_node$instance$171ecc1fc526bab5
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB34_3:                                ; %bb1
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_each$instance$341ef9419761ecf9 ; -- Begin function wf_std.collections.ordered_map.ordered_map_each$instance$341ef9419761ecf9
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_each$instance$341ef9419761ecf9: ; @"wf_std.collections.ordered_map.ordered_map_each$instance$341ef9419761ecf9"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	bl	_wf_std.collections.ordered_map.ordered_map_each_link$instance$5fa8e8b3d971a72b
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_free$instance$5b3375fb2964755f ; -- Begin function wf_std.collections.ordered_map.ordered_map_free$instance$5b3375fb2964755f
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_free$instance$5b3375fb2964755f: ; @"wf_std.collections.ordered_map.ordered_map_free$instance$5b3375fb2964755f"
; %bb.0:                                ; %entry
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	ldr	q0, [x0]
	str	q0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB36_2
; %bb.1:                                ; %bb2.i
	sub	x8, x8, #1
	mov	x9, sp
	add	x9, x9, x8, lsl #3
	str	x8, [sp]
	ldr	x0, [x9, #8]
	bl	_wf_std.collections.ordered_map.ordered_map_free_node$instance$a14f6fad6bd909bd
LBB36_2:                                ; %"wf_std.collections.ordered_map.ordered_map_free_link$instance$a14f6fad6bd909bd.exit"
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_new$instance$a36c254d11d20619 ; -- Begin function wf_std.collections.ordered_map.ordered_map_new$instance$a36c254d11d20619
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_new$instance$a36c254d11d20619: ; @"wf_std.collections.ordered_map.ordered_map_new$instance$a36c254d11d20619"
; %bb.0:                                ; %entry
	mov	x0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_put$instance$912c4c551bcb3786 ; -- Begin function wf_std.collections.ordered_map.ordered_map_put$instance$912c4c551bcb3786
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_put$instance$912c4c551bcb3786: ; @"wf_std.collections.ordered_map.ordered_map_put$instance$912c4c551bcb3786"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #832
	.cfi_def_cfa_offset 928
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	str	x4, [sp, #32]                   ; 8-byte Folded Spill
	mov	x20, x1
	mov	x19, x0
	ldp	x15, x14, [x3]
	ldp	x13, x12, [x3, #16]
	ldp	x11, x10, [x3, #32]
	ldp	x4, x9, [x3, #48]
	ldp	x8, x30, [x3, #64]
	ldp	x28, x27, [x3, #80]
	ldp	x26, x25, [x3, #96]
	ldp	x24, x23, [x3, #112]
	ldp	x17, x7, [x3, #128]
	ldr	x16, [x3, #144]
	str	x16, [sp, #48]                  ; 8-byte Folded Spill
	ldr	x16, [x3, #152]
	str	x16, [sp, #64]                  ; 8-byte Folded Spill
	ldr	x16, [x3, #160]
	str	x16, [sp, #80]                  ; 8-byte Folded Spill
	ldr	x16, [x3, #168]
	str	x16, [sp, #96]                  ; 8-byte Folded Spill
	ldr	x16, [x3, #176]
	str	x16, [sp, #112]                 ; 8-byte Folded Spill
	ldr	x16, [x3, #184]
	str	x16, [sp, #128]                 ; 8-byte Folded Spill
	ldr	x16, [x3, #192]
	str	x16, [sp, #144]                 ; 8-byte Folded Spill
	ldr	x16, [x3, #200]
	str	x16, [sp, #160]                 ; 8-byte Folded Spill
	ldr	x16, [x3, #208]
	str	x16, [sp, #176]                 ; 8-byte Folded Spill
	ldr	x16, [x3, #216]
	str	x16, [sp, #192]                 ; 8-byte Folded Spill
	ldr	x16, [x3, #224]
	str	x16, [sp, #208]                 ; 8-byte Folded Spill
	ldr	x16, [x3, #232]
	str	x16, [sp, #224]                 ; 8-byte Folded Spill
	ldr	x16, [x3, #240]
	str	x16, [sp, #240]                 ; 8-byte Folded Spill
	ldr	x16, [x3, #248]
	str	x16, [sp, #256]                 ; 8-byte Folded Spill
	ldr	x22, [x1]
	cbz	x22, LBB38_14
; %bb.1:                                ; %bb2
	add	x16, x20, #8
	mov	w3, #280                        ; =0x118
	b	LBB38_4
LBB38_2:                                ; %bb2.i
                                        ;   in Loop: Header=BB38_4 Depth=1
	cbz	x1, LBB38_12
LBB38_3:                                ; %bb10.i
                                        ;   in Loop: Header=BB38_4 Depth=1
	madd	x16, x1, x3, x21
	ldur	x0, [x16, #-8]
	cbz	x0, LBB38_14
LBB38_4:                                ; %bb1.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB38_6 Depth 2
	ldr	x0, [x16]
	mov	x21, x0
	ldr	x16, [x21, #16]!
	cbz	x16, LBB38_9
; %bb.5:                                ; %bb2.lr.ph.i.i.i.i
                                        ;   in Loop: Header=BB38_4 Depth=1
	mov	x1, #0                          ; =0x0
	add	x5, x0, #24
LBB38_6:                                ; %bb2.i.i.i.i
                                        ;   Parent Loop BB38_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x6, [x5]
	cmp	x2, x6
	b.ls	LBB38_10
; %bb.7:                                ; %bb8.i.i.i.i
                                        ;   in Loop: Header=BB38_6 Depth=2
	add	x5, x5, #280
	add	x1, x1, #1
	cmp	x16, x1
	b.ne	LBB38_6
; %bb.8:                                ;   in Loop: Header=BB38_4 Depth=1
	mov	x1, x16
	b	LBB38_3
LBB38_9:                                ;   in Loop: Header=BB38_4 Depth=1
	mov	x1, #0                          ; =0x0
LBB38_10:                               ; %"wf_std.collections.ordered_map.ordered_map_search$instance$43c0c30766ba2e8b.exit.i"
                                        ;   in Loop: Header=BB38_4 Depth=1
	cmp	x1, x16
	b.hs	LBB38_2
; %bb.11:                               ; %bb3.i
                                        ;   in Loop: Header=BB38_4 Depth=1
	madd	x16, x1, x3, x21
	ldr	x5, [x16, #8]
	cmp	x2, x5
	b.ne	LBB38_2
	b	LBB38_19
LBB38_12:                               ; %bb9.i
                                        ;   in Loop: Header=BB38_4 Depth=1
	ldr	x16, [x0]
	cbz	x16, LBB38_14
; %bb.13:                               ; %bb12.i
                                        ;   in Loop: Header=BB38_4 Depth=1
	add	x16, x0, #8
	b	LBB38_4
LBB38_14:                               ; %bb1
	ldr	x21, [x20, #16]
	lsr	x16, x21, #13
	cbz	x16, LBB38_16
; %bb.15:                               ; %bb8
	stp	x15, x14, [x19, #16]
	stp	x13, x12, [x19, #32]
	stp	xzr, x2, [x19]
	mov	w12, #1                         ; =0x1
	str	w12, [x19]
	strb	w12, [x19, #4]
	stp	x11, x10, [x19, #48]
	stp	x4, x9, [x19, #64]
	stp	x8, x30, [x19, #80]
	stp	x28, x27, [x19, #96]
	stp	x26, x25, [x19, #112]
	stp	x24, x23, [x19, #128]
	stp	x17, x7, [x19, #144]
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	stp	x9, x8, [x19, #160]
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #96]                   ; 8-byte Folded Reload
	stp	x9, x8, [x19, #176]
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	stp	x9, x8, [x19, #192]
	ldr	x9, [sp, #144]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	stp	x9, x8, [x19, #208]
	ldr	x9, [sp, #176]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #192]                  ; 8-byte Folded Reload
	stp	x9, x8, [x19, #224]
	ldr	x9, [sp, #208]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #224]                  ; 8-byte Folded Reload
	stp	x9, x8, [x19, #240]
	ldr	x9, [sp, #240]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #256]                  ; 8-byte Folded Reload
	stp	x9, x8, [x19, #256]
	b	LBB38_24
LBB38_16:                               ; %bb9
	str	x2, [sp, #568]
	str	x15, [sp, #576]
	str	x14, [sp, #584]
	str	x13, [sp, #592]
	str	x12, [sp, #600]
	str	x11, [sp, #608]
	str	x10, [sp, #616]
	str	x4, [sp, #624]
	str	x9, [sp, #632]
	str	x8, [sp, #640]
	str	x30, [sp, #648]
	str	x28, [sp, #656]
	str	x27, [sp, #664]
	str	x26, [sp, #672]
	str	x25, [sp, #680]
	str	x24, [sp, #688]
	str	x23, [sp, #696]
	str	x17, [sp, #704]
	str	x7, [sp, #712]
	ldr	x8, [sp, #48]                   ; 8-byte Folded Reload
	str	x8, [sp, #720]
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	x8, [sp, #728]
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	str	x8, [sp, #736]
	ldr	x8, [sp, #96]                   ; 8-byte Folded Reload
	str	x8, [sp, #744]
	ldr	x8, [sp, #112]                  ; 8-byte Folded Reload
	str	x8, [sp, #752]
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	str	x8, [sp, #760]
	ldr	x8, [sp, #144]                  ; 8-byte Folded Reload
	str	x8, [sp, #768]
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	str	x8, [sp, #776]
	ldr	x8, [sp, #176]                  ; 8-byte Folded Reload
	str	x8, [sp, #784]
	ldr	x8, [sp, #192]                  ; 8-byte Folded Reload
	str	x8, [sp, #792]
	ldr	x8, [sp, #208]                  ; 8-byte Folded Reload
	str	x8, [sp, #800]
	ldr	x8, [sp, #224]                  ; 8-byte Folded Reload
	str	x8, [sp, #808]
	ldr	x8, [sp, #240]                  ; 8-byte Folded Reload
	str	x8, [sp, #816]
	ldr	x8, [sp, #256]                  ; 8-byte Folded Reload
	str	x8, [sp, #824]
	add	x0, sp, #280
	add	x2, sp, #568
	mov	x1, x20
	ldr	x3, [sp, #32]                   ; 8-byte Folded Reload
	bl	_wf_std.collections.ordered_map.ordered_map_insert_link$instance$43c0c30766ba2e8b
	ldr	w8, [sp, #280]
	cbz	w8, LBB38_23
; %bb.17:                               ; %bb12
	add	x8, sp, #280
	add	x9, sp, #49
	ldur	q1, [x9, #255]
	add	x9, sp, #33
	ldur	q2, [x9, #255]
	add	x9, sp, #81
	ldur	q0, [x9, #255]
	stp	q0, q1, [sp, #224]              ; 32-byte Folded Spill
	add	x9, sp, #65
	ldur	q0, [x9, #255]
	stp	q0, q2, [sp, #96]               ; 32-byte Folded Spill
	add	x9, sp, #113
	ldur	q1, [x9, #255]
	add	x9, sp, #97
	ldur	q2, [x9, #255]
	ldur	q0, [x8, #120]
	stp	q0, q1, [sp, #192]              ; 32-byte Folded Spill
	add	x9, sp, #129
	ldur	q0, [x9, #255]
	stp	q0, q2, [sp, #64]               ; 32-byte Folded Spill
	ldur	q1, [x8, #152]
	ldur	q2, [x8, #136]
	ldur	q0, [x8, #184]
	stp	q0, q1, [sp, #160]              ; 32-byte Folded Spill
	ldur	q0, [x8, #168]
	stp	q0, q2, [sp, #32]               ; 32-byte Folded Spill
	ldur	q1, [x8, #216]
	ldur	q0, [x8, #200]
	str	q0, [sp, #16]                   ; 16-byte Folded Spill
	ldur	q0, [x8, #248]
	str	q0, [sp, #256]                  ; 16-byte Folded Spill
	ldur	q0, [x8, #232]
	stp	q0, q1, [sp, #128]              ; 32-byte Folded Spill
	ldr	x23, [sp, #544]
	ldr	x24, [sp, #552]
	ldr	x25, [sp, #560]
	str	xzr, [sp, #272]
	cbz	x22, LBB38_20
; %bb.18:                               ; %run.move.body.v3.preheader.i
	lsl	x2, x22, #3
	add	x0, sp, #272
	add	x1, x20, #8
	bl	_memcpy
	ldr	x26, [sp, #272]
	b	LBB38_21
LBB38_19:                               ; %bb5
	ldp	q0, q1, [x16, #16]
	stp	x15, x14, [x16, #16]
	stp	x13, x12, [x16, #32]
	ldp	q2, q3, [x16, #48]
	stp	x11, x10, [x16, #48]
	stp	x4, x9, [x16, #64]
	ldp	q4, q5, [x16, #80]
	stp	x8, x30, [x16, #80]
	stp	x28, x27, [x16, #96]
	ldp	q6, q7, [x16, #112]
	stp	x26, x25, [x16, #112]
	stp	x24, x23, [x16, #128]
	ldp	q16, q17, [x16, #144]
	stp	x17, x7, [x16, #144]
	ldr	x9, [sp, #48]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	stp	x9, x8, [x16, #160]
	ldp	q18, q19, [x16, #176]
	ldr	x9, [sp, #80]                   ; 8-byte Folded Reload
	ldr	x8, [sp, #96]                   ; 8-byte Folded Reload
	stp	x9, x8, [x16, #176]
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	stp	x9, x8, [x16, #192]
	ldp	q20, q21, [x16, #208]
	ldr	x9, [sp, #144]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	stp	x9, x8, [x16, #208]
	ldr	x9, [sp, #176]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #192]                  ; 8-byte Folded Reload
	stp	x9, x8, [x16, #224]
	ldp	q22, q23, [x16, #240]
	ldr	x9, [sp, #208]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #224]                  ; 8-byte Folded Reload
	stp	x9, x8, [x16, #240]
	ldr	x9, [sp, #240]                  ; 8-byte Folded Reload
	ldr	x8, [sp, #256]                  ; 8-byte Folded Reload
	stp	x9, x8, [x16, #256]
	stp	xzr, x2, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	stp	q0, q1, [x19, #16]
	stp	q2, q3, [x19, #48]
	stp	q4, q5, [x19, #80]
	stp	q6, q7, [x19, #112]
	stp	q16, q17, [x19, #144]
	stp	q18, q19, [x19, #176]
	stp	q20, q21, [x19, #208]
	stp	q22, q23, [x19, #240]
	b	LBB38_24
LBB38_20:
	mov	x26, #0                         ; =0x0
LBB38_21:                               ; %"wf_append$instance$42f33d80f30f592c.exit"
	str	xzr, [x20]
	mov	w0, #4224                       ; =0x1080
	bl	_malloc
	cbz	x0, LBB38_25
; %bb.22:                               ; %"wf_box_new$instance$3178c7907270f1e1.exit"
	mov	x21, x0
	stp	x22, x26, [x0]
	mov	w8, #1                          ; =0x1
	str	x8, [x0, #16]
	ldr	q0, [sp, #112]                  ; 16-byte Folded Reload
	stur	q0, [x0, #24]
	ldr	q0, [sp, #240]                  ; 16-byte Folded Reload
	stur	q0, [x0, #40]
	ldr	q0, [sp, #96]                   ; 16-byte Folded Reload
	stur	q0, [x0, #56]
	ldr	q0, [sp, #224]                  ; 16-byte Folded Reload
	stur	q0, [x0, #72]
	ldr	q0, [sp, #80]                   ; 16-byte Folded Reload
	stur	q0, [x0, #88]
	ldr	q0, [sp, #208]                  ; 16-byte Folded Reload
	stur	q0, [x0, #104]
	ldr	q0, [sp, #64]                   ; 16-byte Folded Reload
	stur	q0, [x0, #120]
	ldr	q0, [sp, #192]                  ; 16-byte Folded Reload
	stur	q0, [x0, #136]
	ldr	q0, [sp, #48]                   ; 16-byte Folded Reload
	stur	q0, [x0, #152]
	ldr	q0, [sp, #176]                  ; 16-byte Folded Reload
	stur	q0, [x0, #168]
	ldr	q0, [sp, #32]                   ; 16-byte Folded Reload
	stur	q0, [x0, #184]
	ldr	q0, [sp, #160]                  ; 16-byte Folded Reload
	stur	q0, [x0, #200]
	ldr	q0, [sp, #16]                   ; 16-byte Folded Reload
	stur	q0, [x0, #216]
	ldp	q0, q1, [sp, #128]              ; 32-byte Folded Reload
	stur	q1, [x0, #232]
	mov	x8, x0
	str	q0, [x8, #248]!
	ldr	q0, [sp, #256]                  ; 16-byte Folded Reload
	str	q0, [x8, #16]
	stp	x23, x24, [x0, #280]
	str	x25, [x0, #296]
	add	x0, x0, #304
	mov	w1, #3920                       ; =0xf50
	bl	_bzero
	ldr	x8, [x20]
	add	x9, x20, x8, lsl #3
	str	x21, [x9, #8]
	add	x8, x8, #1
	str	x8, [x20]
	ldr	x21, [x20, #16]
LBB38_23:                               ; %bb10
	add	x8, x21, #1
	str	x8, [x20, #16]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	stp	q0, q0, [x19, #32]
	stp	q0, q0, [x19, #64]
	stp	q0, q0, [x19, #96]
	stp	q0, q0, [x19, #128]
	stp	q0, q0, [x19, #160]
	stp	q0, q0, [x19, #192]
	stp	q0, q0, [x19, #224]
	str	q0, [x19, #256]
LBB38_24:                               ; %common.ret
	add	sp, sp, #832
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB38_25:                               ; %box.new.oom.v1.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_ordered_cost_put_result$instance$ff5e39efec5d08ee ; -- Begin function wf_ordered_cost_put_result$instance$ff5e39efec5d08ee
	.p2align	2
_wf_ordered_cost_put_result$instance$ff5e39efec5d08ee: ; @"wf_ordered_cost_put_result$instance$ff5e39efec5d08ee"
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cbz	w8, LBB39_2
; %bb.1:                                ; %bb3
	sub	sp, sp, #288
	stp	x28, x27, [sp, #256]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #272]            ; 16-byte Folded Spill
	ldr	x8, [x0, #8]
	ldrb	w9, [x0, #4]
	ldr	x10, [x1]
	mov	w11, #131                       ; =0x83
	tst	w9, #0x1
	mov	w9, #1                          ; =0x1
	cinc	x9, x9, ne
	madd	x9, x10, x11, x9
	str	x9, [x1]
	ldp	q0, q1, [x0, #208]
	stp	q0, q1, [sp, #192]
	ldp	q0, q1, [x0, #240]
	stp	q0, q1, [sp, #224]
	ldp	q0, q1, [x0, #144]
	stp	q0, q1, [sp, #128]
	ldp	q0, q1, [x0, #176]
	stp	q0, q1, [sp, #160]
	ldp	q0, q1, [x0, #80]
	stp	q0, q1, [sp, #64]
	ldp	q0, q1, [x0, #112]
	stp	q0, q1, [sp, #96]
	ldp	q0, q1, [x0, #16]
	stp	q0, q1, [sp]
	ldp	q0, q1, [x0, #48]
	stp	q0, q1, [sp, #32]
	mov	x2, sp
	mov	x0, x1
	mov	x1, x8
	bl	_wf_ordered_cost_record_consume
	ldp	x29, x30, [sp, #272]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #256]            ; 16-byte Folded Reload
	add	sp, sp, #288
	mov	w0, #0                          ; =0x0
	ret
LBB39_2:                                ; %bb2
	ldr	x8, [x1]
	mov	w9, #131                        ; =0x83
	mul	x8, x8, x9
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_len$instance$a36c254d11d20619 ; -- Begin function wf_std.collections.ordered_map.ordered_map_len$instance$a36c254d11d20619
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_len$instance$a36c254d11d20619: ; @"wf_std.collections.ordered_map.ordered_map_len$instance$a36c254d11d20619"
; %bb.0:                                ; %entry
	ldr	x0, [x0, #16]
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_lookup$instance$27c9a7455d5e3844 ; -- Begin function wf_std.collections.ordered_map.ordered_map_lookup$instance$27c9a7455d5e3844
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_lookup$instance$27c9a7455d5e3844: ; @"wf_std.collections.ordered_map.ordered_map_lookup$instance$27c9a7455d5e3844"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB41_2
; %bb.1:                                ; %bb2.i.i.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #8]
	bl	_wf_std.collections.ordered_map.ordered_map_lookup_node$instance$768bf1dd9f398f38
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB41_2:
	mov	w2, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_edit$instance$374d92b1aa276be7 ; -- Begin function wf_std.collections.ordered_map.ordered_map_edit$instance$374d92b1aa276be7
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_edit$instance$374d92b1aa276be7: ; @"wf_std.collections.ordered_map.ordered_map_edit$instance$374d92b1aa276be7"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB42_2
; %bb.1:                                ; %bb2.i.i.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #8]
	bl	_wf_std.collections.ordered_map.ordered_map_edit_node$instance$887d1b484f24fc68
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB42_2:
	mov	w2, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_remove$instance$912c4c551bcb3786 ; -- Begin function wf_std.collections.ordered_map.ordered_map_remove$instance$912c4c551bcb3786
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_remove$instance$912c4c551bcb3786: ; @"wf_std.collections.ordered_map.ordered_map_remove$instance$912c4c551bcb3786"
; %bb.0:                                ; %entry
	sub	sp, sp, #368
	stp	x26, x25, [sp, #288]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #304]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #320]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #336]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #352]            ; 16-byte Folded Spill
	mov	x19, x0
	ldr	x22, [x1]
	cbz	x22, LBB43_9
; %bb.1:                                ; %"wf_std.collections.ordered_map.ordered_map_remove_link$instance$43c0c30766ba2e8b.exit"
	mov	x20, x1
	ldr	x1, [x1, #8]
	add	x21, sp, #8
	add	x0, sp, #8
	bl	_wf_std.collections.ordered_map.ordered_map_remove_node$instance$43c0c30766ba2e8b
	ldr	w8, [sp, #8]
	cbz	w8, LBB43_9
; %bb.2:                                ; %bb2.i3
	sub	x23, x22, #1
	add	x24, x20, x23, lsl #3
	str	x23, [x20]
	ldr	x0, [x24, #8]
	ldr	x8, [x0, #16]
	cbnz	x8, LBB43_6
; %bb.3:                                ; %bb5.i
	ldp	x22, x25, [x0]
	bl	_free
	str	x25, [sp, #280]
	cbz	x22, LBB43_5
; %bb.4:                                ; %run.move.body.v3.preheader.i.i
	lsl	x2, x22, #3
	add	x0, x24, #8
	add	x1, sp, #280
	bl	_memcpy
LBB43_5:                                ; %"wf_append$instance$42f33d80f30f592c.exit.i"
	add	x22, x22, x23
LBB43_6:                                ; %"wf_std.collections.ordered_map.ordered_map_contract_root$instance$d883f474bea0047c.exit"
	str	x22, [x20]
	ldr	x8, [x20, #16]
	cbz	x8, LBB43_8
; %bb.7:                                ; %bb4
	sub	x8, x8, #1
	str	x8, [x20, #16]
LBB43_8:                                ; %bb3
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19], #8
	add	x1, x21, #8
	mov	x0, x19
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	b	LBB43_10
LBB43_9:                                ; %bb1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #240]
	stp	q0, q0, [x19, #208]
	stp	q0, q0, [x19, #176]
	stp	q0, q0, [x19, #144]
	stp	q0, q0, [x19, #112]
	stp	q0, q0, [x19, #80]
	stp	q0, q0, [x19, #48]
	stp	q0, q0, [x19, #16]
	str	q0, [x19]
LBB43_10:                               ; %bb3
	ldp	x29, x30, [sp, #352]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #336]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #320]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #304]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #288]            ; 16-byte Folded Reload
	add	sp, sp, #368
	ret
                                        ; -- End function
	.globl	_wf_ordered_cost_taken_result$instance$ff5e39efec5d08ee ; -- Begin function wf_ordered_cost_taken_result$instance$ff5e39efec5d08ee
	.p2align	2
_wf_ordered_cost_taken_result$instance$ff5e39efec5d08ee: ; @"wf_ordered_cost_taken_result$instance$ff5e39efec5d08ee"
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cmp	w8, #1
	b.ne	LBB44_2
; %bb.1:                                ; %bb2
	sub	sp, sp, #288
	stp	x28, x27, [sp, #256]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #272]            ; 16-byte Folded Spill
	ldr	x8, [x0, #8]
	ldp	q0, q1, [x0, #208]
	stp	q0, q1, [sp, #192]
	ldp	q0, q1, [x0, #240]
	stp	q0, q1, [sp, #224]
	ldp	q0, q1, [x0, #144]
	stp	q0, q1, [sp, #128]
	ldp	q0, q1, [x0, #176]
	stp	q0, q1, [sp, #160]
	ldp	q0, q1, [x0, #80]
	stp	q0, q1, [sp, #64]
	ldp	q0, q1, [x0, #112]
	stp	q0, q1, [sp, #96]
	ldp	q0, q1, [x0, #16]
	stp	q0, q1, [sp]
	ldp	q0, q1, [x0, #48]
	mov	w9, #131                        ; =0x83
	mov	x10, #1                         ; =0x1
	stp	q0, q1, [sp, #32]
	ldr	x11, [x1]
	madd	x9, x11, x9, x10
	str	x9, [x1]
	mov	x2, sp
	mov	x0, x1
	mov	x1, x8
	bl	_wf_ordered_cost_record_consume
	ldp	x29, x30, [sp, #272]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #256]            ; 16-byte Folded Reload
	add	sp, sp, #288
	mov	w0, #0                          ; =0x0
	ret
LBB44_2:                                ; %bb3
	ldr	x8, [x1]
	mov	w9, #131                        ; =0x83
	mul	x8, x8, x9
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_range$instance$e886f4eb776d75c0 ; -- Begin function wf_std.collections.ordered_map.ordered_map_range$instance$e886f4eb776d75c0
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_range$instance$e886f4eb776d75c0: ; @"wf_std.collections.ordered_map.ordered_map_range$instance$e886f4eb776d75c0"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x2]
	cmp	x8, x9
	b.hs	LBB45_3
; %bb.1:                                ; %bb2
	ldr	x8, [x0]
	cbz	x8, LBB45_3
; %bb.2:                                ; %bb2.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #8]
	bl	_wf_std.collections.ordered_map.ordered_map_range_node$instance$475e4daed49f96af
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB45_3:                                ; %bb1
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_each$instance$960d100d77757702 ; -- Begin function wf_std.collections.ordered_map.ordered_map_each$instance$960d100d77757702
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_each$instance$960d100d77757702: ; @"wf_std.collections.ordered_map.ordered_map_each$instance$960d100d77757702"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	bl	_wf_std.collections.ordered_map.ordered_map_each_link$instance$5703a7a9bf1884ed
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_free$instance$56a8ddd8129b5d48 ; -- Begin function wf_std.collections.ordered_map.ordered_map_free$instance$56a8ddd8129b5d48
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_free$instance$56a8ddd8129b5d48: ; @"wf_std.collections.ordered_map.ordered_map_free$instance$56a8ddd8129b5d48"
; %bb.0:                                ; %entry
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	ldr	q0, [x0]
	str	q0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB47_2
; %bb.1:                                ; %bb2.i
	sub	x8, x8, #1
	mov	x9, sp
	add	x9, x9, x8, lsl #3
	str	x8, [sp]
	ldr	x0, [x9, #8]
	bl	_wf_std.collections.ordered_map.ordered_map_free_node$instance$40650b236ee646e0
LBB47_2:                                ; %"wf_std.collections.ordered_map.ordered_map_free_link$instance$40650b236ee646e0.exit"
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.globl	_wf_slots_new$instance$b6f7fa3c54e90571 ; -- Begin function wf_slots_new$instance$b6f7fa3c54e90571
	.p2align	2
_wf_slots_new$instance$b6f7fa3c54e90571: ; @"wf_slots_new$instance$b6f7fa3c54e90571"
; %bb.0:                                ; %entry
	mov	x0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_replace_node$instance$5046b787ff5cdb3f ; -- Begin function wf_std.collections.ordered_map.ordered_map_replace_node$instance$5046b787ff5cdb3f
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_replace_node$instance$5046b787ff5cdb3f: ; @"wf_std.collections.ordered_map.ordered_map_replace_node$instance$5046b787ff5cdb3f"
; %bb.0:                                ; %entry
	sub	sp, sp, #16
	b	LBB49_4
LBB49_1:                                ; %bb2
                                        ;   in Loop: Header=BB49_4 Depth=1
	cbz	x9, LBB49_12
LBB49_2:                                ; %bb10
                                        ;   in Loop: Header=BB49_4 Depth=1
	add	x8, x8, x9, lsl #5
	ldur	x9, [x8, #-8]
	cbz	x9, LBB49_14
LBB49_3:                                ; %bb1.backedge
                                        ;   in Loop: Header=BB49_4 Depth=1
	ldr	x0, [x8]
LBB49_4:                                ; %bb1
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB49_6 Depth 2
	mov	x8, x0
	ldr	x10, [x8, #16]!
	cbz	x10, LBB49_9
; %bb.5:                                ; %bb2.lr.ph.i.i.i
                                        ;   in Loop: Header=BB49_4 Depth=1
	mov	x9, #0                          ; =0x0
	add	x11, x0, #24
	ldr	x12, [x1]
LBB49_6:                                ; %bb2.i.i.i
                                        ;   Parent Loop BB49_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x13, [x11], #32
	cmp	x12, x13
	b.ls	LBB49_10
; %bb.7:                                ; %bb8.i.i.i
                                        ;   in Loop: Header=BB49_6 Depth=2
	add	x9, x9, #1
	cmp	x10, x9
	b.ne	LBB49_6
; %bb.8:                                ;   in Loop: Header=BB49_4 Depth=1
	mov	x9, x10
	b	LBB49_2
LBB49_9:                                ;   in Loop: Header=BB49_4 Depth=1
	mov	x9, #0                          ; =0x0
LBB49_10:                               ; %"wf_std.collections.ordered_map.ordered_map_search$instance$5046b787ff5cdb3f.exit"
                                        ;   in Loop: Header=BB49_4 Depth=1
	cmp	x9, x10
	b.hs	LBB49_1
; %bb.11:                               ; %bb3
                                        ;   in Loop: Header=BB49_4 Depth=1
	add	x10, x8, x9, lsl #5
	ldr	x11, [x1]
	ldr	x12, [x10, #8]
	cmp	x11, x12
	b.ne	LBB49_1
	b	LBB49_15
LBB49_12:                               ; %bb9
                                        ;   in Loop: Header=BB49_4 Depth=1
	ldr	x8, [x0]
	cbz	x8, LBB49_14
; %bb.13:                               ; %bb12
                                        ;   in Loop: Header=BB49_4 Depth=1
	add	x8, x0, #8
	b	LBB49_3
LBB49_14:
	mov	w0, #0                          ; =0x0
	add	sp, sp, #16
	ret
LBB49_15:                               ; %bb6
	ldur	q0, [x10, #8]
	ldr	q1, [x1]
	stur	q1, [x10, #8]
	str	q0, [x1]
	mov	w0, #1                          ; =0x1
	add	sp, sp, #16
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_insert_link$instance$5046b787ff5cdb3f ; -- Begin function wf_std.collections.ordered_map.ordered_map_insert_link$instance$5046b787ff5cdb3f
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_insert_link$instance$5046b787ff5cdb3f: ; @"wf_std.collections.ordered_map.ordered_map_insert_link$instance$5046b787ff5cdb3f"
	.cfi_startproc
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	cbz	x8, LBB50_2
; %bb.1:                                ; %bb2
	ldr	x1, [x1, #8]
	b	_wf_std.collections.ordered_map.ordered_map_insert_node$instance$5046b787ff5cdb3f
LBB50_2:                                ; %bb3
	ldr	q0, [x2]
	str	xzr, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	stur	q0, [x0, #8]
	stp	xzr, xzr, [x0, #24]
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_slots_new$instance$5069c23bc45853ea ; -- Begin function wf_slots_new$instance$5069c23bc45853ea
	.p2align	2
_wf_slots_new$instance$5069c23bc45853ea: ; @"wf_slots_new$instance$5069c23bc45853ea"
; %bb.0:                                ; %entry
	str	xzr, [x0, #480]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0, #448]
	stp	q0, q0, [x0, #416]
	stp	q0, q0, [x0, #384]
	stp	q0, q0, [x0, #352]
	stp	q0, q0, [x0, #320]
	stp	q0, q0, [x0, #288]
	stp	q0, q0, [x0, #256]
	stp	q0, q0, [x0, #224]
	stp	q0, q0, [x0, #192]
	stp	q0, q0, [x0, #160]
	stp	q0, q0, [x0, #128]
	stp	q0, q0, [x0, #96]
	stp	q0, q0, [x0, #64]
	stp	q0, q0, [x0, #32]
	stp	q0, q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_box_new$instance$dc0681021cdc805e ; -- Begin function wf_box_new$instance$dc0681021cdc805e
	.p2align	2
_wf_box_new$instance$dc0681021cdc805e:  ; @"wf_box_new$instance$dc0681021cdc805e"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w0, #504                        ; =0x1f8
	bl	_malloc
	cbz	x0, LBB52_2
; %bb.1:                                ; %box.new.ready.v1
	mov	x1, x19
	mov	w2, #504                        ; =0x1f8
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_memcpy
LBB52_2:                                ; %box.new.oom.v1
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_lookup_link$instance$11eb30e8dabe0f7e ; -- Begin function wf_std.collections.ordered_map.ordered_map_lookup_link$instance$11eb30e8dabe0f7e
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_lookup_link$instance$11eb30e8dabe0f7e: ; @"wf_std.collections.ordered_map.ordered_map_lookup_link$instance$11eb30e8dabe0f7e"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB53_2
; %bb.1:                                ; %bb2.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #8]
	bl	_wf_std.collections.ordered_map.ordered_map_lookup_node$instance$11eb30e8dabe0f7e
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB53_2:
	mov	w2, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_edit_link$instance$41f33845185638b6 ; -- Begin function wf_std.collections.ordered_map.ordered_map_edit_link$instance$41f33845185638b6
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_edit_link$instance$41f33845185638b6: ; @"wf_std.collections.ordered_map.ordered_map_edit_link$instance$41f33845185638b6"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB54_2
; %bb.1:                                ; %bb2.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #8]
	bl	_wf_std.collections.ordered_map.ordered_map_edit_node$instance$41f33845185638b6
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB54_2:
	mov	w2, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_remove_link$instance$5046b787ff5cdb3f ; -- Begin function wf_std.collections.ordered_map.ordered_map_remove_link$instance$5046b787ff5cdb3f
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_remove_link$instance$5046b787ff5cdb3f: ; @"wf_std.collections.ordered_map.ordered_map_remove_link$instance$5046b787ff5cdb3f"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB55_2
; %bb.1:                                ; %bb2.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #8]
	bl	_wf_std.collections.ordered_map.ordered_map_remove_node$instance$5046b787ff5cdb3f
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB55_2:
	mov	x2, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_contract_root$instance$0ed342445dd803f3 ; -- Begin function wf_std.collections.ordered_map.ordered_map_contract_root$instance$0ed342445dd803f3
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_contract_root$instance$0ed342445dd803f3: ; @"wf_std.collections.ordered_map.ordered_map_contract_root$instance$0ed342445dd803f3"
; %bb.0:                                ; %entry
	ldr	x9, [x0]
	cbz	x9, LBB56_6
; %bb.1:                                ; %bb2
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	sub	x19, x9, #1
	add	x21, x0, x19, lsl #3
	str	x19, [x0]
	ldr	x8, [x21, #8]
	ldr	x10, [x8, #16]
	cbnz	x10, LBB56_5
; %bb.2:                                ; %bb5
	mov	x20, x0
	ldp	x22, x23, [x8]
	mov	x0, x8
	bl	_free
	str	x23, [sp, #8]
	cbz	x22, LBB56_4
; %bb.3:                                ; %run.move.body.v3.preheader.i
	lsl	x2, x22, #3
	add	x0, x21, #8
	add	x1, sp, #8
	bl	_memcpy
LBB56_4:                                ; %"wf_append$instance$48c61fa9751a6936.exit"
	add	x9, x22, x19
	mov	x0, x20
LBB56_5:                                ; %bb1.sink.split
	str	x9, [x0]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
LBB56_6:                                ; %bb1
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_range_link$instance$171ecc1fc526bab5 ; -- Begin function wf_std.collections.ordered_map.ordered_map_range_link$instance$171ecc1fc526bab5
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_range_link$instance$171ecc1fc526bab5: ; @"wf_std.collections.ordered_map.ordered_map_range_link$instance$171ecc1fc526bab5"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB57_2
; %bb.1:                                ; %bb2
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #8]
	bl	_wf_std.collections.ordered_map.ordered_map_range_node$instance$171ecc1fc526bab5
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB57_2:                                ; %bb1
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_each_link$instance$5fa8e8b3d971a72b ; -- Begin function wf_std.collections.ordered_map.ordered_map_each_link$instance$5fa8e8b3d971a72b
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_each_link$instance$5fa8e8b3d971a72b: ; @"wf_std.collections.ordered_map.ordered_map_each_link$instance$5fa8e8b3d971a72b"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB58_5
; %bb.1:                                ; %bb2
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	mov	x19, x1
	ldr	x20, [x0, #8]
	mov	x0, x20
	bl	_wf_std.collections.ordered_map.ordered_map_each_link$instance$5fa8e8b3d971a72b
	ldr	x21, [x20, #16]
	cbz	x21, LBB58_4
; %bb.2:                                ; %bb2.i.preheader
	mov	x22, #0                         ; =0x0
	add	x20, x20, #40
	mov	w23, #131                       ; =0x83
LBB58_3:                                ; %bb2.i
                                        ; =>This Inner Loop Header: Depth=1
	ldp	x8, x9, [x20, #-16]
	ldr	x10, [x19]
	add	x8, x10, x8
	madd	x8, x8, x23, x9
	str	x8, [x19]
	mov	x0, x20
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_each_link$instance$5fa8e8b3d971a72b
	add	x22, x22, #1
	add	x20, x20, #32
	cmp	x21, x22
	b.ne	LBB58_3
LBB58_4:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
LBB58_5:                                ; %bb1
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_free_link$instance$a14f6fad6bd909bd ; -- Begin function wf_std.collections.ordered_map.ordered_map_free_link$instance$a14f6fad6bd909bd
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_free_link$instance$a14f6fad6bd909bd: ; @"wf_std.collections.ordered_map.ordered_map_free_link$instance$a14f6fad6bd909bd"
; %bb.0:                                ; %entry
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	ldr	q0, [x0]
	str	q0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB59_2
; %bb.1:                                ; %bb2
	sub	x8, x8, #1
	mov	x9, sp
	add	x9, x9, x8, lsl #3
	str	x8, [sp]
	ldr	x0, [x9, #8]
	bl	_wf_std.collections.ordered_map.ordered_map_free_node$instance$a14f6fad6bd909bd
LBB59_2:                                ; %bb1
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.globl	_wf_slots_new$instance$1088237bf33084ad ; -- Begin function wf_slots_new$instance$1088237bf33084ad
	.p2align	2
_wf_slots_new$instance$1088237bf33084ad: ; @"wf_slots_new$instance$1088237bf33084ad"
; %bb.0:                                ; %entry
	mov	x0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_replace_node$instance$43c0c30766ba2e8b ; -- Begin function wf_std.collections.ordered_map.ordered_map_replace_node$instance$43c0c30766ba2e8b
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_replace_node$instance$43c0c30766ba2e8b: ; @"wf_std.collections.ordered_map.ordered_map_replace_node$instance$43c0c30766ba2e8b"
; %bb.0:                                ; %entry
	sub	sp, sp, #320
	stp	x28, x27, [sp, #272]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #288]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #304]            ; 16-byte Folded Spill
	mov	w8, #280                        ; =0x118
	b	LBB61_4
LBB61_1:                                ; %bb2
                                        ;   in Loop: Header=BB61_4 Depth=1
	cbz	x10, LBB61_12
LBB61_2:                                ; %bb10
                                        ;   in Loop: Header=BB61_4 Depth=1
	madd	x9, x10, x8, x9
	ldur	x10, [x9, #-8]
	cbz	x10, LBB61_14
LBB61_3:                                ; %bb1.backedge
                                        ;   in Loop: Header=BB61_4 Depth=1
	ldr	x0, [x9]
LBB61_4:                                ; %bb1
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB61_6 Depth 2
	mov	x9, x0
	ldr	x11, [x9, #16]!
	cbz	x11, LBB61_9
; %bb.5:                                ; %bb2.lr.ph.i.i.i
                                        ;   in Loop: Header=BB61_4 Depth=1
	mov	x10, #0                         ; =0x0
	add	x12, x0, #24
	ldr	x13, [x1]
LBB61_6:                                ; %bb2.i.i.i
                                        ;   Parent Loop BB61_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x14, [x12]
	cmp	x13, x14
	b.ls	LBB61_10
; %bb.7:                                ; %bb8.i.i.i
                                        ;   in Loop: Header=BB61_6 Depth=2
	add	x12, x12, #280
	add	x10, x10, #1
	cmp	x11, x10
	b.ne	LBB61_6
; %bb.8:                                ;   in Loop: Header=BB61_4 Depth=1
	mov	x10, x11
	b	LBB61_2
LBB61_9:                                ;   in Loop: Header=BB61_4 Depth=1
	mov	x10, #0                         ; =0x0
LBB61_10:                               ; %"wf_std.collections.ordered_map.ordered_map_search$instance$43c0c30766ba2e8b.exit"
                                        ;   in Loop: Header=BB61_4 Depth=1
	cmp	x10, x11
	b.hs	LBB61_1
; %bb.11:                               ; %bb3
                                        ;   in Loop: Header=BB61_4 Depth=1
	madd	x20, x10, x8, x9
	ldr	x11, [x1]
	ldr	x12, [x20, #8]
	cmp	x11, x12
	b.ne	LBB61_1
	b	LBB61_15
LBB61_12:                               ; %bb9
                                        ;   in Loop: Header=BB61_4 Depth=1
	ldr	x9, [x0]
	cbz	x9, LBB61_14
; %bb.13:                               ; %bb12
                                        ;   in Loop: Header=BB61_4 Depth=1
	add	x9, x0, #8
	b	LBB61_3
LBB61_14:
	mov	w0, #0                          ; =0x0
	b	LBB61_16
LBB61_15:                               ; %bb6
	add	x0, sp, #8
	mov	x19, x1
	add	x1, x20, #8
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	x0, x20, #8
	mov	x1, x19
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	x1, sp, #8
	mov	x0, x19
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	mov	w0, #1                          ; =0x1
LBB61_16:                               ; %common.ret
	ldp	x29, x30, [sp, #304]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #288]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #272]            ; 16-byte Folded Reload
	add	sp, sp, #320
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_insert_link$instance$43c0c30766ba2e8b ; -- Begin function wf_std.collections.ordered_map.ordered_map_insert_link$instance$43c0c30766ba2e8b
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_insert_link$instance$43c0c30766ba2e8b: ; @"wf_std.collections.ordered_map.ordered_map_insert_link$instance$43c0c30766ba2e8b"
	.cfi_startproc
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	cbz	x8, LBB62_2
; %bb.1:                                ; %bb2
	ldr	x1, [x1, #8]
	b	_wf_std.collections.ordered_map.ordered_map_insert_node$instance$43c0c30766ba2e8b
LBB62_2:                                ; %bb3
	ldr	x8, [x2, #256]
	ldp	q0, q1, [x2]
	ldp	q2, q3, [x2, #32]
	ldp	q4, q5, [x2, #64]
	ldp	q6, q7, [x2, #96]
	ldp	q16, q17, [x2, #128]
	ldp	q18, q19, [x2, #160]
	ldp	q20, q21, [x2, #192]
	ldp	q22, q23, [x2, #224]
	str	xzr, [x0]
	mov	w9, #1                          ; =0x1
	str	w9, [x0]
	stur	q0, [x0, #8]
	stur	q1, [x0, #24]
	stur	q2, [x0, #40]
	stur	q3, [x0, #56]
	stur	q4, [x0, #72]
	stur	q5, [x0, #88]
	stur	q6, [x0, #104]
	stur	q7, [x0, #120]
	stur	q16, [x0, #136]
	stur	q17, [x0, #152]
	stur	q18, [x0, #168]
	stur	q19, [x0, #184]
	stur	q20, [x0, #200]
	stur	q21, [x0, #216]
	stur	q22, [x0, #232]
	stur	q23, [x0, #248]
	stp	xzr, xzr, [x0, #272]
	str	x8, [x0, #264]
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_slots_new$instance$b5740be5b34e9f89 ; -- Begin function wf_slots_new$instance$b5740be5b34e9f89
	.p2align	2
_wf_slots_new$instance$b5740be5b34e9f89: ; @"wf_slots_new$instance$b5740be5b34e9f89"
; %bb.0:                                ; %entry
	mov	w1, #4208                       ; =0x1070
	b	_bzero
                                        ; -- End function
	.globl	_wf_box_new$instance$3178c7907270f1e1 ; -- Begin function wf_box_new$instance$3178c7907270f1e1
	.p2align	2
_wf_box_new$instance$3178c7907270f1e1:  ; @"wf_box_new$instance$3178c7907270f1e1"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w0, #4224                       ; =0x1080
	bl	_malloc
	cbz	x0, LBB64_2
; %bb.1:                                ; %box.new.ready.v1
	mov	x1, x19
	mov	w2, #4224                       ; =0x1080
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_memcpy
LBB64_2:                                ; %box.new.oom.v1
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_lookup_link$instance$768bf1dd9f398f38 ; -- Begin function wf_std.collections.ordered_map.ordered_map_lookup_link$instance$768bf1dd9f398f38
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_lookup_link$instance$768bf1dd9f398f38: ; @"wf_std.collections.ordered_map.ordered_map_lookup_link$instance$768bf1dd9f398f38"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB65_2
; %bb.1:                                ; %bb2.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #8]
	bl	_wf_std.collections.ordered_map.ordered_map_lookup_node$instance$768bf1dd9f398f38
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB65_2:
	mov	w2, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_edit_link$instance$887d1b484f24fc68 ; -- Begin function wf_std.collections.ordered_map.ordered_map_edit_link$instance$887d1b484f24fc68
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_edit_link$instance$887d1b484f24fc68: ; @"wf_std.collections.ordered_map.ordered_map_edit_link$instance$887d1b484f24fc68"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB66_2
; %bb.1:                                ; %bb2.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #8]
	bl	_wf_std.collections.ordered_map.ordered_map_edit_node$instance$887d1b484f24fc68
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB66_2:
	mov	w2, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_remove_link$instance$43c0c30766ba2e8b ; -- Begin function wf_std.collections.ordered_map.ordered_map_remove_link$instance$43c0c30766ba2e8b
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_remove_link$instance$43c0c30766ba2e8b: ; @"wf_std.collections.ordered_map.ordered_map_remove_link$instance$43c0c30766ba2e8b"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	cbz	x8, LBB67_2
; %bb.1:                                ; %bb2
	ldr	x1, [x1, #8]
	b	_wf_std.collections.ordered_map.ordered_map_remove_node$instance$43c0c30766ba2e8b
LBB67_2:                                ; %bb3
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0, #240]
	stp	q0, q0, [x0, #208]
	stp	q0, q0, [x0, #176]
	stp	q0, q0, [x0, #144]
	stp	q0, q0, [x0, #112]
	stp	q0, q0, [x0, #80]
	stp	q0, q0, [x0, #48]
	stp	q0, q0, [x0, #16]
	str	q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_contract_root$instance$d883f474bea0047c ; -- Begin function wf_std.collections.ordered_map.ordered_map_contract_root$instance$d883f474bea0047c
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_contract_root$instance$d883f474bea0047c: ; @"wf_std.collections.ordered_map.ordered_map_contract_root$instance$d883f474bea0047c"
; %bb.0:                                ; %entry
	ldr	x9, [x0]
	cbz	x9, LBB68_6
; %bb.1:                                ; %bb2
	sub	sp, sp, #80
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	sub	x19, x9, #1
	add	x21, x0, x19, lsl #3
	str	x19, [x0]
	ldr	x8, [x21, #8]
	ldr	x10, [x8, #16]
	cbnz	x10, LBB68_5
; %bb.2:                                ; %bb5
	mov	x20, x0
	ldp	x22, x23, [x8]
	mov	x0, x8
	bl	_free
	str	x23, [sp, #8]
	cbz	x22, LBB68_4
; %bb.3:                                ; %run.move.body.v3.preheader.i
	lsl	x2, x22, #3
	add	x0, x21, #8
	add	x1, sp, #8
	bl	_memcpy
LBB68_4:                                ; %"wf_append$instance$42f33d80f30f592c.exit"
	add	x9, x22, x19
	mov	x0, x20
LBB68_5:                                ; %bb1.sink.split
	str	x9, [x0]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #80
LBB68_6:                                ; %bb1
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_range_link$instance$475e4daed49f96af ; -- Begin function wf_std.collections.ordered_map.ordered_map_range_link$instance$475e4daed49f96af
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_range_link$instance$475e4daed49f96af: ; @"wf_std.collections.ordered_map.ordered_map_range_link$instance$475e4daed49f96af"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB69_2
; %bb.1:                                ; %bb2
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #8]
	bl	_wf_std.collections.ordered_map.ordered_map_range_node$instance$475e4daed49f96af
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB69_2:                                ; %bb1
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_each_link$instance$5703a7a9bf1884ed ; -- Begin function wf_std.collections.ordered_map.ordered_map_each_link$instance$5703a7a9bf1884ed
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_each_link$instance$5703a7a9bf1884ed: ; @"wf_std.collections.ordered_map.ordered_map_each_link$instance$5703a7a9bf1884ed"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB70_5
; %bb.1:                                ; %bb2
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	mov	x19, x1
	ldr	x20, [x0, #8]
	mov	x0, x20
	bl	_wf_std.collections.ordered_map.ordered_map_each_link$instance$5703a7a9bf1884ed
	ldr	x21, [x20, #16]
	cbz	x21, LBB70_4
; %bb.2:                                ; %bb2.i.preheader
	mov	x22, #0                         ; =0x0
	add	x20, x20, #288
	mov	w23, #131                       ; =0x83
LBB70_3:                                ; %bb2.i
                                        ; =>This Inner Loop Header: Depth=1
	sub	x0, x20, #264
	sub	x1, x20, #256
	bl	_wf_ordered_cost_record_content
	ldr	x8, [x19]
	madd	x8, x8, x23, x0
	str	x8, [x19]
	mov	x0, x20
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_each_link$instance$5703a7a9bf1884ed
	add	x22, x22, #1
	add	x20, x20, #280
	cmp	x21, x22
	b.ne	LBB70_3
LBB70_4:
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
LBB70_5:                                ; %bb1
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_free_link$instance$40650b236ee646e0 ; -- Begin function wf_std.collections.ordered_map.ordered_map_free_link$instance$40650b236ee646e0
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_free_link$instance$40650b236ee646e0: ; @"wf_std.collections.ordered_map.ordered_map_free_link$instance$40650b236ee646e0"
; %bb.0:                                ; %entry
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	ldr	q0, [x0]
	str	q0, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB71_2
; %bb.1:                                ; %bb2
	sub	x8, x8, #1
	mov	x9, sp
	add	x9, x9, x8, lsl #3
	str	x8, [sp]
	ldr	x0, [x9, #8]
	bl	_wf_std.collections.ordered_map.ordered_map_free_node$instance$40650b236ee646e0
LBB71_2:                                ; %bb1
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_search$instance$5046b787ff5cdb3f ; -- Begin function wf_std.collections.ordered_map.ordered_map_search$instance$5046b787ff5cdb3f
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_search$instance$5046b787ff5cdb3f: ; @"wf_std.collections.ordered_map.ordered_map_search$instance$5046b787ff5cdb3f"
; %bb.0:                                ; %entry
	ldr	x9, [x0, #16]
	cbz	x9, LBB72_5
; %bb.1:                                ; %bb2.lr.ph.i.i
	mov	x8, x0
	mov	x0, #0                          ; =0x0
	add	x8, x8, #24
	ldr	x10, [x1]
LBB72_2:                                ; %bb2.i.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x8], #32
	cmp	x10, x11
	b.ls	LBB72_6
; %bb.3:                                ; %bb8.i.i
                                        ;   in Loop: Header=BB72_2 Depth=1
	add	x0, x0, #1
	cmp	x9, x0
	b.ne	LBB72_2
; %bb.4:
	mov	x0, x9
	ret
LBB72_5:
	mov	x0, #0                          ; =0x0
LBB72_6:                                ; %"wf_std.collections.ordered_map.ordered_map_search_result$instance$5046b787ff5cdb3f.exit"
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_insert_node$instance$5046b787ff5cdb3f ; -- Begin function wf_std.collections.ordered_map.ordered_map_insert_node$instance$5046b787ff5cdb3f
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_insert_node$instance$5046b787ff5cdb3f: ; @"wf_std.collections.ordered_map.ordered_map_insert_node$instance$5046b787ff5cdb3f"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #128
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 128
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	ldp	x8, x9, [x2]
	ldr	x10, [x1, #16]
	cbz	x10, LBB73_8
; %bb.1:                                ; %bb2.lr.ph.i.i.i
	mov	x19, #0                         ; =0x0
	add	x11, x1, #24
LBB73_2:                                ; %bb2.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x12, [x11], #32
	cmp	x8, x12
	b.ls	LBB73_5
; %bb.3:                                ; %bb8.i.i.i
                                        ;   in Loop: Header=BB73_2 Depth=1
	add	x19, x19, #1
	cmp	x10, x19
	b.ne	LBB73_2
; %bb.4:
	mov	x19, x10
	b	LBB73_6
LBB73_5:                                ; %"wf_std.collections.ordered_map.ordered_map_search$instance$5046b787ff5cdb3f.exit"
	cbz	x19, LBB73_8
LBB73_6:                                ; %bb3
	add	x10, x1, x19, lsl #5
	stp	x8, x9, [sp, #8]
	ldr	x11, [x10, #8]
	cbz	x11, LBB73_13
; %bb.7:                                ; %bb2.i14
	mov	x20, x1
	mov	x21, x0
	sub	x8, x10, #8
	ldr	x1, [x8, #24]
	add	x0, sp, #40
	add	x2, sp, #8
	bl	_wf_std.collections.ordered_map.ordered_map_insert_node$instance$5046b787ff5cdb3f
	b	LBB73_10
LBB73_8:                                ; %bb2
	stp	x8, x9, [sp, #24]
	ldr	x10, [x1]
	cbz	x10, LBB73_12
; %bb.9:                                ; %bb2.i
	mov	x21, x0
	mov	x20, x1
	ldr	x1, [x1, #8]
	add	x0, sp, #40
	add	x2, sp, #24
	bl	_wf_std.collections.ordered_map.ordered_map_insert_node$instance$5046b787ff5cdb3f
	mov	x19, #0                         ; =0x0
LBB73_10:                               ; %bb1
	ldr	w8, [sp, #40]
	mov	x0, x21
	mov	x1, x20
	cbnz	w8, LBB73_14
; %bb.11:                               ; %bb4
	str	xzr, [x0, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	b	LBB73_15
LBB73_12:
	mov	x19, #0                         ; =0x0
LBB73_13:                               ; %bb5.sink.split
	mov	w10, #1                         ; =0x1
	str	w10, [sp, #40]
	stp	x8, x9, [sp, #48]
	stp	xzr, xzr, [sp, #64]
LBB73_14:                               ; %bb5
	add	x8, sp, #40
	add	x3, x8, #8
	mov	x2, x19
	bl	_wf_std.collections.ordered_map.ordered_map_insert_item$instance$0ed342445dd803f3
LBB73_15:                               ; %bb4
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_lookup_node$instance$11eb30e8dabe0f7e ; -- Begin function wf_std.collections.ordered_map.ordered_map_lookup_node$instance$11eb30e8dabe0f7e
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_lookup_node$instance$11eb30e8dabe0f7e: ; @"wf_std.collections.ordered_map.ordered_map_lookup_node$instance$11eb30e8dabe0f7e"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x10, [x0, #16]
	cbz	x10, LBB74_9
; %bb.1:                                ; %bb2.lr.ph.i.i
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
	ldr	x11, [x1]
LBB74_2:                                ; %bb2.i.i23
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x12, [x9]
	cmp	x11, x12
	b.ls	LBB74_5
; %bb.3:                                ; %bb8.i.i
                                        ;   in Loop: Header=BB74_2 Depth=1
	add	x8, x8, #1
	add	x9, x9, #32
	cmp	x10, x8
	b.ne	LBB74_2
; %bb.4:
	mov	x8, x10
	b	LBB74_7
LBB74_5:                                ; %"wf_std.collections.ordered_map.ordered_map_search_result$instance$5046b787ff5cdb3f.exit"
	ccmp	x8, x10, #2, hs
	b.lo	LBB74_13
; %bb.6:                                ; %bb1.i
	cbz	x8, LBB74_9
LBB74_7:                                ; %bb9.i
	add	x8, x0, x8, lsl #5
	ldr	x9, [x8, #8]
	cbz	x9, LBB74_12
; %bb.8:                                ; %bb2.i.i
	sub	x8, x8, #8
	ldr	x0, [x8, #24]
	b	LBB74_11
LBB74_9:                                ; %bb8.i
	ldr	x8, [x0]
	cbz	x8, LBB74_12
; %bb.10:                               ; %bb2.i.i16
	ldr	x0, [x0, #8]
LBB74_11:                               ; %"wf_std.collections.ordered_map.ordered_map_lookup_node$instance$11eb30e8dabe0f7e.body.exit"
	bl	_wf_std.collections.ordered_map.ordered_map_lookup_node$instance$11eb30e8dabe0f7e
	b	LBB74_14
LBB74_12:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	b	LBB74_14
LBB74_13:                               ; %bb5.i
	mov	w0, #0                          ; =0x0
	mov	w8, #131                        ; =0x83
	ldp	x10, x9, [x9]
	madd	x1, x10, x8, x9
	ldr	x9, [x3]
	madd	x8, x9, x8, x1
	str	x8, [x3]
LBB74_14:                               ; %"wf_std.collections.ordered_map.ordered_map_lookup_node$instance$11eb30e8dabe0f7e.body.exit"
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_edit_node$instance$41f33845185638b6 ; -- Begin function wf_std.collections.ordered_map.ordered_map_edit_node$instance$41f33845185638b6
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_edit_node$instance$41f33845185638b6: ; @"wf_std.collections.ordered_map.ordered_map_edit_node$instance$41f33845185638b6"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x8, x0
	ldr	x10, [x8, #16]!
	cbz	x10, LBB75_5
; %bb.1:                                ; %bb2.lr.ph.i.i.i
	mov	x9, #0                          ; =0x0
	add	x11, x0, #24
	ldr	x12, [x1]
LBB75_2:                                ; %bb2.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x13, [x11], #32
	cmp	x12, x13
	b.ls	LBB75_6
; %bb.3:                                ; %bb8.i.i.i
                                        ;   in Loop: Header=BB75_2 Depth=1
	add	x9, x9, #1
	cmp	x10, x9
	b.ne	LBB75_2
; %bb.4:
	mov	x9, x10
	b	LBB75_10
LBB75_5:
	mov	x9, #0                          ; =0x0
LBB75_6:                                ; %"wf_std.collections.ordered_map.ordered_map_search$instance$5046b787ff5cdb3f.exit"
	cmp	x9, x10
	b.hs	LBB75_9
; %bb.7:                                ; %bb2.i
	add	x11, x8, x9, lsl #5
	ldr	x10, [x1]
	ldr	x12, [x11, #8]
	cmp	x10, x12
	b.ne	LBB75_9
; %bb.8:                                ; %bb5.i
	mov	w0, #0                          ; =0x0
	ldr	x8, [x11, #16]
	add	x8, x8, #1
	str	x8, [x11, #16]
	mov	w9, #131                        ; =0x83
	madd	x1, x10, x9, x8
	ldr	x8, [x3]
	madd	x8, x8, x9, x1
	str	x8, [x3]
	b	LBB75_16
LBB75_9:                                ; %bb1.i
	cbz	x9, LBB75_12
LBB75_10:                               ; %bb9.i
	add	x8, x8, x9, lsl #5
	ldur	x9, [x8, #-8]
	cbz	x9, LBB75_15
; %bb.11:                               ; %bb2.i.i
	ldr	x0, [x8]
	b	LBB75_14
LBB75_12:                               ; %bb8.i
	ldr	x8, [x0]
	cbz	x8, LBB75_15
; %bb.13:                               ; %bb2.i.i16
	ldr	x0, [x0, #8]
LBB75_14:                               ; %"wf_std.collections.ordered_map.ordered_map_edit_node$instance$41f33845185638b6.body.exit"
	bl	_wf_std.collections.ordered_map.ordered_map_edit_node$instance$41f33845185638b6
	b	LBB75_16
LBB75_15:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
LBB75_16:                               ; %"wf_std.collections.ordered_map.ordered_map_edit_node$instance$41f33845185638b6.body.exit"
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_remove_node$instance$5046b787ff5cdb3f ; -- Begin function wf_std.collections.ordered_map.ordered_map_remove_node$instance$5046b787ff5cdb3f
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_remove_node$instance$5046b787ff5cdb3f: ; @"wf_std.collections.ordered_map.ordered_map_remove_node$instance$5046b787ff5cdb3f"
; %bb.0:                                ; %entry
	sub	sp, sp, #80
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	mov	x19, x0
	mov	x8, x0
	ldr	x21, [x8, #16]!
	cbz	x21, LBB76_5
; %bb.1:                                ; %bb2.lr.ph.i.i.i
	mov	x20, #0                         ; =0x0
	add	x9, x19, #24
	ldr	x10, [x1]
LBB76_2:                                ; %bb2.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x9], #32
	cmp	x10, x11
	b.ls	LBB76_6
; %bb.3:                                ; %bb8.i.i.i
                                        ;   in Loop: Header=BB76_2 Depth=1
	add	x20, x20, #1
	cmp	x21, x20
	b.ne	LBB76_2
; %bb.4:
	mov	x20, x21
	b	LBB76_10
LBB76_5:
	mov	x20, #0                         ; =0x0
LBB76_6:                                ; %"wf_std.collections.ordered_map.ordered_map_search$instance$5046b787ff5cdb3f.exit"
	cmp	x20, x21
	b.hs	LBB76_9
; %bb.7:                                ; %bb2.i
	add	x9, x8, x20, lsl #5
	mov	x0, x9
	ldr	x10, [x0, #8]!
	ldr	x11, [x1]
	cmp	x11, x10
	b.ne	LBB76_9
; %bb.8:                                ; %bb5.i
	ldp	q0, q1, [x0]
	stp	q0, q1, [sp]
	mvn	x8, x20
	add	x8, x21, x8
	lsl	x2, x8, #5
	add	x1, x9, #40
	bl	_memmove
	sub	x8, x21, #1
	str	x8, [x19, #16]
	mov	x2, sp
	mov	x0, x19
	mov	x1, x20
	bl	_wf_std.collections.ordered_map.ordered_map_finish_remove$instance$0ed342445dd803f3
	mov	x2, x1
	mov	x1, x0
	b	LBB76_15
LBB76_9:                                ; %bb1.i
	cbz	x20, LBB76_11
LBB76_10:                               ; %bb9.i
	add	x8, x8, x20, lsl #5
	ldur	x9, [x8, #-8]
	cbnz	x9, LBB76_13
	b	LBB76_16
LBB76_11:                               ; %bb8.i
	ldr	x8, [x19]
	cbz	x8, LBB76_16
; %bb.12:                               ; %bb2.i.i15
	mov	x20, #0                         ; =0x0
	add	x8, x19, #8
LBB76_13:                               ; %bb7.i
	ldr	x0, [x8]
	bl	_wf_std.collections.ordered_map.ordered_map_remove_node$instance$5046b787ff5cdb3f
	cbz	w0, LBB76_17
; %bb.14:                               ; %bb11.i
	mov	x0, x19
	mov	x19, x1
	mov	x1, x20
	mov	x20, x2
	bl	_wf_std.collections.ordered_map.ordered_map_repair_child$instance$0ed342445dd803f3
	mov	x1, x19
	mov	x2, x20
LBB76_15:                               ; %"wf_std.collections.ordered_map.ordered_map_remove_node$instance$5046b787ff5cdb3f.body.exit"
	mov	w0, #1                          ; =0x1
	b	LBB76_18
LBB76_16:
	mov	x2, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	w0, #0                          ; =0x0
	b	LBB76_18
LBB76_17:
	mov	x2, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
LBB76_18:                               ; %"wf_std.collections.ordered_map.ordered_map_remove_node$instance$5046b787ff5cdb3f.body.exit"
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_range_node$instance$171ecc1fc526bab5 ; -- Begin function wf_std.collections.ordered_map.ordered_map_range_node$instance$171ecc1fc526bab5
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_range_node$instance$171ecc1fc526bab5: ; @"wf_std.collections.ordered_map.ordered_map_range_node$instance$171ecc1fc526bab5"
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	mov	x19, x4
	mov	x20, x3
	mov	x21, x2
	mov	x22, x1
	mov	x23, x0
	ldr	x24, [x0, #16]
	cbz	x24, LBB77_8
; %bb.1:                                ; %bb2.lr.ph.i.i.i
	mov	x25, #0                         ; =0x0
	add	x8, x23, #24
	ldr	x9, [x22]
LBB77_2:                                ; %bb2.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x8], #32
	cmp	x9, x10
	b.ls	LBB77_5
; %bb.3:                                ; %bb8.i.i.i
                                        ;   in Loop: Header=BB77_2 Depth=1
	add	x25, x25, #1
	cmp	x24, x25
	b.ne	LBB77_2
; %bb.4:
	mov	x25, x24
	b	LBB77_6
LBB77_5:                                ; %"wf_std.collections.ordered_map.ordered_map_search$instance$5046b787ff5cdb3f.exit"
	cbz	x25, LBB77_8
LBB77_6:                                ; %bb3
	add	x8, x23, x25, lsl #5
	ldr	x9, [x8, #8]
	cbz	x9, LBB77_11
; %bb.7:                                ; %bb2.i7
	sub	x8, x8, #8
	add	x8, x8, #24
	b	LBB77_10
LBB77_8:                                ; %bb2
	ldr	x8, [x23]
	cbz	x8, LBB77_17
; %bb.9:                                ; %bb2.i
	mov	x25, #0                         ; =0x0
	add	x8, x23, #8
LBB77_10:                               ; %bb1.sink.split
	ldr	x0, [x8]
	mov	x1, x22
	mov	x2, x21
	mov	x3, x20
	mov	x4, x19
	bl	_wf_std.collections.ordered_map.ordered_map_range_node$instance$171ecc1fc526bab5
LBB77_11:                               ; %bb1
	cmp	x25, x24
	b.hs	LBB77_18
LBB77_12:                               ; %bb5.lr.ph
	ldr	x26, [x21]
	add	x8, x23, x25, lsl #5
	add	x23, x8, #48
	mov	w27, #131                       ; =0x83
	b	LBB77_14
LBB77_13:                               ; %"wf_std.collections.ordered_map.ordered_map_range_link$instance$171ecc1fc526bab5.exit20"
                                        ;   in Loop: Header=BB77_14 Depth=1
	add	x25, x25, #1
	add	x23, x23, #32
	cmp	x24, x25
	b.eq	LBB77_18
LBB77_14:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	ldur	x8, [x23, #-24]
	cmp	x8, x26
	b.hs	LBB77_18
; %bb.15:                               ; %bb10
                                        ;   in Loop: Header=BB77_14 Depth=1
	ldr	x9, [x19]
	add	x8, x9, x8
	ldp	x9, x10, [x23, #-16]
	madd	x8, x8, x27, x9
	str	x8, [x19]
	cbz	x10, LBB77_13
; %bb.16:                               ; %bb2.i16
                                        ;   in Loop: Header=BB77_14 Depth=1
	ldr	x0, [x23]
	mov	x1, x22
	mov	x2, x21
	mov	x3, x20
	mov	x4, x19
	bl	_wf_std.collections.ordered_map.ordered_map_range_node$instance$171ecc1fc526bab5
	b	LBB77_13
LBB77_17:
	mov	x25, #0                         ; =0x0
	cmp	x25, x24
	b.lo	LBB77_12
LBB77_18:                               ; %common.ret
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_each_node$instance$5fa8e8b3d971a72b ; -- Begin function wf_std.collections.ordered_map.ordered_map_each_node$instance$5fa8e8b3d971a72b
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_each_node$instance$5fa8e8b3d971a72b: ; @"wf_std.collections.ordered_map.ordered_map_each_node$instance$5fa8e8b3d971a72b"
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	mov	x19, x1
	mov	x20, x0
	bl	_wf_std.collections.ordered_map.ordered_map_each_link$instance$5fa8e8b3d971a72b
	ldr	x21, [x20, #16]
	cbz	x21, LBB78_3
; %bb.1:                                ; %bb2.preheader
	mov	x22, #0                         ; =0x0
	add	x20, x20, #40
	mov	w23, #131                       ; =0x83
LBB78_2:                                ; %bb2
                                        ; =>This Inner Loop Header: Depth=1
	ldp	x8, x9, [x20, #-16]
	ldr	x10, [x19]
	add	x8, x10, x8
	madd	x8, x8, x23, x9
	str	x8, [x19]
	mov	x0, x20
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_each_link$instance$5fa8e8b3d971a72b
	add	x22, x22, #1
	add	x20, x20, #32
	cmp	x21, x22
	b.ne	LBB78_2
LBB78_3:                                ; %bb4
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_free_node$instance$a14f6fad6bd909bd ; -- Begin function wf_std.collections.ordered_map.ordered_map_free_node$instance$a14f6fad6bd909bd
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_free_node$instance$a14f6fad6bd909bd: ; @"wf_std.collections.ordered_map.ordered_map_free_node$instance$a14f6fad6bd909bd"
; %bb.0:                                ; %entry
	sub	sp, sp, #112
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x1
	mov	x20, x0
	mov	x21, x0
	ldr	x8, [x21, #16]!
	cbz	x8, LBB79_5
; %bb.1:
	mov	w22, #131                       ; =0x83
	mov	x23, #58809                     ; =0xe5b9
	movk	x23, #7396, lsl #16
	movk	x23, #18285, lsl #32
	movk	x23, #48984, lsl #48
	mov	x24, #4587                      ; =0x11eb
	movk	x24, #4913, lsl #16
	movk	x24, #18875, lsl #32
	movk	x24, #38096, lsl #48
	add	x25, sp, #16
	b	LBB79_3
LBB79_2:                                ; %"wf_std.collections.ordered_map.ordered_map_free_link$instance$a14f6fad6bd909bd.exit18"
                                        ;   in Loop: Header=BB79_3 Depth=1
	cbz	x8, LBB79_5
LBB79_3:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	sub	x8, x8, #1
	add	x9, x21, x8, lsl #5
	str	x8, [x21]
	ldp	x10, x11, [x9, #8]
	ldur	q0, [x9, #24]
	str	q0, [sp, #16]
	madd	x9, x10, x22, x11
	ldp	x10, x11, [x19, #8]
	add	x10, x10, x9
	eor	x9, x9, x9, lsr #30
	mul	x9, x9, x23
	eor	x9, x9, x9, lsr #27
	mul	x9, x9, x24
	eor	x11, x11, x9, lsr #31
	eor	x9, x11, x9
	stp	x10, x9, [x19, #8]
	ldr	x9, [x19, #24]
	add	x9, x9, #1
	str	x9, [x19, #24]
	ldr	x9, [sp, #16]
	cbz	x9, LBB79_2
; %bb.4:                                ; %bb2.i12
                                        ;   in Loop: Header=BB79_3 Depth=1
	sub	x8, x9, #1
	add	x9, x25, x8, lsl #3
	str	x8, [sp, #16]
	ldr	x0, [x9, #8]
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_free_node$instance$a14f6fad6bd909bd
	ldr	x8, [x21]
	b	LBB79_2
LBB79_5:                                ; %bb4
	str	xzr, [sp, #8]
	ldr	x21, [x20]
	cbz	x21, LBB79_7
; %bb.6:                                ; %run.move.body.v3.preheader.i
	lsl	x2, x21, #3
	add	x0, sp, #8
	add	x1, x20, #8
	bl	_memcpy
	ldr	x22, [sp, #8]
	mov	x0, x20
	bl	_free
	add	x8, sp, #16
	add	x8, x8, #8
	sub	x9, x21, #1
	stp	x9, x22, [sp, #16]
	ldr	x0, [x8, x9, lsl #3]
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_free_node$instance$a14f6fad6bd909bd
	b	LBB79_8
LBB79_7:                                ; %"wf_std.collections.ordered_map.ordered_map_free_link$instance$a14f6fad6bd909bd.exit.critedge"
	mov	x0, x20
	bl	_free
	str	xzr, [sp, #24]
LBB79_8:                                ; %"wf_std.collections.ordered_map.ordered_map_free_link$instance$a14f6fad6bd909bd.exit"
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_search$instance$43c0c30766ba2e8b ; -- Begin function wf_std.collections.ordered_map.ordered_map_search$instance$43c0c30766ba2e8b
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_search$instance$43c0c30766ba2e8b: ; @"wf_std.collections.ordered_map.ordered_map_search$instance$43c0c30766ba2e8b"
; %bb.0:                                ; %entry
	ldr	x9, [x0, #16]
	cbz	x9, LBB80_5
; %bb.1:                                ; %bb2.lr.ph.i.i
	mov	x8, x0
	mov	x0, #0                          ; =0x0
	add	x8, x8, #24
	ldr	x10, [x1]
LBB80_2:                                ; %bb2.i.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x8]
	cmp	x10, x11
	b.ls	LBB80_6
; %bb.3:                                ; %bb8.i.i
                                        ;   in Loop: Header=BB80_2 Depth=1
	add	x8, x8, #280
	add	x0, x0, #1
	cmp	x9, x0
	b.ne	LBB80_2
; %bb.4:
	mov	x0, x9
	ret
LBB80_5:
	mov	x0, #0                          ; =0x0
LBB80_6:                                ; %"wf_std.collections.ordered_map.ordered_map_search_result$instance$43c0c30766ba2e8b.exit"
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_insert_node$instance$43c0c30766ba2e8b ; -- Begin function wf_std.collections.ordered_map.ordered_map_insert_node$instance$43c0c30766ba2e8b
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_insert_node$instance$43c0c30766ba2e8b: ; @"wf_std.collections.ordered_map.ordered_map_insert_node$instance$43c0c30766ba2e8b"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	sub	sp, sp, #1104
	.cfi_def_cfa_offset 1152
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x1
	mov	x19, x0
	ldr	x8, [x2], #8
	ldr	x10, [x1, #16]
	cbz	x10, LBB81_8
; %bb.1:                                ; %bb2.lr.ph.i.i.i
	mov	x21, #0                         ; =0x0
	add	x9, sp, #288
	add	x11, x20, #24
LBB81_2:                                ; %bb2.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x12, [x11]
	cmp	x8, x12
	b.ls	LBB81_5
; %bb.3:                                ; %bb8.i.i.i
                                        ;   in Loop: Header=BB81_2 Depth=1
	add	x11, x11, #280
	add	x21, x21, #1
	cmp	x10, x21
	b.ne	LBB81_2
; %bb.4:
	mov	x21, x10
	b	LBB81_6
LBB81_5:                                ; %"wf_std.collections.ordered_map.ordered_map_search$instance$43c0c30766ba2e8b.exit"
	cbz	x21, LBB81_8
LBB81_6:                                ; %bb3
	ldp	q0, q1, [x2, #192]
	stur	q0, [x9, #200]
	stur	q1, [x9, #216]
	ldp	q0, q1, [x2, #224]
	stur	q0, [x9, #232]
	stur	q1, [x9, #248]
	ldp	q0, q1, [x2, #128]
	stur	q0, [x9, #136]
	stur	q1, [x9, #152]
	ldp	q0, q1, [x2, #160]
	stur	q0, [x9, #168]
	stur	q1, [x9, #184]
	ldp	q0, q1, [x2, #64]
	stur	q0, [x9, #72]
	stur	q1, [x9, #88]
	ldp	q0, q1, [x2, #96]
	stur	q0, [x9, #104]
	stur	q1, [x9, #120]
	ldp	q0, q1, [x2]
	stur	q0, [x9, #8]
	stur	q1, [x9, #24]
	ldp	q0, q1, [x2, #32]
	stur	q0, [x9, #40]
	mov	w10, #280                       ; =0x118
	madd	x10, x21, x10, x20
	str	x8, [sp, #288]
	stur	q1, [x9, #56]
	add	x0, sp, #816
	add	x1, x10, #8
	add	x2, sp, #288
	bl	_wf_std.collections.ordered_map.ordered_map_insert_link$instance$43c0c30766ba2e8b
	ldr	w8, [sp, #816]
	cbz	w8, LBB81_9
LBB81_7:                                ; %bb5
	add	x8, sp, #816
	add	x0, sp, #8
	add	x1, x8, #8
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	add	x3, sp, #8
	mov	x0, x19
	mov	x1, x20
	mov	x2, x21
	bl	_wf_std.collections.ordered_map.ordered_map_insert_item$instance$d883f474bea0047c
	b	LBB81_10
LBB81_8:                                ; %bb2
	add	x9, sp, #552
	ldp	q0, q1, [x2, #192]
	stur	q0, [x9, #200]
	stur	q1, [x9, #216]
	ldp	q0, q1, [x2, #224]
	stur	q0, [x9, #232]
	stur	q1, [x9, #248]
	ldp	q0, q1, [x2, #128]
	stur	q0, [x9, #136]
	stur	q1, [x9, #152]
	ldp	q0, q1, [x2, #160]
	stur	q0, [x9, #168]
	stur	q1, [x9, #184]
	ldp	q0, q1, [x2, #64]
	stur	q0, [x9, #72]
	stur	q1, [x9, #88]
	ldp	q0, q1, [x2, #96]
	stur	q0, [x9, #104]
	stur	q1, [x9, #120]
	ldp	q0, q1, [x2]
	stur	q0, [x9, #8]
	stur	q1, [x9, #24]
	ldp	q0, q1, [x2, #32]
	stur	q0, [x9, #40]
	str	x8, [sp, #552]
	stur	q1, [x9, #56]
	add	x0, sp, #816
	add	x2, sp, #552
	mov	x1, x20
	bl	_wf_std.collections.ordered_map.ordered_map_insert_link$instance$43c0c30766ba2e8b
	mov	x21, #0                         ; =0x0
	ldr	w8, [sp, #816]
	cbnz	w8, LBB81_7
LBB81_9:                                ; %bb4
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #256]
	stp	q0, q0, [x19, #224]
	stp	q0, q0, [x19, #192]
	stp	q0, q0, [x19, #160]
	stp	q0, q0, [x19, #128]
	stp	q0, q0, [x19, #96]
	stp	q0, q0, [x19, #64]
	stp	q0, q0, [x19, #32]
	stp	q0, q0, [x19]
LBB81_10:                               ; %bb5
	add	sp, sp, #1104
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_lookup_node$instance$768bf1dd9f398f38 ; -- Begin function wf_std.collections.ordered_map.ordered_map_lookup_node$instance$768bf1dd9f398f38
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_lookup_node$instance$768bf1dd9f398f38: ; @"wf_std.collections.ordered_map.ordered_map_lookup_node$instance$768bf1dd9f398f38"
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	ldr	x10, [x0, #16]
	cbz	x10, LBB82_9
; %bb.1:                                ; %bb2.lr.ph.i.i
	mov	x9, #0                          ; =0x0
	add	x8, x0, #24
	ldr	x11, [x1]
LBB82_2:                                ; %bb2.i.i22
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x12, [x8]
	cmp	x11, x12
	b.ls	LBB82_5
; %bb.3:                                ; %bb8.i.i
                                        ;   in Loop: Header=BB82_2 Depth=1
	add	x9, x9, #1
	add	x8, x8, #280
	cmp	x10, x9
	b.ne	LBB82_2
; %bb.4:
	mov	x9, x10
	b	LBB82_7
LBB82_5:                                ; %"wf_std.collections.ordered_map.ordered_map_search_result$instance$43c0c30766ba2e8b.exit"
	ccmp	x9, x10, #2, hs
	b.lo	LBB82_13
; %bb.6:                                ; %bb1.i
	cbz	x9, LBB82_9
LBB82_7:                                ; %bb9.i
	mov	w8, #280                        ; =0x118
	madd	x8, x9, x8, x0
	ldr	x9, [x8, #8]
	cbz	x9, LBB82_12
; %bb.8:                                ; %bb2.i.i
	sub	x8, x8, #256
	ldr	x0, [x8, #272]
	b	LBB82_11
LBB82_9:                                ; %bb8.i
	ldr	x8, [x0]
	cbz	x8, LBB82_12
; %bb.10:                               ; %bb2.i.i16
	ldr	x0, [x0, #8]
LBB82_11:                               ; %"wf_std.collections.ordered_map.ordered_map_lookup_node$instance$768bf1dd9f398f38.body.exit"
	bl	_wf_std.collections.ordered_map.ordered_map_lookup_node$instance$768bf1dd9f398f38
	b	LBB82_14
LBB82_12:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	b	LBB82_14
LBB82_13:                               ; %bb5.i
	add	x1, x8, #8
	mov	x0, x8
	mov	x19, x3
	bl	_wf_ordered_cost_record_content
	mov	x1, x0
	mov	w0, #0                          ; =0x0
	ldr	x8, [x19]
	mov	w9, #131                        ; =0x83
	madd	x8, x8, x9, x1
	str	x8, [x19]
LBB82_14:                               ; %"wf_std.collections.ordered_map.ordered_map_lookup_node$instance$768bf1dd9f398f38.body.exit"
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_edit_node$instance$887d1b484f24fc68 ; -- Begin function wf_std.collections.ordered_map.ordered_map_edit_node$instance$887d1b484f24fc68
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_edit_node$instance$887d1b484f24fc68: ; @"wf_std.collections.ordered_map.ordered_map_edit_node$instance$887d1b484f24fc68"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x9, x0
	ldr	x8, [x9, #16]!
	cbz	x8, LBB83_5
; %bb.1:                                ; %bb2.lr.ph.i.i.i
	mov	x10, #0                         ; =0x0
	add	x11, x0, #24
	ldr	x12, [x1]
LBB83_2:                                ; %bb2.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x13, [x11]
	cmp	x12, x13
	b.ls	LBB83_6
; %bb.3:                                ; %bb8.i.i.i
                                        ;   in Loop: Header=BB83_2 Depth=1
	add	x11, x11, #280
	add	x10, x10, #1
	cmp	x8, x10
	b.ne	LBB83_2
; %bb.4:
	mov	x10, x8
	b	LBB83_10
LBB83_5:
	mov	x10, #0                         ; =0x0
LBB83_6:                                ; %"wf_std.collections.ordered_map.ordered_map_search$instance$43c0c30766ba2e8b.exit"
	cmp	x10, x8
	b.hs	LBB83_9
; %bb.7:                                ; %bb2.i
	mov	w8, #280                        ; =0x118
	madd	x11, x10, x8, x9
	mov	x8, x11
	ldr	x12, [x8, #8]!
	ldr	x13, [x1]
	cmp	x13, x12
	b.ne	LBB83_9
; %bb.8:                                ; %bb5.i
	add	x2, x11, #16
	mov	x0, x3
	mov	x1, x8
	bl	_wf_ordered_cost_record_edit
	mov	x1, x0
	mov	w0, #0                          ; =0x0
	b	LBB83_16
LBB83_9:                                ; %bb1.i
	cbz	x10, LBB83_12
LBB83_10:                               ; %bb9.i
	mov	w8, #280                        ; =0x118
	madd	x8, x10, x8, x9
	ldur	x9, [x8, #-8]
	cbz	x9, LBB83_15
; %bb.11:                               ; %bb2.i.i
	ldr	x0, [x8]
	b	LBB83_14
LBB83_12:                               ; %bb8.i
	ldr	x8, [x0]
	cbz	x8, LBB83_15
; %bb.13:                               ; %bb2.i.i16
	ldr	x0, [x0, #8]
LBB83_14:                               ; %"wf_std.collections.ordered_map.ordered_map_edit_node$instance$887d1b484f24fc68.body.exit"
	bl	_wf_std.collections.ordered_map.ordered_map_edit_node$instance$887d1b484f24fc68
	b	LBB83_16
LBB83_15:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
LBB83_16:                               ; %"wf_std.collections.ordered_map.ordered_map_edit_node$instance$887d1b484f24fc68.body.exit"
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_remove_node$instance$43c0c30766ba2e8b ; -- Begin function wf_std.collections.ordered_map.ordered_map_remove_node$instance$43c0c30766ba2e8b
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_remove_node$instance$43c0c30766ba2e8b: ; @"wf_std.collections.ordered_map.ordered_map_remove_node$instance$43c0c30766ba2e8b"
; %bb.0:                                ; %entry
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #816
	mov	x20, x1
	mov	x19, x0
	mov	x8, x1
	ldr	x23, [x8, #16]!
	cbz	x23, LBB84_5
; %bb.1:                                ; %bb2.lr.ph.i.i.i
	mov	x21, #0                         ; =0x0
	add	x9, x20, #24
	ldr	x10, [x2]
LBB84_2:                                ; %bb2.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x9]
	cmp	x10, x11
	b.ls	LBB84_6
; %bb.3:                                ; %bb8.i.i.i
                                        ;   in Loop: Header=BB84_2 Depth=1
	add	x9, x9, #280
	add	x21, x21, #1
	cmp	x23, x21
	b.ne	LBB84_2
; %bb.4:
	mov	x21, x23
	b	LBB84_10
LBB84_5:
	mov	x21, #0                         ; =0x0
LBB84_6:                                ; %"wf_std.collections.ordered_map.ordered_map_search$instance$43c0c30766ba2e8b.exit"
	cmp	x21, x23
	b.hs	LBB84_9
; %bb.7:                                ; %bb2
	mov	w9, #280                        ; =0x118
	madd	x24, x21, x9, x8
	mov	x22, x24
	ldr	x9, [x22, #8]!
	ldr	x10, [x2]
	cmp	x10, x9
	b.ne	LBB84_9
; %bb.8:                                ; %bb5
	mov	w25, #280                       ; =0x118
	add	x0, sp, #536
	mov	x1, x22
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	mvn	x8, x21
	add	x8, x23, x8
	mul	x2, x8, x25
	add	x1, x24, #288
	mov	x0, x22
	bl	_memmove
	sub	x8, x23, #1
	str	x8, [x20, #16]
	add	x0, sp, #272
	add	x3, sp, #536
	mov	x1, x20
	mov	x2, x21
	bl	_wf_std.collections.ordered_map.ordered_map_finish_remove$instance$d883f474bea0047c
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19], #8
	add	x1, sp, #272
	b	LBB84_15
LBB84_9:                                ; %bb1
	cbz	x21, LBB84_11
LBB84_10:                               ; %bb9
	mov	w9, #280                        ; =0x118
	madd	x8, x21, x9, x8
	ldur	x9, [x8, #-8]
	cbnz	x9, LBB84_13
	b	LBB84_16
LBB84_11:                               ; %bb8
	ldr	x8, [x20]
	cbz	x8, LBB84_16
; %bb.12:                               ; %bb2.i
	mov	x21, #0                         ; =0x0
	add	x8, x20, #8
LBB84_13:                               ; %bb7
	ldr	x1, [x8]
	mov	x22, sp
	mov	x0, sp
	bl	_wf_std.collections.ordered_map.ordered_map_remove_node$instance$43c0c30766ba2e8b
	ldr	w8, [sp]
	cbz	w8, LBB84_16
; %bb.14:                               ; %bb11
	mov	x0, x20
	mov	x1, x21
	bl	_wf_std.collections.ordered_map.ordered_map_repair_child$instance$d883f474bea0047c
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19], #8
	add	x1, x22, #8
LBB84_15:                               ; %common.ret
	mov	x0, x19
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	b	LBB84_17
LBB84_16:                               ; %bb10
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #240]
	stp	q0, q0, [x19, #208]
	stp	q0, q0, [x19, #176]
	stp	q0, q0, [x19, #144]
	stp	q0, q0, [x19, #112]
	stp	q0, q0, [x19, #80]
	stp	q0, q0, [x19, #48]
	stp	q0, q0, [x19, #16]
	str	q0, [x19]
LBB84_17:                               ; %common.ret
	add	sp, sp, #816
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_range_node$instance$475e4daed49f96af ; -- Begin function wf_std.collections.ordered_map.ordered_map_range_node$instance$475e4daed49f96af
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_range_node$instance$475e4daed49f96af: ; @"wf_std.collections.ordered_map.ordered_map_range_node$instance$475e4daed49f96af"
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	mov	x19, x4
	mov	x20, x3
	mov	x21, x2
	mov	x22, x1
	mov	x23, x0
	ldr	x24, [x0, #16]
	cbz	x24, LBB85_8
; %bb.1:                                ; %bb2.lr.ph.i.i.i
	mov	x25, #0                         ; =0x0
	add	x8, x23, #24
	ldr	x9, [x22]
LBB85_2:                                ; %bb2.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x8]
	cmp	x9, x10
	b.ls	LBB85_5
; %bb.3:                                ; %bb8.i.i.i
                                        ;   in Loop: Header=BB85_2 Depth=1
	add	x8, x8, #280
	add	x25, x25, #1
	cmp	x24, x25
	b.ne	LBB85_2
; %bb.4:
	mov	x25, x24
	b	LBB85_6
LBB85_5:                                ; %"wf_std.collections.ordered_map.ordered_map_search$instance$43c0c30766ba2e8b.exit"
	cbz	x25, LBB85_8
LBB85_6:                                ; %bb3
	mov	w8, #280                        ; =0x118
	madd	x8, x25, x8, x23
	ldr	x9, [x8, #8]
	cbz	x9, LBB85_11
; %bb.7:                                ; %bb2.i7
	sub	x8, x8, #256
	add	x8, x8, #272
	b	LBB85_10
LBB85_8:                                ; %bb2
	ldr	x8, [x23]
	cbz	x8, LBB85_17
; %bb.9:                                ; %bb2.i
	mov	x25, #0                         ; =0x0
	add	x8, x23, #8
LBB85_10:                               ; %bb1.sink.split
	ldr	x0, [x8]
	mov	x1, x22
	mov	x2, x21
	mov	x3, x20
	mov	x4, x19
	bl	_wf_std.collections.ordered_map.ordered_map_range_node$instance$475e4daed49f96af
LBB85_11:                               ; %bb1
	cmp	x25, x24
	b.hs	LBB85_18
LBB85_12:                               ; %bb5.lr.ph
	ldr	x26, [x21]
	mov	w8, #280                        ; =0x118
	madd	x23, x25, x8, x23
	mov	w27, #131                       ; =0x83
	b	LBB85_14
LBB85_13:                               ; %"wf_std.collections.ordered_map.ordered_map_range_link$instance$475e4daed49f96af.exit21"
                                        ;   in Loop: Header=BB85_14 Depth=1
	add	x25, x25, #1
	add	x23, x23, #280
	cmp	x24, x25
	b.eq	LBB85_18
LBB85_14:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	mov	x0, x23
	ldr	x8, [x0, #24]!
	cmp	x8, x26
	b.hs	LBB85_18
; %bb.15:                               ; %bb10
                                        ;   in Loop: Header=BB85_14 Depth=1
	add	x1, x23, #32
	bl	_wf_ordered_cost_record_content
	ldr	x8, [x19]
	madd	x8, x8, x27, x0
	str	x8, [x19]
	ldr	x8, [x23, #288]
	cbz	x8, LBB85_13
; %bb.16:                               ; %bb2.i17
                                        ;   in Loop: Header=BB85_14 Depth=1
	ldr	x0, [x23, #296]
	mov	x1, x22
	mov	x2, x21
	mov	x3, x20
	mov	x4, x19
	bl	_wf_std.collections.ordered_map.ordered_map_range_node$instance$475e4daed49f96af
	b	LBB85_13
LBB85_17:
	mov	x25, #0                         ; =0x0
	cmp	x25, x24
	b.lo	LBB85_12
LBB85_18:                               ; %common.ret
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_each_node$instance$5703a7a9bf1884ed ; -- Begin function wf_std.collections.ordered_map.ordered_map_each_node$instance$5703a7a9bf1884ed
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_each_node$instance$5703a7a9bf1884ed: ; @"wf_std.collections.ordered_map.ordered_map_each_node$instance$5703a7a9bf1884ed"
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	mov	x19, x1
	mov	x20, x0
	bl	_wf_std.collections.ordered_map.ordered_map_each_link$instance$5703a7a9bf1884ed
	ldr	x21, [x20, #16]
	cbz	x21, LBB86_3
; %bb.1:                                ; %bb2.preheader
	mov	x22, #0                         ; =0x0
	add	x20, x20, #288
	mov	w23, #131                       ; =0x83
LBB86_2:                                ; %bb2
                                        ; =>This Inner Loop Header: Depth=1
	sub	x0, x20, #264
	sub	x1, x20, #256
	bl	_wf_ordered_cost_record_content
	ldr	x8, [x19]
	madd	x8, x8, x23, x0
	str	x8, [x19]
	mov	x0, x20
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_each_link$instance$5703a7a9bf1884ed
	add	x22, x22, #1
	add	x20, x20, #280
	cmp	x21, x22
	b.ne	LBB86_2
LBB86_3:                                ; %bb4
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_free_node$instance$40650b236ee646e0 ; -- Begin function wf_std.collections.ordered_map.ordered_map_free_node$instance$40650b236ee646e0
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_free_node$instance$40650b236ee646e0: ; @"wf_std.collections.ordered_map.ordered_map_free_node$instance$40650b236ee646e0"
; %bb.0:                                ; %entry
	sub	sp, sp, #368
	stp	x26, x25, [sp, #288]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #304]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #320]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #336]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #352]            ; 16-byte Folded Spill
	mov	x19, x1
	mov	x20, x0
	mov	x21, x0
	ldr	x25, [x21, #16]!
	cbz	x25, LBB87_5
; %bb.1:
	add	x22, sp, #16
	mov	w23, #280                       ; =0x118
	add	x24, sp, #272
	b	LBB87_3
LBB87_2:                                ; %"wf_std.collections.ordered_map.ordered_map_free_link$instance$40650b236ee646e0.exit17"
                                        ;   in Loop: Header=BB87_3 Depth=1
	cbz	x25, LBB87_5
LBB87_3:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	sub	x25, x25, #1
	str	x25, [x21]
	madd	x8, x25, x23, x21
	ldr	x1, [x8, #8]
	ldp	q0, q1, [x8, #208]
	stp	q0, q1, [x22, #192]
	ldp	q0, q1, [x8, #240]
	stp	q0, q1, [x22, #224]
	ldp	q0, q1, [x8, #144]
	stp	q0, q1, [x22, #128]
	ldp	q0, q1, [x8, #176]
	stp	q0, q1, [x22, #160]
	ldp	q0, q1, [x8, #80]
	stp	q0, q1, [sp, #80]
	ldp	q0, q1, [x8, #112]
	stp	q0, q1, [sp, #112]
	ldp	q0, q1, [x8, #16]
	stp	q0, q1, [sp, #16]
	ldp	q0, q1, [x8, #48]
	stp	q0, q1, [sp, #48]
	ldr	q0, [x8, #272]
	str	q0, [x22, #256]
	add	x2, sp, #16
	mov	x0, x19
	bl	_wf_ordered_cost_record_consume
	ldr	x8, [sp, #272]
	cbz	x8, LBB87_2
; %bb.4:                                ; %bb2.i11
                                        ;   in Loop: Header=BB87_3 Depth=1
	sub	x8, x8, #1
	add	x9, x24, x8, lsl #3
	str	x8, [sp, #272]
	ldr	x0, [x9, #8]
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_free_node$instance$40650b236ee646e0
	ldr	x25, [x21]
	b	LBB87_2
LBB87_5:                                ; %bb4
	str	xzr, [sp, #8]
	ldr	x21, [x20]
	cbz	x21, LBB87_7
; %bb.6:                                ; %run.move.body.v3.preheader.i
	lsl	x2, x21, #3
	add	x0, sp, #8
	add	x1, x20, #8
	bl	_memcpy
	ldr	x22, [sp, #8]
	mov	x0, x20
	bl	_free
	add	x8, sp, #272
	add	x8, x8, #8
	sub	x9, x21, #1
	stp	x9, x22, [sp, #272]
	ldr	x0, [x8, x9, lsl #3]
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_free_node$instance$40650b236ee646e0
	b	LBB87_8
LBB87_7:                                ; %"wf_std.collections.ordered_map.ordered_map_free_link$instance$40650b236ee646e0.exit.critedge"
	mov	x0, x20
	bl	_free
	str	xzr, [sp, #280]
LBB87_8:                                ; %"wf_std.collections.ordered_map.ordered_map_free_link$instance$40650b236ee646e0.exit"
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #352]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #336]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #320]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #304]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #288]            ; 16-byte Folded Reload
	add	sp, sp, #368
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_search_result$instance$5046b787ff5cdb3f ; -- Begin function wf_std.collections.ordered_map.ordered_map_search_result$instance$5046b787ff5cdb3f
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_search_result$instance$5046b787ff5cdb3f: ; @"wf_std.collections.ordered_map.ordered_map_search_result$instance$5046b787ff5cdb3f"
; %bb.0:                                ; %entry
	ldr	x9, [x0, #16]
	cbz	x9, LBB88_5
; %bb.1:                                ; %bb2.lr.ph.i
	mov	x8, x0
	mov	x0, #0                          ; =0x0
	add	x8, x8, #24
	ldr	x10, [x1]
LBB88_2:                                ; %bb2.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x8], #32
	cmp	x10, x11
	b.ls	LBB88_6
; %bb.3:                                ; %bb8.i
                                        ;   in Loop: Header=BB88_2 Depth=1
	add	x0, x0, #1
	cmp	x9, x0
	b.ne	LBB88_2
; %bb.4:
	mov	w1, #1                          ; =0x1
	mov	x0, x9
	ret
LBB88_5:
	mov	x0, #0                          ; =0x0
	mov	w1, #1                          ; =0x1
	ret
LBB88_6:                                ; %bb6.i
	mov	w8, #-7                         ; =0xfffffff9
	csel	w1, w8, wzr, lo
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_insert_item$instance$0ed342445dd803f3 ; -- Begin function wf_std.collections.ordered_map.ordered_map_insert_item$instance$0ed342445dd803f3
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_insert_item$instance$0ed342445dd803f3: ; @"wf_std.collections.ordered_map.ordered_map_insert_item$instance$0ed342445dd803f3"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #1008
	.cfi_def_cfa_offset 1104
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x3
	mov	x19, x0
	mov	x21, x1
	ldr	x22, [x21, #16]!
	cmp	x22, #14
	b.hi	LBB89_2
; %bb.1:                                ; %bb2
	sub	x8, x22, x2
	add	x23, x21, x2, lsl #5
	lsl	x2, x8, #5
	add	x0, x23, #40
	add	x1, x23, #8
	bl	_memmove
	add	x8, x22, #1
	str	x8, [x21]
	ldp	q1, q0, [x20]
	stur	q0, [x23, #24]
	stur	q1, [x23, #8]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	str	xzr, [x19, #32]
	b	LBB89_9
LBB89_2:                                ; %bb3
	add	x8, sp, #488
	add	x9, x8, #232
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x9, #224]
	stp	q0, q0, [x9, #192]
	stp	q0, q0, [x9, #160]
	stp	q0, q0, [x9, #128]
	stp	q0, q0, [x9, #96]
	stp	q0, q0, [x9, #64]
	stp	q0, q0, [x9, #32]
	stur	q0, [x8, #248]
	stur	q0, [x8, #232]
	add	x9, x1, #24
	sub	x10, x22, #1
	add	x11, x9, x10, lsl #5
	str	x10, [x1, #16]
	ldp	q0, q1, [x11]
	add	x10, sp, #241
	stur	q0, [x10, #255]
	add	x10, sp, #257
	stur	q1, [x10, #255]
	sub	x10, x22, #2
	add	x11, x9, x10, lsl #5
	str	x10, [x1, #16]
	ldp	q0, q1, [x11]
	add	x10, sp, #273
	stur	q0, [x10, #255]
	add	x10, sp, #289
	stur	q1, [x10, #255]
	sub	x10, x22, #3
	add	x11, x9, x10, lsl #5
	str	x10, [x1, #16]
	ldp	q0, q1, [x11]
	add	x10, sp, #305
	stur	q0, [x10, #255]
	stur	q1, [x8, #88]
	sub	x10, x22, #4
	add	x11, x9, x10, lsl #5
	str	x10, [x1, #16]
	ldp	q0, q1, [x11]
	stur	q1, [x8, #120]
	stur	q0, [x8, #104]
	sub	x10, x22, #5
	add	x11, x9, x10, lsl #5
	str	x10, [x1, #16]
	ldp	q0, q1, [x11]
	stur	q1, [x8, #152]
	stur	q0, [x8, #136]
	sub	x10, x22, #6
	add	x11, x9, x10, lsl #5
	str	x10, [x1, #16]
	ldp	q0, q1, [x11]
	stur	q1, [x8, #184]
	stur	q0, [x8, #168]
	sub	x23, x22, #7
	add	x9, x9, x23, lsl #5
	str	x23, [x1, #16]
	mov	w10, #7                         ; =0x7
	str	x10, [sp, #488]
	add	x10, sp, #241
	ldur	q0, [x10, #255]
	add	x10, sp, #257
	ldur	q1, [x10, #255]
	stp	q0, q1, [sp, #976]
	ldp	q2, q3, [x9]
	add	x9, sp, #257
	stur	q3, [x9, #255]
	add	x9, sp, #241
	stur	q2, [x9, #255]
	stur	q1, [x8, #216]
	stur	q0, [x8, #200]
	add	x9, sp, #273
	ldur	q0, [x9, #255]
	add	x9, sp, #289
	ldur	q1, [x9, #255]
	stp	q0, q1, [sp, #976]
	ldur	q2, [x8, #168]
	ldur	q3, [x8, #184]
	stur	q3, [x9, #255]
	add	x9, sp, #273
	stur	q2, [x9, #255]
	stur	q1, [x8, #184]
	stur	q0, [x8, #168]
	add	x9, sp, #305
	ldur	q0, [x9, #255]
	ldur	q1, [x8, #88]
	stp	q0, q1, [sp, #976]
	ldur	q2, [x8, #136]
	ldur	q3, [x8, #152]
	stur	q3, [x8, #88]
	stur	q2, [x9, #255]
	stur	q1, [x8, #152]
	stur	q0, [x8, #136]
	sub	x8, x22, #8
	add	x9, x21, x8, lsl #5
	str	x8, [x1, #16]
	ldur	q0, [x9, #8]
	str	q0, [sp, #464]
	ldp	x22, x9, [x9, #24]
	str	x9, [sp, #456]
	cmp	x2, #8
	b.hs	LBB89_5
; %bb.3:                                ; %bb15
	sub	x8, x8, x2
	add	x24, x21, x2, lsl #5
	lsl	x2, x8, #5
	add	x0, x24, #40
	add	x1, x24, #8
	bl	_memmove
	str	x23, [x21]
	ldp	q0, q1, [x20]
	stur	q0, [x24, #8]
	stur	q1, [x24, #24]
	str	xzr, [sp, #448]
	cbz	x22, LBB89_6
LBB89_4:                                ; %run.move.body.v3.preheader.i
	lsl	x2, x22, #3
	add	x0, sp, #448
	add	x1, sp, #456
	bl	_memcpy
	ldr	x8, [sp, #448]
	str	x8, [sp, #168]                  ; 8-byte Folded Spill
	b	LBB89_7
LBB89_5:                                ; %bb16
	lsl	x8, x2, #5
	add	x9, sp, #488
	add	x21, x9, x8
	sub	x1, x21, #248
	sub	x0, x21, #216
	mov	w9, #480                        ; =0x1e0
	sub	x2, x9, x8
	bl	_memmove
	mov	w8, #8                          ; =0x8
	str	x8, [sp, #488]
	ldp	q1, q0, [x20]
	stur	q0, [x21, #-232]
	stur	q1, [x21, #-248]
	str	xzr, [sp, #448]
	cbnz	x22, LBB89_4
LBB89_6:
	str	xzr, [sp, #168]                 ; 8-byte Folded Spill
LBB89_7:                                ; %"wf_append$instance$48c61fa9751a6936.exit"
	add	x8, sp, #249
	ldur	q0, [x8, #255]
	str	q0, [sp, #432]                  ; 16-byte Folded Spill
	add	x8, sp, #233
	ldur	q0, [x8, #255]
	str	q0, [sp, #176]                  ; 16-byte Folded Spill
	ldr	x21, [sp, #520]
	ldr	x23, [sp, #528]
	ldr	x24, [sp, #536]
	ldr	x25, [sp, #544]
	ldr	x26, [sp, #552]
	ldr	x27, [sp, #560]
	ldr	x28, [sp, #568]
	ldr	x20, [sp, #576]
	ldr	x9, [sp, #584]
	ldr	x8, [sp, #592]
	stp	x8, x9, [sp, #152]              ; 16-byte Folded Spill
	ldr	x9, [sp, #600]
	ldr	x8, [sp, #608]
	stp	x8, x9, [sp, #136]              ; 16-byte Folded Spill
	ldr	x9, [sp, #616]
	ldr	x8, [sp, #624]
	stp	x8, x9, [sp, #120]              ; 16-byte Folded Spill
	ldr	x9, [sp, #632]
	ldr	x8, [sp, #640]
	stp	x8, x9, [sp, #104]              ; 16-byte Folded Spill
	ldr	x9, [sp, #648]
	ldr	x8, [sp, #656]
	stp	x8, x9, [sp, #88]               ; 16-byte Folded Spill
	ldr	x9, [sp, #664]
	ldr	x8, [sp, #672]
	stp	x8, x9, [sp, #72]               ; 16-byte Folded Spill
	ldr	x9, [sp, #680]
	ldr	x8, [sp, #688]
	stp	x8, x9, [sp, #56]               ; 16-byte Folded Spill
	ldr	x9, [sp, #696]
	ldr	x8, [sp, #704]
	stp	x8, x9, [sp, #40]               ; 16-byte Folded Spill
	ldr	x9, [sp, #712]
	ldr	x8, [sp, #720]
	stp	x8, x9, [sp, #24]               ; 16-byte Folded Spill
	ldr	x9, [sp, #728]
	ldr	x8, [sp, #736]
	stp	x8, x9, [sp, #8]                ; 16-byte Folded Spill
	ldr	x9, [sp, #744]
	ldr	x8, [sp, #752]
	stp	x8, x9, [sp, #416]              ; 16-byte Folded Spill
	ldr	x9, [sp, #760]
	ldr	x8, [sp, #768]
	stp	x8, x9, [sp, #400]              ; 16-byte Folded Spill
	ldr	x9, [sp, #776]
	ldr	x8, [sp, #784]
	stp	x8, x9, [sp, #384]              ; 16-byte Folded Spill
	ldr	x9, [sp, #792]
	ldr	x8, [sp, #800]
	stp	x8, x9, [sp, #368]              ; 16-byte Folded Spill
	ldr	x9, [sp, #808]
	ldr	x8, [sp, #816]
	stp	x8, x9, [sp, #352]              ; 16-byte Folded Spill
	ldr	x9, [sp, #824]
	ldr	x8, [sp, #832]
	stp	x8, x9, [sp, #336]              ; 16-byte Folded Spill
	ldr	x9, [sp, #840]
	ldr	x8, [sp, #848]
	stp	x8, x9, [sp, #320]              ; 16-byte Folded Spill
	ldr	x9, [sp, #856]
	ldr	x8, [sp, #864]
	stp	x8, x9, [sp, #304]              ; 16-byte Folded Spill
	ldr	x9, [sp, #872]
	ldr	x8, [sp, #880]
	stp	x8, x9, [sp, #288]              ; 16-byte Folded Spill
	ldr	x9, [sp, #888]
	ldr	x8, [sp, #896]
	stp	x8, x9, [sp, #272]              ; 16-byte Folded Spill
	ldr	x9, [sp, #904]
	ldr	x8, [sp, #912]
	stp	x8, x9, [sp, #256]              ; 16-byte Folded Spill
	ldr	x9, [sp, #920]
	ldr	x8, [sp, #928]
	stp	x8, x9, [sp, #240]              ; 16-byte Folded Spill
	ldr	x9, [sp, #936]
	ldr	x8, [sp, #944]
	stp	x8, x9, [sp, #224]              ; 16-byte Folded Spill
	ldr	x9, [sp, #952]
	ldr	x8, [sp, #960]
	stp	x8, x9, [sp, #208]              ; 16-byte Folded Spill
	ldr	x8, [sp, #968]
	str	x8, [sp, #200]                  ; 8-byte Folded Spill
	mov	w0, #504                        ; =0x1f8
	bl	_malloc
	cbz	x0, LBB89_10
; %bb.8:                                ; %"wf_box_new$instance$dc0681021cdc805e.exit"
	ldp	x10, x9, [sp, #160]             ; 16-byte Folded Reload
	stp	x22, x9, [x0]
	stp	x21, x23, [x0, #48]
	stp	x24, x25, [x0, #64]
	stp	x26, x27, [x0, #80]
	stp	x28, x20, [x0, #96]
	ldp	x11, x9, [sp, #144]             ; 16-byte Folded Reload
	stp	x10, x9, [x0, #112]
	ldp	x10, x9, [sp, #128]             ; 16-byte Folded Reload
	stp	x11, x9, [x0, #128]
	ldp	x11, x9, [sp, #112]             ; 16-byte Folded Reload
	stp	x10, x9, [x0, #144]
	ldp	x10, x9, [sp, #96]              ; 16-byte Folded Reload
	stp	x11, x9, [x0, #160]
	ldp	x11, x9, [sp, #80]              ; 16-byte Folded Reload
	stp	x10, x9, [x0, #176]
	ldp	x10, x9, [sp, #64]              ; 16-byte Folded Reload
	stp	x11, x9, [x0, #192]
	ldp	x11, x9, [sp, #48]              ; 16-byte Folded Reload
	stp	x10, x9, [x0, #208]
	ldp	x10, x9, [sp, #32]              ; 16-byte Folded Reload
	stp	x11, x9, [x0, #224]
	ldp	x11, x9, [sp, #16]              ; 16-byte Folded Reload
	stp	x10, x9, [x0, #240]
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	stp	x11, x8, [x0, #256]
	ldr	q1, [sp, #176]                  ; 16-byte Folded Reload
	ldr	q0, [sp, #432]                  ; 16-byte Folded Reload
	stp	q1, q0, [x0, #16]
	ldp	x8, x9, [sp, #416]              ; 16-byte Folded Reload
	stp	x9, x8, [x0, #272]
	ldp	x8, x9, [sp, #400]              ; 16-byte Folded Reload
	stp	x9, x8, [x0, #288]
	ldp	x8, x9, [sp, #384]              ; 16-byte Folded Reload
	stp	x9, x8, [x0, #304]
	ldp	x8, x9, [sp, #368]              ; 16-byte Folded Reload
	stp	x9, x8, [x0, #320]
	ldp	x8, x9, [sp, #352]              ; 16-byte Folded Reload
	stp	x9, x8, [x0, #336]
	ldp	x8, x9, [sp, #336]              ; 16-byte Folded Reload
	stp	x9, x8, [x0, #352]
	ldp	x8, x9, [sp, #320]              ; 16-byte Folded Reload
	stp	x9, x8, [x0, #368]
	ldp	x8, x9, [sp, #304]              ; 16-byte Folded Reload
	stp	x9, x8, [x0, #384]
	ldp	x8, x9, [sp, #288]              ; 16-byte Folded Reload
	stp	x9, x8, [x0, #400]
	ldp	x8, x9, [sp, #272]              ; 16-byte Folded Reload
	stp	x9, x8, [x0, #416]
	ldp	x8, x9, [sp, #256]              ; 16-byte Folded Reload
	stp	x9, x8, [x0, #432]
	ldp	x8, x9, [sp, #240]              ; 16-byte Folded Reload
	stp	x9, x8, [x0, #448]
	ldp	x8, x9, [sp, #224]              ; 16-byte Folded Reload
	stp	x9, x8, [x0, #464]
	ldp	x8, x9, [sp, #208]              ; 16-byte Folded Reload
	stp	x9, x8, [x0, #480]
	ldr	x8, [sp, #200]                  ; 8-byte Folded Reload
	str	x8, [x0, #496]
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	ldr	q0, [sp, #464]
	stur	q0, [x19, #8]
	stp	x8, x0, [x19, #24]
LBB89_9:                                ; %bb2
	add	sp, sp, #1008
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB89_10:                               ; %box.new.oom.v1.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_remove_item$instance$0ed342445dd803f3 ; -- Begin function wf_std.collections.ordered_map.ordered_map_remove_item$instance$0ed342445dd803f3
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_remove_item$instance$0ed342445dd803f3: ; @"wf_std.collections.ordered_map.ordered_map_remove_item$instance$0ed342445dd803f3"
; %bb.0:                                ; %entry
	sub	sp, sp, #80
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	mov	x19, x1
	mov	x20, x0
	mov	x21, x0
	ldr	x22, [x21, #16]!
	add	x8, x21, x1, lsl #5
	ldur	q0, [x8, #8]
	ldur	q1, [x8, #24]
	stp	q0, q1, [sp]
	mvn	x9, x1
	add	x9, x22, x9
	lsl	x2, x9, #5
	add	x0, x8, #8
	add	x1, x8, #40
	bl	_memmove
	sub	x8, x22, #1
	str	x8, [x21]
	mov	x2, sp
	mov	x0, x20
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_finish_remove$instance$0ed342445dd803f3
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_repair_child$instance$0ed342445dd803f3 ; -- Begin function wf_std.collections.ordered_map.ordered_map_repair_child$instance$0ed342445dd803f3
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_repair_child$instance$0ed342445dd803f3: ; @"wf_std.collections.ordered_map.ordered_map_repair_child$instance$0ed342445dd803f3"
; %bb.0:                                ; %entry
	sub	sp, sp, #144
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	mov	x21, x0
	ldr	x22, [x21, #16]!
	cbz	x22, LBB91_10
; %bb.1:                                ; %bb3
	cbz	x1, LBB91_6
; %bb.2:                                ; %bb6
	sub	x23, x1, #1
	add	x20, x21, x23, lsl #5
	ldr	x8, [x20, #24]
	cbz	x8, LBB91_10
; %bb.3:                                ; %bb14
	ldr	x8, [x20, #32]
	ldr	x8, [x8, #16]
	cmp	x8, #6
	b.hi	LBB91_10
; %bb.4:                                ; %bb17
	ldur	q0, [x20, #8]
	ldur	q1, [x20, #24]
	stp	q0, q1, [sp, #48]
	sub	x8, x22, x1
	lsl	x19, x8, #5
	mov	x24, x0
	add	x0, x20, #8
	add	x1, x20, #40
	mov	x2, x19
	bl	_memmove
	sub	x8, x22, #1
	str	x8, [x24, #16]
	sub	x8, x20, #8
	cmp	x23, #0
	csel	x1, x24, x8, eq
	add	x0, sp, #8
	add	x2, sp, #48
	bl	_wf_std.collections.ordered_map.ordered_map_repair_separator$instance$0ed342445dd803f3
	ldr	w8, [sp, #8]
	cbz	w8, LBB91_10
; %bb.5:                                ; %bb6.i18
	add	x0, x20, #40
	add	x1, x20, #8
	mov	x2, x19
	bl	_memmove
	str	x22, [x21]
	ldp	q0, q1, [sp, #16]
	stur	q1, [x20, #24]
	stur	q0, [x20, #8]
	b	LBB91_10
LBB91_6:                                ; %bb5
	ldr	x8, [x0]
	cbz	x8, LBB91_10
; %bb.7:                                ; %bb8
	ldr	x8, [x0, #8]
	ldr	x8, [x8, #16]
	cmp	x8, #6
	b.hi	LBB91_10
; %bb.8:                                ; %bb11
	ldur	q0, [x0, #24]
	ldur	q1, [x0, #40]
	stp	q0, q1, [sp, #48]
	sub	x23, x22, #1
	lsl	x19, x23, #5
	mov	x20, x0
	add	x0, x0, #24
	add	x1, x20, #56
	mov	x2, x19
	bl	_memmove
	str	x23, [x20, #16]
	add	x0, sp, #8
	add	x2, sp, #48
	mov	x23, x20
	mov	x1, x20
	bl	_wf_std.collections.ordered_map.ordered_map_repair_separator$instance$0ed342445dd803f3
	ldr	w8, [sp, #8]
	cbz	w8, LBB91_10
; %bb.9:                                ; %bb6.i
	add	x0, x23, #56
	add	x1, x23, #24
	mov	x2, x19
	bl	_memmove
	str	x22, [x21]
	ldp	q1, q0, [sp, #16]
	stur	q1, [x23, #24]
	stur	q0, [x23, #40]
LBB91_10:                               ; %common.ret
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_search_result$instance$43c0c30766ba2e8b ; -- Begin function wf_std.collections.ordered_map.ordered_map_search_result$instance$43c0c30766ba2e8b
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_search_result$instance$43c0c30766ba2e8b: ; @"wf_std.collections.ordered_map.ordered_map_search_result$instance$43c0c30766ba2e8b"
; %bb.0:                                ; %entry
	ldr	x9, [x0, #16]
	cbz	x9, LBB92_5
; %bb.1:                                ; %bb2.lr.ph.i
	mov	x8, x0
	mov	x0, #0                          ; =0x0
	add	x8, x8, #24
	ldr	x10, [x1]
LBB92_2:                                ; %bb2.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x8]
	cmp	x10, x11
	b.ls	LBB92_6
; %bb.3:                                ; %bb8.i
                                        ;   in Loop: Header=BB92_2 Depth=1
	add	x8, x8, #280
	add	x0, x0, #1
	cmp	x9, x0
	b.ne	LBB92_2
; %bb.4:
	mov	w1, #1                          ; =0x1
	mov	x0, x9
	ret
LBB92_5:
	mov	x0, #0                          ; =0x0
	mov	w1, #1                          ; =0x1
	ret
LBB92_6:                                ; %bb6.i
	mov	w8, #-7                         ; =0xfffffff9
	csel	w1, w8, wzr, lo
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_insert_item$instance$d883f474bea0047c ; -- Begin function wf_std.collections.ordered_map.ordered_map_insert_item$instance$d883f474bea0047c
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_insert_item$instance$d883f474bea0047c: ; @"wf_std.collections.ordered_map.ordered_map_insert_item$instance$d883f474bea0047c"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	mov	w9, #8960                       ; =0x2300
Lloh62:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh63:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #2, lsl #12             ; =8192
	sub	sp, sp, #768
	.cfi_def_cfa_offset 9056
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x21, x3
	mov	x24, x2
	mov	x19, x0
	mov	x27, x1
	ldr	x28, [x27, #16]!
	cmp	x28, #14
	b.hi	LBB93_2
; %bb.1:                                ; %bb2
	sub	x8, x28, x24
	mov	w9, #280                        ; =0x118
	madd	x20, x24, x9, x27
	mul	x2, x8, x9
	add	x0, x20, #288
	add	x1, x20, #8
	bl	_memmove
	add	x8, x28, #1
	str	x8, [x27]
	add	x0, x20, #8
	mov	x1, x21
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	stp	q0, q0, [x19, #32]
	stp	q0, q0, [x19, #64]
	stp	q0, q0, [x19, #96]
	stp	q0, q0, [x19, #128]
	stp	q0, q0, [x19, #160]
	stp	q0, q0, [x19, #192]
	stp	q0, q0, [x19, #224]
	stp	q0, q0, [x19, #256]
	b	LBB93_11
LBB93_2:                                ; %bb3
	mov	x25, x1
	str	x21, [sp, #4160]                ; 8-byte Folded Spill
	add	x22, sp, #1, lsl #12            ; =4096
	add	x22, x22, #376
	add	x20, x22, #568
	add	x0, x20, #1400
	str	x0, [sp, #4176]                 ; 8-byte Folded Spill
	mov	w1, #2240                       ; =0x8c0
	bl	_bzero
	mov	w8, #280                        ; =0x118
	mul	x21, x28, x8
	add	x26, x25, x21
	sub	x8, x28, #1
	sub	x1, x26, #256
	str	x8, [x25, #16]
	add	x0, x22, #8
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	sub	x8, x28, #2
	sub	x1, x26, #536
	str	x8, [x25, #16]
	add	x0, x22, #288
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	sub	x8, x28, #3
	sub	x1, x26, #816
	str	x8, [x25, #16]
	mov	x0, x20
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	sub	x8, x28, #4
	sub	x1, x26, #1096
	str	x8, [x25, #16]
	add	x0, x20, #280
	str	x0, [sp, #4168]                 ; 8-byte Folded Spill
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	sub	x8, x28, #5
	sub	x1, x26, #1376
	str	x8, [x25, #16]
	add	x0, x20, #560
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	sub	x8, x28, #6
	sub	x1, x26, #1656
	str	x8, [x25, #16]
	add	x0, x22, #1408
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	sub	x23, x28, #7
	sub	x26, x26, #1936
	str	x23, [x25, #16]
	mov	w8, #7                          ; =0x7
	str	x8, [sp, #4472]
	add	x0, sp, #2, lsl #12             ; =8192
	add	x0, x0, #488
	add	x1, x22, #8
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	add	x0, x22, #8
	mov	x1, x26
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	add	x0, x20, #1120
	add	x1, sp, #2, lsl #12             ; =8192
	add	x1, x1, #488
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	add	x0, sp, #2, lsl #12             ; =8192
	add	x0, x0, #488
	add	x1, x22, #288
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	add	x0, x22, #288
	add	x1, x22, #1408
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	add	x0, x22, #1408
	add	x1, sp, #2, lsl #12             ; =8192
	add	x1, x1, #488
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	add	x0, sp, #2, lsl #12             ; =8192
	add	x0, x0, #488
	mov	x1, x20
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	add	x1, x20, #560
	mov	x0, x20
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	add	x0, x20, #560
	add	x1, sp, #2, lsl #12             ; =8192
	add	x1, x1, #488
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	sub	x22, x28, #8
	add	x8, x21, x27
	sub	x1, x8, #2232
	str	x22, [x25, #16]
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #96
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	cmp	x24, #8
	b.hs	LBB93_4
; %bb.3:                                ; %bb15
	sub	x8, x22, x24
	mov	w9, #280                        ; =0x118
	madd	x21, x24, x9, x27
	mul	x2, x8, x9
	add	x0, x21, #288
	add	x1, x21, #8
	bl	_memmove
	str	x23, [x27]
	add	x0, x21, #8
	b	LBB93_5
LBB93_4:                                ; %bb16
	mov	w8, #280                        ; =0x118
	mov	w9, #15                         ; =0xf
	sub	x9, x9, x24
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #376
	madd	x10, x24, x8, x10
	sub	x24, x10, #2232
	sub	x0, x10, #1952
	mul	x2, x9, x8
	mov	x1, x24
	bl	_memmove
	mov	w8, #8                          ; =0x8
	str	x8, [sp, #4472]
	mov	x0, x24
LBB93_5:                                ; %bb14
	ldr	x1, [sp, #4160]                 ; 8-byte Folded Reload
	mov	w2, #280                        ; =0x118
	bl	_memcpy
; %bb.6:                                ; %bb14
	str	xzr, [sp, #4184]
	ldr	x27, [sp, #4456]
	cbz	x27, LBB93_8
; %bb.7:                                ; %run.move.body.v3.preheader.i
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #96
	lsl	x2, x27, #3
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #88
	add	x1, x8, #272
	bl	_memcpy
	ldr	x8, [sp, #4184]
	str	x8, [sp, #3944]                 ; 8-byte Folded Spill
	b	LBB93_9
LBB93_8:
	str	xzr, [sp, #3944]                ; 8-byte Folded Spill
LBB93_9:                                ; %"wf_append$instance$42f33d80f30f592c.exit"
	str	xzr, [sp, #4456]
	ldr	x8, [sp, #4728]
	str	x8, [sp, #3936]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #4736]
	str	x8, [sp, #3928]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #4744]
	str	x8, [sp, #3920]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #4752]
	str	x8, [sp, #3912]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5016]
	str	x8, [sp, #3640]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5024]
	str	x8, [sp, #3632]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5032]
	str	x8, [sp, #3624]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5296]
	str	x8, [sp, #3616]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5304]
	str	x8, [sp, #3608]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #5312]
	str	x8, [sp, #3600]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #4168]                 ; 8-byte Folded Reload
	ldp	q0, q1, [x8]
	str	q1, [sp, #3088]                 ; 16-byte Folded Spill
	str	q0, [sp, #3104]                 ; 16-byte Folded Spill
	add	x8, x20, #312
	ldp	q0, q1, [x8]
	str	q1, [sp, #3024]                 ; 16-byte Folded Spill
	str	q0, [sp, #3040]                 ; 16-byte Folded Spill
	add	x8, x20, #344
	ldp	q0, q1, [x8]
	str	q1, [sp, #2992]                 ; 16-byte Folded Spill
	str	q0, [sp, #3008]                 ; 16-byte Folded Spill
	add	x8, x20, #376
	ldp	q0, q1, [x8]
	str	q1, [sp, #2960]                 ; 16-byte Folded Spill
	str	q0, [sp, #2976]                 ; 16-byte Folded Spill
	add	x8, x20, #408
	ldp	q0, q1, [x8]
	str	q1, [sp, #2928]                 ; 16-byte Folded Spill
	str	q0, [sp, #2944]                 ; 16-byte Folded Spill
	add	x8, x20, #440
	ldp	q0, q1, [x8]
	str	q1, [sp, #2896]                 ; 16-byte Folded Spill
	str	q0, [sp, #2912]                 ; 16-byte Folded Spill
	add	x8, x20, #472
	ldp	q0, q1, [x8]
	str	q1, [sp, #2864]                 ; 16-byte Folded Spill
	str	q0, [sp, #2880]                 ; 16-byte Folded Spill
	add	x8, x20, #504
	ldp	q0, q1, [x8]
	str	q1, [sp, #2832]                 ; 16-byte Folded Spill
	str	q0, [sp, #2848]                 ; 16-byte Folded Spill
	ldr	x22, [sp, #5576]
	ldr	x24, [sp, #5584]
	ldr	x25, [sp, #5592]
	ldr	x23, [sp, #5856]
	ldr	x26, [sp, #5864]
	ldr	x28, [sp, #5872]
	ldr	x8, [sp, #6136]
	str	x8, [sp, #4160]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6144]
	str	x8, [sp, #4152]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6152]
	str	x8, [sp, #4168]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6416]
	str	x8, [sp, #4144]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6424]
	str	x8, [sp, #4136]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6432]
	str	x8, [sp, #4128]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #4176]                 ; 8-byte Folded Reload
	ldp	q0, q1, [x8]
	str	q1, [sp, #2032]                 ; 16-byte Folded Spill
	str	q0, [sp, #2048]                 ; 16-byte Folded Spill
	add	x8, x20, #1432
	ldp	q0, q1, [x8]
	str	q1, [sp, #2000]                 ; 16-byte Folded Spill
	str	q0, [sp, #2016]                 ; 16-byte Folded Spill
	add	x8, x20, #1464
	ldp	q0, q1, [x8]
	str	q1, [sp, #1968]                 ; 16-byte Folded Spill
	str	q0, [sp, #1984]                 ; 16-byte Folded Spill
	add	x8, x20, #1496
	ldp	q0, q1, [x8]
	str	q1, [sp, #1936]                 ; 16-byte Folded Spill
	str	q0, [sp, #1952]                 ; 16-byte Folded Spill
	add	x8, x20, #1528
	ldp	q0, q1, [x8]
	str	q1, [sp, #1904]                 ; 16-byte Folded Spill
	str	q0, [sp, #1920]                 ; 16-byte Folded Spill
	add	x8, x20, #1560
	ldp	q0, q1, [x8]
	str	q1, [sp, #1872]                 ; 16-byte Folded Spill
	str	q0, [sp, #1888]                 ; 16-byte Folded Spill
	add	x8, x20, #1592
	ldp	q0, q1, [x8]
	str	q1, [sp, #1840]                 ; 16-byte Folded Spill
	str	q0, [sp, #1856]                 ; 16-byte Folded Spill
	add	x8, x20, #1624
	ldp	q0, q1, [x8]
	str	q1, [sp, #1808]                 ; 16-byte Folded Spill
	str	q0, [sp, #1824]                 ; 16-byte Folded Spill
	ldr	x8, [sp, #6696]
	str	x8, [sp, #4176]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6704]
	str	x8, [sp, #4120]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6712]
	str	x8, [sp, #4112]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6976]
	str	x8, [sp, #4104]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6984]
	str	x8, [sp, #4096]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #6992]
	str	x8, [sp, #4088]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7256]
	str	x8, [sp, #4080]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7264]
	str	x8, [sp, #4072]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7272]
	str	x8, [sp, #4064]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7536]
	str	x8, [sp, #4056]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7544]
	str	x8, [sp, #4048]                 ; 8-byte Folded Spill
	ldr	x8, [sp, #7552]
	str	x8, [sp, #4040]                 ; 8-byte Folded Spill
	add	x8, x20, #2520
	add	x9, x20, #2552
	add	x10, x20, #2584
	add	x11, x20, #2616
	add	x12, x20, #2648
	add	x13, x20, #2680
	add	x14, x20, #2712
	add	x15, x20, #2744
	ldr	x16, [sp, #7816]
	str	x16, [sp, #4024]                ; 8-byte Folded Spill
	ldr	x16, [sp, #7824]
	str	x16, [sp, #4016]                ; 8-byte Folded Spill
	ldr	x16, [sp, #7832]
	str	x16, [sp, #4008]                ; 8-byte Folded Spill
	ldr	x16, [sp, #8096]
	str	x16, [sp, #3984]                ; 8-byte Folded Spill
	ldr	x16, [sp, #8104]
	str	x16, [sp, #3976]                ; 8-byte Folded Spill
	ldr	x16, [sp, #8112]
	str	x16, [sp, #3968]                ; 8-byte Folded Spill
	ldr	x21, [sp, #8376]
	ldr	x16, [sp, #8384]
	str	x16, [sp, #3960]                ; 8-byte Folded Spill
	ldr	x16, [sp, #8392]
	str	x16, [sp, #3952]                ; 8-byte Folded Spill
	ldr	x16, [sp, #8656]
	str	x16, [sp, #4000]                ; 8-byte Folded Spill
	ldr	x16, [sp, #8664]
	str	x16, [sp, #3992]                ; 8-byte Folded Spill
	ldr	x16, [sp, #8672]
	str	x16, [sp, #4032]                ; 8-byte Folded Spill
	ldp	q0, q1, [x8]
	str	q1, [sp, #1264]                 ; 16-byte Folded Spill
	str	q0, [sp, #1280]                 ; 16-byte Folded Spill
	ldp	q0, q1, [x9]
	str	q1, [sp, #1232]                 ; 16-byte Folded Spill
	str	q0, [sp, #1248]                 ; 16-byte Folded Spill
	ldp	q0, q1, [x10]
	str	q1, [sp, #1200]                 ; 16-byte Folded Spill
	str	q0, [sp, #1216]                 ; 16-byte Folded Spill
	ldp	q0, q1, [x11]
	str	q1, [sp, #1168]                 ; 16-byte Folded Spill
	str	q0, [sp, #1184]                 ; 16-byte Folded Spill
	ldp	q0, q1, [x12]
	str	q1, [sp, #1136]                 ; 16-byte Folded Spill
	str	q0, [sp, #1152]                 ; 16-byte Folded Spill
	ldp	q0, q1, [x13]
	str	q1, [sp, #1104]                 ; 16-byte Folded Spill
	str	q0, [sp, #1120]                 ; 16-byte Folded Spill
	ldp	q0, q1, [x14]
	str	q1, [sp, #1072]                 ; 16-byte Folded Spill
	str	q0, [sp, #1088]                 ; 16-byte Folded Spill
	ldp	q0, q1, [x15]
	str	q1, [sp, #1040]                 ; 16-byte Folded Spill
	str	q0, [sp, #1056]                 ; 16-byte Folded Spill
	ldp	q0, q1, [x20]
	str	q1, [sp, #1344]                 ; 16-byte Folded Spill
	str	q0, [sp, #1296]                 ; 16-byte Folded Spill
	ldp	q0, q1, [x20, #32]
	str	q1, [sp, #1376]                 ; 16-byte Folded Spill
	str	q0, [sp, #1312]                 ; 16-byte Folded Spill
	ldp	q0, q1, [x20, #64]
	str	q1, [sp, #1408]                 ; 16-byte Folded Spill
	str	q0, [sp, #1328]                 ; 16-byte Folded Spill
	ldp	q0, q1, [x20, #96]
	str	q1, [sp, #1440]                 ; 16-byte Folded Spill
	str	q0, [sp, #1360]                 ; 16-byte Folded Spill
	ldp	q0, q1, [x20, #128]
	str	q1, [sp, #1472]                 ; 16-byte Folded Spill
	str	q0, [sp, #1392]                 ; 16-byte Folded Spill
	ldp	q0, q1, [x20, #160]
	str	q1, [sp, #1504]                 ; 16-byte Folded Spill
	str	q0, [sp, #1424]                 ; 16-byte Folded Spill
	ldp	q0, q1, [x20, #192]
	str	q1, [sp, #1520]                 ; 16-byte Folded Spill
	str	q0, [sp, #1456]                 ; 16-byte Folded Spill
	ldp	q0, q1, [x20, #224]
	str	q1, [sp, #1536]                 ; 16-byte Folded Spill
	str	q0, [sp, #1488]                 ; 16-byte Folded Spill
	ldp	q0, q1, [x20, #560]
	str	q1, [sp, #1552]                 ; 16-byte Folded Spill
	str	q0, [sp, #1568]                 ; 16-byte Folded Spill
	ldp	q0, q1, [x20, #592]
	str	q1, [sp, #1584]                 ; 16-byte Folded Spill
	str	q0, [sp, #1600]                 ; 16-byte Folded Spill
	ldp	q0, q1, [x20, #624]
	str	q1, [sp, #1616]                 ; 16-byte Folded Spill
	str	q0, [sp, #1632]                 ; 16-byte Folded Spill
	ldp	q0, q1, [x20, #656]
	str	q1, [sp, #1648]                 ; 16-byte Folded Spill
	str	q0, [sp, #1664]                 ; 16-byte Folded Spill
	ldp	q0, q1, [x20, #688]
	str	q1, [sp, #1680]                 ; 16-byte Folded Spill
	str	q0, [sp, #1696]                 ; 16-byte Folded Spill
	ldp	q0, q1, [x20, #720]
	str	q1, [sp, #1712]                 ; 16-byte Folded Spill
	str	q0, [sp, #1728]                 ; 16-byte Folded Spill
	ldp	q0, q1, [x20, #752]
	str	q1, [sp, #1744]                 ; 16-byte Folded Spill
	str	q0, [sp, #1760]                 ; 16-byte Folded Spill
	ldp	q0, q1, [x20, #784]
	str	q1, [sp, #1776]                 ; 16-byte Folded Spill
	str	q0, [sp, #1792]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1136]
	str	q0, [sp, #2064]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1120]
	str	q0, [sp, #2080]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1168]
	str	q0, [sp, #2096]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1152]
	str	q0, [sp, #2112]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1200]
	str	q0, [sp, #2128]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1184]
	str	q0, [sp, #2144]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1232]
	str	q0, [sp, #2160]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1216]
	str	q0, [sp, #2176]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1264]
	str	q0, [sp, #2192]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1248]
	str	q0, [sp, #2208]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1296]
	str	q0, [sp, #2224]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1280]
	str	q0, [sp, #2240]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1328]
	str	q0, [sp, #2256]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1312]
	str	q0, [sp, #2272]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1360]
	str	q0, [sp, #2288]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1344]
	str	q0, [sp, #2304]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1696]
	str	q0, [sp, #2320]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1680]
	str	q0, [sp, #2336]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1728]
	str	q0, [sp, #2352]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1712]
	str	q0, [sp, #2368]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1760]
	str	q0, [sp, #2384]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1744]
	str	q0, [sp, #2400]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1792]
	str	q0, [sp, #2416]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1776]
	str	q0, [sp, #2432]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1824]
	str	q0, [sp, #2448]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1808]
	str	q0, [sp, #2464]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1856]
	str	q0, [sp, #2480]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1840]
	str	q0, [sp, #2496]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1888]
	str	q0, [sp, #2512]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1872]
	str	q0, [sp, #2528]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1920]
	str	q0, [sp, #2544]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #1904]
	str	q0, [sp, #2560]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2256]
	str	q0, [sp, #3056]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2240]
	str	q0, [sp, #3072]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2288]
	str	q0, [sp, #3120]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2272]
	str	q0, [sp, #3136]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2320]
	str	q0, [sp, #3152]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2304]
	str	q0, [sp, #3168]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2352]
	str	q0, [sp, #3184]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2336]
	str	q0, [sp, #3200]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2384]
	str	q0, [sp, #3216]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2368]
	str	q0, [sp, #3232]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2416]
	str	q0, [sp, #3248]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2400]
	str	q0, [sp, #3264]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2448]
	str	q0, [sp, #3280]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2432]
	str	q0, [sp, #3296]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2480]
	str	q0, [sp, #3312]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2464]
	str	q0, [sp, #3328]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2816]
	str	q0, [sp, #3344]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2800]
	str	q0, [sp, #3360]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2848]
	str	q0, [sp, #3376]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2832]
	str	q0, [sp, #3392]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2880]
	str	q0, [sp, #3408]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2864]
	str	q0, [sp, #3424]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2912]
	str	q0, [sp, #3440]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2896]
	str	q0, [sp, #3456]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2944]
	str	q0, [sp, #3472]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2928]
	str	q0, [sp, #3488]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2976]
	str	q0, [sp, #3504]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2960]
	str	q0, [sp, #3520]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #3008]
	str	q0, [sp, #3536]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #2992]
	str	q0, [sp, #3552]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #3040]
	str	q0, [sp, #3568]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #3024]
	str	q0, [sp, #3584]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #3376]
	str	q0, [sp, #3648]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #3360]
	str	q0, [sp, #3664]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #3408]
	str	q0, [sp, #3680]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #3392]
	str	q0, [sp, #3696]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #3440]
	str	q0, [sp, #3712]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #3424]
	str	q0, [sp, #3728]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #3472]
	str	q0, [sp, #3744]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #3456]
	str	q0, [sp, #3760]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #3504]
	str	q0, [sp, #3776]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #3488]
	str	q0, [sp, #3792]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #3536]
	str	q0, [sp, #3808]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #3520]
	str	q0, [sp, #3824]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #3568]
	str	q0, [sp, #3840]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #3552]
	str	q0, [sp, #3856]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #3600]
	str	q0, [sp, #3872]                 ; 16-byte Folded Spill
	ldr	q0, [x20, #3584]
	str	q0, [sp, #3888]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #137
	ldur	q1, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #121
	ldur	q2, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #169
	ldur	q0, [x8, #255]
	stp	q0, q1, [sp, #240]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #153
	ldur	q0, [x8, #255]
	stp	q0, q2, [sp, #112]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #201
	ldur	q1, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #185
	ldur	q2, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #233
	ldur	q0, [x8, #255]
	stp	q0, q1, [sp, #208]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #217
	ldur	q0, [x8, #255]
	stp	q0, q2, [sp, #80]               ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #265
	ldur	q1, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #249
	ldur	q2, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #297
	ldur	q0, [x8, #255]
	stp	q0, q1, [sp, #176]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #281
	ldur	q0, [x8, #255]
	stp	q0, q2, [sp, #48]               ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #329
	ldur	q1, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #313
	ldur	q2, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #361
	ldur	q0, [x8, #255]
	stp	q0, q1, [sp, #144]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #345
	ldur	q0, [x8, #255]
	stp	q0, q2, [sp, #16]               ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #425
	ldur	q1, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #409
	ldur	q2, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #457
	ldur	q0, [x8, #255]
	stp	q0, q1, [sp, #1008]             ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #441
	ldur	q0, [x8, #255]
	stp	q0, q2, [sp, #368]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #489
	ldur	q1, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #473
	ldur	q2, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #521
	ldur	q0, [x8, #255]
	stp	q0, q1, [sp, #976]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #505
	ldur	q0, [x8, #255]
	stp	q0, q2, [sp, #336]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #553
	ldur	q1, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #537
	ldur	q2, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #585
	ldur	q0, [x8, #255]
	stp	q0, q1, [sp, #944]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #569
	ldur	q0, [x8, #255]
	stp	q0, q2, [sp, #304]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #617
	ldur	q1, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #601
	ldur	q2, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #649
	ldur	q0, [x8, #255]
	stp	q0, q1, [sp, #912]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #633
	ldur	q0, [x8, #255]
	stp	q0, q2, [sp, #272]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #1545
	ldur	q1, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #1529
	ldur	q0, [x8, #255]
	stp	q1, q0, [sp, #880]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #1577
	ldur	q1, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #1561
	ldur	q0, [x8, #255]
	stp	q1, q0, [sp, #848]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #1609
	ldur	q1, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #1593
	ldur	q0, [x8, #255]
	stp	q1, q0, [sp, #816]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #1641
	ldur	q1, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #1625
	ldur	q0, [x8, #255]
	stp	q1, q0, [sp, #784]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #1673
	ldur	q1, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #1657
	ldur	q0, [x8, #255]
	stp	q1, q0, [sp, #752]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #1705
	ldur	q1, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #1689
	ldur	q0, [x8, #255]
	stp	q1, q0, [sp, #720]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #1737
	ldur	q1, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #1721
	ldur	q0, [x8, #255]
	stp	q1, q0, [sp, #688]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #1769
	ldur	q1, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #1753
	ldur	q0, [x8, #255]
	stp	q1, q0, [sp, #656]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2665
	ldur	q1, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2649
	ldur	q0, [x8, #255]
	stp	q1, q0, [sp, #624]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2697
	ldur	q1, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2681
	ldur	q0, [x8, #255]
	stp	q1, q0, [sp, #592]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2729
	ldur	q1, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2713
	ldur	q0, [x8, #255]
	stp	q1, q0, [sp, #560]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2761
	ldur	q1, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2745
	ldur	q0, [x8, #255]
	stp	q1, q0, [sp, #528]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2793
	ldur	q1, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2777
	ldur	q0, [x8, #255]
	stp	q1, q0, [sp, #496]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2825
	ldur	q1, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2809
	ldur	q0, [x8, #255]
	stp	q1, q0, [sp, #464]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2857
	ldur	q1, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2841
	ldur	q0, [x8, #255]
	stp	q1, q0, [sp, #432]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2889
	ldur	q1, [x8, #255]
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2873
	ldur	q0, [x8, #255]
	stp	q1, q0, [sp, #400]              ; 32-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #3785
	ldur	q0, [x8, #255]
	str	q0, [sp, #2800]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #3769
	ldur	q0, [x8, #255]
	str	q0, [sp, #2816]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #3817
	ldur	q0, [x8, #255]
	str	q0, [sp, #2768]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #3801
	ldur	q0, [x8, #255]
	str	q0, [sp, #2784]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #3849
	ldur	q0, [x8, #255]
	str	q0, [sp, #2736]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #3833
	ldur	q0, [x8, #255]
	str	q0, [sp, #2752]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #3881
	ldur	q0, [x8, #255]
	str	q0, [sp, #2704]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #3865
	ldur	q0, [x8, #255]
	str	q0, [sp, #2720]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #3913
	ldur	q0, [x8, #255]
	str	q0, [sp, #2672]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #3897
	ldur	q0, [x8, #255]
	str	q0, [sp, #2688]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #3945
	ldur	q0, [x8, #255]
	str	q0, [sp, #2640]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #3929
	ldur	q0, [x8, #255]
	str	q0, [sp, #2656]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #3977
	ldur	q0, [x8, #255]
	str	q0, [sp, #2608]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #3961
	ldur	q0, [x8, #255]
	str	q0, [sp, #2624]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #4009
	ldur	q0, [x8, #255]
	str	q0, [sp, #2576]                 ; 16-byte Folded Spill
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #3993
	ldur	q0, [x8, #255]
	str	q0, [sp, #2592]                 ; 16-byte Folded Spill
	mov	w0, #4224                       ; =0x1080
	bl	_malloc
	cbz	x0, LBB93_12
; %bb.10:                               ; %"wf_box_new$instance$3178c7907270f1e1.exit"
	ldr	q1, [sp, #128]                  ; 16-byte Folded Reload
	ldr	q0, [sp, #256]                  ; 16-byte Folded Reload
	stp	q1, q0, [x0, #16]
	ldr	q1, [sp, #112]                  ; 16-byte Folded Reload
	ldr	q0, [sp, #240]                  ; 16-byte Folded Reload
	stp	q1, q0, [x0, #48]
	ldr	q1, [sp, #96]                   ; 16-byte Folded Reload
	ldr	q0, [sp, #224]                  ; 16-byte Folded Reload
	stp	q1, q0, [x0, #80]
	ldr	q1, [sp, #80]                   ; 16-byte Folded Reload
	ldr	q0, [sp, #208]                  ; 16-byte Folded Reload
	stp	q1, q0, [x0, #112]
	ldr	q1, [sp, #64]                   ; 16-byte Folded Reload
	ldr	q0, [sp, #192]                  ; 16-byte Folded Reload
	stp	q1, q0, [x0, #144]
	ldr	q1, [sp, #48]                   ; 16-byte Folded Reload
	ldr	q0, [sp, #176]                  ; 16-byte Folded Reload
	stp	q1, q0, [x0, #176]
	ldr	q1, [sp, #32]                   ; 16-byte Folded Reload
	ldr	q0, [sp, #160]                  ; 16-byte Folded Reload
	stp	q1, q0, [x0, #208]
	ldr	q1, [sp, #16]                   ; 16-byte Folded Reload
	ldr	q0, [sp, #144]                  ; 16-byte Folded Reload
	stp	q1, q0, [x0, #240]
	ldr	q1, [sp, #3088]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3104]                 ; 16-byte Folded Reload
	stp	q0, q1, [x0, #864]
	ldr	q1, [sp, #3024]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3040]                 ; 16-byte Folded Reload
	stp	q0, q1, [x0, #896]
	ldr	q1, [sp, #2992]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3008]                 ; 16-byte Folded Reload
	stp	q0, q1, [x0, #928]
	ldr	q1, [sp, #2960]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #2976]                 ; 16-byte Folded Reload
	stp	q0, q1, [x0, #960]
	ldr	q1, [sp, #2928]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #2944]                 ; 16-byte Folded Reload
	stp	q0, q1, [x0, #992]
	ldr	q0, [sp, #2896]                 ; 16-byte Folded Reload
	str	q0, [x0, #1040]
	ldr	q0, [sp, #2912]                 ; 16-byte Folded Reload
	str	q0, [x0, #1024]
	ldr	q0, [sp, #2864]                 ; 16-byte Folded Reload
	str	q0, [x0, #1072]
	ldr	q0, [sp, #2880]                 ; 16-byte Folded Reload
	str	q0, [x0, #1056]
	ldr	q0, [sp, #2832]                 ; 16-byte Folded Reload
	str	q0, [x0, #1104]
	ldr	q0, [sp, #2848]                 ; 16-byte Folded Reload
	str	q0, [x0, #1088]
	ldr	q0, [sp, #2032]                 ; 16-byte Folded Reload
	str	q0, [x0, #2000]
	ldr	q0, [sp, #2048]                 ; 16-byte Folded Reload
	str	q0, [x0, #1984]
	ldr	q0, [sp, #2000]                 ; 16-byte Folded Reload
	str	q0, [x0, #2032]
	ldr	q0, [sp, #2016]                 ; 16-byte Folded Reload
	str	q0, [x0, #2016]
	ldr	q0, [sp, #1968]                 ; 16-byte Folded Reload
	str	q0, [x0, #2064]
	ldr	q0, [sp, #1984]                 ; 16-byte Folded Reload
	str	q0, [x0, #2048]
	ldr	q0, [sp, #1936]                 ; 16-byte Folded Reload
	str	q0, [x0, #2096]
	ldr	q0, [sp, #1952]                 ; 16-byte Folded Reload
	str	q0, [x0, #2080]
	ldr	q0, [sp, #1904]                 ; 16-byte Folded Reload
	str	q0, [x0, #2128]
	ldr	q0, [sp, #1920]                 ; 16-byte Folded Reload
	str	q0, [x0, #2112]
	ldr	q0, [sp, #1872]                 ; 16-byte Folded Reload
	str	q0, [x0, #2160]
	ldr	q0, [sp, #1888]                 ; 16-byte Folded Reload
	str	q0, [x0, #2144]
	ldr	q0, [sp, #1840]                 ; 16-byte Folded Reload
	str	q0, [x0, #2192]
	ldr	q0, [sp, #1856]                 ; 16-byte Folded Reload
	str	q0, [x0, #2176]
	ldr	q0, [sp, #1808]                 ; 16-byte Folded Reload
	str	q0, [x0, #2224]
	ldr	q0, [sp, #1824]                 ; 16-byte Folded Reload
	str	q0, [x0, #2208]
	ldr	q0, [sp, #1264]                 ; 16-byte Folded Reload
	str	q0, [x0, #3120]
	ldr	q0, [sp, #1280]                 ; 16-byte Folded Reload
	str	q0, [x0, #3104]
	ldr	q0, [sp, #1232]                 ; 16-byte Folded Reload
	str	q0, [x0, #3152]
	ldr	q0, [sp, #1248]                 ; 16-byte Folded Reload
	str	q0, [x0, #3136]
	ldr	q0, [sp, #1200]                 ; 16-byte Folded Reload
	str	q0, [x0, #3184]
	ldr	q0, [sp, #1216]                 ; 16-byte Folded Reload
	str	q0, [x0, #3168]
	ldr	q0, [sp, #1168]                 ; 16-byte Folded Reload
	str	q0, [x0, #3216]
	ldr	q0, [sp, #1184]                 ; 16-byte Folded Reload
	str	q0, [x0, #3200]
	ldr	q0, [sp, #1136]                 ; 16-byte Folded Reload
	str	q0, [x0, #3248]
	ldr	q0, [sp, #1152]                 ; 16-byte Folded Reload
	str	q0, [x0, #3232]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [x0, #3280]
	ldr	q0, [sp, #1120]                 ; 16-byte Folded Reload
	str	q0, [x0, #3264]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [x0, #3312]
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [x0, #3296]
	ldr	q0, [sp, #1040]                 ; 16-byte Folded Reload
	str	q0, [x0, #3344]
	ldr	q0, [sp, #1056]                 ; 16-byte Folded Reload
	str	q0, [x0, #3328]
	ldr	x8, [sp, #3944]                 ; 8-byte Folded Reload
	stp	x27, x8, [x0]
	ldr	x9, [sp, #3936]                 ; 8-byte Folded Reload
	ldr	x8, [sp, #3928]                 ; 8-byte Folded Reload
	stp	x9, x8, [x0, #272]
	ldr	x9, [sp, #3920]                 ; 8-byte Folded Reload
	ldr	x8, [sp, #3912]                 ; 8-byte Folded Reload
	stp	x9, x8, [x0, #288]
	ldr	x8, [sp, #3640]                 ; 8-byte Folded Reload
	str	x8, [x0, #560]
	ldr	x8, [sp, #3632]                 ; 8-byte Folded Reload
	str	x8, [x0, #568]
	ldr	x8, [sp, #3624]                 ; 8-byte Folded Reload
	str	x8, [x0, #576]
	ldr	x8, [sp, #3616]                 ; 8-byte Folded Reload
	str	x8, [x0, #840]
	ldr	x8, [sp, #3608]                 ; 8-byte Folded Reload
	str	x8, [x0, #848]
	ldr	x8, [sp, #3600]                 ; 8-byte Folded Reload
	str	x8, [x0, #856]
	str	x22, [x0, #1120]
	str	x24, [x0, #1128]
	str	x25, [x0, #1136]
	str	x23, [x0, #1400]
	str	x26, [x0, #1408]
	str	x28, [x0, #1416]
	add	x8, x0, #304
	ldr	q1, [sp, #384]                  ; 16-byte Folded Reload
	ldr	q0, [sp, #1024]                 ; 16-byte Folded Reload
	stp	q1, q0, [x8]
	ldr	q1, [sp, #368]                  ; 16-byte Folded Reload
	ldr	q0, [sp, #1008]                 ; 16-byte Folded Reload
	stp	q1, q0, [x8, #32]
	ldr	q1, [sp, #352]                  ; 16-byte Folded Reload
	ldr	q0, [sp, #992]                  ; 16-byte Folded Reload
	stp	q1, q0, [x8, #64]
	ldr	q1, [sp, #336]                  ; 16-byte Folded Reload
	ldr	q0, [sp, #976]                  ; 16-byte Folded Reload
	stp	q1, q0, [x8, #96]
	ldr	q1, [sp, #320]                  ; 16-byte Folded Reload
	ldr	q0, [sp, #960]                  ; 16-byte Folded Reload
	stp	q1, q0, [x8, #128]
	ldr	q1, [sp, #304]                  ; 16-byte Folded Reload
	ldr	q0, [sp, #944]                  ; 16-byte Folded Reload
	stp	q1, q0, [x8, #160]
	ldr	q1, [sp, #288]                  ; 16-byte Folded Reload
	ldr	q0, [sp, #928]                  ; 16-byte Folded Reload
	stp	q1, q0, [x8, #192]
	ldr	q1, [sp, #272]                  ; 16-byte Folded Reload
	ldr	q0, [sp, #912]                  ; 16-byte Folded Reload
	stp	q1, q0, [x8, #224]
	ldp	q1, q0, [sp, #880]              ; 32-byte Folded Reload
	str	q1, [x8, #1136]
	str	q0, [x8, #1120]
	ldp	q1, q0, [sp, #848]              ; 32-byte Folded Reload
	str	q1, [x8, #1168]
	str	q0, [x8, #1152]
	ldp	q1, q0, [sp, #816]              ; 32-byte Folded Reload
	str	q1, [x8, #1200]
	str	q0, [x8, #1184]
	ldp	q1, q0, [sp, #784]              ; 32-byte Folded Reload
	str	q1, [x8, #1232]
	str	q0, [x8, #1216]
	ldp	q1, q0, [sp, #752]              ; 32-byte Folded Reload
	str	q1, [x8, #1264]
	str	q0, [x8, #1248]
	ldp	q1, q0, [sp, #720]              ; 32-byte Folded Reload
	str	q1, [x8, #1296]
	str	q0, [x8, #1280]
	ldp	q1, q0, [sp, #688]              ; 32-byte Folded Reload
	str	q1, [x8, #1328]
	str	q0, [x8, #1312]
	ldp	q1, q0, [sp, #656]              ; 32-byte Folded Reload
	str	q1, [x8, #1360]
	str	q0, [x8, #1344]
	ldp	q1, q0, [sp, #624]              ; 32-byte Folded Reload
	str	q1, [x8, #2256]
	str	q0, [x8, #2240]
	ldp	q1, q0, [sp, #592]              ; 32-byte Folded Reload
	str	q1, [x8, #2288]
	str	q0, [x8, #2272]
	ldp	q1, q0, [sp, #560]              ; 32-byte Folded Reload
	str	q1, [x8, #2320]
	str	q0, [x8, #2304]
	ldp	q1, q0, [sp, #528]              ; 32-byte Folded Reload
	str	q1, [x8, #2352]
	str	q0, [x8, #2336]
	ldp	q1, q0, [sp, #496]              ; 32-byte Folded Reload
	str	q1, [x8, #2384]
	str	q0, [x8, #2368]
	ldp	q1, q0, [sp, #464]              ; 32-byte Folded Reload
	str	q1, [x8, #2416]
	str	q0, [x8, #2400]
	ldp	q1, q0, [sp, #432]              ; 32-byte Folded Reload
	str	q1, [x8, #2448]
	str	q0, [x8, #2432]
	ldp	q1, q0, [sp, #400]              ; 32-byte Folded Reload
	str	q1, [x8, #2480]
	str	q0, [x8, #2464]
	add	x9, x8, #280
	ldr	q1, [sp, #1296]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1344]                 ; 16-byte Folded Reload
	stp	q1, q0, [x9]
	add	x9, x8, #312
	ldr	q1, [sp, #1312]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1376]                 ; 16-byte Folded Reload
	stp	q1, q0, [x9]
	add	x9, x8, #344
	ldr	q1, [sp, #1328]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1408]                 ; 16-byte Folded Reload
	stp	q1, q0, [x9]
	add	x9, x8, #376
	ldr	q1, [sp, #1360]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1440]                 ; 16-byte Folded Reload
	stp	q1, q0, [x9]
	add	x9, x8, #408
	ldr	q1, [sp, #1392]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1472]                 ; 16-byte Folded Reload
	stp	q1, q0, [x9]
	add	x9, x8, #440
	ldr	q1, [sp, #1424]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1504]                 ; 16-byte Folded Reload
	stp	q1, q0, [x9]
	add	x9, x8, #472
	ldr	q1, [sp, #1456]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1520]                 ; 16-byte Folded Reload
	stp	q1, q0, [x9]
	add	x9, x8, #504
	ldr	q1, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1536]                 ; 16-byte Folded Reload
	stp	q1, q0, [x9]
	add	x9, x8, #840
	ldr	q1, [sp, #1552]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1568]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #872
	ldr	q1, [sp, #1584]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1600]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #904
	ldr	q1, [sp, #1616]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1632]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #936
	ldr	q1, [sp, #1648]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1664]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #968
	ldr	q1, [sp, #1680]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1696]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #1000
	ldr	q1, [sp, #1712]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1728]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #1032
	ldr	q1, [sp, #1744]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1760]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #1064
	ldr	q1, [sp, #1776]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1792]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #1400
	ldr	q1, [sp, #2064]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #2080]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #1432
	ldr	q1, [sp, #2096]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #2112]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #1464
	ldr	q1, [sp, #2128]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #2144]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #1496
	ldr	q1, [sp, #2160]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #2176]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #1528
	ldr	q1, [sp, #2192]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #2208]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #1560
	ldr	q1, [sp, #2224]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #2240]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #1592
	ldr	q1, [sp, #2256]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #2272]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #1624
	ldr	q1, [sp, #2288]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #2304]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #1960
	ldr	q1, [sp, #2320]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #2336]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #1992
	ldr	q1, [sp, #2352]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #2368]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #2024
	ldr	q1, [sp, #2384]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #2400]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #2056
	ldr	q1, [sp, #2416]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #2432]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #2088
	ldr	q1, [sp, #2448]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #2464]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #2120
	ldr	q1, [sp, #2480]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #2496]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #2152
	ldr	q1, [sp, #2512]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #2528]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #2184
	ldr	q1, [sp, #2544]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #2560]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #2520
	ldr	q1, [sp, #3056]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3072]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #2552
	ldr	q1, [sp, #3120]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3136]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #2584
	ldr	q1, [sp, #3152]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3168]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #2616
	ldr	q1, [sp, #3184]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3200]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #2648
	ldr	q1, [sp, #3216]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3232]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #2680
	ldr	q1, [sp, #3248]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3264]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #2712
	ldr	q1, [sp, #3280]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3296]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #2744
	ldr	q1, [sp, #3312]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3328]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #3080
	ldr	q1, [sp, #3344]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3360]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #3112
	ldr	q1, [sp, #3376]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3392]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #3144
	ldr	q1, [sp, #3408]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3424]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #3176
	ldr	q1, [sp, #3440]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3456]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #3208
	ldr	q1, [sp, #3472]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3488]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #3240
	ldr	q1, [sp, #3504]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3520]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #3272
	ldr	q1, [sp, #3536]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3552]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	add	x9, x8, #3304
	ldr	q1, [sp, #3568]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3584]                 ; 16-byte Folded Reload
	stp	q0, q1, [x9]
	ldr	x9, [sp, #4160]                 ; 8-byte Folded Reload
	str	x9, [x0, #1680]
	ldr	x9, [sp, #4152]                 ; 8-byte Folded Reload
	str	x9, [x0, #1688]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #96
	add	x9, x9, #264
	ldr	x10, [sp, #4168]                ; 8-byte Folded Reload
	str	x10, [x0, #1696]
	ldr	x10, [sp, #4144]                ; 8-byte Folded Reload
	str	x10, [x0, #1960]
	ldr	x10, [sp, #4136]                ; 8-byte Folded Reload
	str	x10, [x0, #1968]
	ldr	x10, [sp, #4128]                ; 8-byte Folded Reload
	str	x10, [x0, #1976]
	ldr	x10, [sp, #4176]                ; 8-byte Folded Reload
	str	x10, [x0, #2240]
	ldr	x10, [sp, #4120]                ; 8-byte Folded Reload
	str	x10, [x0, #2248]
	ldr	x10, [sp, #4112]                ; 8-byte Folded Reload
	str	x10, [x0, #2256]
	ldr	x10, [sp, #4104]                ; 8-byte Folded Reload
	str	x10, [x0, #2520]
	ldr	x10, [sp, #4096]                ; 8-byte Folded Reload
	str	x10, [x0, #2528]
	ldr	x10, [sp, #4088]                ; 8-byte Folded Reload
	str	x10, [x0, #2536]
	ldr	x10, [sp, #4080]                ; 8-byte Folded Reload
	str	x10, [x0, #2800]
	ldr	x10, [sp, #4072]                ; 8-byte Folded Reload
	str	x10, [x0, #2808]
	ldr	x10, [sp, #4064]                ; 8-byte Folded Reload
	str	x10, [x0, #2816]
	ldr	x10, [sp, #4056]                ; 8-byte Folded Reload
	str	x10, [x0, #3080]
	ldr	x10, [sp, #4048]                ; 8-byte Folded Reload
	str	x10, [x0, #3088]
	ldr	x10, [sp, #4040]                ; 8-byte Folded Reload
	str	x10, [x0, #3096]
	ldr	x10, [sp, #4024]                ; 8-byte Folded Reload
	str	x10, [x0, #3360]
	ldr	x10, [sp, #4016]                ; 8-byte Folded Reload
	str	x10, [x0, #3368]
	ldr	x10, [sp, #4008]                ; 8-byte Folded Reload
	str	x10, [x0, #3376]
	ldr	x10, [sp, #3984]                ; 8-byte Folded Reload
	str	x10, [x0, #3640]
	ldr	x10, [sp, #3976]                ; 8-byte Folded Reload
	str	x10, [x0, #3648]
	ldr	x10, [sp, #3968]                ; 8-byte Folded Reload
	str	x10, [x0, #3656]
	ldr	q0, [sp, #2800]                 ; 16-byte Folded Reload
	str	q0, [x8, #3376]
	ldr	q0, [sp, #2816]                 ; 16-byte Folded Reload
	str	q0, [x8, #3360]
	ldr	q0, [sp, #2768]                 ; 16-byte Folded Reload
	str	q0, [x8, #3408]
	ldr	q0, [sp, #2784]                 ; 16-byte Folded Reload
	str	q0, [x8, #3392]
	ldr	q0, [sp, #2736]                 ; 16-byte Folded Reload
	str	q0, [x8, #3440]
	ldr	q0, [sp, #2752]                 ; 16-byte Folded Reload
	str	q0, [x8, #3424]
	ldr	q0, [sp, #2704]                 ; 16-byte Folded Reload
	str	q0, [x8, #3472]
	ldr	q0, [sp, #2720]                 ; 16-byte Folded Reload
	str	q0, [x8, #3456]
	ldr	q0, [sp, #2672]                 ; 16-byte Folded Reload
	str	q0, [x8, #3504]
	ldr	q0, [sp, #2688]                 ; 16-byte Folded Reload
	str	q0, [x8, #3488]
	ldr	q0, [sp, #2640]                 ; 16-byte Folded Reload
	str	q0, [x8, #3536]
	ldr	q0, [sp, #2656]                 ; 16-byte Folded Reload
	str	q0, [x8, #3520]
	ldr	q0, [sp, #2608]                 ; 16-byte Folded Reload
	str	q0, [x8, #3568]
	ldr	q0, [sp, #2624]                 ; 16-byte Folded Reload
	str	q0, [x8, #3552]
	ldr	q0, [sp, #2576]                 ; 16-byte Folded Reload
	str	q0, [x8, #3600]
	ldr	q0, [sp, #2592]                 ; 16-byte Folded Reload
	str	q0, [x8, #3584]
	str	x21, [x0, #3920]
	ldr	x10, [sp, #3960]                ; 8-byte Folded Reload
	str	x10, [x0, #3928]
	ldr	x10, [sp, #3952]                ; 8-byte Folded Reload
	str	x10, [x0, #3936]
	add	x10, x8, #3640
	ldr	q1, [sp, #3648]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3664]                 ; 16-byte Folded Reload
	stp	q0, q1, [x10]
	add	x10, x8, #3672
	ldr	q1, [sp, #3680]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3696]                 ; 16-byte Folded Reload
	stp	q0, q1, [x10]
	add	x10, x8, #3704
	ldr	q1, [sp, #3712]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3728]                 ; 16-byte Folded Reload
	stp	q0, q1, [x10]
	add	x10, x8, #3736
	ldr	q1, [sp, #3744]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3760]                 ; 16-byte Folded Reload
	stp	q0, q1, [x10]
	add	x10, x8, #3768
	ldr	q1, [sp, #3776]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3792]                 ; 16-byte Folded Reload
	stp	q0, q1, [x10]
	add	x10, x8, #3800
	ldr	q1, [sp, #3808]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3824]                 ; 16-byte Folded Reload
	stp	q0, q1, [x10]
	add	x10, x8, #3832
	ldr	q1, [sp, #3840]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3856]                 ; 16-byte Folded Reload
	stp	q0, q1, [x10]
	add	x8, x8, #3864
	ldr	q1, [sp, #3872]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #3888]                 ; 16-byte Folded Reload
	stp	q0, q1, [x8]
	ldr	x8, [sp, #4000]                 ; 8-byte Folded Reload
	str	x8, [x0, #4200]
	ldr	x8, [sp, #3992]                 ; 8-byte Folded Reload
	str	x8, [x0, #4208]
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19], #8
	ldr	x8, [sp, #4032]                 ; 8-byte Folded Reload
	str	x8, [x0, #4216]
	ldr	x8, [sp, #4456]
	add	x9, x9, x8, lsl #3
	str	x0, [x9, #8]
	add	x8, x8, #1
	str	x8, [sp, #4456]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #96
	mov	x0, x19
	mov	w2, #280                        ; =0x118
	bl	_memcpy
LBB93_11:                               ; %bb2
	add	sp, sp, #2, lsl #12             ; =8192
	add	sp, sp, #768
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB93_12:                               ; %box.new.oom.v1.i
	bl	l_wf_resource_abort
	.loh AdrpLdrGot	Lloh62, Lloh63
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_remove_item$instance$d883f474bea0047c ; -- Begin function wf_std.collections.ordered_map.ordered_map_remove_item$instance$d883f474bea0047c
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_remove_item$instance$d883f474bea0047c: ; @"wf_std.collections.ordered_map.ordered_map_remove_item$instance$d883f474bea0047c"
; %bb.0:                                ; %entry
	sub	sp, sp, #368
	stp	x28, x27, [sp, #288]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #304]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #320]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #336]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #352]            ; 16-byte Folded Spill
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
	add	x8, x1, #16
	mov	w22, #280                       ; =0x118
	madd	x23, x2, x22, x8
	add	x0, sp, #8
	add	x1, x23, #8
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	ldr	x24, [x20, #16]
	mvn	x8, x19
	add	x8, x24, x8
	mul	x2, x8, x22
	add	x0, x23, #8
	add	x1, x23, #288
	bl	_memmove
	sub	x8, x24, #1
	str	x8, [x20, #16]
	add	x3, sp, #8
	mov	x0, x21
	mov	x1, x20
	mov	x2, x19
	bl	_wf_std.collections.ordered_map.ordered_map_finish_remove$instance$d883f474bea0047c
	ldp	x29, x30, [sp, #352]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #336]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #320]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #304]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #288]            ; 16-byte Folded Reload
	add	sp, sp, #368
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_repair_child$instance$d883f474bea0047c ; -- Begin function wf_std.collections.ordered_map.ordered_map_repair_child$instance$d883f474bea0047c
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_repair_child$instance$d883f474bea0047c: ; @"wf_std.collections.ordered_map.ordered_map_repair_child$instance$d883f474bea0047c"
; %bb.0:                                ; %entry
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #576
	mov	x21, x0
	ldr	x22, [x21, #16]!
	cbz	x22, LBB95_11
; %bb.1:                                ; %bb3
	cbz	x1, LBB95_6
; %bb.2:                                ; %bb6
	sub	x23, x1, #1
	mov	w8, #280                        ; =0x118
	madd	x20, x23, x8, x21
	ldr	x8, [x20, #272]
	cbz	x8, LBB95_11
; %bb.3:                                ; %bb14
	ldr	x8, [x20, #280]
	ldr	x8, [x8, #16]
	cmp	x8, #6
	b.hi	LBB95_11
; %bb.4:                                ; %bb17
	mov	w19, #280                       ; =0x118
	mov	x24, x0
	add	x0, sp, #296
	mov	x25, x1
	add	x1, x20, #8
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	sub	x8, x22, x25
	mul	x19, x8, x19
	add	x0, x20, #8
	add	x1, x20, #288
	mov	x2, x19
	bl	_memmove
	sub	x8, x22, #1
	str	x8, [x24, #16]
	sub	x8, x20, #8
	cmp	x23, #0
	csel	x1, x24, x8, eq
	add	x23, sp, #8
	add	x0, sp, #8
	add	x2, sp, #296
	bl	_wf_std.collections.ordered_map.ordered_map_repair_separator$instance$d883f474bea0047c
	ldr	w8, [sp, #8]
	cbz	w8, LBB95_11
; %bb.5:                                ; %bb6.i18
	add	x0, x20, #288
	add	x1, x20, #8
	mov	x2, x19
	bl	_memmove
	str	x22, [x21]
	add	x0, x20, #8
	b	LBB95_10
LBB95_6:                                ; %bb5
	ldr	x8, [x0]
	cbz	x8, LBB95_11
; %bb.7:                                ; %bb8
	ldr	x8, [x0, #8]
	ldr	x8, [x8, #16]
	cmp	x8, #6
	b.hi	LBB95_11
; %bb.8:                                ; %bb11
	mov	w19, #280                       ; =0x118
	mov	x20, x0
	add	x0, sp, #296
	add	x1, x20, #24
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	sub	x23, x22, #1
	mul	x19, x23, x19
	add	x0, x20, #24
	add	x1, x20, #304
	mov	x2, x19
	bl	_memmove
	str	x23, [x20, #16]
	add	x23, sp, #8
	add	x0, sp, #8
	add	x2, sp, #296
	mov	x24, x20
	mov	x1, x20
	bl	_wf_std.collections.ordered_map.ordered_map_repair_separator$instance$d883f474bea0047c
	ldr	w8, [sp, #8]
	cbz	w8, LBB95_11
; %bb.9:                                ; %bb6.i
	add	x0, x24, #304
	add	x1, x24, #24
	mov	x2, x19
	bl	_memmove
	str	x22, [x21]
	add	x0, x24, #24
LBB95_10:                               ; %common.ret
	add	x1, x23, #8
	mov	w2, #280                        ; =0x118
	bl	_memcpy
LBB95_11:                               ; %common.ret
	mov	w0, #0                          ; =0x0
	add	sp, sp, #576
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_finish_remove$instance$0ed342445dd803f3 ; -- Begin function wf_std.collections.ordered_map.ordered_map_finish_remove$instance$0ed342445dd803f3
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_finish_remove$instance$0ed342445dd803f3: ; @"wf_std.collections.ordered_map.ordered_map_finish_remove$instance$0ed342445dd803f3"
; %bb.0:                                ; %entry
	sub	sp, sp, #144
	stp	x28, x27, [sp, #48]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	ldp	x8, x23, [x2, #16]
	ldp	x21, x20, [x2]
	stp	x21, x20, [sp, #8]
	stp	x8, x23, [sp, #24]
	cbz	x8, LBB96_9
; %bb.1:                                ; %bb4.i.preheader
	mov	x22, x1
	mov	x19, x0
	add	x9, sp, #8
	add	x25, x9, #24
	b	LBB96_4
LBB96_2:                                ; %"wf_append$instance$48c61fa9751a6936.exit.i.i"
                                        ;   in Loop: Header=BB96_4 Depth=1
	add	x8, x27, x26
LBB96_3:                                ; %"wf_std.collections.ordered_map.ordered_map_contract_root$instance$0ed342445dd803f3.exit.i"
                                        ;   in Loop: Header=BB96_4 Depth=1
	stp	x20, x8, [sp, #16]
	str	x23, [sp, #32]
	cbz	x8, LBB96_9
LBB96_4:                                ; %bb4.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x23, #16]
	cbnz	x9, LBB96_8
; %bb.5:                                ; %bb2.i.i
                                        ;   in Loop: Header=BB96_4 Depth=1
	sub	x26, x8, #1
	add	x24, x25, x26, lsl #3
	str	x26, [sp, #24]
	ldr	x0, [x24]
	ldr	x9, [x0, #16]
	cbnz	x9, LBB96_3
; %bb.6:                                ; %bb5.i.i
                                        ;   in Loop: Header=BB96_4 Depth=1
	ldp	x27, x28, [x0]
	bl	_free
	str	x28, [sp, #40]
	cbz	x27, LBB96_2
; %bb.7:                                ; %run.move.body.v3.preheader.i.i.i
                                        ;   in Loop: Header=BB96_4 Depth=1
	lsl	x2, x27, #3
	add	x1, sp, #40
	mov	x0, x24
	bl	_memcpy
	ldr	x23, [sp, #32]
	ldp	x21, x20, [sp, #8]
	b	LBB96_2
LBB96_8:                                ; %bb6.i
	mov	x0, x23
	bl	_wf_std.collections.ordered_map.ordered_map_take_min$instance$0ed342445dd803f3
	mov	x24, x19
	ldr	x25, [x24, #16]!
	stp	x0, x1, [sp, #8]
	add	x23, x22, #1
	sub	x8, x25, x22
	add	x22, x24, x22, lsl #5
	add	x9, x24, x23, lsl #5
	lsl	x2, x8, #5
	add	x0, x9, #8
	add	x1, x22, #8
	bl	_memmove
	add	x8, x25, #1
	str	x8, [x24]
	ldur	q0, [sp, #8]
	ldur	q1, [sp, #24]
	stur	q0, [x22, #8]
	stur	q1, [x22, #24]
	mov	x0, x19
	mov	x1, x23
	bl	_wf_std.collections.ordered_map.ordered_map_repair_child$instance$0ed342445dd803f3
LBB96_9:                                ; %"wf_std.collections.ordered_map.ordered_map_finish_remove$instance$0ed342445dd803f3.body.exit"
	mov	x0, x21
	mov	x1, x20
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_repair_at$instance$0ed342445dd803f3 ; -- Begin function wf_std.collections.ordered_map.ordered_map_repair_at$instance$0ed342445dd803f3
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_repair_at$instance$0ed342445dd803f3: ; @"wf_std.collections.ordered_map.ordered_map_repair_at$instance$0ed342445dd803f3"
; %bb.0:                                ; %entry
	sub	sp, sp, #144
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	mov	x19, x1
	mov	x20, x0
	mov	x22, x0
	ldr	x23, [x22, #16]!
	add	x21, x22, x1, lsl #5
	ldur	q0, [x21, #8]
	ldur	q1, [x21, #24]
	stp	q0, q1, [sp, #48]
	mvn	x8, x1
	add	x8, x23, x8
	lsl	x2, x8, #5
	add	x0, x21, #8
	add	x1, x21, #40
	bl	_memmove
	sub	x24, x23, #1
	str	x24, [x22]
	sub	x8, x21, #8
	cmp	x19, #0
	csel	x1, x20, x8, eq
	add	x0, sp, #8
	add	x2, sp, #48
	bl	_wf_std.collections.ordered_map.ordered_map_repair_separator$instance$0ed342445dd803f3
	ldr	w8, [sp, #8]
	cbz	w8, LBB97_2
; %bb.1:                                ; %bb6
	sub	x8, x24, x19
	lsl	x2, x8, #5
	add	x0, x21, #40
	add	x1, x21, #8
	bl	_memmove
	str	x23, [x22]
	ldp	q0, q1, [sp, #16]
	stur	q1, [x21, #24]
	stur	q0, [x21, #8]
LBB97_2:                                ; %bb4
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_finish_remove$instance$d883f474bea0047c ; -- Begin function wf_std.collections.ordered_map.ordered_map_finish_remove$instance$d883f474bea0047c
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_finish_remove$instance$d883f474bea0047c: ; @"wf_std.collections.ordered_map.ordered_map_finish_remove$instance$d883f474bea0047c"
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #1088
	ldur	q0, [x3, #8]
	ldur	q1, [x3, #24]
	add	x19, sp, #544
	ldur	q2, [x3, #40]
	ldur	q3, [x3, #56]
	ldur	q4, [x3, #72]
	ldur	q5, [x3, #88]
	ldur	q6, [x3, #104]
	ldur	q7, [x3, #120]
	ldur	q16, [x3, #136]
	ldur	q17, [x3, #152]
	ldur	q18, [x3, #168]
	ldur	q19, [x3, #184]
	ldur	q20, [x3, #200]
	ldur	q21, [x3, #216]
	ldur	q22, [x3, #232]
	ldur	q23, [x3, #248]
	ldp	x9, x22, [x3, #264]
	ldr	x8, [x3]
	stur	q0, [x19, #8]
	stur	q1, [x19, #24]
	stur	q2, [x19, #40]
	stur	q3, [x19, #56]
	stur	q4, [x19, #72]
	stur	q5, [x19, #88]
	stur	q6, [x19, #104]
	stur	q7, [x19, #120]
	stur	q16, [x19, #136]
	stur	q17, [x19, #152]
	stur	q18, [x19, #168]
	stur	q19, [x19, #184]
	stur	q20, [x19, #200]
	stur	q21, [x19, #216]
	stur	q22, [x19, #232]
	stur	q23, [x19, #248]
	str	x8, [sp, #544]
	str	x9, [sp, #808]
	str	x22, [sp, #816]
	cbz	x9, LBB98_3
; %bb.1:                                ; %bb4.peel
	mov	x21, x2
	mov	x20, x1
	ldr	x8, [x22, #16]
	cbz	x8, LBB98_4
LBB98_2:
	mov	x23, x0
	add	x19, sp, #280
	add	x0, sp, #280
	mov	x1, x22
	bl	_wf_std.collections.ordered_map.ordered_map_take_min$instance$d883f474bea0047c
	add	x0, sp, #824
	add	x1, sp, #280
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	x0, sp, #280
	add	x1, sp, #544
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	x0, sp, #544
	add	x1, sp, #824
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	mov	x22, x20
	ldr	x24, [x22, #16]!
	sub	x8, x24, x21
	mov	w9, #280                        ; =0x118
	madd	x25, x21, x9, x22
	mul	x2, x8, x9
	add	x0, x25, #288
	add	x1, x25, #8
	bl	_memmove
	add	x8, x24, #1
	str	x8, [x22]
	add	x0, x25, #8
	add	x1, sp, #544
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	add	x1, x21, #1
	mov	x0, x20
	bl	_wf_std.collections.ordered_map.ordered_map_repair_child$instance$d883f474bea0047c
	mov	x0, x23
LBB98_3:                                ; %common.ret
	mov	x1, x19
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	sp, sp, #1088
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB98_4:                                ; %bb2.i.peel
	add	x24, x19, #272
	sub	x26, x9, #1
	add	x23, x24, x26, lsl #3
	str	x26, [sp, #808]
	ldr	x8, [x23]
	ldr	x10, [x8, #16]
	cbnz	x10, LBB98_8
; %bb.5:                                ; %bb5.i.peel
	mov	x25, x0
	ldp	x27, x28, [x8]
	mov	x0, x8
	stp	q1, q0, [sp, #240]              ; 32-byte Folded Spill
	stp	q3, q2, [sp, #208]              ; 32-byte Folded Spill
	stp	q5, q4, [sp, #176]              ; 32-byte Folded Spill
	stp	q7, q6, [sp, #144]              ; 32-byte Folded Spill
	stp	q17, q16, [sp, #112]            ; 32-byte Folded Spill
	stp	q19, q18, [sp, #80]             ; 32-byte Folded Spill
	stp	q21, q20, [sp, #48]             ; 32-byte Folded Spill
	stp	q23, q22, [sp, #16]             ; 32-byte Folded Spill
	bl	_free
	ldp	q23, q22, [sp, #16]             ; 32-byte Folded Reload
	ldp	q21, q20, [sp, #48]             ; 32-byte Folded Reload
	ldp	q19, q18, [sp, #80]             ; 32-byte Folded Reload
	ldp	q17, q16, [sp, #112]            ; 32-byte Folded Reload
	ldp	q7, q6, [sp, #144]              ; 32-byte Folded Reload
	ldp	q5, q4, [sp, #176]              ; 32-byte Folded Reload
	ldp	q3, q2, [sp, #208]              ; 32-byte Folded Reload
	ldp	q1, q0, [sp, #240]              ; 32-byte Folded Reload
	str	x28, [sp, #824]
	cbz	x27, LBB98_7
; %bb.6:                                ; %run.move.body.v3.preheader.i.i.peel
	lsl	x2, x27, #3
	add	x1, sp, #824
	mov	x0, x23
	bl	_memcpy
	ldur	q0, [x19, #8]
	ldur	q1, [x19, #24]
	ldur	q2, [x19, #40]
	ldur	q3, [x19, #56]
	ldur	q4, [x19, #72]
	ldur	q5, [x19, #88]
	ldur	q6, [x19, #104]
	ldur	q7, [x19, #120]
	ldur	q16, [x19, #136]
	ldur	q17, [x19, #152]
	ldur	q18, [x19, #168]
	ldur	q19, [x19, #184]
	ldur	q20, [x19, #200]
	ldur	q21, [x19, #216]
	ldur	q22, [x19, #232]
	ldur	q23, [x19, #248]
	ldr	x22, [sp, #816]
LBB98_7:                                ; %"wf_append$instance$42f33d80f30f592c.exit.i.peel"
	add	x9, x27, x26
	mov	x0, x25
LBB98_8:                                ; %bb1.outer
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB98_9 Depth 2
	sub	x25, x9, #1
	add	x23, x24, x25, lsl #3
LBB98_9:                                ; %bb1
                                        ;   Parent Loop BB98_8 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	stur	q0, [x19, #8]
	stur	q1, [x19, #24]
	stur	q2, [x19, #40]
	stur	q3, [x19, #56]
	stur	q4, [x19, #72]
	stur	q5, [x19, #88]
	stur	q6, [x19, #104]
	stur	q7, [x19, #120]
	stur	q16, [x19, #136]
	stur	q17, [x19, #152]
	stur	q18, [x19, #168]
	stur	q19, [x19, #184]
	stur	q20, [x19, #200]
	stur	q21, [x19, #216]
	stur	q22, [x19, #232]
	stur	q23, [x19, #248]
	str	x9, [sp, #808]
	str	x22, [sp, #816]
	cbz	x9, LBB98_15
; %bb.10:                               ; %bb4
                                        ;   in Loop: Header=BB98_9 Depth=2
	ldr	x8, [x22, #16]
	cbnz	x8, LBB98_2
; %bb.11:                               ; %bb2.i
                                        ;   in Loop: Header=BB98_9 Depth=2
	str	x25, [sp, #808]
	ldr	x8, [x23]
	ldr	x10, [x8, #16]
	cbnz	x10, LBB98_9
; %bb.12:                               ; %bb5.i
                                        ;   in Loop: Header=BB98_8 Depth=1
	mov	x26, x0
	ldp	x27, x28, [x8]
	mov	x0, x8
	stp	q1, q0, [sp, #240]              ; 32-byte Folded Spill
	stp	q3, q2, [sp, #208]              ; 32-byte Folded Spill
	stp	q5, q4, [sp, #176]              ; 32-byte Folded Spill
	stp	q7, q6, [sp, #144]              ; 32-byte Folded Spill
	stp	q17, q16, [sp, #112]            ; 32-byte Folded Spill
	stp	q19, q18, [sp, #80]             ; 32-byte Folded Spill
	stp	q21, q20, [sp, #48]             ; 32-byte Folded Spill
	stp	q23, q22, [sp, #16]             ; 32-byte Folded Spill
	bl	_free
	ldp	q23, q22, [sp, #16]             ; 32-byte Folded Reload
	ldp	q21, q20, [sp, #48]             ; 32-byte Folded Reload
	ldp	q19, q18, [sp, #80]             ; 32-byte Folded Reload
	ldp	q17, q16, [sp, #112]            ; 32-byte Folded Reload
	ldp	q7, q6, [sp, #144]              ; 32-byte Folded Reload
	ldp	q5, q4, [sp, #176]              ; 32-byte Folded Reload
	ldp	q3, q2, [sp, #208]              ; 32-byte Folded Reload
	ldp	q1, q0, [sp, #240]              ; 32-byte Folded Reload
	str	x28, [sp, #824]
	cbz	x27, LBB98_14
; %bb.13:                               ; %run.move.body.v3.preheader.i.i
                                        ;   in Loop: Header=BB98_8 Depth=1
	lsl	x2, x27, #3
	add	x1, sp, #824
	mov	x0, x23
	bl	_memcpy
	ldur	q0, [x19, #8]
	ldur	q1, [x19, #24]
	ldur	q2, [x19, #40]
	ldur	q3, [x19, #56]
	ldur	q4, [x19, #72]
	ldur	q5, [x19, #88]
	ldur	q6, [x19, #104]
	ldur	q7, [x19, #120]
	ldur	q16, [x19, #136]
	ldur	q17, [x19, #152]
	ldur	q18, [x19, #168]
	ldur	q19, [x19, #184]
	ldur	q20, [x19, #200]
	ldur	q21, [x19, #216]
	ldur	q22, [x19, #232]
	ldur	q23, [x19, #248]
	ldr	x22, [sp, #816]
LBB98_14:                               ; %"wf_append$instance$42f33d80f30f592c.exit.i"
                                        ;   in Loop: Header=BB98_8 Depth=1
	add	x9, x27, x25
	mov	x0, x26
	b	LBB98_8
LBB98_15:
	add	x19, sp, #544
	b	LBB98_3
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_repair_at$instance$d883f474bea0047c ; -- Begin function wf_std.collections.ordered_map.ordered_map_repair_at$instance$d883f474bea0047c
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_repair_at$instance$d883f474bea0047c: ; @"wf_std.collections.ordered_map.ordered_map_repair_at$instance$d883f474bea0047c"
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #576
	mov	x19, x1
	mov	x20, x0
	add	x21, x0, #16
	mov	w24, #280                       ; =0x118
	madd	x22, x1, x24, x21
	add	x0, sp, #296
	add	x1, x22, #8
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	ldr	x23, [x20, #16]
	mvn	x8, x19
	add	x8, x23, x8
	mul	x2, x8, x24
	add	x0, x22, #8
	add	x1, x22, #288
	bl	_memmove
	sub	x24, x23, #1
	str	x24, [x20, #16]
	sub	x8, x22, #8
	cmp	x19, #0
	csel	x1, x20, x8, eq
	add	x20, sp, #8
	add	x0, sp, #8
	add	x2, sp, #296
	bl	_wf_std.collections.ordered_map.ordered_map_repair_separator$instance$d883f474bea0047c
	ldr	w8, [sp, #8]
	cbz	w8, LBB99_2
; %bb.1:                                ; %bb6
	sub	x8, x24, x19
	mov	w9, #280                        ; =0x118
	mul	x2, x8, x9
	add	x0, x22, #288
	add	x1, x22, #8
	bl	_memmove
	str	x23, [x21]
	add	x0, x22, #8
	add	x1, x20, #8
	mov	w2, #280                        ; =0x118
	bl	_memcpy
LBB99_2:                                ; %bb4
	mov	w0, #0                          ; =0x0
	add	sp, sp, #576
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_take_min$instance$0ed342445dd803f3 ; -- Begin function wf_std.collections.ordered_map.ordered_map_take_min$instance$0ed342445dd803f3
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_take_min$instance$0ed342445dd803f3: ; @"wf_std.collections.ordered_map.ordered_map_take_min$instance$0ed342445dd803f3"
; %bb.0:                                ; %entry
	sub	sp, sp, #160
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	mov	x19, x0
	mov	x22, x0
	ldr	x8, [x22], #8
	cbnz	x8, LBB100_7
LBB100_1:                               ; %bb3.i
	mov	x23, x19
	ldp	x20, x21, [x23, #24]!
	ldp	x24, x25, [x23, #16]
	ldur	x8, [x23, #-8]
	sub	x26, x8, #1
	lsl	x2, x26, #5
	add	x1, x23, #32
	mov	x0, x23
	bl	_memmove
	stur	x26, [x23, #-8]
	str	x25, [sp, #8]
	cbz	x24, LBB100_3
; %bb.2:                                ; %run.move.body.v3.preheader.i
	lsl	x2, x24, #3
	add	x1, sp, #8
	mov	x0, x22
	bl	_memcpy
LBB100_3:                               ; %"wf_append$instance$48c61fa9751a6936.exit"
	str	x24, [x19]
LBB100_4:                               ; %"wf_std.collections.ordered_map.ordered_map_take_min$instance$0ed342445dd803f3.body.exit"
	mov	x0, x20
	mov	x1, x21
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB100_5:                               ; %"wf_append$instance$48c61fa9751a6936.exit.i"
                                        ;   in Loop: Header=BB100_7 Depth=1
	add	x8, x21, x20
LBB100_6:                               ; %"wf_std.collections.ordered_map.ordered_map_contract_root$instance$0ed342445dd803f3.exit"
                                        ;   in Loop: Header=BB100_7 Depth=1
	str	x8, [x19]
	cbz	x8, LBB100_1
LBB100_7:                               ; %bb4.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x23, [x22]
	ldr	x9, [x23, #16]
	cbnz	x9, LBB100_11
; %bb.8:                                ; %bb2.i
                                        ;   in Loop: Header=BB100_7 Depth=1
	sub	x20, x8, #1
	add	x9, x19, x20, lsl #3
	str	x20, [x19]
	ldr	x0, [x9, #8]
	ldr	x9, [x0, #16]
	cbnz	x9, LBB100_6
; %bb.9:                                ; %bb5.i
                                        ;   in Loop: Header=BB100_7 Depth=1
	ldp	x21, x23, [x0]
	bl	_free
	str	x23, [sp, #8]
	cbz	x21, LBB100_5
; %bb.10:                               ; %run.move.body.v3.preheader.i.i
                                        ;   in Loop: Header=BB100_7 Depth=1
	lsl	x2, x21, #3
	add	x0, x22, x20, lsl #3
	add	x1, sp, #8
	bl	_memcpy
	b	LBB100_5
LBB100_11:                              ; %bb6.i
	mov	x0, x23
	bl	_wf_std.collections.ordered_map.ordered_map_take_min$instance$0ed342445dd803f3
	mov	x20, x0
	mov	x21, x1
	ldr	x24, [x19, #16]
	cbz	x24, LBB100_4
; %bb.12:                               ; %bb8.i
	ldr	x8, [x23, #16]
	cmp	x8, #6
	b.hi	LBB100_4
; %bb.13:                               ; %bb11.i
	ldur	q0, [x19, #24]
	ldur	q1, [x19, #40]
	stp	q0, q1, [sp, #48]
	sub	x23, x24, #1
	lsl	x22, x23, #5
	add	x0, x19, #24
	add	x1, x19, #56
	mov	x2, x22
	bl	_memmove
	str	x23, [x19, #16]
	add	x0, sp, #8
	add	x2, sp, #48
	mov	x1, x19
	bl	_wf_std.collections.ordered_map.ordered_map_repair_separator$instance$0ed342445dd803f3
	ldr	w8, [sp, #8]
	cbz	w8, LBB100_4
; %bb.14:                               ; %bb6.i.i
	add	x0, x19, #56
	add	x1, x19, #24
	mov	x2, x22
	bl	_memmove
	str	x24, [x19, #16]
	ldp	q1, q0, [sp, #16]
	stur	q1, [x19, #24]
	stur	q0, [x19, #40]
	b	LBB100_4
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_repair_separator$instance$0ed342445dd803f3 ; -- Begin function wf_std.collections.ordered_map.ordered_map_repair_separator$instance$0ed342445dd803f3
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_repair_separator$instance$0ed342445dd803f3: ; @"wf_std.collections.ordered_map.ordered_map_repair_separator$instance$0ed342445dd803f3"
; %bb.0:                                ; %entry
	sub	sp, sp, #240
	stp	x26, x25, [sp, #160]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #176]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #192]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #208]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #224]            ; 16-byte Folded Spill
	ldp	q0, q1, [x2]
	stp	q0, q1, [sp]
	ldr	x8, [x1]
	cbz	x8, LBB101_5
; %bb.1:                                ; %bb3
	ldr	x21, [sp, #16]
	cbz	x21, LBB101_6
; %bb.2:                                ; %bb6
	mov	x8, sp
	add	x8, x8, #16
	sub	x9, x21, #1
	add	x24, x8, x9, lsl #3
	str	x9, [sp, #16]
	ldr	x19, [x24, #8]
	ldr	x23, [x1, #8]
	mov	x20, x23
	ldr	x22, [x20, #16]!
	ldr	x26, [x19, #16]
	cmp	x22, #7
	b.hs	LBB101_8
; %bb.3:                                ; %bb8
	mov	x25, x0
	cmp	x26, #7
	b.ls	LBB101_15
; %bb.4:                                ; %bb11
	ldur	q0, [x19, #24]
	ldur	q1, [x19, #40]
	stp	q0, q1, [sp, #128]
	sub	x23, x26, #1
	lsl	x2, x23, #5
	add	x0, x19, #24
	add	x1, x19, #56
	bl	_memmove
	str	x23, [x19, #16]
	ldr	q0, [sp]
	ldp	q1, q2, [sp, #128]
	str	q1, [sp]
	ldr	q1, [x19]
	stp	q0, q1, [sp, #128]
	str	q2, [x19]
	add	x8, x20, x22, lsl #5
	ldp	q0, q1, [sp, #128]
	stur	q0, [x8, #8]
	stur	q1, [x8, #24]
	add	x8, x22, #1
	str	x8, [x20]
	b	LBB101_22
LBB101_5:                               ; %bb2
	ldp	q0, q1, [x2]
	stp	q0, q1, [sp, #64]
	b	LBB101_7
LBB101_6:                               ; %bb5
	ldp	q0, q1, [x2]
	stp	q0, q1, [sp, #32]
LBB101_7:                               ; %common.ret
	str	xzr, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	b	LBB101_24
LBB101_8:                               ; %bb9
	cmp	x26, #7
	b.hs	LBB101_23
; %bb.9:                                ; %bb14
	mov	x25, x0
	cmp	x22, #7
	b.ne	LBB101_21
; %bb.10:                               ; %bb18
	ldp	q1, q0, [sp]
	stp	q1, q0, [sp, #128]
	ldr	x21, [x19]
	ldr	x22, [sp, #144]
	cbz	x21, LBB101_12
; %bb.11:                               ; %run.move.body.v3.preheader.i.i33
	add	x8, sp, #128
	add	x8, x8, #16
	add	x8, x8, x22, lsl #3
	lsl	x2, x21, #3
	add	x0, x8, #8
	add	x1, x19, #8
	bl	_memcpy
LBB101_12:                              ; %"wf_append$instance$48c61fa9751a6936.exit.i36"
	add	x8, x22, x21
	str	x8, [sp, #144]
	add	x8, x23, #248
	ldp	q0, q1, [sp, #128]
	stur	q0, [x23, #248]
	str	q1, [x8, #16]
	ldr	x21, [x19, #16]
	cbz	x21, LBB101_14
; %bb.13:                               ; %run.move.body.v3.i.preheader.i46
	lsl	x2, x21, #5
	add	x0, x23, #280
	add	x1, x19, #24
	bl	_memcpy
LBB101_14:                              ; %"wf_std.collections.ordered_map.ordered_map_merge$instance$0ed342445dd803f3.exit51"
	add	x8, x21, #8
	b	LBB101_20
LBB101_15:                              ; %bb12
	ldp	q1, q0, [sp]
	stp	q1, q0, [sp, #128]
	ldr	x21, [x19]
	ldr	x24, [sp, #144]
	cbz	x21, LBB101_17
; %bb.16:                               ; %run.move.body.v3.preheader.i.i
	add	x8, sp, #128
	add	x8, x8, #16
	add	x8, x8, x24, lsl #3
	lsl	x2, x21, #3
	add	x0, x8, #8
	add	x1, x19, #8
	bl	_memcpy
LBB101_17:                              ; %"wf_append$instance$48c61fa9751a6936.exit.i"
	add	x8, x24, x21
	str	x8, [sp, #144]
	lsl	x8, x22, #5
	add	x9, x20, x8
	ldp	q0, q1, [sp, #128]
	stur	q0, [x9, #8]
	stur	q1, [x9, #24]
	ldr	x21, [x19, #16]
	cbz	x21, LBB101_19
; %bb.18:                               ; %run.move.body.v3.i.preheader.i
	add	x8, x23, x8
	lsl	x2, x21, #5
	add	x0, x8, #56
	add	x1, x19, #24
	bl	_memcpy
LBB101_19:                              ; %"wf_std.collections.ordered_map.ordered_map_merge$instance$0ed342445dd803f3.exit"
	add	x8, x22, x21
	add	x8, x8, #1
LBB101_20:                              ; %"wf_std.collections.ordered_map.ordered_map_merge$instance$0ed342445dd803f3.exit51"
	str	x8, [x20]
	mov	x0, x19
	bl	_free
	str	xzr, [x25, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x25]
	b	LBB101_25
LBB101_21:                              ; %bb17
	sub	x8, x22, #1
	add	x9, x20, x8, lsl #5
	str	x8, [x20]
	ldr	q0, [sp]
	ldur	q1, [x9, #8]
	str	q1, [sp]
	ldr	q1, [x19]
	stp	q0, q1, [sp, #128]
	ldur	q0, [x9, #24]
	str	q0, [x19]
	lsl	x2, x26, #5
	add	x0, x19, #56
	add	x1, x19, #24
	bl	_memmove
	add	x8, x26, #1
	str	x8, [x19, #16]
	ldp	q0, q1, [sp, #128]
	stur	q0, [x19, #24]
	stur	q1, [x19, #40]
LBB101_22:                              ; %bb7
	mov	x0, x25
LBB101_23:                              ; %bb7
	str	x19, [x24, #8]
	str	x21, [sp, #16]
	str	xzr, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	ldp	q0, q1, [sp]
LBB101_24:                              ; %common.ret
	stur	q0, [x0, #8]
	stur	q1, [x0, #24]
LBB101_25:                              ; %common.ret
	ldp	x29, x30, [sp, #224]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #208]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #192]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #176]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #160]            ; 16-byte Folded Reload
	add	sp, sp, #240
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_take_min$instance$d883f474bea0047c ; -- Begin function wf_std.collections.ordered_map.ordered_map_take_min$instance$d883f474bea0047c
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_take_min$instance$d883f474bea0047c: ; @"wf_std.collections.ordered_map.ordered_map_take_min$instance$d883f474bea0047c"
; %bb.0:                                ; %entry
	sub	sp, sp, #368
	stp	x28, x27, [sp, #288]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #304]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #320]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #336]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #352]            ; 16-byte Folded Spill
	mov	x19, x1
	mov	x21, x0
	mov	x20, x1
	ldr	x8, [x20], #8
	cbnz	x8, LBB102_6
LBB102_1:                               ; %bb3
	add	x0, sp, #16
	add	x1, x19, #24
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	ldp	x22, x23, [x19, #288]
	ldr	x8, [x19, #16]
	sub	x24, x8, #1
	mov	w8, #280                        ; =0x118
	mul	x2, x24, x8
	add	x0, x19, #24
	add	x1, x19, #304
	bl	_memmove
	str	x24, [x19, #16]
	add	x1, sp, #16
	mov	x0, x21
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	str	x23, [sp, #8]
	cbz	x22, LBB102_3
; %bb.2:                                ; %run.move.body.v3.preheader.i
	lsl	x2, x22, #3
	add	x1, sp, #8
	mov	x0, x20
	bl	_memcpy
LBB102_3:                               ; %"wf_append$instance$42f33d80f30f592c.exit"
	str	x22, [x19]
	ldp	x29, x30, [sp, #352]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #336]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #320]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #304]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #288]            ; 16-byte Folded Reload
	add	sp, sp, #368
	ret
LBB102_4:                               ; %"wf_append$instance$42f33d80f30f592c.exit.i"
                                        ;   in Loop: Header=BB102_6 Depth=1
	add	x8, x23, x22
LBB102_5:                               ; %"wf_std.collections.ordered_map.ordered_map_contract_root$instance$d883f474bea0047c.exit"
                                        ;   in Loop: Header=BB102_6 Depth=1
	str	x8, [x19]
	cbz	x8, LBB102_1
LBB102_6:                               ; %bb4
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x1, [x20]
	ldr	x9, [x1, #16]
	cbnz	x9, LBB102_10
; %bb.7:                                ; %bb2.i
                                        ;   in Loop: Header=BB102_6 Depth=1
	sub	x22, x8, #1
	add	x9, x19, x22, lsl #3
	str	x22, [x19]
	ldr	x0, [x9, #8]
	ldr	x9, [x0, #16]
	cbnz	x9, LBB102_5
; %bb.8:                                ; %bb5.i
                                        ;   in Loop: Header=BB102_6 Depth=1
	ldp	x23, x24, [x0]
	bl	_free
	str	x24, [sp, #280]
	cbz	x23, LBB102_4
; %bb.9:                                ; %run.move.body.v3.preheader.i.i
                                        ;   in Loop: Header=BB102_6 Depth=1
	lsl	x2, x23, #3
	add	x0, x20, x22, lsl #3
	add	x1, sp, #280
	bl	_memcpy
	b	LBB102_4
LBB102_10:                              ; %bb6
	mov	x0, x21
	bl	_wf_std.collections.ordered_map.ordered_map_take_min$instance$d883f474bea0047c
	mov	x0, x19
	mov	x1, #0                          ; =0x0
	ldp	x29, x30, [sp, #352]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #336]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #320]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #304]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #288]            ; 16-byte Folded Reload
	add	sp, sp, #368
	b	_wf_std.collections.ordered_map.ordered_map_repair_child$instance$d883f474bea0047c
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_repair_separator$instance$d883f474bea0047c ; -- Begin function wf_std.collections.ordered_map.ordered_map_repair_separator$instance$d883f474bea0047c
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_repair_separator$instance$d883f474bea0047c: ; @"wf_std.collections.ordered_map.ordered_map_repair_separator$instance$d883f474bea0047c"
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #1408
	mov	x20, x2
	mov	x21, x1
	mov	x19, x0
	mov	x23, sp
	mov	x0, sp
	mov	x1, x2
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	ldr	x8, [x21]
	cbz	x8, LBB103_5
; %bb.1:                                ; %bb3
	ldr	x22, [sp, #264]
	cbz	x22, LBB103_6
; %bb.2:                                ; %bb6
	add	x8, x23, #264
	sub	x9, x22, #1
	add	x24, x8, x9, lsl #3
	str	x9, [sp, #264]
	ldr	x20, [x24, #8]
	ldr	x25, [x21, #8]
	mov	x21, x25
	ldr	x23, [x21, #16]!
	ldr	x26, [x20, #16]
	cmp	x23, #7
	b.hs	LBB103_7
; %bb.3:                                ; %bb8
	cmp	x26, #7
	b.ls	LBB103_14
; %bb.4:                                ; %bb11
	mov	w25, #280                       ; =0x118
	add	x27, sp, #1128
	add	x0, sp, #1128
	add	x1, x20, #24
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	sub	x26, x26, #1
	mul	x2, x26, x25
	add	x0, x20, #24
	add	x1, x20, #304
	bl	_memmove
	str	x26, [x20, #16]
	add	x0, sp, #840
	add	x1, sp, #1128
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	x0, sp, #1128
	mov	x1, sp
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	mov	x0, sp
	add	x1, sp, #840
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	x8, x27, #264
	ldr	q0, [x8]
	ldr	q1, [x20]
	str	q1, [x8]
	str	q0, [x20]
	madd	x8, x23, x25, x21
	add	x0, x8, #8
	add	x1, sp, #1128
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	add	x8, x23, #1
	str	x8, [x21]
	b	LBB103_21
LBB103_5:                               ; %bb2
	add	x0, sp, #560
	mov	x1, x20
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19], #8
	add	x1, sp, #560
	b	LBB103_22
LBB103_6:                               ; %bb5
	add	x0, sp, #280
	mov	x1, x20
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19], #8
	add	x1, sp, #280
	b	LBB103_22
LBB103_7:                               ; %bb9
	cmp	x26, #7
	b.hs	LBB103_21
; %bb.8:                                ; %bb14
	cmp	x23, #7
	b.ne	LBB103_20
; %bb.9:                                ; %bb18
	add	x24, sp, #1128
	add	x0, sp, #1128
	mov	x1, sp
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	ldr	x22, [x20]
	ldr	x23, [sp, #1392]
	cbz	x22, LBB103_11
; %bb.10:                               ; %run.move.body.v3.preheader.i.i33
	add	x8, x24, #264
	add	x8, x8, x23, lsl #3
	lsl	x2, x22, #3
	add	x0, x8, #8
	add	x1, x20, #8
	bl	_memcpy
LBB103_11:                              ; %"wf_append$instance$42f33d80f30f592c.exit.i36"
	add	x8, x23, x22
	str	x8, [sp, #1392]
	add	x0, x25, #1984
	add	x1, sp, #1128
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	ldr	x22, [x20, #16]
	cbz	x22, LBB103_13
; %bb.12:                               ; %run.move.body.v3.i.preheader.i46
	mov	w8, #280                        ; =0x118
	mul	x2, x22, x8
	add	x0, x25, #2264
	add	x1, x20, #24
	bl	_memcpy
LBB103_13:                              ; %"wf_std.collections.ordered_map.ordered_map_merge$instance$d883f474bea0047c.exit51"
	add	x8, x22, #8
	b	LBB103_19
LBB103_14:                              ; %bb12
	add	x26, sp, #1128
	add	x0, sp, #1128
	mov	x1, sp
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	ldr	x22, [x20]
	ldr	x24, [sp, #1392]
	cbz	x22, LBB103_16
; %bb.15:                               ; %run.move.body.v3.preheader.i.i
	add	x8, x26, #264
	add	x8, x8, x24, lsl #3
	lsl	x2, x22, #3
	add	x0, x8, #8
	add	x1, x20, #8
	bl	_memcpy
LBB103_16:                              ; %"wf_append$instance$42f33d80f30f592c.exit.i"
	add	x8, x24, x22
	str	x8, [sp, #1392]
	mov	w8, #280                        ; =0x118
	mul	x24, x23, x8
	add	x8, x21, x24
	add	x0, x8, #8
	add	x1, sp, #1128
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	ldr	x22, [x20, #16]
	cbz	x22, LBB103_18
; %bb.17:                               ; %run.move.body.v3.i.preheader.i
	add	x8, x25, x24
	mov	w9, #280                        ; =0x118
	mul	x2, x22, x9
	add	x0, x8, #304
	add	x1, x20, #24
	bl	_memcpy
LBB103_18:                              ; %"wf_std.collections.ordered_map.ordered_map_merge$instance$d883f474bea0047c.exit"
	add	x8, x23, x22
	add	x8, x8, #1
LBB103_19:                              ; %"wf_std.collections.ordered_map.ordered_map_merge$instance$d883f474bea0047c.exit51"
	str	x8, [x21]
	mov	x0, x20
	bl	_free
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19, #256]
	stp	q0, q0, [x19, #224]
	stp	q0, q0, [x19, #192]
	stp	q0, q0, [x19, #160]
	stp	q0, q0, [x19, #128]
	stp	q0, q0, [x19, #96]
	stp	q0, q0, [x19, #64]
	stp	q0, q0, [x19, #32]
	stp	q0, q0, [x19]
	b	LBB103_23
LBB103_20:                              ; %bb17
	sub	x8, x23, #1
	mov	w23, #280                       ; =0x118
	madd	x25, x8, x23, x21
	str	x8, [x21]
	add	x21, sp, #1128
	add	x0, sp, #1128
	mov	x1, sp
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	mov	x0, sp
	add	x1, x25, #8
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	x8, x21, #264
	ldr	q0, [x20]
	str	q0, [x8]
	ldr	q0, [x25, #272]
	str	q0, [x20]
	mul	x2, x26, x23
	add	x0, x20, #304
	add	x1, x20, #24
	bl	_memmove
	add	x8, x26, #1
	str	x8, [x20, #16]
	add	x0, x20, #24
	add	x1, sp, #1128
	mov	w2, #280                        ; =0x118
	bl	_memcpy
LBB103_21:                              ; %bb7
	str	x20, [x24, #8]
	str	x22, [sp, #264]
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19], #8
	mov	x1, sp
LBB103_22:                              ; %common.ret
	mov	x0, x19
	mov	w2, #280                        ; =0x118
	bl	_memcpy
LBB103_23:                              ; %common.ret
	add	sp, sp, #1408
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_borrow_right$instance$0ed342445dd803f3 ; -- Begin function wf_std.collections.ordered_map.ordered_map_borrow_right$instance$0ed342445dd803f3
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_borrow_right$instance$0ed342445dd803f3: ; @"wf_std.collections.ordered_map.ordered_map_borrow_right$instance$0ed342445dd803f3"
; %bb.0:                                ; %entry
	sub	sp, sp, #112
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
	ldur	q0, [x1, #24]
	ldur	q1, [x1, #40]
	stp	q0, q1, [sp]
	ldr	x8, [x1, #16]
	sub	x22, x8, #1
	lsl	x2, x22, #5
	add	x0, x1, #24
	add	x1, x1, #56
	bl	_memmove
	str	x22, [x20, #16]
	ldr	q0, [x19]
	ldp	q1, q2, [sp]
	str	q1, [x19]
	ldr	q1, [x20]
	stp	q0, q1, [sp]
	str	q2, [x20]
	ldr	x8, [x21, #16]!
	add	x9, x21, x8, lsl #5
	ldp	q0, q1, [sp]
	stur	q0, [x9, #8]
	stur	q1, [x9, #24]
	add	x8, x8, #1
	str	x8, [x21]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_merge$instance$0ed342445dd803f3 ; -- Begin function wf_std.collections.ordered_map.ordered_map_merge$instance$0ed342445dd803f3
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_merge$instance$0ed342445dd803f3: ; @"wf_std.collections.ordered_map.ordered_map_merge$instance$0ed342445dd803f3"
; %bb.0:                                ; %entry
	sub	sp, sp, #96
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	mov	x19, x1
	mov	x20, x0
	ldp	q1, q0, [x2]
	stp	q1, q0, [sp]
	ldr	x21, [x1]
	ldr	x22, [sp, #16]
	cbz	x21, LBB105_2
; %bb.1:                                ; %run.move.body.v3.preheader.i
	mov	x8, sp
	add	x8, x8, #16
	add	x8, x8, x22, lsl #3
	lsl	x2, x21, #3
	add	x0, x8, #8
	add	x1, x19, #8
	bl	_memcpy
LBB105_2:                               ; %"wf_append$instance$48c61fa9751a6936.exit"
	add	x8, x22, x21
	str	x8, [sp, #16]
	mov	x21, x20
	ldr	x22, [x21, #16]!
	lsl	x8, x22, #5
	add	x9, x21, x8
	ldp	q1, q0, [sp]
	stur	q0, [x9, #24]
	stur	q1, [x9, #8]
	ldr	x23, [x19, #16]
	cbz	x23, LBB105_4
; %bb.3:                                ; %run.move.body.v3.i.preheader
	add	x8, x20, x8
	lsl	x2, x23, #5
	add	x0, x8, #56
	add	x1, x19, #24
	bl	_memcpy
LBB105_4:                               ; %"wf_append$instance$d5eecd37872eaac2.exit"
	add	x8, x22, x23
	add	x8, x8, #1
	str	x8, [x21]
	mov	x0, x19
	bl	_free
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_borrow_left$instance$0ed342445dd803f3 ; -- Begin function wf_std.collections.ordered_map.ordered_map_borrow_left$instance$0ed342445dd803f3
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_borrow_left$instance$0ed342445dd803f3: ; @"wf_std.collections.ordered_map.ordered_map_borrow_left$instance$0ed342445dd803f3"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	mov	x19, x1
	ldr	x8, [x0, #16]!
	sub	x8, x8, #1
	add	x9, x0, x8, lsl #5
	str	x8, [x0]
	ldr	q0, [x2]
	ldur	q1, [x9, #8]
	str	q1, [x2]
	ldr	q1, [x1]
	stp	q0, q1, [sp]
	ldur	q0, [x9, #24]
	str	q0, [x1]
	ldr	x20, [x1, #16]
	lsl	x2, x20, #5
	add	x0, x1, #56
	add	x1, x1, #24
	bl	_memmove
	add	x8, x20, #1
	str	x8, [x19, #16]
	ldp	q0, q1, [sp]
	stur	q0, [x19, #24]
	stur	q1, [x19, #40]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_borrow_right$instance$d883f474bea0047c ; -- Begin function wf_std.collections.ordered_map.ordered_map_borrow_right$instance$d883f474bea0047c
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_borrow_right$instance$d883f474bea0047c: ; @"wf_std.collections.ordered_map.ordered_map_borrow_right$instance$d883f474bea0047c"
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #560
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
	mov	w22, #280                       ; =0x118
	mov	x23, sp
	mov	x0, sp
	add	x1, x1, #24
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	ldr	x8, [x20, #16]
	sub	x24, x8, #1
	mul	x2, x24, x22
	add	x0, x20, #24
	add	x1, x20, #304
	bl	_memmove
	str	x24, [x20, #16]
	add	x0, sp, #280
	mov	x1, sp
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	mov	x0, sp
	mov	x1, x19
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	x1, sp, #280
	mov	x0, x19
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	x8, x23, #264
	ldr	q0, [x8]
	ldr	q1, [x20]
	str	q1, [x8]
	str	q0, [x20]
	ldr	x19, [x21, #16]!
	madd	x8, x19, x22, x21
	add	x0, x8, #8
	mov	x1, sp
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	add	x8, x19, #1
	str	x8, [x21]
	mov	w0, #0                          ; =0x0
	add	sp, sp, #560
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #80             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_merge$instance$d883f474bea0047c ; -- Begin function wf_std.collections.ordered_map.ordered_map_merge$instance$d883f474bea0047c
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_merge$instance$d883f474bea0047c: ; @"wf_std.collections.ordered_map.ordered_map_merge$instance$d883f474bea0047c"
; %bb.0:                                ; %entry
	sub	sp, sp, #368
	stp	x28, x27, [sp, #288]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #304]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #320]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #336]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #352]            ; 16-byte Folded Spill
	mov	x19, x1
	mov	x20, x0
	add	x23, sp, #8
	add	x0, sp, #8
	mov	x1, x2
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	ldr	x21, [x19]
	ldr	x22, [sp, #272]
	cbz	x21, LBB108_2
; %bb.1:                                ; %run.move.body.v3.preheader.i
	add	x8, x23, #264
	add	x8, x8, x22, lsl #3
	lsl	x2, x21, #3
	add	x0, x8, #8
	add	x1, x19, #8
	bl	_memcpy
LBB108_2:                               ; %"wf_append$instance$42f33d80f30f592c.exit"
	add	x8, x22, x21
	str	x8, [sp, #272]
	mov	x21, x20
	ldr	x22, [x21, #16]!
	mov	w8, #280                        ; =0x118
	mul	x24, x22, x8
	add	x8, x21, x24
	add	x0, x8, #8
	add	x1, sp, #8
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	ldr	x23, [x19, #16]
	cbz	x23, LBB108_4
; %bb.3:                                ; %run.move.body.v3.i.preheader
	add	x8, x20, x24
	mov	w9, #280                        ; =0x118
	mul	x2, x23, x9
	add	x0, x8, #304
	add	x1, x19, #24
	bl	_memcpy
LBB108_4:                               ; %"wf_append$instance$252e05fd84976d22.exit"
	add	x8, x22, x23
	add	x8, x8, #1
	str	x8, [x21]
	mov	x0, x19
	bl	_free
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #352]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #336]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #320]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #304]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #288]            ; 16-byte Folded Reload
	add	sp, sp, #368
	ret
                                        ; -- End function
	.globl	_wf_std.collections.ordered_map.ordered_map_borrow_left$instance$d883f474bea0047c ; -- Begin function wf_std.collections.ordered_map.ordered_map_borrow_left$instance$d883f474bea0047c
	.p2align	2
_wf_std.collections.ordered_map.ordered_map_borrow_left$instance$d883f474bea0047c: ; @"wf_std.collections.ordered_map.ordered_map_borrow_left$instance$d883f474bea0047c"
; %bb.0:                                ; %entry
	sub	sp, sp, #352
	stp	x24, x23, [sp, #288]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #304]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #320]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #336]            ; 16-byte Folded Spill
	mov	x19, x2
	mov	x20, x1
	ldr	x8, [x0, #16]!
	sub	x8, x8, #1
	mov	w21, #280                       ; =0x118
	madd	x22, x8, x21, x0
	str	x8, [x0]
	add	x23, sp, #8
	add	x0, sp, #8
	mov	x1, x2
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	x1, x22, #8
	mov	x0, x19
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	add	x8, x23, #264
	ldr	q0, [x20]
	str	q0, [x8]
	ldr	q0, [x22, #272]
	str	q0, [x20]
	ldr	x19, [x20, #16]
	mul	x2, x19, x21
	add	x0, x20, #304
	add	x1, x20, #24
	bl	_memmove
	add	x8, x19, #1
	str	x8, [x20, #16]
	add	x0, x20, #24
	add	x1, sp, #8
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #336]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #320]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #304]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #288]            ; 16-byte Folded Reload
	add	sp, sp, #352
	ret
                                        ; -- End function
	.globl	_wf_append$instance$48c61fa9751a6936 ; -- Begin function wf_append$instance$48c61fa9751a6936
	.p2align	2
_wf_append$instance$48c61fa9751a6936:   ; @"wf_append$instance$48c61fa9751a6936"
; %bb.0:                                ; %entry
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	mov	x20, x1
	mov	x19, x0
	ldr	x21, [x1]
	ldr	x22, [x0]
	cbz	x21, LBB110_2
; %bb.1:                                ; %run.move.body.v3.preheader
	lsl	x2, x21, #3
	add	x8, x19, x22, lsl #3
	add	x0, x8, #8
	add	x1, x20, #8
	bl	_memcpy
LBB110_2:                               ; %run.move.done.v3
	add	x8, x22, x21
	str	xzr, [x20]
	str	x8, [x19]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_place_back$instance$f2ca242ae19e388d ; -- Begin function wf_place_back$instance$f2ca242ae19e388d
	.p2align	2
_wf_place_back$instance$f2ca242ae19e388d: ; @"wf_place_back$instance$f2ca242ae19e388d"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	add	x9, x0, x8, lsl #5
	ldp	q0, q1, [x1]
	stur	q0, [x9, #8]
	stur	q1, [x9, #24]
	add	x8, x8, #1
	str	x8, [x0]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_place_back$instance$0270a1f1e6dbd4ef ; -- Begin function wf_place_back$instance$0270a1f1e6dbd4ef
	.p2align	2
_wf_place_back$instance$0270a1f1e6dbd4ef: ; @"wf_place_back$instance$0270a1f1e6dbd4ef"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	add	x9, x0, x8, lsl #3
	str	x1, [x9, #8]
	add	x8, x8, #1
	str	x8, [x0]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_append$instance$42f33d80f30f592c ; -- Begin function wf_append$instance$42f33d80f30f592c
	.p2align	2
_wf_append$instance$42f33d80f30f592c:   ; @"wf_append$instance$42f33d80f30f592c"
; %bb.0:                                ; %entry
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	mov	x20, x1
	mov	x19, x0
	ldr	x21, [x1]
	ldr	x22, [x0]
	cbz	x21, LBB113_2
; %bb.1:                                ; %run.move.body.v3.preheader
	lsl	x2, x21, #3
	add	x8, x19, x22, lsl #3
	add	x0, x8, #8
	add	x1, x20, #8
	bl	_memcpy
LBB113_2:                               ; %run.move.done.v3
	add	x8, x22, x21
	str	xzr, [x20]
	str	x8, [x19]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_place_back$instance$14527b91a946204e ; -- Begin function wf_place_back$instance$14527b91a946204e
	.p2align	2
_wf_place_back$instance$14527b91a946204e: ; @"wf_place_back$instance$14527b91a946204e"
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	mov	x19, x0
	ldr	x20, [x0]
	mov	w8, #280                        ; =0x118
	madd	x8, x20, x8, x0
	add	x0, x8, #8
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	add	x8, x20, #1
	str	x8, [x19]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_place_back$instance$d09c0308a37bc3d3 ; -- Begin function wf_place_back$instance$d09c0308a37bc3d3
	.p2align	2
_wf_place_back$instance$d09c0308a37bc3d3: ; @"wf_place_back$instance$d09c0308a37bc3d3"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	add	x9, x0, x8, lsl #3
	str	x1, [x9, #8]
	add	x8, x8, #1
	str	x8, [x0]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_swap$instance$8a9ddfa029d2f6d8 ; -- Begin function wf_swap$instance$8a9ddfa029d2f6d8
	.p2align	2
_wf_swap$instance$8a9ddfa029d2f6d8:     ; @"wf_swap$instance$8a9ddfa029d2f6d8"
; %bb.0:                                ; %entry
	ldr	q0, [x0]
	str	q0, [sp, #-16]!
	ldr	q1, [x1]
	str	q1, [x0]
	str	q0, [x1]
	mov	w0, #0                          ; =0x0
	add	sp, sp, #16
	ret
                                        ; -- End function
	.globl	_wf_take_back$instance$0270a1f1e6dbd4ef ; -- Begin function wf_take_back$instance$0270a1f1e6dbd4ef
	.p2align	2
_wf_take_back$instance$0270a1f1e6dbd4ef: ; @"wf_take_back$instance$0270a1f1e6dbd4ef"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	sub	x8, x8, #1
	add	x9, x0, x8, lsl #3
	str	x8, [x0]
	ldr	x0, [x9, #8]
	ret
                                        ; -- End function
	.globl	_wf_free_empty$instance$a98c08577aae5c25 ; -- Begin function wf_free_empty$instance$a98c08577aae5c25
	.p2align	2
_wf_free_empty$instance$a98c08577aae5c25: ; @"wf_free_empty$instance$a98c08577aae5c25"
; %bb.0:                                ; %entry
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_free_empty$instance$da190c5295df38da ; -- Begin function wf_free_empty$instance$da190c5295df38da
	.p2align	2
_wf_free_empty$instance$da190c5295df38da: ; @"wf_free_empty$instance$da190c5295df38da"
; %bb.0:                                ; %entry
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_swap$instance$92cd3375584bbc81 ; -- Begin function wf_swap$instance$92cd3375584bbc81
	.p2align	2
_wf_swap$instance$92cd3375584bbc81:     ; @"wf_swap$instance$92cd3375584bbc81"
; %bb.0:                                ; %entry
	sub	sp, sp, #320
	stp	x28, x27, [sp, #272]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #288]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #304]            ; 16-byte Folded Spill
	mov	x19, x1
	mov	x20, x0
	add	x0, sp, #8
	mov	x1, x20
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	mov	x0, x20
	mov	x1, x19
	mov	w2, #264                        ; =0x108
	bl	_memmove
	add	x1, sp, #8
	mov	x0, x19
	mov	w2, #264                        ; =0x108
	bl	_memcpy
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #304]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #288]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #272]            ; 16-byte Folded Reload
	add	sp, sp, #320
	ret
                                        ; -- End function
	.globl	_wf_take_back$instance$d09c0308a37bc3d3 ; -- Begin function wf_take_back$instance$d09c0308a37bc3d3
	.p2align	2
_wf_take_back$instance$d09c0308a37bc3d3: ; @"wf_take_back$instance$d09c0308a37bc3d3"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	sub	x8, x8, #1
	add	x9, x0, x8, lsl #3
	str	x8, [x0]
	ldr	x0, [x9, #8]
	ret
                                        ; -- End function
	.globl	_wf_free_empty$instance$fcdc37d8a2bcbb32 ; -- Begin function wf_free_empty$instance$fcdc37d8a2bcbb32
	.p2align	2
_wf_free_empty$instance$fcdc37d8a2bcbb32: ; @"wf_free_empty$instance$fcdc37d8a2bcbb32"
; %bb.0:                                ; %entry
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_free_empty$instance$a8c3c22f03c46f30 ; -- Begin function wf_free_empty$instance$a8c3c22f03c46f30
	.p2align	2
_wf_free_empty$instance$a8c3c22f03c46f30: ; @"wf_free_empty$instance$a8c3c22f03c46f30"
; %bb.0:                                ; %entry
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_take_back$instance$f2ca242ae19e388d ; -- Begin function wf_take_back$instance$f2ca242ae19e388d
	.p2align	2
_wf_take_back$instance$f2ca242ae19e388d: ; @"wf_take_back$instance$f2ca242ae19e388d"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	sub	x8, x8, #1
	add	x9, x1, x8, lsl #5
	str	x8, [x1]
	ldur	q0, [x9, #8]
	ldur	q1, [x9, #24]
	stp	q0, q1, [x0]
	ret
                                        ; -- End function
	.globl	_wf_take_back$instance$14527b91a946204e ; -- Begin function wf_take_back$instance$14527b91a946204e
	.p2align	2
_wf_take_back$instance$14527b91a946204e: ; @"wf_take_back$instance$14527b91a946204e"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	sub	x9, x8, #1
	mov	w10, #280                       ; =0x118
	madd	x8, x8, x10, x1
	sub	x8, x8, #272
	str	x9, [x1]
	mov	x1, x8
	mov	w2, #280                        ; =0x118
	b	_memcpy
                                        ; -- End function
	.globl	_wf_insert_at$instance$f2ca242ae19e388d ; -- Begin function wf_insert_at$instance$f2ca242ae19e388d
	.p2align	2
_wf_insert_at$instance$f2ca242ae19e388d: ; @"wf_insert_at$instance$f2ca242ae19e388d"
; %bb.0:                                ; %entry
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	mov	x19, x2
	mov	x20, x0
	ldr	x21, [x0]
	sub	x8, x21, x1
	add	x22, x0, x1, lsl #5
	lsl	x2, x8, #5
	add	x0, x22, #40
	add	x1, x22, #8
	bl	_memmove
	add	x8, x21, #1
	str	x8, [x20]
	ldp	q0, q1, [x19]
	stur	q0, [x22, #8]
	stur	q1, [x22, #24]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_swap$instance$540750c06c323435 ; -- Begin function wf_swap$instance$540750c06c323435
	.p2align	2
_wf_swap$instance$540750c06c323435:     ; @"wf_swap$instance$540750c06c323435"
; %bb.0:                                ; %entry
	ldp	q0, q1, [x0]
	stp	q0, q1, [sp, #-32]!
	ldp	q3, q2, [x1]
	stp	q3, q2, [x0]
	stp	q0, q1, [x1]
	mov	w0, #0                          ; =0x0
	add	sp, sp, #32
	ret
                                        ; -- End function
	.globl	_wf_remove_at$instance$f2ca242ae19e388d ; -- Begin function wf_remove_at$instance$f2ca242ae19e388d
	.p2align	2
_wf_remove_at$instance$f2ca242ae19e388d: ; @"wf_remove_at$instance$f2ca242ae19e388d"
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	mov	x19, x1
	add	x8, x1, x2, lsl #5
	ldur	q0, [x8, #8]
	ldur	q1, [x8, #24]
	stp	q0, q1, [x0]
	ldr	x20, [x1]
	mvn	x9, x2
	add	x9, x20, x9
	lsl	x2, x9, #5
	add	x0, x8, #8
	add	x1, x8, #40
	bl	_memmove
	sub	x8, x20, #1
	str	x8, [x19]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_insert_at$instance$14527b91a946204e ; -- Begin function wf_insert_at$instance$14527b91a946204e
	.p2align	2
_wf_insert_at$instance$14527b91a946204e: ; @"wf_insert_at$instance$14527b91a946204e"
; %bb.0:                                ; %entry
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	mov	x19, x2
	mov	x20, x0
	ldr	x21, [x0]
	sub	x8, x21, x1
	mov	w9, #280                        ; =0x118
	madd	x22, x1, x9, x0
	mul	x2, x8, x9
	add	x0, x22, #288
	add	x1, x22, #8
	bl	_memmove
	add	x8, x21, #1
	str	x8, [x20]
	add	x0, x22, #8
	mov	x1, x19
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_swap$instance$0ff094122dba9aec ; -- Begin function wf_swap$instance$0ff094122dba9aec
	.p2align	2
_wf_swap$instance$0ff094122dba9aec:     ; @"wf_swap$instance$0ff094122dba9aec"
; %bb.0:                                ; %entry
	sub	sp, sp, #336
	stp	x28, x27, [sp, #288]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #304]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #320]            ; 16-byte Folded Spill
	mov	x19, x1
	mov	x20, x0
	add	x0, sp, #8
	mov	x1, x20
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	mov	x0, x20
	mov	x1, x19
	mov	w2, #280                        ; =0x118
	bl	_memmove
	add	x1, sp, #8
	mov	x0, x19
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #320]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #304]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #288]            ; 16-byte Folded Reload
	add	sp, sp, #336
	ret
                                        ; -- End function
	.globl	_wf_remove_at$instance$14527b91a946204e ; -- Begin function wf_remove_at$instance$14527b91a946204e
	.p2align	2
_wf_remove_at$instance$14527b91a946204e: ; @"wf_remove_at$instance$14527b91a946204e"
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	mov	x19, x2
	mov	x20, x1
	mov	w21, #280                       ; =0x118
	madd	x22, x2, x21, x1
	add	x1, x22, #8
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	ldr	x23, [x20]
	mvn	x8, x19
	add	x8, x23, x8
	mul	x2, x8, x21
	add	x0, x22, #8
	add	x1, x22, #288
	bl	_memmove
	sub	x8, x23, #1
	str	x8, [x20]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_swap$instance$da190c5295df38da ; -- Begin function wf_swap$instance$da190c5295df38da
	.p2align	2
_wf_swap$instance$da190c5295df38da:     ; @"wf_swap$instance$da190c5295df38da"
; %bb.0:                                ; %entry
	ldr	q0, [x0]
	str	q0, [sp, #-16]!
	ldr	q1, [x1]
	str	q1, [x0]
	str	q0, [x1]
	mov	w0, #0                          ; =0x0
	add	sp, sp, #16
	ret
                                        ; -- End function
	.globl	_wf_append$instance$d5eecd37872eaac2 ; -- Begin function wf_append$instance$d5eecd37872eaac2
	.p2align	2
_wf_append$instance$d5eecd37872eaac2:   ; @"wf_append$instance$d5eecd37872eaac2"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cbz	x8, LBB133_3
; %bb.1:                                ; %run.move.body.v3.preheader
	mov	x10, #0                         ; =0x0
	add	x11, x0, x9, lsl #5
	add	x11, x11, #8
	add	x12, x1, #8
LBB133_2:                               ; %run.move.body.v3
                                        ; =>This Inner Loop Header: Depth=1
	add	x10, x10, #1
	ldp	q0, q1, [x12], #32
	stp	q0, q1, [x11], #32
	cmp	x8, x10
	b.ne	LBB133_2
LBB133_3:                               ; %run.move.done.v3
	add	x8, x9, x8
	str	xzr, [x1]
	str	x8, [x0]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_swap$instance$a8c3c22f03c46f30 ; -- Begin function wf_swap$instance$a8c3c22f03c46f30
	.p2align	2
_wf_swap$instance$a8c3c22f03c46f30:     ; @"wf_swap$instance$a8c3c22f03c46f30"
; %bb.0:                                ; %entry
	ldr	q0, [x0]
	str	q0, [sp, #-16]!
	ldr	q1, [x1]
	str	q1, [x0]
	str	q0, [x1]
	mov	w0, #0                          ; =0x0
	add	sp, sp, #16
	ret
                                        ; -- End function
	.globl	_wf_append$instance$252e05fd84976d22 ; -- Begin function wf_append$instance$252e05fd84976d22
	.p2align	2
_wf_append$instance$252e05fd84976d22:   ; @"wf_append$instance$252e05fd84976d22"
; %bb.0:                                ; %entry
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	mov	x20, x1
	mov	x19, x0
	ldr	x23, [x1]
	ldr	x24, [x0]
	cbz	x23, LBB135_3
; %bb.1:                                ; %run.move.body.v3.preheader
	mov	x25, #0                         ; =0x0
	mov	w8, #280                        ; =0x118
	madd	x8, x24, x8, x19
	add	x21, x8, #8
	add	x22, x20, #8
LBB135_2:                               ; %run.move.body.v3
                                        ; =>This Inner Loop Header: Depth=1
	add	x25, x25, #1
	mov	x0, x21
	mov	x1, x22
	mov	w2, #280                        ; =0x118
	bl	_memcpy
	add	x21, x21, #280
	add	x22, x22, #280
	cmp	x23, x25
	b.ne	LBB135_2
LBB135_3:                               ; %run.move.done.v3
	add	x8, x24, x23
	str	xzr, [x20]
	str	x8, [x19]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf__floor_run                  ; -- Begin function wf__floor_run
	.weak_definition	_wf__floor_run
	.p2align	2
_wf__floor_run:                         ; @wf__floor_run
	.cfi_startproc
; %bb.0:                                ; %entry
	b	_wf__main_body
	.cfi_endproc
                                        ; -- End function
	.globl	_wf__main_body                  ; -- Begin function wf__main_body
	.p2align	2
_wf__main_body:                         ; @wf__main_body
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	bl	_wf_ordered_cost_trace$instance$fa3caca27a003293
	mov	x0, #0                          ; =0x0
	mov	x1, #0                          ; =0x0
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	bl	_wf_ordered_cost_trace$instance$ff5e39efec5d08ee
	mov	x0, sp
	mov	w1, #0                          ; =0x0
	bl	_wf_std.process.exit_status
	mov	x0, sp
	bl	_wf__ordinary_exit_code
	and	w0, w0, #0xff
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_main                           ; -- Begin function main
	.p2align	2
_main:                                  ; @main
	.cfi_startproc
; %bb.0:                                ; %entry
	b	_wf__floor_run
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__const
l_.wf_resource.heap:                    ; @.wf_resource.heap
	.ascii	"{\"resource\":\"heap\"}\n"

.subsections_via_symbols
