_wf_collections.ordered_map.ordered_map_lookup_link$instance$11eb30e8dabe0f7e: ; @"wf_collections.ordered_map.ordered_map_lookup_link$instance$11eb30e8dabe0f7e"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB7_6
; %bb.1:                                ; %bb2.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #8]
	mov	x8, x0
	ldr	x10, [x8, #16]!
	cbz	x10, LBB7_7
; %bb.2:                                ; %bb2.lr.ph.i
	mov	x9, #0                          ; =0x0
	add	x11, x0, #24
	ldr	x12, [x1]
LBB7_3:                                 ; %bb2.i4
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x13, [x11], #32
	cmp	x12, x13
	b.ls	LBB7_8
; %bb.4:                                ; %bb8.i
                                        ;   in Loop: Header=BB7_3 Depth=1
	add	x9, x9, #1
	cmp	x10, x9
	b.ne	LBB7_3
; %bb.5:
	add	x8, x8, x10, lsl #5
	sub	x0, x8, #8
	bl	_wf_collections.ordered_map.ordered_map_lookup_link$instance$11eb30e8dabe0f7e
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	mov	w2, #0                          ; =0x0
	ret
LBB7_6:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	ret
LBB7_7:
	mov	x9, #0                          ; =0x0
LBB7_8:                                 ; %"wf_collections.ordered_map.ordered_map_search$instance$5046b787ff5cdb3f.exit"
	cmp	x9, x10
	b.hs	LBB7_11
; %bb.9:                                ; %bb2.i.i
	add	x11, x8, x9, lsl #5
	ldr	x10, [x1]
	ldr	x12, [x11, #8]
	cmp	x10, x12
	b.ne	LBB7_11
; %bb.10:                               ; %bb5.i.i
	mov	w0, #0                          ; =0x0
	ldr	x8, [x11, #16]
	mov	w9, #131                        ; =0x83
	madd	x1, x10, x9, x8
	ldr	x8, [x2]
	madd	x8, x8, x9, x1
	str	x8, [x2]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	mov	w2, #0                          ; =0x0
	ret
LBB7_11:                                ; %bb1.i.i
	cbz	x9, LBB7_13
; %bb.12:                               ; %bb9.i.i
	add	x8, x8, x9, lsl #5
	sub	x0, x8, #8
LBB7_13:                                ; %bb8.i.i
	bl	_wf_collections.ordered_map.ordered_map_lookup_link$instance$11eb30e8dabe0f7e
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	mov	w2, #0                          ; =0x0
	ret
                                        ; -- End function