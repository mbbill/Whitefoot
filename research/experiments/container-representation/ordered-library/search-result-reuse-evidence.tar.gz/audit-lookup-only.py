from pathlib import Path
import re,json
p=Path(__file__).resolve().parent
def bodies(s):
 out={}
 s=s.replace('wf_collections.ordered_map.','wf_std.collections.ordered_map.')
 for b in re.findall(r'^_wf_[^\n]+:.*?; -- End function',s,re.M|re.S):
  name=b.splitlines()[0].split(':')[0]
  code='\n'.join(line.split(';')[0].rstrip() for line in b.splitlines() if line.split(';')[0].strip())
  labs={m:f'BB{i}' for i,m in enumerate(re.findall(r'^(LBB\d+_\d+):',code,re.M))}
  for old in sorted(labs,key=len,reverse=True):code=re.sub(r'\b'+old+r'\b',labs[old],code)
  out[name]=code
 return out
result={}
for mode in ['public','normal','retained']:
 control='control.public.s' if mode=='public' else f'control.{mode}.screen.s'
 a=bodies((p/control).read_text());b=bodies((p/f'lookup-only.{mode}.screen.s').read_text())
 changed=[name for name,v in a.items() if 'ordered_map_lookup' not in name and (name not in b or v!=b[name])]
 assert not changed,changed
 priorfile={'public':'candidate-guard.public.s','normal':'prior-candidate.normal.screen.s','retained':'candidate.retained.s'}[mode]
 prior=bodies((p/priorfile).read_text())
 lookup=[name for name in a if 'ordered_map_lookup' in name and a[name]!=b.get(name)]
 assert len(lookup)==2
 assert all(b[name]==prior[name] for name in lookup)
 result[mode]={'existing_bodies':len(a),'new_bodies':len(b.keys()-a.keys()),'changed_nonlookup':changed,'lookup_matches_prior':lookup}
print(json.dumps(result,indent=2))
