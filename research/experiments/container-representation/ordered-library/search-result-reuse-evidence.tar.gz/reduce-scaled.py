from pathlib import Path
import csv,json,statistics
p=Path(__file__).resolve().parent
data={}
for f in p.glob('*-scaled-cohort*.csv'):
 arm,mode,scaled,cohort=f.stem.split('-')
 for row in csv.DictReader(f.open()):
  if row['sample']=='0':continue
  key=(arm,mode,cohort,row['pair_bytes'],row['path'],row['count'],row['sample'])
  data.setdefault(key,{})[row['variant']]=int(row['elapsed_ns'])
clocks=[int(r['quantum_ns']) for f in p.glob('*-scaled-clock.csv') for r in csv.DictReader(f.open())]
threshold=max(1000000,1000*max(clocks))
def admitted(windows,medians):
 return min(windows)>=threshold and max(medians)/min(medians)<=1.10
assert not admitted([threshold-1],[1,1,1,1])
assert not admitted([threshold],[1,1,1,1.11])
assert admitted([threshold],[1,1,1,1.10])
rows=[]
for mode in ['normal','retained']:
 for cell in sorted(set(k[3:6] for k in data if k[1]==mode)):
  outcomes=[];ratios=[];ranges=[];medians=[];windows=[];peer_ratios=[]
  for cohort in ['cohort0','cohort1']:
   arms=[];raw=[]
   for arm in ['control','candidate']:
    vals=[data[(arm,mode,cohort,*cell,str(i))] for i in range(1,6)]
    arms.append([v['whitefoot']/v['source-c'] for v in vals]);raw.append(vals)
    windows += [v[name] for v in vals for name in ['whitefoot','source-c']]
    medians.append(statistics.median(v['source-c'] for v in vals))
   a,b=arms
   outcomes.append('gain' if max(b)<min(a) else 'loss' if min(b)>max(a) else 'overlap')
   ratios.append(statistics.median(b)/statistics.median(a));ranges.append([min(a),max(a),min(b),max(b)])
   peer_ratios.append({name:statistics.median(v[name] for v in raw[1])/statistics.median(v[name] for v in raw[0]) for name in ['source-c','direct-c','avl-c']})
  admission=admitted(windows,medians)
  direction=(outcomes[0] if outcomes[0]==outcomes[1] else 'mixed') if admission else 'unadmitted'
  rows.append({'mode':mode,'cell':cell,'admitted':admission,'direction':direction,'cohorts':outcomes,'median_ratio':ratios,'ratio_ranges':ranges,'source_drift':max(medians)/min(medians),'window_min_ns':min(windows),'window_max_ns':max(windows),'peer_median_ratios':peer_ratios})
result={'clock_quantum_ns':max(clocks),'threshold_ns':threshold,'admission_negative_controls':'short interval and >10% source drift both refuse; boundary valid case admits','cells':rows}
(p/'scaled-reduction.json').write_text(json.dumps(result,indent=2))
print('summary',{d:sum(r['direction']==d for r in rows) for d in ['gain','loss','overlap','mixed','unadmitted']})
for r in rows:print(r)
