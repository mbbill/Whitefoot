_wf_collections.ordered_map.ordered_map_lookup_link$instance$11eb30e8dabe0f7e: ; @"wf_collections.ordered_map.ordered_map_lookup_link$instance$11eb30e8dabe0f7e"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB7_6
; %bb.1:                                ; %bb2.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #8]
	ldr	x9, [x0, #16]
	cbz	x9, LBB7_10
; %bb.2:                                ; %bb2.lr.ph.i.i
	mov	x8, #0                          ; =0x0
	add	x10, x0, #24
	ldr	x11, [x1]
LBB7_3:                                 ; %bb2.i.i2
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x12, [x10]
	cmp	x11, x12
	b.ls	LBB7_7
; %bb.4:                                ; %bb8.i.i5
                                        ;   in Loop: Header=BB7_3 Depth=1
	add	x8, x8, #1
	add	x10, x10, #32
	cmp	x9, x8
	b.ne	LBB7_3
; %bb.5:
	add	x8, x0, x9, lsl #5
	add	x0, x8, #8
	bl	_wf_collections.ordered_map.ordered_map_lookup_link$instance$11eb30e8dabe0f7e
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	mov	w2, #0                          ; =0x0
	ret
LBB7_6:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	ret
LBB7_7:                                 ; %"wf_collections.ordered_map.ordered_map_search$instance$5046b787ff5cdb3f.exit"
	ccmp	x8, x9, #2, hs
	b.lo	LBB7_11
; %bb.8:                                ; %bb1.i.i
	cbz	x8, LBB7_10
; %bb.9:                                ; %bb9.i.i
	add	x8, x0, x8, lsl #5
	add	x0, x8, #8
LBB7_10:                                ; %bb8.i.i
	bl	_wf_collections.ordered_map.ordered_map_lookup_link$instance$11eb30e8dabe0f7e
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	mov	w2, #0                          ; =0x0
	ret
LBB7_11:                                ; %bb5.i.i
	mov	w0, #0                          ; =0x0
	ldp	x8, x9, [x10]
	mov	w10, #131                       ; =0x83
	madd	x1, x8, x10, x9
	ldr	x8, [x2]
	madd	x8, x8, x10, x1
	str	x8, [x2]
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	mov	w2, #0                          ; =0x0
	ret
                                        ; -- End function