_wf_collections.ordered_map.ordered_map_lookup_node$instance$11eb30e8dabe0f7e: ; @"wf_collections.ordered_map.ordered_map_lookup_node$instance$11eb30e8dabe0f7e"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x10, [x0, #16]
	cbz	x10, LBB74_9
; %bb.1:                                ; %bb2.lr.ph.i.i
	mov	x8, #0                          ; =0x0
	add	x9, x0, #24
	ldr	x11, [x1]
LBB74_2:                                ; %bb2.i.i23
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x12, [x9]
	cmp	x11, x12
	b.ls	LBB74_5
; %bb.3:                                ; %bb8.i.i
                                        ;   in Loop: Header=BB74_2 Depth=1
	add	x8, x8, #1
	add	x9, x9, #32
	cmp	x10, x8
	b.ne	LBB74_2
; %bb.4:
	mov	x8, x10
	b	LBB74_7
LBB74_5:                                ; %"wf_collections.ordered_map.ordered_map_search$instance$5046b787ff5cdb3f.exit"
	ccmp	x8, x10, #2, hs
	b.lo	LBB74_13
; %bb.6:                                ; %bb1.i
	cbz	x8, LBB74_9
LBB74_7:                                ; %bb9.i
	add	x8, x0, x8, lsl #5
	ldr	x9, [x8, #8]
	cbz	x9, LBB74_12
; %bb.8:                                ; %bb2.i.i
	sub	x8, x8, #8
	ldr	x0, [x8, #24]
	b	LBB74_11
LBB74_9:                                ; %bb8.i
	ldr	x8, [x0]
	cbz	x8, LBB74_12
; %bb.10:                               ; %bb2.i.i16
	ldr	x0, [x0, #8]
LBB74_11:                               ; %"wf_collections.ordered_map.ordered_map_lookup_node$instance$11eb30e8dabe0f7e.body.exit"
	bl	_wf_collections.ordered_map.ordered_map_lookup_node$instance$11eb30e8dabe0f7e
	b	LBB74_14
LBB74_12:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	b	LBB74_14
LBB74_13:                               ; %bb5.i
	mov	w0, #0                          ; =0x0
	mov	w8, #131                        ; =0x83
	ldp	x10, x9, [x9]
	madd	x1, x10, x8, x9
	ldr	x9, [x3]
	madd	x8, x9, x8, x1
	str	x8, [x3]
LBB74_14:                               ; %"wf_collections.ordered_map.ordered_map_lookup_node$instance$11eb30e8dabe0f7e.body.exit"
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function