	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function wf_resource_record_abort
l_wf_resource_record_abort:             ; @wf_resource_record_abort
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
Lloh0:
	adrp	x19, l_.wf_resource.heap@PAGE
Lloh1:
	add	x19, x19, l_.wf_resource.heap@PAGEOFF
	mov	w20, #20                        ; =0x14
	b	LBB0_2
LBB0_1:                                 ; %error.i
                                        ;   in Loop: Header=BB0_2 Depth=1
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #4
	b.ne	LBB0_6
LBB0_2:                                 ; %write.i
                                        ; =>This Inner Loop Header: Depth=1
	mov	w0, #2                          ; =0x2
	mov	x1, x19
	mov	x2, x20
	bl	_write
	tbnz	x0, #63, LBB0_1
; %bb.3:                                ; %wf_resource_write.exit
                                        ;   in Loop: Header=BB0_2 Depth=1
	subs	x20, x20, x0
	b.eq	LBB0_6
; %bb.4:                                ; %wf_resource_write.exit
                                        ;   in Loop: Header=BB0_2 Depth=1
	cbz	x0, LBB0_6
; %bb.5:                                ; %write.more
                                        ;   in Loop: Header=BB0_2 Depth=1
	add	x19, x19, x0
	b	LBB0_2
LBB0_6:                                 ; %abort
	bl	_abort
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_resource_abort
l_wf_resource_abort:                    ; @wf_resource_abort
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	l_wf_resource_record_abort
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_indexed_cost_small_trace
lCPI2_0:
	.quad	17                              ; 0x11
	.quad	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_indexed_cost_small_trace
	.p2align	2
_wf_indexed_cost_small_trace:           ; @wf_indexed_cost_small_trace
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #656
	.cfi_def_cfa_offset 752
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x4
	mov	x27, x3
	mov	x23, x2
	mov	x24, x1
	mov	x21, x0
	lsl	x28, x0, #1
	cmp	x3, #0
	csel	x22, x28, xzr, eq
	cbz	x0, LBB2_8
; %bb.1:                                ; %window.payload.allocate.v1.i.i.i.i.i
	lsl	x8, x21, #6
	sub	x0, x8, x21, lsl #3
	bl	_malloc
	mov	x25, x0
	cbz	x0, LBB2_7
; %bb.2:                                ; %"wf_std.collections.slab.slab_new$instance$50cad5863314d34d.exit.i.i"
	str	x27, [sp, #40]                  ; 8-byte Folded Spill
	cbz	x22, LBB2_9
LBB2_3:                                 ; %window.payload.allocate.v1.i.i.i2.i.i
	lsl	x20, x22, #5
	mov	x0, x20
	bl	_malloc
	cbz	x0, LBB2_7
; %bb.4:                                ; %bb5.i.i.i.i.preheader
	mov	x26, x0
	mov	x8, #0                          ; =0x0
	add	x9, x0, #8
LBB2_5:                                 ; %bb5.i.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x9, #8]
	str	xzr, [x9], #32
	cmp	x22, x8
	b.ne	LBB2_5
; %bb.6:                                ; %window.payload.allocate.v1.i.i.i.i
	mov	x0, x20
	bl	_malloc
	cbnz	x0, LBB2_10
LBB2_7:                                 ; %window.block.oom.v1.i.i.i.i.i
	bl	l_wf_resource_abort
LBB2_8:
Lloh2:
	adrp	x25, l_.wf.empty.slots.payload@PAGE
Lloh3:
	add	x25, x25, l_.wf.empty.slots.payload@PAGEOFF
	str	x27, [sp, #40]                  ; 8-byte Folded Spill
	cbnz	x22, LBB2_3
LBB2_9:
Lloh4:
	adrp	x26, l_.wf.empty.slots.payload@PAGE
Lloh5:
	add	x26, x26, l_.wf.empty.slots.payload@PAGEOFF
	mov	x0, x26
LBB2_10:                                ; %"wf_record_store_new$instance$d656314a40e34216.exit.i"
Lloh6:
	adrp	x8, lCPI2_0@PAGE
Lloh7:
	ldr	q0, [x8, lCPI2_0@PAGEOFF]
	add	x27, sp, #48
	add	x20, x27, #440
	str	q0, [x20]
	cmp	x23, #0
	cset	w8, ne
	strb	w8, [x20, #8]
	stp	xzr, x21, [sp, #504]
	str	x25, [sp, #520]
	str	x21, [sp, #528]
	str	x22, [sp, #536]
	str	x22, [sp, #544]
	str	x26, [sp, #552]
	str	xzr, [sp, #560]
	str	xzr, [sp, #576]
	str	xzr, [sp, #568]
	str	x22, [sp, #584]
	str	x0, [sp, #592]
	mov	w8, #8192                       ; =0x2000
	lsl	x26, x21, #2
	str	x8, [sp, #600]
	cbz	x21, LBB2_105
; %bb.11:                               ; %bb5.i.preheader
	stp	x28, x23, [sp, #24]             ; 16-byte Folded Spill
	mov	x25, #0                         ; =0x0
	mov	w22, #8191                      ; =0x1fff
	mov	w27, #1                         ; =0x1
	mov	x28, #32557                     ; =0x7f2d
	movk	x28, #19605, lsl #16
	movk	x28, #62509, lsl #32
	movk	x28, #22609, lsl #48
	mov	x23, #33103                     ; =0x814f
	movk	x23, #63335, lsl #16
	movk	x23, #31614, lsl #32
	movk	x23, #5125, lsl #48
LBB2_12:                                ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	madd	x24, x24, x28, x23
	lsr	x8, x24, #32
	udiv	x9, x8, x26
	msub	x8, x9, x26, x8
	and	x9, x25, #0x7
	cmp	x9, #1
	csel	x2, x22, x27, eq
	add	x25, x25, #1
	add	x4, x8, x26
	mov	x0, x20
	mov	x1, x19
	mov	x3, x25
	bl	_wf_indexed_cost_insert$instance$2b4e452a2d5f5791
	add	x22, x22, #2
	add	x27, x27, #2
	cmp	x21, x25
	b.ne	LBB2_12
; %bb.13:                               ; %bb7.thread.i
	add	x3, x21, #1
	mov	x0, x20
	mov	x1, x19
	mov	x2, #-1                         ; =0xffffffffffffffff
	mov	x4, #0                          ; =0x0
	bl	_wf_indexed_cost_insert$instance$2b4e452a2d5f5791
	add	x27, sp, #48
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	cbnz	x8, LBB2_106
; %bb.14:                               ; %bb13.lr.ph.i
	mov	x24, #0                         ; =0x0
	mov	w25, #19867                     ; =0x4d9b
	movk	w25, #34, lsl #16
	add	x8, x21, #2
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	lsl	x8, x21, #4
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	mov	w22, #8191                      ; =0x1fff
	mov	w28, #131                       ; =0x83
	b	LBB2_16
LBB2_15:                                ; %bb25.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	add	x24, x24, #1
	cmp	x24, x21
	b.eq	LBB2_107
LBB2_16:                                ; %bb13.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB2_52 Depth 2
	lsl	x8, x24, #1
	and	x9, x24, #0x7
	add	x10, x8, x22
	cmp	x9, #1
	csinc	x23, x10, x8, eq
	add	x0, sp, #48
	mov	x1, x20
	mov	x2, x19
	mov	x3, x23
	bl	_wf_indexed_cost_lookup$instance$174c6fc95f4077f6
	ldr	w8, [sp, #48]
	cbnz	w8, LBB2_15
; %bb.17:                               ; %bb17.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	add	x9, sp, #48
	ldur	x8, [x9, #24]
	stur	x8, [x27, #48]
	add	x17, sp, #48
	ldur	q0, [x9, #8]
	stur	q0, [x27, #32]
	ldr	x9, [sp, #80]
	ldr	x10, [sp, #488]
	cmp	x9, x10
	b.ne	LBB2_33
; %bb.18:                               ; %bb3.i.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x8, [sp, #88]
	ldr	x11, [sp, #504]
	cmp	x8, x11
	mov	w16, #17161                     ; =0x4309
	mov	w0, #1                          ; =0x1
	b.hs	LBB2_34
; %bb.19:                               ; %bb2.i.i.i.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x12, [sp, #96]
	ldr	x11, [sp, #520]
	mov	w13, #56                        ; =0x38
	madd	x11, x8, x13, x11
	ldr	x8, [x11, #40]
	cmp	x8, x12
	b.ne	LBB2_34
; %bb.20:                               ; %bb5.i.i.i.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x8, [x11]
	cbz	x8, LBB2_34
; %bb.21:                               ; %bb8.i.i.i.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldp	x10, x9, [x19, #24]
	ldp	x8, x12, [x19]
	cmp	x8, x12
	b.hs	LBB2_23
; %bb.22:                               ; %bb2.i.i.i.i.i.i49.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x13, [x19, #16]
	mov	w14, #5                         ; =0x5
	str	x14, [x13, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB2_23:                                ; %wf_indexed_cost_word.exit.i.i.i.i.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x13, [x11, #8]
	cmp	x8, x12
	b.hs	LBB2_25
; %bb.24:                               ; %bb2.i12.i.i.i.i.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x14, [x19, #16]
	str	x13, [x14, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB2_25:                                ; %wf_indexed_cost_word.exit18.i.i.i.i.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	madd	x10, x10, x16, x13
	add	x10, x10, #655
	ldr	x11, [x11, #16]
	madd	x10, x10, x28, x11
	add	x9, x9, #3
	stp	x10, x9, [x19, #24]
	cmp	x8, x12
	b.hs	LBB2_27
; %bb.26:                               ; %bb2.i.i.i.i.i.i.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x9, [x19, #16]
	str	x11, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	ldp	x10, x9, [x19, #24]
LBB2_27:                                ; %bb20.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	str	wzr, [sp, #104]
	strb	wzr, [sp, #108]
	str	wzr, [sp, #112]
	ldr	x12, [x19, #8]
	cmp	x8, x12
	b.hs	LBB2_92
; %bb.28:                               ; %bb2.i.i265.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x11, [x19, #16]
	str	x0, [x11, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x12
	b.lo	LBB2_93
LBB2_29:                                ; %wf_indexed_cost_word.exit18.i234.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	cmp	x8, x12
	b.hs	LBB2_31
LBB2_30:                                ; %bb2.i30.i253.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x11, [x19, #16]
	str	x23, [x11, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB2_31:                                ; %wf_indexed_cost_word.exit36.i239.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	madd	x10, x10, x25, x23
	mov	w11, #18733                     ; =0x492d
	add	x10, x10, x11
	mul	x10, x10, x28
	add	x11, x9, #4
	stp	x10, x11, [x19, #24]
	cmp	x8, x12
	b.hs	LBB2_41
; %bb.32:                               ;   in Loop: Header=BB2_16 Depth=1
	mov	x9, #0                          ; =0x0
	b	LBB2_40
LBB2_33:                                ;   in Loop: Header=BB2_16 Depth=1
	mov	w8, #4                          ; =0x4
	mov	w16, #17161                     ; =0x4309
	mov	w0, #1                          ; =0x1
	b	LBB2_35
LBB2_34:                                ;   in Loop: Header=BB2_16 Depth=1
	mov	w8, #3                          ; =0x3
LBB2_35:                                ; %bb21.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	str	w0, [sp, #104]
	strb	wzr, [sp, #108]
	str	w8, [sp, #112]
	ldp	x13, x11, [x19, #24]
	ldp	x8, x12, [x19]
	cmp	x8, x12
	b.hs	LBB2_47
; %bb.36:                               ; %bb2.i.i326.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x14, [x19, #16]
	str	x0, [x14, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x12
	b.lo	LBB2_48
LBB2_37:                                ; %wf_indexed_cost_word.exit18.i285.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	cmp	x8, x12
	b.hs	LBB2_39
LBB2_38:                                ; %bb2.i30.i314.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x14, [x19, #16]
	str	x23, [x14, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB2_39:                                ; %wf_indexed_cost_word.exit36.i290.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	madd	x13, x13, x25, x23
	mov	w14, #18733                     ; =0x492d
	add	x13, x13, x14
	cmp	x9, x10
	mov	w9, #3                          ; =0x3
	cinc	x9, x9, ne
	madd	x10, x13, x28, x9
	add	x11, x11, #4
	stp	x10, x11, [x19, #24]
	cmp	x8, x12
	b.hs	LBB2_41
LBB2_40:                                ; %bb19.sink.split.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x10, [x19, #16]
	str	x9, [x10, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	ldp	x10, x11, [x19, #24]
LBB2_41:                                ; %bb19.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x12, [x19, #8]
	cmp	x8, x12
	b.hs	LBB2_43
; %bb.42:                               ; %bb2.i.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x9, [x19, #16]
	mov	w13, #3                         ; =0x3
	str	x13, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB2_43:                                ; %wf_indexed_cost_word.exit.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x9, [sp, #40]                   ; 8-byte Folded Reload
	add	x9, x9, x24
	madd	x10, x10, x16, x9
	add	x10, x10, #393
	add	x11, x11, #2
	stp	x10, x11, [x19, #24]
	cmp	x8, x12
	b.hs	LBB2_45
; %bb.44:                               ; %bb2.i12.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x10, [x19, #16]
	str	x9, [x10, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB2_45:                                ; %wf_indexed_cost_offer.exit.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	str	x9, [sp, #120]
	ldr	x10, [sp, #600]
	cbz	x10, LBB2_49
; %bb.46:                               ; %bb3.i.i.i.i.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	udiv	x11, x23, x10
	msub	x11, x11, x10, x23
	ldr	x10, [sp, #536]
	cbnz	x10, LBB2_50
	b	LBB2_60
LBB2_47:                                ; %wf_indexed_cost_word.exit.i280.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	cmp	x8, x12
	b.hs	LBB2_37
LBB2_48:                                ; %bb2.i12.i320.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x14, [x19, #16]
	mov	w15, #12                        ; =0xc
	str	x15, [x14, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x12
	b.lo	LBB2_38
	b	LBB2_39
LBB2_49:                                ;   in Loop: Header=BB2_16 Depth=1
	mov	x11, #0                         ; =0x0
	ldr	x10, [sp, #536]
	cbz	x10, LBB2_60
LBB2_50:                                ; %bb3.i.i.i.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	udiv	x12, x11, x10
	msub	x11, x12, x10, x11
	ldr	x12, [sp, #552]
	mov	x13, x10
	b	LBB2_52
LBB2_51:                                ; %bb8.i.i.i.i64.i
                                        ;   in Loop: Header=BB2_52 Depth=2
	add	x14, x11, #1
	cmp	x14, x10
	csinc	x11, xzr, x11, hs
	subs	x13, x13, #1
	b.eq	LBB2_60
LBB2_52:                                ; %bb5.i.i.i.i63.i
                                        ;   Parent Loop BB2_16 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x14, x12, x11, lsl #5
	ldr	w15, [x14]
	cmp	w15, #1
	b.eq	LBB2_51
; %bb.53:                               ; %bb5.i.i.i.i63.i
                                        ;   in Loop: Header=BB2_52 Depth=2
	cmp	w15, #2
	b.ne	LBB2_60
; %bb.54:                               ; %bb9.i.i.i.i.i
                                        ;   in Loop: Header=BB2_52 Depth=2
	ldr	x15, [x14, #8]
	cmp	x15, x23
	b.ne	LBB2_51
; %bb.55:                               ; %bb3.i120.i.i.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x10, [x14, #16]
	ldr	x11, [sp, #504]
	cmp	x10, x11
	b.hs	LBB2_91
; %bb.56:                               ; %bb2.i.i.i.i.i68.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x12, [x14, #24]
	ldr	x11, [sp, #520]
	mov	w13, #56                        ; =0x38
	madd	x11, x10, x13, x11
	ldr	x10, [x11, #40]
	cmp	x10, x12
	b.ne	LBB2_91
; %bb.57:                               ; %bb5.i.i.i.i.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x10, [x11]
	cbz	x10, LBB2_91
; %bb.58:                               ; %bb3.i.i.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x10, [x11, #8]
	cmp	x10, x23
	b.ne	LBB2_104
; %bb.59:                               ; %bb4.i.i71.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	mov	x10, #0                         ; =0x0
	ldr	x12, [x11, #16]
	str	x9, [x11, #16]
	ldr	x8, [x19]
	mov	x9, x12
	b	LBB2_61
LBB2_60:                                ;   in Loop: Header=BB2_16 Depth=1
	mov	w10, #2                         ; =0x2
LBB2_61:                                ; %"wf_record_store_replace$instance$d656314a40e34216.exit.i"
                                        ;   in Loop: Header=BB2_16 Depth=1
	str	w10, [sp, #128]
	stp	x9, x9, [sp, #136]
	ldp	x11, x9, [x19, #24]
	ldr	x12, [x19, #8]
	cmp	x8, x12
	b.hs	LBB2_79
; %bb.62:                               ; %bb2.i.i96.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x13, [x19, #16]
	str	x0, [x13, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x12
	b.lo	LBB2_80
LBB2_63:                                ; %wf_indexed_cost_word.exit18.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	cmp	x8, x12
	b.hs	LBB2_65
LBB2_64:                                ; %bb2.i30.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x13, [x19, #16]
	str	x23, [x13, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB2_65:                                ; %wf_indexed_cost_word.exit36.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	madd	x11, x11, x25, x23
	mov	w13, #17816                     ; =0x4598
	add	x11, x11, x13
	madd	x11, x11, x28, x10
	add	x9, x9, #4
	stp	x11, x9, [x19, #24]
	cmp	x8, x12
	b.hs	LBB2_67
; %bb.66:                               ; %bb2.i49.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x9, [x19, #16]
	str	x10, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	ldp	x11, x9, [x19, #24]
LBB2_67:                                ; %wf_indexed_cost_outcome.exit.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x10, [x19, #8]
	cmp	x8, x10
	b.hs	LBB2_69
; %bb.68:                               ; %bb2.i.i125.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #4                         ; =0x4
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB2_69:                                ; %wf_indexed_cost_word.exit.i110.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	cmp	x8, x10
	b.hs	LBB2_71
; %bb.70:                               ; %bb2.i12.i119.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x12, [x19, #16]
	str	x23, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB2_71:                                ; %wf_indexed_cost_word.exit18.i115.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	madd	x11, x11, x16, x23
	add	x12, x11, #524
	ldr	x11, [sp, #144]
	madd	x12, x12, x28, x11
	add	x9, x9, #3
	stp	x12, x9, [x19, #24]
	cmp	x8, x10
	b.hs	LBB2_73
; %bb.72:                               ; %bb2.i.i.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x9, [x19, #16]
	str	x11, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB2_73:                                ; %"wf_indexed_cost_accept$instance$2b4e452a2d5f5791.exit.i"
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x9, [sp, #80]
	ldr	x10, [sp, #488]
	cmp	x9, x10
	b.ne	LBB2_81
; %bb.74:                               ; %bb3.i.i.i.i132.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x11, [sp, #88]
	ldr	x10, [sp, #504]
	cmp	x11, x10
	b.hs	LBB2_82
; %bb.75:                               ; %bb2.i.i.i.i.i136.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x14, [sp, #96]
	ldr	x9, [sp, #520]
	mov	w12, #56                        ; =0x38
	madd	x13, x11, x12, x9
	ldr	x12, [x13, #40]
	cmp	x12, x14
	b.ne	LBB2_82
; %bb.76:                               ; %bb5.i.i.i.i.i144.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x12, [x13]
	cbz	x12, LBB2_82
; %bb.77:                               ; %bb2.i.i.i147.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x1, [x13, #32]
	cmp	x1, #2, lsl #12                 ; =8192
	b.ne	LBB2_94
; %bb.78:                               ;   in Loop: Header=BB2_16 Depth=1
	mov	w9, #7                          ; =0x7
	b	LBB2_83
LBB2_79:                                ; %wf_indexed_cost_word.exit.i80.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	cmp	x8, x12
	b.hs	LBB2_63
LBB2_80:                                ; %bb2.i12.i90.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x13, [x19, #16]
	mov	w14, #5                         ; =0x5
	str	x14, [x13, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x12
	b.lo	LBB2_64
	b	LBB2_65
LBB2_81:                                ;   in Loop: Header=BB2_16 Depth=1
	mov	w9, #4                          ; =0x4
	b	LBB2_83
LBB2_82:                                ;   in Loop: Header=BB2_16 Depth=1
	mov	w9, #3                          ; =0x3
LBB2_83:                                ; %"wf_record_store_reschedule$instance$d656314a40e34216.exit.i"
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldp	x12, x11, [x19, #24]
	ldr	x10, [x19, #8]
	cmp	x8, x10
	b.hs	LBB2_89
; %bb.84:                               ; %bb2.i.i214.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x13, [x19, #16]
	str	x0, [x13, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB2_90
LBB2_85:                                ; %wf_indexed_cost_word.exit18.i173.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	cmp	x8, x10
	b.hs	LBB2_87
LBB2_86:                                ; %bb2.i30.i202.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x13, [x19, #16]
	str	x23, [x13, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB2_87:                                ; %switch.lookup
                                        ;   in Loop: Header=BB2_16 Depth=1
	madd	x12, x12, x25, x23
	mov	w13, #17947                     ; =0x461b
	add	x12, x12, x13
	madd	x12, x12, x28, x9
	add	x11, x11, #4
	stp	x12, x11, [x19, #24]
	cmp	x8, x10
	b.hs	LBB2_15
; %bb.88:                               ; %bb2.i49.i187.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x10, [x19, #16]
	str	x9, [x10, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	b	LBB2_15
LBB2_89:                                ; %wf_indexed_cost_word.exit.i168.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	cmp	x8, x10
	b.hs	LBB2_85
LBB2_90:                                ; %bb2.i12.i208.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x13, [x19, #16]
	mov	w14, #6                         ; =0x6
	str	x14, [x13, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB2_86
	b	LBB2_87
LBB2_91:                                ;   in Loop: Header=BB2_16 Depth=1
	mov	w10, #3                         ; =0x3
	b	LBB2_61
LBB2_92:                                ; %wf_indexed_cost_word.exit.i229.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	cmp	x8, x12
	b.hs	LBB2_29
LBB2_93:                                ; %bb2.i12.i259.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x11, [x19, #16]
	mov	w13, #12                        ; =0xc
	str	x13, [x11, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x12
	b.lo	LBB2_30
	b	LBB2_31
LBB2_94:                                ; %bb6.i.i.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x2, [sp, #576]
	cmp	x1, x2
	b.hs	LBB2_103
; %bb.95:                               ; %bb8.i.i.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x12, [sp, #592]
	add	x12, x12, x1, lsl #5
	mov	x15, x12
	ldr	x16, [x15, #16]!
	cmp	x16, x11
	b.ne	LBB2_103
; %bb.96:                               ; %bb8.i.i.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x11, [x12, #24]
	cmp	x11, x14
	b.ne	LBB2_103
; %bb.97:                               ; %bb11.i.i.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x11, [x13, #8]
	ldr	x13, [x12, #8]
	cmp	x13, x11
	b.ne	LBB2_103
; %bb.98:                               ; %bb2.i153.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	sbfx	x8, x24, #0, #1
	ldr	x11, [sp, #16]                  ; 8-byte Folded Reload
	and	x8, x8, x11
	add	x8, x8, x24
	ldr	q0, [x15]
	str	q0, [sp, #608]
	str	x8, [x12]
	str	q0, [x12, #16]
	ldr	x8, [x12, #16]
	cmp	x8, x10
	b.hs	LBB2_102
; %bb.99:                               ; %bb2.i.i.i.i4.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x10, [x12, #24]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x9
	ldr	x9, [x8, #40]
	cmp	x9, x10
	b.ne	LBB2_102
; %bb.100:                              ; %bb5.i.i.i.i12.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	ldr	x9, [x8]
	cbz	x9, LBB2_102
; %bb.101:                              ; %bb8.i.i.i.i.i.i
                                        ;   in Loop: Header=BB2_16 Depth=1
	str	x1, [x8, #32]
LBB2_102:                               ; %"wf_collections.priority_queue.priority_queue_replace_at_indexed$instance$8a68ac1679550fca.exit.i.i"
                                        ;   in Loop: Header=BB2_16 Depth=1
	add	x0, x17, #528
	add	x8, sp, #48
	add	x3, x8, #456
	bl	_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$8a68ac1679550fca
	mov	x9, #0                          ; =0x0
	ldr	x8, [x19]
	mov	w0, #1                          ; =0x1
	b	LBB2_83
LBB2_103:                               ;   in Loop: Header=BB2_16 Depth=1
	mov	w9, #8                          ; =0x8
	b	LBB2_83
LBB2_104:                               ;   in Loop: Header=BB2_16 Depth=1
	mov	w10, #5                         ; =0x5
	b	LBB2_61
LBB2_105:                               ; %bb7.i
	mov	x0, x20
	mov	x1, x19
	mov	x2, #-1                         ; =0xffffffffffffffff
	mov	w3, #1                          ; =0x1
	mov	x4, #0                          ; =0x0
	bl	_wf_indexed_cost_insert$instance$2b4e452a2d5f5791
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	cbz	x8, LBB2_175
LBB2_106:                               ; %bb11.i
	mov	x0, x20
	mov	x1, #-1                         ; =0xffffffffffffffff
	b	LBB2_185
LBB2_107:                               ; %bb27.lr.ph.i
	mov	x28, #0                         ; =0x0
	mov	w25, #9053                      ; =0x235d
	movk	w25, #36, lsl #16
	lsl	x24, x21, #3
	mov	w22, #23106                     ; =0x5a42
	movk	w22, #35, lsl #16
	mov	w23, #1                         ; =0x1
	mov	w27, #9053                      ; =0x235d
	movk	w27, #36, lsl #16
	str	x24, [sp, #16]                  ; 8-byte Folded Spill
	b	LBB2_109
LBB2_108:                               ; %bb36.i
                                        ;   in Loop: Header=BB2_109 Depth=1
	add	x28, x28, #1
	add	x24, x24, #1
	add	x22, x22, #262
	add	x27, x27, #262
	add	x23, x23, #2
	cmp	x21, x28
	b.eq	LBB2_127
LBB2_109:                               ; %bb27.i
                                        ; =>This Inner Loop Header: Depth=1
	tst	x28, #0x3
	b.ne	LBB2_108
; %bb.110:                              ; %bb31.i
                                        ;   in Loop: Header=BB2_109 Depth=1
	add	x8, sp, #48
	add	x0, x8, #104
	mov	x1, x20
	mov	x2, x19
	mov	x3, x23
	bl	_wf_indexed_cost_lookup$instance$174c6fc95f4077f6
	ldr	w8, [sp, #152]
	cbnz	w8, LBB2_108
; %bb.111:                              ; %bb34.i
                                        ;   in Loop: Header=BB2_109 Depth=1
	add	x8, sp, #48
	ldur	q0, [x8, #112]
	add	x9, sp, #48
	stur	q0, [x9, #136]
	ldur	x8, [x8, #128]
	stur	x8, [x9, #152]
	add	x1, x9, #136
	mov	x0, x20
	bl	_wf_record_store_cancel$instance$d656314a40e34216
	ldp	x11, x9, [x19, #24]
	ldp	x8, x10, [x19]
	cmp	x8, x10
	b.hs	LBB2_123
; %bb.112:                              ; %bb2.i.i393.i
                                        ;   in Loop: Header=BB2_109 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB2_124
LBB2_113:                               ; %wf_indexed_cost_word.exit18.i352.i
                                        ;   in Loop: Header=BB2_109 Depth=1
	cmp	x8, x10
	b.hs	LBB2_115
LBB2_114:                               ; %bb2.i30.i381.i
                                        ;   in Loop: Header=BB2_109 Depth=1
	ldr	x12, [x19, #16]
	str	x23, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB2_115:                               ; %switch.lookup23
                                        ;   in Loop: Header=BB2_109 Depth=1
	mov	w12, w0
	mov	w13, #46673                     ; =0xb651
	movk	w13, #4493, lsl #16
	madd	x11, x11, x13, x12
	add	x11, x27, x11
	add	x9, x9, #4
	stp	x11, x9, [x19, #24]
	cmp	x8, x10
	b.hs	LBB2_117
; %bb.116:                              ; %bb2.i49.i366.i
                                        ;   in Loop: Header=BB2_109 Depth=1
	ldr	x9, [x19, #16]
	str	x12, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB2_117:                               ; %wf_indexed_cost_outcome.exit399.i
                                        ;   in Loop: Header=BB2_109 Depth=1
	add	x8, sp, #48
	add	x1, x8, #136
	mov	x0, x20
	mov	x2, x24
	bl	_wf_record_store_schedule$instance$d656314a40e34216
	ldp	x11, x9, [x19, #24]
	ldp	x8, x10, [x19]
	cmp	x8, x10
	b.hs	LBB2_125
; %bb.118:                              ; %bb2.i.i454.i
                                        ;   in Loop: Header=BB2_109 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB2_126
LBB2_119:                               ; %wf_indexed_cost_word.exit18.i413.i
                                        ;   in Loop: Header=BB2_109 Depth=1
	cmp	x8, x10
	b.hs	LBB2_121
LBB2_120:                               ; %bb2.i30.i442.i
                                        ;   in Loop: Header=BB2_109 Depth=1
	ldr	x12, [x19, #16]
	str	x23, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB2_121:                               ; %switch.lookup25
                                        ;   in Loop: Header=BB2_109 Depth=1
	mov	w12, w0
	mov	w13, #46673                     ; =0xb651
	movk	w13, #4493, lsl #16
	madd	x11, x11, x13, x12
	add	x11, x22, x11
	add	x9, x9, #4
	stp	x11, x9, [x19, #24]
	cmp	x8, x10
	b.hs	LBB2_108
; %bb.122:                              ; %bb2.i49.i427.i
                                        ;   in Loop: Header=BB2_109 Depth=1
	ldr	x9, [x19, #16]
	str	x12, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	b	LBB2_108
LBB2_123:                               ; %wf_indexed_cost_word.exit.i347.i
                                        ;   in Loop: Header=BB2_109 Depth=1
	cmp	x8, x10
	b.hs	LBB2_113
LBB2_124:                               ; %bb2.i12.i387.i
                                        ;   in Loop: Header=BB2_109 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #7                         ; =0x7
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB2_114
	b	LBB2_115
LBB2_125:                               ; %wf_indexed_cost_word.exit.i408.i
                                        ;   in Loop: Header=BB2_109 Depth=1
	cmp	x8, x10
	b.hs	LBB2_119
LBB2_126:                               ; %bb2.i12.i448.i
                                        ;   in Loop: Header=BB2_109 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #4                         ; =0x4
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB2_120
	b	LBB2_121
LBB2_127:                               ; %bb38.lr.ph.i
	mov	x24, #0                         ; =0x0
	ldp	x22, x8, [sp, #16]              ; 16-byte Folded Reload
	add	x8, x8, #2
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	mov	w28, #26214                     ; =0x6666
	movk	w28, #36, lsl #16
	mov	w23, #1                         ; =0x1
	add	x27, sp, #48
	b	LBB2_131
LBB2_128:                               ; %bb50.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	add	x3, x27, #192
	mov	x0, x20
	mov	x1, x19
	mov	x2, x23
	bl	_wf_indexed_cost_delete$instance$2b4e452a2d5f5791
LBB2_129:                               ; %bb47.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	add	x3, x8, x24
	add	x4, x22, x24
	mov	x0, x20
	mov	x1, x19
	mov	x2, x23
	bl	_wf_indexed_cost_insert$instance$2b4e452a2d5f5791
LBB2_130:                               ; %bb53.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	add	x24, x24, #1
	add	x25, x25, #262
	add	x28, x28, #262
	add	x23, x23, #2
	cmp	x21, x24
	b.eq	LBB2_175
LBB2_131:                               ; %bb38.i
                                        ; =>This Inner Loop Header: Depth=1
	tst	x24, #0x7
	b.ne	LBB2_130
; %bb.132:                              ; %bb42.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	add	x0, x27, #160
	mov	x1, x20
	mov	x2, x19
	mov	x3, x23
	bl	_wf_indexed_cost_lookup$instance$174c6fc95f4077f6
	ldr	w8, [sp, #208]
	cbnz	w8, LBB2_130
; %bb.133:                              ; %bb45.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	add	x8, sp, #48
	ldur	q0, [x8, #168]
	stur	q0, [x27, #192]
	ldur	x8, [x8, #184]
	stur	x8, [x27, #208]
	add	x3, x27, #192
	mov	x0, x20
	mov	x1, x19
	mov	x2, x23
	bl	_wf_indexed_cost_delete$instance$2b4e452a2d5f5791
	ldr	x8, [sp, #32]                   ; 8-byte Folded Reload
	cbz	x8, LBB2_146
; %bb.134:                              ; %bb48.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	tbnz	w24, #3, LBB2_154
; %bb.135:                              ; %bb51.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	add	x2, x27, #192
	mov	x0, x20
	mov	x1, x23
	bl	_wf_record_store_detach$instance$d656314a40e34216
	ldp	x11, x9, [x19, #24]
	ldp	x8, x10, [x19]
	cmp	x8, x10
	b.hs	LBB2_167
; %bb.136:                              ; %bb2.i.i618.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB2_168
LBB2_137:                               ; %wf_indexed_cost_word.exit18.i577.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	cmp	x8, x10
	b.hs	LBB2_139
LBB2_138:                               ; %bb2.i30.i606.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	ldr	x12, [x19, #16]
	str	x23, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB2_139:                               ; %switch.lookup29
                                        ;   in Loop: Header=BB2_131 Depth=1
	mov	w12, w0
	mov	w13, #46673                     ; =0xb651
	movk	w13, #4493, lsl #16
	madd	x11, x11, x13, x12
	add	x11, x28, x11
	add	x9, x9, #4
	stp	x11, x9, [x19, #24]
	cmp	x8, x10
	b.hs	LBB2_141
; %bb.140:                              ; %bb2.i49.i591.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	ldr	x9, [x19, #16]
	str	x12, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB2_141:                               ; %wf_indexed_cost_outcome.exit624.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	add	x3, x27, #192
	mov	x0, x20
	mov	x1, x19
	mov	x2, x23
	bl	_wf_indexed_cost_delete$instance$2b4e452a2d5f5791
	add	x1, x27, #192
	mov	x0, x20
	bl	_wf_record_store_cancel$instance$d656314a40e34216
	ldp	x11, x9, [x19, #24]
	ldp	x8, x10, [x19]
	cmp	x8, x10
	b.hs	LBB2_169
; %bb.142:                              ; %bb2.i.i679.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB2_170
LBB2_143:                               ; %wf_indexed_cost_word.exit18.i638.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	cmp	x8, x10
	b.hs	LBB2_145
LBB2_144:                               ; %bb2.i30.i667.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	ldr	x12, [x19, #16]
	str	x23, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB2_145:                               ; %switch.lookup31
                                        ;   in Loop: Header=BB2_131 Depth=1
	mov	w12, w0
	mov	w13, #46673                     ; =0xb651
	movk	w13, #4493, lsl #16
	madd	x11, x11, x13, x12
	add	x11, x25, x11
	b	LBB2_165
LBB2_146:                               ; %bb49.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	add	x0, x27, #216
	mov	x1, x20
	mov	x2, x19
	mov	x3, x23
	bl	_wf_indexed_cost_lookup$instance$174c6fc95f4077f6
	add	x1, x27, #192
	mov	x0, x20
	bl	_wf_record_store_cancel$instance$d656314a40e34216
	ldp	x11, x9, [x19, #24]
	ldp	x8, x10, [x19]
	cmp	x8, x10
	b.hs	LBB2_152
; %bb.147:                              ; %bb2.i.i557.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB2_153
LBB2_148:                               ; %wf_indexed_cost_word.exit18.i516.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	cmp	x8, x10
	b.hs	LBB2_150
LBB2_149:                               ; %bb2.i30.i545.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	ldr	x12, [x19, #16]
	str	x23, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB2_150:                               ; %switch.lookup27
                                        ;   in Loop: Header=BB2_131 Depth=1
	mov	w12, w0
	mov	w13, #46673                     ; =0xb651
	movk	w13, #4493, lsl #16
	madd	x11, x11, x13, x12
	add	x11, x25, x11
	add	x9, x9, #4
	stp	x11, x9, [x19, #24]
	cmp	x8, x10
	b.hs	LBB2_129
; %bb.151:                              ; %bb2.i49.i530.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	ldr	x9, [x19, #16]
	str	x12, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	b	LBB2_129
LBB2_152:                               ; %wf_indexed_cost_word.exit.i511.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	cmp	x8, x10
	b.hs	LBB2_148
LBB2_153:                               ; %bb2.i12.i551.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #7                         ; =0x7
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB2_149
	b	LBB2_150
LBB2_154:                               ; %bb52.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	add	x1, x27, #192
	mov	x0, x20
	bl	_wf_record_store_cancel$instance$d656314a40e34216
	ldp	x11, x9, [x19, #24]
	ldp	x8, x10, [x19]
	cmp	x8, x10
	b.hs	LBB2_171
; %bb.155:                              ; %bb2.i.i740.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB2_172
LBB2_156:                               ; %wf_indexed_cost_word.exit18.i699.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	cmp	x8, x10
	b.hs	LBB2_158
LBB2_157:                               ; %bb2.i30.i728.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	ldr	x12, [x19, #16]
	str	x23, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB2_158:                               ; %switch.lookup33
                                        ;   in Loop: Header=BB2_131 Depth=1
	mov	w12, w0
	mov	w13, #46673                     ; =0xb651
	movk	w13, #4493, lsl #16
	madd	x11, x11, x13, x12
	add	x11, x25, x11
	add	x9, x9, #4
	stp	x11, x9, [x19, #24]
	cmp	x8, x10
	b.hs	LBB2_160
; %bb.159:                              ; %bb2.i49.i713.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	ldr	x9, [x19, #16]
	str	x12, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB2_160:                               ; %wf_indexed_cost_outcome.exit746.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	add	x3, x27, #192
	mov	x0, x20
	mov	x1, x19
	mov	x2, x23
	bl	_wf_indexed_cost_delete$instance$2b4e452a2d5f5791
	add	x2, x27, #192
	mov	x0, x20
	mov	x1, x23
	bl	_wf_record_store_detach$instance$d656314a40e34216
	ldp	x11, x9, [x19, #24]
	ldp	x8, x10, [x19]
	cmp	x8, x10
	b.hs	LBB2_173
; %bb.161:                              ; %bb2.i.i801.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB2_174
LBB2_162:                               ; %wf_indexed_cost_word.exit18.i760.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	cmp	x8, x10
	b.hs	LBB2_164
LBB2_163:                               ; %bb2.i30.i789.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	ldr	x12, [x19, #16]
	str	x23, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB2_164:                               ; %switch.lookup35
                                        ;   in Loop: Header=BB2_131 Depth=1
	mov	w12, w0
	mov	w13, #46673                     ; =0xb651
	movk	w13, #4493, lsl #16
	madd	x11, x11, x13, x12
	add	x11, x28, x11
LBB2_165:                               ; %switch.lookup31
                                        ;   in Loop: Header=BB2_131 Depth=1
	add	x9, x9, #4
	stp	x11, x9, [x19, #24]
	cmp	x8, x10
	b.hs	LBB2_128
; %bb.166:                              ; %bb50.sink.split.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	ldr	x9, [x19, #16]
	str	x12, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	b	LBB2_128
LBB2_167:                               ; %wf_indexed_cost_word.exit.i572.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	cmp	x8, x10
	b.hs	LBB2_137
LBB2_168:                               ; %bb2.i12.i612.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #8                         ; =0x8
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB2_138
	b	LBB2_139
LBB2_169:                               ; %wf_indexed_cost_word.exit.i633.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	cmp	x8, x10
	b.hs	LBB2_143
LBB2_170:                               ; %bb2.i12.i673.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #7                         ; =0x7
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB2_144
	b	LBB2_145
LBB2_171:                               ; %wf_indexed_cost_word.exit.i694.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	cmp	x8, x10
	b.hs	LBB2_156
LBB2_172:                               ; %bb2.i12.i734.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #7                         ; =0x7
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB2_157
	b	LBB2_158
LBB2_173:                               ; %wf_indexed_cost_word.exit.i755.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	cmp	x8, x10
	b.hs	LBB2_162
LBB2_174:                               ; %bb2.i12.i795.i
                                        ;   in Loop: Header=BB2_131 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #8                         ; =0x8
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB2_163
	b	LBB2_164
LBB2_175:                               ; %bb40.i
	sub	x1, x26, #1
	mov	x0, x20
	mov	x2, x19
	bl	_wf_record_store_expire$instance$083db5949cf60ce0
	mov	w8, #131                        ; =0x83
	mov	x9, #6                          ; =0x6
	ldp	x10, x11, [x19, #24]
	madd	x9, x10, x8, x9
	add	x10, x11, #1
	stp	x9, x10, [x19, #24]
	ldp	x8, x11, [x19]
	cmp	x8, x11
	b.hs	LBB2_177
; %bb.176:                              ; %bb2.i472.i
	ldr	x9, [x19, #16]
	mov	w10, #6                         ; =0x6
	str	x10, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	ldp	x9, x10, [x19, #24]
	ldr	x11, [x19, #8]
LBB2_177:                               ; %wf_indexed_cost_word.exit478.i
	mov	w12, #131                       ; =0x83
	madd	x9, x9, x12, x0
	add	x10, x10, #1
	stp	x9, x10, [x19, #24]
	cmp	x8, x11
	b.hs	LBB2_179
; %bb.178:                              ; %bb2.i490.i
	ldr	x9, [x19, #16]
	str	x0, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB2_179:                               ; %wf_indexed_cost_word.exit496.i
	cbz	x21, LBB2_184
; %bb.180:                              ; %bb55.lr.ph.i
	mov	x25, #0                         ; =0x0
	add	x8, x21, x21, lsl #1
	add	x22, x8, #2
	lsl	x23, x21, #3
	mov	w24, #1                         ; =0x1
	b	LBB2_182
LBB2_181:                               ; %bb61.i
                                        ;   in Loop: Header=BB2_182 Depth=1
	add	x25, x25, #1
	add	x23, x23, #1
	add	x22, x22, #1
	add	x24, x24, #2
	cmp	x21, x25
	b.eq	LBB2_184
LBB2_182:                               ; %bb55.i
                                        ; =>This Inner Loop Header: Depth=1
	and	x8, x25, #0x3
	cmp	x8, #2
	b.ne	LBB2_181
; %bb.183:                              ; %bb59.i
                                        ;   in Loop: Header=BB2_182 Depth=1
	add	x0, x27, #248
	mov	x1, x20
	mov	x2, x19
	mov	x3, x24
	bl	_wf_indexed_cost_lookup$instance$174c6fc95f4077f6
	mov	x0, x20
	mov	x1, x19
	mov	x2, x24
	mov	x3, x22
	mov	x4, x23
	bl	_wf_indexed_cost_insert$instance$2b4e452a2d5f5791
	b	LBB2_181
LBB2_184:                               ; %bb57.i
	add	x8, x21, x21, lsl #3
	sub	x1, x8, #1
	mov	x0, x20
LBB2_185:                               ; %bb11.i
	mov	x2, x19
	bl	_wf_record_store_expire$instance$083db5949cf60ce0
	mov	w8, #131                        ; =0x83
	mov	x9, #6                          ; =0x6
	ldp	x10, x11, [x19, #24]
	madd	x9, x10, x8, x9
	add	x10, x11, #1
	stp	x9, x10, [x19, #24]
	ldp	x8, x11, [x19]
	cmp	x8, x11
	b.hs	LBB2_187
; %bb.186:                              ; %bb2.i.i
	ldr	x9, [x19, #16]
	mov	w10, #6                         ; =0x6
	str	x10, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	ldp	x9, x10, [x19, #24]
	ldr	x11, [x19, #8]
LBB2_187:                               ; %wf_indexed_cost_word.exit.i
	mov	w12, #131                       ; =0x83
	madd	x9, x9, x12, x0
	add	x10, x10, #1
	stp	x9, x10, [x19, #24]
	cmp	x8, x11
	b.hs	LBB2_189
; %bb.188:                              ; %bb9.sink.split.i
	ldr	x9, [x19, #16]
	str	x0, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB2_189:                               ; %bb9.i
	add	x8, sp, #48
	add	x8, x8, #280
	ldp	q0, q1, [x20, #32]
	stp	q0, q1, [x8, #32]
	ldp	q1, q0, [x20, #80]
	stp	q1, q0, [x8, #80]
	ldr	q0, [x20, #64]
	str	q0, [x8, #64]
	ldp	q1, q0, [x20]
	stp	q1, q0, [x8]
	ldr	x8, [x20, #112]
	str	x8, [sp, #440]
	ldp	x23, x22, [sp, #344]
	ldr	x20, [sp, #360]
	ldr	x8, [sp, #384]
	ldp	x24, x21, [sp, #424]
	cbz	x8, LBB2_191
; %bb.190:                              ; %slots.release.drop.6.i.i.i.i
	ldr	x0, [sp, #392]
	bl	_free
LBB2_191:                               ; %"wf_std.collections.hash_map.hash_map_free$instance$ae582e16a4511b12.exit.i.i"
	cbz	x24, LBB2_193
; %bb.192:                              ; %slots.release.drop.6.i.i2.i.i
	mov	x0, x21
	bl	_free
LBB2_193:                               ; %"wf_collections.priority_queue.priority_queue_free$instance$56071cfe5106e0aa.exit.i.i"
	cbz	x23, LBB2_204
; %bb.194:                              ; %bb5.lr.ph.i.i.i
	ldp	x10, x8, [x19, #24]
	tbnz	w23, #0, LBB2_196
; %bb.195:
	mov	x9, x23
	b	LBB2_203
LBB2_196:                               ; %bb5.i.i.i.prol
	sub	x9, x23, #1
	mov	w11, #56                        ; =0x38
	madd	x11, x9, x11, x20
	ldp	q0, q1, [x11]
	stp	q0, q1, [sp, #608]
	ldr	x11, [x11, #32]
	str	x11, [sp, #640]
	ldr	x11, [sp, #608]
	cbz	x11, LBB2_203
; %bb.197:                              ; %bb7.i.i.i.prol
	sub	x11, x11, #1
	add	x12, sp, #608
	add	x13, x12, x11, lsl #5
	str	x11, [sp, #608]
	ldr	x14, [x13, #8]
	ldp	x11, x12, [x19]
	cmp	x11, x12
	b.hs	LBB2_199
; %bb.198:                              ; %bb2.i.i.i.i.i.i.prol
	ldr	x15, [x19, #16]
	mov	w16, #4                         ; =0x4
	str	x16, [x15, x11, lsl #3]
	add	x11, x11, #1
	str	x11, [x19]
LBB2_199:                               ; %wf_indexed_cost_word.exit.i.i.i.i.i.prol
	ldr	x13, [x13, #16]
	mov	w15, #17161                     ; =0x4309
	madd	x10, x10, x15, x14
	add	x10, x10, #524
	cmp	x11, x12
	b.hs	LBB2_201
; %bb.200:                              ; %bb2.i12.i.i.i.i.i.prol
	ldr	x15, [x19, #16]
	str	x14, [x15, x11, lsl #3]
	add	x11, x11, #1
	str	x11, [x19]
LBB2_201:                               ; %wf_indexed_cost_word.exit18.i.i.i.i.i.prol
	mov	w14, #131                       ; =0x83
	madd	x10, x10, x14, x13
	add	x8, x8, #3
	stp	x10, x8, [x19, #24]
	cmp	x11, x12
	b.hs	LBB2_203
; %bb.202:                              ; %bb2.i.i.i.i.i.i.i.prol
	ldr	x12, [x19, #16]
	str	x13, [x12, x11, lsl #3]
	add	x11, x11, #1
	str	x11, [x19]
LBB2_203:                               ; %bb5.i.i.i.prol.loopexit
	cmp	x23, #1
	b.ne	LBB2_207
LBB2_204:                               ; %bb4.i.i.i
	cbz	x22, LBB2_206
; %bb.205:                              ; %slots.release.drop.6.i.i8.i.i
	mov	x0, x20
	bl	_free
LBB2_206:                               ; %"wf_indexed_cost_trace$instance$2b4e452a2d5f5791.exit"
	ldr	q0, [x19, #16]
	str	q0, [sp, #464]
	ldr	x0, [sp, #472]
	add	sp, sp, #656
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB2_207:                               ; %bb5.lr.ph.i.i.i.new
	mov	w11, #56                        ; =0x38
	madd	x11, x9, x11, x20
	sub	x11, x11, #56
	add	x12, sp, #608
	mov	w13, #4                         ; =0x4
	mov	w14, #17161                     ; =0x4309
	mov	w15, #131                       ; =0x83
	b	LBB2_209
LBB2_208:                               ; %bb6.i.i.i.1
                                        ;   in Loop: Header=BB2_209 Depth=1
	sub	x11, x11, #112
	sub	x9, x9, #2
	cbz	x9, LBB2_204
LBB2_209:                               ; %bb5.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q0, q1, [x11]
	stp	q0, q1, [sp, #608]
	ldr	x16, [x11, #32]
	str	x16, [sp, #640]
	ldr	x16, [sp, #608]
	cbz	x16, LBB2_216
; %bb.210:                              ; %bb7.i.i.i
                                        ;   in Loop: Header=BB2_209 Depth=1
	sub	x0, x16, #1
	str	x0, [sp, #608]
	ldp	x16, x17, [x19]
	cmp	x16, x17
	b.hs	LBB2_212
; %bb.211:                              ; %bb2.i.i.i.i.i.i
                                        ;   in Loop: Header=BB2_209 Depth=1
	ldr	x1, [x19, #16]
	str	x13, [x1, x16, lsl #3]
	add	x16, x16, #1
	str	x16, [x19]
LBB2_212:                               ; %wf_indexed_cost_word.exit.i.i.i.i.i
                                        ;   in Loop: Header=BB2_209 Depth=1
	add	x1, x12, x0, lsl #5
	ldr	x0, [x1, #8]
	cmp	x16, x17
	b.hs	LBB2_214
; %bb.213:                              ; %bb2.i12.i.i.i.i.i
                                        ;   in Loop: Header=BB2_209 Depth=1
	ldr	x2, [x19, #16]
	str	x0, [x2, x16, lsl #3]
	add	x16, x16, #1
	str	x16, [x19]
LBB2_214:                               ; %wf_indexed_cost_word.exit18.i.i.i.i.i
                                        ;   in Loop: Header=BB2_209 Depth=1
	ldr	x1, [x1, #16]
	madd	x10, x10, x14, x0
	add	x10, x10, #524
	madd	x10, x10, x15, x1
	add	x8, x8, #3
	stp	x10, x8, [x19, #24]
	cmp	x16, x17
	b.hs	LBB2_216
; %bb.215:                              ; %bb2.i.i.i.i.i.i.i
                                        ;   in Loop: Header=BB2_209 Depth=1
	ldr	x17, [x19, #16]
	str	x1, [x17, x16, lsl #3]
	add	x16, x16, #1
	str	x16, [x19]
LBB2_216:                               ; %bb6.i.i.i
                                        ;   in Loop: Header=BB2_209 Depth=1
	ldur	q0, [x11, #-56]
	ldur	q1, [x11, #-40]
	stp	q0, q1, [sp, #608]
	ldur	x16, [x11, #-24]
	str	x16, [sp, #640]
	ldr	x16, [sp, #608]
	cbz	x16, LBB2_208
; %bb.217:                              ; %bb7.i.i.i.1
                                        ;   in Loop: Header=BB2_209 Depth=1
	sub	x0, x16, #1
	str	x0, [sp, #608]
	ldp	x16, x17, [x19]
	cmp	x16, x17
	b.hs	LBB2_219
; %bb.218:                              ; %bb2.i.i.i.i.i.i.1
                                        ;   in Loop: Header=BB2_209 Depth=1
	ldr	x1, [x19, #16]
	str	x13, [x1, x16, lsl #3]
	add	x16, x16, #1
	str	x16, [x19]
LBB2_219:                               ; %wf_indexed_cost_word.exit.i.i.i.i.i.1
                                        ;   in Loop: Header=BB2_209 Depth=1
	add	x1, x12, x0, lsl #5
	ldr	x0, [x1, #8]
	cmp	x16, x17
	b.hs	LBB2_221
; %bb.220:                              ; %bb2.i12.i.i.i.i.i.1
                                        ;   in Loop: Header=BB2_209 Depth=1
	ldr	x2, [x19, #16]
	str	x0, [x2, x16, lsl #3]
	add	x16, x16, #1
	str	x16, [x19]
LBB2_221:                               ; %wf_indexed_cost_word.exit18.i.i.i.i.i.1
                                        ;   in Loop: Header=BB2_209 Depth=1
	ldr	x1, [x1, #16]
	madd	x10, x10, x14, x0
	add	x10, x10, #524
	madd	x10, x10, x15, x1
	add	x8, x8, #3
	stp	x10, x8, [x19, #24]
	cmp	x16, x17
	b.hs	LBB2_208
; %bb.222:                              ; %bb2.i.i.i.i.i.i.i.1
                                        ;   in Loop: Header=BB2_209 Depth=1
	ldr	x17, [x19, #16]
	str	x1, [x17, x16, lsl #3]
	add	x16, x16, #1
	str	x16, [x19]
	b	LBB2_208
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh4, Lloh5
	.loh AdrpLdr	Lloh6, Lloh7
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_indexed_cost_insert$instance$2b4e452a2d5f5791
lCPI3_0:
	.quad	8192                            ; 0x2000
	.quad	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_wf_indexed_cost_insert$instance$2b4e452a2d5f5791: ; @"wf_indexed_cost_insert$instance$2b4e452a2d5f5791"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #160
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 160
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x2
	mov	x19, x1
	ldp	x11, x8, [x1, #24]
	ldp	x9, x10, [x1]
	cmp	x9, x10
	b.hs	LBB3_2
; %bb.1:                                ; %bb2.i.i
	ldr	x12, [x19, #16]
	mov	w13, #3                         ; =0x3
	str	x13, [x12, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x19]
LBB3_2:                                 ; %wf_indexed_cost_word.exit.i
	mov	w12, #17161                     ; =0x4309
	madd	x11, x11, x12, x3
	add	x11, x11, #393
	add	x8, x8, #2
	stp	x11, x8, [x19, #24]
	cmp	x9, x10
	b.hs	LBB3_4
; %bb.3:                                ; %bb2.i12.i
	ldr	x8, [x19, #16]
	str	x3, [x8, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x19]
LBB3_4:                                 ; %wf_indexed_cost_offer.exit
	strb	wzr, [sp, #56]
	ldr	x22, [x0, #40]
	ldr	x10, [x0, #16]
	cmp	x22, x10
	b.hs	LBB3_7
; %bb.5:                                ; %bb2.i.i6
	ldr	x8, [x0, #32]
	mov	w11, #56                        ; =0x38
	madd	x11, x22, x11, x8
	ldr	x12, [x11]
	cbnz	x12, LBB3_30
; %bb.6:                                ; %bb8.i.i
	ldp	x23, x9, [x11, #40]
	stp	x20, x3, [x11, #8]
	strb	wzr, [x11, #24]
	mov	w12, #8192                      ; =0x2000
	str	x12, [x11, #32]
	mov	w12, #1                         ; =0x1
	str	x12, [x11]
	str	x9, [x0, #40]
	mov	x9, x10
	b	LBB3_9
LBB3_7:                                 ; %bb3.i.i
	ldr	x8, [x0, #24]
	cmp	x10, x8
	b.hs	LBB3_30
; %bb.8:                                ; %bb11.i.i
	mov	x23, #0                         ; =0x0
	ldr	x8, [x0, #32]
	mov	w9, #56                         ; =0x38
	madd	x9, x10, x9, x8
	mov	w11, #1                         ; =0x1
	stp	x11, x20, [x9]
	str	x3, [x9, #16]
	strb	wzr, [x9, #24]
Lloh8:
	adrp	x11, lCPI3_0@PAGE
Lloh9:
	ldr	q0, [x11, lCPI3_0@PAGEOFF]
	str	q0, [x9, #32]
	str	x22, [x9, #48]
	add	x9, x10, #1
	str	x9, [x0, #16]
	mov	x22, x10
LBB3_9:                                 ; %bb2
	ldr	x11, [x0]
	stp	x11, x22, [sp, #32]
	str	x23, [sp, #48]
	ldp	x14, x12, [x19, #24]
	ldp	x10, x13, [x19]
	cmp	x10, x13
	b.hs	LBB3_11
; %bb.10:                               ; %bb2.i.i27
	ldr	x15, [x19, #16]
	mov	w16, #1                         ; =0x1
	str	x16, [x15, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x19]
LBB3_11:                                ; %wf_indexed_cost_word.exit.i16
	cmp	x10, x13
	b.hs	LBB3_13
; %bb.12:                               ; %bb2.i12.i21
	ldr	x15, [x19, #16]
	mov	w16, #1                         ; =0x1
	str	x16, [x15, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x19]
LBB3_13:                                ; %wf_indexed_cost_word.exit18.i
	mov	w21, #19867                     ; =0x4d9b
	movk	w21, #34, lsl #16
	madd	x14, x14, x21, x20
	mov	w15, #17292                     ; =0x438c
	add	x14, x14, x15
	cmp	x10, x13
	b.hs	LBB3_15
; %bb.14:                               ; %bb2.i30.i
	ldr	x15, [x19, #16]
	str	x20, [x15, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x19]
LBB3_15:                                ; %wf_indexed_cost_word.exit36.i
	mov	w15, #131                       ; =0x83
	mul	x14, x14, x15
	add	x12, x12, #4
	stp	x14, x12, [x19, #24]
	cmp	x10, x13
	b.hs	LBB3_17
; %bb.16:                               ; %bb2.i49.i
	ldr	x12, [x19, #16]
	str	xzr, [x12, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x19]
	ldp	x14, x12, [x19, #24]
LBB3_17:                                ; %wf_indexed_cost_outcome.exit
	ldr	x13, [x19, #8]
	cmp	x10, x13
	b.hs	LBB3_19
; %bb.18:                               ; %bb2.i.i52
	ldr	x15, [x19, #16]
	mov	w16, #2                         ; =0x2
	str	x16, [x15, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x19]
LBB3_19:                                ; %wf_indexed_cost_word.exit.i41
	mov	w15, #17161                     ; =0x4309
	madd	x14, x14, x15, x11
	add	x14, x14, #262
	cmp	x10, x13
	b.hs	LBB3_21
; %bb.20:                               ; %bb2.i13.i
	ldr	x15, [x19, #16]
	str	x11, [x15, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x19]
LBB3_21:                                ; %wf_indexed_cost_word.exit19.i
	mov	w11, #131                       ; =0x83
	madd	x11, x14, x11, x22
	cmp	x10, x13
	b.hs	LBB3_23
; %bb.22:                               ; %bb2.i31.i
	ldr	x14, [x19, #16]
	str	x22, [x14, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x19]
LBB3_23:                                ; %wf_indexed_cost_word.exit37.i
	mov	w14, #131                       ; =0x83
	madd	x11, x11, x14, x23
	add	x12, x12, #4
	stp	x11, x12, [x19, #24]
	cmp	x10, x13
	b.hs	LBB3_25
; %bb.24:                               ; %bb2.i49.i46
	ldr	x11, [x19, #16]
	str	x23, [x11, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x19]
LBB3_25:                                ; %bb3.i.i58
	cmp	x22, x9
	b.hs	LBB3_104
; %bb.26:                               ; %bb2.i.i.i
	mov	w10, #56                        ; =0x38
	madd	x24, x22, x10, x8
	ldr	x10, [x24, #40]
	cmp	x10, x23
	b.ne	LBB3_104
; %bb.27:                               ; %bb5.i.i.i
	ldr	x10, [x24]
	cbz	x10, LBB3_104
; %bb.28:                               ; %bb2.i61
	ldr	x25, [x24, #8]
	ldrb	w10, [x24, #24]
	and	w10, w10, #0x1
	strb	w10, [sp, #56]
	tbz	w10, #0, LBB3_45
LBB3_29:
	mov	w9, #1                          ; =0x1
	b	LBB3_105
LBB3_30:                                ; %bb3
	ldp	x11, x10, [x19, #24]
	ldr	x8, [x19, #8]
	cmp	x9, x8
	b.hs	LBB3_32
; %bb.31:                               ; %bb2.i.i229
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x19]
LBB3_32:                                ; %wf_indexed_cost_word.exit.i192
	cmp	x9, x8
	b.hs	LBB3_34
; %bb.33:                               ; %bb2.i12.i223
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x19]
LBB3_34:                                ; %wf_indexed_cost_word.exit18.i197
	mov	w12, #19867                     ; =0x4d9b
	movk	w12, #34, lsl #16
	madd	x11, x11, x12, x20
	mov	w12, #17292                     ; =0x438c
	add	x11, x11, x12
	cmp	x9, x8
	b.hs	LBB3_36
; %bb.35:                               ; %bb2.i30.i217
	ldr	x12, [x19, #16]
	str	x20, [x12, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x19]
LBB3_36:                                ; %wf_indexed_cost_word.exit36.i202
	mov	w12, #131                       ; =0x83
	mov	x13, #6                         ; =0x6
	madd	x11, x11, x12, x13
	add	x10, x10, #4
	stp	x11, x10, [x19, #24]
	cmp	x9, x8
	b.hs	LBB3_38
; %bb.37:                               ; %bb2.i49.i211
	ldr	x8, [x19, #16]
	mov	w10, #6                         ; =0x6
	str	x10, [x8, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x19]
	ldp	x11, x10, [x19, #24]
LBB3_38:                                ; %wf_indexed_cost_outcome.exit235
	ldr	x8, [x19, #8]
	cmp	x9, x8
	b.hs	LBB3_40
; %bb.39:                               ; %bb2.i.i258
	ldr	x12, [x19, #16]
	mov	w13, #4                         ; =0x4
	str	x13, [x12, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x19]
LBB3_40:                                ; %wf_indexed_cost_word.exit.i244
	mov	w12, #17161                     ; =0x4309
	madd	x11, x11, x12, x20
	add	x11, x11, #524
	cmp	x9, x8
	b.hs	LBB3_42
; %bb.41:                               ; %bb2.i12.i252
	ldr	x12, [x19, #16]
	str	x20, [x12, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x19]
LBB3_42:                                ; %wf_indexed_cost_word.exit18.i249
	mov	w12, #131                       ; =0x83
	madd	x11, x11, x12, x3
	add	x10, x10, #3
	stp	x11, x10, [x19, #24]
	cmp	x9, x8
	b.hs	LBB3_44
LBB3_43:                                ; %bb1.sink.split
	ldr	x8, [x19, #16]
	str	x3, [x8, x9, lsl #3]
	add	x8, x9, #1
	str	x8, [x19]
LBB3_44:                                ; %bb1
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB3_45:                                ; %bb6.i
	ldr	x26, [x0, #112]
	udiv	x15, x25, x26
	cbz	x26, LBB3_47
; %bb.46:                               ; %bb3.i.i.i
	msub	x10, x15, x26, x25
	b	LBB3_48
LBB3_47:
	mov	x10, #0                         ; =0x0
LBB3_48:                                ; %wf_record_id_hash.exit.i.i
	ldr	x28, [x0, #48]
	cbz	x28, LBB3_61
; %bb.49:                               ; %bb3.i12.i
	udiv	x11, x10, x28
	msub	x10, x11, x28, x10
	ldr	x11, [x0, #64]
	mov	x12, x28
	b	LBB3_51
LBB3_50:                                ; %bb8.i.i63
                                        ;   in Loop: Header=BB3_51 Depth=1
	add	x13, x10, #1
	cmp	x13, x28
	csinc	x10, xzr, x10, hs
	subs	x12, x12, #1
	b.eq	LBB3_61
LBB3_51:                                ; %bb5.i13.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x13, x11, x10, lsl #5
	ldr	w14, [x13]
	cmp	w14, #1
	b.eq	LBB3_50
; %bb.52:                               ; %bb5.i13.i
                                        ;   in Loop: Header=BB3_51 Depth=1
	cmp	w14, #2
	b.ne	LBB3_61
; %bb.53:                               ; %bb9.i.i
                                        ;   in Loop: Header=BB3_51 Depth=1
	ldr	x14, [x13, #8]
	cmp	x14, x25
	b.ne	LBB3_50
; %bb.54:                               ; %bb8.i
	ldp	x11, x10, [x13, #16]
	cmp	x11, x22
	ccmp	x10, x23, #0, eq
	b.eq	LBB3_29
; %bb.55:                               ; %bb12.i
	cmp	x11, x9
	b.hs	LBB3_59
; %bb.56:                               ; %bb2.i.i24.i
	mov	w9, #56                         ; =0x38
	madd	x8, x11, x9, x8
	ldr	x9, [x8, #40]
	cmp	x9, x10
	b.ne	LBB3_59
; %bb.57:                               ; %"wf_std.collections.slab.slab_find_index$instance$50cad5863314d34d.exit.i"
	ldr	x8, [x8]
	mov	w9, #5                          ; =0x5
	cbnz	x8, LBB3_105
; %bb.58:                               ; %"wf_std.collections.slab.slab_find_index$instance$50cad5863314d34d.exit.i"
	ldrb	w8, [x0, #8]
	tbz	w8, #0, LBB3_61
	b	LBB3_105
LBB3_59:                                ; %bb15.i
	ldrb	w8, [x0, #8]
	tbz	w8, #0, LBB3_61
; %bb.60:
	mov	w9, #5                          ; =0x5
	b	LBB3_105
LBB3_61:                                ; %bb7.i
	ldp	x5, x8, [x0, #72]
	adds	x9, x5, x8
	csinv	x9, x9, xzr, lo
	lsr	x10, x28, #13
	cbnz	x10, LBB3_80
; %bb.62:                               ; %bb7.i
	sub	x10, x28, x28, lsr #2
	cmp	x9, x10
	b.lo	LBB3_80
; %bb.63:                               ; %bb2.i20.i
	lsr	x9, x10, #1
	cmp	x5, x9
	csinc	x10, x28, xzr, lo
	mov	w11, #8192                      ; =0x2000
	lsl	x12, x28, #1
	cmp	x28, #1, lsl #12                ; =4096
	csel	x11, x12, x11, ls
	cmp	x5, x9
	csel	x9, x10, x11, lo
	cmp	x28, #0
	csel	x27, x10, x9, eq
	cmp	x27, x28
	b.lo	LBB3_80
; %bb.64:                               ; %bb3.i.i7.i.i
	cbz	x27, LBB3_80
; %bb.65:                               ; %window.payload.allocate.v1.i.i.i.i.i.i
	stp	x5, x0, [sp, #16]               ; 16-byte Folded Spill
	stp	x15, x4, [sp]                   ; 16-byte Folded Spill
	lsl	x0, x27, #5
	bl	_malloc
	cbz	x0, LBB3_120
; %bb.66:                               ; %bb5.i.i.i.i.i.preheader
	mov	x8, x0
	mov	x10, #0                         ; =0x0
	add	x9, x0, #8
	ldr	x0, [sp, #24]                   ; 8-byte Folded Reload
LBB3_67:                                ; %bb5.i.i.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x10, x10, #1
	stp	xzr, xzr, [x9, #8]
	str	xzr, [x9], #32
	cmp	x27, x10
	b.ne	LBB3_67
; %bb.68:                               ; %"wf_std.collections.hash_map.hash_map_extend$instance$83298420b4219017.exit.i.i.i.i"
	ldp	x11, x9, [x0, #56]
	stp	x27, x27, [x0, #48]
	str	x8, [x0, #64]
	ldr	x5, [sp, #16]                   ; 8-byte Folded Reload
	cbz	x28, LBB3_82
; %bb.69:
	mov	w12, #2                         ; =0x2
	b	LBB3_72
LBB3_70:                                ; %"wf_std.collections.hash_map.hash_map_migrate_owner$instance$1870b122c27cb60e.exit.i.i.i.i"
                                        ;   in Loop: Header=BB3_72 Depth=1
	add	x14, x8, x2, lsl #5
	str	w12, [x14]
	stur	q0, [x14, #8]
	str	x13, [x14, #24]
LBB3_71:                                ; %bb15.i.i.i.i
                                        ;   in Loop: Header=BB3_72 Depth=1
	cbz	x28, LBB3_82
LBB3_72:                                ; %bb14.i.i.i.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB3_74 Depth 2
                                        ;       Child Loop BB3_78 Depth 3
	sub	x28, x28, #1
	add	x13, x9, x28, lsl #5
	ldr	w14, [x13]
	cmp	w14, #2
	b.lo	LBB3_71
; %bb.73:                               ;   in Loop: Header=BB3_72 Depth=1
	ldur	q0, [x13, #8]
	ldr	x14, [x13, #8]
	ldr	x13, [x13, #24]
LBB3_74:                                ; %bb1.i9.i.i.i.i
                                        ;   Parent Loop BB3_72 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB3_78 Depth 3
	cbz	x26, LBB3_76
; %bb.75:                               ; %bb3.i.i.i.i.i.i
                                        ;   in Loop: Header=BB3_74 Depth=2
	udiv	x15, x14, x26
	msub	x16, x15, x26, x14
	b	LBB3_77
LBB3_76:                                ;   in Loop: Header=BB3_74 Depth=2
	mov	x16, #0                         ; =0x0
LBB3_77:                                ; %wf_record_id_hash.exit.i.i.i.i.i
                                        ;   in Loop: Header=BB3_74 Depth=2
	mov	x15, #0                         ; =0x0
	udiv	x17, x16, x27
	msub	x16, x17, x27, x16
	sub	x17, x27, x16
	neg	x1, x17
LBB3_78:                                ; %bb3.i.i.i.i.i
                                        ;   Parent Loop BB3_72 Depth=1
                                        ;     Parent Loop BB3_74 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x15, x17
	csel	x2, x16, x1, lo
	add	x2, x2, x15
	lsl	x3, x2, #5
	ldr	w3, [x8, x3]
	cmp	w3, #1
	b.ls	LBB3_70
; %bb.79:                               ; %bb2.i12.i.i.i.i
                                        ;   in Loop: Header=BB3_78 Depth=3
	add	x15, x15, #1
	cmp	x10, x15
	b.ne	LBB3_78
	b	LBB3_74
LBB3_80:
	mov	x27, x28
	cbz	x26, LBB3_85
LBB3_81:                                ; %bb3.i.i.i.i
	msub	x9, x15, x26, x25
	b	LBB3_86
LBB3_82:                                ; %bb13.i.i.i.i
	cbz	x11, LBB3_84
; %bb.83:                               ; %slots.release.drop.6.i.i.i.i.i
	mov	x0, x9
	bl	_free
	ldp	x5, x0, [sp, #16]               ; 16-byte Folded Reload
LBB3_84:                                ; %"wf_free_empty$instance$16f094be4fd843b6.exit.i.i.i.i"
	mov	x8, #0                          ; =0x0
	str	xzr, [x0, #80]
	ldp	x15, x4, [sp]                   ; 16-byte Folded Reload
	cbnz	x26, LBB3_81
LBB3_85:
	mov	x9, #0                          ; =0x0
LBB3_86:                                ; %wf_record_id_hash.exit.i.i.i
	cbz	x27, LBB3_94
; %bb.87:                               ; %bb2.i.i17.i
	udiv	x10, x9, x27
	msub	x9, x10, x27, x9
	ldr	x11, [x0, #64]
	mov	x12, x27
	mov	x10, x27
	b	LBB3_90
LBB3_88:                                ; %bb11.i.i.i
                                        ;   in Loop: Header=BB3_90 Depth=1
	cmp	x10, x27
	csel	x10, x9, x10, eq
LBB3_89:                                ; %bb8.i.i.i
                                        ;   in Loop: Header=BB3_90 Depth=1
	add	x13, x9, #1
	cmp	x13, x27
	csinc	x9, xzr, x9, hs
	subs	x12, x12, #1
	b.eq	LBB3_96
LBB3_90:                                ; %bb5.i.i18.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x13, x11, x9, lsl #5
	ldr	w14, [x13]
	cmp	w14, #1
	b.eq	LBB3_88
; %bb.91:                               ; %bb5.i.i18.i
                                        ;   in Loop: Header=BB3_90 Depth=1
	cmp	w14, #2
	b.ne	LBB3_95
; %bb.92:                               ; %bb3.i11.i.i.i
                                        ;   in Loop: Header=BB3_90 Depth=1
	ldr	x14, [x13, #8]
	cmp	x14, x25
	b.ne	LBB3_89
; %bb.93:                               ; %"wf_std.collections.hash_map.hash_map_exchange$instance$44a98dc5bf86badc.exit.i.i.i"
	mov	w8, #2                          ; =0x2
	str	w8, [x13]
	stp	x22, x23, [x13, #16]
	b	LBB3_101
LBB3_94:
	mov	x10, #0                         ; =0x0
	b	LBB3_96
LBB3_95:                                ; %bb10.i.i.i
	cmp	x10, x27
	csel	x10, x9, x10, eq
LBB3_96:                                ; %bb1.i.i.i
	mov	w9, #6                          ; =0x6
	lsr	x11, x5, #13
	cbnz	x11, LBB3_105
; %bb.97:                               ; %bb1.i.i.i
	cmp	x10, x27
	b.hs	LBB3_105
; %bb.98:                               ; %bb27.i.i.i
	add	x9, x5, #1
	str	x9, [x0, #72]
	ldr	x9, [x0, #64]
	add	x9, x9, x10, lsl #5
	ldr	w10, [x9]
	cmp	w10, #1
	b.ne	LBB3_100
; %bb.99:                               ; %bb29.thread.i.i.i
	subs	x8, x8, #1
	csel	x8, xzr, x8, lo
	str	x8, [x0, #80]
LBB3_100:                               ; %bb29.i.i.i
	mov	w8, #2                          ; =0x2
	str	w8, [x9]
	stp	x25, x22, [x9, #8]
	str	x23, [x9, #24]
LBB3_101:                               ; %bb2.i.i40.i
	ldr	x8, [x24, #40]
	cmp	x8, x23
	b.ne	LBB3_104
; %bb.102:                              ; %bb5.i.i50.i
	ldr	x8, [x24]
	cbz	x8, LBB3_104
; %bb.103:
	mov	x9, #0                          ; =0x0
	mov	w8, #1                          ; =0x1
	strb	w8, [x24, #24]
	b	LBB3_105
LBB3_104:                               ; %bb5.i.i
	mov	w9, #3                          ; =0x3
LBB3_105:                               ; %"wf_record_store_attach$instance$d656314a40e34216.exit"
	ldp	x12, x10, [x19, #24]
	ldp	x8, x11, [x19]
	cmp	x8, x11
	b.hs	LBB3_107
; %bb.106:                              ; %bb2.i.i116
	ldr	x13, [x19, #16]
	mov	w14, #1                         ; =0x1
	str	x14, [x13, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB3_107:                               ; %wf_indexed_cost_word.exit.i78
	cmp	x8, x11
	b.hs	LBB3_109
; %bb.108:                              ; %bb2.i12.i110
	ldr	x13, [x19, #16]
	mov	w14, #2                         ; =0x2
	str	x14, [x13, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB3_109:                               ; %wf_indexed_cost_word.exit18.i83
	madd	x12, x12, x21, x20
	mov	w13, #17423                     ; =0x440f
	add	x12, x12, x13
	cmp	x8, x11
	b.hs	LBB3_111
; %bb.110:                              ; %bb2.i30.i104
	ldr	x13, [x19, #16]
	str	x20, [x13, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB3_111:                               ; %switch.lookup
	mov	w13, #131                       ; =0x83
	madd	x12, x12, x13, x9
	add	x10, x10, #4
	stp	x12, x10, [x19, #24]
	cmp	x8, x11
	b.hs	LBB3_113
; %bb.112:                              ; %bb2.i49.i94
	ldr	x10, [x19, #16]
	str	x9, [x10, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB3_113:                               ; %wf_indexed_cost_outcome.exit122
	add	x1, sp, #32
	mov	x2, x4
	bl	_wf_record_store_schedule$instance$d656314a40e34216
	ldp	x11, x8, [x19, #24]
	ldp	x9, x10, [x19]
	cmp	x9, x10
	b.hs	LBB3_115
; %bb.114:                              ; %bb2.i.i177
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x19]
LBB3_115:                               ; %wf_indexed_cost_word.exit.i131
	cmp	x9, x10
	b.hs	LBB3_117
; %bb.116:                              ; %bb2.i12.i171
	ldr	x12, [x19, #16]
	mov	w13, #4                         ; =0x4
	str	x13, [x12, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x19]
LBB3_117:                               ; %wf_indexed_cost_word.exit18.i136
	madd	x11, x11, x21, x20
	mov	w12, #17685                     ; =0x4515
	add	x11, x11, x12
	cmp	x9, x10
	b.hs	LBB3_119
; %bb.118:                              ; %bb2.i30.i165
	ldr	x12, [x19, #16]
	str	x20, [x12, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x19]
LBB3_119:                               ; %switch.lookup13
	mov	w3, w0
	mov	w12, #131                       ; =0x83
	madd	x11, x11, x12, x3
	add	x8, x8, #4
	stp	x11, x8, [x19, #24]
	cmp	x9, x10
	b.lo	LBB3_43
	b	LBB3_44
LBB3_120:                               ; %window.block.oom.v1.i.i.i.i.i.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh8, Lloh9
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_indexed_cost_lookup$instance$174c6fc95f4077f6
_wf_indexed_cost_lookup$instance$174c6fc95f4077f6: ; @"wf_indexed_cost_lookup$instance$174c6fc95f4077f6"
; %bb.0:                                ; %entry
	ldr	x8, [x1, #112]
	cbz	x8, LBB4_2
; %bb.1:                                ; %bb3.i.i.i
	udiv	x9, x3, x8
	msub	x9, x9, x8, x3
	ldr	x8, [x1, #48]
	cbnz	x8, LBB4_3
	b	LBB4_29
LBB4_2:
	mov	x9, #0                          ; =0x0
	ldr	x8, [x1, #48]
	cbz	x8, LBB4_29
LBB4_3:                                 ; %bb3.i.i
	udiv	x10, x9, x8
	msub	x9, x10, x8, x9
	ldr	x10, [x1, #64]
	mov	x11, x8
	b	LBB4_5
LBB4_4:                                 ; %bb8.i.i
                                        ;   in Loop: Header=BB4_5 Depth=1
	add	x12, x9, #1
	cmp	x12, x8
	csinc	x9, xzr, x9, hs
	subs	x11, x11, #1
	b.eq	LBB4_29
LBB4_5:                                 ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x12, x10, x9, lsl #5
	ldr	w13, [x12]
	cmp	w13, #1
	b.eq	LBB4_4
; %bb.6:                                ; %bb5.i.i
                                        ;   in Loop: Header=BB4_5 Depth=1
	cmp	w13, #2
	b.ne	LBB4_29
; %bb.7:                                ; %bb9.i.i
                                        ;   in Loop: Header=BB4_5 Depth=1
	ldr	x13, [x12, #8]
	cmp	x13, x3
	b.ne	LBB4_4
; %bb.8:                                ; %bb3.i120.i
	ldr	x8, [x12, #16]
	ldr	x9, [x1, #16]
	cmp	x8, x9
	b.hs	LBB4_39
; %bb.9:                                ; %bb2.i.i.i
	ldr	x9, [x12, #24]
	ldr	x10, [x1, #32]
	mov	w11, #56                        ; =0x38
	madd	x10, x8, x11, x10
	ldr	x11, [x10, #40]
	cmp	x11, x9
	b.ne	LBB4_39
; %bb.10:                               ; %bb5.i.i.i
	ldr	x11, [x10]
	cbz	x11, LBB4_39
; %bb.11:                               ; %bb3.i
	ldr	x10, [x10, #8]
	cmp	x10, x3
	b.ne	LBB4_40
; %bb.12:                               ; %bb1
	ldp	x10, x11, [x2]
	cmp	x10, x11
	b.hs	LBB4_14
; %bb.13:                               ; %bb2.i.i
	ldr	x12, [x2, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x2]
LBB4_14:                                ; %wf_indexed_cost_word.exit.i
	cmp	x10, x11
	b.hs	LBB4_16
; %bb.15:                               ; %bb2.i12.i
	ldr	x12, [x2, #16]
	mov	w13, #3                         ; =0x3
	str	x13, [x12, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x2]
LBB4_16:                                ; %wf_indexed_cost_word.exit18.i
	ldr	x12, [x2, #24]
	mov	w13, #19867                     ; =0x4d9b
	movk	w13, #34, lsl #16
	mov	w14, #17554                     ; =0x4492
	cmp	x10, x11
	b.hs	LBB4_18
; %bb.17:                               ; %bb2.i30.i
	ldr	x15, [x2, #16]
	str	x3, [x15, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x2]
LBB4_18:                                ; %wf_indexed_cost_word.exit36.i
	madd	x15, x12, x13, x3
	cmp	x10, x11
	b.hs	LBB4_20
; %bb.19:                               ; %bb2.i49.i
	ldr	x12, [x2, #16]
	str	xzr, [x12, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x2]
LBB4_20:                                ; %wf_indexed_cost_outcome.exit
	ldr	x12, [x1]
	add	x14, x15, x14
	cmp	x10, x11
	b.hs	LBB4_22
; %bb.21:                               ; %bb2.i.i80
	ldr	x15, [x2, #16]
	mov	w16, #2                         ; =0x2
	str	x16, [x15, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x2]
LBB4_22:                                ; %wf_indexed_cost_word.exit.i69
	madd	x13, x14, x13, x12
	add	x14, x13, #262
	cmp	x10, x11
	b.hs	LBB4_24
; %bb.23:                               ; %bb2.i13.i
	ldr	x13, [x2, #16]
	str	x12, [x13, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x2]
LBB4_24:                                ; %wf_indexed_cost_word.exit19.i
	ldr	x13, [x2, #32]
	mov	w15, #131                       ; =0x83
	madd	x14, x14, x15, x8
	cmp	x10, x11
	b.hs	LBB4_26
; %bb.25:                               ; %bb2.i31.i
	ldr	x15, [x2, #16]
	str	x8, [x15, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x2]
LBB4_26:                                ; %wf_indexed_cost_word.exit37.i
	mov	w15, #131                       ; =0x83
	madd	x14, x14, x15, x9
	add	x13, x13, #8
	stp	x14, x13, [x2, #24]
	cmp	x10, x11
	b.hs	LBB4_28
; %bb.27:                               ; %bb2.i49.i74
	ldr	x11, [x2, #16]
	str	x9, [x11, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x2]
LBB4_28:                                ; %wf_indexed_cost_handle.exit
	stp	xzr, x12, [x0]
	stp	x8, x9, [x0, #16]
	ret
LBB4_29:
	mov	w8, #2                          ; =0x2
LBB4_30:                                ; %bb2
	ldp	x9, x10, [x2]
	cmp	x9, x10
	b.hs	LBB4_32
; %bb.31:                               ; %bb2.i.i132
	ldr	x11, [x2, #16]
	mov	w12, #1                         ; =0x1
	str	x12, [x11, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x2]
LBB4_32:                                ; %wf_indexed_cost_word.exit.i94
	ldr	x12, [x2, #24]
	cmp	x9, x10
	b.hs	LBB4_34
; %bb.33:                               ; %bb2.i12.i126
	ldr	x11, [x2, #16]
	mov	w13, #3                         ; =0x3
	str	x13, [x11, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x2]
LBB4_34:                                ; %wf_indexed_cost_word.exit18.i99
	ldr	x11, [x2, #32]
	mov	w13, #19867                     ; =0x4d9b
	movk	w13, #34, lsl #16
	madd	x12, x12, x13, x3
	mov	w13, #17554                     ; =0x4492
	add	x12, x12, x13
	cmp	x9, x10
	b.hs	LBB4_36
; %bb.35:                               ; %bb2.i30.i120
	ldr	x13, [x2, #16]
	str	x3, [x13, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x2]
LBB4_36:                                ; %wf_indexed_cost_word.exit36.i104
	sub	w13, w8, #2
	add	x13, x13, #2
	mov	w14, #131                       ; =0x83
	madd	x12, x12, x14, x13
	add	x11, x11, #4
	stp	x12, x11, [x2, #24]
	cmp	x9, x10
	b.hs	LBB4_38
; %bb.37:                               ; %bb2.i49.i110
	ldr	x10, [x2, #16]
	str	x13, [x10, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x2]
LBB4_38:                                ; %wf_indexed_cost_outcome.exit138
	stp	xzr, xzr, [x0, #8]
	str	xzr, [x0, #24]
	mov	w9, #1                          ; =0x1
	stp	w9, w8, [x0]
	ret
LBB4_39:
	mov	w8, #3                          ; =0x3
	b	LBB4_30
LBB4_40:
	mov	w8, #5                          ; =0x5
	b	LBB4_30
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_store_cancel$instance$d656314a40e34216
_wf_record_store_cancel$instance$d656314a40e34216: ; @"wf_record_store_cancel$instance$d656314a40e34216"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.ne	LBB5_6
; %bb.1:                                ; %bb3.i.i.i
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	ldr	x19, [x1, #8]
	mov	x3, x0
	ldr	x8, [x3, #16]!
	cmp	x19, x8
	b.hs	LBB5_20
; %bb.2:                                ; %bb2.i.i.i.i
	ldr	x20, [x1, #16]
	ldr	x8, [x0, #32]
	mov	w9, #56                         ; =0x38
	madd	x10, x19, x9, x8
	ldr	x8, [x10, #40]
	cmp	x8, x20
	b.ne	LBB5_20
; %bb.3:                                ; %bb5.i.i.i.i
	ldr	x8, [x10]
	cbz	x8, LBB5_20
; %bb.4:                                ; %bb2.i.i
	ldr	x1, [x10, #32]
	cmp	x1, #2, lsl #12                 ; =8192
	b.ne	LBB5_7
; %bb.5:
	mov	w0, #7                          ; =0x7
	b	LBB5_21
LBB5_6:
	mov	w0, #4                          ; =0x4
	ret
LBB5_7:                                 ; %bb6.i.i
	mov	x8, x0
	ldr	x12, [x8, #88]!
	cmp	x1, x12
	b.hs	LBB5_22
; %bb.8:                                ; %bb8.i.i
	ldr	x11, [x0, #104]
	add	x9, x11, x1, lsl #5
	ldp	x13, x14, [x9, #16]
	cmp	x13, x19
	ccmp	x14, x20, #0, eq
	b.ne	LBB5_22
; %bb.9:                                ; %bb11.i.i
	ldr	x10, [x10, #8]
	ldr	x13, [x9, #8]
	cmp	x13, x10
	b.ne	LBB5_22
; %bb.10:                               ; %bb2
	sub	x2, x12, #1
	str	x2, [x8]
	ldr	x21, [x3]
	cmp	x1, x2
	b.hs	LBB5_16
; %bb.11:                               ; %bb2.i
	add	x10, x11, x2, lsl #5
	ldp	q0, q1, [x10]
	stp	q0, q1, [x9]
	ldr	x10, [x9, #16]
	cmp	x10, x21
	b.hs	LBB5_15
; %bb.12:                               ; %bb2.i.i.i.i4
	ldr	x11, [x9, #24]
	ldr	x9, [x0, #32]
	mov	w12, #56                        ; =0x38
	madd	x9, x10, x12, x9
	ldr	x10, [x9, #40]
	cmp	x10, x11
	b.ne	LBB5_15
; %bb.13:                               ; %bb5.i.i.i.i12
	ldr	x10, [x9]
	cbz	x10, LBB5_15
; %bb.14:                               ; %bb8.i.i.i.i
	str	x1, [x9, #32]
LBB5_15:                                ; %"wf_record_report_position$instance$d656314a40e34216.exit.i"
	mov	x22, x0
	mov	x0, x8
	bl	_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$8a68ac1679550fca
	mov	x0, x22
LBB5_16:                                ; %"wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$8a68ac1679550fca.exit"
	cmp	x19, x21
	b.hs	LBB5_20
; %bb.17:                               ; %bb2.i.i20
	ldr	x8, [x0, #32]
	mov	w9, #56                         ; =0x38
	madd	x8, x19, x9, x8
	ldr	x9, [x8, #40]
	cmp	x9, x20
	b.ne	LBB5_20
; %bb.18:                               ; %bb5.i.i
	ldr	x9, [x8]
	cbz	x9, LBB5_20
; %bb.19:                               ; %bb8.i.i23
	mov	w0, #0                          ; =0x0
	mov	w9, #8192                       ; =0x2000
	str	x9, [x8, #32]
	b	LBB5_21
LBB5_20:
	mov	w0, #3                          ; =0x3
LBB5_21:
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB5_22:
	mov	w0, #8                          ; =0x8
	b	LBB5_21
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_store_schedule$instance$d656314a40e34216
_wf_record_store_schedule$instance$d656314a40e34216: ; @"wf_record_store_schedule$instance$d656314a40e34216"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #112
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 112
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.ne	LBB6_7
; %bb.1:                                ; %bb3.i
	ldr	x8, [x1, #8]
	mov	x19, x0
	ldr	x22, [x19, #16]!
	cmp	x8, x22
	b.hs	LBB6_8
; %bb.2:                                ; %bb2.i.i
	ldr	x9, [x1, #16]
	ldr	x21, [x0, #32]
	mov	w10, #56                        ; =0x38
	madd	x10, x8, x10, x21
	ldr	x11, [x10, #40]
	cmp	x11, x9
	b.ne	LBB6_8
; %bb.3:                                ; %bb5.i.i
	ldr	x11, [x10]
	cbz	x11, LBB6_8
; %bb.4:                                ; %bb2
	ldr	x23, [x10, #8]
	ldr	x10, [x10, #32]
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB6_10
; %bb.5:                                ; %bb6
	ldur	q0, [x1, #8]
	stp	q0, q0, [sp]
	ldur	x20, [x0, #88]
	lsr	x8, x20, #13
	cbz	x8, LBB6_13
; %bb.6:                                ; %bb10
	mov	w0, #6                          ; =0x6
	b	LBB6_9
LBB6_7:
	mov	w0, #4                          ; =0x4
	b	LBB6_9
LBB6_8:
	mov	w0, #3                          ; =0x3
LBB6_9:                                 ; %common.ret
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB6_10:                                ; %bb2.i.i4
	ldur	x11, [x0, #88]
	cmp	x10, x11
	b.hs	LBB6_18
; %bb.11:                               ; %bb8.i.i
	ldr	x11, [x0, #104]
	add	x10, x11, x10, lsl #5
	ldp	x11, x12, [x10, #16]
	mov	w0, #8                          ; =0x8
	cmp	x11, x8
	ccmp	x12, x9, #0, eq
	b.ne	LBB6_9
; %bb.12:                               ; %bb11.i.i
	ldr	x8, [x10, #8]
	cmp	x8, x23
	csinc	w0, w0, wzr, ne
	b	LBB6_9
LBB6_13:                                ; %bb3.i6
	ldr	x8, [x0, #96]
	cmp	x8, x20
	b.ne	LBB6_19
; %bb.14:                               ; %bb3.i.i
	mov	x24, x2
	cbz	x20, LBB6_20
; %bb.15:                               ; %bb6.i.i19
	mov	x25, x0
	cmp	x20, #1, lsl #12                ; =4096
	b.hi	LBB6_22
; %bb.16:                               ; %bb11.i.i20
	ldr	x0, [x0, #104]
	lsl	x1, x20, #6
	bl	_realloc
	cbz	x0, LBB6_30
; %bb.17:                               ; %"wf_grow$instance$57d99a800120d980.exit.i33.i.i"
	mov	x8, x0
	lsl	x9, x20, #1
	b	LBB6_24
LBB6_18:
	mov	w0, #8                          ; =0x8
	b	LBB6_9
LBB6_19:                                ; %"bb3.wf_collections.priority_queue.priority_queue_make_room$instance$8ea10e07481bf32d.exit_crit_edge.i"
	ldr	x8, [x0, #104]
	b	LBB6_25
LBB6_20:                                ; %bb5.i.i22
	mov	x25, x0
	mov	w0, #32                         ; =0x20
	bl	_malloc
	cbz	x0, LBB6_30
; %bb.21:                               ; %window.grow.copy.ready.v2.i.i.i.i
	mov	x8, x0
	mov	w9, #1                          ; =0x1
	b	LBB6_24
LBB6_22:                                ; %bb7.i.i
	ldr	x0, [x0, #104]
	mov	w1, #262144                     ; =0x40000
	bl	_realloc
	cbz	x0, LBB6_30
; %bb.23:                               ; %"wf_grow$instance$57d99a800120d980.exit.i.i.i"
	mov	x8, x0
	mov	w9, #8192                       ; =0x2000
LBB6_24:                                ; %"wf_collections.priority_queue.priority_queue_make_room$instance$8ea10e07481bf32d.exit.i"
	mov	x0, x25
	stp	x9, x8, [x25, #96]
	mov	x2, x24
LBB6_25:                                ; %"wf_collections.priority_queue.priority_queue_make_room$instance$8ea10e07481bf32d.exit.i"
	add	x9, x20, #1
	add	x8, x8, x20, lsl #5
	stp	x2, x23, [x8]
	ldr	q0, [sp, #16]
	str	q0, [x8, #16]
	stur	x9, [x0, #88]
	ldr	x9, [x8, #16]
	cmp	x9, x22
	b.hs	LBB6_29
; %bb.26:                               ; %bb2.i.i.i.i9
	ldr	x10, [x8, #24]
	mov	w8, #56                         ; =0x38
	madd	x8, x9, x8, x21
	ldr	x9, [x8, #40]
	cmp	x9, x10
	b.ne	LBB6_29
; %bb.27:                               ; %bb5.i.i.i.i16
	ldr	x9, [x8]
	cbz	x9, LBB6_29
; %bb.28:                               ; %bb8.i.i.i.i
	str	x20, [x8, #32]
LBB6_29:                                ; %"wf_collections.priority_queue.priority_queue_push_indexed$instance$8a68ac1679550fca.exit.thread"
	add	x0, x0, #88
	mov	x1, x20
	mov	x2, x19
	bl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$8a68ac1679550fca
	mov	w0, #0                          ; =0x0
	b	LBB6_9
LBB6_30:                                ; %window.block.oom.v2.i.i.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_indexed_cost_delete$instance$2b4e452a2d5f5791
_wf_indexed_cost_delete$instance$2b4e452a2d5f5791: ; @"wf_indexed_cost_delete$instance$2b4e452a2d5f5791"
; %bb.0:                                ; %entry
	sub	sp, sp, #16
	mov	w9, #19867                      ; =0x4d9b
	movk	w9, #34, lsl #16
	ldr	x8, [x3]
	ldr	x10, [x0]
	cmp	x8, x10
	b.ne	LBB7_7
; %bb.1:                                ; %bb3.i.i
	ldr	x10, [x3, #8]
	ldr	x8, [x0, #16]
	cmp	x10, x8
	b.hs	LBB7_8
; %bb.2:                                ; %bb2.i.i.i
	ldr	x13, [x3, #16]
	ldr	x12, [x0, #32]
	mov	w8, #56                         ; =0x38
	madd	x8, x10, x8, x12
	ldr	x11, [x8, #40]
	cmp	x11, x13
	b.ne	LBB7_8
; %bb.3:                                ; %bb5.i.i.i
	ldr	x11, [x8]
	cbz	x11, LBB7_8
; %bb.4:                                ; %bb2.i
	ldrb	w14, [x8, #24]
	ldr	x15, [x8, #32]
	and	w14, w14, #0x1
	strb	w14, [sp, #8]
	ldrb	w16, [x0, #8]
	cmp	x15, #2, lsl #12                ; =8192
	csinc	w14, w14, wzr, eq
	tbz	w16, #0, LBB7_18
; %bb.5:                                ; %bb2.i
	tbz	w14, #0, LBB7_18
; %bb.6:
	mov	w8, #9                          ; =0x9
	b	LBB7_9
LBB7_7:
	mov	w8, #4                          ; =0x4
	b	LBB7_9
LBB7_8:                                 ; %bb5.i.i
	mov	w8, #3                          ; =0x3
LBB7_9:                                 ; %bb3
	ldp	x10, x11, [x1]
	cmp	x10, x11
	b.hs	LBB7_11
; %bb.10:                               ; %bb2.i.i54
	ldr	x12, [x1, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x1]
LBB7_11:                                ; %wf_indexed_cost_word.exit.i18
	ldr	x13, [x1, #24]
	cmp	x10, x11
	b.hs	LBB7_13
; %bb.12:                               ; %bb2.i12.i48
	ldr	x12, [x1, #16]
	mov	w14, #9                         ; =0x9
	str	x14, [x12, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x1]
LBB7_13:                                ; %wf_indexed_cost_word.exit18.i23
	ldr	x12, [x1, #32]
	madd	x9, x13, x9, x2
	mov	w13, #18340                     ; =0x47a4
	add	x9, x9, x13
	cmp	x10, x11
	b.hs	LBB7_15
; %bb.14:                               ; %bb2.i30.i42
	ldr	x13, [x1, #16]
	str	x2, [x13, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x1]
LBB7_15:                                ; %wf_indexed_cost_word.exit36.i28
	mov	w13, #131                       ; =0x83
	madd	x9, x9, x13, x8
	add	x12, x12, #4
	stp	x9, x12, [x1, #24]
	cmp	x10, x11
	b.hs	LBB7_17
LBB7_16:                                ; %bb1.sink.split
	ldr	x9, [x1, #16]
	str	x8, [x9, x10, lsl #3]
	add	x8, x10, #1
	str	x8, [x1]
LBB7_17:                                ; %bb1
	add	sp, sp, #16
	ret
LBB7_18:                                ; %bb8.i.i
	sub	x11, x11, #1
	add	x14, x8, x11, lsl #5
	str	x11, [x8]
	ldp	x11, x8, [x14, #8]
	cmn	x13, #1
	b.eq	LBB7_20
; %bb.19:                               ; %bb11.i.i
	add	x13, x13, #1
	mov	w14, #56                        ; =0x38
	ldr	x15, [x0, #40]
	madd	x12, x10, x14, x12
	stp	x13, x15, [x12, #40]
	str	x10, [x0, #40]
LBB7_20:                                ; %bb2
	ldp	x10, x12, [x1]
	cmp	x10, x12
	b.hs	LBB7_22
; %bb.21:                               ; %bb2.i.i
	ldr	x13, [x1, #16]
	mov	w14, #1                         ; =0x1
	str	x14, [x13, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x1]
LBB7_22:                                ; %wf_indexed_cost_word.exit.i
	cmp	x10, x12
	b.hs	LBB7_24
; %bb.23:                               ; %bb2.i12.i
	ldr	x13, [x1, #16]
	mov	w14, #9                         ; =0x9
	str	x14, [x13, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x1]
LBB7_24:                                ; %wf_indexed_cost_word.exit18.i
	ldr	x14, [x1, #24]
	mov	w13, #18340                     ; =0x47a4
	cmp	x10, x12
	b.hs	LBB7_26
; %bb.25:                               ; %bb2.i30.i
	ldr	x15, [x1, #16]
	str	x2, [x15, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x1]
LBB7_26:                                ; %wf_indexed_cost_word.exit36.i
	madd	x14, x14, x9, x2
	cmp	x10, x12
	b.hs	LBB7_28
; %bb.27:                               ; %bb2.i49.i
	ldr	x15, [x1, #16]
	str	xzr, [x15, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x1]
LBB7_28:                                ; %wf_indexed_cost_outcome.exit
	add	x14, x14, x13
	cmp	x10, x12
	b.hs	LBB7_30
; %bb.29:                               ; %bb2.i.i.i9
	ldr	x13, [x1, #16]
	mov	w15, #4                         ; =0x4
	str	x15, [x13, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x1]
LBB7_30:                                ; %wf_indexed_cost_word.exit.i.i
	ldr	x13, [x1, #32]
	madd	x9, x14, x9, x11
	add	x9, x9, #524
	cmp	x10, x12
	b.hs	LBB7_32
; %bb.31:                               ; %bb2.i12.i.i
	ldr	x14, [x1, #16]
	str	x11, [x14, x10, lsl #3]
	add	x10, x10, #1
	str	x10, [x1]
LBB7_32:                                ; %wf_indexed_cost_word.exit18.i.i
	mov	w11, #131                       ; =0x83
	madd	x9, x9, x11, x8
	add	x11, x13, #7
	stp	x9, x11, [x1, #24]
	cmp	x10, x12
	b.lo	LBB7_16
	b	LBB7_17
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_store_detach$instance$d656314a40e34216
_wf_record_store_detach$instance$d656314a40e34216: ; @"wf_record_store_detach$instance$d656314a40e34216"
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	ldr	x9, [x0]
	cmp	x8, x9
	b.ne	LBB8_3
; %bb.1:                                ; %bb3
	ldr	x8, [x0, #112]
	cbz	x8, LBB8_5
; %bb.2:                                ; %bb3.i.i
	udiv	x9, x1, x8
	msub	x13, x9, x8, x1
	ldr	x11, [x0, #48]
	cbnz	x11, LBB8_6
	b	LBB8_26
LBB8_3:
	mov	w8, #4                          ; =0x4
LBB8_4:                                 ; %common.ret
	mov	x0, x8
	ret
LBB8_5:
	mov	x13, #0                         ; =0x0
	ldr	x11, [x0, #48]
	cbz	x11, LBB8_26
LBB8_6:                                 ; %bb3.i
	ldp	x10, x9, [x2, #8]
	mov	x12, x11
	udiv	x14, x13, x11
	msub	x14, x14, x11, x13
	ldr	x13, [x0, #64]
	mov	x15, x11
	b	LBB8_8
LBB8_7:                                 ; %bb8.i
                                        ;   in Loop: Header=BB8_8 Depth=1
	add	x16, x14, #1
	cmp	x16, x11
	csinc	x14, xzr, x14, hs
	subs	x15, x15, #1
	b.eq	LBB8_26
LBB8_8:                                 ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x16, x13, x14, lsl #5
	ldr	w17, [x16]
	cmp	w17, #1
	b.eq	LBB8_7
; %bb.9:                                ; %bb5.i
                                        ;   in Loop: Header=BB8_8 Depth=1
	cmp	w17, #2
	b.ne	LBB8_26
; %bb.10:                               ; %bb9.i
                                        ;   in Loop: Header=BB8_8 Depth=1
	ldr	x17, [x16, #8]
	cmp	x17, x1
	b.ne	LBB8_7
; %bb.11:                               ; %bb4
	ldp	x14, x15, [x16, #16]
	cmp	x14, x10
	ccmp	x15, x9, #0, eq
	b.eq	LBB8_13
; %bb.12:
	mov	w0, #5                          ; =0x5
	ret
LBB8_13:                                ; %bb7
	ldr	x14, [x0, #72]
	cbz	x14, LBB8_26
; %bb.14:                               ; %bb3.i5
	cbz	x8, LBB8_16
; %bb.15:                               ; %bb3.i.i.i.i
	udiv	x15, x1, x8
	msub	x8, x15, x8, x1
LBB8_16:                                ; %bb3.i.i.i
	udiv	x15, x8, x11
	msub	x15, x15, x11, x8
	b	LBB8_18
LBB8_17:                                ; %bb8.i.i.i
                                        ;   in Loop: Header=BB8_18 Depth=1
	add	x8, x15, #1
	cmp	x8, x11
	csinc	x15, xzr, x15, hs
	mov	w8, #2                          ; =0x2
	subs	x12, x12, #1
	b.eq	LBB8_4
LBB8_18:                                ; %bb5.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x8, x13, x15, lsl #5
	ldr	w16, [x8]
	cmp	w16, #1
	b.eq	LBB8_17
; %bb.19:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB8_18 Depth=1
	cmp	w16, #2
	b.ne	LBB8_26
; %bb.20:                               ; %bb3.i3.i.i.i
                                        ;   in Loop: Header=BB8_18 Depth=1
	ldr	x16, [x8, #8]
	cmp	x16, x1
	b.ne	LBB8_17
; %bb.21:                               ; %bb9
	mov	w11, #1                         ; =0x1
	str	w11, [x8]
	sub	x11, x14, #1
	stp	xzr, xzr, [x8, #16]
	str	xzr, [x8, #8]
	ldr	x8, [x0, #80]
	adds	x8, x8, #1
	csinv	x8, x8, xzr, lo
	stp	x11, x8, [x0, #72]
	ldr	x8, [x0, #16]
	cmp	x10, x8
	b.hs	LBB8_25
; %bb.22:                               ; %bb2.i.i
	ldr	x8, [x0, #32]
	mov	w11, #56                        ; =0x38
	madd	x10, x10, x11, x8
	ldr	x8, [x10, #40]
	cmp	x8, x9
	b.ne	LBB8_25
; %bb.23:                               ; %bb5.i.i
	ldr	x8, [x10]
	cbz	x8, LBB8_4
; %bb.24:                               ; %bb8.i.i
	strb	wzr, [x10, #24]
LBB8_25:
	mov	w0, #0                          ; =0x0
	ret
LBB8_26:
	mov	w0, #2                          ; =0x2
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_store_expire$instance$083db5949cf60ce0
_wf_record_store_expire$instance$083db5949cf60ce0: ; @"wf_record_store_expire$instance$083db5949cf60ce0"
; %bb.0:                                ; %entry
	sub	sp, sp, #496
	stp	x28, x27, [sp, #400]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #416]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #432]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #448]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #464]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #480]            ; 16-byte Folded Spill
	mov	x23, x0
	ldr	x8, [x23, #88]!
	cbz	x8, LBB9_34
; %bb.1:                                ; %bb5.lr.ph
	mov	x20, x2
	mov	x21, x1
	mov	x22, x0
	mov	x19, #0                         ; =0x0
	add	x24, sp, #32
	ldp	x10, x9, [x2, #24]
	stp	x10, x9, [sp, #16]              ; 16-byte Folded Spill
	mov	w27, #8192                      ; =0x2000
	mov	w28, #56                        ; =0x38
	mov	w25, #1                         ; =0x1
LBB9_2:                                 ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x22, #104]
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp, #32]
	ldr	x10, [sp, #32]
	cmp	x10, x21
	b.hi	LBB9_35
; %bb.3:                                ; %bb8
                                        ;   in Loop: Header=BB9_2 Depth=1
	ldur	x26, [x22, #16]
	subs	x2, x8, #1
	add	x8, x9, x2, lsl #5
	str	x2, [x23]
	ldp	q0, q1, [x8]
	stp	q0, q1, [sp, #368]
	b.eq	LBB9_9
; %bb.4:                                ; %bb2.i
                                        ;   in Loop: Header=BB9_2 Depth=1
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp, #368]
	ldp	q0, q1, [x8]
	stp	q0, q1, [x9]
	ldr	x8, [x9, #16]
	cmp	x8, x26
	b.hs	LBB9_8
; %bb.5:                                ; %bb2.i.i.i.i
                                        ;   in Loop: Header=BB9_2 Depth=1
	ldr	x9, [x9, #24]
	ldr	x10, [x22, #32]
	madd	x8, x8, x28, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB9_8
; %bb.6:                                ; %bb5.i.i.i.i
                                        ;   in Loop: Header=BB9_2 Depth=1
	ldr	x9, [x8]
	cbz	x9, LBB9_8
; %bb.7:                                ; %bb8.i.i.i.i
                                        ;   in Loop: Header=BB9_2 Depth=1
	str	xzr, [x8, #32]
LBB9_8:                                 ; %"wf_record_report_position$instance$d656314a40e34216.exit.i"
                                        ;   in Loop: Header=BB9_2 Depth=1
	add	x3, x22, #16
	mov	x0, x23
	mov	x1, #0                          ; =0x0
	bl	_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$8a68ac1679550fca
LBB9_9:                                 ; %"wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$8a68ac1679550fca.exit"
                                        ;   in Loop: Header=BB9_2 Depth=1
	ldp	q0, q1, [sp, #368]
	stp	q0, q1, [x24, #32]
	str	x27, [sp, #352]
	ldur	q0, [x24, #48]
	stur	q0, [x24, #64]
	ldr	x8, [sp, #96]
	cmp	x8, x26
	b.hs	LBB9_13
; %bb.10:                               ; %bb2.i.i
                                        ;   in Loop: Header=BB9_2 Depth=1
	ldr	x10, [sp, #104]
	ldr	x9, [x22, #32]
	madd	x9, x8, x28, x9
	ldr	x8, [x9, #40]
	cmp	x8, x10
	b.ne	LBB9_13
; %bb.11:                               ; %bb5.i.i
                                        ;   in Loop: Header=BB9_2 Depth=1
	ldr	x8, [x9]
	cbz	x8, LBB9_13
; %bb.12:                               ; %bb8.i.i
                                        ;   in Loop: Header=BB9_2 Depth=1
	mov	w8, #0                          ; =0x0
	str	x27, [x9, #32]
	b	LBB9_14
LBB9_13:                                ;   in Loop: Header=BB9_2 Depth=1
	mov	w8, #1                          ; =0x1
LBB9_14:                                ; %"wf_std.collections.slab.slab_edit$instance$8d4b560d82c479d8.exit"
                                        ;   in Loop: Header=BB9_2 Depth=1
	ldp	q0, q1, [x22, #64]
	stur	q0, [x24, #152]
	stur	q1, [x24, #168]
	ldr	q0, [x22, #96]
	stur	q0, [x24, #184]
	ldp	q0, q1, [x22]
	stur	q0, [x24, #88]
	stur	q1, [x24, #104]
	ldp	q0, q1, [x22, #32]
	stur	q0, [x24, #120]
	str	w8, [sp, #112]
	strh	wzr, [sp, #116]
	ldr	x8, [x22, #112]
	stur	x8, [x24, #200]
	stur	q1, [x24, #136]
	ldur	q0, [x24, #48]
	stur	q0, [x24, #208]
	ldr	x26, [sp, #120]
	ldr	x1, [sp, #72]
	str	x26, [sp, #256]
	ldur	q0, [x24, #48]
	stur	q0, [x24, #232]
	add	x2, x24, #224
	mov	x0, x22
	bl	_wf_record_store_detach$instance$d656314a40e34216
	ldr	x8, [x22]
	cmp	x26, x8
	b.ne	LBB9_21
; %bb.15:                               ; %bb3.i.i
                                        ;   in Loop: Header=BB9_2 Depth=1
	ldr	x8, [sp, #264]
	ldur	x9, [x22, #16]
	cmp	x8, x9
	b.hs	LBB9_22
; %bb.16:                               ; %bb2.i.i.i
                                        ;   in Loop: Header=BB9_2 Depth=1
	ldr	x10, [sp, #272]
	ldr	x9, [x22, #32]
	madd	x11, x8, x28, x9
	ldr	x12, [x11, #40]
	cmp	x12, x10
	b.ne	LBB9_22
; %bb.17:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB9_2 Depth=1
	ldr	x12, [x11]
	cbz	x12, LBB9_22
; %bb.18:                               ; %bb2.i7
                                        ;   in Loop: Header=BB9_2 Depth=1
	ldrb	w13, [x11, #24]
	ldr	x14, [x11, #32]
	and	w13, w13, #0x1
	strb	w13, [sp, #360]
	ldrb	w15, [x22, #8]
	cmp	x14, #2, lsl #12                ; =8192
	csinc	w13, w13, wzr, eq
	tbz	w15, #0, LBB9_25
; %bb.19:                               ; %bb2.i7
                                        ;   in Loop: Header=BB9_2 Depth=1
	tbz	w13, #0, LBB9_25
; %bb.20:                               ;   in Loop: Header=BB9_2 Depth=1
	mov	w8, #9                          ; =0x9
	b	LBB9_23
LBB9_21:                                ;   in Loop: Header=BB9_2 Depth=1
	mov	w8, #4                          ; =0x4
	b	LBB9_23
LBB9_22:                                ; %bb5.i.i6
                                        ;   in Loop: Header=BB9_2 Depth=1
	mov	w8, #3                          ; =0x3
LBB9_23:                                ; %"wf_record_store_delete$instance$d656314a40e34216.exit.thread"
                                        ;   in Loop: Header=BB9_2 Depth=1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x24, #256]
	str	w25, [sp, #280]
	str	w8, [sp, #284]
LBB9_24:                                ; %bb9
                                        ;   in Loop: Header=BB9_2 Depth=1
	ldr	x8, [x23]
	cbnz	x8, LBB9_2
	b	LBB9_35
LBB9_25:                                ; %bb8.i.i8
                                        ;   in Loop: Header=BB9_2 Depth=1
	sub	x12, x12, #1
	add	x13, x11, x12, lsl #5
	str	x12, [x11]
	ldur	q0, [x13, #8]
	ldur	q1, [x13, #24]
	stp	q0, q1, [sp, #368]
	cmn	x10, #1
	b.eq	LBB9_27
; %bb.26:                               ; %bb11.i.i
                                        ;   in Loop: Header=BB9_2 Depth=1
	add	x10, x10, #1
	ldr	x11, [x22, #40]
	madd	x9, x8, x28, x9
	stp	x10, x11, [x9, #40]
	str	x8, [x22, #40]
LBB9_27:                                ; %bb10
                                        ;   in Loop: Header=BB9_2 Depth=1
	str	xzr, [sp, #280]
	ldp	q0, q1, [sp, #368]
	stp	q0, q1, [x24, #256]
	ldp	q0, q1, [x24, #256]
	stp	q0, q1, [x24, #288]
	ldp	x8, x9, [x20]
	cmp	x8, x9
	b.hs	LBB9_29
; %bb.28:                               ; %bb2.i.i.i15
                                        ;   in Loop: Header=BB9_2 Depth=1
	ldr	x10, [x20, #16]
	mov	w11, #4                         ; =0x4
	str	x11, [x10, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x20]
LBB9_29:                                ; %wf_indexed_cost_word.exit.i.i
                                        ;   in Loop: Header=BB9_2 Depth=1
	ldp	x11, x10, [sp, #320]
	cmp	x8, x9
	b.hs	LBB9_31
; %bb.30:                               ; %bb2.i12.i.i
                                        ;   in Loop: Header=BB9_2 Depth=1
	ldr	x12, [x20, #16]
	str	x11, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x20]
LBB9_31:                                ; %wf_indexed_cost_word.exit18.i.i
                                        ;   in Loop: Header=BB9_2 Depth=1
	ldr	x12, [sp, #16]                  ; 8-byte Folded Reload
	mov	w13, #17161                     ; =0x4309
	madd	x11, x12, x13, x11
	add	x11, x11, #524
	mov	w12, #131                       ; =0x83
	madd	x12, x11, x12, x10
	ldr	x11, [sp, #24]                  ; 8-byte Folded Reload
	add	x11, x11, #3
	stp	x12, x11, [sp, #16]             ; 16-byte Folded Spill
	stp	x12, x11, [x20, #24]
	cmp	x8, x9
	b.hs	LBB9_33
; %bb.32:                               ; %bb2.i.i.i.i14
                                        ;   in Loop: Header=BB9_2 Depth=1
	ldr	x9, [x20, #16]
	str	x10, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x20]
LBB9_33:                                ; %"wf_indexed_cost_consume$instance$2b4e452a2d5f5791.exit"
                                        ;   in Loop: Header=BB9_2 Depth=1
	add	x19, x19, #1
	b	LBB9_24
LBB9_34:
	mov	x19, #0                         ; =0x0
LBB9_35:                                ; %bb2
	mov	x0, x19
	ldp	x29, x30, [sp, #480]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #464]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #448]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #432]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #416]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #400]            ; 16-byte Folded Reload
	add	sp, sp, #496
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$8a68ac1679550fca
_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$8a68ac1679550fca: ; @"wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$8a68ac1679550fca"
; %bb.0:                                ; %entry
	sub	sp, sp, #32
	cbz	x1, LBB10_2
; %bb.1:                                ; %bb2
	lsl	x8, x1, #4
	ldr	x9, [x0, #16]
	sub	x8, x8, #16
	and	x8, x8, #0xffffffffffffffe0
	add	x8, x9, x8
	add	x9, x9, x1, lsl #5
	ldr	x10, [x8]
	ldr	x11, [x9]
	cmp	x10, x11
	b.hs	LBB10_31
LBB10_2:                                ; %bb1
	lsr	x8, x2, #1
	cmp	x1, x8
	b.hs	LBB10_30
; %bb.3:                                ; %bb5.lr.ph.i
	ldr	x9, [x0]
	ldr	x10, [x0, #16]
	mov	w11, #56                        ; =0x38
	b	LBB10_5
LBB10_4:                                ; %"wf_record_report_position$instance$d656314a40e34216.exit24.i"
                                        ;   in Loop: Header=BB10_5 Depth=1
	cmp	x1, x8
	b.hs	LBB10_30
LBB10_5:                                ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	mov	x12, x1
	lsl	x14, x1, #1
	mov	w13, #1                         ; =0x1
	bfi	x13, x1, #1, #63
	add	x14, x14, #2
	cmp	x14, x9
	b.hs	LBB10_9
; %bb.6:                                ; %bb2.i.i
                                        ;   in Loop: Header=BB10_5 Depth=1
	add	x15, x10, x14, lsl #5
	add	x16, x10, x13, lsl #5
	ldr	x17, [x15]
	ldr	x0, [x16]
	cmp	x17, x0
	b.hs	LBB10_8
LBB10_7:                                ;   in Loop: Header=BB10_5 Depth=1
	mov	x1, x14
	b	LBB10_10
LBB10_8:                                ; %bb3.i.i.i
                                        ;   in Loop: Header=BB10_5 Depth=1
	b.ls	LBB10_25
LBB10_9:                                ;   in Loop: Header=BB10_5 Depth=1
	mov	x1, x13
LBB10_10:                               ; %"wf_collections.priority_queue.priority_queue_child$instance$b5f40c82891b87e4.exit.i"
                                        ;   in Loop: Header=BB10_5 Depth=1
	add	x14, x10, x12, lsl #5
	add	x13, x10, x1, lsl #5
	ldr	x15, [x14]
	ldr	x16, [x13]
	cmp	x15, x16
	b.lo	LBB10_30
; %bb.11:                               ; %bb3.i.i
                                        ;   in Loop: Header=BB10_5 Depth=1
	b.hi	LBB10_17
; %bb.12:                               ; %bb6.i.i
                                        ;   in Loop: Header=BB10_5 Depth=1
	ldr	x15, [x14, #8]
	ldr	x16, [x13, #8]
	cmp	x15, x16
	b.lo	LBB10_30
; %bb.13:                               ; %bb9.i.i
                                        ;   in Loop: Header=BB10_5 Depth=1
	b.hi	LBB10_17
; %bb.14:                               ; %bb12.i.i
                                        ;   in Loop: Header=BB10_5 Depth=1
	ldr	x15, [x14, #16]
	ldr	x16, [x13, #16]
	cmp	x15, x16
	b.lo	LBB10_30
; %bb.15:                               ; %bb15.i.i
                                        ;   in Loop: Header=BB10_5 Depth=1
	b.hi	LBB10_17
; %bb.16:                               ; %bb18.i.i
                                        ;   in Loop: Header=BB10_5 Depth=1
	ldr	x15, [x14, #24]
	ldr	x16, [x13, #24]
	cmp	x15, x16
	b.ls	LBB10_30
LBB10_17:                               ; %bb8.i
                                        ;   in Loop: Header=BB10_5 Depth=1
	ldp	q1, q0, [x14]
	ldp	q3, q2, [x13]
	stp	q3, q2, [x14]
	stp	q1, q0, [x13]
	ldr	x16, [x14, #16]
	ldr	x15, [x3]
	cmp	x16, x15
	b.hs	LBB10_21
; %bb.18:                               ; %bb2.i.i.i.i
                                        ;   in Loop: Header=BB10_5 Depth=1
	ldr	x17, [x14, #24]
	ldr	x14, [x3, #16]
	madd	x14, x16, x11, x14
	ldr	x16, [x14, #40]
	cmp	x16, x17
	b.ne	LBB10_21
; %bb.19:                               ; %bb5.i.i.i.i
                                        ;   in Loop: Header=BB10_5 Depth=1
	ldr	x16, [x14]
	cbz	x16, LBB10_21
; %bb.20:                               ; %bb8.i.i.i.i
                                        ;   in Loop: Header=BB10_5 Depth=1
	str	x12, [x14, #32]
LBB10_21:                               ; %"wf_record_report_position$instance$d656314a40e34216.exit.i"
                                        ;   in Loop: Header=BB10_5 Depth=1
	ldr	x12, [x13, #16]
	cmp	x12, x15
	b.hs	LBB10_4
; %bb.22:                               ; %bb2.i.i.i11.i
                                        ;   in Loop: Header=BB10_5 Depth=1
	ldr	x13, [x13, #24]
	ldr	x14, [x3, #16]
	madd	x12, x12, x11, x14
	ldr	x14, [x12, #40]
	cmp	x14, x13
	b.ne	LBB10_4
; %bb.23:                               ; %bb5.i.i.i19.i
                                        ;   in Loop: Header=BB10_5 Depth=1
	ldr	x13, [x12]
	cbz	x13, LBB10_4
; %bb.24:                               ; %bb8.i.i.i22.i
                                        ;   in Loop: Header=BB10_5 Depth=1
	str	x1, [x12, #32]
	b	LBB10_4
LBB10_25:                               ; %bb6.i.i.i
                                        ;   in Loop: Header=BB10_5 Depth=1
	ldr	x17, [x15, #8]
	ldr	x0, [x16, #8]
	cmp	x17, x0
	b.lo	LBB10_7
; %bb.26:                               ; %bb9.i.i.i
                                        ;   in Loop: Header=BB10_5 Depth=1
	b.hi	LBB10_9
; %bb.27:                               ; %bb12.i.i.i
                                        ;   in Loop: Header=BB10_5 Depth=1
	ldr	x17, [x15, #16]
	ldr	x0, [x16, #16]
	mov	x1, x14
	cmp	x17, x0
	b.lo	LBB10_10
; %bb.28:                               ; %bb15.i.i.i
                                        ;   in Loop: Header=BB10_5 Depth=1
	mov	x1, x13
	b.hi	LBB10_10
; %bb.29:                               ; %bb18.i.i.i
                                        ;   in Loop: Header=BB10_5 Depth=1
	ldr	x15, [x15, #24]
	ldr	x16, [x16, #24]
	cmp	x15, x16
	csel	x1, x14, x13, lo
	b	LBB10_10
LBB10_30:                               ; %common.ret
	add	sp, sp, #32
	ret
LBB10_31:                               ; %bb3.i
	b.ls	LBB10_33
LBB10_32:                               ; %bb5
	mov	x2, x3
	add	sp, sp, #32
	b	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$8a68ac1679550fca
LBB10_33:                               ; %bb6.i
	ldr	x10, [x8, #8]
	ldr	x11, [x9, #8]
	cmp	x10, x11
	b.lo	LBB10_2
; %bb.34:                               ; %bb9.i
	b.hi	LBB10_32
; %bb.35:                               ; %bb12.i
	ldr	x10, [x8, #16]
	ldr	x11, [x9, #16]
	cmp	x10, x11
	b.lo	LBB10_2
; %bb.36:                               ; %bb15.i
	b.hi	LBB10_32
; %bb.37:                               ; %bb18.i
	ldr	x8, [x8, #24]
	ldr	x9, [x9, #24]
	cmp	x8, x9
	b.ls	LBB10_2
	b	LBB10_32
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$8a68ac1679550fca
_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$8a68ac1679550fca: ; @"wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$8a68ac1679550fca"
; %bb.0:                                ; %entry
	cbz	x1, LBB11_19
; %bb.1:                                ; %bb5.lr.ph
	sub	sp, sp, #32
	ldr	x8, [x0, #16]
	mov	w9, #56                         ; =0x38
	b	LBB11_3
LBB11_2:                                ; %"wf_record_report_position$instance$d656314a40e34216.exit23"
                                        ;   in Loop: Header=BB11_3 Depth=1
	cmp	x10, #2
	b.lo	LBB11_18
LBB11_3:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	mov	x11, x1
	sub	x10, x1, #1
	lsr	x1, x10, #1
	add	x13, x8, x1, lsl #5
	add	x12, x8, x11, lsl #5
	ldr	x14, [x13]
	ldr	x15, [x12]
	cmp	x14, x15
	b.lo	LBB11_18
; %bb.4:                                ; %bb3.i
                                        ;   in Loop: Header=BB11_3 Depth=1
	b.hi	LBB11_10
; %bb.5:                                ; %bb6.i
                                        ;   in Loop: Header=BB11_3 Depth=1
	ldr	x14, [x13, #8]
	ldr	x15, [x12, #8]
	cmp	x14, x15
	b.lo	LBB11_18
; %bb.6:                                ; %bb9.i
                                        ;   in Loop: Header=BB11_3 Depth=1
	b.hi	LBB11_10
; %bb.7:                                ; %bb12.i
                                        ;   in Loop: Header=BB11_3 Depth=1
	ldr	x14, [x13, #16]
	ldr	x15, [x12, #16]
	cmp	x14, x15
	b.lo	LBB11_18
; %bb.8:                                ; %bb15.i
                                        ;   in Loop: Header=BB11_3 Depth=1
	b.hi	LBB11_10
; %bb.9:                                ; %bb18.i
                                        ;   in Loop: Header=BB11_3 Depth=1
	ldr	x14, [x13, #24]
	ldr	x15, [x12, #24]
	cmp	x14, x15
	b.ls	LBB11_18
LBB11_10:                               ; %bb8
                                        ;   in Loop: Header=BB11_3 Depth=1
	ldp	q1, q0, [x13]
	ldp	q3, q2, [x12]
	stp	q3, q2, [x13]
	stp	q1, q0, [x12]
	ldr	x15, [x13, #16]
	ldr	x14, [x2]
	cmp	x15, x14
	b.hs	LBB11_14
; %bb.11:                               ; %bb2.i.i.i
                                        ;   in Loop: Header=BB11_3 Depth=1
	ldr	x16, [x13, #24]
	ldr	x13, [x2, #16]
	madd	x13, x15, x9, x13
	ldr	x15, [x13, #40]
	cmp	x15, x16
	b.ne	LBB11_14
; %bb.12:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB11_3 Depth=1
	ldr	x15, [x13]
	cbz	x15, LBB11_14
; %bb.13:                               ; %bb8.i.i.i
                                        ;   in Loop: Header=BB11_3 Depth=1
	str	x1, [x13, #32]
LBB11_14:                               ; %"wf_record_report_position$instance$d656314a40e34216.exit"
                                        ;   in Loop: Header=BB11_3 Depth=1
	ldr	x13, [x12, #16]
	cmp	x13, x14
	b.hs	LBB11_2
; %bb.15:                               ; %bb2.i.i.i10
                                        ;   in Loop: Header=BB11_3 Depth=1
	ldr	x14, [x12, #24]
	ldr	x12, [x2, #16]
	madd	x12, x13, x9, x12
	ldr	x13, [x12, #40]
	cmp	x13, x14
	b.ne	LBB11_2
; %bb.16:                               ; %bb5.i.i.i18
                                        ;   in Loop: Header=BB11_3 Depth=1
	ldr	x13, [x12]
	cbz	x13, LBB11_2
; %bb.17:                               ; %bb8.i.i.i21
                                        ;   in Loop: Header=BB11_3 Depth=1
	str	x11, [x12, #32]
	b	LBB11_2
LBB11_18:
	add	sp, sp, #32
LBB11_19:                               ; %common.ret
	ret
                                        ; -- End function
	.globl	_wf__floor_run                  ; -- Begin function wf__floor_run
	.weak_definition	_wf__floor_run
	.p2align	2
_wf__floor_run:                         ; @wf__floor_run
	.cfi_startproc
; %bb.0:                                ; %entry
	b	_wf__main_body
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf__main_body
lCPI13_0:
	.quad	101                             ; 0x65
	.quad	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf__main_body
	.p2align	2
_wf__main_body:                         ; @wf__main_body
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 96
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stp	xzr, xzr, [sp, #40]
Lloh10:
	adrp	x8, l_.wf.empty.slots.payload@PAGE
Lloh11:
	add	x8, x8, l_.wf.empty.slots.payload@PAGEOFF
	str	x8, [sp, #56]
Lloh12:
	adrp	x8, lCPI13_0@PAGE
Lloh13:
	ldr	q0, [x8, lCPI13_0@PAGEOFF]
	stur	q0, [sp, #64]
	add	x4, sp, #40
	mov	w0, #16                         ; =0x10
	mov	w1, #101                        ; =0x65
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	bl	_wf_indexed_cost_small_trace
	mov	x0, sp
	mov	w1, #0                          ; =0x0
	bl	_wf_std.process.exit_status
	ldr	x8, [sp, #48]
	cbz	x8, LBB13_2
; %bb.1:                                ; %slots.release.drop.8.i
	ldr	x0, [sp, #56]
	bl	_free
LBB13_2:                                ; %wf_main.exit
	mov	x0, sp
	bl	_wf__ordinary_exit_code
	and	w0, w0, #0xff
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdd	Lloh10, Lloh11
	.cfi_endproc
                                        ; -- End function
.zerofill __DATA,__bss,l_.wf.empty.slots.payload,8,3 ; @.wf.empty.slots.payload
	.section	__TEXT,__const
l_.wf_resource.heap:                    ; @.wf_resource.heap
	.ascii	"{\"resource\":\"heap\"}\n"

.subsections_via_symbols
