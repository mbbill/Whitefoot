	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function wf_resource_record_abort
l_wf_resource_record_abort:             ; @wf_resource_record_abort
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
Lloh0:
	adrp	x19, l_.wf_resource.heap@PAGE
Lloh1:
	add	x19, x19, l_.wf_resource.heap@PAGEOFF
	mov	w20, #20                        ; =0x14
	b	LBB0_2
LBB0_1:                                 ; %error.i
                                        ;   in Loop: Header=BB0_2 Depth=1
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #4
	b.ne	LBB0_6
LBB0_2:                                 ; %write.i
                                        ; =>This Inner Loop Header: Depth=1
	mov	w0, #2                          ; =0x2
	mov	x1, x19
	mov	x2, x20
	bl	_write
	tbnz	x0, #63, LBB0_1
; %bb.3:                                ; %wf_resource_write.exit
                                        ;   in Loop: Header=BB0_2 Depth=1
	subs	x20, x20, x0
	b.eq	LBB0_6
; %bb.4:                                ; %wf_resource_write.exit
                                        ;   in Loop: Header=BB0_2 Depth=1
	cbz	x0, LBB0_6
; %bb.5:                                ; %write.more
                                        ;   in Loop: Header=BB0_2 Depth=1
	add	x19, x19, x0
	b	LBB0_2
LBB0_6:                                 ; %abort
	bl	_abort
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_resource_abort
l_wf_resource_abort:                    ; @wf_resource_abort
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	l_wf_resource_record_abort
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_indexed_cost_small_make
_wf_indexed_cost_small_make:            ; @wf_indexed_cost_small_make
; %bb.0:                                ; %entry
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_indexed_cost_small_observe
_wf_indexed_cost_small_observe:         ; @wf_indexed_cost_small_observe
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	mov	w9, #131                        ; =0x83
	ldp	x10, x11, [x0, #24]
	madd	x9, x10, x9, x8
	add	x10, x11, #1
	stp	x9, x10, [x0, #24]
	ldp	x9, x10, [x0]
	cmp	x9, x10
	b.hs	LBB3_2
; %bb.1:                                ; %bb2.i
	ldr	x10, [x0, #16]
	str	x8, [x10, x9, lsl #3]
	add	x8, x9, #1
	str	x8, [x0]
LBB3_2:                                 ; %wf_indexed_cost_word.exit
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_indexed_cost_small_consume
_wf_indexed_cost_small_consume:         ; @wf_indexed_cost_small_consume
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	mov	w9, #131                        ; =0x83
	ldp	x10, x11, [x0, #24]
	madd	x9, x10, x9, x8
	add	x10, x11, #1
	stp	x9, x10, [x0, #24]
	ldp	x9, x10, [x0]
	cmp	x9, x10
	b.hs	LBB4_2
; %bb.1:                                ; %bb2.i
	ldr	x10, [x0, #16]
	str	x8, [x10, x9, lsl #3]
	add	x8, x9, #1
	str	x8, [x0]
LBB4_2:                                 ; %wf_indexed_cost_word.exit
	ret
                                        ; -- End function
	.globl	_wf_indexed_cost_small_trace    ; -- Begin function wf_indexed_cost_small_trace
	.p2align	2
_wf_indexed_cost_small_trace:           ; @wf_indexed_cost_small_trace
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #592
	.cfi_def_cfa_offset 688
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x4
	mov	x25, x3
	mov	x22, x2
	mov	x24, x1
	mov	x21, x0
	add	x26, sp, #32
	add	x20, x26, #440
	lsl	x23, x0, #1
	cmp	x3, #0
	csel	x3, x23, xzr, eq
	cmp	x2, #0
	cset	w1, ne
	mov	x0, x20
	mov	x2, x21
	mov	x4, x3
	bl	_wf_record_store_new$instance$d656314a40e34216
	lsl	x27, x21, #2
	cbz	x21, LBB5_48
; %bb.1:                                ; %bb5.i.preheader
	stp	x23, x25, [sp, #16]             ; 16-byte Folded Spill
	str	x22, [sp, #8]                   ; 8-byte Folded Spill
	mov	x25, #0                         ; =0x0
	mov	w22, #8191                      ; =0x1fff
	mov	w26, #1                         ; =0x1
	mov	x28, #32557                     ; =0x7f2d
	movk	x28, #19605, lsl #16
	movk	x28, #62509, lsl #32
	movk	x28, #22609, lsl #48
	mov	x23, #33103                     ; =0x814f
	movk	x23, #63335, lsl #16
	movk	x23, #31614, lsl #32
	movk	x23, #5125, lsl #48
LBB5_2:                                 ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	madd	x24, x24, x28, x23
	lsr	x8, x24, #32
	udiv	x9, x8, x27
	msub	x8, x9, x27, x8
	and	x9, x25, #0x7
	cmp	x9, #1
	csel	x2, x22, x26, eq
	add	x25, x25, #1
	add	x4, x8, x27
	mov	x0, x20
	mov	x1, x19
	mov	x3, x25
	bl	_wf_indexed_cost_insert$instance$2b4e452a2d5f5791
	add	x22, x22, #2
	add	x26, x26, #2
	cmp	x21, x25
	b.ne	LBB5_2
; %bb.3:                                ; %bb7.thread.i
	add	x3, x21, #1
	mov	x0, x20
	mov	x1, x19
	mov	x2, #-1                         ; =0xffffffffffffffff
	mov	x4, #0                          ; =0x0
	bl	_wf_indexed_cost_insert$instance$2b4e452a2d5f5791
	add	x26, sp, #32
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	cbnz	x8, LBB5_49
; %bb.4:                                ; %bb13.lr.ph.i
	mov	x22, #0                         ; =0x0
	lsl	x8, x21, #4
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	mov	w25, #8191                      ; =0x1fff
	mov	w28, #131                       ; =0x83
	mov	w24, #1                         ; =0x1
	b	LBB5_6
LBB5_5:                                 ; %bb25.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	add	x22, x22, #1
	add	x25, x25, #2
	add	x24, x24, #2
	cmp	x21, x22
	b.eq	LBB5_50
LBB5_6:                                 ; %bb13.i
                                        ; =>This Inner Loop Header: Depth=1
	and	x8, x22, #0x7
	cmp	x8, #1
	csel	x23, x25, x24, eq
	add	x0, sp, #32
	mov	x1, x20
	mov	x2, x19
	mov	x3, x23
	bl	_wf_indexed_cost_lookup$instance$174c6fc95f4077f6
	ldr	w8, [sp, #32]
	cbnz	w8, LBB5_5
; %bb.7:                                ; %bb17.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	add	x8, sp, #32
	ldur	q0, [x8, #8]
	stur	q0, [x26, #32]
	ldur	x8, [x8, #24]
	stur	x8, [x26, #48]
	add	x1, x26, #32
	mov	x0, x20
	mov	x2, x19
	bl	_wf_record_store_visit$instance$97c7d7c95188d5f1
	str	w0, [sp, #88]
	strb	w1, [sp, #92]
	str	w2, [sp, #96]
	cbz	w0, LBB5_13
; %bb.8:                                ; %bb21.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	ldp	x9, x10, [x19, #24]
	ldp	x8, x11, [x19]
	cmp	x8, x11
	b.lo	LBB5_44
; %bb.9:                                ; %wf_indexed_cost_word.exit.i216.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	cmp	x8, x11
	b.lo	LBB5_45
LBB5_10:                                ; %wf_indexed_cost_word.exit18.i221.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	cmp	x8, x11
	b.hs	LBB5_12
LBB5_11:                                ; %bb2.i30.i250.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	ldr	x12, [x19, #16]
	str	x23, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB5_12:                                ; %switch.lookup14
                                        ;   in Loop: Header=BB5_6 Depth=1
	mov	w12, #19867                     ; =0x4d9b
	movk	w12, #34, lsl #16
	madd	x9, x9, x12, x23
	mov	w12, #18733                     ; =0x492d
	add	x9, x9, x12
	mov	w12, w2
	madd	x9, x9, x28, x12
	add	x10, x10, #4
	stp	x9, x10, [x19, #24]
	cmp	x8, x11
	b.lo	LBB5_19
	b	LBB5_20
LBB5_13:                                ; %bb20.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	ldp	x9, x10, [x19, #24]
	ldp	x8, x11, [x19]
	cmp	x8, x11
	b.lo	LBB5_46
; %bb.14:                               ; %wf_indexed_cost_word.exit.i165.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	cmp	x8, x11
	b.lo	LBB5_47
LBB5_15:                                ; %wf_indexed_cost_word.exit18.i170.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	cmp	x8, x11
	b.hs	LBB5_17
LBB5_16:                                ; %bb2.i30.i189.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	ldr	x12, [x19, #16]
	str	x23, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB5_17:                                ; %wf_indexed_cost_word.exit36.i175.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	mov	w12, #19867                     ; =0x4d9b
	movk	w12, #34, lsl #16
	madd	x9, x9, x12, x23
	mov	w12, #18733                     ; =0x492d
	add	x9, x9, x12
	mul	x9, x9, x28
	add	x10, x10, #4
	stp	x9, x10, [x19, #24]
	cmp	x8, x11
	b.hs	LBB5_20
; %bb.18:                               ;   in Loop: Header=BB5_6 Depth=1
	mov	x12, #0                         ; =0x0
LBB5_19:                                ; %bb19.sink.split.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	ldr	x9, [x19, #16]
	str	x12, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	ldp	x9, x10, [x19, #24]
LBB5_20:                                ; %bb19.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	ldr	x11, [x19, #8]
	cmp	x8, x11
	b.hs	LBB5_22
; %bb.21:                               ; %bb2.i.i.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #3                         ; =0x3
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB5_22:                                ; %wf_indexed_cost_word.exit.i.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	add	x12, x21, x22
	add	x0, x12, #2
	mov	w13, #17161                     ; =0x4309
	madd	x9, x9, x13, x12
	add	x9, x9, #395
	add	x10, x10, #2
	stp	x9, x10, [x19, #24]
	cmp	x8, x11
	b.hs	LBB5_24
; %bb.23:                               ; %bb2.i12.i.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	ldr	x9, [x19, #16]
	str	x0, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB5_24:                                ; %wf_indexed_cost_offer.exit.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	bl	_wf_indexed_cost_small_make
	str	x0, [sp, #104]
	add	x2, x26, #72
	mov	x0, x20
	mov	x1, x23
	bl	_wf_record_store_replace$instance$d656314a40e34216
	str	w0, [sp, #112]
	stp	x1, x1, [sp, #120]
	ldp	x11, x9, [x19, #24]
	ldp	x8, x10, [x19]
	cmp	x8, x10
	b.lo	LBB5_40
; %bb.25:                               ; %wf_indexed_cost_word.exit.i52.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	cmp	x8, x10
	b.lo	LBB5_41
LBB5_26:                                ; %wf_indexed_cost_word.exit18.i.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	cmp	x8, x10
	b.hs	LBB5_28
LBB5_27:                                ; %bb2.i30.i.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	ldr	x12, [x19, #16]
	str	x23, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB5_28:                                ; %switch.lookup
                                        ;   in Loop: Header=BB5_6 Depth=1
	mov	w12, #19867                     ; =0x4d9b
	movk	w12, #34, lsl #16
	madd	x11, x11, x12, x23
	mov	w12, #17816                     ; =0x4598
	add	x11, x11, x12
	mov	w12, w0
	madd	x11, x11, x28, x12
	add	x9, x9, #4
	stp	x11, x9, [x19, #24]
	cmp	x8, x10
	b.hs	LBB5_30
; %bb.29:                               ; %bb2.i49.i.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	ldr	x9, [x19, #16]
	str	x12, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	ldp	x11, x9, [x19, #24]
LBB5_30:                                ; %wf_indexed_cost_outcome.exit.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	ldr	x10, [x19, #8]
	cmp	x8, x10
	b.hs	LBB5_32
; %bb.31:                               ; %bb2.i.i90.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #4                         ; =0x4
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB5_32:                                ; %wf_indexed_cost_word.exit.i77.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	mov	w12, #17161                     ; =0x4309
	madd	x11, x11, x12, x23
	add	x11, x11, #524
	add	x9, x9, #2
	stp	x11, x9, [x19, #24]
	cmp	x8, x10
	b.hs	LBB5_34
; %bb.33:                               ; %bb2.i12.i84.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	ldr	x9, [x19, #16]
	str	x23, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB5_34:                                ; %"wf_indexed_cost_accept$instance$2b4e452a2d5f5791.exit.i"
                                        ;   in Loop: Header=BB5_6 Depth=1
	add	x1, x26, #96
	mov	x0, x19
	bl	_wf_indexed_cost_small_consume
	sbfx	x8, x22, #0, #1
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	and	x8, x8, x9
	add	x1, x26, #32
	add	x2, x8, x22
	mov	x0, x20
	bl	_wf_record_store_reschedule$instance$d656314a40e34216
	ldp	x11, x9, [x19, #24]
	ldp	x8, x10, [x19]
	cmp	x8, x10
	b.lo	LBB5_42
; %bb.35:                               ; %wf_indexed_cost_word.exit.i104.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	cmp	x8, x10
	b.lo	LBB5_43
LBB5_36:                                ; %wf_indexed_cost_word.exit18.i109.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	cmp	x8, x10
	b.hs	LBB5_38
LBB5_37:                                ; %bb2.i30.i138.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	ldr	x12, [x19, #16]
	str	x23, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB5_38:                                ; %switch.lookup12
                                        ;   in Loop: Header=BB5_6 Depth=1
	mov	w12, #19867                     ; =0x4d9b
	movk	w12, #34, lsl #16
	madd	x11, x11, x12, x23
	mov	w12, #17947                     ; =0x461b
	add	x12, x11, x12
	mov	w11, w0
	madd	x12, x12, x28, x11
	add	x9, x9, #4
	stp	x12, x9, [x19, #24]
	cmp	x8, x10
	b.hs	LBB5_5
; %bb.39:                               ; %bb2.i49.i123.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	ldr	x9, [x19, #16]
	str	x11, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	b	LBB5_5
LBB5_40:                                ; %bb2.i.i63.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.hs	LBB5_26
LBB5_41:                                ; %bb2.i12.i57.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #5                         ; =0x5
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB5_27
	b	LBB5_28
LBB5_42:                                ; %bb2.i.i150.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.hs	LBB5_36
LBB5_43:                                ; %bb2.i12.i144.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #6                         ; =0x6
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB5_37
	b	LBB5_38
LBB5_44:                                ; %bb2.i.i262.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x11
	b.hs	LBB5_10
LBB5_45:                                ; %bb2.i12.i256.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #12                        ; =0xc
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x11
	b.lo	LBB5_11
	b	LBB5_12
LBB5_46:                                ; %bb2.i.i201.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x11
	b.hs	LBB5_15
LBB5_47:                                ; %bb2.i12.i195.i
                                        ;   in Loop: Header=BB5_6 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #12                        ; =0xc
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x11
	b.lo	LBB5_16
	b	LBB5_17
LBB5_48:                                ; %bb7.i
	mov	x0, x20
	mov	x1, x19
	mov	x2, #-1                         ; =0xffffffffffffffff
	mov	w3, #1                          ; =0x1
	mov	x4, #0                          ; =0x0
	bl	_wf_indexed_cost_insert$instance$2b4e452a2d5f5791
	cbz	x25, LBB5_118
LBB5_49:                                ; %bb11.i
	mov	x0, x20
	mov	x1, #-1                         ; =0xffffffffffffffff
	b	LBB5_128
LBB5_50:                                ; %bb27.lr.ph.i
	mov	x28, #0                         ; =0x0
	mov	w22, #9053                      ; =0x235d
	movk	w22, #36, lsl #16
	lsl	x24, x21, #3
	mov	w25, #23106                     ; =0x5a42
	movk	w25, #35, lsl #16
	mov	w23, #1                         ; =0x1
	mov	w26, #9053                      ; =0x235d
	movk	w26, #36, lsl #16
	str	x24, [sp, #24]                  ; 8-byte Folded Spill
	b	LBB5_52
LBB5_51:                                ; %bb36.i
                                        ;   in Loop: Header=BB5_52 Depth=1
	add	x28, x28, #1
	add	x24, x24, #1
	add	x25, x25, #262
	add	x26, x26, #262
	add	x23, x23, #2
	cmp	x21, x28
	b.eq	LBB5_70
LBB5_52:                                ; %bb27.i
                                        ; =>This Inner Loop Header: Depth=1
	tst	x28, #0x3
	b.ne	LBB5_51
; %bb.53:                               ; %bb31.i
                                        ;   in Loop: Header=BB5_52 Depth=1
	add	x8, sp, #32
	add	x0, x8, #104
	mov	x1, x20
	mov	x2, x19
	mov	x3, x23
	bl	_wf_indexed_cost_lookup$instance$174c6fc95f4077f6
	ldr	w8, [sp, #136]
	cbnz	w8, LBB5_51
; %bb.54:                               ; %bb34.i
                                        ;   in Loop: Header=BB5_52 Depth=1
	add	x8, sp, #32
	ldur	q0, [x8, #112]
	add	x9, sp, #32
	stur	q0, [x9, #136]
	ldur	x8, [x8, #128]
	stur	x8, [x9, #152]
	add	x1, x9, #136
	mov	x0, x20
	bl	_wf_record_store_cancel$instance$d656314a40e34216
	ldp	x11, x9, [x19, #24]
	ldp	x8, x10, [x19]
	cmp	x8, x10
	b.lo	LBB5_66
; %bb.55:                               ; %wf_indexed_cost_word.exit.i283.i
                                        ;   in Loop: Header=BB5_52 Depth=1
	cmp	x8, x10
	b.lo	LBB5_67
LBB5_56:                                ; %wf_indexed_cost_word.exit18.i288.i
                                        ;   in Loop: Header=BB5_52 Depth=1
	cmp	x8, x10
	b.hs	LBB5_58
LBB5_57:                                ; %bb2.i30.i317.i
                                        ;   in Loop: Header=BB5_52 Depth=1
	ldr	x12, [x19, #16]
	str	x23, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB5_58:                                ; %switch.lookup16
                                        ;   in Loop: Header=BB5_52 Depth=1
	mov	w12, w0
	mov	w13, #46673                     ; =0xb651
	movk	w13, #4493, lsl #16
	madd	x11, x11, x13, x12
	add	x11, x26, x11
	add	x9, x9, #4
	stp	x11, x9, [x19, #24]
	cmp	x8, x10
	b.hs	LBB5_60
; %bb.59:                               ; %bb2.i49.i302.i
                                        ;   in Loop: Header=BB5_52 Depth=1
	ldr	x9, [x19, #16]
	str	x12, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB5_60:                                ; %wf_indexed_cost_outcome.exit335.i
                                        ;   in Loop: Header=BB5_52 Depth=1
	add	x8, sp, #32
	add	x1, x8, #136
	mov	x0, x20
	mov	x2, x24
	bl	_wf_record_store_schedule$instance$d656314a40e34216
	ldp	x11, x9, [x19, #24]
	ldp	x8, x10, [x19]
	cmp	x8, x10
	b.lo	LBB5_68
; %bb.61:                               ; %wf_indexed_cost_word.exit.i344.i
                                        ;   in Loop: Header=BB5_52 Depth=1
	cmp	x8, x10
	b.lo	LBB5_69
LBB5_62:                                ; %wf_indexed_cost_word.exit18.i349.i
                                        ;   in Loop: Header=BB5_52 Depth=1
	cmp	x8, x10
	b.hs	LBB5_64
LBB5_63:                                ; %bb2.i30.i378.i
                                        ;   in Loop: Header=BB5_52 Depth=1
	ldr	x12, [x19, #16]
	str	x23, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB5_64:                                ; %switch.lookup18
                                        ;   in Loop: Header=BB5_52 Depth=1
	mov	w12, w0
	mov	w13, #46673                     ; =0xb651
	movk	w13, #4493, lsl #16
	madd	x11, x11, x13, x12
	add	x11, x25, x11
	add	x9, x9, #4
	stp	x11, x9, [x19, #24]
	cmp	x8, x10
	b.hs	LBB5_51
; %bb.65:                               ; %bb2.i49.i363.i
                                        ;   in Loop: Header=BB5_52 Depth=1
	ldr	x9, [x19, #16]
	str	x12, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	b	LBB5_51
LBB5_66:                                ; %bb2.i.i329.i
                                        ;   in Loop: Header=BB5_52 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.hs	LBB5_56
LBB5_67:                                ; %bb2.i12.i323.i
                                        ;   in Loop: Header=BB5_52 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #7                         ; =0x7
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB5_57
	b	LBB5_58
LBB5_68:                                ; %bb2.i.i390.i
                                        ;   in Loop: Header=BB5_52 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.hs	LBB5_62
LBB5_69:                                ; %bb2.i12.i384.i
                                        ;   in Loop: Header=BB5_52 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #4                         ; =0x4
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB5_63
	b	LBB5_64
LBB5_70:                                ; %bb38.lr.ph.i
	mov	x24, #0                         ; =0x0
	ldp	x25, x8, [sp, #8]               ; 16-byte Folded Reload
	add	x8, x8, #2
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	mov	w28, #26214                     ; =0x6666
	movk	w28, #36, lsl #16
	mov	w23, #1                         ; =0x1
	add	x26, sp, #32
	b	LBB5_74
LBB5_71:                                ; %bb50.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	add	x3, x26, #192
	mov	x0, x20
	mov	x1, x19
	mov	x2, x23
	bl	_wf_indexed_cost_delete$instance$2b4e452a2d5f5791
LBB5_72:                                ; %bb47.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	ldp	x9, x8, [sp, #16]               ; 16-byte Folded Reload
	add	x3, x9, x24
	add	x4, x8, x24
	mov	x0, x20
	mov	x1, x19
	mov	x2, x23
	bl	_wf_indexed_cost_insert$instance$2b4e452a2d5f5791
LBB5_73:                                ; %bb53.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	add	x24, x24, #1
	add	x22, x22, #262
	add	x28, x28, #262
	add	x23, x23, #2
	cmp	x21, x24
	b.eq	LBB5_118
LBB5_74:                                ; %bb38.i
                                        ; =>This Inner Loop Header: Depth=1
	tst	x24, #0x7
	b.ne	LBB5_73
; %bb.75:                               ; %bb42.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	add	x0, x26, #160
	mov	x1, x20
	mov	x2, x19
	mov	x3, x23
	bl	_wf_indexed_cost_lookup$instance$174c6fc95f4077f6
	ldr	w8, [sp, #192]
	cbnz	w8, LBB5_73
; %bb.76:                               ; %bb45.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	add	x8, sp, #32
	ldur	q0, [x8, #168]
	stur	q0, [x26, #192]
	ldur	x8, [x8, #184]
	stur	x8, [x26, #208]
	add	x3, x26, #192
	mov	x0, x20
	mov	x1, x19
	mov	x2, x23
	bl	_wf_indexed_cost_delete$instance$2b4e452a2d5f5791
	cbz	x25, LBB5_89
; %bb.77:                               ; %bb48.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	tbnz	w24, #3, LBB5_95
; %bb.78:                               ; %bb51.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	add	x2, x26, #192
	mov	x0, x20
	mov	x1, x23
	bl	_wf_record_store_detach$instance$d656314a40e34216
	ldp	x11, x9, [x19, #24]
	ldp	x8, x10, [x19]
	cmp	x8, x10
	b.lo	LBB5_110
; %bb.79:                               ; %wf_indexed_cost_word.exit.i508.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	cmp	x8, x10
	b.lo	LBB5_111
LBB5_80:                                ; %wf_indexed_cost_word.exit18.i513.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	cmp	x8, x10
	b.hs	LBB5_82
LBB5_81:                                ; %bb2.i30.i542.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	ldr	x12, [x19, #16]
	str	x23, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB5_82:                                ; %switch.lookup22
                                        ;   in Loop: Header=BB5_74 Depth=1
	mov	w12, w0
	mov	w13, #46673                     ; =0xb651
	movk	w13, #4493, lsl #16
	madd	x11, x11, x13, x12
	add	x11, x28, x11
	add	x9, x9, #4
	stp	x11, x9, [x19, #24]
	cmp	x8, x10
	b.hs	LBB5_84
; %bb.83:                               ; %bb2.i49.i527.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	ldr	x9, [x19, #16]
	str	x12, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB5_84:                                ; %wf_indexed_cost_outcome.exit560.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	add	x3, x26, #192
	mov	x0, x20
	mov	x1, x19
	mov	x2, x23
	bl	_wf_indexed_cost_delete$instance$2b4e452a2d5f5791
	add	x1, x26, #192
	mov	x0, x20
	bl	_wf_record_store_cancel$instance$d656314a40e34216
	ldp	x11, x9, [x19, #24]
	ldp	x8, x10, [x19]
	cmp	x8, x10
	b.lo	LBB5_112
; %bb.85:                               ; %wf_indexed_cost_word.exit.i569.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	cmp	x8, x10
	b.lo	LBB5_113
LBB5_86:                                ; %wf_indexed_cost_word.exit18.i574.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	cmp	x8, x10
	b.hs	LBB5_88
LBB5_87:                                ; %bb2.i30.i603.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	ldr	x12, [x19, #16]
	str	x23, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB5_88:                                ; %switch.lookup24
                                        ;   in Loop: Header=BB5_74 Depth=1
	mov	w12, w0
	mov	w13, #46673                     ; =0xb651
	movk	w13, #4493, lsl #16
	madd	x11, x11, x13, x12
	add	x11, x22, x11
	b	LBB5_106
LBB5_89:                                ; %bb49.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	add	x0, x26, #216
	mov	x1, x20
	mov	x2, x19
	mov	x3, x23
	bl	_wf_indexed_cost_lookup$instance$174c6fc95f4077f6
	add	x1, x26, #192
	mov	x0, x20
	bl	_wf_record_store_cancel$instance$d656314a40e34216
	ldp	x11, x9, [x19, #24]
	ldp	x8, x10, [x19]
	cmp	x8, x10
	b.lo	LBB5_108
; %bb.90:                               ; %wf_indexed_cost_word.exit.i447.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	cmp	x8, x10
	b.lo	LBB5_109
LBB5_91:                                ; %wf_indexed_cost_word.exit18.i452.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	cmp	x8, x10
	b.hs	LBB5_93
LBB5_92:                                ; %bb2.i30.i481.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	ldr	x12, [x19, #16]
	str	x23, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB5_93:                                ; %switch.lookup20
                                        ;   in Loop: Header=BB5_74 Depth=1
	mov	w12, w0
	mov	w13, #46673                     ; =0xb651
	movk	w13, #4493, lsl #16
	madd	x11, x11, x13, x12
	add	x11, x22, x11
	add	x9, x9, #4
	stp	x11, x9, [x19, #24]
	cmp	x8, x10
	b.hs	LBB5_72
; %bb.94:                               ; %bb2.i49.i466.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	ldr	x9, [x19, #16]
	str	x12, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	b	LBB5_72
LBB5_95:                                ; %bb52.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	add	x1, x26, #192
	mov	x0, x20
	bl	_wf_record_store_cancel$instance$d656314a40e34216
	ldp	x11, x9, [x19, #24]
	ldp	x8, x10, [x19]
	cmp	x8, x10
	b.lo	LBB5_114
; %bb.96:                               ; %wf_indexed_cost_word.exit.i630.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	cmp	x8, x10
	b.lo	LBB5_115
LBB5_97:                                ; %wf_indexed_cost_word.exit18.i635.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	cmp	x8, x10
	b.hs	LBB5_99
LBB5_98:                                ; %bb2.i30.i664.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	ldr	x12, [x19, #16]
	str	x23, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB5_99:                                ; %switch.lookup26
                                        ;   in Loop: Header=BB5_74 Depth=1
	mov	w12, w0
	mov	w13, #46673                     ; =0xb651
	movk	w13, #4493, lsl #16
	madd	x11, x11, x13, x12
	add	x11, x22, x11
	add	x9, x9, #4
	stp	x11, x9, [x19, #24]
	cmp	x8, x10
	b.hs	LBB5_101
; %bb.100:                              ; %bb2.i49.i649.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	ldr	x9, [x19, #16]
	str	x12, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB5_101:                               ; %wf_indexed_cost_outcome.exit682.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	add	x3, x26, #192
	mov	x0, x20
	mov	x1, x19
	mov	x2, x23
	bl	_wf_indexed_cost_delete$instance$2b4e452a2d5f5791
	add	x2, x26, #192
	mov	x0, x20
	mov	x1, x23
	bl	_wf_record_store_detach$instance$d656314a40e34216
	ldp	x11, x9, [x19, #24]
	ldp	x8, x10, [x19]
	cmp	x8, x10
	b.lo	LBB5_116
; %bb.102:                              ; %wf_indexed_cost_word.exit.i691.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	cmp	x8, x10
	b.lo	LBB5_117
LBB5_103:                               ; %wf_indexed_cost_word.exit18.i696.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	cmp	x8, x10
	b.hs	LBB5_105
LBB5_104:                               ; %bb2.i30.i725.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	ldr	x12, [x19, #16]
	str	x23, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB5_105:                               ; %switch.lookup28
                                        ;   in Loop: Header=BB5_74 Depth=1
	mov	w12, w0
	mov	w13, #46673                     ; =0xb651
	movk	w13, #4493, lsl #16
	madd	x11, x11, x13, x12
	add	x11, x28, x11
LBB5_106:                               ; %switch.lookup24
                                        ;   in Loop: Header=BB5_74 Depth=1
	add	x9, x9, #4
	stp	x11, x9, [x19, #24]
	cmp	x8, x10
	b.hs	LBB5_71
; %bb.107:                              ; %bb50.sink.split.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	ldr	x9, [x19, #16]
	str	x12, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	b	LBB5_71
LBB5_108:                               ; %bb2.i.i493.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.hs	LBB5_91
LBB5_109:                               ; %bb2.i12.i487.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #7                         ; =0x7
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB5_92
	b	LBB5_93
LBB5_110:                               ; %bb2.i.i554.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.hs	LBB5_80
LBB5_111:                               ; %bb2.i12.i548.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #8                         ; =0x8
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB5_81
	b	LBB5_82
LBB5_112:                               ; %bb2.i.i615.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.hs	LBB5_86
LBB5_113:                               ; %bb2.i12.i609.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #7                         ; =0x7
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB5_87
	b	LBB5_88
LBB5_114:                               ; %bb2.i.i676.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.hs	LBB5_97
LBB5_115:                               ; %bb2.i12.i670.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #7                         ; =0x7
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB5_98
	b	LBB5_99
LBB5_116:                               ; %bb2.i.i737.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.hs	LBB5_103
LBB5_117:                               ; %bb2.i12.i731.i
                                        ;   in Loop: Header=BB5_74 Depth=1
	ldr	x12, [x19, #16]
	mov	w13, #8                         ; =0x8
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	cmp	x8, x10
	b.lo	LBB5_104
	b	LBB5_105
LBB5_118:                               ; %bb40.i
	sub	x1, x27, #1
	mov	x0, x20
	mov	x2, x19
	bl	_wf_record_store_expire$instance$083db5949cf60ce0
	mov	w8, #131                        ; =0x83
	mov	x9, #6                          ; =0x6
	ldp	x10, x11, [x19, #24]
	madd	x9, x10, x8, x9
	add	x10, x11, #1
	stp	x9, x10, [x19, #24]
	ldp	x8, x11, [x19]
	cmp	x8, x11
	b.hs	LBB5_120
; %bb.119:                              ; %bb2.i408.i
	ldr	x9, [x19, #16]
	mov	w10, #6                         ; =0x6
	str	x10, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	ldp	x9, x10, [x19, #24]
	ldr	x11, [x19, #8]
LBB5_120:                               ; %wf_indexed_cost_word.exit414.i
	mov	w12, #131                       ; =0x83
	madd	x9, x9, x12, x0
	add	x10, x10, #1
	stp	x9, x10, [x19, #24]
	cmp	x8, x11
	b.hs	LBB5_122
; %bb.121:                              ; %bb2.i426.i
	ldr	x9, [x19, #16]
	str	x0, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB5_122:                               ; %wf_indexed_cost_word.exit432.i
	cbz	x21, LBB5_127
; %bb.123:                              ; %bb55.lr.ph.i
	mov	x25, #0                         ; =0x0
	add	x8, x21, x21, lsl #1
	add	x22, x8, #2
	lsl	x23, x21, #3
	mov	w24, #1                         ; =0x1
	b	LBB5_125
LBB5_124:                               ; %bb61.i
                                        ;   in Loop: Header=BB5_125 Depth=1
	add	x25, x25, #1
	add	x23, x23, #1
	add	x22, x22, #1
	add	x24, x24, #2
	cmp	x21, x25
	b.eq	LBB5_127
LBB5_125:                               ; %bb55.i
                                        ; =>This Inner Loop Header: Depth=1
	and	x8, x25, #0x3
	cmp	x8, #2
	b.ne	LBB5_124
; %bb.126:                              ; %bb59.i
                                        ;   in Loop: Header=BB5_125 Depth=1
	add	x0, x26, #248
	mov	x1, x20
	mov	x2, x19
	mov	x3, x24
	bl	_wf_indexed_cost_lookup$instance$174c6fc95f4077f6
	mov	x0, x20
	mov	x1, x19
	mov	x2, x24
	mov	x3, x22
	mov	x4, x23
	bl	_wf_indexed_cost_insert$instance$2b4e452a2d5f5791
	b	LBB5_124
LBB5_127:                               ; %bb57.i
	add	x8, x21, x21, lsl #3
	sub	x1, x8, #1
	mov	x0, x20
LBB5_128:                               ; %bb57.i
	mov	x2, x19
	bl	_wf_record_store_expire$instance$083db5949cf60ce0
	mov	w8, #131                        ; =0x83
	mov	x9, #6                          ; =0x6
	ldp	x10, x11, [x19, #24]
	madd	x9, x10, x8, x9
	add	x10, x11, #1
	stp	x9, x10, [x19, #24]
	ldp	x8, x11, [x19]
	cmp	x8, x11
	b.hs	LBB5_130
; %bb.129:                              ; %bb2.i755.i
	ldr	x9, [x19, #16]
	mov	w10, #6                         ; =0x6
	str	x10, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	ldp	x9, x10, [x19, #24]
	ldr	x11, [x19, #8]
LBB5_130:                               ; %wf_indexed_cost_word.exit761.i
	mov	w12, #131                       ; =0x83
	madd	x9, x9, x12, x0
	add	x10, x10, #1
	stp	x9, x10, [x19, #24]
	cmp	x8, x11
	b.hs	LBB5_132
; %bb.131:                              ; %bb9.sink.split.i
	ldr	x9, [x19, #16]
	str	x0, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB5_132:                               ; %"wf_indexed_cost_trace$instance$2b4e452a2d5f5791.exit"
	add	x8, sp, #32
	add	x0, x8, #280
	ldp	q0, q1, [x20, #64]
	stp	q0, q1, [x0, #64]
	ldr	q0, [x20, #96]
	str	q0, [x0, #96]
	ldp	q0, q1, [x20]
	stp	q0, q1, [x0]
	ldp	q0, q1, [x20, #32]
	stp	q0, q1, [x0, #32]
	ldr	x8, [x20, #112]
	str	x8, [sp, #424]
	mov	x1, x19
	bl	_wf_record_store_free$instance$083db5949cf60ce0
	ldr	q0, [x19, #16]
	str	q0, [sp, #448]
	ldr	x0, [sp, #456]
	add	sp, sp, #592
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_id_hash
_wf_record_id_hash:                     ; @wf_record_id_hash
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB6_2
; %bb.1:                                ; %bb3
	ldr	x9, [x1]
	udiv	x10, x9, x8
	msub	x0, x10, x8, x9
	ret
LBB6_2:
	mov	x0, #0                          ; =0x0
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_id_equal
_wf_record_id_equal:                    ; @wf_record_id_equal
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x9, [x1]
	cmp	x8, x9
	cset	w0, eq
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_due_compare
_wf_record_due_compare:                 ; @wf_record_due_compare
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x9, [x1]
	cmp	x8, x9
	b.hs	LBB8_2
LBB8_1:
	mov	w0, #-1                         ; =0xffffffff
	ret
LBB8_2:                                 ; %bb3
	b.ls	LBB8_4
; %bb.3:
	mov	w0, #1                          ; =0x1
	ret
LBB8_4:                                 ; %bb6
	ldr	x8, [x0, #8]
	ldr	x9, [x1, #8]
	cmp	x8, x9
	b.lo	LBB8_1
; %bb.5:                                ; %bb9
	b.ls	LBB8_7
; %bb.6:
	mov	w0, #1                          ; =0x1
	ret
LBB8_7:                                 ; %bb12
	ldr	x8, [x0, #16]
	ldr	x9, [x1, #16]
	cmp	x8, x9
	b.lo	LBB8_1
; %bb.8:                                ; %bb15
	b.ls	LBB8_10
; %bb.9:
	mov	w0, #1                          ; =0x1
	ret
LBB8_10:                                ; %bb18
	ldr	x8, [x0, #24]
	ldr	x9, [x1, #24]
	mov	w10, #-1                        ; =0xffffffff
	cmp	x8, x9
	cset	w8, hi
	csel	w0, w10, w8, lo
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_read_handle
_wf_record_read_handle:                 ; @wf_record_read_handle
; %bb.0:                                ; %entry
	ldp	x8, x1, [x0]
	mov	x0, x8
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_read_due
_wf_record_read_due:                    ; @wf_record_read_due
; %bb.0:                                ; %entry
	ldp	q0, q1, [x1]
	stp	q0, q1, [x0]
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_record_store_new$instance$d656314a40e34216
lCPI11_0:
	.quad	17                              ; 0x11
	.quad	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_wf_record_store_new$instance$d656314a40e34216: ; @"wf_record_store_new$instance$d656314a40e34216"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 80
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x20, x4
	mov	x21, x3
	mov	x22, x2
	mov	x23, x1
	mov	x19, x0
	cbz	x2, LBB11_9
; %bb.1:                                ; %window.payload.allocate.v1.i.i.i
	lsl	x8, x22, #6
	sub	x0, x8, x22, lsl #3
	bl	_malloc
	mov	x24, x0
	cbz	x0, LBB11_8
; %bb.2:                                ; %"wf_std.collections.slab.slab_new$instance$50cad5863314d34d.exit"
	cbz	x21, LBB11_10
LBB11_3:                                ; %window.payload.allocate.v1.i.i.i2
	lsl	x0, x21, #5
	bl	_malloc
	cbz	x0, LBB11_8
; %bb.4:                                ; %bb5.i.i.preheader
	mov	x25, x0
	mov	x8, #0                          ; =0x0
	add	x9, x0, #8
LBB11_5:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x9, #8]
	str	xzr, [x9], #32
	cmp	x21, x8
	b.ne	LBB11_5
; %bb.6:                                ; %"wf_std.collections.hash_map.hash_map_new$instance$83298420b4219017.exit"
	cbz	x20, LBB11_11
LBB11_7:                                ; %window.payload.allocate.v1.i.i
	lsl	x0, x20, #5
	bl	_malloc
	cbnz	x0, LBB11_12
LBB11_8:                                ; %window.block.oom.v1.i.i.i
	bl	l_wf_resource_abort
LBB11_9:
Lloh2:
	adrp	x24, l_.wf.empty.slots.payload@PAGE
Lloh3:
	add	x24, x24, l_.wf.empty.slots.payload@PAGEOFF
	cbnz	x21, LBB11_3
LBB11_10:
Lloh4:
	adrp	x25, l_.wf.empty.slots.payload@PAGE
Lloh5:
	add	x25, x25, l_.wf.empty.slots.payload@PAGEOFF
	cbnz	x20, LBB11_7
LBB11_11:
Lloh6:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh7:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB11_12:                               ; %"wf_box_slots_new$instance$57d99a800120d980.exit"
Lloh8:
	adrp	x8, lCPI11_0@PAGE
Lloh9:
	ldr	q0, [x8, lCPI11_0@PAGEOFF]
	str	q0, [x19]
	and	w8, w23, #0x1
	strb	w8, [x19, #8]
	stp	xzr, x22, [x19, #16]
	stp	x24, x22, [x19, #32]
	stp	x21, x21, [x19, #48]
	stp	x25, xzr, [x19, #64]
	stp	xzr, xzr, [x19, #80]
	stp	x20, x0, [x19, #96]
	mov	w8, #8192                       ; =0x2000
	str	x8, [x19, #112]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh2, Lloh3
	.loh AdrpAdd	Lloh4, Lloh5
	.loh AdrpAdd	Lloh6, Lloh7
	.loh AdrpLdr	Lloh8, Lloh9
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_indexed_cost_insert$instance$2b4e452a2d5f5791
_wf_indexed_cost_insert$instance$2b4e452a2d5f5791: ; @"wf_indexed_cost_insert$instance$2b4e452a2d5f5791"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #112
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 112
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x21, x4
	mov	x20, x2
	mov	x19, x1
	mov	x22, x0
	ldp	x11, x9, [x1, #24]
	ldp	x8, x10, [x1]
	cmp	x8, x10
	b.hs	LBB12_2
; %bb.1:                                ; %bb2.i.i
	ldr	x12, [x19, #16]
	mov	w13, #3                         ; =0x3
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB12_2:                                ; %wf_indexed_cost_word.exit.i
	mov	w12, #17161                     ; =0x4309
	madd	x11, x11, x12, x3
	add	x11, x11, #393
	add	x9, x9, #2
	stp	x11, x9, [x19, #24]
	cmp	x8, x10
	b.hs	LBB12_4
; %bb.3:                                ; %bb2.i12.i
	ldr	x9, [x19, #16]
	str	x3, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB12_4:                                ; %wf_indexed_cost_offer.exit
	mov	w23, #19867                     ; =0x4d9b
	movk	w23, #34, lsl #16
	mov	x0, x3
	bl	_wf_indexed_cost_small_make
	str	x0, [sp, #40]
	add	x24, sp, #8
	add	x0, sp, #8
	add	x3, sp, #40
	mov	x1, x22
	mov	x2, x20
	bl	_wf_record_store_insert$instance$d656314a40e34216
	ldr	w8, [sp, #8]
	ldr	x9, [sp, #16]
	cbz	w8, LBB12_18
; %bb.5:                                ; %bb3
	str	x9, [sp]
	ldp	x11, x9, [x19, #24]
	ldp	x8, x10, [x19]
	cmp	x8, x10
	b.hs	LBB12_7
; %bb.6:                                ; %bb2.i.i206
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB12_7:                                ; %wf_indexed_cost_word.exit.i169
	cmp	x8, x10
	b.hs	LBB12_9
; %bb.8:                                ; %bb2.i12.i200
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB12_9:                                ; %wf_indexed_cost_word.exit18.i174
	madd	x11, x11, x23, x20
	mov	w12, #17292                     ; =0x438c
	add	x11, x11, x12
	cmp	x8, x10
	b.hs	LBB12_11
; %bb.10:                               ; %bb2.i30.i194
	ldr	x12, [x19, #16]
	str	x20, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB12_11:                               ; %wf_indexed_cost_word.exit36.i179
	mov	w12, #131                       ; =0x83
	mov	x13, #6                         ; =0x6
	madd	x11, x11, x12, x13
	add	x9, x9, #4
	stp	x11, x9, [x19, #24]
	cmp	x8, x10
	b.hs	LBB12_13
; %bb.12:                               ; %bb2.i49.i188
	ldr	x9, [x19, #16]
	mov	w10, #6                         ; =0x6
	str	x10, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	ldp	x11, x9, [x19, #24]
LBB12_13:                               ; %wf_indexed_cost_outcome.exit212
	ldr	x10, [x19, #8]
	cmp	x8, x10
	b.hs	LBB12_15
; %bb.14:                               ; %bb2.i.i234
	ldr	x12, [x19, #16]
	mov	w13, #4                         ; =0x4
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB12_15:                               ; %wf_indexed_cost_word.exit.i221
	mov	w12, #17161                     ; =0x4309
	madd	x11, x11, x12, x20
	add	x11, x11, #524
	add	x9, x9, #2
	stp	x11, x9, [x19, #24]
	cmp	x8, x10
	b.hs	LBB12_17
; %bb.16:                               ; %bb2.i12.i228
	ldr	x9, [x19, #16]
	str	x20, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB12_17:                               ; %"wf_indexed_cost_accept$instance$2b4e452a2d5f5791.exit"
	mov	x1, sp
	mov	x0, x19
	bl	_wf_indexed_cost_small_consume
	b	LBB12_50
LBB12_18:                               ; %bb2
	ldp	x10, x12, [x19, #24]
	ldp	x8, x13, [x19]
	cmp	x8, x13
	b.hs	LBB12_20
; %bb.19:                               ; %bb2.i.i20
	ldr	x11, [x19, #16]
	mov	w14, #1                         ; =0x1
	str	x14, [x11, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB12_20:                               ; %wf_indexed_cost_word.exit.i9
	cmp	x8, x13
	b.hs	LBB12_22
; %bb.21:                               ; %bb2.i12.i14
	ldr	x11, [x19, #16]
	mov	w14, #1                         ; =0x1
	str	x14, [x11, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB12_22:                               ; %wf_indexed_cost_word.exit18.i
	madd	x10, x10, x23, x20
	mov	w11, #17292                     ; =0x438c
	add	x14, x10, x11
	cmp	x8, x13
	b.hs	LBB12_24
; %bb.23:                               ; %bb2.i30.i
	ldr	x10, [x19, #16]
	str	x20, [x10, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB12_24:                               ; %wf_indexed_cost_word.exit36.i
	ldp	x11, x10, [sp, #24]
	mov	w15, #131                       ; =0x83
	mul	x14, x14, x15
	add	x12, x12, #4
	stp	x14, x12, [x19, #24]
	cmp	x8, x13
	b.hs	LBB12_26
; %bb.25:                               ; %bb2.i49.i
	ldr	x12, [x19, #16]
	str	xzr, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	ldp	x14, x12, [x19, #24]
LBB12_26:                               ; %wf_indexed_cost_outcome.exit
	ldr	x13, [x19, #8]
	cmp	x8, x13
	b.hs	LBB12_28
; %bb.27:                               ; %bb2.i.i45
	ldr	x15, [x19, #16]
	mov	w16, #2                         ; =0x2
	str	x16, [x15, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB12_28:                               ; %wf_indexed_cost_word.exit.i34
	mov	w15, #17161                     ; =0x4309
	madd	x14, x14, x15, x9
	add	x14, x14, #262
	cmp	x8, x13
	b.hs	LBB12_30
; %bb.29:                               ; %bb2.i13.i
	ldr	x15, [x19, #16]
	str	x9, [x15, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB12_30:                               ; %wf_indexed_cost_word.exit19.i
	mov	w9, #131                        ; =0x83
	madd	x9, x14, x9, x11
	cmp	x8, x13
	b.hs	LBB12_32
; %bb.31:                               ; %bb2.i31.i
	ldr	x14, [x19, #16]
	str	x11, [x14, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB12_32:                               ; %wf_indexed_cost_word.exit37.i
	mov	w11, #131                       ; =0x83
	madd	x9, x9, x11, x10
	add	x11, x12, #4
	stp	x9, x11, [x19, #24]
	cmp	x8, x13
	b.hs	LBB12_34
; %bb.33:                               ; %bb2.i49.i39
	ldr	x9, [x19, #16]
	str	x10, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB12_34:                               ; %wf_indexed_cost_handle.exit
	add	x1, x24, #8
	mov	x0, x22
	bl	_wf_record_store_attach$instance$d656314a40e34216
	ldp	x11, x9, [x19, #24]
	ldp	x8, x10, [x19]
	cmp	x8, x10
	b.hs	LBB12_36
; %bb.35:                               ; %bb2.i.i93
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB12_36:                               ; %wf_indexed_cost_word.exit.i59
	cmp	x8, x10
	b.hs	LBB12_38
; %bb.37:                               ; %bb2.i12.i87
	ldr	x12, [x19, #16]
	mov	w13, #2                         ; =0x2
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB12_38:                               ; %wf_indexed_cost_word.exit18.i64
	madd	x11, x11, x23, x20
	mov	w12, #17423                     ; =0x440f
	add	x11, x11, x12
	cmp	x8, x10
	b.hs	LBB12_40
; %bb.39:                               ; %bb2.i30.i81
	ldr	x12, [x19, #16]
	str	x20, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB12_40:                               ; %switch.lookup
	mov	w12, w0
	mov	w13, #131                       ; =0x83
	madd	x11, x11, x13, x12
	add	x9, x9, #4
	stp	x11, x9, [x19, #24]
	cmp	x8, x10
	b.hs	LBB12_42
; %bb.41:                               ; %bb2.i49.i75
	ldr	x9, [x19, #16]
	str	x12, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB12_42:                               ; %wf_indexed_cost_outcome.exit99
	add	x1, x24, #8
	mov	x0, x22
	mov	x2, x21
	bl	_wf_record_store_schedule$instance$d656314a40e34216
	ldp	x11, x9, [x19, #24]
	ldp	x8, x10, [x19]
	cmp	x8, x10
	b.hs	LBB12_44
; %bb.43:                               ; %bb2.i.i154
	ldr	x12, [x19, #16]
	mov	w13, #1                         ; =0x1
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB12_44:                               ; %wf_indexed_cost_word.exit.i108
	cmp	x8, x10
	b.hs	LBB12_46
; %bb.45:                               ; %bb2.i12.i148
	ldr	x12, [x19, #16]
	mov	w13, #4                         ; =0x4
	str	x13, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB12_46:                               ; %wf_indexed_cost_word.exit18.i113
	madd	x11, x11, x23, x20
	mov	w12, #17685                     ; =0x4515
	add	x11, x11, x12
	cmp	x8, x10
	b.hs	LBB12_48
; %bb.47:                               ; %bb2.i30.i142
	ldr	x12, [x19, #16]
	str	x20, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB12_48:                               ; %switch.lookup1
	mov	w12, w0
	mov	w13, #131                       ; =0x83
	madd	x11, x11, x13, x12
	add	x9, x9, #4
	stp	x11, x9, [x19, #24]
	cmp	x8, x10
	b.hs	LBB12_50
; %bb.49:                               ; %bb2.i49.i127
	ldr	x9, [x19, #16]
	str	x12, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB12_50:                               ; %bb1
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_indexed_cost_lookup$instance$174c6fc95f4077f6
_wf_indexed_cost_lookup$instance$174c6fc95f4077f6: ; @"wf_indexed_cost_lookup$instance$174c6fc95f4077f6"
; %bb.0:                                ; %entry
	sub	sp, sp, #80
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	mov	x21, x3
	mov	x20, x2
	mov	x19, x0
	mov	w22, #19867                     ; =0x4d9b
	movk	w22, #34, lsl #16
	mov	x0, sp
	mov	x2, x3
	bl	_wf_record_store_lookup$instance$d656314a40e34216
	ldr	w8, [sp]
	cbz	w8, LBB13_10
; %bb.1:                                ; %bb2
	ldr	w8, [sp, #4]
	ldp	x9, x10, [x20]
	cmp	x9, x10
	b.hs	LBB13_3
; %bb.2:                                ; %bb2.i.i126
	ldr	x11, [x20, #16]
	mov	w12, #1                         ; =0x1
	str	x12, [x11, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x20]
LBB13_3:                                ; %wf_indexed_cost_word.exit.i92
	ldr	x12, [x20, #24]
	cmp	x9, x10
	b.hs	LBB13_5
; %bb.4:                                ; %bb2.i12.i120
	ldr	x11, [x20, #16]
	mov	w13, #3                         ; =0x3
	str	x13, [x11, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x20]
LBB13_5:                                ; %wf_indexed_cost_word.exit18.i97
	ldr	x11, [x20, #32]
	madd	x12, x12, x22, x21
	mov	w13, #17554                     ; =0x4492
	add	x12, x12, x13
	cmp	x9, x10
	b.hs	LBB13_7
; %bb.6:                                ; %bb2.i30.i114
	ldr	x13, [x20, #16]
	str	x21, [x13, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x20]
LBB13_7:                                ; %switch.lookup
	mov	w13, #131                       ; =0x83
	madd	x12, x12, x13, x8
	add	x11, x11, #4
	stp	x12, x11, [x20, #24]
	cmp	x9, x10
	b.hs	LBB13_9
; %bb.8:                                ; %bb2.i49.i108
	ldr	x10, [x20, #16]
	str	x8, [x10, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x20]
LBB13_9:                                ; %wf_indexed_cost_outcome.exit132
	stp	xzr, xzr, [x19, #8]
	str	xzr, [x19, #24]
	mov	w9, #1                          ; =0x1
	stp	w9, w8, [x19]
	b	LBB13_27
LBB13_10:                               ; %bb1
	ldp	x8, x9, [x20]
	cmp	x8, x9
	b.hs	LBB13_12
; %bb.11:                               ; %bb2.i.i
	ldr	x10, [x20, #16]
	mov	w11, #1                         ; =0x1
	str	x11, [x10, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x20]
LBB13_12:                               ; %wf_indexed_cost_word.exit.i
	cmp	x8, x9
	b.hs	LBB13_14
; %bb.13:                               ; %bb2.i12.i
	ldr	x10, [x20, #16]
	mov	w11, #3                         ; =0x3
	str	x11, [x10, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x20]
LBB13_14:                               ; %wf_indexed_cost_word.exit18.i
	ldr	x10, [x20, #24]
	mov	w11, #17554                     ; =0x4492
	cmp	x8, x9
	b.hs	LBB13_16
; %bb.15:                               ; %bb2.i30.i
	ldr	x12, [x20, #16]
	str	x21, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x20]
LBB13_16:                               ; %wf_indexed_cost_word.exit36.i
	madd	x12, x10, x22, x21
	cmp	x8, x9
	b.hs	LBB13_18
; %bb.17:                               ; %bb2.i49.i
	ldr	x10, [x20, #16]
	str	xzr, [x10, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x20]
LBB13_18:                               ; %wf_indexed_cost_outcome.exit
	ldr	x10, [sp, #8]
	add	x12, x12, x11
	cmp	x8, x9
	b.hs	LBB13_20
; %bb.19:                               ; %bb2.i.i78
	ldr	x11, [x20, #16]
	mov	w13, #2                         ; =0x2
	str	x13, [x11, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x20]
LBB13_20:                               ; %wf_indexed_cost_word.exit.i67
	ldr	x11, [sp, #16]
	madd	x12, x12, x22, x10
	add	x14, x12, #262
	cmp	x8, x9
	b.hs	LBB13_22
; %bb.21:                               ; %bb2.i13.i
	ldr	x12, [x20, #16]
	str	x10, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x20]
LBB13_22:                               ; %wf_indexed_cost_word.exit19.i
	ldr	x12, [sp, #24]
	ldr	x13, [x20, #32]
	mov	w15, #131                       ; =0x83
	madd	x14, x14, x15, x11
	cmp	x8, x9
	b.hs	LBB13_24
; %bb.23:                               ; %bb2.i31.i
	ldr	x15, [x20, #16]
	str	x11, [x15, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x20]
LBB13_24:                               ; %wf_indexed_cost_word.exit37.i
	mov	w15, #131                       ; =0x83
	madd	x14, x14, x15, x12
	add	x13, x13, #8
	stp	x14, x13, [x20, #24]
	cmp	x8, x9
	b.hs	LBB13_26
; %bb.25:                               ; %bb2.i49.i72
	ldr	x9, [x20, #16]
	str	x12, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x20]
LBB13_26:                               ; %wf_indexed_cost_handle.exit
	stp	xzr, x10, [x19]
	stp	x11, x12, [x19, #16]
LBB13_27:                               ; %common.ret
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function wf_record_store_visit$instance$97c7d7c95188d5f1.body
lCPI14_0:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_wf_record_store_visit$instance$97c7d7c95188d5f1.body: ; @"wf_record_store_visit$instance$97c7d7c95188d5f1.body"
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	ldr	x9, [x1]
	cmp	x8, x9
	b.ne	LBB14_9
; %bb.1:                                ; %bb3
	ldr	x8, [x2, #8]
	ldr	x9, [x1, #16]
	cmp	x8, x9
	b.hs	LBB14_10
; %bb.2:                                ; %bb2.i.i
	ldr	x9, [x2, #16]
	ldr	x10, [x1, #32]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB14_10
; %bb.3:                                ; %bb5.i.i
	ldr	x9, [x8]
	cbz	x9, LBB14_10
; %bb.4:                                ; %bb8.i.i
	ldp	x12, x10, [x3, #24]
	ldp	x9, x11, [x3]
	cmp	x9, x11
	b.hs	LBB14_6
; %bb.5:                                ; %bb2.i.i.i.i
	ldr	x13, [x3, #16]
	mov	w14, #5                         ; =0x5
	str	x14, [x13, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x3]
LBB14_6:                                ; %wf_indexed_cost_word.exit.i.i.i
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	mov	x19, x0
	ldr	x13, [x8, #8]
	mov	w14, #17161                     ; =0x4309
	madd	x12, x12, x14, x13
	add	x12, x12, #655
	add	x10, x10, #2
	stp	x12, x10, [x3, #24]
	cmp	x9, x11
	b.hs	LBB14_8
; %bb.7:                                ; %bb2.i12.i.i.i
	ldr	x10, [x3, #16]
	str	x13, [x10, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x3]
LBB14_8:                                ; %bb4
	add	x1, x8, #16
	mov	x0, x3
	bl	_wf_indexed_cost_small_observe
	str	wzr, [x19, #8]
	str	xzr, [x19]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB14_9:                                ; %bb2
Lloh10:
	adrp	x8, lCPI14_0@PAGE
Lloh11:
	ldr	d0, [x8, lCPI14_0@PAGEOFF]
	str	d0, [x0]
	mov	w8, #4                          ; =0x4
	str	w8, [x0, #8]
	ret
LBB14_10:                               ; %bb5
Lloh12:
	adrp	x8, lCPI14_0@PAGE
Lloh13:
	ldr	d0, [x8, lCPI14_0@PAGEOFF]
	str	d0, [x0]
	mov	w8, #3                          ; =0x3
	str	w8, [x0, #8]
	ret
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh12, Lloh13
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_store_visit$instance$97c7d7c95188d5f1
_wf_record_store_visit$instance$97c7d7c95188d5f1: ; @"wf_record_store_visit$instance$97c7d7c95188d5f1"
; %bb.0:                                ; %entry
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	mov	x3, x2
	mov	x2, x1
	mov	x1, x0
	add	x0, sp, #4
	bl	_wf_record_store_visit$instance$97c7d7c95188d5f1.body
	ldr	w0, [sp, #4]
	ldr	w2, [sp, #12]
	ldrb	w1, [sp, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_store_replace$instance$d656314a40e34216.body
_wf_record_store_replace$instance$d656314a40e34216.body: ; @"wf_record_store_replace$instance$d656314a40e34216.body"
; %bb.0:                                ; %entry
	sub	sp, sp, #96
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	mov	x20, x1
	mov	x19, x0
	ldr	x21, [x3]
	str	x21, [sp, #8]
	add	x0, sp, #16
	bl	_wf_record_store_lookup$instance$d656314a40e34216
	ldr	w8, [sp, #16]
	cbz	w8, LBB16_2
; %bb.1:                                ; %bb3
	ldr	w8, [sp, #20]
	str	xzr, [x19]
	b	LBB16_7
LBB16_2:                                ; %bb2
	ldr	x8, [sp, #32]
	ldr	x9, [x20, #16]
	cmp	x8, x9
	b.hs	LBB16_6
; %bb.3:                                ; %bb2.i.i
	ldr	x9, [sp, #40]
	ldr	x10, [x20, #32]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB16_6
; %bb.4:                                ; %bb5.i.i
	ldr	x9, [x8]
	cbz	x9, LBB16_6
; %bb.5:                                ; %bb4
	add	x0, sp, #8
	add	x1, x8, #8
	bl	_wf_record_swap_payload$instance$174c6fc95f4077f6
	ldr	x8, [sp, #8]
	stp	xzr, x8, [x19]
	b	LBB16_8
LBB16_6:                                ; %bb5
	str	xzr, [x19]
	mov	w8, #3                          ; =0x3
LBB16_7:                                ; %common.ret
	str	w8, [x19]
	str	x21, [x19, #8]
LBB16_8:                                ; %common.ret
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_store_replace$instance$d656314a40e34216
_wf_record_store_replace$instance$d656314a40e34216: ; @"wf_record_store_replace$instance$d656314a40e34216"
; %bb.0:                                ; %entry
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	mov	x3, x2
	mov	x2, x1
	mov	x1, x0
	mov	x0, sp
	bl	_wf_record_store_replace$instance$d656314a40e34216.body
	ldr	w0, [sp]
	ldr	x1, [sp, #8]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_store_reschedule$instance$d656314a40e34216
_wf_record_store_reschedule$instance$d656314a40e34216: ; @"wf_record_store_reschedule$instance$d656314a40e34216"
; %bb.0:                                ; %entry
	sub	sp, sp, #208
	stp	x24, x23, [sp, #144]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #160]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #176]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	mov	x20, x2
	mov	x19, x0
	bl	_wf_record_store_position$instance$d656314a40e34216
	cbz	w0, LBB18_2
; %bb.1:
	mov	x0, x2
	b	LBB18_3
LBB18_2:                                ; %bb2
	add	x8, sp, #8
	ldr	x9, [x19, #104]
	add	x21, x9, x1, lsl #5
	add	x0, x8, #24
	mov	x22, x1
	mov	x1, x21
	bl	_wf_record_read_due
	ldr	x8, [sp, #40]
	stp	x20, x8, [sp, #80]
	ldur	q0, [sp, #48]
	stur	q0, [sp, #96]
	ldr	x20, [x19, #88]!
	sub	x23, x19, #72
	ldur	q1, [sp, #80]
	stp	q1, q0, [x21]
	mov	x0, x23
	mov	x1, x21
	mov	x2, x22
	bl	_wf_record_report_position$instance$d656314a40e34216
	mov	x0, x19
	mov	x1, x22
	mov	x2, x20
	mov	x3, x23
	bl	_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$8a68ac1679550fca
	mov	w0, #0                          ; =0x0
LBB18_3:                                ; %common.ret
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #176]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #160]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_store_cancel$instance$d656314a40e34216
_wf_record_store_cancel$instance$d656314a40e34216: ; @"wf_record_store_cancel$instance$d656314a40e34216"
; %bb.0:                                ; %entry
	sub	sp, sp, #208
	stp	x24, x23, [sp, #144]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #160]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #176]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	mov	x19, x0
	ldr	q0, [x1]
	str	q0, [sp]
	ldr	x8, [x1, #16]
	str	x8, [sp, #16]
	mov	x24, sp
	mov	x1, sp
	bl	_wf_record_store_position$instance$d656314a40e34216
	mov	x8, x0
	mov	x0, x2
	str	w8, [sp, #24]
	str	x1, [sp, #32]
	str	w2, [sp, #40]
	cbnz	w8, LBB19_8
; %bb.1:                                ; %bb2
	mov	x21, x19
	ldr	x8, [x21, #88]!
	sub	x20, x21, #72
	sub	x22, x8, #1
	ldr	x8, [x21, #16]
	add	x9, x8, x22, lsl #5
	str	x22, [x21]
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp, #112]
	cmp	x1, x22
	b.hs	LBB19_3
; %bb.2:                                ; %bb2.i
	add	x8, x8, x1, lsl #5
	ldp	q0, q1, [x8]
	stp	q0, q1, [sp, #112]
	ldp	q1, q0, [x9]
	stp	q1, q0, [x8]
	mov	x0, x20
	mov	x23, x1
	mov	x1, x8
	mov	x2, x23
	bl	_wf_record_report_position$instance$d656314a40e34216
	mov	x0, x21
	mov	x1, x23
	mov	x2, x22
	mov	x3, x20
	bl	_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$8a68ac1679550fca
LBB19_3:                                ; %"wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$8a68ac1679550fca.exit"
	ldp	q0, q1, [sp, #112]
	stp	q0, q1, [x24, #48]
	mov	w8, #8192                       ; =0x2000
	str	x8, [sp, #104]
	ldur	q0, [sp, #8]
	stur	q0, [x24, #80]
	ldr	x8, [sp, #80]
	ldr	x9, [x20]
	cmp	x8, x9
	b.hs	LBB19_7
; %bb.4:                                ; %bb2.i.i
	ldr	x9, [sp, #88]
	ldr	x10, [x19, #32]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB19_7
; %bb.5:                                ; %bb5.i.i
	ldr	x9, [x8]
	cbz	x9, LBB19_7
; %bb.6:                                ; %bb8.i.i
	add	x0, x24, #104
	add	x1, x8, #8
	bl	_wf_record_set_position$instance$174c6fc95f4077f6
	mov	w0, #0                          ; =0x0
	b	LBB19_8
LBB19_7:
	mov	w0, #3                          ; =0x3
LBB19_8:                                ; %common.ret
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #176]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #160]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_store_schedule$instance$d656314a40e34216
_wf_record_store_schedule$instance$d656314a40e34216: ; @"wf_record_store_schedule$instance$d656314a40e34216"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #368
	stp	x26, x25, [sp, #288]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #304]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #320]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #336]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #352]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 368
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x20, x2
	mov	x19, x0
	mov	x21, sp
	ldr	q0, [x1]
	str	q0, [sp]
	ldr	x8, [x1, #16]
	str	x8, [sp, #16]
	add	x0, x21, #24
	mov	x2, sp
	mov	x1, x19
	bl	_wf_record_store_info$instance$d656314a40e34216
	ldr	w8, [sp, #24]
	cbz	w8, LBB20_2
; %bb.1:                                ; %bb3
	ldr	w0, [sp, #28]
	b	LBB20_21
LBB20_2:                                ; %bb2
	ldr	x8, [sp, #48]
	stur	x8, [x21, #72]
	ldr	q0, [sp, #32]
	stur	q0, [x21, #56]
	ldr	x8, [sp, #72]
	cmp	x8, #2, lsl #12                 ; =8192
	b.ne	LBB20_5
; %bb.3:                                ; %bb6
	ldr	x8, [sp, #56]
	ldur	q0, [sp, #8]
	stur	q0, [x21, #104]
	stp	x20, x8, [sp, #120]
	stur	q0, [sp, #136]
	ldur	q0, [x21, #120]
	ldur	q1, [x21, #136]
	stp	q0, q1, [sp, #224]
	ldr	x20, [x19, #88]
	lsr	x8, x20, #13
	cbz	x8, LBB20_6
; %bb.4:                                ; %bb10
	mov	w0, #6                          ; =0x6
	b	LBB20_21
LBB20_5:                                ; %bb5
	mov	x1, sp
	mov	x0, x19
	bl	_wf_record_store_position$instance$d656314a40e34216
	cmp	w0, #0
	csinc	w0, w2, wzr, ne
	b	LBB20_21
LBB20_6:                                ; %bb3.i
	ldr	x8, [x19, #96]
	cmp	x8, x20
	b.ne	LBB20_11
; %bb.7:                                ; %bb3.i.i
	cbz	x20, LBB20_12
; %bb.8:                                ; %bb6.i.i
	cmp	x20, #1, lsl #12                ; =4096
	b.hi	LBB20_14
; %bb.9:                                ; %bb11.i.i
	ldr	x0, [x19, #104]
	lsl	x1, x20, #6
	bl	_realloc
	cbz	x0, LBB20_22
; %bb.10:                               ; %"wf_grow$instance$57d99a800120d980.exit.i33.i.i"
	mov	x21, x0
	lsl	x8, x20, #1
	b	LBB20_16
LBB20_11:                               ; %"bb3.wf_collections.priority_queue.priority_queue_make_room$instance$8ea10e07481bf32d.exit_crit_edge.i"
	ldr	x21, [x19, #104]
	b	LBB20_17
LBB20_12:                               ; %bb5.i.i
	mov	w0, #32                         ; =0x20
	bl	_malloc
	cbz	x0, LBB20_22
; %bb.13:                               ; %window.grow.copy.ready.v2.i.i.i.i
	mov	x21, x0
	mov	w8, #1                          ; =0x1
	b	LBB20_16
LBB20_14:                               ; %bb7.i.i
	ldr	x0, [x19, #104]
	mov	w1, #262144                     ; =0x40000
	bl	_realloc
	cbz	x0, LBB20_22
; %bb.15:                               ; %"wf_grow$instance$57d99a800120d980.exit.i.i.i"
	mov	x21, x0
	mov	w8, #8192                       ; =0x2000
LBB20_16:                               ; %"wf_collections.priority_queue.priority_queue_make_room$instance$8ea10e07481bf32d.exit.i"
	stp	x8, x21, [x19, #96]
LBB20_17:                               ; %"wf_collections.priority_queue.priority_queue_make_room$instance$8ea10e07481bf32d.exit.i"
	add	x1, x21, x20, lsl #5
	ldp	q0, q1, [sp, #224]
	stp	q0, q1, [x1]
	add	x8, x20, #1
	str	x8, [x19, #88]
	add	x0, x19, #16
	mov	x2, x20
	bl	_wf_record_report_position$instance$d656314a40e34216
	cbz	x20, LBB20_20
LBB20_18:                               ; %bb5.i78.i
                                        ; =>This Inner Loop Header: Depth=1
	sub	x25, x20, #1
	lsr	x22, x25, #1
	add	x24, x21, x22, lsl #5
	add	x23, x21, x20, lsl #5
	mov	x0, x24
	mov	x1, x23
	bl	_wf_record_due_compare
	cmp	w0, #1
	b.lt	LBB20_20
; %bb.19:                               ; %bb8.i.i
                                        ;   in Loop: Header=BB20_18 Depth=1
	ldp	q0, q1, [x24]
	stp	q0, q1, [sp, #256]
	ldp	q0, q1, [x23]
	stp	q0, q1, [x24]
	ldp	q0, q1, [sp, #256]
	stp	q0, q1, [x23]
	add	x0, x19, #16
	mov	x1, x24
	mov	x2, x22
	bl	_wf_record_report_position$instance$d656314a40e34216
	add	x0, x19, #16
	mov	x1, x23
	mov	x2, x20
	bl	_wf_record_report_position$instance$d656314a40e34216
	mov	x20, x22
	cmp	x25, #1
	b.hi	LBB20_18
LBB20_20:                               ; %"wf_collections.priority_queue.priority_queue_push_indexed$instance$8a68ac1679550fca.exit.thread"
	mov	w0, #0                          ; =0x0
LBB20_21:                               ; %common.ret
	ldp	x29, x30, [sp, #352]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #336]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #320]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #304]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #288]            ; 16-byte Folded Reload
	add	sp, sp, #368
	ret
LBB20_22:                               ; %window.block.oom.v2.i.i.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_indexed_cost_delete$instance$2b4e452a2d5f5791
_wf_indexed_cost_delete$instance$2b4e452a2d5f5791: ; @"wf_indexed_cost_delete$instance$2b4e452a2d5f5791"
; %bb.0:                                ; %entry
	sub	sp, sp, #96
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	mov	x20, x2
	mov	x19, x1
	mov	x1, x0
	mov	w21, #19867                     ; =0x4d9b
	movk	w21, #34, lsl #16
	mov	x0, sp
	mov	x2, x3
	bl	_wf_record_store_delete$instance$d656314a40e34216
	ldr	w8, [sp]
	cbz	w8, LBB21_9
; %bb.1:                                ; %bb3
	ldp	x8, x9, [x19]
	cmp	x8, x9
	b.hs	LBB21_3
; %bb.2:                                ; %bb2.i.i43
	ldr	x10, [x19, #16]
	mov	w11, #1                         ; =0x1
	str	x11, [x10, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB21_3:                                ; %wf_indexed_cost_word.exit.i10
	ldr	w10, [sp, #4]
	ldr	x12, [x19, #24]
	cmp	x8, x9
	b.hs	LBB21_5
; %bb.4:                                ; %bb2.i12.i37
	ldr	x11, [x19, #16]
	mov	w13, #9                         ; =0x9
	str	x13, [x11, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB21_5:                                ; %wf_indexed_cost_word.exit18.i15
	ldr	x11, [x19, #32]
	madd	x12, x12, x21, x20
	mov	w13, #18340                     ; =0x47a4
	add	x12, x12, x13
	cmp	x8, x9
	b.hs	LBB21_7
; %bb.6:                                ; %bb2.i30.i31
	ldr	x13, [x19, #16]
	str	x20, [x13, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB21_7:                                ; %switch.lookup
	mov	w13, #131                       ; =0x83
	madd	x12, x12, x13, x10
	add	x11, x11, #4
	stp	x12, x11, [x19, #24]
	cmp	x8, x9
	b.hs	LBB21_22
; %bb.8:                                ; %bb2.i49.i25
	ldr	x9, [x19, #16]
	str	x10, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
	b	LBB21_22
LBB21_9:                                ; %bb2
	ldp	x8, x9, [x19]
	cmp	x8, x9
	b.hs	LBB21_11
; %bb.10:                               ; %bb2.i.i
	ldr	x10, [x19, #16]
	mov	w11, #1                         ; =0x1
	str	x11, [x10, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB21_11:                               ; %wf_indexed_cost_word.exit.i
	cmp	x8, x9
	b.hs	LBB21_13
; %bb.12:                               ; %bb2.i12.i
	ldr	x10, [x19, #16]
	mov	w11, #9                         ; =0x9
	str	x11, [x10, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB21_13:                               ; %wf_indexed_cost_word.exit18.i
	ldr	x11, [x19, #24]
	mov	w10, #18340                     ; =0x47a4
	cmp	x8, x9
	b.hs	LBB21_15
; %bb.14:                               ; %bb2.i30.i
	ldr	x12, [x19, #16]
	str	x20, [x12, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB21_15:                               ; %wf_indexed_cost_word.exit36.i
	madd	x13, x11, x21, x20
	ldr	x14, [sp, #16]
	cmp	x8, x9
	b.hs	LBB21_17
; %bb.16:                               ; %bb2.i49.i
	ldr	x11, [x19, #16]
	str	xzr, [x11, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB21_17:                               ; %wf_indexed_cost_outcome.exit
	ldr	x11, [sp, #8]
	ldr	x12, [x19, #32]
	add	x10, x13, x10
	str	x14, [sp, #40]
	cmp	x8, x9
	b.hs	LBB21_19
; %bb.18:                               ; %bb2.i.i.i
	ldr	x13, [x19, #16]
	mov	w14, #4                         ; =0x4
	str	x14, [x13, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB21_19:                               ; %wf_indexed_cost_word.exit.i.i
	madd	x10, x10, x21, x11
	add	x10, x10, #524
	add	x12, x12, #6
	stp	x10, x12, [x19, #24]
	cmp	x8, x9
	b.hs	LBB21_21
; %bb.20:                               ; %bb2.i12.i.i
	ldr	x9, [x19, #16]
	str	x11, [x9, x8, lsl #3]
	add	x8, x8, #1
	str	x8, [x19]
LBB21_21:                               ; %"wf_indexed_cost_consume$instance$2b4e452a2d5f5791.exit"
	add	x1, sp, #40
	mov	x0, x19
	bl	_wf_indexed_cost_small_consume
LBB21_22:                               ; %bb1
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_store_detach$instance$d656314a40e34216
_wf_record_store_detach$instance$d656314a40e34216: ; @"wf_record_store_detach$instance$d656314a40e34216"
; %bb.0:                                ; %entry
	sub	sp, sp, #400
	stp	x28, x27, [sp, #304]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #320]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #336]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #352]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #368]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #384]            ; 16-byte Folded Spill
	ldr	q0, [x2]
	str	q0, [sp]
	ldp	q0, q1, [x0, #64]
	stur	q0, [sp, #88]
	stur	q1, [sp, #104]
	ldr	q0, [x0, #96]
	stur	q0, [sp, #120]
	ldp	q0, q1, [x0]
	stur	q0, [sp, #24]
	stur	q1, [sp, #40]
	ldp	q0, q1, [x0, #32]
	stur	q0, [sp, #56]
	ldr	x8, [x2, #16]
	str	x8, [sp, #16]
	ldr	x8, [x0, #112]
	str	x1, [sp, #280]
	str	x8, [sp, #136]
	stur	q1, [sp, #72]
	ldr	x8, [sp]
	ldr	x9, [sp, #24]
	cmp	x8, x9
	b.ne	LBB22_11
; %bb.1:                                ; %bb3
	mov	x19, x0
	ldr	x21, [x0, #48]
	cbz	x21, LBB22_20
; %bb.2:                                ; %bb3.i
	mov	x23, x2
	mov	x20, sp
	add	x0, x19, #112
	add	x1, x20, #280
	bl	_wf_record_id_hash
	udiv	x8, x0, x21
	msub	x24, x8, x21, x0
	ldr	x22, [x19, #64]
	mov	x25, x21
	b	LBB22_4
LBB22_3:                                ; %bb8.i
                                        ;   in Loop: Header=BB22_4 Depth=1
	add	x8, x24, #1
	cmp	x8, x21
	csinc	x24, xzr, x24, hs
	subs	x25, x25, #1
	b.eq	LBB22_20
LBB22_4:                                ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x26, x22, x24, lsl #5
	ldr	w8, [x26]
	cmp	w8, #1
	b.eq	LBB22_3
; %bb.5:                                ; %bb5.i
                                        ;   in Loop: Header=BB22_4 Depth=1
	cmp	w8, #2
	b.ne	LBB22_20
; %bb.6:                                ; %bb9.i
                                        ;   in Loop: Header=BB22_4 Depth=1
	add	x0, x26, #8
	add	x1, x20, #280
	bl	_wf_record_id_equal
	tbz	w0, #0, LBB22_3
; %bb.7:                                ; %bb4
	add	x0, x26, #16
	bl	_wf_record_read_handle
	stp	xzr, x0, [sp, #144]
	str	x1, [sp, #160]
	ldur	q0, [sp, #152]
	stur	q0, [x20, #168]
	ldur	q0, [x23, #8]
	stur	q0, [x20, #184]
	ldr	x8, [sp, #168]
	ldr	x9, [sp, #184]
	mov	w0, #5                          ; =0x5
	cmp	x8, x9
	b.ne	LBB22_21
; %bb.8:                                ; %bb4
	ldr	x8, [sp, #176]
	ldr	x9, [sp, #192]
	cmp	x8, x9
	b.ne	LBB22_21
; %bb.9:                                ; %bb7
	ldr	x24, [x19, #72]
	cbz	x24, LBB22_20
; %bb.10:                               ; %bb3.i5
	mov	x8, sp
	orr	x23, x8, #0x8
	add	x0, x19, #112
	add	x1, x20, #280
	bl	_wf_record_id_hash
	udiv	x8, x0, x21
	msub	x25, x8, x21, x0
	mov	x26, x21
	b	LBB22_13
LBB22_11:
	mov	w0, #4                          ; =0x4
	b	LBB22_21
LBB22_12:                               ; %bb8.i.i.i
                                        ;   in Loop: Header=BB22_13 Depth=1
	add	x8, x25, #1
	cmp	x8, x21
	csinc	x25, xzr, x25, hs
	mov	w0, #2                          ; =0x2
	subs	x26, x26, #1
	b.eq	LBB22_21
LBB22_13:                               ; %bb5.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x27, x22, x25, lsl #5
	ldr	w8, [x27]
	cmp	w8, #1
	b.eq	LBB22_12
; %bb.14:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB22_13 Depth=1
	cmp	w8, #2
	b.ne	LBB22_20
; %bb.15:                               ; %bb3.i.i.i.i
                                        ;   in Loop: Header=BB22_13 Depth=1
	add	x0, x27, #8
	add	x1, x20, #280
	bl	_wf_record_id_equal
	tbz	w0, #0, LBB22_12
; %bb.16:                               ; %bb9
	ldr	x8, [x27, #24]
	mov	w9, #1                          ; =0x1
	str	w9, [x27]
	sub	x10, x24, #1
	ldur	q0, [x27, #8]
	stp	xzr, xzr, [x27, #16]
	stur	xzr, [x27, #8]
	ldr	x11, [x19, #80]
	adds	x11, x11, #1
	csinv	x11, x11, xzr, lo
	stp	x10, x11, [x19, #72]
	str	x9, [sp, #200]
	str	q0, [sp, #208]
	str	x8, [sp, #224]
	stur	x8, [x20, #248]
	ldr	q0, [sp, #208]
	stur	q0, [x20, #232]
	strb	wzr, [x20, #288]
	ldr	q0, [x23]
	str	q0, [x20, #256]
	ldr	x8, [sp, #256]
	ldr	x9, [x19, #16]
	cmp	x8, x9
	b.hs	LBB22_22
; %bb.17:                               ; %bb2.i.i
	ldr	x9, [sp, #264]
	ldr	x10, [x19, #32]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB22_22
; %bb.18:                               ; %bb5.i.i
	ldr	x9, [x8]
	cbz	x9, LBB22_22
; %bb.19:                               ; %bb8.i.i
	add	x0, x20, #288
	add	x1, x8, #8
	bl	_wf_record_set_id_member$instance$174c6fc95f4077f6
	mov	w0, #0                          ; =0x0
	b	LBB22_21
LBB22_20:
	mov	w0, #2                          ; =0x2
LBB22_21:                               ; %common.ret
	ldp	x29, x30, [sp, #384]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #368]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #352]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #336]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #320]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #304]            ; 16-byte Folded Reload
	add	sp, sp, #400
	ret
LBB22_22:
	mov	w0, #0                          ; =0x0
	b	LBB22_21
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_store_expire$instance$083db5949cf60ce0
_wf_record_store_expire$instance$083db5949cf60ce0: ; @"wf_record_store_expire$instance$083db5949cf60ce0"
; %bb.0:                                ; %entry
	sub	sp, sp, #464
	stp	x28, x27, [sp, #368]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #384]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #400]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #416]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #432]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #448]            ; 16-byte Folded Spill
	mov	x23, x0
	ldr	x24, [x23, #88]!
	cbz	x24, LBB23_17
; %bb.1:                                ; %bb5.lr.ph
	mov	x20, x2
	mov	x21, x1
	mov	x22, x0
	mov	x19, #0                         ; =0x0
	add	x26, sp, #336
	add	x27, sp, #8
	mov	w28, #8192                      ; =0x2000
	b	LBB23_4
LBB23_2:                                ; %"wf_indexed_cost_consume$instance$2b4e452a2d5f5791.exit"
                                        ;   in Loop: Header=BB23_4 Depth=1
	add	x1, sp, #336
	mov	x0, x20
	bl	_wf_indexed_cost_small_consume
	add	x19, x19, #1
LBB23_3:                                ; %bb9
                                        ;   in Loop: Header=BB23_4 Depth=1
	ldr	x24, [x23]
	cbz	x24, LBB23_18
LBB23_4:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x25, [x22, #104]
	add	x0, sp, #8
	mov	x1, x25
	bl	_wf_record_read_due
	ldr	x8, [sp, #8]
	cmp	x8, x21
	b.hi	LBB23_18
; %bb.5:                                ; %bb8
                                        ;   in Loop: Header=BB23_4 Depth=1
	subs	x24, x24, #1
	add	x8, x25, x24, lsl #5
	str	x24, [x23]
	ldp	q0, q1, [x8]
	stp	q0, q1, [x26]
	b.eq	LBB23_7
; %bb.6:                                ; %bb2.i
                                        ;   in Loop: Header=BB23_4 Depth=1
	ldp	q0, q1, [x25]
	stp	q0, q1, [x26]
	ldp	q1, q0, [x8]
	stp	q1, q0, [x25]
	add	x0, x22, #16
	mov	x1, x25
	mov	x2, #0                          ; =0x0
	bl	_wf_record_report_position$instance$d656314a40e34216
	add	x3, x22, #16
	mov	x0, x23
	mov	x1, #0                          ; =0x0
	mov	x2, x24
	bl	_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$8a68ac1679550fca
LBB23_7:                                ; %"wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$8a68ac1679550fca.exit"
                                        ;   in Loop: Header=BB23_4 Depth=1
	ldp	q0, q1, [x26]
	stp	q0, q1, [x27, #32]
	str	x28, [sp, #328]
	ldur	q0, [x27, #48]
	stur	q0, [x27, #64]
	ldr	x8, [sp, #72]
	ldur	x9, [x22, #16]
	cmp	x8, x9
	b.hs	LBB23_11
; %bb.8:                                ; %bb2.i.i
                                        ;   in Loop: Header=BB23_4 Depth=1
	ldr	x9, [sp, #80]
	ldr	x10, [x22, #32]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB23_11
; %bb.9:                                ; %bb5.i.i
                                        ;   in Loop: Header=BB23_4 Depth=1
	ldr	x9, [x8]
	cbz	x9, LBB23_11
; %bb.10:                               ; %bb8.i.i
                                        ;   in Loop: Header=BB23_4 Depth=1
	add	x0, x27, #320
	add	x1, x8, #8
	bl	_wf_record_set_position$instance$174c6fc95f4077f6
	mov	w8, #0                          ; =0x0
	b	LBB23_12
LBB23_11:                               ;   in Loop: Header=BB23_4 Depth=1
	mov	w8, #1                          ; =0x1
LBB23_12:                               ; %"wf_std.collections.slab.slab_edit$instance$8d4b560d82c479d8.exit"
                                        ;   in Loop: Header=BB23_4 Depth=1
	ldp	q0, q1, [x22, #64]
	stur	q0, [x27, #152]
	stur	q1, [x27, #168]
	ldr	q0, [x22, #96]
	stur	q0, [x27, #184]
	ldp	q0, q1, [x22]
	stur	q0, [x27, #88]
	stur	q1, [x27, #104]
	ldp	q0, q1, [x22, #32]
	stur	q0, [x27, #120]
	str	w8, [sp, #88]
	ldr	x8, [x22, #112]
	stur	x8, [x27, #200]
	stur	q1, [x27, #136]
	ldr	x8, [sp, #96]
	ldr	x1, [sp, #48]
	str	x8, [sp, #232]
	strh	wzr, [sp, #92]
	ldur	q0, [x27, #48]
	stur	q0, [x27, #208]
	ldur	q0, [x27, #48]
	stur	q0, [x27, #232]
	add	x2, x27, #224
	mov	x0, x22
	bl	_wf_record_store_detach$instance$d656314a40e34216
	add	x0, x27, #248
	add	x2, x27, #224
	mov	x1, x22
	bl	_wf_record_store_delete$instance$d656314a40e34216
	ldr	w8, [sp, #256]
	cbnz	w8, LBB23_3
; %bb.13:                               ; %bb10
                                        ;   in Loop: Header=BB23_4 Depth=1
	ldp	q0, q1, [x27, #256]
	stp	q0, q1, [x27, #288]
	ldp	x8, x9, [sp, #296]
	str	x9, [sp, #336]
	ldp	x9, x10, [x20]
	cmp	x9, x10
	b.hs	LBB23_15
; %bb.14:                               ; %bb2.i.i.i
                                        ;   in Loop: Header=BB23_4 Depth=1
	ldr	x11, [x20, #16]
	mov	w12, #4                         ; =0x4
	str	x12, [x11, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x20]
LBB23_15:                               ; %wf_indexed_cost_word.exit.i.i
                                        ;   in Loop: Header=BB23_4 Depth=1
	ldp	x11, x12, [x20, #24]
	mov	w13, #17161                     ; =0x4309
	madd	x11, x11, x13, x8
	add	x11, x11, #524
	add	x12, x12, #2
	stp	x11, x12, [x20, #24]
	cmp	x9, x10
	b.hs	LBB23_2
; %bb.16:                               ; %bb2.i12.i.i
                                        ;   in Loop: Header=BB23_4 Depth=1
	ldr	x10, [x20, #16]
	str	x8, [x10, x9, lsl #3]
	add	x8, x9, #1
	str	x8, [x20]
	b	LBB23_2
LBB23_17:
	mov	x19, #0                         ; =0x0
LBB23_18:                               ; %bb2
	mov	x0, x19
	ldp	x29, x30, [sp, #448]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #432]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #416]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #400]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #384]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #368]            ; 16-byte Folded Reload
	add	sp, sp, #464
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_store_free$instance$083db5949cf60ce0
_wf_record_store_free$instance$083db5949cf60ce0: ; @"wf_record_store_free$instance$083db5949cf60ce0"
; %bb.0:                                ; %entry
	sub	sp, sp, #128
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	mov	x20, x1
	ldp	x23, x22, [x0, #16]
	ldr	x19, [x0, #32]
	ldr	x8, [x0, #56]
	ldp	x24, x21, [x0, #96]
	cbz	x8, LBB24_2
; %bb.1:                                ; %slots.release.drop.6.i.i
	ldr	x0, [x0, #64]
	bl	_free
LBB24_2:                                ; %"wf_std.collections.hash_map.hash_map_free$instance$ae582e16a4511b12.exit"
	cbz	x24, LBB24_4
; %bb.3:                                ; %slots.release.drop.6.i.i2
	mov	x0, x21
	bl	_free
LBB24_4:                                ; %"wf_collections.priority_queue.priority_queue_free$instance$56071cfe5106e0aa.exit"
	cbz	x23, LBB24_13
; %bb.5:                                ; %bb5.lr.ph.i
	mov	w8, #56                         ; =0x38
	madd	x8, x23, x8, x19
	sub	x21, x8, #56
	mov	x24, sp
	mov	w25, #4                         ; =0x4
	mov	w26, #17161                     ; =0x4309
	b	LBB24_8
LBB24_6:                                ; %"wf_indexed_cost_consume$instance$2b4e452a2d5f5791.exit.i"
                                        ;   in Loop: Header=BB24_8 Depth=1
	add	x1, sp, #40
	mov	x0, x20
	bl	_wf_indexed_cost_small_consume
LBB24_7:                                ; %bb6.i
                                        ;   in Loop: Header=BB24_8 Depth=1
	sub	x21, x21, #56
	sub	x23, x23, #1
	cbz	x23, LBB24_13
LBB24_8:                                ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q0, q1, [x21]
	stp	q0, q1, [sp]
	ldr	x8, [x21, #32]
	str	x8, [sp, #32]
	ldr	x8, [sp]
	cbz	x8, LBB24_7
; %bb.9:                                ; %bb7.i
                                        ;   in Loop: Header=BB24_8 Depth=1
	sub	x8, x8, #1
	add	x9, x24, x8, lsl #5
	str	x8, [sp]
	ldp	x8, x9, [x9, #8]
	str	x9, [sp, #40]
	ldp	x9, x10, [x20]
	cmp	x9, x10
	b.hs	LBB24_11
; %bb.10:                               ; %bb2.i.i.i.i
                                        ;   in Loop: Header=BB24_8 Depth=1
	ldr	x11, [x20, #16]
	str	x25, [x11, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x20]
LBB24_11:                               ; %wf_indexed_cost_word.exit.i.i.i
                                        ;   in Loop: Header=BB24_8 Depth=1
	ldp	x11, x12, [x20, #24]
	madd	x11, x11, x26, x8
	add	x11, x11, #524
	add	x12, x12, #2
	stp	x11, x12, [x20, #24]
	cmp	x9, x10
	b.hs	LBB24_6
; %bb.12:                               ; %bb2.i12.i.i.i
                                        ;   in Loop: Header=BB24_8 Depth=1
	ldr	x10, [x20, #16]
	str	x8, [x10, x9, lsl #3]
	add	x8, x9, #1
	str	x8, [x20]
	b	LBB24_6
LBB24_13:                               ; %bb4.i
	cbz	x22, LBB24_15
; %bb.14:                               ; %slots.release.drop.6.i.i8
	mov	x0, x19
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #128
	b	_free
LBB24_15:                               ; %"wf_std.collections.slab.slab_free$instance$c399a9c4dcd4740d.exit"
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_record_store_insert$instance$d656314a40e34216
lCPI25_0:
	.quad	8192                            ; 0x2000
	.quad	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_wf_record_store_insert$instance$d656314a40e34216: ; @"wf_record_store_insert$instance$d656314a40e34216"
; %bb.0:                                ; %entry
	sub	sp, sp, #16
	ldr	x10, [x3]
	strb	wzr, [sp, #8]
	ldr	x8, [x1, #40]
	ldr	x11, [x1, #16]
	cmp	x8, x11
	b.hs	LBB25_3
; %bb.1:                                ; %bb2.i
	ldr	x9, [x1, #32]
	mov	w11, #56                        ; =0x38
	madd	x11, x8, x11, x9
	ldr	x9, [x11]
	cbnz	x9, LBB25_6
; %bb.2:                                ; %bb8.i
	ldp	x9, x12, [x11, #40]
	stp	x2, x10, [x11, #8]
	strb	wzr, [x11, #24]
	mov	w10, #8192                      ; =0x2000
	str	x10, [x11, #32]
	mov	w10, #1                         ; =0x1
	str	x10, [x11]
	str	x12, [x1, #40]
	b	LBB25_5
LBB25_3:                                ; %bb3.i
	ldr	x9, [x1, #24]
	cmp	x11, x9
	b.hs	LBB25_6
; %bb.4:                                ; %bb11.i
	mov	x9, #0                          ; =0x0
	ldr	x12, [x1, #32]
	mov	w13, #56                        ; =0x38
	madd	x12, x11, x13, x12
	mov	w13, #1                         ; =0x1
	stp	x13, x2, [x12]
	str	x10, [x12, #16]
	strb	wzr, [x12, #24]
Lloh14:
	adrp	x10, lCPI25_0@PAGE
Lloh15:
	ldr	q0, [x10, lCPI25_0@PAGEOFF]
	str	q0, [x12, #32]
	str	x8, [x12, #48]
	add	x8, x11, #1
	str	x8, [x1, #16]
	mov	x8, x11
LBB25_5:                                ; %bb1
	ldr	x10, [x1]
	stp	xzr, x10, [x0]
	stp	x8, x9, [x0, #16]
	add	sp, sp, #16
	ret
LBB25_6:                                ; %bb2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	str	x10, [x0, #8]
	add	sp, sp, #16
	ret
	.loh AdrpLdr	Lloh14, Lloh15
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_store_attach$instance$d656314a40e34216
_wf_record_store_attach$instance$d656314a40e34216: ; @"wf_record_store_attach$instance$d656314a40e34216"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #496
	.cfi_def_cfa_offset 592
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x19, x0
	add	x22, sp, #48
	ldr	q0, [x1]
	str	q0, [sp, #48]
	ldr	x8, [x1, #16]
	str	x8, [sp, #64]
	add	x0, x22, #24
	add	x2, sp, #48
	mov	x1, x19
	bl	_wf_record_store_info$instance$d656314a40e34216
	ldr	w8, [sp, #72]
	cbz	w8, LBB26_2
; %bb.1:                                ; %bb3
	ldr	w0, [sp, #76]
	b	LBB26_59
LBB26_2:                                ; %bb2
	ldr	q0, [sp, #80]
	str	q0, [sp, #128]
	ldr	x8, [sp, #96]
	str	x8, [sp, #144]
	ldr	x9, [sp, #128]
	ldrb	w10, [sp, #136]
	str	x9, [sp, #104]
	strb	w10, [sp, #112]
	str	x8, [sp, #120]
	str	x8, [x22, #416]
	ldur	q0, [sp, #104]
	str	q0, [x22, #400]
	ldrb	w8, [x22, #408]
	cmp	w8, #1
	b.ne	LBB26_4
LBB26_3:
	mov	w0, #1                          ; =0x1
	b	LBB26_59
LBB26_4:                                ; %bb6
	ldr	x26, [x19, #48]
	cbz	x26, LBB26_15
; %bb.5:                                ; %bb3.i
	add	x20, x22, #184
	add	x0, x19, #112
	add	x1, x22, #400
	bl	_wf_record_id_hash
	udiv	x8, x0, x26
	msub	x21, x8, x26, x0
	ldr	x23, [x19, #64]
	mov	x24, x26
	b	LBB26_7
LBB26_6:                                ; %bb8.i
                                        ;   in Loop: Header=BB26_7 Depth=1
	add	x8, x21, #1
	cmp	x8, x26
	csinc	x21, xzr, x21, hs
	subs	x24, x24, #1
	b.eq	LBB26_15
LBB26_7:                                ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x25, x23, x21, lsl #5
	ldr	w8, [x25]
	cmp	w8, #1
	b.eq	LBB26_6
; %bb.8:                                ; %bb5.i
                                        ;   in Loop: Header=BB26_7 Depth=1
	cmp	w8, #2
	b.ne	LBB26_15
; %bb.9:                                ; %bb9.i
                                        ;   in Loop: Header=BB26_7 Depth=1
	add	x0, x25, #8
	add	x1, x22, #400
	bl	_wf_record_id_equal
	tbz	w0, #0, LBB26_6
; %bb.10:                               ; %bb8
	add	x0, x25, #16
	bl	_wf_record_read_handle
	stp	xzr, x0, [sp, #152]
	str	x1, [sp, #168]
	ldr	q0, [sp, #160]
	ldur	q1, [sp, #56]
	stp	q0, q1, [x22, #128]
	ldp	x8, x9, [sp, #176]
	ldr	x10, [sp, #192]
	cmp	x8, x10
	b.ne	LBB26_12
; %bb.11:                               ; %bb8
	ldr	x10, [sp, #200]
	cmp	x9, x10
	b.eq	LBB26_3
LBB26_12:                               ; %bb12
	ldr	x10, [x19, #16]
	cmp	x8, x10
	b.hs	LBB26_60
; %bb.13:                               ; %bb2.i.i16
	ldr	x10, [x19, #32]
	mov	w11, #56                        ; =0x38
	madd	x10, x8, x11, x10
	ldr	x11, [x10, #40]
	cmp	x11, x9
	b.ne	LBB26_60
; %bb.14:                               ; %"wf_std.collections.slab.slab_find_index$instance$50cad5863314d34d.exit"
	ldr	x9, [x10]
	cmp	x9, #0
	csel	x8, xzr, x8, eq
	cset	w10, eq
	str	w10, [sp, #208]
	str	x8, [sp, #216]
	strb	wzr, [sp, #224]
	cbnz	x9, LBB26_62
	b	LBB26_61
LBB26_15:                               ; %bb7.sink.split
	stp	xzr, xzr, [x22, #104]
	stur	xzr, [x22, #120]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #152]
LBB26_16:                               ; %bb7
	ldr	x21, [sp, #448]
	ldur	q0, [sp, #56]
	str	q0, [x22, #304]
	ldp	x11, x10, [sp, #352]
	ldp	x27, x20, [x19, #72]
	adds	x8, x27, x20
	csinv	x8, x8, xzr, lo
	lsr	x9, x26, #13
	stp	x10, x21, [sp, #32]             ; 16-byte Folded Spill
	str	x11, [sp, #24]                  ; 8-byte Folded Spill
	cbnz	x9, LBB26_35
; %bb.17:                               ; %bb7
	sub	x9, x26, x26, lsr #2
	cmp	x8, x9
	b.lo	LBB26_35
; %bb.18:                               ; %bb2.i14
	lsr	x8, x9, #1
	cmp	x27, x8
	csinc	x9, x26, xzr, lo
	mov	w10, #8192                      ; =0x2000
	lsl	x11, x26, #1
	cmp	x26, #1, lsl #12                ; =4096
	csel	x10, x11, x10, ls
	cmp	x27, x8
	csel	x8, x9, x10, lo
	cmp	x26, #0
	csel	x28, x9, x8, eq
	cmp	x28, x26
	b.lo	LBB26_35
; %bb.19:                               ; %bb3.i.i7.i
	cbz	x28, LBB26_35
; %bb.20:                               ; %window.payload.allocate.v1.i.i.i.i.i
	str	x27, [sp, #16]                  ; 8-byte Folded Spill
	lsl	x0, x28, #5
	bl	_malloc
	cbz	x0, LBB26_63
; %bb.21:                               ; %bb5.i.i.i.i.preheader
	mov	x20, x0
	mov	x25, #0                         ; =0x0
	add	x8, x0, #8
LBB26_22:                               ; %bb5.i.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x8, #-8]
	add	x25, x25, #1
	stp	xzr, xzr, [x8, #8]
	str	xzr, [x8], #32
	cmp	x28, x25
	b.ne	LBB26_22
; %bb.23:                               ; %"wf_std.collections.hash_map.hash_map_extend$instance$83298420b4219017.exit.i.i.i"
	ldp	x8, x21, [x19, #56]
	str	x8, [sp, #8]                    ; 8-byte Folded Spill
	stp	x28, x28, [x19, #48]
	str	x20, [x19, #64]
	cbnz	x26, LBB26_25
	b	LBB26_31
LBB26_24:                               ; %bb15.i.i.i
                                        ;   in Loop: Header=BB26_25 Depth=1
	cbz	x26, LBB26_31
LBB26_25:                               ; %bb14.i.i.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB26_27 Depth 2
                                        ;       Child Loop BB26_28 Depth 3
	sub	x26, x26, #1
	add	x8, x21, x26, lsl #5
	ldr	w9, [x8]
	cmp	w9, #1
	b.ls	LBB26_24
; %bb.26:                               ; %bb18.i.i.i
                                        ;   in Loop: Header=BB26_25 Depth=1
	ldp	x24, x27, [x8, #8]
	ldr	x23, [x8, #24]
LBB26_27:                               ; %bb1.i9.i.i.i
                                        ;   Parent Loop BB26_25 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB26_28 Depth 3
	str	x24, [sp, #488]
	add	x0, x19, #112
	add	x1, sp, #488
	bl	_wf_record_id_hash
	mov	x8, #0                          ; =0x0
	udiv	x9, x0, x28
	msub	x9, x9, x28, x0
	sub	x10, x28, x9
	neg	x11, x10
LBB26_28:                               ; %bb3.i.i.i.i
                                        ;   Parent Loop BB26_25 Depth=1
                                        ;     Parent Loop BB26_27 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x8, x10
	csel	x12, x9, x11, lo
	add	x12, x12, x8
	lsl	x13, x12, #5
	ldr	w13, [x20, x13]
	cmp	w13, #1
	b.ls	LBB26_30
; %bb.29:                               ; %bb2.i12.i.i.i
                                        ;   in Loop: Header=BB26_28 Depth=3
	add	x8, x8, #1
	cmp	x25, x8
	b.ne	LBB26_28
	b	LBB26_27
LBB26_30:                               ; %"wf_std.collections.hash_map.hash_map_migrate_owner$instance$1870b122c27cb60e.exit.i.i.i"
                                        ;   in Loop: Header=BB26_25 Depth=1
	add	x8, x20, x12, lsl #5
	mov	w9, #2                          ; =0x2
	str	w9, [x8]
	stp	x24, x27, [x8, #8]
	str	x23, [x8, #24]
	cbnz	x26, LBB26_25
LBB26_31:                               ; %bb13.i.i.i
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	cbz	x8, LBB26_33
; %bb.32:                               ; %slots.release.drop.6.i.i.i.i
	mov	x0, x21
	bl	_free
LBB26_33:                               ; %"wf_free_empty$instance$16f094be4fd843b6.exit.i.i.i"
	mov	x20, #0                         ; =0x0
	str	xzr, [x19, #80]
	ldr	x21, [sp, #40]                  ; 8-byte Folded Reload
	ldr	x27, [sp, #16]                  ; 8-byte Folded Reload
	str	x21, [sp, #488]
	cbnz	x28, LBB26_36
LBB26_34:
	mov	x21, #0                         ; =0x0
	b	LBB26_44
LBB26_35:
	mov	x28, x26
	str	x21, [sp, #488]
	cbz	x28, LBB26_34
LBB26_36:                               ; %bb2.i.i
	add	x0, x19, #112
	add	x1, sp, #488
	bl	_wf_record_id_hash
	udiv	x8, x0, x28
	msub	x23, x8, x28, x0
	ldr	x25, [x19, #64]
	mov	x26, x28
	mov	x21, x28
	b	LBB26_39
LBB26_37:                               ; %bb11.i.i
                                        ;   in Loop: Header=BB26_39 Depth=1
	cmp	x21, x28
	csel	x21, x23, x21, eq
LBB26_38:                               ; %bb8.i.i
                                        ;   in Loop: Header=BB26_39 Depth=1
	add	x8, x23, #1
	cmp	x8, x28
	csinc	x23, xzr, x23, hs
	subs	x26, x26, #1
	b.eq	LBB26_44
LBB26_39:                               ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x24, x25, x23, lsl #5
	ldr	w8, [x24]
	cmp	w8, #1
	b.eq	LBB26_37
; %bb.40:                               ; %bb5.i.i
                                        ;   in Loop: Header=BB26_39 Depth=1
	cmp	w8, #2
	b.ne	LBB26_43
; %bb.41:                               ; %bb3.i.i.i
                                        ;   in Loop: Header=BB26_39 Depth=1
	add	x0, x24, #8
	add	x1, sp, #488
	bl	_wf_record_id_equal
	tbz	w0, #0, LBB26_38
; %bb.42:                               ; %"wf_std.collections.hash_map.hash_map_exchange$instance$44a98dc5bf86badc.exit.i.i"
	ldp	x27, x9, [x24, #8]
	ldr	x10, [x24, #24]
	mov	w11, #2                         ; =0x2
	str	w11, [x24]
	ldr	x8, [sp, #40]                   ; 8-byte Folded Reload
	ldr	x11, [sp, #24]                  ; 8-byte Folded Reload
	stp	x8, x11, [x24, #8]
	ldr	x11, [sp, #32]                  ; 8-byte Folded Reload
	str	x11, [x24, #24]
	mov	w11, #1                         ; =0x1
	str	x11, [sp, #368]
	b	LBB26_51
LBB26_43:                               ; %bb10.i.i
	cmp	x21, x28
	csel	x21, x23, x21, eq
LBB26_44:                               ; %bb1.i.i
	lsr	x8, x27, #13
	cbnz	x8, LBB26_48
; %bb.45:                               ; %bb1.i.i
	cmp	x21, x28
	b.hs	LBB26_48
; %bb.46:                               ; %bb27.i.i
	add	x8, x27, #1
	str	x8, [x19, #72]
	ldr	x8, [x19, #64]
	add	x8, x8, x21, lsl #5
	ldr	w12, [x8]
	cmp	w12, #1
	b.ne	LBB26_49
; %bb.47:                               ; %bb29.thread.i.i
	subs	x9, x20, #1
	csel	x9, xzr, x9, lo
	str	x9, [x19, #80]
	mov	w9, #2                          ; =0x2
	str	w9, [x8]
	ldr	x10, [sp, #40]                  ; 8-byte Folded Reload
	ldp	x11, x9, [sp, #24]              ; 16-byte Folded Reload
	stp	x10, x11, [x8, #8]
	str	x9, [x8, #24]
	b	LBB26_53
LBB26_48:                               ; %bb23.i.i
	mov	w8, #1                          ; =0x1
	str	x8, [sp, #368]
	strb	w8, [x22, #324]
	ldp	x10, x27, [sp, #32]             ; 16-byte Folded Reload
	ldr	x9, [sp, #24]                   ; 8-byte Folded Reload
	b	LBB26_51
LBB26_49:                               ; %bb29.i.i
	ldp	x9, x10, [x8, #8]
	ldr	x11, [x8, #24]
	mov	w13, #2                         ; =0x2
	str	w13, [x8]
	ldr	x14, [sp, #40]                  ; 8-byte Folded Reload
	ldp	x15, x13, [sp, #24]             ; 16-byte Folded Reload
	stp	x14, x15, [x8, #8]
	str	x13, [x8, #24]
	cbz	w12, LBB26_53
; %bb.50:                               ; %bb3.i29.i.i
	mov	w8, #1                          ; =0x1
	str	x8, [sp, #368]
	mov	x27, x9
	mov	x9, x10
	mov	x10, x11
LBB26_51:                               ; %bb21
	add	x8, sp, #48
	add	x8, x8, #328
	stp	x27, x9, [sp, #376]
	str	x10, [sp, #392]
	ldrb	w9, [x22, #324]
	ldr	q0, [x8]
	str	q0, [x22, #352]
	str	x10, [x22, #368]
	tbz	w9, #0, LBB26_54
; %bb.52:
	mov	w0, #6                          ; =0x6
	b	LBB26_59
LBB26_53:                               ; %"wf_std.collections.hash_map.hash_map_put$instance$1870b122c27cb60e.exit.thread"
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x22, #320]
LBB26_54:                               ; %bb19
	add	x8, x22, #376
	add	x9, sp, #48
	orr	x9, x9, #0x8
	mov	w10, #1                         ; =0x1
	strb	w10, [x22, #424]
	ldr	q0, [x9]
	str	q0, [x8]
	ldr	x8, [sp, #424]
	ldr	x9, [x19, #16]
	cmp	x8, x9
	b.hs	LBB26_58
; %bb.55:                               ; %bb2.i.i26
	ldr	x9, [sp, #432]
	ldr	x10, [x19, #32]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB26_58
; %bb.56:                               ; %bb5.i.i34
	ldr	x9, [x8]
	cbz	x9, LBB26_58
; %bb.57:                               ; %bb8.i.i36
	add	x0, x22, #424
	add	x1, x8, #8
	bl	_wf_record_set_id_member$instance$174c6fc95f4077f6
	mov	w0, #0                          ; =0x0
	b	LBB26_59
LBB26_58:
	mov	w0, #3                          ; =0x3
LBB26_59:                               ; %common.ret
	add	sp, sp, #496
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB26_60:                               ; %"wf_std.collections.slab.slab_find_index$instance$50cad5863314d34d.exit.thread"
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #208]
	str	xzr, [sp, #216]
	strb	wzr, [sp, #224]
LBB26_61:                               ; %bb15
	ldp	q0, q1, [x19]
	stp	q0, q1, [x20]
	ldp	q0, q1, [x19, #32]
	stp	q0, q1, [x20, #32]
	ldr	x8, [x19, #112]
	str	x8, [x20, #112]
	ldp	q0, q1, [x19, #80]
	stp	q0, q1, [x20, #80]
	ldr	q1, [x19, #64]
	str	q1, [x20, #64]
	ldrb	w8, [sp, #240]
	tbz	w8, #0, LBB26_16
LBB26_62:
	mov	w0, #5                          ; =0x5
	b	LBB26_59
LBB26_63:                               ; %window.block.oom.v1.i.i.i.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function wf_record_store_lookup$instance$d656314a40e34216
lCPI27_0:
	.long	1                               ; 0x1
	.long	5                               ; 0x5
lCPI27_1:
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_wf_record_store_lookup$instance$d656314a40e34216: ; @"wf_record_store_lookup$instance$d656314a40e34216"
; %bb.0:                                ; %entry
	sub	sp, sp, #352
	stp	x28, x27, [sp, #256]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #272]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #288]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #304]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #320]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #336]            ; 16-byte Folded Spill
	mov	x19, x0
	str	x2, [sp, #248]
	ldr	x22, [x1, #48]
	cbz	x22, LBB27_8
; %bb.1:                                ; %bb3.i
	mov	x20, x1
	add	x21, sp, #8
	add	x0, x1, #112
	add	x1, x21, #240
	bl	_wf_record_id_hash
	udiv	x8, x0, x22
	msub	x23, x8, x22, x0
	ldr	x24, [x20, #64]
	mov	x25, x22
	b	LBB27_3
LBB27_2:                                ; %bb8.i
                                        ;   in Loop: Header=BB27_3 Depth=1
	add	x8, x23, #1
	cmp	x8, x22
	csinc	x23, xzr, x23, hs
	subs	x25, x25, #1
	b.eq	LBB27_8
LBB27_3:                                ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x26, x24, x23, lsl #5
	ldr	w8, [x26]
	cmp	w8, #1
	b.eq	LBB27_2
; %bb.4:                                ; %bb5.i
                                        ;   in Loop: Header=BB27_3 Depth=1
	cmp	w8, #2
	b.ne	LBB27_8
; %bb.5:                                ; %bb9.i
                                        ;   in Loop: Header=BB27_3 Depth=1
	add	x0, x26, #8
	add	x1, x21, #240
	bl	_wf_record_id_equal
	tbz	w0, #0, LBB27_2
; %bb.6:                                ; %bb1
	add	x0, x26, #16
	bl	_wf_record_read_handle
	stp	xzr, x0, [sp, #8]
	str	x1, [sp, #24]
	ldur	q2, [sp, #16]
	ldp	q0, q1, [x20, #64]
	stp	q0, q1, [sp, #112]
	ldr	q0, [x20, #96]
	stur	q0, [x21, #136]
	ldp	q0, q3, [x20]
	stp	q2, q0, [sp, #32]
	ldp	q0, q1, [x20, #32]
	stp	q3, q0, [sp, #64]
	add	x8, sp, #8
	ldr	x9, [x20, #112]
	stur	q1, [sp, #96]
	ldr	x10, [sp, #48]
	stp	x9, x10, [sp, #160]
	ldur	q0, [sp, #16]
	stur	q0, [x21, #168]
	add	x0, x8, #184
	add	x2, x21, #160
	mov	x1, x20
	bl	_wf_record_store_info$instance$d656314a40e34216
	ldr	w8, [sp, #192]
	cbz	w8, LBB27_11
; %bb.7:                                ; %bb4
	ldr	w8, [sp, #196]
	stp	xzr, xzr, [x19, #16]
	str	xzr, [x19, #8]
	mov	w9, #1                          ; =0x1
	stp	w9, w8, [x19]
	b	LBB27_10
LBB27_8:                                ; %bb2
	movi.2d	v0, #0000000000000000
	str	xzr, [x19, #24]
	mov.d	v0[1], v0[0]
	stur	q0, [x19, #8]
Lloh16:
	adrp	x8, lCPI27_1@PAGE
Lloh17:
	ldr	d0, [x8, lCPI27_1@PAGEOFF]
LBB27_9:                                ; %common.ret
	str	d0, [x19]
LBB27_10:                               ; %common.ret
	ldp	x29, x30, [sp, #336]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #320]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #304]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #288]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #272]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #256]            ; 16-byte Folded Reload
	add	sp, sp, #352
	ret
LBB27_11:                               ; %bb3
	ldur	q0, [sp, #200]
	stur	q0, [x21, #216]
	ldr	x8, [sp, #216]
	ldr	x9, [sp, #248]
	stur	x8, [x21, #232]
	ldr	x8, [sp, #224]
	cmp	x8, x9
	b.ne	LBB27_13
; %bb.12:                               ; %bb6
	str	xzr, [x19]
	ldur	q0, [x21, #160]
	stur	q0, [x19, #8]
	ldur	x8, [x21, #176]
	stur	x8, [x19, #24]
	b	LBB27_10
LBB27_13:                               ; %bb7
	stp	xzr, xzr, [x19, #8]
	stur	xzr, [x19, #24]
Lloh18:
	adrp	x8, lCPI27_0@PAGE
Lloh19:
	ldr	d0, [x8, lCPI27_0@PAGEOFF]
	b	LBB27_9
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh18, Lloh19
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_store_position$instance$d656314a40e34216.body
_wf_record_store_position$instance$d656314a40e34216.body: ; @"wf_record_store_position$instance$d656314a40e34216.body"
; %bb.0:                                ; %entry
	sub	sp, sp, #192
	stp	x22, x21, [sp, #144]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #160]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	mov	x20, x1
	mov	x19, x0
	mov	x21, sp
	ldr	q0, [x2]
	str	q0, [sp]
	ldr	x8, [x2, #16]
	str	x8, [sp, #16]
	add	x0, x21, #24
	mov	x2, sp
	bl	_wf_record_store_info$instance$d656314a40e34216
	ldr	w8, [sp, #24]
	cbz	w8, LBB28_2
; %bb.1:                                ; %bb3
	ldr	w8, [sp, #28]
	stp	xzr, xzr, [x19, #8]
	str	xzr, [x19]
	mov	w9, #1                          ; =0x1
	str	w9, [x19]
	b	LBB28_10
LBB28_2:                                ; %bb2
	ldr	x8, [sp, #48]
	stur	x8, [x21, #72]
	ldr	q0, [sp, #32]
	stur	q0, [x21, #56]
	ldr	x8, [sp, #72]
	cmp	x8, #2, lsl #12                 ; =8192
	b.ne	LBB28_4
; %bb.3:                                ; %bb5
	stp	xzr, xzr, [x19, #8]
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	mov	w8, #7                          ; =0x7
	b	LBB28_10
LBB28_4:                                ; %bb6
	ldr	x9, [x20, #88]
	cmp	x8, x9
	b.hs	LBB28_9
; %bb.5:                                ; %bb8
	ldr	x9, [x20, #104]
	add	x1, x9, x8, lsl #5
	add	x0, x21, #80
	bl	_wf_record_read_due
	ldr	q0, [sp, #96]
	ldur	q1, [sp, #8]
	stp	q0, q1, [x21, #112]
	ldr	x8, [sp, #112]
	ldr	x9, [sp, #128]
	cmp	x8, x9
	b.ne	LBB28_9
; %bb.6:                                ; %bb8
	ldr	x8, [sp, #120]
	ldr	x9, [sp, #136]
	cmp	x8, x9
	b.ne	LBB28_9
; %bb.7:                                ; %bb11
	ldr	x8, [sp, #88]
	ldr	x9, [sp, #56]
	cmp	x8, x9
	b.ne	LBB28_9
; %bb.8:                                ; %bb14
	ldr	x8, [sp, #72]
	stp	x8, xzr, [x19, #8]
	str	xzr, [x19]
	b	LBB28_11
LBB28_9:                                ; %bb7
	stp	xzr, xzr, [x19, #8]
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	mov	w8, #8                          ; =0x8
LBB28_10:                               ; %common.ret
	str	w8, [x19, #16]
LBB28_11:                               ; %common.ret
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #160]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_store_position$instance$d656314a40e34216
_wf_record_store_position$instance$d656314a40e34216: ; @"wf_record_store_position$instance$d656314a40e34216"
; %bb.0:                                ; %entry
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	mov	x2, x1
	mov	x1, x0
	add	x0, sp, #8
	bl	_wf_record_store_position$instance$d656314a40e34216.body
	ldr	w0, [sp, #8]
	ldr	x1, [sp, #16]
	ldr	w2, [sp, #24]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function wf_record_store_info$instance$d656314a40e34216
lCPI30_0:
	.long	1                               ; 0x1
	.long	4                               ; 0x4
lCPI30_1:
	.long	1                               ; 0x1
	.long	3                               ; 0x3
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_wf_record_store_info$instance$d656314a40e34216: ; @"wf_record_store_info$instance$d656314a40e34216"
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	ldr	x9, [x1]
	cmp	x8, x9
	b.ne	LBB30_5
; %bb.1:                                ; %bb3
	ldr	x8, [x2, #8]
	ldr	x9, [x1, #16]
	cmp	x8, x9
	b.hs	LBB30_6
; %bb.2:                                ; %bb2.i
	ldr	x9, [x2, #16]
	ldr	x10, [x1, #32]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB30_6
; %bb.3:                                ; %bb5.i
	ldr	x9, [x8]
	cbz	x9, LBB30_6
; %bb.4:                                ; %bb4
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	mov	x19, x0
	add	x0, x8, #8
	bl	_wf_record_read_info$instance$174c6fc95f4077f6
	and	w8, w1, #0x1
	strb	w8, [sp, #8]
	str	wzr, [sp]
	stur	wzr, [sp, #3]
	stp	xzr, x0, [x19]
	strb	w8, [x19, #16]
	ldr	w8, [sp]
	stur	w8, [x19, #17]
	mov	w8, wzr
	str	w8, [x19, #20]
	str	x2, [x19, #24]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB30_5:                                ; %bb2
	movi.2d	v0, #0000000000000000
	str	xzr, [x0, #24]
	mov.d	v0[1], v0[0]
	stur	q0, [x0, #8]
Lloh20:
	adrp	x8, lCPI30_0@PAGE
Lloh21:
	ldr	d0, [x8, lCPI30_0@PAGEOFF]
	str	d0, [x0]
	ret
LBB30_6:                                ; %bb5
	movi.2d	v0, #0000000000000000
	str	xzr, [x0, #24]
	mov.d	v0[1], v0[0]
	stur	q0, [x0, #8]
Lloh22:
	adrp	x8, lCPI30_1@PAGE
Lloh23:
	ldr	d0, [x8, lCPI30_1@PAGEOFF]
	str	d0, [x0]
	ret
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpLdr	Lloh22, Lloh23
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function wf_record_store_delete$instance$d656314a40e34216
lCPI31_0:
	.long	1                               ; 0x1
	.long	9                               ; 0x9
lCPI31_1:
	.long	1                               ; 0x1
	.long	3                               ; 0x3
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_wf_record_store_delete$instance$d656314a40e34216: ; @"wf_record_store_delete$instance$d656314a40e34216"
; %bb.0:                                ; %entry
	sub	sp, sp, #128
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	mov	x20, x1
	mov	x19, x0
	ldr	q0, [x2]
	str	q0, [sp, #32]
	ldr	x8, [x2, #16]
	str	x8, [sp, #48]
	mov	x0, sp
	add	x2, sp, #32
	bl	_wf_record_store_info$instance$d656314a40e34216
	ldr	w8, [sp]
	cbz	w8, LBB31_2
; %bb.1:                                ; %bb3
	ldr	w8, [sp, #4]
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #8]
	stur	q0, [x19, #24]
	mov	w9, #1                          ; =0x1
	stp	w9, w8, [x19]
	b	LBB31_14
LBB31_2:                                ; %bb2
	ldrb	w8, [x20, #8]
	tbz	w8, #0, LBB31_5
; %bb.3:                                ; %bb5
	ldrb	w8, [sp, #16]
	tbnz	w8, #0, LBB31_12
; %bb.4:                                ; %bb9
	ldr	x8, [sp, #24]
	cmp	x8, #2, lsl #12                 ; =8192
	b.ne	LBB31_12
LBB31_5:                                ; %bb4
	ldr	x8, [sp, #40]
	ldr	x9, [x20, #16]
	cmp	x8, x9
	b.hs	LBB31_11
; %bb.6:                                ; %bb2.i
	ldr	x10, [sp, #48]
	ldr	x9, [x20, #32]
	mov	w11, #56                        ; =0x38
	madd	x11, x8, x11, x9
	ldr	x12, [x11, #40]
	cmp	x12, x10
	b.ne	LBB31_11
; %bb.7:                                ; %bb5.i
	ldr	x12, [x11]
	cbz	x12, LBB31_11
; %bb.8:                                ; %bb8.i
	sub	x12, x12, #1
	add	x13, x11, x12, lsl #5
	str	x12, [x11]
	ldur	q0, [x13, #8]
	ldur	q1, [x13, #24]
	stp	q0, q1, [sp, #64]
	cmn	x10, #1
	b.eq	LBB31_10
; %bb.9:                                ; %bb11.i
	add	x10, x10, #1
	mov	w11, #56                        ; =0x38
	ldr	x12, [x20, #40]
	madd	x9, x8, x11, x9
	stp	x10, x12, [x9, #40]
	str	x8, [x20, #40]
LBB31_10:                               ; %bb13
	str	xzr, [x19]
	ldp	q0, q1, [sp, #64]
	stur	q0, [x19, #8]
	stur	q1, [x19, #24]
	b	LBB31_14
LBB31_11:                               ; %bb14
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #24]
	stur	q0, [x19, #8]
Lloh24:
	adrp	x8, lCPI31_1@PAGE
Lloh25:
	ldr	d0, [x8, lCPI31_1@PAGEOFF]
	b	LBB31_13
LBB31_12:                               ; %bb8
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #24]
	stur	q0, [x19, #8]
Lloh26:
	adrp	x8, lCPI31_0@PAGE
Lloh27:
	ldr	d0, [x8, lCPI31_0@PAGEOFF]
LBB31_13:                               ; %common.ret
	str	d0, [x19]
LBB31_14:                               ; %common.ret
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpLdr	Lloh26, Lloh27
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_swap_payload$instance$174c6fc95f4077f6
_wf_record_swap_payload$instance$174c6fc95f4077f6: ; @"wf_record_swap_payload$instance$174c6fc95f4077f6"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x9, [x1, #8]
	str	x9, [x0]
	str	x8, [x1, #8]
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_report_position$instance$d656314a40e34216
_wf_record_report_position$instance$d656314a40e34216: ; @"wf_record_report_position$instance$d656314a40e34216"
; %bb.0:                                ; %entry
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	str	x2, [sp, #8]
	ldr	x8, [x1, #16]
	ldr	x9, [x0]
	cmp	x8, x9
	b.hs	LBB33_4
; %bb.1:                                ; %bb2.i.i
	ldr	x9, [x1, #24]
	ldr	x10, [x0, #16]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB33_4
; %bb.2:                                ; %bb5.i.i
	ldr	x9, [x8]
	cbz	x9, LBB33_4
; %bb.3:                                ; %bb8.i.i
	add	x0, sp, #8
	add	x1, x8, #8
	bl	_wf_record_set_position$instance$174c6fc95f4077f6
LBB33_4:                                ; %"wf_std.collections.slab.slab_edit$instance$8d4b560d82c479d8.exit"
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$8a68ac1679550fca
_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$8a68ac1679550fca: ; @"wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$8a68ac1679550fca"
; %bb.0:                                ; %entry
	sub	sp, sp, #176
	stp	x26, x25, [sp, #96]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #112]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	mov	x19, x3
	mov	x25, x2
	mov	x20, x1
	mov	x24, x0
	cbz	x1, LBB34_5
; %bb.1:                                ; %bb2
	sub	x8, x20, #1
	lsr	x21, x8, #1
	ldr	x26, [x24, #16]
	add	x23, x26, x21, lsl #5
	add	x22, x26, x20, lsl #5
	mov	x0, x23
	mov	x1, x22
	bl	_wf_record_due_compare
	cmp	w0, #1
	b.lt	LBB34_5
; %bb.2:                                ; %bb5
	ldp	q1, q0, [x23]
	ldp	q3, q2, [x22]
	stp	q3, q2, [x23]
	stp	q1, q0, [x22]
	mov	x0, x19
	mov	x1, x23
	mov	x2, x21
	bl	_wf_record_report_position$instance$d656314a40e34216
	mov	x0, x19
	mov	x1, x22
	mov	x2, x20
	bl	_wf_record_report_position$instance$d656314a40e34216
	cmp	x20, #3
	b.lo	LBB34_11
LBB34_3:                                ; %bb5.i6
                                        ; =>This Inner Loop Header: Depth=1
	sub	x24, x21, #1
	lsr	x20, x24, #1
	add	x23, x26, x20, lsl #5
	add	x22, x26, x21, lsl #5
	mov	x0, x23
	mov	x1, x22
	bl	_wf_record_due_compare
	cmp	w0, #1
	b.lt	LBB34_11
; %bb.4:                                ; %bb8.i9
                                        ;   in Loop: Header=BB34_3 Depth=1
	ldp	q1, q0, [x23]
	ldp	q3, q2, [x22]
	stp	q3, q2, [x23]
	stp	q1, q0, [x22]
	mov	x0, x19
	mov	x1, x23
	mov	x2, x20
	bl	_wf_record_report_position$instance$d656314a40e34216
	mov	x0, x19
	mov	x1, x22
	mov	x2, x21
	bl	_wf_record_report_position$instance$d656314a40e34216
	mov	x21, x20
	cmp	x24, #2
	b.hs	LBB34_3
	b	LBB34_11
LBB34_5:                                ; %bb1
	lsr	x25, x25, #1
	cmp	x20, x25
	b.hs	LBB34_11
; %bb.6:                                ; %bb5.lr.ph.i
	ldr	x26, [x24]
	ldr	x24, [x24, #16]
LBB34_7:                                ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x8, x20, #1
	mov	w21, #1                         ; =0x1
	bfi	x21, x20, #1, #63
	add	x22, x8, #2
	cmp	x22, x26
	b.hs	LBB34_9
; %bb.8:                                ; %bb2.i.i
                                        ;   in Loop: Header=BB34_7 Depth=1
	add	x0, x24, x22, lsl #5
	add	x1, x24, x21, lsl #5
	bl	_wf_record_due_compare
	cmp	w0, #0
	csel	x21, x22, x21, lt
LBB34_9:                                ; %"wf_collections.priority_queue.priority_queue_child$instance$b5f40c82891b87e4.exit.i"
                                        ;   in Loop: Header=BB34_7 Depth=1
	add	x23, x24, x20, lsl #5
	add	x22, x24, x21, lsl #5
	mov	x0, x23
	mov	x1, x22
	bl	_wf_record_due_compare
	cmp	w0, #1
	b.lt	LBB34_11
; %bb.10:                               ; %bb8.i
                                        ;   in Loop: Header=BB34_7 Depth=1
	ldp	q1, q0, [x23]
	ldp	q3, q2, [x22]
	stp	q3, q2, [x23]
	stp	q1, q0, [x22]
	mov	x0, x19
	mov	x1, x23
	mov	x2, x20
	bl	_wf_record_report_position$instance$d656314a40e34216
	mov	x0, x19
	mov	x1, x22
	mov	x2, x21
	bl	_wf_record_report_position$instance$d656314a40e34216
	mov	x20, x21
	cmp	x21, x25
	b.lo	LBB34_7
LBB34_11:                               ; %common.ret
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #144]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_set_position$instance$174c6fc95f4077f6
_wf_record_set_position$instance$174c6fc95f4077f6: ; @"wf_record_set_position$instance$174c6fc95f4077f6"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	str	x8, [x1, #24]
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_set_id_member$instance$174c6fc95f4077f6
_wf_record_set_id_member$instance$174c6fc95f4077f6: ; @"wf_record_set_id_member$instance$174c6fc95f4077f6"
; %bb.0:                                ; %entry
	ldrb	w8, [x0]
	strb	w8, [x1, #16]
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_read_info$instance$174c6fc95f4077f6.body
_wf_record_read_info$instance$174c6fc95f4077f6.body: ; @"wf_record_read_info$instance$174c6fc95f4077f6.body"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldrb	w9, [x1, #16]
	ldr	x10, [x1, #24]
	stp	x8, xzr, [x0]
	and	w8, w9, #0x1
	strb	w8, [x0, #8]
	str	x10, [x0, #16]
	ret
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_record_read_info$instance$174c6fc95f4077f6
_wf_record_read_info$instance$174c6fc95f4077f6: ; @"wf_record_read_info$instance$174c6fc95f4077f6"
; %bb.0:                                ; %entry
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	mov	x1, x0
	add	x0, sp, #8
	bl	_wf_record_read_info$instance$174c6fc95f4077f6.body
	ldr	x0, [sp, #8]
	ldrb	w1, [sp, #16]
	ldr	x2, [sp, #24]
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
                                        ; -- End function
	.globl	_wf__floor_run                  ; -- Begin function wf__floor_run
	.weak_definition	_wf__floor_run
	.p2align	2
_wf__floor_run:                         ; @wf__floor_run
	.cfi_startproc
; %bb.0:                                ; %entry
	b	_wf__main_body
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf__main_body
lCPI40_0:
	.quad	101                             ; 0x65
	.quad	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf__main_body
	.p2align	2
_wf__main_body:                         ; @wf__main_body
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #96
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 96
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	stp	xzr, xzr, [sp, #40]
Lloh28:
	adrp	x8, l_.wf.empty.slots.payload@PAGE
Lloh29:
	add	x8, x8, l_.wf.empty.slots.payload@PAGEOFF
	str	x8, [sp, #56]
Lloh30:
	adrp	x8, lCPI40_0@PAGE
Lloh31:
	ldr	q0, [x8, lCPI40_0@PAGEOFF]
	stur	q0, [sp, #64]
	add	x4, sp, #40
	mov	w0, #16                         ; =0x10
	mov	w1, #101                        ; =0x65
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	bl	_wf_indexed_cost_small_trace
	mov	x0, sp
	mov	w1, #0                          ; =0x0
	bl	_wf_std.process.exit_status
	ldr	x8, [sp, #48]
	cbz	x8, LBB40_2
; %bb.1:                                ; %slots.release.drop.8.i
	ldr	x0, [sp, #56]
	bl	_free
LBB40_2:                                ; %wf_main.exit
	mov	x0, sp
	bl	_wf__ordinary_exit_code
	and	w0, w0, #0xff
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdd	Lloh28, Lloh29
	.cfi_endproc
                                        ; -- End function
.zerofill __DATA,__bss,l_.wf.empty.slots.payload,8,3 ; @.wf.empty.slots.payload
	.section	__TEXT,__const
l_.wf_resource.heap:                    ; @.wf_resource.heap
	.ascii	"{\"resource\":\"heap\"}\n"

.subsections_via_symbols
