	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function wf_resource_record_abort
l_wf_resource_record_abort:             ; @wf_resource_record_abort
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
Lloh0:
	adrp	x19, l_.wf_resource.heap@PAGE
Lloh1:
	add	x19, x19, l_.wf_resource.heap@PAGEOFF
	mov	w20, #20                        ; =0x14
	b	LBB0_2
LBB0_1:                                 ; %error.i
                                        ;   in Loop: Header=BB0_2 Depth=1
	bl	___error
	ldr	w8, [x0]
	cmp	w8, #4
	b.ne	LBB0_6
LBB0_2:                                 ; %write.i
                                        ; =>This Inner Loop Header: Depth=1
	mov	w0, #2                          ; =0x2
	mov	x1, x19
	mov	x2, x20
	bl	_write
	tbnz	x0, #63, LBB0_1
; %bb.3:                                ; %wf_resource_write.exit
                                        ;   in Loop: Header=BB0_2 Depth=1
	subs	x20, x20, x0
	b.eq	LBB0_6
; %bb.4:                                ; %wf_resource_write.exit
                                        ;   in Loop: Header=BB0_2 Depth=1
	cbz	x0, LBB0_6
; %bb.5:                                ; %write.more
                                        ;   in Loop: Header=BB0_2 Depth=1
	add	x19, x19, x0
	b	LBB0_2
LBB0_6:                                 ; %abort
	bl	_abort
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc
                                        ; -- End function
	.p2align	2                               ; -- Begin function wf_resource_abort
l_wf_resource_abort:                    ; @wf_resource_abort
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	l_wf_resource_record_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_indexed_child               ; -- Begin function wf_indexed_child
	.p2align	2
_wf_indexed_child:                      ; @wf_indexed_child
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w0, #16                         ; =0x10
	bl	_malloc
	cbz	x0, LBB2_2
; %bb.1:                                ; %"wf_box_new$instance$18ded78b3e1c4ff3.exit"
	add	x8, x19, #101
	stp	x19, x8, [x0]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB2_2:                                 ; %box.new.oom.v1.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_indexed_child_read          ; -- Begin function wf_indexed_child_read
	.p2align	2
_wf_indexed_child_read:                 ; @wf_indexed_child_read
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldp	x9, x8, [x8]
	add	x10, x9, #101
	cmp	x8, x10
	csinv	x0, x9, xzr, eq
	ret
                                        ; -- End function
	.globl	_wf_indexed_child_consume       ; -- Begin function wf_indexed_child_consume
	.p2align	2
_wf_indexed_child_consume:              ; @wf_indexed_child_consume
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	bl	_free
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_indexed_wide
lCPI5_0:
	.quad	11                              ; 0xb
	.quad	22                              ; 0x16
lCPI5_1:
	.quad	33                              ; 0x21
	.quad	44                              ; 0x2c
lCPI5_2:
	.quad	55                              ; 0x37
	.quad	66                              ; 0x42
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_indexed_wide
	.p2align	2
_wf_indexed_wide:                       ; @wf_indexed_wide
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x1
	mov	x19, x0
	mov	w0, #16                         ; =0x10
	bl	_malloc
	cbz	x0, LBB5_2
; %bb.1:                                ; %wf_indexed_child.exit
	add	x8, x20, #101
	stp	x20, x8, [x0]
	dup.2d	v0, x20
Lloh2:
	adrp	x8, lCPI5_0@PAGE
Lloh3:
	ldr	q1, [x8, lCPI5_0@PAGEOFF]
	add.2d	v1, v0, v1
Lloh4:
	adrp	x8, lCPI5_1@PAGE
Lloh5:
	ldr	q2, [x8, lCPI5_1@PAGEOFF]
	add.2d	v2, v0, v2
Lloh6:
	adrp	x8, lCPI5_2@PAGE
Lloh7:
	ldr	q3, [x8, lCPI5_2@PAGEOFF]
	add.2d	v0, v0, v3
	add	x8, x20, #77
	str	x0, [x19]
	stur	q1, [x19, #8]
	stur	q2, [x19, #24]
	stur	q0, [x19, #40]
	str	x8, [x19, #56]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB5_2:                                 ; %box.new.oom.v1.i.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_indexed_wide_read
lCPI6_0:
	.quad	22                              ; 0x16
	.quad	33                              ; 0x21
lCPI6_1:
	.quad	44                              ; 0x2c
	.quad	55                              ; 0x37
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_indexed_wide_read
	.p2align	2
_wf_indexed_wide_read:                  ; @wf_indexed_wide_read
; %bb.0:                                ; %entry
	ldp	x8, x10, [x0]
	ldp	x9, x8, [x8]
	add	x11, x9, #101
	cmp	x8, x11
	csinv	x9, x9, xzr, eq
	add	x8, x9, #11
	cmp	x10, x8
	b.ne	LBB6_4
; %bb.1:                                ; %bb3
	dup.2d	v0, x9
Lloh8:
	adrp	x8, lCPI6_0@PAGE
Lloh9:
	ldr	q1, [x8, lCPI6_0@PAGEOFF]
	add.2d	v1, v0, v1
Lloh10:
	adrp	x8, lCPI6_1@PAGE
Lloh11:
	ldr	q2, [x8, lCPI6_1@PAGEOFF]
	add.2d	v0, v0, v2
	ldp	q2, q3, [x0, #16]
	cmeq.2d	v0, v3, v0
	cmeq.2d	v1, v2, v1
	uzp1.4s	v0, v1, v0
	xtn.4h	v0, v0
	uminv.4h	h0, v0
	fmov	w10, s0
	mov	x8, #-1                         ; =0xffffffffffffffff
	tbz	w10, #0, LBB6_5
; %bb.2:                                ; %bb3
	add	x10, x9, #66
	ldr	x11, [x0, #48]
	cmp	x11, x10
	b.ne	LBB6_5
; %bb.3:                                ; %bb18
	add	x8, x9, #77
	ldr	x10, [x0, #56]
	cmp	x10, x8
	csinv	x0, x9, xzr, eq
	ret
LBB6_4:
	mov	x8, #-1                         ; =0xffffffffffffffff
LBB6_5:                                 ; %common.ret
	mov	x0, x8
	ret
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
                                        ; -- End function
	.globl	_wf_indexed_wide_consume        ; -- Begin function wf_indexed_wide_consume
	.p2align	2
_wf_indexed_wide_consume:               ; @wf_indexed_wide_consume
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0]
	bl	_free
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_indexed_ledger              ; -- Begin function wf_indexed_ledger
	.p2align	2
_wf_indexed_ledger:                     ; @wf_indexed_ledger
; %bb.0:                                ; %entry
	mov	w1, #1312                       ; =0x520
	b	_bzero
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_indexed_oracle
lCPI9_0:
	.quad	-1                              ; 0xffffffffffffffff
	.quad	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_indexed_oracle
	.p2align	2
_wf_indexed_oracle:                     ; @wf_indexed_oracle
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	mov	x19, x0
	strb	wzr, [sp, #24]
	strb	wzr, [sp, #16]
	strb	wzr, [sp, #15]
	and	w20, wzr, #0xff
	add	x0, x0, #24
	mov	w1, #2024                       ; =0x7e8
	bl	_bzero
	str	x20, [x19]
	movi.2d	v0, #0000000000000000
	stur	q0, [x19, #8]
	strh	wzr, [x19, #24]
	str	q0, [x19, #32]
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [x19, #48]
	strb	w20, [x19, #64]
	stur	q0, [x19, #72]
	strh	wzr, [x19, #88]
	str	q0, [x19, #96]
	str	x8, [x19, #112]
	strb	w20, [x19, #128]
	stur	q0, [x19, #136]
	strh	wzr, [x19, #152]
	str	q0, [x19, #160]
	str	x8, [x19, #176]
	strb	w20, [x19, #192]
	stur	q0, [x19, #200]
	strh	wzr, [x19, #216]
	str	q0, [x19, #224]
	str	x8, [x19, #240]
	strb	w20, [x19, #256]
	add	x9, x19, #264
	str	q0, [x9]
	strh	wzr, [x19, #280]
	str	q0, [x19, #288]
	str	x8, [x19, #304]
	strb	w20, [x19, #320]
	add	x9, x19, #328
	str	q0, [x9]
	strh	wzr, [x19, #344]
	str	q0, [x19, #352]
	str	x8, [x19, #368]
	strb	w20, [x19, #384]
	add	x9, x19, #392
	str	q0, [x9]
	strh	wzr, [x19, #408]
	str	q0, [x19, #416]
	str	x8, [x19, #432]
	strb	w20, [x19, #448]
	add	x9, x19, #456
	str	q0, [x9]
	strh	wzr, [x19, #472]
	str	q0, [x19, #480]
	str	x8, [x19, #496]
	strb	w20, [x19, #512]
	add	x9, x19, #520
	str	q0, [x9]
	strh	wzr, [x19, #536]
	str	q0, [x19, #544]
	str	x8, [x19, #560]
	strb	w20, [x19, #576]
	add	x9, x19, #584
	str	q0, [x9]
	strh	wzr, [x19, #600]
	str	q0, [x19, #608]
	str	x8, [x19, #624]
	strb	w20, [x19, #640]
	add	x9, x19, #648
	str	q0, [x9]
	strh	wzr, [x19, #664]
	str	q0, [x19, #672]
	str	x8, [x19, #688]
	strb	w20, [x19, #704]
	add	x9, x19, #712
	str	q0, [x9]
	strh	wzr, [x19, #728]
	str	q0, [x19, #736]
	str	x8, [x19, #752]
	strb	w20, [x19, #768]
	add	x8, x19, #776
	str	q0, [x8]
	strh	wzr, [x19, #792]
Lloh12:
	adrp	x8, lCPI9_0@PAGE
Lloh13:
	ldr	q1, [x8, lCPI9_0@PAGEOFF]
	stp	q0, q1, [x19, #800]
	strb	w20, [x19, #832]
	add	x8, x19, #840
	str	q0, [x8]
	strh	wzr, [x19, #856]
	stp	q0, q1, [x19, #864]
	strb	w20, [x19, #896]
	add	x8, x19, #904
	str	q0, [x8]
	strh	wzr, [x19, #920]
	stp	q0, q1, [x19, #928]
	strb	w20, [x19, #960]
	add	x8, x19, #968
	str	q0, [x8]
	strh	wzr, [x19, #984]
	stp	q0, q1, [x19, #992]
	strb	w20, [x19, #1024]
	add	x8, x19, #1032
	str	q0, [x8]
	strh	wzr, [x19, #1048]
	str	q0, [x19, #1056]
	str	q1, [x19, #1072]
	strb	w20, [x19, #1088]
	add	x8, x19, #1096
	str	q0, [x8]
	strh	wzr, [x19, #1112]
	str	q0, [x19, #1120]
	str	q1, [x19, #1136]
	strb	w20, [x19, #1152]
	add	x8, x19, #1160
	str	q0, [x8]
	strh	wzr, [x19, #1176]
	str	q0, [x19, #1184]
	str	q1, [x19, #1200]
	strb	w20, [x19, #1216]
	add	x8, x19, #1224
	str	q0, [x8]
	strh	wzr, [x19, #1240]
	str	q0, [x19, #1248]
	str	q1, [x19, #1264]
	strb	w20, [x19, #1280]
	add	x8, x19, #1288
	str	q0, [x8]
	strh	wzr, [x19, #1304]
	str	q0, [x19, #1312]
	str	q1, [x19, #1328]
	strb	w20, [x19, #1344]
	add	x8, x19, #1352
	str	q0, [x8]
	strh	wzr, [x19, #1368]
	str	q0, [x19, #1376]
	str	q1, [x19, #1392]
	strb	w20, [x19, #1408]
	add	x8, x19, #1416
	str	q0, [x8]
	strh	wzr, [x19, #1432]
	str	q0, [x19, #1440]
	str	q1, [x19, #1456]
	strb	w20, [x19, #1472]
	add	x8, x19, #1480
	str	q0, [x8]
	strh	wzr, [x19, #1496]
	str	q0, [x19, #1504]
	str	q1, [x19, #1520]
	strb	w20, [x19, #1536]
	add	x8, x19, #1544
	str	q0, [x8]
	strh	wzr, [x19, #1560]
	str	q0, [x19, #1568]
	str	q1, [x19, #1584]
	strb	w20, [x19, #1600]
	add	x8, x19, #1608
	str	q0, [x8]
	strh	wzr, [x19, #1624]
	str	q0, [x19, #1632]
	str	q1, [x19, #1648]
	strb	w20, [x19, #1664]
	add	x8, x19, #1672
	str	q0, [x8]
	strh	wzr, [x19, #1688]
	str	q0, [x19, #1696]
	str	q1, [x19, #1712]
	strb	w20, [x19, #1728]
	add	x8, x19, #1736
	str	q0, [x8]
	strh	wzr, [x19, #1752]
	str	q0, [x19, #1760]
	str	q1, [x19, #1776]
	strb	w20, [x19, #1792]
	add	x8, x19, #1800
	str	q0, [x8]
	strh	wzr, [x19, #1816]
	str	q0, [x19, #1824]
	str	q1, [x19, #1840]
	strb	w20, [x19, #1856]
	add	x8, x19, #1864
	str	q0, [x8]
	strh	wzr, [x19, #1880]
	str	q0, [x19, #1888]
	str	q1, [x19, #1904]
	strb	w20, [x19, #1920]
	add	x8, x19, #1928
	str	q0, [x8]
	strh	wzr, [x19, #1944]
	str	q0, [x19, #1952]
	str	q1, [x19, #1968]
	strb	w20, [x19, #1984]
	add	x8, x19, #1992
	str	q0, [x8]
	strh	wzr, [x19, #2008]
	str	q0, [x19, #2016]
	str	q1, [x19, #2032]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.loh AdrpLdr	Lloh12, Lloh13
                                        ; -- End function
	.globl	_wf_indexed_fail                ; -- Begin function wf_indexed_fail
	.p2align	2
_wf_indexed_fail:                       ; @wf_indexed_fail
; %bb.0:                                ; %entry
	ldr	x8, [x0, #1304]
	add	x8, x8, #1
	str	x8, [x0, #1304]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_indexed_status              ; -- Begin function wf_indexed_status
	.p2align	2
_wf_indexed_status:                     ; @wf_indexed_status
; %bb.0:                                ; %entry
	cmp	x2, w1, uxtw
	b.eq	LBB11_2
; %bb.1:                                ; %bb13
	ldr	x8, [x0, #1304]
	add	x8, x8, #1
	str	x8, [x0, #1304]
LBB11_2:                                ; %bb12
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_indexed_before              ; -- Begin function wf_indexed_before
	.p2align	2
_wf_indexed_before:                     ; @wf_indexed_before
; %bb.0:                                ; %entry
	ldr	x8, [x0, #8]
	ldr	x9, [x0, #32]
	ldp	x10, x11, [x0, #48]
	ldr	x12, [x1, #8]
	ldr	x13, [x1, #32]
	ldp	x14, x15, [x1, #48]
	cmp	x11, x15
	cset	w11, lo
	cmp	x10, x14
	cset	w10, lo
	csel	w10, w11, w10, eq
	cmp	x8, x12
	cset	w8, lo
	csel	w8, w10, w8, eq
	cmp	x9, x13
	cset	w9, lo
	csel	w0, w8, w9, eq
	ret
                                        ; -- End function
	.globl	_wf_indexed_word_consume        ; -- Begin function wf_indexed_word_consume
	.p2align	2
_wf_indexed_word_consume:               ; @wf_indexed_word_consume
; %bb.0:                                ; %entry
	add	x8, x1, #8
	mov	w9, #1                          ; =0x1
	dup.2d	v0, x9
	ldr	q1, [x0]
	ld1.d	{ v0 }[1], [x8]
	add.2d	v0, v1, v0
	str	q0, [x0]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_indexed_capacity_and_retirement
lCPI14_0:
	.quad	1                               ; 0x1
	.quad	10                              ; 0xa
lCPI14_1:
	.quad	2                               ; 0x2
	.quad	0                               ; 0x0
lCPI14_2:
	.quad	1                               ; 0x1
	.quad	20                              ; 0x14
lCPI14_3:
	.quad	1                               ; 0x1
	.quad	30                              ; 0x1e
lCPI14_4:
	.quad	1                               ; 0x1
	.quad	0                               ; 0x0
lCPI14_5:
	.quad	1                               ; 0x1
	.quad	2                               ; 0x2
lCPI14_6:
	.quad	1                               ; 0x1
	.quad	3                               ; 0x3
lCPI14_7:
	.quad	83                              ; 0x53
	.quad	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_indexed_capacity_and_retirement
	.p2align	2
_wf_indexed_capacity_and_retirement:    ; @wf_indexed_capacity_and_retirement
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #528
	.cfi_def_cfa_offset 624
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	add	x0, sp, #264
	mov	w1, #81                         ; =0x51
	mov	w2, #0                          ; =0x0
	mov	w3, #2                          ; =0x2
	mov	w4, #2                          ; =0x2
	mov	x6, #0                          ; =0x0
	mov	w5, #2                          ; =0x2
	bl	_wf_record_store_new$instance$50c6da9371c13a22
	strb	wzr, [sp, #480]
	ldr	x8, [sp, #304]
	ldr	x9, [sp, #280]
	cmp	x8, x9
	b.hs	LBB14_4
; %bb.1:                                ; %bb2.i.i.i.i
	ldr	x10, [sp, #296]
	mov	w11, #56                        ; =0x38
	madd	x11, x8, x11, x10
	ldr	x10, [x11]
	cbnz	x10, LBB14_7
; %bb.2:                                ; %bb5.i.i.i.i
	ldr	x19, [x11, #40]
	cmp	x19, #1
	b.hi	LBB14_7
; %bb.3:                                ; %bb8.i.i.i.i
	ldr	x10, [x11, #48]
	mov	w12, #11                        ; =0xb
	str	x12, [x11, #16]
	strb	wzr, [x11, #24]
	mov	w12, #2                         ; =0x2
	str	x12, [x11, #32]
Lloh14:
	adrp	x12, lCPI14_0@PAGE
Lloh15:
	ldr	q0, [x12, lCPI14_0@PAGEOFF]
	str	q0, [x11]
	str	x10, [sp, #304]
	b	LBB14_6
LBB14_4:                                ; %bb3.i.i.i.i
	ldr	x10, [sp, #288]
	cmp	x9, x10
	b.hs	LBB14_7
; %bb.5:                                ; %bb11.i.i.i.i
	mov	x19, #0                         ; =0x0
	ldr	x10, [sp, #296]
	mov	w11, #56                        ; =0x38
	madd	x10, x9, x11, x10
Lloh16:
	adrp	x11, lCPI14_0@PAGE
Lloh17:
	ldr	q0, [x11, lCPI14_0@PAGEOFF]
	str	q0, [x10]
	mov	w11, #11                        ; =0xb
	str	x11, [x10, #16]
Lloh18:
	adrp	x11, lCPI14_1@PAGE
Lloh19:
	ldr	q0, [x11, lCPI14_1@PAGEOFF]
	strb	wzr, [x10, #24]
	str	q0, [x10, #32]
	str	x8, [x10, #48]
	mov	x10, x8
	mov	x8, x9
	add	x9, x9, #1
	str	x9, [sp, #280]
LBB14_6:                                ; %bb1.i.i
	mov	x21, #0                         ; =0x0
	mov	x20, x8
	ldr	x22, [sp, #264]
	mov	x8, x10
	b	LBB14_8
LBB14_7:                                ; %bb2.i.i
	mov	x19, #0                         ; =0x0
	ldr	x22, [sp, #264]
	mov	w20, #2                         ; =0x2
	mov	w21, #1                         ; =0x1
LBB14_8:                                ; %"wf_indexed_word_insert$instance$c9ecd8438d97c9c4.exit"
	stp	x22, x20, [sp, #456]
	str	x19, [sp, #472]
	strb	wzr, [sp, #480]
	cmp	x8, x9
	b.hs	LBB14_12
; %bb.9:                                ; %bb2.i.i.i.i60
	ldr	x9, [sp, #296]
	mov	w10, #56                        ; =0x38
	madd	x9, x8, x10, x9
	ldr	x10, [x9]
	cbnz	x10, LBB14_14
; %bb.10:                               ; %bb5.i.i.i.i67
	ldr	x10, [x9, #40]
	cmp	x10, #1
	b.hi	LBB14_14
; %bb.11:                               ; %bb8.i.i.i.i71
	ldr	x11, [x9, #48]
	mov	w12, #22                        ; =0x16
	str	x12, [x9, #16]
	strb	wzr, [x9, #24]
	mov	w12, #2                         ; =0x2
	str	x12, [x9, #32]
Lloh20:
	adrp	x12, lCPI14_2@PAGE
Lloh21:
	ldr	q0, [x12, lCPI14_2@PAGEOFF]
	str	q0, [x9]
	str	x11, [sp, #304]
	b	LBB14_15
LBB14_12:                               ; %bb3.i.i.i.i29
	ldr	x10, [sp, #288]
	cmp	x9, x10
	b.hs	LBB14_14
; %bb.13:                               ; %bb11.i.i.i.i44
	mov	x10, #0                         ; =0x0
	ldr	x11, [sp, #296]
	mov	w12, #56                        ; =0x38
	madd	x11, x9, x12, x11
Lloh22:
	adrp	x12, lCPI14_2@PAGE
Lloh23:
	ldr	q0, [x12, lCPI14_2@PAGEOFF]
	str	q0, [x11]
	mov	w12, #22                        ; =0x16
	str	x12, [x11, #16]
Lloh24:
	adrp	x12, lCPI14_1@PAGE
Lloh25:
	ldr	q0, [x12, lCPI14_1@PAGEOFF]
	strb	wzr, [x11, #24]
	str	q0, [x11, #32]
	str	x8, [x11, #48]
	add	x8, x9, #1
	str	x8, [sp, #280]
	mov	x8, x9
	b	LBB14_15
LBB14_14:                               ; %bb2.i.i33
	mov	x10, #0                         ; =0x0
	add	x21, x21, #1
	mov	w8, #2                          ; =0x2
LBB14_15:                               ; %"wf_indexed_word_insert$instance$c9ecd8438d97c9c4.exit78"
	stp	x22, x8, [sp, #432]
	str	x10, [sp, #448]
	add	x0, sp, #264
	add	x1, sp, #456
	bl	_wf_record_store_attach$instance$50c6da9371c13a22
	cmp	w0, #0
	cinc	x21, x21, ne
	add	x0, sp, #264
	add	x1, sp, #432
	bl	_wf_record_store_attach$instance$50c6da9371c13a22
	cmp	w0, #0
	cinc	x21, x21, ne
	add	x0, sp, #264
	add	x1, sp, #456
	mov	w2, #10                         ; =0xa
	bl	_wf_record_store_schedule$instance$50c6da9371c13a22
	cmp	w0, #0
	cinc	x21, x21, ne
	add	x0, sp, #264
	add	x1, sp, #432
	mov	w2, #20                         ; =0x14
	bl	_wf_record_store_schedule$instance$50c6da9371c13a22
	cmp	w0, #0
	cinc	x9, x21, ne
	ldr	x21, [sp, #264]
	ldr	x8, [sp, #280]
	cmp	x22, x21
	b.ne	LBB14_21
; %bb.16:                               ; %bb3.i.i
	cmp	x20, x8
	b.hs	LBB14_21
; %bb.17:                               ; %bb2.i.i.i
	ldr	x10, [sp, #296]
	mov	w11, #56                        ; =0x38
	madd	x11, x20, x11, x10
	ldr	x12, [x11, #40]
	cmp	x12, x19
	b.ne	LBB14_21
; %bb.18:                               ; %bb5.i.i.i
	ldr	x12, [x11]
	cbz	x12, LBB14_21
; %bb.19:                               ; %bb2.i
	ldrb	w13, [x11, #24]
	ldr	x14, [x11, #32]
	and	w13, w13, #0x1
	strb	w13, [sp, #480]
	ldrb	w15, [sp, #272]
	cmp	x14, #2
	csinc	w13, w13, wzr, eq
	tbz	w15, #0, LBB14_175
; %bb.20:                               ; %bb2.i
	tbz	w13, #0, LBB14_175
LBB14_21:                               ; %bb5.i.i
	mov	w10, #1                         ; =0x1
LBB14_22:                               ; %bb1
	add	x22, x9, x10
	strb	wzr, [sp, #480]
	ldr	x19, [sp, #304]
	cmp	x19, x8
	b.hs	LBB14_26
; %bb.23:                               ; %bb2.i.i.i.i177
	ldr	x8, [sp, #296]
	mov	w9, #56                         ; =0x38
	madd	x8, x19, x9, x8
	ldr	x9, [x8]
	cbnz	x9, LBB14_28
; %bb.24:                               ; %bb5.i.i.i.i184
	ldr	x20, [x8, #40]
	cmp	x20, #1
	b.hi	LBB14_28
; %bb.25:                               ; %bb8.i.i.i.i188
	ldr	x9, [x8, #48]
	mov	w10, #33                        ; =0x21
	str	x10, [x8, #16]
	strb	wzr, [x8, #24]
	mov	w10, #2                         ; =0x2
	str	x10, [x8, #32]
Lloh26:
	adrp	x10, lCPI14_3@PAGE
Lloh27:
	ldr	q0, [x10, lCPI14_3@PAGEOFF]
	str	q0, [x8]
	str	x9, [sp, #304]
	b	LBB14_29
LBB14_26:                               ; %bb3.i.i.i.i146
	ldr	x9, [sp, #288]
	cmp	x8, x9
	b.hs	LBB14_28
; %bb.27:                               ; %bb11.i.i.i.i161
	mov	x20, #0                         ; =0x0
	ldr	x9, [sp, #296]
	mov	w10, #56                        ; =0x38
	madd	x9, x8, x10, x9
Lloh28:
	adrp	x10, lCPI14_3@PAGE
Lloh29:
	ldr	q0, [x10, lCPI14_3@PAGEOFF]
	str	q0, [x9]
	mov	w10, #33                        ; =0x21
	str	x10, [x9, #16]
Lloh30:
	adrp	x10, lCPI14_1@PAGE
Lloh31:
	ldr	q0, [x10, lCPI14_1@PAGEOFF]
	strb	wzr, [x9, #24]
	str	q0, [x9, #32]
	str	x19, [x9, #48]
	add	x9, x8, #1
	str	x9, [sp, #280]
	mov	x19, x8
	b	LBB14_29
LBB14_28:                               ; %bb2.i.i150
	mov	x20, #0                         ; =0x0
	add	x22, x22, #1
	mov	w19, #2                         ; =0x2
LBB14_29:                               ; %"wf_indexed_word_insert$instance$c9ecd8438d97c9c4.exit195"
	stp	x21, x19, [sp, #408]
	str	x20, [sp, #424]
	add	x0, sp, #264
	add	x1, sp, #408
	bl	_wf_record_store_attach$instance$50c6da9371c13a22
	cmp	w0, #6
	cinc	x22, x22, lo
	add	x0, sp, #264
	add	x1, sp, #408
	mov	w2, #30                         ; =0x1e
	bl	_wf_record_store_schedule$instance$50c6da9371c13a22
	cmp	w0, #6
	cinc	x8, x22, ne
	ldr	x9, [sp, #264]
	cmp	x21, x9
	b.ne	LBB14_34
; %bb.30:                               ; %bb3.i233
	ldr	x9, [sp, #280]
	cmp	x19, x9
	b.hs	LBB14_34
; %bb.31:                               ; %bb2.i.i237
	ldr	x9, [sp, #296]
	mov	w10, #56                        ; =0x38
	madd	x9, x19, x10, x9
	ldr	x10, [x9, #40]
	cmp	x10, x20
	b.ne	LBB14_34
; %bb.32:                               ; %bb5.i.i238
	ldr	x10, [x9]
	cbz	x10, LBB14_34
; %bb.33:                               ; %bb8
	ldrb	w10, [x9, #24]
	ldr	x9, [x9, #32]
	and	w10, w10, #0x1
	strb	w10, [sp, #480]
	and	w10, w10, #0xff
	and	x10, x10, #0x1
	add	x8, x8, x10
	cmp	x9, #2
	cinc	x19, x8, ne
	b	LBB14_35
LBB14_34:                               ; %bb9
	add	x19, x8, #1
LBB14_35:                               ; %bb7
	add	x0, sp, #264
	add	x2, sp, #456
	mov	w1, #10                         ; =0xa
	bl	_wf_record_store_detach$instance$50c6da9371c13a22
	cmp	w0, #0
	cinc	x19, x19, ne
	add	x0, sp, #264
	add	x1, sp, #408
	bl	_wf_record_store_attach$instance$50c6da9371c13a22
	cmp	w0, #0
	cinc	x19, x19, ne
	stp	xzr, xzr, [sp, #248]
	add	x0, sp, #264
	add	x2, sp, #248
	mov	w1, #10                         ; =0xa
	bl	_wf_record_store_expire$instance$b867adcf10f50f79
	cmp	x0, #0
	cinc	x8, x19, ne
	ldr	x22, [sp, #248]
	cmp	x22, #0
	cinc	x19, x8, ne
	add	x0, sp, #264
	add	x1, sp, #408
	mov	w2, #30                         ; =0x1e
	bl	_wf_record_store_schedule$instance$50c6da9371c13a22
	cmp	w0, #0
	cinc	x21, x19, ne
	ldp	x24, x23, [sp, #280]
	ldr	x19, [sp, #296]
	ldr	x8, [sp, #320]
	ldp	x25, x20, [sp, #360]
	cbz	x8, LBB14_37
; %bb.36:                               ; %slots.release.drop.6.i.i.i
	ldr	x0, [sp, #328]
	bl	_free
LBB14_37:                               ; %"wf_std.collections.hash_map.hash_map_free$instance$d405037d8db33b6d.exit.i"
	cbz	x25, LBB14_39
; %bb.38:                               ; %slots.release.drop.6.i.i2.i
	mov	x0, x20
	bl	_free
LBB14_39:                               ; %"wf_collections.priority_queue.priority_queue_free$instance$272f87483c69b364.exit.i"
	cbz	x24, LBB14_48
; %bb.40:                               ; %bb5.lr.ph.i.i
	ldr	x8, [sp, #256]
	ands	x10, x24, #0x7
	b.eq	LBB14_45
; %bb.41:                               ; %bb5.i.i310.prol.preheader
	mov	w9, #56                         ; =0x38
	madd	x9, x24, x9, x19
	sub	x11, x9, #56
	add	x12, sp, #480
	mov	x9, x24
	b	LBB14_43
LBB14_42:                               ; %bb6.i.i.prol
                                        ;   in Loop: Header=BB14_43 Depth=1
	sub	x11, x11, #56
	sub	x9, x9, #1
	sub	x10, x10, #1
	cbz	x10, LBB14_46
LBB14_43:                               ; %bb5.i.i310.prol
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x11]
	str	q0, [sp, #480]
	ldr	q0, [x11, #16]
	str	q0, [sp, #496]
	ldr	x13, [x11, #32]
	str	x13, [sp, #512]
	ldr	x13, [sp, #480]
	cbz	x13, LBB14_42
; %bb.44:                               ; %bb7.i.i.prol
                                        ;   in Loop: Header=BB14_43 Depth=1
	sub	x13, x13, #1
	str	x13, [sp, #480]
	add	x13, x12, x13, lsl #5
	ldr	x13, [x13, #16]
	add	x22, x22, #1
	add	x8, x13, x8
	b	LBB14_42
LBB14_45:
	mov	x9, x24
LBB14_46:                               ; %bb5.i.i310.prol.loopexit
	cmp	x24, #8
	b.hs	LBB14_94
LBB14_47:                               ; %bb4.i.i.loopexit
	stp	x22, x8, [sp, #248]
LBB14_48:                               ; %bb4.i.i
	cbz	x23, LBB14_50
; %bb.49:                               ; %slots.release.drop.6.i.i8.i
	mov	x0, x19
	bl	_free
LBB14_50:                               ; %"wf_record_store_free$instance$b867adcf10f50f79.exit"
	cmp	x22, #2
	cinc	x8, x21, ne
	ldr	x24, [sp, #256]
	cmp	x24, #55
	cinc	x19, x8, ne
	add	x0, sp, #128
	mov	w1, #82                         ; =0x52
	mov	w2, #0                          ; =0x0
	mov	w3, #1                          ; =0x1
	mov	x4, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	mov	x6, #0                          ; =0x0
	bl	_wf_record_store_new$instance$5ffcb0796f3480f6
	strb	wzr, [sp, #480]
	ldr	x9, [sp, #168]
	ldr	x8, [sp, #144]
	cmp	x9, x8
	b.hs	LBB14_54
; %bb.51:                               ; %bb2.i.i.i.i359
	ldr	x10, [sp, #160]
	mov	w11, #56                        ; =0x38
	madd	x10, x9, x11, x10
	ldr	x11, [x10]
	cbnz	x11, LBB14_57
; %bb.52:                               ; %bb5.i.i.i.i366
	ldr	x11, [x10, #40]
	cmp	x11, #1
	b.hi	LBB14_57
; %bb.53:                               ; %bb8.i.i.i.i370
	ldr	x12, [x10, #48]
	mov	w13, #111                       ; =0x6f
	str	x13, [x10, #16]
	strb	wzr, [x10, #24]
	mov	w13, #1                         ; =0x1
	str	x13, [x10, #32]
	dup.2d	v0, x13
	str	q0, [x10]
	str	x12, [sp, #168]
	b	LBB14_56
LBB14_54:                               ; %bb3.i.i.i.i328
	ldr	x10, [sp, #152]
	cmp	x8, x10
	b.hs	LBB14_57
; %bb.55:                               ; %bb11.i.i.i.i343
	mov	x11, #0                         ; =0x0
	ldr	x10, [sp, #160]
	mov	w12, #56                        ; =0x38
	madd	x10, x8, x12, x10
	mov	w12, #1                         ; =0x1
	dup.2d	v0, x12
	str	q0, [x10]
	mov	w12, #111                       ; =0x6f
	str	x12, [x10, #16]
Lloh32:
	adrp	x12, lCPI14_4@PAGE
Lloh33:
	ldr	q0, [x12, lCPI14_4@PAGEOFF]
	strb	wzr, [x10, #24]
	str	q0, [x10, #32]
	str	x9, [x10, #48]
	mov	x12, x9
	mov	x9, x8
	add	x8, x8, #1
	str	x8, [sp, #144]
LBB14_56:                               ; %bb1.i.i355
	mov	x10, x9
	ldr	x13, [sp, #128]
	mov	x9, x12
	b	LBB14_58
LBB14_57:                               ; %bb2.i.i332
	mov	x11, #0                         ; =0x0
	add	x19, x19, #1
	ldr	x13, [sp, #128]
	mov	w10, #1                         ; =0x1
LBB14_58:                               ; %bb3.i.i389
	stp	x13, x10, [sp, #384]
	str	x11, [sp, #400]
	cmp	x10, x8
	b.hs	LBB14_63
; %bb.59:                               ; %bb2.i.i.i394
	ldr	x12, [sp, #160]
	mov	w13, #56                        ; =0x38
	madd	x13, x10, x13, x12
	ldr	x14, [x13, #40]
	cmp	x14, x11
	b.ne	LBB14_63
; %bb.60:                               ; %bb5.i.i.i402
	ldr	x14, [x13]
	cbz	x14, LBB14_63
; %bb.61:                               ; %bb2.i405
	ldrb	w15, [x13, #24]
	ldr	x16, [x13, #32]
	and	w15, w15, #0x1
	strb	w15, [sp, #480]
	ldrb	w17, [sp, #136]
	cmp	x16, #1
	csinc	w15, w15, wzr, eq
	tbz	w17, #0, LBB14_169
; %bb.62:                               ; %bb2.i405
	tbz	w15, #0, LBB14_169
LBB14_63:                               ; %bb5.i.i393
	mov	w11, #1                         ; =0x1
LBB14_64:                               ; %bb28
	add	x12, x19, x11
	strb	wzr, [sp, #480]
	cmp	x9, x8
	b.hs	LBB14_68
; %bb.65:                               ; %bb2.i.i.i.i470
	ldr	x11, [sp, #160]
	mov	w13, #56                        ; =0x38
	madd	x14, x9, x13, x11
	ldr	x11, [x14]
	cbnz	x11, LBB14_70
; %bb.66:                               ; %bb5.i.i.i.i477
	ldr	x11, [x14, #40]
	cmp	x11, #1
	b.hi	LBB14_70
; %bb.67:                               ; %bb8.i.i.i.i481
	mov	x13, x9
	ldr	x9, [x14, #48]
	mov	w15, #222                       ; =0xde
	str	x15, [x14, #16]
	strb	wzr, [x14, #24]
	mov	w15, #1                         ; =0x1
	str	x15, [x14, #32]
Lloh34:
	adrp	x15, lCPI14_5@PAGE
Lloh35:
	ldr	q0, [x15, lCPI14_5@PAGEOFF]
	str	q0, [x14]
	str	x9, [sp, #168]
	b	LBB14_71
LBB14_68:                               ; %bb3.i.i.i.i439
	ldr	x11, [sp, #152]
	cmp	x8, x11
	b.hs	LBB14_70
; %bb.69:                               ; %bb11.i.i.i.i454
	mov	x11, #0                         ; =0x0
	ldr	x13, [sp, #160]
	mov	w14, #56                        ; =0x38
	madd	x13, x8, x14, x13
Lloh36:
	adrp	x14, lCPI14_5@PAGE
Lloh37:
	ldr	q0, [x14, lCPI14_5@PAGEOFF]
	str	q0, [x13]
	mov	w14, #222                       ; =0xde
	str	x14, [x13, #16]
Lloh38:
	adrp	x14, lCPI14_4@PAGE
Lloh39:
	ldr	q0, [x14, lCPI14_4@PAGEOFF]
	strb	wzr, [x13, #24]
	str	q0, [x13, #32]
	str	x9, [x13, #48]
	mov	x13, x8
	add	x8, x8, #1
	str	x8, [sp, #144]
	b	LBB14_71
LBB14_70:                               ; %bb2.i.i443
	mov	x11, #0                         ; =0x0
	add	x12, x12, #1
	mov	w13, #1                         ; =0x1
LBB14_71:                               ; %"wf_indexed_word_insert$instance$82e8a0addfd772af.exit488"
	cmp	x13, x10
	cinc	x10, x12, ne
	cmp	x11, #1
	cinc	x10, x10, ne
	cmp	x13, x8
	b.hs	LBB14_76
; %bb.72:                               ; %bb2.i.i.i515
	ldr	x12, [sp, #160]
	mov	w14, #56                        ; =0x38
	madd	x14, x13, x14, x12
	ldr	x15, [x14, #40]
	cmp	x15, x11
	b.ne	LBB14_76
; %bb.73:                               ; %bb5.i.i.i523
	ldr	x15, [x14]
	cbz	x15, LBB14_76
; %bb.74:                               ; %bb2.i526
	ldrb	w16, [x14, #24]
	ldr	x17, [x14, #32]
	and	w16, w16, #0x1
	strb	w16, [sp, #480]
	ldrb	w0, [sp, #136]
	cmp	x17, #1
	csinc	w16, w16, wzr, eq
	tbz	w0, #0, LBB14_172
; %bb.75:                               ; %bb2.i526
	tbz	w16, #0, LBB14_172
LBB14_76:                               ; %bb5.i.i514
	mov	w11, #1                         ; =0x1
LBB14_77:                               ; %bb40
	add	x23, x10, x11
	strb	wzr, [sp, #480]
	cmp	x9, x8
	b.hs	LBB14_81
; %bb.78:                               ; %bb2.i.i563
	ldr	x8, [sp, #160]
	mov	w10, #56                        ; =0x38
	madd	x8, x9, x10, x8
	ldr	x9, [x8]
	cbnz	x9, LBB14_84
; %bb.79:                               ; %bb5.i.i564
	ldr	x9, [x8, #40]
	cmp	x9, #1
	b.hi	LBB14_84
; %bb.80:                               ; %bb8.i.i565
	ldr	x9, [x8, #48]
	mov	w10, #333                       ; =0x14d
	str	x10, [x8, #16]
	strb	wzr, [x8, #24]
	mov	w10, #1                         ; =0x1
	str	x10, [x8, #32]
Lloh40:
	adrp	x10, lCPI14_6@PAGE
Lloh41:
	ldr	q0, [x10, lCPI14_6@PAGEOFF]
	str	q0, [x8]
	str	x9, [sp, #168]
	b	LBB14_83
LBB14_81:                               ; %bb3.i.i556
	ldr	x10, [sp, #152]
	cmp	x8, x10
	b.hs	LBB14_84
; %bb.82:                               ; %bb11.i.i560
	ldr	x10, [sp, #160]
	mov	w11, #56                        ; =0x38
	madd	x10, x8, x11, x10
Lloh42:
	adrp	x11, lCPI14_6@PAGE
Lloh43:
	ldr	q0, [x11, lCPI14_6@PAGEOFF]
	str	q0, [x10]
	mov	w11, #333                       ; =0x14d
	str	x11, [x10, #16]
	strb	wzr, [x10, #24]
Lloh44:
	adrp	x11, lCPI14_4@PAGE
Lloh45:
	ldr	q0, [x11, lCPI14_4@PAGEOFF]
	str	q0, [x10, #32]
	str	x9, [x10, #48]
	add	x8, x8, #1
	str	x8, [sp, #144]
LBB14_83:                               ; %bb46
	add	x23, x23, #1
LBB14_84:                               ; %bb46
	add	x0, sp, #128
	add	x1, sp, #384
	mov	w2, #1                          ; =0x1
	bl	_wf_record_store_schedule$instance$5ffcb0796f3480f6
	mov	x19, x0
	ldp	x26, x25, [sp, #144]
	ldr	x20, [sp, #160]
	ldr	x8, [sp, #184]
	ldp	x27, x21, [sp, #224]
	cbz	x8, LBB14_86
; %bb.85:                               ; %slots.release.drop.6.i.i.i605
	ldr	x0, [sp, #192]
	bl	_free
LBB14_86:                               ; %"wf_std.collections.hash_map.hash_map_free$instance$49bcdf956259ee48.exit.i"
	cbz	x27, LBB14_88
; %bb.87:                               ; %slots.release.drop.6.i.i2.i609
	mov	x0, x21
	bl	_free
LBB14_88:                               ; %"wf_collections.priority_queue.priority_queue_free$instance$bc1a7c25f6fdb27b.exit.i"
	cbz	x26, LBB14_115
; %bb.89:                               ; %bb5.i.i615.preheader
	ands	x9, x26, #0x7
	b.eq	LBB14_112
; %bb.90:                               ; %bb5.i.i615.prol.preheader
	mov	w8, #56                         ; =0x38
	madd	x8, x26, x8, x20
	sub	x10, x8, #56
	add	x11, sp, #480
	mov	x8, x26
	b	LBB14_92
LBB14_91:                               ; %bb6.i.i629.prol
                                        ;   in Loop: Header=BB14_92 Depth=1
	sub	x10, x10, #56
	sub	x8, x8, #1
	sub	x9, x9, #1
	cbz	x9, LBB14_113
LBB14_92:                               ; %bb5.i.i615.prol
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x10]
	str	q0, [sp, #480]
	ldr	q0, [x10, #16]
	str	q0, [sp, #496]
	ldr	x12, [x10, #32]
	str	x12, [sp, #512]
	ldr	x12, [sp, #480]
	cbz	x12, LBB14_91
; %bb.93:                               ; %bb7.i.i623.prol
                                        ;   in Loop: Header=BB14_92 Depth=1
	sub	x12, x12, #1
	str	x12, [sp, #480]
	add	x12, x11, x12, lsl #5
	ldr	x12, [x12, #16]
	add	x22, x22, #1
	add	x24, x12, x24
	b	LBB14_91
LBB14_94:                               ; %bb5.lr.ph.i.i.new
	mov	w10, #56                        ; =0x38
	madd	x10, x9, x10, x19
	sub	x10, x10, #224
	add	x11, sp, #480
	b	LBB14_96
LBB14_95:                               ; %bb6.i.i.7
                                        ;   in Loop: Header=BB14_96 Depth=1
	sub	x10, x10, #448
	sub	x9, x9, #8
	cbz	x9, LBB14_47
LBB14_96:                               ; %bb5.i.i310
                                        ; =>This Inner Loop Header: Depth=1
	ldur	q0, [x10, #168]
	str	q0, [sp, #480]
	ldur	q0, [x10, #184]
	str	q0, [sp, #496]
	ldr	x12, [x10, #200]
	str	x12, [sp, #512]
	ldr	x12, [sp, #480]
	cbz	x12, LBB14_98
; %bb.97:                               ; %bb7.i.i
                                        ;   in Loop: Header=BB14_96 Depth=1
	sub	x12, x12, #1
	str	x12, [sp, #480]
	add	x12, x11, x12, lsl #5
	ldr	x12, [x12, #16]
	add	x22, x22, #1
	add	x8, x12, x8
LBB14_98:                               ; %bb6.i.i
                                        ;   in Loop: Header=BB14_96 Depth=1
	ldr	q0, [x10, #112]
	str	q0, [sp, #480]
	ldr	q0, [x10, #128]
	str	q0, [sp, #496]
	ldr	x12, [x10, #144]
	str	x12, [sp, #512]
	ldr	x12, [sp, #480]
	cbz	x12, LBB14_100
; %bb.99:                               ; %bb7.i.i.1
                                        ;   in Loop: Header=BB14_96 Depth=1
	sub	x12, x12, #1
	str	x12, [sp, #480]
	add	x12, x11, x12, lsl #5
	ldr	x12, [x12, #16]
	add	x22, x22, #1
	add	x8, x12, x8
LBB14_100:                              ; %bb6.i.i.1
                                        ;   in Loop: Header=BB14_96 Depth=1
	ldur	q0, [x10, #56]
	str	q0, [sp, #480]
	ldur	q0, [x10, #72]
	str	q0, [sp, #496]
	ldr	x12, [x10, #88]
	str	x12, [sp, #512]
	ldr	x12, [sp, #480]
	cbz	x12, LBB14_102
; %bb.101:                              ; %bb7.i.i.2
                                        ;   in Loop: Header=BB14_96 Depth=1
	sub	x12, x12, #1
	str	x12, [sp, #480]
	add	x12, x11, x12, lsl #5
	ldr	x12, [x12, #16]
	add	x22, x22, #1
	add	x8, x12, x8
LBB14_102:                              ; %bb6.i.i.2
                                        ;   in Loop: Header=BB14_96 Depth=1
	ldr	q0, [x10]
	str	q0, [sp, #480]
	ldr	q0, [x10, #16]
	str	q0, [sp, #496]
	ldr	x12, [x10, #32]
	str	x12, [sp, #512]
	ldr	x12, [sp, #480]
	cbz	x12, LBB14_104
; %bb.103:                              ; %bb7.i.i.3
                                        ;   in Loop: Header=BB14_96 Depth=1
	sub	x12, x12, #1
	str	x12, [sp, #480]
	add	x12, x11, x12, lsl #5
	ldr	x12, [x12, #16]
	add	x22, x22, #1
	add	x8, x12, x8
LBB14_104:                              ; %bb6.i.i.3
                                        ;   in Loop: Header=BB14_96 Depth=1
	ldur	q0, [x10, #-56]
	str	q0, [sp, #480]
	ldur	q0, [x10, #-40]
	str	q0, [sp, #496]
	ldur	x12, [x10, #-24]
	str	x12, [sp, #512]
	ldr	x12, [sp, #480]
	cbz	x12, LBB14_106
; %bb.105:                              ; %bb7.i.i.4
                                        ;   in Loop: Header=BB14_96 Depth=1
	sub	x12, x12, #1
	str	x12, [sp, #480]
	add	x12, x11, x12, lsl #5
	ldr	x12, [x12, #16]
	add	x22, x22, #1
	add	x8, x12, x8
LBB14_106:                              ; %bb6.i.i.4
                                        ;   in Loop: Header=BB14_96 Depth=1
	ldur	q0, [x10, #-112]
	str	q0, [sp, #480]
	ldur	q0, [x10, #-96]
	str	q0, [sp, #496]
	ldur	x12, [x10, #-80]
	str	x12, [sp, #512]
	ldr	x12, [sp, #480]
	cbz	x12, LBB14_108
; %bb.107:                              ; %bb7.i.i.5
                                        ;   in Loop: Header=BB14_96 Depth=1
	sub	x12, x12, #1
	str	x12, [sp, #480]
	add	x12, x11, x12, lsl #5
	ldr	x12, [x12, #16]
	add	x22, x22, #1
	add	x8, x12, x8
LBB14_108:                              ; %bb6.i.i.5
                                        ;   in Loop: Header=BB14_96 Depth=1
	ldur	q0, [x10, #-168]
	str	q0, [sp, #480]
	ldur	q0, [x10, #-152]
	str	q0, [sp, #496]
	ldur	x12, [x10, #-136]
	str	x12, [sp, #512]
	ldr	x12, [sp, #480]
	cbz	x12, LBB14_110
; %bb.109:                              ; %bb7.i.i.6
                                        ;   in Loop: Header=BB14_96 Depth=1
	sub	x12, x12, #1
	str	x12, [sp, #480]
	add	x12, x11, x12, lsl #5
	ldr	x12, [x12, #16]
	add	x22, x22, #1
	add	x8, x12, x8
LBB14_110:                              ; %bb6.i.i.6
                                        ;   in Loop: Header=BB14_96 Depth=1
	ldur	q0, [x10, #-224]
	str	q0, [sp, #480]
	ldur	q0, [x10, #-208]
	str	q0, [sp, #496]
	ldur	x12, [x10, #-192]
	str	x12, [sp, #512]
	ldr	x12, [sp, #480]
	cbz	x12, LBB14_95
; %bb.111:                              ; %bb7.i.i.7
                                        ;   in Loop: Header=BB14_96 Depth=1
	sub	x12, x12, #1
	str	x12, [sp, #480]
	add	x12, x11, x12, lsl #5
	ldr	x12, [x12, #16]
	add	x22, x22, #1
	add	x8, x12, x8
	b	LBB14_95
LBB14_112:
	mov	x8, x26
LBB14_113:                              ; %bb5.i.i615.prol.loopexit
	cmp	x26, #8
	b.hs	LBB14_127
LBB14_114:                              ; %bb4.i.i633.loopexit
	stp	x22, x24, [sp, #248]
LBB14_115:                              ; %bb4.i.i633
	cbz	x25, LBB14_117
; %bb.116:                              ; %slots.release.drop.6.i.i8.i635
	mov	x0, x20
	bl	_free
LBB14_117:                              ; %bb52
Lloh46:
	adrp	x8, lCPI14_7@PAGE
Lloh47:
	ldr	q0, [x8, lCPI14_7@PAGEOFF]
	str	q0, [sp]
	strb	wzr, [sp, #8]
Lloh48:
	adrp	x8, l_.wf.empty.slots.payload@PAGE
Lloh49:
	add	x8, x8, l_.wf.empty.slots.payload@PAGEOFF
	stp	xzr, xzr, [sp, #16]
	stp	x8, xzr, [sp, #32]
	stp	xzr, xzr, [sp, #48]
	stp	x8, xzr, [sp, #64]
	stp	xzr, xzr, [sp, #80]
	stp	xzr, x8, [sp, #96]
	str	xzr, [sp, #112]
	mov	x0, sp
	add	x2, sp, #248
	mov	x1, #-1                         ; =0xffffffffffffffff
	bl	_wf_record_store_expire$instance$07ca9210fae40158
	mov	x20, x0
	ldp	x25, x24, [sp, #16]
	ldr	x21, [sp, #32]
	ldr	x8, [sp, #56]
	ldp	x26, x22, [sp, #96]
	cbz	x8, LBB14_119
; %bb.118:                              ; %slots.release.drop.6.i.i.i714
	ldr	x0, [sp, #64]
	bl	_free
LBB14_119:                              ; %"wf_std.collections.hash_map.hash_map_free$instance$254d3f8f5bda5a0a.exit.i"
	cbz	x26, LBB14_121
; %bb.120:                              ; %slots.release.drop.6.i.i2.i718
	mov	x0, x22
	bl	_free
LBB14_121:                              ; %"wf_collections.priority_queue.priority_queue_free$instance$f600fe92c9d45040.exit.i"
	cbz	x25, LBB14_148
; %bb.122:                              ; %bb5.lr.ph.i.i720
	ldp	x8, x9, [sp, #248]
	ands	x11, x25, #0x7
	b.eq	LBB14_145
; %bb.123:                              ; %bb5.i.i724.prol.preheader
	mov	w10, #56                        ; =0x38
	madd	x10, x25, x10, x21
	sub	x12, x10, #56
	add	x13, sp, #480
	mov	x10, x25
	b	LBB14_125
LBB14_124:                              ; %bb6.i.i738.prol
                                        ;   in Loop: Header=BB14_125 Depth=1
	sub	x12, x12, #56
	sub	x10, x10, #1
	sub	x11, x11, #1
	cbz	x11, LBB14_146
LBB14_125:                              ; %bb5.i.i724.prol
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x12]
	str	q0, [sp, #480]
	ldr	q0, [x12, #16]
	str	q0, [sp, #496]
	ldr	x14, [x12, #32]
	str	x14, [sp, #512]
	ldr	x14, [sp, #480]
	cbz	x14, LBB14_124
; %bb.126:                              ; %bb7.i.i732.prol
                                        ;   in Loop: Header=BB14_125 Depth=1
	sub	x14, x14, #1
	str	x14, [sp, #480]
	add	x14, x13, x14, lsl #5
	ldr	x14, [x14, #16]
	add	x8, x8, #1
	add	x9, x14, x9
	b	LBB14_124
LBB14_127:                              ; %bb5.i.i615.preheader.new
	mov	w9, #56                         ; =0x38
	madd	x9, x8, x9, x20
	sub	x9, x9, #224
	add	x10, sp, #480
	b	LBB14_129
LBB14_128:                              ; %bb6.i.i629.7
                                        ;   in Loop: Header=BB14_129 Depth=1
	sub	x9, x9, #448
	sub	x8, x8, #8
	cbz	x8, LBB14_114
LBB14_129:                              ; %bb5.i.i615
                                        ; =>This Inner Loop Header: Depth=1
	ldur	q0, [x9, #168]
	str	q0, [sp, #480]
	ldur	q0, [x9, #184]
	str	q0, [sp, #496]
	ldr	x11, [x9, #200]
	str	x11, [sp, #512]
	ldr	x11, [sp, #480]
	cbz	x11, LBB14_131
; %bb.130:                              ; %bb7.i.i623
                                        ;   in Loop: Header=BB14_129 Depth=1
	sub	x11, x11, #1
	str	x11, [sp, #480]
	add	x11, x10, x11, lsl #5
	ldr	x11, [x11, #16]
	add	x22, x22, #1
	add	x24, x11, x24
LBB14_131:                              ; %bb6.i.i629
                                        ;   in Loop: Header=BB14_129 Depth=1
	ldr	q0, [x9, #112]
	str	q0, [sp, #480]
	ldr	q0, [x9, #128]
	str	q0, [sp, #496]
	ldr	x11, [x9, #144]
	str	x11, [sp, #512]
	ldr	x11, [sp, #480]
	cbz	x11, LBB14_133
; %bb.132:                              ; %bb7.i.i623.1
                                        ;   in Loop: Header=BB14_129 Depth=1
	sub	x11, x11, #1
	str	x11, [sp, #480]
	add	x11, x10, x11, lsl #5
	ldr	x11, [x11, #16]
	add	x22, x22, #1
	add	x24, x11, x24
LBB14_133:                              ; %bb6.i.i629.1
                                        ;   in Loop: Header=BB14_129 Depth=1
	ldur	q0, [x9, #56]
	str	q0, [sp, #480]
	ldur	q0, [x9, #72]
	str	q0, [sp, #496]
	ldr	x11, [x9, #88]
	str	x11, [sp, #512]
	ldr	x11, [sp, #480]
	cbz	x11, LBB14_135
; %bb.134:                              ; %bb7.i.i623.2
                                        ;   in Loop: Header=BB14_129 Depth=1
	sub	x11, x11, #1
	str	x11, [sp, #480]
	add	x11, x10, x11, lsl #5
	ldr	x11, [x11, #16]
	add	x22, x22, #1
	add	x24, x11, x24
LBB14_135:                              ; %bb6.i.i629.2
                                        ;   in Loop: Header=BB14_129 Depth=1
	ldr	q0, [x9]
	str	q0, [sp, #480]
	ldr	q0, [x9, #16]
	str	q0, [sp, #496]
	ldr	x11, [x9, #32]
	str	x11, [sp, #512]
	ldr	x11, [sp, #480]
	cbz	x11, LBB14_137
; %bb.136:                              ; %bb7.i.i623.3
                                        ;   in Loop: Header=BB14_129 Depth=1
	sub	x11, x11, #1
	str	x11, [sp, #480]
	add	x11, x10, x11, lsl #5
	ldr	x11, [x11, #16]
	add	x22, x22, #1
	add	x24, x11, x24
LBB14_137:                              ; %bb6.i.i629.3
                                        ;   in Loop: Header=BB14_129 Depth=1
	ldur	q0, [x9, #-56]
	str	q0, [sp, #480]
	ldur	q0, [x9, #-40]
	str	q0, [sp, #496]
	ldur	x11, [x9, #-24]
	str	x11, [sp, #512]
	ldr	x11, [sp, #480]
	cbz	x11, LBB14_139
; %bb.138:                              ; %bb7.i.i623.4
                                        ;   in Loop: Header=BB14_129 Depth=1
	sub	x11, x11, #1
	str	x11, [sp, #480]
	add	x11, x10, x11, lsl #5
	ldr	x11, [x11, #16]
	add	x22, x22, #1
	add	x24, x11, x24
LBB14_139:                              ; %bb6.i.i629.4
                                        ;   in Loop: Header=BB14_129 Depth=1
	ldur	q0, [x9, #-112]
	str	q0, [sp, #480]
	ldur	q0, [x9, #-96]
	str	q0, [sp, #496]
	ldur	x11, [x9, #-80]
	str	x11, [sp, #512]
	ldr	x11, [sp, #480]
	cbz	x11, LBB14_141
; %bb.140:                              ; %bb7.i.i623.5
                                        ;   in Loop: Header=BB14_129 Depth=1
	sub	x11, x11, #1
	str	x11, [sp, #480]
	add	x11, x10, x11, lsl #5
	ldr	x11, [x11, #16]
	add	x22, x22, #1
	add	x24, x11, x24
LBB14_141:                              ; %bb6.i.i629.5
                                        ;   in Loop: Header=BB14_129 Depth=1
	ldur	q0, [x9, #-168]
	str	q0, [sp, #480]
	ldur	q0, [x9, #-152]
	str	q0, [sp, #496]
	ldur	x11, [x9, #-136]
	str	x11, [sp, #512]
	ldr	x11, [sp, #480]
	cbz	x11, LBB14_143
; %bb.142:                              ; %bb7.i.i623.6
                                        ;   in Loop: Header=BB14_129 Depth=1
	sub	x11, x11, #1
	str	x11, [sp, #480]
	add	x11, x10, x11, lsl #5
	ldr	x11, [x11, #16]
	add	x22, x22, #1
	add	x24, x11, x24
LBB14_143:                              ; %bb6.i.i629.6
                                        ;   in Loop: Header=BB14_129 Depth=1
	ldur	q0, [x9, #-224]
	str	q0, [sp, #480]
	ldur	q0, [x9, #-208]
	str	q0, [sp, #496]
	ldur	x11, [x9, #-192]
	str	x11, [sp, #512]
	ldr	x11, [sp, #480]
	cbz	x11, LBB14_128
; %bb.144:                              ; %bb7.i.i623.7
                                        ;   in Loop: Header=BB14_129 Depth=1
	sub	x11, x11, #1
	str	x11, [sp, #480]
	add	x11, x10, x11, lsl #5
	ldr	x11, [x11, #16]
	add	x22, x22, #1
	add	x24, x11, x24
	b	LBB14_128
LBB14_145:
	mov	x10, x25
LBB14_146:                              ; %bb5.i.i724.prol.loopexit
	cmp	x25, #8
	b.hs	LBB14_151
LBB14_147:                              ; %bb4.i.i742.loopexit
	str	x8, [sp, #248]
LBB14_148:                              ; %bb4.i.i742
	cbz	x24, LBB14_150
; %bb.149:                              ; %slots.release.drop.6.i.i8.i744
	mov	x0, x21
	bl	_free
LBB14_150:                              ; %"wf_record_store_free$instance$07ca9210fae40158.exit"
	cmp	w19, #3
	cinc	x8, x23, ne
	cmp	x20, #0
	cinc	x8, x8, ne
	ldr	x9, [sp, #248]
	cmp	x9, #2
	cinc	x0, x8, ne
	add	sp, sp, #528
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB14_151:                              ; %bb5.lr.ph.i.i720.new
	mov	w11, #56                        ; =0x38
	madd	x11, x10, x11, x21
	sub	x11, x11, #224
	add	x12, sp, #480
	b	LBB14_153
LBB14_152:                              ; %bb6.i.i738.7
                                        ;   in Loop: Header=BB14_153 Depth=1
	sub	x11, x11, #448
	sub	x10, x10, #8
	cbz	x10, LBB14_147
LBB14_153:                              ; %bb5.i.i724
                                        ; =>This Inner Loop Header: Depth=1
	ldur	q0, [x11, #168]
	str	q0, [sp, #480]
	ldur	q0, [x11, #184]
	str	q0, [sp, #496]
	ldr	x13, [x11, #200]
	str	x13, [sp, #512]
	ldr	x13, [sp, #480]
	cbz	x13, LBB14_155
; %bb.154:                              ; %bb7.i.i732
                                        ;   in Loop: Header=BB14_153 Depth=1
	sub	x13, x13, #1
	str	x13, [sp, #480]
	add	x13, x12, x13, lsl #5
	ldr	x13, [x13, #16]
	add	x8, x8, #1
	add	x9, x13, x9
LBB14_155:                              ; %bb6.i.i738
                                        ;   in Loop: Header=BB14_153 Depth=1
	ldr	q0, [x11, #112]
	str	q0, [sp, #480]
	ldr	q0, [x11, #128]
	str	q0, [sp, #496]
	ldr	x13, [x11, #144]
	str	x13, [sp, #512]
	ldr	x13, [sp, #480]
	cbz	x13, LBB14_157
; %bb.156:                              ; %bb7.i.i732.1
                                        ;   in Loop: Header=BB14_153 Depth=1
	sub	x13, x13, #1
	str	x13, [sp, #480]
	add	x13, x12, x13, lsl #5
	ldr	x13, [x13, #16]
	add	x8, x8, #1
	add	x9, x13, x9
LBB14_157:                              ; %bb6.i.i738.1
                                        ;   in Loop: Header=BB14_153 Depth=1
	ldur	q0, [x11, #56]
	str	q0, [sp, #480]
	ldur	q0, [x11, #72]
	str	q0, [sp, #496]
	ldr	x13, [x11, #88]
	str	x13, [sp, #512]
	ldr	x13, [sp, #480]
	cbz	x13, LBB14_159
; %bb.158:                              ; %bb7.i.i732.2
                                        ;   in Loop: Header=BB14_153 Depth=1
	sub	x13, x13, #1
	str	x13, [sp, #480]
	add	x13, x12, x13, lsl #5
	ldr	x13, [x13, #16]
	add	x8, x8, #1
	add	x9, x13, x9
LBB14_159:                              ; %bb6.i.i738.2
                                        ;   in Loop: Header=BB14_153 Depth=1
	ldr	q0, [x11]
	str	q0, [sp, #480]
	ldr	q0, [x11, #16]
	str	q0, [sp, #496]
	ldr	x13, [x11, #32]
	str	x13, [sp, #512]
	ldr	x13, [sp, #480]
	cbz	x13, LBB14_161
; %bb.160:                              ; %bb7.i.i732.3
                                        ;   in Loop: Header=BB14_153 Depth=1
	sub	x13, x13, #1
	str	x13, [sp, #480]
	add	x13, x12, x13, lsl #5
	ldr	x13, [x13, #16]
	add	x8, x8, #1
	add	x9, x13, x9
LBB14_161:                              ; %bb6.i.i738.3
                                        ;   in Loop: Header=BB14_153 Depth=1
	ldur	q0, [x11, #-56]
	str	q0, [sp, #480]
	ldur	q0, [x11, #-40]
	str	q0, [sp, #496]
	ldur	x13, [x11, #-24]
	str	x13, [sp, #512]
	ldr	x13, [sp, #480]
	cbz	x13, LBB14_163
; %bb.162:                              ; %bb7.i.i732.4
                                        ;   in Loop: Header=BB14_153 Depth=1
	sub	x13, x13, #1
	str	x13, [sp, #480]
	add	x13, x12, x13, lsl #5
	ldr	x13, [x13, #16]
	add	x8, x8, #1
	add	x9, x13, x9
LBB14_163:                              ; %bb6.i.i738.4
                                        ;   in Loop: Header=BB14_153 Depth=1
	ldur	q0, [x11, #-112]
	str	q0, [sp, #480]
	ldur	q0, [x11, #-96]
	str	q0, [sp, #496]
	ldur	x13, [x11, #-80]
	str	x13, [sp, #512]
	ldr	x13, [sp, #480]
	cbz	x13, LBB14_165
; %bb.164:                              ; %bb7.i.i732.5
                                        ;   in Loop: Header=BB14_153 Depth=1
	sub	x13, x13, #1
	str	x13, [sp, #480]
	add	x13, x12, x13, lsl #5
	ldr	x13, [x13, #16]
	add	x8, x8, #1
	add	x9, x13, x9
LBB14_165:                              ; %bb6.i.i738.5
                                        ;   in Loop: Header=BB14_153 Depth=1
	ldur	q0, [x11, #-168]
	str	q0, [sp, #480]
	ldur	q0, [x11, #-152]
	str	q0, [sp, #496]
	ldur	x13, [x11, #-136]
	str	x13, [sp, #512]
	ldr	x13, [sp, #480]
	cbz	x13, LBB14_167
; %bb.166:                              ; %bb7.i.i732.6
                                        ;   in Loop: Header=BB14_153 Depth=1
	sub	x13, x13, #1
	str	x13, [sp, #480]
	add	x13, x12, x13, lsl #5
	ldr	x13, [x13, #16]
	add	x8, x8, #1
	add	x9, x13, x9
LBB14_167:                              ; %bb6.i.i738.6
                                        ;   in Loop: Header=BB14_153 Depth=1
	ldur	q0, [x11, #-224]
	str	q0, [sp, #480]
	ldur	q0, [x11, #-208]
	str	q0, [sp, #496]
	ldur	x13, [x11, #-192]
	str	x13, [sp, #512]
	ldr	x13, [sp, #480]
	cbz	x13, LBB14_152
; %bb.168:                              ; %bb7.i.i732.7
                                        ;   in Loop: Header=BB14_153 Depth=1
	sub	x13, x13, #1
	str	x13, [sp, #480]
	add	x13, x12, x13, lsl #5
	ldr	x13, [x13, #16]
	add	x8, x8, #1
	add	x9, x13, x9
	b	LBB14_152
LBB14_169:                              ; %bb8.i.i411
	sub	x14, x14, #1
	str	x14, [x13]
	add	x13, x13, x14, lsl #5
	ldr	x13, [x13, #16]
	cbnz	x11, LBB14_171
; %bb.170:                              ; %bb11.i.i417
	mov	w11, #56                        ; =0x38
	madd	x11, x10, x11, x12
	mov	w12, #1                         ; =0x1
	stp	x12, x9, [x11, #40]
	str	x10, [sp, #168]
	mov	x9, x10
LBB14_171:                              ; %bb29
	cmp	x13, #111
	cset	w11, ne
	b	LBB14_64
LBB14_172:                              ; %bb8.i.i532
	sub	x15, x15, #1
	str	x15, [x14]
	add	x14, x14, x15, lsl #5
	ldr	x14, [x14, #16]
	cbnz	x11, LBB14_174
; %bb.173:                              ; %bb11.i.i538
	mov	w11, #56                        ; =0x38
	madd	x11, x13, x11, x12
	mov	w12, #1                         ; =0x1
	stp	x12, x9, [x11, #40]
	str	x13, [sp, #168]
	mov	x9, x13
LBB14_174:                              ; %bb41
	cmp	x14, #222
	cset	w11, ne
	b	LBB14_77
LBB14_175:                              ; %bb8.i.i
	sub	x12, x12, #1
	str	x12, [x11]
	add	x11, x11, x12, lsl #5
	ldr	x11, [x11, #16]
	cbnz	x19, LBB14_177
; %bb.176:                              ; %bb11.i.i
	mov	w12, #56                        ; =0x38
	madd	x10, x20, x12, x10
	ldr	x12, [sp, #304]
	mov	w13, #1                         ; =0x1
	stp	x13, x12, [x10, #40]
	str	x20, [sp, #304]
LBB14_177:                              ; %bb2
	cmp	x11, #11
	cset	w10, ne
	b	LBB14_22
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpLdr	Lloh42, Lloh43
	.loh AdrpAdd	Lloh48, Lloh49
	.loh AdrpAdrp	Lloh46, Lloh48
	.loh AdrpLdr	Lloh46, Lloh47
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_indexed_placed              ; -- Begin function wf_indexed_placed
	.p2align	2
_wf_indexed_placed:                     ; @wf_indexed_placed
; %bb.0:                                ; %entry
	ldr	x8, [x1, #8]
	cmp	x8, #8
	b.hs	LBB15_2
; %bb.1:                                ; %bb2
	add	x8, x0, x8, lsl #3
	str	x2, [x8]
	ldr	x9, [x8, #64]
	add	x9, x9, #1
	str	x9, [x8, #64]
	mov	w0, #0                          ; =0x0
	ret
LBB15_2:                                ; %bb3
	ldr	x8, [x0, #128]
	add	x8, x8, #1
	str	x8, [x0, #128]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_indexed_heapify_reports
lCPI16_0:
	.quad	5                               ; 0x5
	.quad	1                               ; 0x1
lCPI16_1:
	.quad	4                               ; 0x4
	.quad	2                               ; 0x2
lCPI16_2:
	.quad	2                               ; 0x2
	.quad	4                               ; 0x4
lCPI16_3:
	.quad	1                               ; 0x1
	.quad	5                               ; 0x5
lCPI16_4:
	.quad	1000                            ; 0x3e8
	.quad	6                               ; 0x6
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_indexed_heapify_reports
	.p2align	2
_wf_indexed_heapify_reports:            ; @wf_indexed_heapify_reports
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #640
	.cfi_def_cfa_offset 736
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	w0, #224                        ; =0xe0
	bl	_malloc
	cbz	x0, LBB16_60
; %bb.1:                                ; %bb11.6
	add	x22, sp, #608
	add	x23, sp, #8
	mov	w8, #7                          ; =0x7
	stp	x8, x0, [sp, #368]
	add	x19, x23, #376
	stp	xzr, xzr, [sp, #8]
	mov	w9, #6                          ; =0x6
	stp	xzr, xzr, [sp, #40]
	stp	x9, xzr, [sp, #24]
	ldur	q0, [sp, #40]
	ldur	q1, [sp, #24]
	stp	q1, q0, [x0]
	mov	w10, #1                         ; =0x1
	str	x10, [sp, #8]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #16]
	str	xzr, [sp, #48]
Lloh50:
	adrp	x10, lCPI16_0@PAGE
Lloh51:
	ldr	q1, [x10, lCPI16_0@PAGEOFF]
	stur	q1, [sp, #24]
	ldur	q1, [sp, #8]
	ldur	q2, [sp, #24]
	mov	w10, #8                         ; =0x8
	dup.2d	v3, x10
	stur	q1, [sp, #40]
	stp	q2, q1, [x0, #32]
	mov	w10, #2                         ; =0x2
	str	x10, [sp, #8]
	stp	q0, q0, [sp, #16]
	str	xzr, [sp, #48]
Lloh52:
	adrp	x10, lCPI16_1@PAGE
Lloh53:
	ldr	q1, [x10, lCPI16_1@PAGEOFF]
	stur	q1, [sp, #24]
	ldur	q1, [sp, #8]
	ldur	q2, [sp, #24]
	stur	q1, [sp, #40]
	stp	q2, q1, [x0, #64]
	mov	w10, #3                         ; =0x3
	str	x10, [sp, #8]
	stp	q0, q0, [sp, #16]
	dup.2d	v1, x10
	str	xzr, [sp, #48]
	stur	q1, [sp, #24]
	ldur	q1, [sp, #8]
	ldur	q2, [sp, #24]
	stur	q1, [sp, #40]
	stp	q2, q1, [x0, #96]
	mov	w10, #4                         ; =0x4
	str	x10, [sp, #8]
	stp	q0, q0, [sp, #16]
	str	xzr, [sp, #48]
Lloh54:
	adrp	x10, lCPI16_2@PAGE
Lloh55:
	ldr	q1, [x10, lCPI16_2@PAGEOFF]
	stur	q1, [sp, #24]
	ldur	q1, [sp, #8]
	ldur	q2, [sp, #24]
	stur	q1, [sp, #40]
	stp	q2, q1, [x0, #128]
	mov	w10, #5                         ; =0x5
	str	x10, [sp, #8]
	stp	q0, q0, [sp, #16]
	str	xzr, [sp, #48]
Lloh56:
	adrp	x10, lCPI16_3@PAGE
Lloh57:
	ldr	q1, [x10, lCPI16_3@PAGEOFF]
	stur	q1, [sp, #24]
	ldur	q1, [sp, #8]
	ldur	q2, [sp, #24]
	stur	q1, [sp, #40]
	stp	q2, q1, [x0, #160]
	str	x9, [sp, #8]
	stp	q0, q0, [sp, #16]
	str	xzr, [sp, #48]
Lloh58:
	adrp	x9, lCPI16_4@PAGE
Lloh59:
	ldr	q1, [x9, lCPI16_4@PAGEOFF]
	stur	q1, [sp, #24]
	ldur	q1, [sp, #8]
	ldur	q2, [sp, #24]
	stp	q2, q1, [x0, #192]
	stur	q3, [sp, #56]
	stur	q3, [sp, #72]
	stur	q3, [sp, #88]
	stur	q3, [sp, #104]
	add	x24, x23, #440
	stur	q0, [sp, #168]
	stur	q0, [sp, #152]
	stur	q1, [sp, #40]
	stur	q0, [sp, #136]
	stur	q0, [sp, #120]
	ldur	q1, [sp, #56]
	ldur	q2, [sp, #72]
	ldur	q3, [sp, #88]
	ldur	q4, [sp, #104]
	stp	q3, q4, [x19, #32]
	stp	q1, q2, [x19]
	stp	q0, q0, [x24, #32]
	stp	q0, q0, [x24]
	str	xzr, [sp, #512]
	ldr	x9, [sp, #376]
	ldr	x25, [sp, #376]
	str	x8, [sp, #360]
	str	x9, [sp, #200]
	add	x8, sp, #105
	ldur	q0, [x8, #255]
	ldur	q1, [x8, #255]
	stur	q0, [sp, #184]
	str	q1, [x22]
	str	x25, [sp, #624]
	mov	x26, x25
	ldr	x20, [sp, #608]
	cbz	x20, LBB16_8
; %bb.2:                                ; %bb2.i.i.preheader
	mov	x8, #0                          ; =0x0
	mov	w9, #8                          ; =0x8
	b	LBB16_5
LBB16_3:                                ; %bb3.i.i.i
                                        ;   in Loop: Header=BB16_5 Depth=1
	ldr	x10, [sp, #512]
	add	x10, x10, #1
	str	x10, [sp, #512]
LBB16_4:                                ; %wf_indexed_placed.exit.i.i
                                        ;   in Loop: Header=BB16_5 Depth=1
	add	x8, x8, #1
	add	x9, x9, #32
	cmp	x20, x8
	b.eq	LBB16_7
LBB16_5:                                ; %bb2.i.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x10, [x26, x9]
	cmp	x10, #7
	b.hi	LBB16_3
; %bb.6:                                ; %bb2.i.i.i
                                        ;   in Loop: Header=BB16_5 Depth=1
	str	x8, [x19, x10, lsl #3]
	ldr	x11, [x24, x10, lsl #3]
	add	x11, x11, #1
	str	x11, [x24, x10, lsl #3]
	b	LBB16_4
LBB16_7:                                ; %bb4.i.i
	cmp	x20, #1
	b.ne	LBB16_49
LBB16_8:                                ; %bb12
	ldr	x8, [sp, #616]
	str	x8, [sp, #528]
	str	x26, [sp, #536]
	ldr	x8, [sp, #512]
	add	x8, x8, #1
	str	x20, [sp, #520]
	str	x8, [sp, #512]
	cbnz	x20, LBB16_53
LBB16_9:                                ; %bb18
	ldr	x8, [sp, #432]
	cmp	x8, #6
	b.eq	LBB16_11
; %bb.10:                               ; %bb30
	ldr	x8, [sp, #512]
	add	x8, x8, #1
	str	x8, [sp, #512]
LBB16_11:                               ; %bb29
	add	x8, x23, #536
	ldr	x9, [sp, #496]
	cmp	x9, #1
	b.eq	LBB16_13
; %bb.12:                               ; %bb33
	ldr	x10, [sp, #512]
	add	x10, x10, #1
	str	x10, [sp, #512]
LBB16_13:                               ; %bb32
	ldp	q0, q1, [x24]
	stp	q0, q1, [x8]
	ldp	q0, q1, [x24, #32]
	stp	q0, q1, [x8, #32]
	cbz	x20, LBB16_16
; %bb.14:                               ; %"wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$4dbd7ca4639a1dfc.exit"
	sub	x8, x20, #1
	add	x10, x25, x8, lsl #5
	str	x8, [sp, #520]
	ldp	q0, q1, [x10]
	stur	q1, [x23, #248]
	stur	q0, [x23, #232]
	ldr	x10, [sp, #248]
	cmp	x10, #6
	b.eq	LBB16_17
; %bb.15:                               ; %bb39
	ldr	x10, [sp, #512]
	add	x10, x10, #1
	str	x10, [sp, #512]
	b	LBB16_17
LBB16_16:
	mov	x8, #0                          ; =0x0
LBB16_17:                               ; %bb35
	ldr	x10, [sp, #512]
	ldr	x11, [sp, #448]
	ldr	x12, [sp, #544]
	cmp	x11, x12
	b.eq	LBB16_19
; %bb.18:                               ; %bb46
	add	x10, x10, #1
	str	x10, [sp, #512]
LBB16_19:                               ; %bb48
	ldr	x11, [sp, #456]
	ldr	x12, [sp, #552]
	cmp	x11, x12
	b.eq	LBB16_21
; %bb.20:                               ; %bb46.1
	add	x10, x10, #1
	str	x10, [sp, #512]
LBB16_21:                               ; %bb48.1
	ldr	x11, [sp, #464]
	ldr	x12, [sp, #560]
	cmp	x11, x12
	b.eq	LBB16_23
; %bb.22:                               ; %bb46.2
	add	x10, x10, #1
	str	x10, [sp, #512]
LBB16_23:                               ; %bb48.2
	ldr	x11, [sp, #472]
	ldr	x12, [sp, #568]
	cmp	x11, x12
	b.eq	LBB16_25
; %bb.24:                               ; %bb46.3
	add	x10, x10, #1
	str	x10, [sp, #512]
LBB16_25:                               ; %bb48.3
	ldr	x11, [sp, #480]
	ldr	x12, [sp, #576]
	cmp	x11, x12
	b.eq	LBB16_27
; %bb.26:                               ; %bb46.4
	add	x10, x10, #1
	str	x10, [sp, #512]
LBB16_27:                               ; %bb48.4
	ldr	x11, [sp, #488]
	ldr	x12, [sp, #584]
	cmp	x11, x12
	b.eq	LBB16_29
; %bb.28:                               ; %bb46.5
	add	x10, x10, #1
	str	x10, [sp, #512]
LBB16_29:                               ; %bb48.5
	ldr	x11, [sp, #592]
	cmp	x9, x11
	b.eq	LBB16_31
; %bb.30:                               ; %bb46.6
	add	x10, x10, #1
	str	x10, [sp, #512]
LBB16_31:                               ; %bb48.6
	ldr	x9, [sp, #504]
	ldr	x11, [sp, #600]
	cmp	x9, x11
	b.eq	LBB16_33
; %bb.32:                               ; %bb46.7
	add	x9, x10, #1
	str	x9, [sp, #512]
LBB16_33:                               ; %bb48.7
	add	x20, x23, #512
	cbz	x8, LBB16_46
; %bb.34:                               ; %bb53.lr.ph
	ldr	x9, [sp, #536]
	subs	x2, x8, #1
	str	x2, [sp, #520]
	b.eq	LBB16_46
; %bb.35:
	add	x21, x23, #264
	add	x23, x23, #296
	b	LBB16_37
LBB16_36:                               ; %bb53.loopexit
                                        ;   in Loop: Header=BB16_37 Depth=1
	ldr	x9, [sp, #536]
	subs	x2, x8, #1
	str	x2, [sp, #520]
	b.eq	LBB16_46
LBB16_37:                               ; %bb2.i45
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB16_44 Depth 2
	add	x8, x9, x2, lsl #5
	ldp	q0, q1, [x9]
	stp	q0, q1, [x22]
	ldp	q0, q1, [x8]
	stp	q0, q1, [x9]
	ldr	x8, [x9, #8]
	cmp	x8, #7
	b.hi	LBB16_39
; %bb.38:                               ; %bb2.i.i56
                                        ;   in Loop: Header=BB16_37 Depth=1
	str	xzr, [x19, x8, lsl #3]
	ldr	x9, [x24, x8, lsl #3]
	add	x9, x9, #1
	str	x9, [x24, x8, lsl #3]
	b	LBB16_40
LBB16_39:                               ; %bb3.i.i50
                                        ;   in Loop: Header=BB16_37 Depth=1
	ldr	x8, [sp, #512]
	add	x8, x8, #1
	str	x8, [sp, #512]
LBB16_40:                               ; %"wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$4dbd7ca4639a1dfc.exit62"
                                        ;   in Loop: Header=BB16_37 Depth=1
	mov	x0, x20
	mov	x1, #0                          ; =0x0
	mov	x4, x19
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$4dbd7ca4639a1dfc
	ldr	x8, [sp, #520]
	ldp	q0, q1, [x22]
	stp	q0, q1, [x21]
	cbz	x8, LBB16_46
; %bb.41:                               ; %bb55.lr.ph
                                        ;   in Loop: Header=BB16_37 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	x10, [sp, #512]
	ldr	x11, [sp, #536]
	b	LBB16_44
LBB16_42:                               ; %bb64.sink.split
                                        ;   in Loop: Header=BB16_44 Depth=2
	add	x10, x10, #1
	str	x10, [sp, #512]
LBB16_43:                               ; %bb64
                                        ;   in Loop: Header=BB16_44 Depth=2
	add	x9, x9, #1
	add	x11, x11, #32
	cmp	x8, x9
	b.eq	LBB16_36
LBB16_44:                               ; %bb55
                                        ;   Parent Loop BB16_37 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q0, q1, [x11]
	stp	q0, q1, [x23]
	ldr	x12, [sp, #312]
	cmp	x12, #7
	b.hi	LBB16_42
; %bb.45:                               ; %bb59
                                        ;   in Loop: Header=BB16_44 Depth=2
	ldr	x12, [x19, x12, lsl #3]
	cmp	x9, x12
	b.ne	LBB16_42
	b	LBB16_43
LBB16_46:                               ; %bb52
	add	x8, sp, #8
	add	x8, x8, #328
	ldr	q0, [x20]
	str	q0, [x8]
	ldr	x8, [x20, #16]
	str	x8, [sp, #352]
	ldr	x8, [sp, #344]
	cbz	x8, LBB16_48
; %bb.47:                               ; %slots.release.drop.6.i.i
	ldr	x0, [sp, #352]
	bl	_free
LBB16_48:                               ; %"wf_collections.priority_queue.priority_queue_free$instance$7bb859331c1381db.exit"
	ldr	x0, [sp, #512]
	add	sp, sp, #640
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB16_49:                               ; %bb7.i.i.preheader
	lsr	x8, x20, #1
	sub	x21, x8, #1
LBB16_50:                               ; %bb7.i.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x0, sp, #608
	mov	x1, x21
	mov	x2, x20
	mov	x4, x19
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$4dbd7ca4639a1dfc
	sub	x21, x21, #1
	cmn	x21, #1
	b.ne	LBB16_50
; %bb.51:                               ; %"wf_collections.priority_queue.priority_queue_heapify_indexed$instance$4dbd7ca4639a1dfc.exit"
	ldr	x8, [sp, #616]
	str	x20, [sp, #520]
	str	x8, [sp, #528]
	str	x26, [sp, #536]
	cmp	x20, #7
	b.eq	LBB16_53
; %bb.52:                               ; %bb12.thread109
	ldr	x8, [sp, #512]
	add	x8, x8, #1
	str	x8, [sp, #512]
LBB16_53:                               ; %bb16.lr.ph
	mov	x8, #0                          ; =0x0
	ldr	x9, [sp, #512]
	b	LBB16_56
LBB16_54:                               ; %bb28.sink.split
                                        ;   in Loop: Header=BB16_56 Depth=1
	add	x9, x9, #1
	str	x9, [sp, #512]
LBB16_55:                               ; %bb28
                                        ;   in Loop: Header=BB16_56 Depth=1
	add	x8, x8, #1
	add	x26, x26, #32
	cmp	x20, x8
	b.eq	LBB16_9
LBB16_56:                               ; %bb16
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q0, q1, [x26]
	stur	q1, [x23, #216]
	stur	q0, [x23, #200]
	ldr	x10, [sp, #216]
	cmp	x10, #8
	b.hs	LBB16_54
; %bb.57:                               ; %bb20
                                        ;   in Loop: Header=BB16_56 Depth=1
	ldr	x11, [x19, x10, lsl #3]
	cmp	x8, x11
	b.eq	LBB16_59
; %bb.58:                               ; %bb23
                                        ;   in Loop: Header=BB16_56 Depth=1
	add	x9, x9, #1
	str	x9, [sp, #512]
LBB16_59:                               ; %bb22
                                        ;   in Loop: Header=BB16_56 Depth=1
	ldr	x10, [x24, x10, lsl #3]
	cbnz	x10, LBB16_55
	b	LBB16_54
LBB16_60:                               ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh58, Lloh59
	.loh AdrpLdr	Lloh56, Lloh57
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpLdr	Lloh52, Lloh53
	.loh AdrpLdr	Lloh50, Lloh51
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_indexed_rise_placed         ; -- Begin function wf_indexed_rise_placed
	.p2align	2
_wf_indexed_rise_placed:                ; @wf_indexed_rise_placed
; %bb.0:                                ; %entry
	ldr	x8, [x0, #40]
	cmp	x8, #5
	b.hs	LBB17_2
; %bb.1:                                ; %bb2
	ldr	x9, [x1, #8]
	add	x9, x2, x9, lsl #4
	str	x9, [x0, x8, lsl #3]
	b	LBB17_3
LBB17_2:                                ; %bb3
	ldr	x9, [x0, #48]
	add	x9, x9, #1
	str	x9, [x0, #48]
LBB17_3:                                ; %bb1
	add	x8, x8, #1
	str	x8, [x0, #40]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_indexed_always_rise         ; -- Begin function wf_indexed_always_rise
	.p2align	2
_wf_indexed_always_rise:                ; @wf_indexed_always_rise
; %bb.0:                                ; %entry
	mov	w0, #1                          ; =0x1
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_indexed_repair_rise
lCPI19_0:
	.quad	30                              ; 0x1e
	.quad	1                               ; 0x1
lCPI19_1:
	.quad	40                              ; 0x28
	.quad	2                               ; 0x2
lCPI19_2:
	.quad	50                              ; 0x32
	.quad	3                               ; 0x3
lCPI19_3:
	.quad	60                              ; 0x3c
	.quad	4                               ; 0x4
lCPI19_4:
	.quad	70                              ; 0x46
	.quad	5                               ; 0x5
lCPI19_5:
	.quad	80                              ; 0x50
	.quad	6                               ; 0x6
lCPI19_6:
	.quad	68                              ; 0x44
	.quad	65                              ; 0x41
lCPI19_7:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI19_8:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI19_9:
	.quad	1                               ; 0x1
	.quad	5                               ; 0x5
lCPI19_10:
	.quad	25                              ; 0x19
	.quad	4                               ; 0x4
lCPI19_11:
	.quad	102                             ; 0x66
	.quad	98                              ; 0x62
lCPI19_12:
	.quad	96                              ; 0x60
	.quad	2                               ; 0x2
lCPI19_13:
	.quad	6                               ; 0x6
	.quad	1                               ; 0x1
lCPI19_14:
	.quad	1                               ; 0x1
	.quad	6                               ; 0x6
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_indexed_repair_rise
	.p2align	2
_wf_indexed_repair_rise:                ; @wf_indexed_repair_rise
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #752
	.cfi_def_cfa_offset 848
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x20, x1
	mov	x21, x0
	mov	w0, #224                        ; =0xe0
	bl	_malloc
	cbz	x0, LBB19_62
; %bb.1:                                ; %bb8.6
	add	x25, sp, #720
	add	x24, sp, #8
	mov	w9, #7                          ; =0x7
	stp	x9, x0, [sp, #392]
	add	x22, x24, #400
	add	x26, x24, #616
	add	x8, x24, #376
	stp	xzr, xzr, [sp, #8]
	mov	w10, #20                        ; =0x14
	stp	xzr, xzr, [sp, #40]
	stp	x10, xzr, [sp, #24]
	ldur	q0, [sp, #40]
	ldur	q1, [sp, #24]
	stp	q1, q0, [x0]
	mov	w10, #1                         ; =0x1
	str	x10, [sp, #8]
	movi.2d	v4, #0000000000000000
	stp	q4, q4, [sp, #16]
	str	xzr, [sp, #48]
Lloh60:
	adrp	x10, lCPI19_0@PAGE
Lloh61:
	ldr	q0, [x10, lCPI19_0@PAGEOFF]
	stur	q0, [sp, #24]
	ldur	q1, [sp, #8]
	ldur	q2, [sp, #24]
	mov	w10, #8                         ; =0x8
	dup.2d	v0, x10
	stur	q1, [sp, #40]
	stp	q2, q1, [x0, #32]
	mov	w10, #2                         ; =0x2
	str	x10, [sp, #8]
	stp	q4, q4, [sp, #16]
	str	xzr, [sp, #48]
Lloh62:
	adrp	x10, lCPI19_1@PAGE
Lloh63:
	ldr	q1, [x10, lCPI19_1@PAGEOFF]
	stur	q1, [sp, #24]
	ldur	q1, [sp, #8]
	ldur	q2, [sp, #24]
	stur	q1, [sp, #40]
	stp	q2, q1, [x0, #64]
	mov	w10, #3                         ; =0x3
	str	x10, [sp, #8]
	stp	q4, q4, [sp, #16]
	str	xzr, [sp, #48]
Lloh64:
	adrp	x10, lCPI19_2@PAGE
Lloh65:
	ldr	q1, [x10, lCPI19_2@PAGEOFF]
	stur	q1, [sp, #24]
	ldur	q1, [sp, #8]
	ldur	q2, [sp, #24]
	stur	q1, [sp, #40]
	stp	q2, q1, [x0, #96]
	mov	w10, #4                         ; =0x4
	str	x10, [sp, #8]
	stp	q4, q4, [sp, #16]
	str	xzr, [sp, #48]
Lloh66:
	adrp	x10, lCPI19_3@PAGE
Lloh67:
	ldr	q1, [x10, lCPI19_3@PAGEOFF]
	stur	q1, [sp, #24]
	ldur	q1, [sp, #8]
	ldur	q2, [sp, #24]
	stur	q1, [sp, #40]
	stp	q2, q1, [x0, #128]
	mov	w10, #5                         ; =0x5
	str	x10, [sp, #8]
	stp	q4, q4, [sp, #16]
	str	xzr, [sp, #48]
Lloh68:
	adrp	x10, lCPI19_4@PAGE
Lloh69:
	ldr	q1, [x10, lCPI19_4@PAGEOFF]
	stur	q1, [sp, #24]
	ldur	q1, [sp, #8]
	ldur	q2, [sp, #24]
	stur	q1, [sp, #40]
	stp	q2, q1, [x0, #160]
	mov	w10, #6                         ; =0x6
	str	x10, [sp, #8]
	stp	q4, q4, [sp, #16]
	str	xzr, [sp, #48]
Lloh70:
	adrp	x10, lCPI19_5@PAGE
Lloh71:
	ldr	q1, [x10, lCPI19_5@PAGEOFF]
	stur	q1, [sp, #24]
	ldur	q1, [sp, #8]
	ldur	q2, [sp, #24]
	stp	q2, q1, [x0, #192]
	ldr	x10, [sp, #400]
	ldr	x27, [sp, #400]
	str	x9, [sp, #384]
	stur	q0, [sp, #56]
	stur	q0, [sp, #72]
	stur	q0, [sp, #88]
	stur	q0, [sp, #104]
	stur	q4, [sp, #168]
	stur	q4, [sp, #152]
	stur	q1, [sp, #40]
	stur	q4, [sp, #136]
	stur	q4, [sp, #120]
	ldur	q0, [sp, #56]
	ldur	q1, [sp, #72]
	ldur	q2, [sp, #88]
	ldur	q3, [sp, #104]
	stp	q2, q3, [x22, #32]
	stp	q0, q1, [x22]
	str	xzr, [sp, #536]
	add	x9, sp, #265
	stur	q4, [x9, #255]
	add	x9, sp, #249
	stur	q4, [x9, #255]
	add	x9, sp, #233
	stur	q4, [x9, #255]
	add	x9, sp, #217
	stur	q4, [x9, #255]
	ldr	q0, [x8]
	str	x10, [sp, #200]
	stur	q0, [sp, #184]
	ldr	q0, [x8]
	str	q0, [x25]
	str	x27, [sp, #736]
	ldr	x19, [sp, #720]
	cbz	x19, LBB19_10
; %bb.2:                                ; %bb2.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x24, #464
	add	x10, x27, #8
	b	LBB19_5
LBB19_3:                                ; %bb3.i.i.i
                                        ;   in Loop: Header=BB19_5 Depth=1
	ldr	x11, [sp, #536]
	add	x11, x11, #1
	str	x11, [sp, #536]
LBB19_4:                                ; %wf_indexed_placed.exit.i.i
                                        ;   in Loop: Header=BB19_5 Depth=1
	add	x8, x8, #1
	cmp	x19, x8
	b.eq	LBB19_7
LBB19_5:                                ; %bb2.i.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x10], #32
	cmp	x11, #7
	b.hi	LBB19_3
; %bb.6:                                ; %bb2.i.i.i
                                        ;   in Loop: Header=BB19_5 Depth=1
	str	x8, [x22, x11, lsl #3]
	ldr	x12, [x9, x11, lsl #3]
	add	x12, x12, #1
	str	x12, [x9, x11, lsl #3]
	b	LBB19_4
LBB19_7:                                ; %bb4.i.i
	cmp	x19, #1
	b.eq	LBB19_10
; %bb.8:                                ; %bb7.i.i.preheader
	lsr	x8, x19, #1
	sub	x23, x8, #1
LBB19_9:                                ; %bb7.i.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x0, sp, #720
	mov	x1, x23
	mov	x2, x19
	mov	x4, x22
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$4dbd7ca4639a1dfc
	sub	x23, x23, #1
	cmn	x23, #1
	b.ne	LBB19_9
LBB19_10:                               ; %"wf_collections.priority_queue.priority_queue_heapify_indexed$instance$4dbd7ca4639a1dfc.exit"
	ldr	x8, [sp, #728]
	str	x19, [sp, #544]
	str	x8, [sp, #552]
	str	x27, [sp, #560]
	movi.2d	v0, #0000000000000000
	stur	q0, [x24, #200]
	stur	q0, [x24, #216]
	stur	xzr, [x24, #232]
	stp	q0, q0, [x24, #624]
	stp	q0, q0, [x24, #560]
	stp	q0, q0, [x24, #592]
Lloh72:
	adrp	x8, lCPI19_6@PAGE
Lloh73:
	ldr	q0, [x8, lCPI19_6@PAGEOFF]
	str	q0, [x26]
	mov	w8, #20                         ; =0x14
	str	x8, [sp, #640]
Lloh74:
	adrp	x8, lCPI19_7@PAGE
Lloh75:
	ldr	q0, [x8, lCPI19_7@PAGEOFF]
	mov	w8, #6                          ; =0x6
	str	x8, [sp, #712]
Lloh76:
	adrp	x8, lCPI19_8@PAGE
Lloh77:
	ldr	q1, [x8, lCPI19_8@PAGEOFF]
	add	x8, sp, #425
	stur	q0, [x8, #255]
	add	x8, sp, #409
	stur	q1, [x8, #255]
Lloh78:
	adrp	x8, lCPI19_9@PAGE
Lloh79:
	ldr	q0, [x8, lCPI19_9@PAGEOFF]
	add	x8, sp, #441
	stur	q0, [x8, #255]
	tbz	w21, #0, LBB19_12
; %bb.11:                               ; %bb15
Lloh80:
	adrp	x8, lCPI19_11@PAGE
Lloh81:
	ldr	q0, [x8, lCPI19_11@PAGEOFF]
	str	q0, [x26]
	mov	w8, #38                         ; =0x26
	str	x8, [sp, #640]
Lloh82:
	adrp	x8, lCPI19_12@PAGE
Lloh83:
	ldr	q0, [x8, lCPI19_12@PAGEOFF]
Lloh84:
	adrp	x8, lCPI19_13@PAGE
Lloh85:
	ldr	q1, [x8, lCPI19_13@PAGEOFF]
	add	x8, sp, #393
	stur	q0, [x8, #255]
	add	x8, sp, #409
	stur	q1, [x8, #255]
	mov	w8, #4                          ; =0x4
	str	x8, [sp, #696]
	mov	w8, #2                          ; =0x2
	str	x8, [sp, #712]
Lloh86:
	adrp	x8, lCPI19_14@PAGE
Lloh87:
	ldr	q0, [x8, lCPI19_14@PAGEOFF]
	mov	w23, #5                         ; =0x5
	mov	w22, #6                         ; =0x6
	str	xzr, [sp, #680]
	b	LBB19_13
LBB19_12:
Lloh88:
	adrp	x8, lCPI19_10@PAGE
Lloh89:
	ldr	q0, [x8, lCPI19_10@PAGEOFF]
	mov	w23, #3                         ; =0x3
	mov	w22, #4                         ; =0x4
LBB19_13:                               ; %bb14
	mov	w8, #1                          ; =0x1
	cmp	x19, #7
	b.eq	LBB19_15
; %bb.14:                               ; %bb18
	str	x8, [sp, #616]
	mov	w8, #2                          ; =0x2
LBB19_15:                               ; %bb17
	add	x21, x24, #536
	cmp	x22, x19
	b.hs	LBB19_21
; %bb.16:                               ; %bb21
	add	x8, sp, #8
	add	x8, x8, #248
	str	x22, [sp, #248]
	movi.2d	v1, #0000000000000000
	str	q1, [x8, #16]
	add	x8, sp, #1
	stur	q1, [x8, #255]
	str	xzr, [sp, #288]
	ldur	q1, [x24, #240]
	add	x8, sp, #9
	stur	q0, [x8, #255]
	add	x8, sp, #25
	stur	q1, [x8, #255]
	add	x8, x27, x22, lsl #5
	tbz	w20, #0, LBB19_18
; %bb.17:                               ; %"wf_collections.priority_queue.priority_queue_replace_at_indexed$instance$69744d0f61ea6fbe.exit"
	ldp	q0, q1, [x8]
	stp	q0, q1, [x25]
	ldp	q1, q0, [x24, #256]
	stp	q1, q0, [x8]
	ldr	x8, [x8, #8]
	orr	x8, x22, x8, lsl #4
	str	x8, [sp, #568]
	mov	w8, #1                          ; =0x1
	str	x8, [sp, #608]
	add	x4, x24, #560
	mov	x0, x21
	mov	x1, x22
	mov	x2, x19
	bl	_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$69744d0f61ea6fbe
	b	LBB19_19
LBB19_18:                               ; %"wf_collections.priority_queue.priority_queue_replace_at_indexed$instance$b789e18464d776a7.exit"
	ldp	q0, q1, [x8]
	stp	q0, q1, [x25]
	ldp	q1, q0, [x24, #256]
	stp	q1, q0, [x8]
	ldr	x8, [x8, #8]
	orr	x8, x22, x8, lsl #4
	str	x8, [sp, #568]
	mov	w8, #1                          ; =0x1
	str	x8, [sp, #608]
	add	x4, x24, #560
	mov	x0, x21
	mov	x1, x22
	mov	x2, x19
	mov	x3, x21
	bl	_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$b789e18464d776a7
LBB19_19:                               ; %bb23
	ldp	q0, q1, [x25]
	stp	q0, q1, [x24, #288]
	ldr	x8, [sp, #304]
	cmp	x8, x22
	b.eq	LBB19_22
; %bb.20:                               ; %bb27
	ldr	x8, [sp, #616]
	add	x8, x8, #1
LBB19_21:                               ; %bb20.sink.split
	str	x8, [sp, #616]
LBB19_22:                               ; %bb20
	ldr	x8, [sp, #608]
	ldr	x20, [sp, #616]
	cmp	x8, x23
	b.eq	LBB19_24
; %bb.23:                               ; %bb30
	add	x20, x20, #1
	str	x20, [sp, #616]
LBB19_24:                               ; %bb29
	ldr	x8, [sp, #568]
	ldr	x9, [sp, #624]
	cmp	x8, x9
	b.eq	LBB19_26
; %bb.25:                               ; %bb37
	add	x20, x20, #1
	str	x20, [sp, #616]
LBB19_26:                               ; %bb39
	ldr	x8, [sp, #576]
	ldr	x9, [sp, #632]
	cmp	x8, x9
	b.eq	LBB19_28
; %bb.27:                               ; %bb37.1
	add	x20, x20, #1
	str	x20, [sp, #616]
LBB19_28:                               ; %bb39.1
	ldr	x8, [sp, #584]
	ldr	x9, [sp, #640]
	cmp	x8, x9
	b.eq	LBB19_30
; %bb.29:                               ; %bb37.2
	add	x20, x20, #1
	str	x20, [sp, #616]
LBB19_30:                               ; %bb39.2
	ldr	x8, [sp, #592]
	ldr	x9, [sp, #648]
	cmp	x8, x9
	b.eq	LBB19_32
; %bb.31:                               ; %bb37.3
	add	x20, x20, #1
	str	x20, [sp, #616]
LBB19_32:                               ; %bb39.3
	ldr	x8, [sp, #600]
	ldr	x9, [sp, #656]
	cmp	x8, x9
	b.eq	LBB19_34
; %bb.33:                               ; %bb37.4
	add	x20, x20, #1
	str	x20, [sp, #616]
LBB19_34:                               ; %bb39.4
	cbz	x19, LBB19_59
; %bb.35:                               ; %bb41.lr.ph
	ldr	x8, [sp, #560]
	ldp	q1, q0, [x8]
	stp	q1, q0, [x24, #320]
	ldr	x9, [sp, #336]
	ldr	x10, [sp, #664]
	cmp	x9, x10
	b.eq	LBB19_37
; %bb.36:                               ; %bb50.sink.split.peel
	add	x20, x20, #1
	str	x20, [sp, #616]
LBB19_37:                               ; %bb50.peel
	cmp	x19, #1
	b.eq	LBB19_59
; %bb.38:                               ; %bb41.peel129
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x24, #320]
	ldr	x9, [sp, #336]
	ldr	x10, [sp, #672]
	cmp	x9, x10
	b.eq	LBB19_40
; %bb.39:                               ; %bb50.sink.split.peel138
	add	x20, x20, #1
	str	x20, [sp, #616]
LBB19_40:                               ; %bb50.peel140
	cmp	x19, #2
	b.eq	LBB19_59
; %bb.41:                               ; %bb41.peel145
	ldp	q0, q1, [x8, #64]
	stp	q0, q1, [x24, #320]
	ldr	x9, [sp, #336]
	ldr	x10, [sp, #680]
	cmp	x9, x10
	b.eq	LBB19_43
; %bb.42:                               ; %bb50.sink.split.peel154
	add	x20, x20, #1
	str	x20, [sp, #616]
LBB19_43:                               ; %bb50.peel156
	cmp	x19, #3
	b.eq	LBB19_59
; %bb.44:                               ; %bb41.peel161
	ldp	q0, q1, [x8, #96]
	stp	q0, q1, [x24, #320]
	ldr	x9, [sp, #336]
	ldr	x10, [sp, #688]
	cmp	x9, x10
	b.eq	LBB19_46
; %bb.45:                               ; %bb50.sink.split.peel170
	add	x20, x20, #1
	str	x20, [sp, #616]
LBB19_46:                               ; %bb50.peel172
	cmp	x19, #4
	b.eq	LBB19_59
; %bb.47:                               ; %bb41.peel177
	ldp	q0, q1, [x8, #128]
	stp	q0, q1, [x24, #320]
	ldr	x9, [sp, #336]
	ldr	x10, [sp, #696]
	cmp	x9, x10
	b.eq	LBB19_49
; %bb.48:                               ; %bb50.sink.split.peel186
	add	x20, x20, #1
	str	x20, [sp, #616]
LBB19_49:                               ; %bb50.peel188
	cmp	x19, #5
	b.eq	LBB19_59
; %bb.50:                               ; %bb41.peel193
	ldp	q0, q1, [x8, #160]
	stp	q0, q1, [x24, #320]
	ldr	x9, [sp, #336]
	ldr	x10, [sp, #704]
	cmp	x9, x10
	b.eq	LBB19_52
; %bb.51:                               ; %bb50.sink.split.peel202
	add	x20, x20, #1
	str	x20, [sp, #616]
LBB19_52:                               ; %bb50.peel204
	cmp	x19, #6
	b.eq	LBB19_59
; %bb.53:                               ; %bb41.peel209
	ldp	q0, q1, [x8, #192]
	stp	q0, q1, [x24, #320]
	ldr	x9, [sp, #336]
	ldr	x10, [sp, #712]
	cmp	x9, x10
	b.eq	LBB19_55
; %bb.54:                               ; %bb50.sink.split.peel218
	add	x20, x20, #1
	str	x20, [sp, #616]
LBB19_55:                               ; %bb50.peel220
	cmp	x19, #7
	b.eq	LBB19_59
; %bb.56:                               ; %bb41.preheader
	add	x9, x8, #224
	mov	w8, #7                          ; =0x7
LBB19_57:                               ; %bb41
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q0, q1, [x9], #32
	stp	q0, q1, [x24, #320]
	add	x10, x20, x8
	sub	x10, x10, #6
	str	x10, [sp, #616]
	add	x8, x8, #1
	cmp	x19, x8
	b.ne	LBB19_57
; %bb.58:                               ; %bb43.loopexit
	add	x8, x20, x8
	sub	x20, x8, #7
LBB19_59:                               ; %bb43
	ldr	q0, [x21]
	add	x8, sp, #105
	stur	q0, [x8, #255]
	ldr	x8, [x21, #16]
	str	x8, [sp, #376]
	ldr	x8, [sp, #368]
	cbz	x8, LBB19_61
; %bb.60:                               ; %slots.release.drop.6.i.i
	ldr	x0, [sp, #376]
	bl	_free
LBB19_61:                               ; %"wf_collections.priority_queue.priority_queue_free$instance$7bb859331c1381db.exit"
	mov	x0, x20
	add	sp, sp, #752
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB19_62:                               ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh70, Lloh71
	.loh AdrpLdr	Lloh68, Lloh69
	.loh AdrpLdr	Lloh66, Lloh67
	.loh AdrpLdr	Lloh64, Lloh65
	.loh AdrpLdr	Lloh62, Lloh63
	.loh AdrpLdr	Lloh60, Lloh61
	.loh AdrpLdr	Lloh78, Lloh79
	.loh AdrpLdr	Lloh76, Lloh77
	.loh AdrpLdr	Lloh74, Lloh75
	.loh AdrpLdr	Lloh72, Lloh73
	.loh AdrpLdr	Lloh86, Lloh87
	.loh AdrpLdr	Lloh84, Lloh85
	.loh AdrpAdrp	Lloh82, Lloh84
	.loh AdrpLdr	Lloh82, Lloh83
	.loh AdrpLdr	Lloh80, Lloh81
	.loh AdrpLdr	Lloh88, Lloh89
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_indexed_edit_owner
lCPI20_0:
	.quad	41                              ; 0x29
	.quad	142                             ; 0x8e
lCPI20_1:
	.quad	52                              ; 0x34
	.quad	63                              ; 0x3f
lCPI20_2:
	.quad	74                              ; 0x4a
	.quad	85                              ; 0x55
lCPI20_3:
	.quad	96                              ; 0x60
	.quad	107                             ; 0x6b
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_indexed_edit_owner
	.p2align	2
_wf_indexed_edit_owner:                 ; @wf_indexed_edit_owner
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x2
	mov	x19, x0
	ldr	x8, [x1]
	add	x8, x8, #1
	str	x8, [x1]
	mov	w0, #16                         ; =0x10
	bl	_malloc
	cbz	x0, LBB20_2
; %bb.1:                                ; %wf_indexed_wide.exit
Lloh90:
	adrp	x8, lCPI20_0@PAGE
Lloh91:
	ldr	q0, [x8, lCPI20_0@PAGEOFF]
	str	q0, [x0]
	ldr	x8, [x20]
	ldr	x9, [x20, #56]
	str	x0, [x20]
	mov	w10, #118                       ; =0x76
	str	x10, [x20, #56]
	str	x8, [x19]
	ldur	q0, [x20, #8]
Lloh92:
	adrp	x8, lCPI20_1@PAGE
Lloh93:
	ldr	q1, [x8, lCPI20_1@PAGEOFF]
	stur	q1, [x20, #8]
	stur	q0, [x19, #8]
	ldur	q0, [x20, #24]
Lloh94:
	adrp	x8, lCPI20_2@PAGE
Lloh95:
	ldr	q1, [x8, lCPI20_2@PAGEOFF]
	stur	q1, [x20, #24]
	stur	q0, [x19, #24]
	ldur	q0, [x20, #40]
Lloh96:
	adrp	x8, lCPI20_3@PAGE
Lloh97:
	ldr	q1, [x8, lCPI20_3@PAGEOFF]
	stur	q1, [x20, #40]
	stur	q0, [x19, #40]
	str	x9, [x19, #56]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB20_2:                                ; %box.new.oom.v1.i.i.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh96, Lloh97
	.loh AdrpAdrp	Lloh94, Lloh96
	.loh AdrpLdr	Lloh94, Lloh95
	.loh AdrpAdrp	Lloh92, Lloh94
	.loh AdrpLdr	Lloh92, Lloh93
	.loh AdrpLdr	Lloh90, Lloh91
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_indexed_edit_consume
lCPI21_0:
	.quad	22                              ; 0x16
	.quad	33                              ; 0x21
lCPI21_1:
	.quad	44                              ; 0x2c
	.quad	55                              ; 0x37
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_indexed_edit_consume
	.p2align	2
_wf_indexed_edit_consume:               ; @wf_indexed_edit_consume
; %bb.0:                                ; %entry
	mov	x8, x0
	ldp	x0, x10, [x1]
	ldp	x9, x11, [x0]
	add	x12, x9, #101
	cmp	x11, x12
	csinv	x9, x9, xzr, eq
	add	x11, x9, #11
	cmp	x10, x11
	b.ne	LBB21_3
; %bb.1:                                ; %bb3.i
	dup.2d	v0, x9
Lloh98:
	adrp	x10, lCPI21_0@PAGE
Lloh99:
	ldr	q1, [x10, lCPI21_0@PAGEOFF]
	add.2d	v1, v0, v1
Lloh100:
	adrp	x10, lCPI21_1@PAGE
Lloh101:
	ldr	q2, [x10, lCPI21_1@PAGEOFF]
	add.2d	v0, v0, v2
	ldp	q2, q3, [x1, #16]
	cmeq.2d	v0, v3, v0
	cmeq.2d	v1, v2, v1
	uzp1.4s	v0, v1, v0
	xtn.4h	v0, v0
	uminv.4h	h0, v0
	fmov	w11, s0
	mov	x10, #-1                        ; =0xffffffffffffffff
	tbz	w11, #0, LBB21_4
; %bb.2:                                ; %bb3.i
	add	x11, x9, #77
	ldp	x13, x12, [x1, #48]
	add	x14, x9, #66
	cmp	x12, x11
	csinv	x9, x9, xzr, eq
	cmp	x13, x14
	csel	x10, x10, x9, ne
	b	LBB21_4
LBB21_3:
	mov	x10, #-1                        ; =0xffffffffffffffff
LBB21_4:                                ; %wf_indexed_wide_read.exit
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	q0, [x8]
	mov	w9, #1                          ; =0x1
	dup.2d	v1, x9
	mov.d	v1[1], x10
	add.2d	v0, v0, v1
	str	q0, [x8]
	bl	_free
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh100, Lloh101
	.loh AdrpAdrp	Lloh98, Lloh100
	.loh AdrpLdr	Lloh98, Lloh99
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_indexed_edit_result
lCPI22_0:
	.quad	40                              ; 0x28
	.quad	141                             ; 0x8d
lCPI22_1:
	.quad	51                              ; 0x33
	.quad	62                              ; 0x3e
lCPI22_2:
	.quad	73                              ; 0x49
	.quad	84                              ; 0x54
lCPI22_3:
	.quad	95                              ; 0x5f
	.quad	106                             ; 0x6a
lCPI22_4:
	.quad	117                             ; 0x75
	.quad	0                               ; 0x0
lCPI22_5:
	.quad	52                              ; 0x34
	.quad	63                              ; 0x3f
lCPI22_6:
	.quad	74                              ; 0x4a
	.quad	85                              ; 0x55
lCPI22_7:
	.quad	96                              ; 0x60
	.quad	107                             ; 0x6b
lCPI22_8:
	.quad	2                               ; 0x2
	.quad	81                              ; 0x51
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_indexed_edit_result
	.p2align	2
_wf_indexed_edit_result:                ; @wf_indexed_edit_result
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #96
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 96
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	w0, #88                         ; =0x58
	bl	_malloc
	cbz	x0, LBB22_4
; %bb.1:                                ; %"wf_std.collections.slab.slab_new$instance$ee4b9614ae2d9710.exit"
	mov	x19, x0
	mov	w0, #16                         ; =0x10
	bl	_malloc
	cbz	x0, LBB22_4
; %bb.2:                                ; %bb8.i20
	mov	x20, x0
Lloh102:
	adrp	x8, lCPI22_0@PAGE
Lloh103:
	ldr	q0, [x8, lCPI22_0@PAGEOFF]
	str	q0, [x0]
	mov	w8, #1                          ; =0x1
	stp	x8, x0, [x19]
Lloh104:
	adrp	x9, lCPI22_1@PAGE
Lloh105:
	ldr	q0, [x9, lCPI22_1@PAGEOFF]
Lloh106:
	adrp	x9, lCPI22_2@PAGE
Lloh107:
	ldr	q1, [x9, lCPI22_2@PAGEOFF]
	stp	q0, q1, [x19, #16]
Lloh108:
	adrp	x9, lCPI22_3@PAGE
Lloh109:
	ldr	q0, [x9, lCPI22_3@PAGEOFF]
Lloh110:
	adrp	x9, lCPI22_4@PAGE
Lloh111:
	ldr	q1, [x9, lCPI22_4@PAGEOFF]
	stp	q0, q1, [x19, #48]
	str	x8, [x19, #80]
	mov	w0, #16                         ; =0x10
	bl	_malloc
	cbz	x0, LBB22_4
; %bb.3:                                ; %bb1
	str	x0, [x19, #8]
Lloh112:
	adrp	x8, lCPI22_5@PAGE
Lloh113:
	ldr	q0, [x8, lCPI22_5@PAGEOFF]
Lloh114:
	adrp	x8, lCPI22_6@PAGE
Lloh115:
	ldr	q1, [x8, lCPI22_6@PAGEOFF]
	stp	q0, q1, [x19, #16]
Lloh116:
	adrp	x8, lCPI22_7@PAGE
Lloh117:
	ldr	q0, [x8, lCPI22_7@PAGEOFF]
	str	q0, [x19, #48]
	mov	w8, #118                        ; =0x76
	str	x8, [x19, #64]
	mov	x21, x0
	mov	x0, x20
	bl	_free
	str	xzr, [x19]
Lloh118:
	adrp	x8, lCPI22_8@PAGE
Lloh119:
	ldr	q0, [x8, lCPI22_8@PAGEOFF]
	str	q0, [sp]
	mov	x0, x21
	bl	_free
	mov	w8, #1                          ; =0x1
	dup.2d	v0, x8
	str	q0, [sp, #16]
	stp	x19, x8, [sp, #32]
	add	x0, sp, #16
	mov	x1, sp
	bl	_wf_std.collections.slab.slab_free$instance$006b6d8e6441afd9
	ldp	x8, x9, [sp]
	cmp	x8, #2
	cset	w8, ne
	cmp	x9, #81
	cinc	x0, x8, ne
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB22_4:                                ; %window.block.oom.v1.i.i.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh110, Lloh111
	.loh AdrpAdrp	Lloh108, Lloh110
	.loh AdrpLdr	Lloh108, Lloh109
	.loh AdrpAdrp	Lloh106, Lloh108
	.loh AdrpLdr	Lloh106, Lloh107
	.loh AdrpAdrp	Lloh104, Lloh106
	.loh AdrpLdr	Lloh104, Lloh105
	.loh AdrpLdr	Lloh102, Lloh103
	.loh AdrpLdr	Lloh118, Lloh119
	.loh AdrpLdr	Lloh116, Lloh117
	.loh AdrpAdrp	Lloh114, Lloh116
	.loh AdrpLdr	Lloh114, Lloh115
	.loh AdrpAdrp	Lloh112, Lloh114
	.loh AdrpLdr	Lloh112, Lloh113
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_main                        ; -- Begin function wf_main
	.p2align	2
_wf_main:                               ; @wf_main
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w0, #0                          ; =0x0
	bl	_wf_indexed_trace$instance$34505fe33827dcb3
	cbz	x0, LBB23_2
; %bb.1:
	mov	w1, #1                          ; =0x1
	b	LBB23_19
LBB23_2:                                ; %bb3
	mov	w0, #1                          ; =0x1
	bl	_wf_indexed_trace$instance$34505fe33827dcb3
	cbz	x0, LBB23_4
; %bb.3:
	mov	w1, #2                          ; =0x2
	b	LBB23_19
LBB23_4:                                ; %bb6
	bl	_wf_indexed_trace$instance$276fd431a73a5d55
	cbz	x0, LBB23_6
; %bb.5:
	mov	w1, #3                          ; =0x3
	b	LBB23_19
LBB23_6:                                ; %bb9
	mov	w0, #1                          ; =0x1
	bl	_wf_indexed_trace$instance$276fd431a73a5d55
	cbz	x0, LBB23_8
; %bb.7:
	mov	w1, #4                          ; =0x4
	b	LBB23_19
LBB23_8:                                ; %bb12
	bl	_wf_indexed_capacity_and_retirement
	cbz	x0, LBB23_10
; %bb.9:
	mov	w1, #5                          ; =0x5
	b	LBB23_19
LBB23_10:                               ; %bb15
	bl	_wf_indexed_heapify_reports
	cbz	x0, LBB23_12
; %bb.11:
	mov	w1, #6                          ; =0x6
	b	LBB23_19
LBB23_12:                               ; %bb18
	bl	_wf_indexed_edit_result
	cbz	x0, LBB23_14
; %bb.13:
	mov	w1, #7                          ; =0x7
	b	LBB23_19
LBB23_14:                               ; %bb21
	mov	w1, #0                          ; =0x0
	bl	_wf_indexed_repair_rise
	cbz	x0, LBB23_16
; %bb.15:
	mov	w1, #8                          ; =0x8
	b	LBB23_19
LBB23_16:                               ; %bb24
	mov	w0, #1                          ; =0x1
	mov	w1, #0                          ; =0x0
	bl	_wf_indexed_repair_rise
	cbz	x0, LBB23_18
; %bb.17:
	mov	w1, #9                          ; =0x9
	b	LBB23_19
LBB23_18:                               ; %bb27
	mov	w0, #1                          ; =0x1
	mov	w1, #1                          ; =0x1
	bl	_wf_indexed_repair_rise
	cmp	x0, #0
	mov	w8, #10                         ; =0xa
	csel	w1, wzr, w8, eq
LBB23_19:                               ; %common.ret
	mov	x0, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	b	_wf_std.process.exit_status
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_record_id_hash              ; -- Begin function wf_record_id_hash
	.p2align	2
_wf_record_id_hash:                     ; @wf_record_id_hash
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	cbz	x8, LBB24_2
; %bb.1:                                ; %bb3
	ldr	x9, [x1]
	udiv	x10, x9, x8
	msub	x0, x10, x8, x9
	ret
LBB24_2:
	mov	x0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_record_id_equal             ; -- Begin function wf_record_id_equal
	.p2align	2
_wf_record_id_equal:                    ; @wf_record_id_equal
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x2]
	cmp	x8, x9
	cset	w0, eq
	ret
                                        ; -- End function
	.globl	_wf_record_due_compare          ; -- Begin function wf_record_due_compare
	.p2align	2
_wf_record_due_compare:                 ; @wf_record_due_compare
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x2]
	cmp	x8, x9
	b.hs	LBB26_2
LBB26_1:
	mov	w0, #-1                         ; =0xffffffff
	ret
LBB26_2:                                ; %bb3
	b.ls	LBB26_4
; %bb.3:
	mov	w0, #1                          ; =0x1
	ret
LBB26_4:                                ; %bb6
	ldr	x8, [x1, #8]
	ldr	x9, [x2, #8]
	cmp	x8, x9
	b.lo	LBB26_1
; %bb.5:                                ; %bb9
	b.ls	LBB26_7
; %bb.6:
	mov	w0, #1                          ; =0x1
	ret
LBB26_7:                                ; %bb12
	ldr	x8, [x1, #16]
	ldr	x9, [x2, #16]
	cmp	x8, x9
	b.lo	LBB26_1
; %bb.8:                                ; %bb15
	b.ls	LBB26_10
; %bb.9:
	mov	w0, #1                          ; =0x1
	ret
LBB26_10:                               ; %bb18
	ldr	x8, [x1, #24]
	ldr	x9, [x2, #24]
	mov	w10, #-1                        ; =0xffffffff
	cmp	x8, x9
	cset	w8, hi
	csel	w0, w10, w8, lo
	ret
                                        ; -- End function
	.globl	_wf_record_handle_equal         ; -- Begin function wf_record_handle_equal
	.p2align	2
_wf_record_handle_equal:                ; @wf_record_handle_equal
; %bb.0:                                ; %entry
	ldp	x8, x9, [x0]
	ldp	x10, x11, [x1]
	cmp	x8, x10
	ccmp	x9, x11, #0, eq
	cset	w0, eq
	ret
                                        ; -- End function
	.globl	_wf_record_read_handle          ; -- Begin function wf_record_read_handle
	.p2align	2
_wf_record_read_handle:                 ; @wf_record_read_handle
; %bb.0:                                ; %entry
	ldp	x0, x1, [x2]
	ret
                                        ; -- End function
	.globl	_wf_record_read_due             ; -- Begin function wf_record_read_due
	.p2align	2
_wf_record_read_due:                    ; @wf_record_read_due
; %bb.0:                                ; %entry
	ldp	q0, q1, [x2]
	stp	q0, q1, [x0]
	ret
                                        ; -- End function
	.globl	_wf_record_discard_id           ; -- Begin function wf_record_discard_id
	.p2align	2
_wf_record_discard_id:                  ; @wf_record_discard_id
; %bb.0:                                ; %entry
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_record_discard_due          ; -- Begin function wf_record_discard_due
	.p2align	2
_wf_record_discard_due:                 ; @wf_record_discard_due
; %bb.0:                                ; %entry
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_probe ; -- Begin function wf_std.collections.hash_map.hash_map_probe
	.p2align	2
_wf_std.collections.hash_map.hash_map_probe: ; @wf_std.collections.hash_map.hash_map_probe
; %bb.0:                                ; %entry
	sub	x8, x2, x0
	cmp	x1, x8
	csneg	x8, x0, x8, lo
	add	x0, x8, x1
	ret
                                        ; -- End function
	.globl	_wf_box_new$instance$18ded78b3e1c4ff3 ; -- Begin function wf_box_new$instance$18ded78b3e1c4ff3
	.p2align	2
_wf_box_new$instance$18ded78b3e1c4ff3:  ; @"wf_box_new$instance$18ded78b3e1c4ff3"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	mov	w0, #16                         ; =0x10
	bl	_malloc
	cbz	x0, LBB33_2
; %bb.1:                                ; %box.new.ready.v1
	ldr	q0, [x19]
	str	q0, [x0]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB33_2:                                ; %box.new.oom.v1
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_array_filled$instance$1bfdd87467a2be8e ; -- Begin function wf_array_filled$instance$1bfdd87467a2be8e
	.p2align	2
_wf_array_filled$instance$1bfdd87467a2be8e: ; @"wf_array_filled$instance$1bfdd87467a2be8e"
; %bb.0:                                ; %entry
	dup.2d	v0, x1
	stp	q0, q0, [x0]
	stp	q0, q0, [x0, #32]
	stp	q0, q0, [x0, #64]
	stp	q0, q0, [x0, #96]
	stp	q0, q0, [x0, #128]
	stp	q0, q0, [x0, #160]
	stp	q0, q0, [x0, #192]
	stp	q0, q0, [x0, #224]
	stp	q0, q0, [x0, #256]
	stp	q0, q0, [x0, #288]
	stp	q0, q0, [x0, #320]
	stp	q0, q0, [x0, #352]
	stp	q0, q0, [x0, #384]
	stp	q0, q0, [x0, #416]
	stp	q0, q0, [x0, #448]
	stp	q0, q0, [x0, #480]
	ret
                                        ; -- End function
	.globl	_wf_array_filled$instance$581665c886d1d2c8 ; -- Begin function wf_array_filled$instance$581665c886d1d2c8
	.p2align	2
_wf_array_filled$instance$581665c886d1d2c8: ; @"wf_array_filled$instance$581665c886d1d2c8"
; %bb.0:                                ; %entry
	dup.2d	v0, x1
	stp	q0, q0, [x0]
	stp	q0, q0, [x0, #32]
	stp	q0, q0, [x0, #64]
	stp	q0, q0, [x0, #96]
	stp	q0, q0, [x0, #128]
	stp	q0, q0, [x0, #160]
	stp	q0, q0, [x0, #192]
	stp	q0, q0, [x0, #224]
	ret
                                        ; -- End function
	.globl	_wf_array_filled$instance$d714c1862d5ade87 ; -- Begin function wf_array_filled$instance$d714c1862d5ade87
	.p2align	2
_wf_array_filled$instance$d714c1862d5ade87: ; @"wf_array_filled$instance$d714c1862d5ade87"
; %bb.0:                                ; %entry
	ldp	q0, q1, [x1]
	stp	q0, q1, [sp, #-64]!
	ldp	q2, q3, [x1, #32]
	stp	q2, q3, [sp, #32]
	stp	q2, q3, [x0, #32]
	stp	q0, q1, [x0]
	stp	q0, q1, [x0, #64]
	stp	q2, q3, [x0, #96]
	stp	q0, q1, [x0, #128]
	stp	q2, q3, [x0, #160]
	ldp	q1, q3, [sp, #32]
	ldp	q5, q0, [sp, #16]
	stp	q1, q3, [x0, #224]
	ldr	q3, [sp]
	stp	q3, q5, [x0, #192]
	ldp	q2, q3, [sp, #32]
	stp	q0, q3, [x0, #288]
	ldp	q4, q0, [sp]
	ldp	q1, q3, [sp]
	stp	q4, q0, [x0, #256]
	ldp	q0, q5, [sp, #32]
	stp	q0, q5, [x0, #352]
	ldr	q0, [sp]
	stp	q0, q3, [x0, #320]
	ldp	q4, q0, [sp, #32]
	stp	q4, q0, [x0, #416]
	ldp	q5, q0, [sp]
	stp	q5, q0, [x0, #384]
	ldp	q0, q3, [sp, #32]
	ldp	q4, q5, [sp, #16]
	stp	q0, q3, [x0, #480]
	ldr	q0, [sp]
	stp	q0, q4, [x0, #448]
	ldr	q0, [sp, #48]
	stp	q5, q0, [x0, #544]
	ldp	q3, q0, [sp]
	stp	q3, q0, [x0, #512]
	ldp	q0, q4, [sp, #32]
	ldp	q5, q3, [sp, #16]
	stp	q0, q4, [x0, #608]
	ldr	q0, [sp]
	stp	q0, q5, [x0, #576]
	ldr	q0, [sp, #48]
	stp	q3, q0, [x0, #672]
	ldp	q4, q0, [sp]
	stp	q4, q0, [x0, #640]
	ldp	q0, q5, [sp, #32]
	ldp	q3, q4, [sp, #16]
	stp	q0, q5, [x0, #736]
	ldr	q0, [sp]
	stp	q0, q3, [x0, #704]
	ldr	q0, [sp, #48]
	stp	q4, q0, [x0, #800]
	ldp	q5, q0, [sp]
	stp	q5, q0, [x0, #768]
	ldp	q0, q3, [sp, #32]
	ldp	q4, q5, [sp, #16]
	stp	q0, q3, [x0, #864]
	ldr	q0, [sp]
	stp	q0, q4, [x0, #832]
	ldr	q0, [sp, #48]
	stp	q5, q0, [x0, #928]
	ldp	q3, q0, [sp]
	stp	q3, q0, [x0, #896]
	ldp	q0, q4, [sp, #32]
	ldp	q5, q3, [sp, #16]
	stp	q0, q4, [x0, #992]
	ldr	q0, [sp]
	stp	q0, q5, [x0, #960]
	ldr	q0, [sp, #48]
	ldr	q5, [sp, #48]
	str	q0, [x0, #1072]
	str	q3, [x0, #1056]
	ldp	q4, q0, [sp]
	str	q0, [x0, #1040]
	str	q4, [x0, #1024]
	str	q5, [x0, #1136]
	ldp	q3, q0, [sp, #16]
	str	q0, [x0, #1120]
	str	q3, [x0, #1104]
	ldr	q0, [sp]
	str	q0, [x0, #1088]
	ldp	q4, q0, [sp, #32]
	ldr	q5, [sp, #48]
	str	q0, [x0, #1200]
	str	q4, [x0, #1184]
	ldp	q3, q0, [sp]
	str	q0, [x0, #1168]
	str	q3, [x0, #1152]
	str	q5, [x0, #1264]
	ldp	q4, q0, [sp, #16]
	str	q0, [x0, #1248]
	str	q4, [x0, #1232]
	ldr	q0, [sp]
	str	q0, [x0, #1216]
	ldp	q3, q0, [sp, #32]
	ldr	q5, [sp, #48]
	str	q0, [x0, #1328]
	str	q3, [x0, #1312]
	ldp	q4, q0, [sp]
	str	q0, [x0, #1296]
	str	q4, [x0, #1280]
	str	q5, [x0, #1392]
	ldp	q3, q0, [sp, #16]
	str	q0, [x0, #1376]
	str	q3, [x0, #1360]
	ldr	q0, [sp]
	str	q0, [x0, #1344]
	ldp	q4, q0, [sp, #32]
	ldr	q5, [sp, #48]
	str	q0, [x0, #1456]
	str	q4, [x0, #1440]
	ldp	q3, q0, [sp]
	str	q0, [x0, #1424]
	str	q3, [x0, #1408]
	str	q5, [x0, #1520]
	ldp	q4, q0, [sp, #16]
	str	q0, [x0, #1504]
	str	q4, [x0, #1488]
	ldr	q0, [sp]
	str	q0, [x0, #1472]
	ldp	q3, q0, [sp, #32]
	ldr	q5, [sp, #48]
	str	q0, [x0, #1584]
	str	q3, [x0, #1568]
	ldp	q4, q0, [sp]
	str	q0, [x0, #1552]
	str	q4, [x0, #1536]
	str	q5, [x0, #1648]
	ldp	q3, q0, [sp, #16]
	str	q0, [x0, #1632]
	str	q3, [x0, #1616]
	ldr	q0, [sp]
	str	q0, [x0, #1600]
	ldp	q4, q0, [sp, #32]
	ldr	q5, [sp, #48]
	str	q0, [x0, #1712]
	str	q4, [x0, #1696]
	ldp	q3, q0, [sp]
	str	q0, [x0, #1680]
	str	q3, [x0, #1664]
	str	q5, [x0, #1776]
	ldp	q4, q0, [sp, #16]
	str	q0, [x0, #1760]
	str	q4, [x0, #1744]
	ldr	q0, [sp]
	str	q0, [x0, #1728]
	ldp	q3, q0, [sp, #32]
	ldr	q5, [sp, #48]
	str	q0, [x0, #1840]
	str	q3, [x0, #1824]
	ldp	q4, q0, [sp]
	str	q0, [x0, #1808]
	str	q4, [x0, #1792]
	str	q5, [x0, #1904]
	ldp	q3, q0, [sp, #16]
	str	q0, [x0, #1888]
	str	q3, [x0, #1872]
	ldr	q0, [sp]
	str	q0, [x0, #1856]
	ldp	q4, q0, [sp, #32]
	ldr	q5, [sp, #48]
	str	q0, [x0, #1968]
	str	q4, [x0, #1952]
	ldp	q3, q0, [sp]
	ldr	q4, [sp, #16]
	str	q0, [x0, #1936]
	str	q3, [x0, #1920]
	str	q5, [x0, #2032]
	str	q2, [x0, #2016]
	str	q4, [x0, #2000]
	str	q1, [x0, #1984]
	add	sp, sp, #64
	ret
                                        ; -- End function
	.globl	_wf_record_store_new$instance$50c6da9371c13a22 ; -- Begin function wf_record_store_new$instance$50c6da9371c13a22
	.p2align	2
_wf_record_store_new$instance$50c6da9371c13a22: ; @"wf_record_store_new$instance$50c6da9371c13a22"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #208
	stp	x26, x25, [sp, #128]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #144]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #160]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #176]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 208
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x6
	mov	x22, x5
	mov	x24, x4
	mov	x25, x3
	mov	x21, x2
	mov	x23, x1
	mov	x20, x0
	cbz	x3, LBB37_2
; %bb.1:                                ; %window.payload.allocate.v1.i.i.i
	lsl	x8, x25, #6
	sub	x0, x8, x25, lsl #3
	bl	_malloc
	cbnz	x0, LBB37_3
	b	LBB37_10
LBB37_2:
Lloh120:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh121:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB37_3:                                ; %"wf_std.collections.slab.slab_new$instance$1a625a3e6534a882.exit"
	stp	xzr, x25, [sp]
	stp	x0, x25, [sp, #16]
	cbz	x24, LBB37_7
; %bb.4:                                ; %window.payload.allocate.v1.i.i.i2
	lsl	x0, x24, #5
	bl	_malloc
	cbz	x0, LBB37_10
; %bb.5:                                ; %bb5.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #8
LBB37_6:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x9, #8]
	str	xzr, [x9], #32
	cmp	x24, x8
	b.ne	LBB37_6
	b	LBB37_8
LBB37_7:
Lloh122:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh123:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB37_8:                                ; %"wf_std.collections.hash_map.hash_map_new$instance$4348312e8937ab7e.exit"
	stp	x24, x24, [sp, #32]
	stp	xzr, xzr, [sp, #56]
	str	x0, [sp, #48]
	cbz	x22, LBB37_11
; %bb.9:                                ; %window.payload.allocate.v1.i.i
	lsl	x0, x22, #5
	bl	_malloc
	cbnz	x0, LBB37_12
LBB37_10:                               ; %window.block.oom.v1.i.i.i
	bl	l_wf_resource_abort
LBB37_11:
Lloh124:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh125:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB37_12:                               ; %"wf_box_slots_new$instance$57d99a800120d980.exit"
	mov	x8, sp
	stp	xzr, x22, [sp, #72]
	stp	x0, xzr, [sp, #88]
	stp	x22, x0, [sp, #104]
	stp	x23, xzr, [x20]
	and	w9, w21, #0x1
	strb	w9, [x20, #8]
	ldp	q0, q1, [sp]
	stp	q0, q1, [x20, #16]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x20, #48]
	ldur	x8, [x8, #64]
	str	x8, [x20, #80]
	ldr	q0, [sp, #96]
	stur	q0, [x20, #88]
	stp	x0, x19, [x20, #104]
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #176]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #160]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #144]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
	.loh AdrpAdd	Lloh120, Lloh121
	.loh AdrpAdd	Lloh122, Lloh123
	.loh AdrpAdd	Lloh124, Lloh125
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_indexed_word_insert$instance$c9ecd8438d97c9c4
lCPI38_0:
	.quad	2                               ; 0x2
	.quad	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_indexed_word_insert$instance$c9ecd8438d97c9c4
	.p2align	2
_wf_indexed_word_insert$instance$c9ecd8438d97c9c4: ; @"wf_indexed_word_insert$instance$c9ecd8438d97c9c4"
; %bb.0:                                ; %entry
	sub	sp, sp, #16
	mov	x8, x2
	mov	x9, x1
	strb	wzr, [sp, #8]
	ldr	x1, [x0, #40]
	ldr	x10, [x0, #16]
	cmp	x1, x10
	b.hs	LBB38_4
; %bb.1:                                ; %bb2.i.i.i
	ldr	x10, [x0, #32]
	mov	w11, #56                        ; =0x38
	madd	x10, x1, x11, x10
	ldr	x11, [x10]
	cbnz	x11, LBB38_7
; %bb.2:                                ; %bb5.i.i.i
	ldr	x2, [x10, #40]
	cmp	x2, #1
	b.hi	LBB38_7
; %bb.3:                                ; %bb8.i.i.i
	ldr	x9, [x10, #48]
	stp	x8, x3, [x10, #8]
	strb	wzr, [x10, #24]
	mov	w11, #2                         ; =0x2
	str	x11, [x10, #32]
	mov	w11, #1                         ; =0x1
	str	x11, [x10]
	str	x9, [x0, #40]
	b	LBB38_6
LBB38_4:                                ; %bb3.i.i.i
	ldr	x11, [x0, #24]
	cmp	x10, x11
	b.hs	LBB38_7
; %bb.5:                                ; %bb11.i.i.i
	mov	x2, #0                          ; =0x0
	ldr	x9, [x0, #32]
	mov	w11, #56                        ; =0x38
	madd	x9, x10, x11, x9
	mov	w11, #1                         ; =0x1
	stp	x11, x8, [x9]
	str	x3, [x9, #16]
	strb	wzr, [x9, #24]
Lloh126:
	adrp	x8, lCPI38_0@PAGE
Lloh127:
	ldr	q0, [x8, lCPI38_0@PAGEOFF]
	str	q0, [x9, #32]
	str	x1, [x9, #48]
	add	x8, x10, #1
	str	x8, [x0, #16]
	mov	x1, x10
LBB38_6:                                ; %bb8.i.i.i
	ldr	x0, [x0]
	add	sp, sp, #16
	ret
LBB38_7:                                ; %bb2.i
	mov	x2, #0                          ; =0x0
	ldr	x8, [x9, #1304]
	add	x8, x8, #1
	str	x8, [x9, #1304]
	ldr	x0, [x0]
	mov	w1, #2                          ; =0x2
	add	sp, sp, #16
	ret
	.loh AdrpLdr	Lloh126, Lloh127
                                        ; -- End function
	.globl	_wf_record_store_attach$instance$50c6da9371c13a22 ; -- Begin function wf_record_store_attach$instance$50c6da9371c13a22
	.p2align	2
_wf_record_store_attach$instance$50c6da9371c13a22: ; @"wf_record_store_attach$instance$50c6da9371c13a22"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	sub	sp, sp, #448
	.cfi_def_cfa_offset 512
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	ldr	q0, [x1]
	str	q0, [sp]
	ldr	x8, [x1, #16]
	str	x8, [sp, #16]
	ldr	x9, [sp]
	ldr	x10, [x0]
	cmp	x9, x10
	b.ne	LBB39_6
; %bb.1:                                ; %bb3.i
	ldr	x11, [sp, #8]
	ldr	x10, [x0, #16]
	cmp	x11, x10
	b.hs	LBB39_32
; %bb.2:                                ; %bb2.i.i
	ldr	x9, [x0, #32]
	mov	w12, #56                        ; =0x38
	madd	x11, x11, x12, x9
	ldr	x12, [x11, #40]
	cmp	x12, x8
	b.ne	LBB39_32
; %bb.3:                                ; %bb5.i.i
	ldr	x8, [x11]
	cbz	x8, LBB39_32
; %bb.4:                                ; %bb2
	mov	x22, sp
	ldr	x8, [x11, #8]
	ldrb	w12, [x11, #24]
	ldr	x11, [x11, #32]
	and	w12, w12, #0x1
	strb	w12, [sp, #432]
	stp	xzr, x8, [sp, #24]
	strb	w12, [sp, #40]
	stur	wzr, [sp, #41]
	str	wzr, [sp, #44]
	ldr	q0, [sp, #32]
	str	q0, [sp, #80]
	str	x11, [sp, #96]
	ldr	x8, [sp, #80]
	ldrb	w12, [sp, #88]
	stp	x11, x8, [sp, #48]
	strb	w12, [sp, #64]
	str	x11, [sp, #72]
	str	x11, [x22, #416]
	ldur	q0, [sp, #56]
	str	q0, [x22, #400]
	ldrb	w8, [x22, #408]
	cmp	w8, #1
	b.ne	LBB39_7
LBB39_5:
	mov	w0, #1                          ; =0x1
	b	LBB39_33
LBB39_6:
	mov	w0, #4                          ; =0x4
	b	LBB39_33
LBB39_7:                                ; %bb6
	mov	x19, x0
	ldr	x8, [x19, #112]!
	sub	x20, x19, #64
	cbz	x8, LBB39_20
; %bb.8:                                ; %bb3.i.i
	ldr	x11, [sp, #400]
	udiv	x12, x11, x8
	msub	x12, x12, x8, x11
	ldr	x8, [x20]
	cbz	x8, LBB39_21
LBB39_9:                                ; %bb3.i12
	add	x11, x22, #184
	udiv	x13, x12, x8
	msub	x12, x13, x8, x12
	ldr	x13, [x0, #64]
	ldr	x21, [sp, #400]
	mov	x14, x8
	b	LBB39_11
LBB39_10:                               ; %bb8.i
                                        ;   in Loop: Header=BB39_11 Depth=1
	add	x15, x12, #1
	cmp	x15, x8
	csinc	x12, xzr, x12, hs
	subs	x14, x14, #1
	b.eq	LBB39_19
LBB39_11:                               ; %bb5.i13
                                        ; =>This Inner Loop Header: Depth=1
	add	x15, x13, x12, lsl #5
	ldr	w16, [x15]
	cmp	w16, #1
	b.eq	LBB39_10
; %bb.12:                               ; %bb5.i13
                                        ;   in Loop: Header=BB39_11 Depth=1
	cmp	w16, #2
	b.ne	LBB39_19
; %bb.13:                               ; %bb9.i
                                        ;   in Loop: Header=BB39_11 Depth=1
	ldr	x16, [x15, #8]
	cmp	x16, x21
	b.ne	LBB39_10
; %bb.14:                               ; %bb8
	str	xzr, [sp, #104]
	ldr	q0, [x15, #16]
	str	q0, [sp, #112]
	ldr	q0, [sp, #112]
	ldur	q1, [x1, #8]
	stp	q0, q1, [x22, #128]
	ldp	x12, x13, [sp, #128]
	ldr	x14, [sp, #144]
	cmp	x12, x14
	b.ne	LBB39_16
; %bb.15:                               ; %bb8
	ldr	x14, [sp, #152]
	cmp	x13, x14
	b.eq	LBB39_5
LBB39_16:                               ; %bb12
	cmp	x12, x10
	b.hs	LBB39_34
; %bb.17:                               ; %bb2.i.i19
	mov	w10, #56                        ; =0x38
	madd	x9, x12, x10, x9
	ldr	x10, [x9, #40]
	cmp	x10, x13
	b.ne	LBB39_34
; %bb.18:                               ; %"wf_std.collections.slab.slab_find_index$instance$1a625a3e6534a882.exit"
	ldr	x9, [x9]
	cmp	x9, #0
	csel	x10, xzr, x12, eq
	cset	w12, eq
	str	w12, [sp, #160]
	str	x10, [sp, #168]
	strb	wzr, [sp, #176]
	cbnz	x9, LBB39_36
	b	LBB39_35
LBB39_19:                               ; %bb10.i
	stp	xzr, xzr, [x22, #104]
	stur	xzr, [x22, #120]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #104]
	b	LBB39_22
LBB39_20:
	mov	x12, #0                         ; =0x0
	ldr	x8, [x20]
	cbnz	x8, LBB39_9
LBB39_21:                               ; %bb2.i14
	stp	xzr, xzr, [x22, #104]
	stur	xzr, [x22, #120]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #104]
	ldr	x21, [sp, #400]
LBB39_22:                               ; %bb7
	ldur	q0, [x1, #8]
	str	q0, [x22, #304]
	ldur	q0, [x1, #8]
	str	q0, [sp, #432]
	ldp	x9, x10, [x0, #72]
	mov	x23, x0
	adds	x9, x9, x10
	csinv	x9, x9, xzr, lo
	cmp	x8, #1
	b.hi	LBB39_25
; %bb.23:                               ; %bb7
	sub	x10, x8, x8, lsr #2
	cmp	x9, x10
	b.lo	LBB39_25
; %bb.24:                               ; %bb6.i
	cmp	x8, #0
	mov	w8, #1                          ; =0x1
	cinc	x1, x8, ne
	mov	x0, x20
	mov	x2, x19
	bl	_wf_std.collections.hash_map.hash_map_rebuild$instance$603c8258fd999e20
LBB39_25:                               ; %"wf_std.collections.hash_map.hash_map_put$instance$603c8258fd999e20.exit"
	add	x0, x22, #320
	add	x3, sp, #432
	mov	x1, x20
	mov	x2, x21
	mov	x4, x19
	bl	_wf_std.collections.hash_map.hash_map_try_put$instance$603c8258fd999e20
	ldr	w8, [sp, #320]
	cbz	w8, LBB39_28
; %bb.26:                               ; %bb21
	mov	x8, sp
	add	x8, x8, #328
	ldrb	w9, [x22, #324]
	ldr	x10, [sp, #344]
	str	x10, [x22, #368]
	ldr	q0, [x8]
	str	q0, [x22, #352]
	tbz	w9, #0, LBB39_28
; %bb.27:
	mov	w0, #6                          ; =0x6
	b	LBB39_33
LBB39_28:                               ; %bb19
	add	x8, x22, #376
	orr	x9, x22, #0x8
	mov	w10, #1                         ; =0x1
	strb	w10, [x22, #424]
	ldr	q0, [x9]
	str	q0, [x8]
	ldr	x8, [sp, #376]
	ldr	x9, [x23, #16]
	cmp	x8, x9
	b.hs	LBB39_32
; %bb.29:                               ; %bb2.i.i35
	ldr	x9, [sp, #384]
	ldr	x10, [x23, #32]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB39_32
; %bb.30:                               ; %bb5.i.i45
	ldr	x9, [x8]
	cbz	x9, LBB39_32
; %bb.31:                               ; %bb8.i.i
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #24]
	b	LBB39_33
LBB39_32:                               ; %bb5.i
	mov	w0, #3                          ; =0x3
LBB39_33:                               ; %common.ret
	add	sp, sp, #448
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB39_34:                               ; %"wf_std.collections.slab.slab_find_index$instance$1a625a3e6534a882.exit.thread"
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #160]
	str	xzr, [sp, #168]
	strb	wzr, [sp, #176]
LBB39_35:                               ; %bb15
	ldp	q0, q1, [x0]
	stp	q0, q1, [x11]
	ldp	q0, q1, [x0, #32]
	stp	q0, q1, [x11, #32]
	ldr	x9, [x0, #112]
	str	x9, [x11, #112]
	ldp	q0, q1, [x0, #80]
	stp	q0, q1, [x11, #80]
	ldr	q1, [x0, #64]
	str	q1, [x11, #64]
	ldrb	w9, [sp, #192]
	tbz	w9, #0, LBB39_22
LBB39_36:
	mov	w0, #5                          ; =0x5
	b	LBB39_33
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_record_store_schedule$instance$50c6da9371c13a22 ; -- Begin function wf_record_store_schedule$instance$50c6da9371c13a22
	.p2align	2
_wf_record_store_schedule$instance$50c6da9371c13a22: ; @"wf_record_store_schedule$instance$50c6da9371c13a22"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #272
	stp	x28, x27, [sp, #240]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #256]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 272
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	ldr	q0, [x1]
	str	q0, [sp]
	ldr	x8, [x1, #16]
	str	x8, [sp, #16]
	ldr	x9, [sp]
	ldr	x10, [x0]
	cmp	x9, x10
	b.ne	LBB40_6
; %bb.1:                                ; %bb3.i
	ldr	x9, [sp, #8]
	mov	x4, x0
	ldr	x10, [x4, #16]!
	cmp	x9, x10
	b.hs	LBB40_7
; %bb.2:                                ; %bb2.i.i
	ldr	x10, [x0, #32]
	mov	w11, #56                        ; =0x38
	madd	x12, x9, x11, x10
	ldr	x10, [x12, #40]
	cmp	x10, x8
	b.ne	LBB40_7
; %bb.3:                                ; %bb5.i.i
	ldr	x10, [x12]
	cbz	x10, LBB40_7
; %bb.4:                                ; %bb2
	mov	x11, sp
	ldr	x10, [x12, #8]
	ldrb	w13, [x12, #24]
	ldr	x12, [x12, #32]
	and	w13, w13, #0x1
	strb	w13, [sp, #232]
	stp	xzr, x10, [sp, #24]
	strb	w13, [sp, #40]
	stur	wzr, [sp, #41]
	str	wzr, [sp, #44]
	str	x12, [sp, #48]
	stur	x12, [x11, #72]
	ldr	q0, [sp, #32]
	stur	q0, [x11, #56]
	ldr	x13, [sp, #72]
	cmp	x13, #2
	b.ne	LBB40_9
; %bb.5:                                ; %bb6
	ldr	x8, [sp, #56]
	ldur	q0, [x1, #8]
	stur	q0, [x11, #104]
	stp	x2, x8, [sp, #120]
	stur	q0, [sp, #136]
	mov	x8, x0
	add	x0, x11, #152
	add	x1, x8, #88
	add	x2, x11, #120
	add	x3, x11, #224
	bl	_wf_collections.priority_queue.priority_queue_push_indexed$instance$2a15825f0f6e194e
	ldr	w8, [sp, #152]
	mov	w9, #6                          ; =0x6
	cmp	w8, #0
	csel	w0, wzr, w9, eq
	b	LBB40_8
LBB40_6:
	mov	w0, #4                          ; =0x4
	b	LBB40_8
LBB40_7:                                ; %bb5.i
	mov	w0, #3                          ; =0x3
LBB40_8:                                ; %common.ret
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #240]            ; 16-byte Folded Reload
	add	sp, sp, #272
	ret
LBB40_9:                                ; %bb2.i.i4
	cmp	x12, #2
	b.ne	LBB40_11
; %bb.10:
	mov	w0, #7                          ; =0x7
	b	LBB40_8
LBB40_11:                               ; %bb6.i.i
	ldr	x11, [x0, #88]
	cmp	x12, x11
	b.hs	LBB40_14
; %bb.12:                               ; %bb8.i.i
	ldr	x11, [x0, #104]
	add	x11, x11, x12, lsl #5
	ldp	x12, x13, [x11, #16]
	mov	w0, #8                          ; =0x8
	cmp	x12, x9
	ccmp	x13, x8, #0, eq
	b.ne	LBB40_8
; %bb.13:                               ; %bb11.i.i
	ldr	x8, [x11, #8]
	cmp	x8, x10
	csinc	w0, w0, wzr, ne
	b	LBB40_8
LBB40_14:
	mov	w0, #8                          ; =0x8
	b	LBB40_8
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function wf_record_store_delete$instance$50c6da9371c13a22
lCPI41_0:
	.long	1                               ; 0x1
	.long	9                               ; 0x9
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_record_store_delete$instance$50c6da9371c13a22
	.p2align	2
_wf_record_store_delete$instance$50c6da9371c13a22: ; @"wf_record_store_delete$instance$50c6da9371c13a22"
; %bb.0:                                ; %entry
	sub	sp, sp, #48
	ldr	x8, [x2]
	ldr	x9, [x1]
	cmp	x8, x9
	b.ne	LBB41_10
; %bb.1:                                ; %bb3.i
	ldr	x8, [x2, #8]
	ldr	x9, [x1, #16]
	cmp	x8, x9
	b.hs	LBB41_11
; %bb.2:                                ; %bb2.i.i
	ldr	x10, [x2, #16]
	ldr	x9, [x1, #32]
	mov	w11, #56                        ; =0x38
	madd	x11, x8, x11, x9
	ldr	x12, [x11, #40]
	cmp	x12, x10
	b.ne	LBB41_11
; %bb.3:                                ; %bb5.i.i
	ldr	x12, [x11]
	cbz	x12, LBB41_11
; %bb.4:                                ; %bb2
	ldrb	w14, [x11, #24]
	ldr	x13, [x11, #32]
	and	w14, w14, #0x1
	strb	w14, [sp, #8]
	ldrb	w15, [x1, #8]
	tbz	w15, #0, LBB41_7
; %bb.5:                                ; %bb5
	cbnz	w14, LBB41_13
; %bb.6:                                ; %bb9
	cmp	x13, #2
	b.ne	LBB41_13
LBB41_7:                                ; %bb8.i
	sub	x12, x12, #1
	add	x13, x11, x12, lsl #5
	str	x12, [x11]
	ldur	q0, [x13, #8]
	ldur	q1, [x13, #24]
	stp	q0, q1, [sp, #16]
	cbnz	x10, LBB41_9
; %bb.8:                                ; %bb11.i
	mov	w10, #56                        ; =0x38
	madd	x9, x8, x10, x9
	ldr	x10, [x1, #40]
	mov	w11, #1                         ; =0x1
	stp	x11, x10, [x9, #40]
	str	x8, [x1, #40]
LBB41_9:                                ; %bb13
	str	xzr, [x0]
	ldp	q0, q1, [sp, #16]
	stur	q0, [x0, #8]
	stur	q1, [x0, #24]
	add	sp, sp, #48
	ret
LBB41_10:
	mov	w8, #4                          ; =0x4
	b	LBB41_12
LBB41_11:                               ; %bb5.i
	mov	w8, #3                          ; =0x3
LBB41_12:                               ; %bb3
	movi.2d	v0, #0000000000000000
	stur	q0, [x0, #24]
	stur	q0, [x0, #8]
	mov	w9, #1                          ; =0x1
	stp	w9, w8, [x0]
	add	sp, sp, #48
	ret
LBB41_13:                               ; %bb8
	movi.2d	v0, #0000000000000000
	stur	q0, [x0, #24]
	stur	q0, [x0, #8]
Lloh128:
	adrp	x8, lCPI41_0@PAGE
Lloh129:
	ldr	d0, [x8, lCPI41_0@PAGEOFF]
	str	d0, [x0]
	add	sp, sp, #48
	ret
	.loh AdrpLdr	Lloh128, Lloh129
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function wf_record_store_info$instance$50c6da9371c13a22
lCPI42_0:
	.long	1                               ; 0x1
	.long	4                               ; 0x4
lCPI42_1:
	.long	1                               ; 0x1
	.long	3                               ; 0x3
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_record_store_info$instance$50c6da9371c13a22
	.p2align	2
_wf_record_store_info$instance$50c6da9371c13a22: ; @"wf_record_store_info$instance$50c6da9371c13a22"
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	ldr	x9, [x1]
	cmp	x8, x9
	b.ne	LBB42_5
; %bb.1:                                ; %bb3
	ldr	x8, [x2, #8]
	ldr	x9, [x1, #16]
	cmp	x8, x9
	b.hs	LBB42_6
; %bb.2:                                ; %bb2.i
	ldr	x9, [x2, #16]
	ldr	x10, [x1, #32]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB42_6
; %bb.3:                                ; %bb5.i
	ldr	x9, [x8]
	cbz	x9, LBB42_6
; %bb.4:                                ; %bb4
	sub	sp, sp, #16
	ldr	x9, [x8, #8]
	ldrb	w10, [x8, #24]
	ldr	x8, [x8, #32]
	and	w10, w10, #0x1
	strb	w10, [sp, #8]
	stp	xzr, x9, [x0]
	strb	w10, [x0, #16]
	stur	wzr, [x0, #17]
	str	wzr, [x0, #20]
	str	x8, [x0, #24]
	add	sp, sp, #16
	ret
LBB42_5:                                ; %bb2
	movi.2d	v0, #0000000000000000
	str	xzr, [x0, #24]
	mov.d	v0[1], v0[0]
	stur	q0, [x0, #8]
Lloh130:
	adrp	x8, lCPI42_0@PAGE
Lloh131:
	ldr	d0, [x8, lCPI42_0@PAGEOFF]
	str	d0, [x0]
	ret
LBB42_6:                                ; %bb5
	movi.2d	v0, #0000000000000000
	str	xzr, [x0, #24]
	mov.d	v0[1], v0[0]
	stur	q0, [x0, #8]
Lloh132:
	adrp	x8, lCPI42_1@PAGE
Lloh133:
	ldr	d0, [x8, lCPI42_1@PAGEOFF]
	str	d0, [x0]
	ret
	.loh AdrpLdr	Lloh130, Lloh131
	.loh AdrpLdr	Lloh132, Lloh133
                                        ; -- End function
	.globl	_wf_record_store_detach$instance$50c6da9371c13a22 ; -- Begin function wf_record_store_detach$instance$50c6da9371c13a22
	.p2align	2
_wf_record_store_detach$instance$50c6da9371c13a22: ; @"wf_record_store_detach$instance$50c6da9371c13a22"
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	ldr	x9, [x0]
	cmp	x8, x9
	b.ne	LBB43_3
; %bb.1:                                ; %bb3
	ldr	x8, [x0, #112]
	cbz	x8, LBB43_5
; %bb.2:                                ; %bb3.i.i
	udiv	x9, x1, x8
	msub	x13, x9, x8, x1
	ldr	x11, [x0, #48]
	cbnz	x11, LBB43_6
	b	LBB43_26
LBB43_3:
	mov	w8, #4                          ; =0x4
LBB43_4:                                ; %common.ret
	mov	x0, x8
	ret
LBB43_5:
	mov	x13, #0                         ; =0x0
	ldr	x11, [x0, #48]
	cbz	x11, LBB43_26
LBB43_6:                                ; %bb3.i
	ldp	x10, x9, [x2, #8]
	mov	x12, x11
	udiv	x14, x13, x11
	msub	x14, x14, x11, x13
	ldr	x13, [x0, #64]
	mov	x15, x11
	b	LBB43_8
LBB43_7:                                ; %bb8.i
                                        ;   in Loop: Header=BB43_8 Depth=1
	add	x16, x14, #1
	cmp	x16, x11
	csinc	x14, xzr, x14, hs
	subs	x15, x15, #1
	b.eq	LBB43_26
LBB43_8:                                ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x16, x13, x14, lsl #5
	ldr	w17, [x16]
	cmp	w17, #1
	b.eq	LBB43_7
; %bb.9:                                ; %bb5.i
                                        ;   in Loop: Header=BB43_8 Depth=1
	cmp	w17, #2
	b.ne	LBB43_26
; %bb.10:                               ; %bb9.i
                                        ;   in Loop: Header=BB43_8 Depth=1
	ldr	x17, [x16, #8]
	cmp	x17, x1
	b.ne	LBB43_7
; %bb.11:                               ; %bb4
	ldp	x14, x15, [x16, #16]
	cmp	x14, x10
	ccmp	x15, x9, #0, eq
	b.eq	LBB43_13
; %bb.12:
	mov	w0, #5                          ; =0x5
	ret
LBB43_13:                               ; %bb7
	ldr	x14, [x0, #72]
	cbz	x14, LBB43_26
; %bb.14:                               ; %bb3.i5
	cbz	x8, LBB43_16
; %bb.15:                               ; %bb3.i.i.i.i
	udiv	x15, x1, x8
	msub	x8, x15, x8, x1
LBB43_16:                               ; %bb3.i.i.i
	udiv	x15, x8, x11
	msub	x15, x15, x11, x8
	b	LBB43_18
LBB43_17:                               ; %bb8.i.i.i
                                        ;   in Loop: Header=BB43_18 Depth=1
	add	x8, x15, #1
	cmp	x8, x11
	csinc	x15, xzr, x15, hs
	mov	w8, #2                          ; =0x2
	subs	x12, x12, #1
	b.eq	LBB43_4
LBB43_18:                               ; %bb5.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x8, x13, x15, lsl #5
	ldr	w16, [x8]
	cmp	w16, #1
	b.eq	LBB43_17
; %bb.19:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB43_18 Depth=1
	cmp	w16, #2
	b.ne	LBB43_26
; %bb.20:                               ; %bb3.i3.i.i.i
                                        ;   in Loop: Header=BB43_18 Depth=1
	ldr	x16, [x8, #8]
	cmp	x16, x1
	b.ne	LBB43_17
; %bb.21:                               ; %bb9
	mov	w11, #1                         ; =0x1
	str	w11, [x8]
	sub	x11, x14, #1
	stp	xzr, xzr, [x8, #16]
	str	xzr, [x8, #8]
	ldr	x8, [x0, #80]
	adds	x8, x8, #1
	csinv	x8, x8, xzr, lo
	stp	x11, x8, [x0, #72]
	ldr	x8, [x0, #16]
	cmp	x10, x8
	b.hs	LBB43_25
; %bb.22:                               ; %bb2.i.i
	ldr	x8, [x0, #32]
	mov	w11, #56                        ; =0x38
	madd	x10, x10, x11, x8
	ldr	x8, [x10, #40]
	cmp	x8, x9
	b.ne	LBB43_25
; %bb.23:                               ; %bb5.i.i
	ldr	x8, [x10]
	cbz	x8, LBB43_4
; %bb.24:                               ; %bb8.i.i
	strb	wzr, [x10, #24]
LBB43_25:
	mov	w0, #0                          ; =0x0
	ret
LBB43_26:
	mov	w0, #2                          ; =0x2
	ret
                                        ; -- End function
	.globl	_wf_record_store_expire$instance$b867adcf10f50f79 ; -- Begin function wf_record_store_expire$instance$b867adcf10f50f79
	.p2align	2
_wf_record_store_expire$instance$b867adcf10f50f79: ; @"wf_record_store_expire$instance$b867adcf10f50f79"
; %bb.0:                                ; %entry
	sub	sp, sp, #496
	stp	x28, x27, [sp, #400]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #416]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #432]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #448]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #464]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #480]            ; 16-byte Folded Spill
	mov	x23, x0
	ldr	x8, [x23, #88]!
	cbz	x8, LBB44_28
; %bb.1:                                ; %bb5.lr.ph
	mov	x20, x2
	mov	x21, x1
	mov	x22, x0
	mov	x19, #0                         ; =0x0
	add	x24, sp, #32
	ldp	x10, x9, [x2]
	stp	x9, x10, [sp, #16]              ; 16-byte Folded Spill
	mov	w27, #2                         ; =0x2
	mov	w28, #56                        ; =0x38
	mov	w25, #1                         ; =0x1
LBB44_2:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x22, #104]
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp, #32]
	ldr	x10, [sp, #32]
	cmp	x10, x21
	b.hi	LBB44_29
; %bb.3:                                ; %bb8
                                        ;   in Loop: Header=BB44_2 Depth=1
	ldur	x26, [x22, #16]
	subs	x2, x8, #1
	add	x8, x9, x2, lsl #5
	str	x2, [x23]
	ldp	q0, q1, [x8]
	stp	q0, q1, [sp, #368]
	b.eq	LBB44_9
; %bb.4:                                ; %bb2.i
                                        ;   in Loop: Header=BB44_2 Depth=1
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp, #368]
	ldp	q0, q1, [x8]
	stp	q0, q1, [x9]
	ldr	x8, [x9, #16]
	cmp	x8, x26
	b.hs	LBB44_8
; %bb.5:                                ; %bb2.i.i.i.i
                                        ;   in Loop: Header=BB44_2 Depth=1
	ldr	x9, [x9, #24]
	ldr	x10, [x22, #32]
	madd	x8, x8, x28, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB44_8
; %bb.6:                                ; %bb5.i.i.i.i
                                        ;   in Loop: Header=BB44_2 Depth=1
	ldr	x9, [x8]
	cbz	x9, LBB44_8
; %bb.7:                                ; %bb8.i.i.i.i
                                        ;   in Loop: Header=BB44_2 Depth=1
	str	xzr, [x8, #32]
LBB44_8:                                ; %"wf_record_report_position$instance$50c6da9371c13a22.exit.i"
                                        ;   in Loop: Header=BB44_2 Depth=1
	add	x4, x22, #16
	mov	x0, x23
	mov	x1, #0                          ; =0x0
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$2a15825f0f6e194e
LBB44_9:                                ; %"wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$2a15825f0f6e194e.exit"
                                        ;   in Loop: Header=BB44_2 Depth=1
	ldp	q0, q1, [sp, #368]
	stp	q0, q1, [x24, #32]
	str	x27, [sp, #352]
	ldur	q0, [x24, #48]
	stur	q0, [x24, #64]
	ldr	x8, [sp, #96]
	cmp	x8, x26
	b.hs	LBB44_13
; %bb.10:                               ; %bb2.i.i
                                        ;   in Loop: Header=BB44_2 Depth=1
	ldr	x10, [sp, #104]
	ldr	x9, [x22, #32]
	madd	x9, x8, x28, x9
	ldr	x8, [x9, #40]
	cmp	x8, x10
	b.ne	LBB44_13
; %bb.11:                               ; %bb5.i.i
                                        ;   in Loop: Header=BB44_2 Depth=1
	ldr	x8, [x9]
	cbz	x8, LBB44_13
; %bb.12:                               ; %bb8.i.i
                                        ;   in Loop: Header=BB44_2 Depth=1
	mov	w8, #0                          ; =0x0
	str	x27, [x9, #32]
	b	LBB44_14
LBB44_13:                               ;   in Loop: Header=BB44_2 Depth=1
	mov	w8, #1                          ; =0x1
LBB44_14:                               ; %"wf_std.collections.slab.slab_edit$instance$79794de0ddcdada2.exit"
                                        ;   in Loop: Header=BB44_2 Depth=1
	ldp	q0, q1, [x22, #64]
	stur	q0, [x24, #152]
	stur	q1, [x24, #168]
	ldr	q0, [x22, #96]
	stur	q0, [x24, #184]
	ldp	q0, q1, [x22]
	stur	q0, [x24, #88]
	stur	q1, [x24, #104]
	ldp	q0, q1, [x22, #32]
	stur	q0, [x24, #120]
	str	w8, [sp, #112]
	strh	wzr, [sp, #116]
	ldr	x8, [x22, #112]
	stur	x8, [x24, #200]
	stur	q1, [x24, #136]
	ldur	q0, [x24, #48]
	stur	q0, [x24, #208]
	ldr	x26, [sp, #120]
	ldr	x1, [sp, #72]
	str	x26, [sp, #256]
	ldur	q0, [x24, #48]
	stur	q0, [x24, #232]
	add	x2, x24, #224
	mov	x0, x22
	bl	_wf_record_store_detach$instance$50c6da9371c13a22
	ldr	x8, [x22]
	cmp	x26, x8
	b.ne	LBB44_21
; %bb.15:                               ; %bb3.i.i
                                        ;   in Loop: Header=BB44_2 Depth=1
	ldr	x8, [sp, #264]
	ldur	x9, [x22, #16]
	cmp	x8, x9
	b.hs	LBB44_22
; %bb.16:                               ; %bb2.i.i.i
                                        ;   in Loop: Header=BB44_2 Depth=1
	ldr	x10, [sp, #272]
	ldr	x9, [x22, #32]
	madd	x11, x8, x28, x9
	ldr	x12, [x11, #40]
	cmp	x12, x10
	b.ne	LBB44_22
; %bb.17:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB44_2 Depth=1
	ldr	x12, [x11]
	cbz	x12, LBB44_22
; %bb.18:                               ; %bb2.i7
                                        ;   in Loop: Header=BB44_2 Depth=1
	ldrb	w13, [x11, #24]
	ldr	x14, [x11, #32]
	and	w13, w13, #0x1
	strb	w13, [sp, #360]
	ldrb	w15, [x22, #8]
	cmp	x14, #2
	csinc	w13, w13, wzr, eq
	tbz	w15, #0, LBB44_25
; %bb.19:                               ; %bb2.i7
                                        ;   in Loop: Header=BB44_2 Depth=1
	tbz	w13, #0, LBB44_25
; %bb.20:                               ;   in Loop: Header=BB44_2 Depth=1
	mov	w8, #9                          ; =0x9
	b	LBB44_23
LBB44_21:                               ;   in Loop: Header=BB44_2 Depth=1
	mov	w8, #4                          ; =0x4
	b	LBB44_23
LBB44_22:                               ; %bb5.i.i6
                                        ;   in Loop: Header=BB44_2 Depth=1
	mov	w8, #3                          ; =0x3
LBB44_23:                               ; %"wf_record_store_delete$instance$50c6da9371c13a22.exit.thread"
                                        ;   in Loop: Header=BB44_2 Depth=1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x24, #256]
	str	w25, [sp, #280]
	str	w8, [sp, #284]
LBB44_24:                               ; %bb9
                                        ;   in Loop: Header=BB44_2 Depth=1
	ldr	x8, [x23]
	cbnz	x8, LBB44_2
	b	LBB44_29
LBB44_25:                               ; %bb8.i.i8
                                        ;   in Loop: Header=BB44_2 Depth=1
	sub	x12, x12, #1
	add	x13, x11, x12, lsl #5
	str	x12, [x11]
	ldur	q0, [x13, #8]
	ldur	q1, [x13, #24]
	stp	q0, q1, [sp, #368]
	cbnz	x10, LBB44_27
; %bb.26:                               ; %bb11.i.i
                                        ;   in Loop: Header=BB44_2 Depth=1
	ldr	x10, [x22, #40]
	madd	x9, x8, x28, x9
	stp	x25, x10, [x9, #40]
	str	x8, [x22, #40]
LBB44_27:                               ; %bb10
                                        ;   in Loop: Header=BB44_2 Depth=1
	str	xzr, [sp, #280]
	ldp	q0, q1, [sp, #368]
	stp	q0, q1, [x24, #256]
	ldp	q0, q1, [x24, #256]
	stp	q0, q1, [x24, #288]
	ldr	x8, [sp, #328]
	ldp	x10, x9, [sp, #16]              ; 16-byte Folded Reload
	add	x9, x9, #1
	add	x10, x10, x8
	stp	x10, x9, [sp, #16]              ; 16-byte Folded Spill
	stp	x9, x10, [x20]
	add	x19, x19, #1
	b	LBB44_24
LBB44_28:
	mov	x19, #0                         ; =0x0
LBB44_29:                               ; %bb2
	mov	x0, x19
	ldp	x29, x30, [sp, #480]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #464]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #448]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #432]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #416]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #400]            ; 16-byte Folded Reload
	add	sp, sp, #496
	ret
                                        ; -- End function
	.globl	_wf_record_store_free$instance$b867adcf10f50f79 ; -- Begin function wf_record_store_free$instance$b867adcf10f50f79
	.p2align	2
_wf_record_store_free$instance$b867adcf10f50f79: ; @"wf_record_store_free$instance$b867adcf10f50f79"
; %bb.0:                                ; %entry
	sub	sp, sp, #112
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x20, x1
	ldp	x23, x22, [x0, #16]
	ldr	x19, [x0, #32]
	ldr	x8, [x0, #56]
	ldp	x24, x21, [x0, #96]
	cbz	x8, LBB45_2
; %bb.1:                                ; %slots.release.drop.6.i.i
	ldr	x0, [x0, #64]
	bl	_free
LBB45_2:                                ; %"wf_std.collections.hash_map.hash_map_free$instance$d405037d8db33b6d.exit"
	cbz	x24, LBB45_4
; %bb.3:                                ; %slots.release.drop.6.i.i2
	mov	x0, x21
	bl	_free
LBB45_4:                                ; %"wf_collections.priority_queue.priority_queue_free$instance$272f87483c69b364.exit"
	cbz	x23, LBB45_12
; %bb.5:                                ; %bb5.lr.ph.i
	ldr	q0, [x20]
	ands	x9, x23, #0x7
	b.eq	LBB45_10
; %bb.6:                                ; %bb5.i.prol.preheader
	mov	w8, #56                         ; =0x38
	madd	x8, x23, x8, x19
	sub	x10, x8, #56
	mov	x11, sp
	mov	w8, #1                          ; =0x1
	dup.2d	v1, x8
	mov	x8, x23
	b	LBB45_8
LBB45_7:                                ; %bb6.i.prol
                                        ;   in Loop: Header=BB45_8 Depth=1
	sub	x10, x10, #56
	sub	x8, x8, #1
	sub	x9, x9, #1
	cbz	x9, LBB45_11
LBB45_8:                                ; %bb5.i.prol
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q2, q3, [x10]
	stp	q2, q3, [sp]
	ldr	x12, [x10, #32]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB45_7
; %bb.9:                                ; %bb7.i.prol
                                        ;   in Loop: Header=BB45_8 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x11, x12, lsl #5
	add	x12, x12, #16
	mov.16b	v2, v1
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
	b	LBB45_7
LBB45_10:
	mov	x8, x23
LBB45_11:                               ; %bb5.i.prol.loopexit
	cmp	x23, #8
	b.hs	LBB45_15
LBB45_12:                               ; %bb4.i
	cbz	x22, LBB45_14
; %bb.13:                               ; %slots.release.drop.6.i.i8
	mov	x0, x19
	bl	_free
LBB45_14:                               ; %"wf_std.collections.slab.slab_free$instance$9c203cb0f3c40552.exit"
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB45_15:                               ; %bb5.lr.ph.i.new
	mov	w9, #56                         ; =0x38
	madd	x9, x8, x9, x19
	sub	x9, x9, #224
	mov	x10, sp
	mov	w11, #1                         ; =0x1
	dup.2d	v1, x11
	b	LBB45_17
LBB45_16:                               ; %bb6.i.7
                                        ;   in Loop: Header=BB45_17 Depth=1
	sub	x9, x9, #448
	sub	x8, x8, #8
	cbz	x8, LBB45_12
LBB45_17:                               ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	ldur	q2, [x9, #168]
	ldur	q3, [x9, #184]
	stp	q2, q3, [sp]
	ldr	x12, [x9, #200]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB45_19
; %bb.18:                               ; %bb7.i
                                        ;   in Loop: Header=BB45_17 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x10, x12, lsl #5
	add	x12, x12, #16
	dup.2d	v2, x11
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
LBB45_19:                               ; %bb6.i
                                        ;   in Loop: Header=BB45_17 Depth=1
	ldp	q2, q3, [x9, #112]
	stp	q2, q3, [sp]
	ldr	x12, [x9, #144]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB45_21
; %bb.20:                               ; %bb7.i.1
                                        ;   in Loop: Header=BB45_17 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x10, x12, lsl #5
	add	x12, x12, #16
	dup.2d	v2, x11
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
LBB45_21:                               ; %bb6.i.1
                                        ;   in Loop: Header=BB45_17 Depth=1
	ldur	q2, [x9, #56]
	ldur	q3, [x9, #72]
	stp	q2, q3, [sp]
	ldr	x12, [x9, #88]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB45_23
; %bb.22:                               ; %bb7.i.2
                                        ;   in Loop: Header=BB45_17 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x10, x12, lsl #5
	add	x12, x12, #16
	dup.2d	v2, x11
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
LBB45_23:                               ; %bb6.i.2
                                        ;   in Loop: Header=BB45_17 Depth=1
	ldp	q2, q3, [x9]
	stp	q2, q3, [sp]
	ldr	x12, [x9, #32]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB45_25
; %bb.24:                               ; %bb7.i.3
                                        ;   in Loop: Header=BB45_17 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x10, x12, lsl #5
	add	x12, x12, #16
	dup.2d	v2, x11
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
LBB45_25:                               ; %bb6.i.3
                                        ;   in Loop: Header=BB45_17 Depth=1
	ldur	q2, [x9, #-56]
	ldur	q3, [x9, #-40]
	stp	q2, q3, [sp]
	ldur	x12, [x9, #-24]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB45_27
; %bb.26:                               ; %bb7.i.4
                                        ;   in Loop: Header=BB45_17 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x10, x12, lsl #5
	add	x12, x12, #16
	dup.2d	v2, x11
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
LBB45_27:                               ; %bb6.i.4
                                        ;   in Loop: Header=BB45_17 Depth=1
	ldp	q2, q3, [x9, #-112]
	stp	q2, q3, [sp]
	ldur	x12, [x9, #-80]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB45_29
; %bb.28:                               ; %bb7.i.5
                                        ;   in Loop: Header=BB45_17 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x10, x12, lsl #5
	add	x12, x12, #16
	dup.2d	v2, x11
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
LBB45_29:                               ; %bb6.i.5
                                        ;   in Loop: Header=BB45_17 Depth=1
	ldur	q2, [x9, #-168]
	ldur	q3, [x9, #-152]
	stp	q2, q3, [sp]
	ldur	x12, [x9, #-136]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB45_31
; %bb.30:                               ; %bb7.i.6
                                        ;   in Loop: Header=BB45_17 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x10, x12, lsl #5
	add	x12, x12, #16
	dup.2d	v2, x11
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
LBB45_31:                               ; %bb6.i.6
                                        ;   in Loop: Header=BB45_17 Depth=1
	ldp	q2, q3, [x9, #-224]
	stp	q2, q3, [sp]
	ldur	x12, [x9, #-192]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB45_16
; %bb.32:                               ; %bb7.i.7
                                        ;   in Loop: Header=BB45_17 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x10, x12, lsl #5
	add	x12, x12, #16
	mov.16b	v2, v1
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
	b	LBB45_16
                                        ; -- End function
	.globl	_wf_record_store_new$instance$5ffcb0796f3480f6 ; -- Begin function wf_record_store_new$instance$5ffcb0796f3480f6
	.p2align	2
_wf_record_store_new$instance$5ffcb0796f3480f6: ; @"wf_record_store_new$instance$5ffcb0796f3480f6"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #208
	stp	x26, x25, [sp, #128]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #144]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #160]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #176]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 208
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x6
	mov	x22, x5
	mov	x24, x4
	mov	x25, x3
	mov	x21, x2
	mov	x23, x1
	mov	x20, x0
	cbz	x3, LBB46_2
; %bb.1:                                ; %window.payload.allocate.v1.i.i.i
	lsl	x8, x25, #6
	sub	x0, x8, x25, lsl #3
	bl	_malloc
	cbnz	x0, LBB46_3
	b	LBB46_10
LBB46_2:
Lloh134:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh135:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB46_3:                                ; %"wf_std.collections.slab.slab_new$instance$85bcb7bfdda43087.exit"
	stp	xzr, x25, [sp]
	stp	x0, x25, [sp, #16]
	cbz	x24, LBB46_7
; %bb.4:                                ; %window.payload.allocate.v1.i.i.i2
	lsl	x0, x24, #5
	bl	_malloc
	cbz	x0, LBB46_10
; %bb.5:                                ; %bb5.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #8
LBB46_6:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x9, #8]
	str	xzr, [x9], #32
	cmp	x24, x8
	b.ne	LBB46_6
	b	LBB46_8
LBB46_7:
Lloh136:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh137:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB46_8:                                ; %"wf_std.collections.hash_map.hash_map_new$instance$bd5728c249450a41.exit"
	stp	x24, x24, [sp, #32]
	stp	xzr, xzr, [sp, #56]
	str	x0, [sp, #48]
	cbz	x22, LBB46_11
; %bb.9:                                ; %window.payload.allocate.v1.i.i
	lsl	x0, x22, #5
	bl	_malloc
	cbnz	x0, LBB46_12
LBB46_10:                               ; %window.block.oom.v1.i.i.i
	bl	l_wf_resource_abort
LBB46_11:
Lloh138:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh139:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB46_12:                               ; %"wf_box_slots_new$instance$57d99a800120d980.exit"
	mov	x8, sp
	stp	xzr, x22, [sp, #72]
	stp	x0, xzr, [sp, #88]
	stp	x22, x0, [sp, #104]
	stp	x23, xzr, [x20]
	and	w9, w21, #0x1
	strb	w9, [x20, #8]
	ldp	q0, q1, [sp]
	stp	q0, q1, [x20, #16]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x20, #48]
	ldur	x8, [x8, #64]
	str	x8, [x20, #80]
	ldr	q0, [sp, #96]
	stur	q0, [x20, #88]
	stp	x0, x19, [x20, #104]
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #176]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #160]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #144]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
	.loh AdrpAdd	Lloh134, Lloh135
	.loh AdrpAdd	Lloh136, Lloh137
	.loh AdrpAdd	Lloh138, Lloh139
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_indexed_word_insert$instance$82e8a0addfd772af
lCPI47_0:
	.quad	1                               ; 0x1
	.quad	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_indexed_word_insert$instance$82e8a0addfd772af
	.p2align	2
_wf_indexed_word_insert$instance$82e8a0addfd772af: ; @"wf_indexed_word_insert$instance$82e8a0addfd772af"
; %bb.0:                                ; %entry
	sub	sp, sp, #16
	mov	x8, x2
	mov	x9, x1
	strb	wzr, [sp, #8]
	ldr	x1, [x0, #40]
	ldr	x10, [x0, #16]
	cmp	x1, x10
	b.hs	LBB47_4
; %bb.1:                                ; %bb2.i.i.i
	ldr	x10, [x0, #32]
	mov	w11, #56                        ; =0x38
	madd	x10, x1, x11, x10
	ldr	x11, [x10]
	cbnz	x11, LBB47_7
; %bb.2:                                ; %bb5.i.i.i
	ldr	x2, [x10, #40]
	cmp	x2, #1
	b.hi	LBB47_7
; %bb.3:                                ; %bb8.i.i.i
	ldr	x9, [x10, #48]
	stp	x8, x3, [x10, #8]
	strb	wzr, [x10, #24]
	mov	w11, #1                         ; =0x1
	str	x11, [x10, #32]
	str	x11, [x10]
	str	x9, [x0, #40]
	b	LBB47_6
LBB47_4:                                ; %bb3.i.i.i
	ldr	x11, [x0, #24]
	cmp	x10, x11
	b.hs	LBB47_7
; %bb.5:                                ; %bb11.i.i.i
	mov	x2, #0                          ; =0x0
	ldr	x9, [x0, #32]
	mov	w11, #56                        ; =0x38
	madd	x9, x10, x11, x9
	mov	w11, #1                         ; =0x1
	stp	x11, x8, [x9]
	str	x3, [x9, #16]
	strb	wzr, [x9, #24]
Lloh140:
	adrp	x8, lCPI47_0@PAGE
Lloh141:
	ldr	q0, [x8, lCPI47_0@PAGEOFF]
	str	q0, [x9, #32]
	str	x1, [x9, #48]
	add	x8, x10, #1
	str	x8, [x0, #16]
	mov	x1, x10
LBB47_6:                                ; %bb8.i.i.i
	ldr	x0, [x0]
	add	sp, sp, #16
	ret
LBB47_7:                                ; %bb2.i
	mov	x2, #0                          ; =0x0
	ldr	x8, [x9, #1304]
	add	x8, x8, #1
	str	x8, [x9, #1304]
	ldr	x0, [x0]
	mov	w1, #1                          ; =0x1
	add	sp, sp, #16
	ret
	.loh AdrpLdr	Lloh140, Lloh141
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function wf_record_store_delete$instance$5ffcb0796f3480f6
lCPI48_0:
	.long	1                               ; 0x1
	.long	9                               ; 0x9
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_record_store_delete$instance$5ffcb0796f3480f6
	.p2align	2
_wf_record_store_delete$instance$5ffcb0796f3480f6: ; @"wf_record_store_delete$instance$5ffcb0796f3480f6"
; %bb.0:                                ; %entry
	sub	sp, sp, #48
	ldr	x8, [x2]
	ldr	x9, [x1]
	cmp	x8, x9
	b.ne	LBB48_10
; %bb.1:                                ; %bb3.i
	ldr	x8, [x2, #8]
	ldr	x9, [x1, #16]
	cmp	x8, x9
	b.hs	LBB48_11
; %bb.2:                                ; %bb2.i.i
	ldr	x10, [x2, #16]
	ldr	x9, [x1, #32]
	mov	w11, #56                        ; =0x38
	madd	x11, x8, x11, x9
	ldr	x12, [x11, #40]
	cmp	x12, x10
	b.ne	LBB48_11
; %bb.3:                                ; %bb5.i.i
	ldr	x12, [x11]
	cbz	x12, LBB48_11
; %bb.4:                                ; %bb2
	ldrb	w14, [x11, #24]
	ldr	x13, [x11, #32]
	and	w14, w14, #0x1
	strb	w14, [sp, #8]
	ldrb	w15, [x1, #8]
	tbz	w15, #0, LBB48_7
; %bb.5:                                ; %bb5
	cbnz	w14, LBB48_13
; %bb.6:                                ; %bb9
	cmp	x13, #1
	b.ne	LBB48_13
LBB48_7:                                ; %bb8.i
	sub	x12, x12, #1
	add	x13, x11, x12, lsl #5
	str	x12, [x11]
	ldur	q0, [x13, #8]
	ldur	q1, [x13, #24]
	stp	q0, q1, [sp, #16]
	cbnz	x10, LBB48_9
; %bb.8:                                ; %bb11.i
	mov	w10, #56                        ; =0x38
	madd	x9, x8, x10, x9
	ldr	x10, [x1, #40]
	mov	w11, #1                         ; =0x1
	stp	x11, x10, [x9, #40]
	str	x8, [x1, #40]
LBB48_9:                                ; %bb13
	str	xzr, [x0]
	ldp	q0, q1, [sp, #16]
	stur	q0, [x0, #8]
	stur	q1, [x0, #24]
	add	sp, sp, #48
	ret
LBB48_10:
	mov	w8, #4                          ; =0x4
	b	LBB48_12
LBB48_11:                               ; %bb5.i
	mov	w8, #3                          ; =0x3
LBB48_12:                               ; %bb3
	movi.2d	v0, #0000000000000000
	stur	q0, [x0, #24]
	stur	q0, [x0, #8]
	mov	w9, #1                          ; =0x1
	stp	w9, w8, [x0]
	add	sp, sp, #48
	ret
LBB48_13:                               ; %bb8
	movi.2d	v0, #0000000000000000
	stur	q0, [x0, #24]
	stur	q0, [x0, #8]
Lloh142:
	adrp	x8, lCPI48_0@PAGE
Lloh143:
	ldr	d0, [x8, lCPI48_0@PAGEOFF]
	str	d0, [x0]
	add	sp, sp, #48
	ret
	.loh AdrpLdr	Lloh142, Lloh143
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_record_store_insert$instance$5ffcb0796f3480f6
lCPI49_0:
	.quad	1                               ; 0x1
	.quad	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_record_store_insert$instance$5ffcb0796f3480f6
	.p2align	2
_wf_record_store_insert$instance$5ffcb0796f3480f6: ; @"wf_record_store_insert$instance$5ffcb0796f3480f6"
; %bb.0:                                ; %entry
	sub	sp, sp, #16
	strb	wzr, [sp, #8]
	ldr	x8, [x1, #40]
	ldr	x10, [x1, #16]
	cmp	x8, x10
	b.hs	LBB49_4
; %bb.1:                                ; %bb2.i
	ldr	x9, [x1, #32]
	mov	w10, #56                        ; =0x38
	madd	x10, x8, x10, x9
	ldr	x9, [x10]
	cbnz	x9, LBB49_7
; %bb.2:                                ; %bb5.i
	ldr	x9, [x10, #40]
	cmp	x9, #1
	b.hi	LBB49_7
; %bb.3:                                ; %bb8.i
	ldr	x11, [x10, #48]
	stp	x2, x3, [x10, #8]
	strb	wzr, [x10, #24]
	mov	w12, #1                         ; =0x1
	str	x12, [x10, #32]
	str	x12, [x10]
	str	x11, [x1, #40]
	b	LBB49_6
LBB49_4:                                ; %bb3.i
	ldr	x9, [x1, #24]
	cmp	x10, x9
	b.hs	LBB49_7
; %bb.5:                                ; %bb11.i
	mov	x9, #0                          ; =0x0
	ldr	x11, [x1, #32]
	mov	w12, #56                        ; =0x38
	madd	x11, x10, x12, x11
	mov	w12, #1                         ; =0x1
	stp	x12, x2, [x11]
	str	x3, [x11, #16]
	strb	wzr, [x11, #24]
Lloh144:
	adrp	x12, lCPI49_0@PAGE
Lloh145:
	ldr	q0, [x12, lCPI49_0@PAGEOFF]
	str	q0, [x11, #32]
	str	x8, [x11, #48]
	add	x8, x10, #1
	str	x8, [x1, #16]
	mov	x8, x10
LBB49_6:                                ; %bb1
	ldr	x10, [x1]
	stp	xzr, x10, [x0]
	stp	x8, x9, [x0, #16]
	add	sp, sp, #16
	ret
LBB49_7:                                ; %bb2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	str	x3, [x0, #8]
	add	sp, sp, #16
	ret
	.loh AdrpLdr	Lloh144, Lloh145
                                        ; -- End function
	.globl	_wf_record_store_schedule$instance$5ffcb0796f3480f6 ; -- Begin function wf_record_store_schedule$instance$5ffcb0796f3480f6
	.p2align	2
_wf_record_store_schedule$instance$5ffcb0796f3480f6: ; @"wf_record_store_schedule$instance$5ffcb0796f3480f6"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #272
	stp	x28, x27, [sp, #240]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #256]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 272
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w27, -24
	.cfi_offset w28, -32
	ldr	q0, [x1]
	str	q0, [sp]
	ldr	x8, [x1, #16]
	str	x8, [sp, #16]
	ldr	x9, [sp]
	ldr	x10, [x0]
	cmp	x9, x10
	b.ne	LBB50_6
; %bb.1:                                ; %bb3.i
	ldr	x9, [sp, #8]
	mov	x4, x0
	ldr	x10, [x4, #16]!
	cmp	x9, x10
	b.hs	LBB50_7
; %bb.2:                                ; %bb2.i.i
	ldr	x10, [x0, #32]
	mov	w11, #56                        ; =0x38
	madd	x12, x9, x11, x10
	ldr	x10, [x12, #40]
	cmp	x10, x8
	b.ne	LBB50_7
; %bb.3:                                ; %bb5.i.i
	ldr	x10, [x12]
	cbz	x10, LBB50_7
; %bb.4:                                ; %bb2
	mov	x11, sp
	ldr	x10, [x12, #8]
	ldrb	w13, [x12, #24]
	ldr	x12, [x12, #32]
	and	w13, w13, #0x1
	strb	w13, [sp, #232]
	stp	xzr, x10, [sp, #24]
	strb	w13, [sp, #40]
	stur	wzr, [sp, #41]
	str	wzr, [sp, #44]
	str	x12, [sp, #48]
	stur	x12, [x11, #72]
	ldr	q0, [sp, #32]
	stur	q0, [x11, #56]
	ldr	x13, [sp, #72]
	cmp	x13, #1
	b.ne	LBB50_9
; %bb.5:                                ; %bb6
	ldr	x8, [sp, #56]
	ldur	q0, [x1, #8]
	stur	q0, [x11, #104]
	stp	x2, x8, [sp, #120]
	stur	q0, [sp, #136]
	mov	x8, x0
	add	x0, x11, #152
	add	x1, x8, #88
	add	x2, x11, #120
	add	x3, x11, #224
	bl	_wf_collections.priority_queue.priority_queue_push_indexed$instance$17afb96af21633a2
	ldr	w8, [sp, #152]
	mov	w9, #6                          ; =0x6
	cmp	w8, #0
	csel	w0, wzr, w9, eq
	b	LBB50_8
LBB50_6:
	mov	w0, #4                          ; =0x4
	b	LBB50_8
LBB50_7:                                ; %bb5.i
	mov	w0, #3                          ; =0x3
LBB50_8:                                ; %common.ret
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #240]            ; 16-byte Folded Reload
	add	sp, sp, #272
	ret
LBB50_9:                                ; %bb2.i.i4
	cmp	x12, #1
	b.ne	LBB50_11
; %bb.10:
	mov	w0, #7                          ; =0x7
	b	LBB50_8
LBB50_11:                               ; %bb6.i.i
	ldr	x11, [x0, #88]
	cmp	x12, x11
	b.hs	LBB50_14
; %bb.12:                               ; %bb8.i.i
	ldr	x11, [x0, #104]
	add	x11, x11, x12, lsl #5
	ldp	x12, x13, [x11, #16]
	mov	w0, #8                          ; =0x8
	cmp	x12, x9
	ccmp	x13, x8, #0, eq
	b.ne	LBB50_8
; %bb.13:                               ; %bb11.i.i
	ldr	x8, [x11, #8]
	cmp	x8, x10
	csinc	w0, w0, wzr, ne
	b	LBB50_8
LBB50_14:
	mov	w0, #8                          ; =0x8
	b	LBB50_8
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_record_store_free$instance$e0a210c961ceece4 ; -- Begin function wf_record_store_free$instance$e0a210c961ceece4
	.p2align	2
_wf_record_store_free$instance$e0a210c961ceece4: ; @"wf_record_store_free$instance$e0a210c961ceece4"
; %bb.0:                                ; %entry
	sub	sp, sp, #112
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x20, x1
	ldp	x23, x22, [x0, #16]
	ldr	x19, [x0, #32]
	ldr	x8, [x0, #56]
	ldp	x24, x21, [x0, #96]
	cbz	x8, LBB51_2
; %bb.1:                                ; %slots.release.drop.6.i.i
	ldr	x0, [x0, #64]
	bl	_free
LBB51_2:                                ; %"wf_std.collections.hash_map.hash_map_free$instance$49bcdf956259ee48.exit"
	cbz	x24, LBB51_4
; %bb.3:                                ; %slots.release.drop.6.i.i2
	mov	x0, x21
	bl	_free
LBB51_4:                                ; %"wf_collections.priority_queue.priority_queue_free$instance$bc1a7c25f6fdb27b.exit"
	cbz	x23, LBB51_12
; %bb.5:                                ; %bb5.lr.ph.i
	ldr	q0, [x20]
	ands	x9, x23, #0x7
	b.eq	LBB51_10
; %bb.6:                                ; %bb5.i.prol.preheader
	mov	w8, #56                         ; =0x38
	madd	x8, x23, x8, x19
	sub	x10, x8, #56
	mov	x11, sp
	mov	w8, #1                          ; =0x1
	dup.2d	v1, x8
	mov	x8, x23
	b	LBB51_8
LBB51_7:                                ; %bb6.i.prol
                                        ;   in Loop: Header=BB51_8 Depth=1
	sub	x10, x10, #56
	sub	x8, x8, #1
	sub	x9, x9, #1
	cbz	x9, LBB51_11
LBB51_8:                                ; %bb5.i.prol
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q2, q3, [x10]
	stp	q2, q3, [sp]
	ldr	x12, [x10, #32]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB51_7
; %bb.9:                                ; %bb7.i.prol
                                        ;   in Loop: Header=BB51_8 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x11, x12, lsl #5
	add	x12, x12, #16
	mov.16b	v2, v1
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
	b	LBB51_7
LBB51_10:
	mov	x8, x23
LBB51_11:                               ; %bb5.i.prol.loopexit
	cmp	x23, #8
	b.hs	LBB51_15
LBB51_12:                               ; %bb4.i
	cbz	x22, LBB51_14
; %bb.13:                               ; %slots.release.drop.6.i.i8
	mov	x0, x19
	bl	_free
LBB51_14:                               ; %"wf_std.collections.slab.slab_free$instance$195c79590f9dde23.exit"
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB51_15:                               ; %bb5.lr.ph.i.new
	mov	w9, #56                         ; =0x38
	madd	x9, x8, x9, x19
	sub	x9, x9, #224
	mov	x10, sp
	mov	w11, #1                         ; =0x1
	dup.2d	v1, x11
	b	LBB51_17
LBB51_16:                               ; %bb6.i.7
                                        ;   in Loop: Header=BB51_17 Depth=1
	sub	x9, x9, #448
	sub	x8, x8, #8
	cbz	x8, LBB51_12
LBB51_17:                               ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	ldur	q2, [x9, #168]
	ldur	q3, [x9, #184]
	stp	q2, q3, [sp]
	ldr	x12, [x9, #200]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB51_19
; %bb.18:                               ; %bb7.i
                                        ;   in Loop: Header=BB51_17 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x10, x12, lsl #5
	add	x12, x12, #16
	dup.2d	v2, x11
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
LBB51_19:                               ; %bb6.i
                                        ;   in Loop: Header=BB51_17 Depth=1
	ldp	q2, q3, [x9, #112]
	stp	q2, q3, [sp]
	ldr	x12, [x9, #144]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB51_21
; %bb.20:                               ; %bb7.i.1
                                        ;   in Loop: Header=BB51_17 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x10, x12, lsl #5
	add	x12, x12, #16
	dup.2d	v2, x11
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
LBB51_21:                               ; %bb6.i.1
                                        ;   in Loop: Header=BB51_17 Depth=1
	ldur	q2, [x9, #56]
	ldur	q3, [x9, #72]
	stp	q2, q3, [sp]
	ldr	x12, [x9, #88]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB51_23
; %bb.22:                               ; %bb7.i.2
                                        ;   in Loop: Header=BB51_17 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x10, x12, lsl #5
	add	x12, x12, #16
	dup.2d	v2, x11
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
LBB51_23:                               ; %bb6.i.2
                                        ;   in Loop: Header=BB51_17 Depth=1
	ldp	q2, q3, [x9]
	stp	q2, q3, [sp]
	ldr	x12, [x9, #32]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB51_25
; %bb.24:                               ; %bb7.i.3
                                        ;   in Loop: Header=BB51_17 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x10, x12, lsl #5
	add	x12, x12, #16
	dup.2d	v2, x11
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
LBB51_25:                               ; %bb6.i.3
                                        ;   in Loop: Header=BB51_17 Depth=1
	ldur	q2, [x9, #-56]
	ldur	q3, [x9, #-40]
	stp	q2, q3, [sp]
	ldur	x12, [x9, #-24]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB51_27
; %bb.26:                               ; %bb7.i.4
                                        ;   in Loop: Header=BB51_17 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x10, x12, lsl #5
	add	x12, x12, #16
	dup.2d	v2, x11
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
LBB51_27:                               ; %bb6.i.4
                                        ;   in Loop: Header=BB51_17 Depth=1
	ldp	q2, q3, [x9, #-112]
	stp	q2, q3, [sp]
	ldur	x12, [x9, #-80]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB51_29
; %bb.28:                               ; %bb7.i.5
                                        ;   in Loop: Header=BB51_17 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x10, x12, lsl #5
	add	x12, x12, #16
	dup.2d	v2, x11
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
LBB51_29:                               ; %bb6.i.5
                                        ;   in Loop: Header=BB51_17 Depth=1
	ldur	q2, [x9, #-168]
	ldur	q3, [x9, #-152]
	stp	q2, q3, [sp]
	ldur	x12, [x9, #-136]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB51_31
; %bb.30:                               ; %bb7.i.6
                                        ;   in Loop: Header=BB51_17 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x10, x12, lsl #5
	add	x12, x12, #16
	dup.2d	v2, x11
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
LBB51_31:                               ; %bb6.i.6
                                        ;   in Loop: Header=BB51_17 Depth=1
	ldp	q2, q3, [x9, #-224]
	stp	q2, q3, [sp]
	ldur	x12, [x9, #-192]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB51_16
; %bb.32:                               ; %bb7.i.7
                                        ;   in Loop: Header=BB51_17 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x10, x12, lsl #5
	add	x12, x12, #16
	mov.16b	v2, v1
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
	b	LBB51_16
                                        ; -- End function
	.globl	_wf_record_store_new$instance$aa2364d9cd38ac5f ; -- Begin function wf_record_store_new$instance$aa2364d9cd38ac5f
	.p2align	2
_wf_record_store_new$instance$aa2364d9cd38ac5f: ; @"wf_record_store_new$instance$aa2364d9cd38ac5f"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #208
	stp	x26, x25, [sp, #128]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #144]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #160]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #176]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 208
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x6
	mov	x22, x5
	mov	x24, x4
	mov	x25, x3
	mov	x21, x2
	mov	x23, x1
	mov	x20, x0
	cbz	x3, LBB52_2
; %bb.1:                                ; %window.payload.allocate.v1.i.i.i
	lsl	x8, x25, #6
	sub	x0, x8, x25, lsl #3
	bl	_malloc
	cbnz	x0, LBB52_3
	b	LBB52_10
LBB52_2:
Lloh146:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh147:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB52_3:                                ; %"wf_std.collections.slab.slab_new$instance$4283ac555539d10e.exit"
	stp	xzr, x25, [sp]
	stp	x0, x25, [sp, #16]
	cbz	x24, LBB52_7
; %bb.4:                                ; %window.payload.allocate.v1.i.i.i2
	lsl	x0, x24, #5
	bl	_malloc
	cbz	x0, LBB52_10
; %bb.5:                                ; %bb5.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #8
LBB52_6:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x9, #8]
	str	xzr, [x9], #32
	cmp	x24, x8
	b.ne	LBB52_6
	b	LBB52_8
LBB52_7:
Lloh148:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh149:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB52_8:                                ; %"wf_std.collections.hash_map.hash_map_new$instance$56bab2225b172a73.exit"
	stp	x24, x24, [sp, #32]
	stp	xzr, xzr, [sp, #56]
	str	x0, [sp, #48]
	cbz	x22, LBB52_11
; %bb.9:                                ; %window.payload.allocate.v1.i.i
	lsl	x0, x22, #5
	bl	_malloc
	cbnz	x0, LBB52_12
LBB52_10:                               ; %window.block.oom.v1.i.i.i
	bl	l_wf_resource_abort
LBB52_11:
Lloh150:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh151:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB52_12:                               ; %"wf_box_slots_new$instance$57d99a800120d980.exit"
	mov	x8, sp
	stp	xzr, x22, [sp, #72]
	stp	x0, xzr, [sp, #88]
	stp	x22, x0, [sp, #104]
	stp	x23, xzr, [x20]
	and	w9, w21, #0x1
	strb	w9, [x20, #8]
	ldp	q0, q1, [sp]
	stp	q0, q1, [x20, #16]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x20, #48]
	ldur	x8, [x8, #64]
	str	x8, [x20, #80]
	ldr	q0, [sp, #96]
	stur	q0, [x20, #88]
	stp	x0, x19, [x20, #104]
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #176]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #160]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #144]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
	.loh AdrpAdd	Lloh146, Lloh147
	.loh AdrpAdd	Lloh148, Lloh149
	.loh AdrpAdd	Lloh150, Lloh151
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_record_store_insert$instance$aa2364d9cd38ac5f ; -- Begin function wf_record_store_insert$instance$aa2364d9cd38ac5f
	.p2align	2
_wf_record_store_insert$instance$aa2364d9cd38ac5f: ; @"wf_record_store_insert$instance$aa2364d9cd38ac5f"
; %bb.0:                                ; %entry
	sub	sp, sp, #16
	strb	wzr, [sp, #8]
	ldr	x8, [x1, #40]
	ldr	x9, [x1, #16]
	cmp	x8, x9
	b.hs	LBB53_4
; %bb.1:                                ; %bb2.i
	ldr	x9, [x1, #32]
	mov	w10, #56                        ; =0x38
	madd	x9, x8, x10, x9
	ldr	x10, [x9]
	cbnz	x10, LBB53_7
; %bb.2:                                ; %bb5.i
	ldr	x10, [x9, #40]
	cbnz	x10, LBB53_7
; %bb.3:                                ; %bb8.i
	ldr	x10, [x9, #48]
	stp	x2, x3, [x9, #8]
	strb	wzr, [x9, #24]
	str	xzr, [x9, #32]
	mov	w11, #1                         ; =0x1
	str	x11, [x9]
	str	x10, [x1, #40]
	b	LBB53_6
LBB53_4:                                ; %bb3.i
	ldr	x10, [x1, #24]
	cmp	x9, x10
	b.hs	LBB53_7
; %bb.5:                                ; %bb11.i
	ldr	x10, [x1, #32]
	mov	w11, #56                        ; =0x38
	madd	x10, x9, x11, x10
	mov	w11, #1                         ; =0x1
	stp	x11, x2, [x10]
	str	x3, [x10, #16]
	strb	wzr, [x10, #24]
	stp	xzr, xzr, [x10, #32]
	str	x8, [x10, #48]
	add	x8, x9, #1
	str	x8, [x1, #16]
	mov	x8, x9
LBB53_6:                                ; %bb1
	ldr	x9, [x1]
	stp	xzr, x9, [x0]
	stp	x8, xzr, [x0, #16]
	add	sp, sp, #16
	ret
LBB53_7:                                ; %bb2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	str	x3, [x0, #8]
	add	sp, sp, #16
	ret
                                        ; -- End function
	.globl	_wf_record_store_expire$instance$07ca9210fae40158 ; -- Begin function wf_record_store_expire$instance$07ca9210fae40158
	.p2align	2
_wf_record_store_expire$instance$07ca9210fae40158: ; @"wf_record_store_expire$instance$07ca9210fae40158"
; %bb.0:                                ; %entry
	sub	sp, sp, #480
	stp	x28, x27, [sp, #384]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #400]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #416]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #432]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #448]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #464]            ; 16-byte Folded Spill
	mov	x23, x0
	ldr	x8, [x23, #88]!
	cbz	x8, LBB54_26
; %bb.1:                                ; %bb5.lr.ph
	mov	x20, x2
	mov	x21, x1
	mov	x22, x0
	mov	x19, #0                         ; =0x0
	add	x24, sp, #16
	ldp	x9, x26, [x2]
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	mov	w27, #56                        ; =0x38
	mov	w28, #1                         ; =0x1
LBB54_2:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x22, #104]
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp, #16]
	ldr	x10, [sp, #16]
	cmp	x10, x21
	b.hi	LBB54_27
; %bb.3:                                ; %bb8
                                        ;   in Loop: Header=BB54_2 Depth=1
	ldur	x25, [x22, #16]
	subs	x2, x8, #1
	add	x8, x9, x2, lsl #5
	str	x2, [x23]
	ldp	q0, q1, [x8]
	stp	q0, q1, [sp, #352]
	b.eq	LBB54_9
; %bb.4:                                ; %bb2.i
                                        ;   in Loop: Header=BB54_2 Depth=1
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp, #352]
	ldp	q0, q1, [x8]
	stp	q0, q1, [x9]
	ldr	x8, [x9, #16]
	cmp	x8, x25
	b.hs	LBB54_8
; %bb.5:                                ; %bb2.i.i.i.i
                                        ;   in Loop: Header=BB54_2 Depth=1
	ldr	x9, [x9, #24]
	ldr	x10, [x22, #32]
	madd	x8, x8, x27, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB54_8
; %bb.6:                                ; %bb5.i.i.i.i
                                        ;   in Loop: Header=BB54_2 Depth=1
	ldr	x9, [x8]
	cbz	x9, LBB54_8
; %bb.7:                                ; %bb8.i.i.i.i
                                        ;   in Loop: Header=BB54_2 Depth=1
	str	xzr, [x8, #32]
LBB54_8:                                ; %"wf_record_report_position$instance$aa2364d9cd38ac5f.exit.i"
                                        ;   in Loop: Header=BB54_2 Depth=1
	add	x4, x22, #16
	mov	x0, x23
	mov	x1, #0                          ; =0x0
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$4a1731430e1da28f
LBB54_9:                                ; %"wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$4a1731430e1da28f.exit"
                                        ;   in Loop: Header=BB54_2 Depth=1
	ldp	q0, q1, [sp, #352]
	stp	q0, q1, [x24, #32]
	str	xzr, [sp, #336]
	ldur	q0, [x24, #48]
	stur	q0, [x24, #64]
	ldr	x8, [sp, #80]
	cmp	x8, x25
	b.hs	LBB54_13
; %bb.10:                               ; %bb2.i.i
                                        ;   in Loop: Header=BB54_2 Depth=1
	ldr	x10, [sp, #88]
	ldr	x9, [x22, #32]
	madd	x9, x8, x27, x9
	ldr	x8, [x9, #40]
	cmp	x8, x10
	b.ne	LBB54_13
; %bb.11:                               ; %bb5.i.i
                                        ;   in Loop: Header=BB54_2 Depth=1
	ldr	x8, [x9]
	cbz	x8, LBB54_13
; %bb.12:                               ; %bb8.i.i
                                        ;   in Loop: Header=BB54_2 Depth=1
	mov	w8, #0                          ; =0x0
	str	xzr, [x9, #32]
	b	LBB54_14
LBB54_13:                               ;   in Loop: Header=BB54_2 Depth=1
	mov	w8, #1                          ; =0x1
LBB54_14:                               ; %"wf_std.collections.slab.slab_edit$instance$d0c575ce05c33b0e.exit"
                                        ;   in Loop: Header=BB54_2 Depth=1
	ldp	q0, q1, [x22, #64]
	stur	q0, [x24, #152]
	stur	q1, [x24, #168]
	ldr	q0, [x22, #96]
	stur	q0, [x24, #184]
	ldp	q0, q1, [x22]
	stur	q0, [x24, #88]
	stur	q1, [x24, #104]
	ldp	q0, q1, [x22, #32]
	stur	q0, [x24, #120]
	str	w8, [sp, #96]
	strh	wzr, [sp, #100]
	ldr	x8, [x22, #112]
	stur	x8, [x24, #200]
	stur	q1, [x24, #136]
	ldur	q0, [x24, #48]
	stur	q0, [x24, #208]
	ldr	x25, [sp, #104]
	ldr	x1, [sp, #56]
	str	x25, [sp, #240]
	ldur	q0, [x24, #48]
	stur	q0, [x24, #232]
	add	x2, x24, #224
	mov	x0, x22
	bl	_wf_record_store_detach$instance$aa2364d9cd38ac5f
	ldr	x8, [x22]
	cmp	x25, x8
	b.ne	LBB54_21
; %bb.15:                               ; %bb3.i.i
                                        ;   in Loop: Header=BB54_2 Depth=1
	ldr	x8, [sp, #248]
	ldur	x9, [x22, #16]
	cmp	x8, x9
	b.hs	LBB54_22
; %bb.16:                               ; %bb2.i.i.i
                                        ;   in Loop: Header=BB54_2 Depth=1
	ldr	x9, [sp, #256]
	ldr	x10, [x22, #32]
	madd	x8, x8, x27, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB54_22
; %bb.17:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB54_2 Depth=1
	ldr	x9, [x8]
	cbz	x9, LBB54_22
; %bb.18:                               ; %bb2.i7
                                        ;   in Loop: Header=BB54_2 Depth=1
	ldrb	w10, [x8, #24]
	ldr	x11, [x8, #32]
	and	w10, w10, #0x1
	strb	w10, [sp, #352]
	ldrb	w12, [x22, #8]
	cmp	x11, #0
	csinc	w10, w10, wzr, eq
	tbz	w12, #0, LBB54_25
; %bb.19:                               ; %bb2.i7
                                        ;   in Loop: Header=BB54_2 Depth=1
	cbz	w10, LBB54_25
; %bb.20:                               ;   in Loop: Header=BB54_2 Depth=1
	mov	w8, #9                          ; =0x9
	b	LBB54_23
LBB54_21:                               ;   in Loop: Header=BB54_2 Depth=1
	mov	w8, #4                          ; =0x4
	b	LBB54_23
LBB54_22:                               ; %bb5.i.i6
                                        ;   in Loop: Header=BB54_2 Depth=1
	mov	w8, #3                          ; =0x3
LBB54_23:                               ; %"wf_record_store_delete$instance$aa2364d9cd38ac5f.exit.thread"
                                        ;   in Loop: Header=BB54_2 Depth=1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x24, #256]
	str	w28, [sp, #264]
	str	w8, [sp, #268]
LBB54_24:                               ; %bb9
                                        ;   in Loop: Header=BB54_2 Depth=1
	ldr	x8, [x23]
	cbnz	x8, LBB54_2
	b	LBB54_27
LBB54_25:                               ; %bb10
                                        ;   in Loop: Header=BB54_2 Depth=1
	sub	x9, x9, #1
	add	x10, x8, x9, lsl #5
	str	x9, [x8]
	ldur	q0, [x10, #8]
	ldur	q1, [x10, #24]
	stp	q0, q1, [x24, #256]
	str	xzr, [sp, #264]
	stp	q0, q1, [x24, #288]
	ldr	x8, [sp, #312]
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	add	x9, x9, #1
	add	x26, x26, x8
	str	x9, [sp, #8]                    ; 8-byte Folded Spill
	stp	x9, x26, [x20]
	add	x19, x19, #1
	b	LBB54_24
LBB54_26:
	mov	x19, #0                         ; =0x0
LBB54_27:                               ; %bb2
	mov	x0, x19
	ldp	x29, x30, [sp, #464]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #448]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #432]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #416]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #400]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #384]            ; 16-byte Folded Reload
	add	sp, sp, #480
	ret
                                        ; -- End function
	.globl	_wf_record_store_free$instance$07ca9210fae40158 ; -- Begin function wf_record_store_free$instance$07ca9210fae40158
	.p2align	2
_wf_record_store_free$instance$07ca9210fae40158: ; @"wf_record_store_free$instance$07ca9210fae40158"
; %bb.0:                                ; %entry
	sub	sp, sp, #112
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x20, x1
	ldp	x23, x22, [x0, #16]
	ldr	x19, [x0, #32]
	ldr	x8, [x0, #56]
	ldp	x24, x21, [x0, #96]
	cbz	x8, LBB55_2
; %bb.1:                                ; %slots.release.drop.6.i.i
	ldr	x0, [x0, #64]
	bl	_free
LBB55_2:                                ; %"wf_std.collections.hash_map.hash_map_free$instance$254d3f8f5bda5a0a.exit"
	cbz	x24, LBB55_4
; %bb.3:                                ; %slots.release.drop.6.i.i2
	mov	x0, x21
	bl	_free
LBB55_4:                                ; %"wf_collections.priority_queue.priority_queue_free$instance$f600fe92c9d45040.exit"
	cbz	x23, LBB55_12
; %bb.5:                                ; %bb5.lr.ph.i
	ldr	q0, [x20]
	ands	x9, x23, #0x7
	b.eq	LBB55_10
; %bb.6:                                ; %bb5.i.prol.preheader
	mov	w8, #56                         ; =0x38
	madd	x8, x23, x8, x19
	sub	x10, x8, #56
	mov	x11, sp
	mov	w8, #1                          ; =0x1
	dup.2d	v1, x8
	mov	x8, x23
	b	LBB55_8
LBB55_7:                                ; %bb6.i.prol
                                        ;   in Loop: Header=BB55_8 Depth=1
	sub	x10, x10, #56
	sub	x8, x8, #1
	sub	x9, x9, #1
	cbz	x9, LBB55_11
LBB55_8:                                ; %bb5.i.prol
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q2, q3, [x10]
	stp	q2, q3, [sp]
	ldr	x12, [x10, #32]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB55_7
; %bb.9:                                ; %bb7.i.prol
                                        ;   in Loop: Header=BB55_8 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x11, x12, lsl #5
	add	x12, x12, #16
	mov.16b	v2, v1
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
	b	LBB55_7
LBB55_10:
	mov	x8, x23
LBB55_11:                               ; %bb5.i.prol.loopexit
	cmp	x23, #8
	b.hs	LBB55_15
LBB55_12:                               ; %bb4.i
	cbz	x22, LBB55_14
; %bb.13:                               ; %slots.release.drop.6.i.i8
	mov	x0, x19
	bl	_free
LBB55_14:                               ; %"wf_std.collections.slab.slab_free$instance$b016683df5790773.exit"
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
LBB55_15:                               ; %bb5.lr.ph.i.new
	mov	w9, #56                         ; =0x38
	madd	x9, x8, x9, x19
	sub	x9, x9, #224
	mov	x10, sp
	mov	w11, #1                         ; =0x1
	dup.2d	v1, x11
	b	LBB55_17
LBB55_16:                               ; %bb6.i.7
                                        ;   in Loop: Header=BB55_17 Depth=1
	sub	x9, x9, #448
	sub	x8, x8, #8
	cbz	x8, LBB55_12
LBB55_17:                               ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	ldur	q2, [x9, #168]
	ldur	q3, [x9, #184]
	stp	q2, q3, [sp]
	ldr	x12, [x9, #200]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB55_19
; %bb.18:                               ; %bb7.i
                                        ;   in Loop: Header=BB55_17 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x10, x12, lsl #5
	add	x12, x12, #16
	dup.2d	v2, x11
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
LBB55_19:                               ; %bb6.i
                                        ;   in Loop: Header=BB55_17 Depth=1
	ldp	q2, q3, [x9, #112]
	stp	q2, q3, [sp]
	ldr	x12, [x9, #144]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB55_21
; %bb.20:                               ; %bb7.i.1
                                        ;   in Loop: Header=BB55_17 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x10, x12, lsl #5
	add	x12, x12, #16
	dup.2d	v2, x11
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
LBB55_21:                               ; %bb6.i.1
                                        ;   in Loop: Header=BB55_17 Depth=1
	ldur	q2, [x9, #56]
	ldur	q3, [x9, #72]
	stp	q2, q3, [sp]
	ldr	x12, [x9, #88]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB55_23
; %bb.22:                               ; %bb7.i.2
                                        ;   in Loop: Header=BB55_17 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x10, x12, lsl #5
	add	x12, x12, #16
	dup.2d	v2, x11
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
LBB55_23:                               ; %bb6.i.2
                                        ;   in Loop: Header=BB55_17 Depth=1
	ldp	q2, q3, [x9]
	stp	q2, q3, [sp]
	ldr	x12, [x9, #32]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB55_25
; %bb.24:                               ; %bb7.i.3
                                        ;   in Loop: Header=BB55_17 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x10, x12, lsl #5
	add	x12, x12, #16
	dup.2d	v2, x11
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
LBB55_25:                               ; %bb6.i.3
                                        ;   in Loop: Header=BB55_17 Depth=1
	ldur	q2, [x9, #-56]
	ldur	q3, [x9, #-40]
	stp	q2, q3, [sp]
	ldur	x12, [x9, #-24]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB55_27
; %bb.26:                               ; %bb7.i.4
                                        ;   in Loop: Header=BB55_17 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x10, x12, lsl #5
	add	x12, x12, #16
	dup.2d	v2, x11
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
LBB55_27:                               ; %bb6.i.4
                                        ;   in Loop: Header=BB55_17 Depth=1
	ldp	q2, q3, [x9, #-112]
	stp	q2, q3, [sp]
	ldur	x12, [x9, #-80]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB55_29
; %bb.28:                               ; %bb7.i.5
                                        ;   in Loop: Header=BB55_17 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x10, x12, lsl #5
	add	x12, x12, #16
	dup.2d	v2, x11
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
LBB55_29:                               ; %bb6.i.5
                                        ;   in Loop: Header=BB55_17 Depth=1
	ldur	q2, [x9, #-168]
	ldur	q3, [x9, #-152]
	stp	q2, q3, [sp]
	ldur	x12, [x9, #-136]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB55_31
; %bb.30:                               ; %bb7.i.6
                                        ;   in Loop: Header=BB55_17 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x10, x12, lsl #5
	add	x12, x12, #16
	dup.2d	v2, x11
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
LBB55_31:                               ; %bb6.i.6
                                        ;   in Loop: Header=BB55_17 Depth=1
	ldp	q2, q3, [x9, #-224]
	stp	q2, q3, [sp]
	ldur	x12, [x9, #-192]
	str	x12, [sp, #32]
	ldr	x12, [sp]
	cbz	x12, LBB55_16
; %bb.32:                               ; %bb7.i.7
                                        ;   in Loop: Header=BB55_17 Depth=1
	sub	x12, x12, #1
	str	x12, [sp]
	add	x12, x10, x12, lsl #5
	add	x12, x12, #16
	mov.16b	v2, v1
	ld1.d	{ v2 }[1], [x12]
	add.2d	v0, v2, v0
	str	q0, [x20]
	b	LBB55_16
                                        ; -- End function
	.globl	_wf_box_slots_new$instance$57d99a800120d980 ; -- Begin function wf_box_slots_new$instance$57d99a800120d980
	.p2align	2
_wf_box_slots_new$instance$57d99a800120d980: ; @"wf_box_slots_new$instance$57d99a800120d980"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	cbz	x0, LBB56_3
; %bb.1:                                ; %window.payload.allocate.v1.i
	lsl	x0, x19, #5
	bl	_malloc
	mov	x2, x0
	cbnz	x0, LBB56_4
; %bb.2:                                ; %window.block.oom.v1.i
	bl	l_wf_resource_abort
LBB56_3:
Lloh152:
	adrp	x2, l_.wf.empty.slots.payload@PAGE
Lloh153:
	add	x2, x2, l_.wf.empty.slots.payload@PAGEOFF
LBB56_4:                                ; %"wf_box_slots_new$instance$57d99a800120d980.body.exit"
	mov	x0, #0                          ; =0x0
	mov	x1, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh152, Lloh153
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_array_filled$instance$62aaf7ed22d74c46 ; -- Begin function wf_array_filled$instance$62aaf7ed22d74c46
	.p2align	2
_wf_array_filled$instance$62aaf7ed22d74c46: ; @"wf_array_filled$instance$62aaf7ed22d74c46"
; %bb.0:                                ; %entry
	dup.2d	v0, x1
	stp	q0, q0, [x0]
	stp	q0, q0, [x0, #32]
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_heapify_indexed$instance$4dbd7ca4639a1dfc ; -- Begin function wf_collections.priority_queue.priority_queue_heapify_indexed$instance$4dbd7ca4639a1dfc
	.p2align	2
_wf_collections.priority_queue.priority_queue_heapify_indexed$instance$4dbd7ca4639a1dfc: ; @"wf_collections.priority_queue.priority_queue_heapify_indexed$instance$4dbd7ca4639a1dfc"
; %bb.0:                                ; %entry
	sub	sp, sp, #80
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	ldr	q0, [x0]
	str	q0, [sp]
	ldr	x19, [x0, #16]
	str	x19, [sp, #16]
	ldr	x21, [sp]
	cbz	x21, LBB58_9
; %bb.1:                                ; %bb2.lr.ph.i
	mov	x20, x2
	mov	x8, #0                          ; =0x0
	add	x9, x2, #64
	add	x10, x19, #8
	b	LBB58_4
LBB58_2:                                ; %bb2.i.i
                                        ;   in Loop: Header=BB58_4 Depth=1
	str	x8, [x20, x11, lsl #3]
	ldr	x12, [x9, x11, lsl #3]
	add	x12, x12, #1
	str	x12, [x9, x11, lsl #3]
LBB58_3:                                ; %wf_indexed_placed.exit.i
                                        ;   in Loop: Header=BB58_4 Depth=1
	add	x8, x8, #1
	cmp	x21, x8
	b.eq	LBB58_6
LBB58_4:                                ; %bb2.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x11, [x10], #32
	cmp	x11, #7
	b.ls	LBB58_2
; %bb.5:                                ; %bb3.i.i
                                        ;   in Loop: Header=BB58_4 Depth=1
	ldr	x11, [x20, #128]
	add	x11, x11, #1
	str	x11, [x20, #128]
	b	LBB58_3
LBB58_6:                                ; %bb4.i
	cmp	x21, #1
	b.eq	LBB58_9
; %bb.7:                                ; %bb7.i.preheader
	lsr	x8, x21, #1
	sub	x22, x8, #1
LBB58_8:                                ; %bb7.i
                                        ; =>This Inner Loop Header: Depth=1
	mov	x0, sp
	mov	x1, x22
	mov	x2, x21
	mov	x4, x20
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$4dbd7ca4639a1dfc
	sub	x22, x22, #1
	cmn	x22, #1
	b.ne	LBB58_8
LBB58_9:                                ; %"wf_collections.priority_queue.priority_queue_heapify_indexed$instance$4dbd7ca4639a1dfc.body.exit"
	ldr	x1, [sp, #8]
	mov	x0, x21
	mov	x2, x19
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_len$instance$04501e43c9a1589a ; -- Begin function wf_collections.priority_queue.priority_queue_len$instance$04501e43c9a1589a
	.p2align	2
_wf_collections.priority_queue.priority_queue_len$instance$04501e43c9a1589a: ; @"wf_collections.priority_queue.priority_queue_len$instance$04501e43c9a1589a"
; %bb.0:                                ; %entry
	ldr	x0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_peek_at$instance$32deebeb1a739cc7 ; -- Begin function wf_collections.priority_queue.priority_queue_peek_at$instance$32deebeb1a739cc7
	.p2align	2
_wf_collections.priority_queue.priority_queue_peek_at$instance$32deebeb1a739cc7: ; @"wf_collections.priority_queue.priority_queue_peek_at$instance$32deebeb1a739cc7"
; %bb.0:                                ; %entry
	ldr	x8, [x1, #16]
	add	x8, x8, x2, lsl #5
	ldp	q1, q0, [x8]
	stp	q1, q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$4dbd7ca4639a1dfc ; -- Begin function wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$4dbd7ca4639a1dfc
	.p2align	2
_wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$4dbd7ca4639a1dfc: ; @"wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$4dbd7ca4639a1dfc"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	mov	x19, x0
	ldr	x8, [x1]
	sub	x8, x8, #1
	ldr	x10, [x1, #16]
	add	x9, x10, x8, lsl #5
	str	x8, [x1]
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp]
	cmp	x2, x8
	b.hs	LBB61_5
; %bb.1:                                ; %bb2
	add	x10, x10, x2, lsl #5
	ldp	q0, q1, [x10]
	stp	q0, q1, [sp]
	ldp	q1, q0, [x9]
	stp	q1, q0, [x10]
	ldr	x9, [x10, #8]
	cmp	x9, #7
	b.hi	LBB61_3
; %bb.2:                                ; %bb2.i
	add	x9, x4, x9, lsl #3
	str	x2, [x9]
	ldr	x10, [x9, #64]
	add	x10, x10, #1
	str	x10, [x9, #64]
	b	LBB61_4
LBB61_3:                                ; %bb3.i
	ldr	x9, [x4, #128]
	add	x9, x9, #1
	str	x9, [x4, #128]
LBB61_4:                                ; %wf_indexed_placed.exit
	mov	x0, x1
	mov	x1, x2
	mov	x2, x8
	bl	_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$4dbd7ca4639a1dfc
LBB61_5:                                ; %bb1
	ldp	q0, q1, [sp]
	stp	q0, q1, [x19]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_free$instance$7bb859331c1381db ; -- Begin function wf_collections.priority_queue.priority_queue_free$instance$7bb859331c1381db
	.p2align	2
_wf_collections.priority_queue.priority_queue_free$instance$7bb859331c1381db: ; @"wf_collections.priority_queue.priority_queue_free$instance$7bb859331c1381db"
; %bb.0:                                ; %entry
	ldr	x8, [x0, #8]
	cbz	x8, LBB62_2
; %bb.1:                                ; %slots.release.drop.6.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #16]
	bl	_free
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB62_2:                                ; %"wf_free_empty$instance$401ab120abe5d512.exit"
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_array_filled$instance$fb041e1baf54ec25 ; -- Begin function wf_array_filled$instance$fb041e1baf54ec25
	.p2align	2
_wf_array_filled$instance$fb041e1baf54ec25: ; @"wf_array_filled$instance$fb041e1baf54ec25"
; %bb.0:                                ; %entry
	dup.2d	v0, x1
	stp	q0, q0, [x0]
	str	x1, [x0, #32]
	ret
                                        ; -- End function
	.globl	_wf_array_filled$instance$285b28e19d69e2ff ; -- Begin function wf_array_filled$instance$285b28e19d69e2ff
	.p2align	2
_wf_array_filled$instance$285b28e19d69e2ff: ; @"wf_array_filled$instance$285b28e19d69e2ff"
; %bb.0:                                ; %entry
	dup.2d	v0, x1
	stp	q0, q0, [x0, #16]
	str	q0, [x0]
	str	x1, [x0, #48]
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_replace_at_indexed$instance$69744d0f61ea6fbe ; -- Begin function wf_collections.priority_queue.priority_queue_replace_at_indexed$instance$69744d0f61ea6fbe
	.p2align	2
_wf_collections.priority_queue.priority_queue_replace_at_indexed$instance$69744d0f61ea6fbe: ; @"wf_collections.priority_queue.priority_queue_replace_at_indexed$instance$69744d0f61ea6fbe"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	mov	x4, x5
	mov	x8, x2
	mov	x19, x0
	ldr	x2, [x1]
	ldr	x9, [x1, #16]
	add	x9, x9, x8, lsl #5
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp]
	ldp	q1, q0, [x3]
	stp	q1, q0, [x9]
	ldr	x10, [x5, #40]
	cmp	x10, #4
	b.hi	LBB65_2
; %bb.1:                                ; %bb2.i
	ldr	x9, [x9, #8]
	add	x9, x8, x9, lsl #4
	str	x9, [x4, x10, lsl #3]
	b	LBB65_3
LBB65_2:                                ; %bb3.i
	ldr	x9, [x4, #48]
	add	x9, x9, #1
	str	x9, [x4, #48]
LBB65_3:                                ; %wf_indexed_rise_placed.exit
	add	x9, x10, #1
	str	x9, [x4, #40]
	mov	x0, x1
	mov	x1, x8
	bl	_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$69744d0f61ea6fbe
	ldp	q0, q1, [sp]
	stp	q0, q1, [x19]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_replace_at_indexed$instance$b789e18464d776a7 ; -- Begin function wf_collections.priority_queue.priority_queue_replace_at_indexed$instance$b789e18464d776a7
	.p2align	2
_wf_collections.priority_queue.priority_queue_replace_at_indexed$instance$b789e18464d776a7: ; @"wf_collections.priority_queue.priority_queue_replace_at_indexed$instance$b789e18464d776a7"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	mov	x8, x2
	mov	x19, x0
	ldr	x2, [x1]
	ldr	x9, [x1, #16]
	add	x9, x9, x8, lsl #5
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp]
	ldp	q1, q0, [x3]
	stp	q1, q0, [x9]
	ldr	x10, [x5, #40]
	cmp	x10, #4
	b.hi	LBB66_2
; %bb.1:                                ; %bb2.i
	ldr	x9, [x9, #8]
	add	x9, x8, x9, lsl #4
	str	x9, [x5, x10, lsl #3]
	b	LBB66_3
LBB66_2:                                ; %bb3.i
	ldr	x9, [x5, #48]
	add	x9, x9, #1
	str	x9, [x5, #48]
LBB66_3:                                ; %wf_indexed_rise_placed.exit
	add	x9, x10, #1
	str	x9, [x5, #40]
	mov	x0, x1
	mov	x1, x8
	mov	x3, x4
	mov	x4, x5
	bl	_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$b789e18464d776a7
	ldp	q0, q1, [sp]
	stp	q0, q1, [x19]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_new$instance$ee4b9614ae2d9710 ; -- Begin function wf_std.collections.slab.slab_new$instance$ee4b9614ae2d9710
	.p2align	2
_wf_std.collections.slab.slab_new$instance$ee4b9614ae2d9710: ; @"wf_std.collections.slab.slab_new$instance$ee4b9614ae2d9710"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	mov	x20, x0
	cbz	x1, LBB67_3
; %bb.1:                                ; %window.payload.allocate.v1.i.i
	mov	w8, #88                         ; =0x58
	mul	x0, x19, x8
	bl	_malloc
	cbnz	x0, LBB67_4
; %bb.2:                                ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
LBB67_3:
Lloh154:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh155:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB67_4:                                ; %"wf_box_slots_new$instance$a165a2c3db63b7e9.exit"
	stp	xzr, x19, [x20]
	stp	x0, x19, [x20, #16]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh154, Lloh155
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_insert$instance$ee4b9614ae2d9710 ; -- Begin function wf_std.collections.slab.slab_insert$instance$ee4b9614ae2d9710
	.p2align	2
_wf_std.collections.slab.slab_insert$instance$ee4b9614ae2d9710: ; @"wf_std.collections.slab.slab_insert$instance$ee4b9614ae2d9710"
; %bb.0:                                ; %entry
	ldp	x13, x16, [x2]
	ldp	x15, x14, [x2, #16]
	ldp	x11, x10, [x2, #32]
	ldp	x9, x8, [x2, #48]
	ldr	x12, [x1, #24]
	ldr	x17, [x1]
	cmp	x12, x17
	b.hs	LBB68_4
; %bb.1:                                ; %bb2
	ldr	x17, [x1, #16]
	mov	w2, #88                         ; =0x58
	madd	x17, x12, x2, x17
	ldr	x2, [x17]
	cbnz	x2, LBB68_6
; %bb.2:                                ; %bb5
	ldr	x2, [x17, #72]
	cbnz	x2, LBB68_6
; %bb.3:                                ; %bb8
	ldr	x2, [x17, #80]
	stp	x16, x15, [x17, #16]
	stp	x14, x11, [x17, #32]
	stp	x10, x9, [x17, #48]
	str	x8, [x17, #64]
	mov	w8, #1                          ; =0x1
	stp	x8, x13, [x17]
	str	x2, [x1, #24]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	stp	q0, q0, [x0, #32]
	str	xzr, [x0, #64]
	str	x12, [x0, #8]
	ret
LBB68_4:                                ; %bb3
	ldr	x2, [x1, #8]
	cmp	x17, x2
	b.hs	LBB68_6
; %bb.5:                                ; %bb11
	ldr	x2, [x1, #16]
	mov	w3, #88                         ; =0x58
	madd	x2, x17, x3, x2
	mov	w3, #1                          ; =0x1
	stp	x3, x13, [x2]
	stp	x16, x15, [x2, #16]
	stp	x14, x11, [x2, #32]
	stp	x10, x9, [x2, #48]
	stp	x8, xzr, [x2, #64]
	str	x12, [x2, #80]
	add	x8, x17, #1
	str	x8, [x1]
	movi.2d	v0, #0000000000000000
	str	xzr, [x0, #64]
	stp	q0, q0, [x0, #32]
	stp	q0, q0, [x0]
	str	x17, [x0, #8]
	ret
LBB68_6:                                ; %bb4
	stp	xzr, x13, [x0]
	mov	w12, #1                         ; =0x1
	str	w12, [x0]
	stp	x16, x15, [x0, #16]
	stp	x14, x11, [x0, #32]
	stp	x10, x9, [x0, #48]
	str	x8, [x0, #64]
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_std.collections.slab.slab_edit$instance$e386cf065a87918d
lCPI69_0:
	.quad	41                              ; 0x29
	.quad	142                             ; 0x8e
lCPI69_1:
	.quad	52                              ; 0x34
	.quad	63                              ; 0x3f
lCPI69_2:
	.quad	74                              ; 0x4a
	.quad	85                              ; 0x55
lCPI69_3:
	.quad	96                              ; 0x60
	.quad	107                             ; 0x6b
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_std.collections.slab.slab_edit$instance$e386cf065a87918d
	.p2align	2
_wf_std.collections.slab.slab_edit$instance$e386cf065a87918d: ; @"wf_std.collections.slab.slab_edit$instance$e386cf065a87918d"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldr	x8, [x2]
	ldr	x9, [x1]
	cmp	x8, x9
	b.hs	LBB69_5
; %bb.1:                                ; %bb2
	ldr	x9, [x2, #8]
	ldr	x10, [x1, #16]
	mov	w11, #88                        ; =0x58
	madd	x19, x8, x11, x10
	ldr	x8, [x19, #72]
	cmp	x8, x9
	b.ne	LBB69_5
; %bb.2:                                ; %bb5
	ldr	x8, [x19]
	cbz	x8, LBB69_5
; %bb.3:                                ; %bb8
	mov	x20, x0
	ldr	x8, [x3]
	add	x8, x8, #1
	str	x8, [x3]
	mov	w0, #16                         ; =0x10
	bl	_malloc
	cbz	x0, LBB69_7
; %bb.4:                                ; %wf_indexed_edit_owner.exit
Lloh156:
	adrp	x8, lCPI69_0@PAGE
Lloh157:
	ldr	q0, [x8, lCPI69_0@PAGEOFF]
	str	q0, [x0]
	ldr	x8, [x19, #8]
	ldr	x9, [x19, #64]
	str	x0, [x19, #8]
	mov	w10, #118                       ; =0x76
	str	x10, [x19, #64]
Lloh158:
	adrp	x10, lCPI69_1@PAGE
Lloh159:
	ldr	q0, [x10, lCPI69_1@PAGEOFF]
	ldp	q1, q2, [x19, #16]
Lloh160:
	adrp	x10, lCPI69_2@PAGE
Lloh161:
	ldr	q3, [x10, lCPI69_2@PAGEOFF]
	stp	q0, q3, [x19, #16]
	ldr	q0, [x19, #48]
Lloh162:
	adrp	x10, lCPI69_3@PAGE
Lloh163:
	ldr	q3, [x10, lCPI69_3@PAGEOFF]
	str	q3, [x19, #48]
	stp	xzr, x8, [x20]
	stp	q1, q2, [x20, #16]
	str	q0, [x20, #48]
	str	x9, [x20, #64]
	b	LBB69_6
LBB69_5:                                ; %bb1
	movi.2d	v0, #0000000000000000
	str	xzr, [x0, #64]
	stp	q0, q0, [x0, #32]
	stp	q0, q0, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
LBB69_6:                                ; %common.ret
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB69_7:                                ; %box.new.oom.v1.i.i.i.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh162, Lloh163
	.loh AdrpAdrp	Lloh160, Lloh162
	.loh AdrpLdr	Lloh160, Lloh161
	.loh AdrpAdrp	Lloh158, Lloh160
	.loh AdrpLdr	Lloh158, Lloh159
	.loh AdrpLdr	Lloh156, Lloh157
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_remove$instance$ee4b9614ae2d9710 ; -- Begin function wf_std.collections.slab.slab_remove$instance$ee4b9614ae2d9710
	.p2align	2
_wf_std.collections.slab.slab_remove$instance$ee4b9614ae2d9710: ; @"wf_std.collections.slab.slab_remove$instance$ee4b9614ae2d9710"
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	ldr	x9, [x1]
	cmp	x8, x9
	b.hs	LBB70_4
; %bb.1:                                ; %bb2
	ldr	x9, [x2, #8]
	ldr	x10, [x1, #16]
	mov	w11, #88                        ; =0x58
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #72]
	cmp	x10, x9
	b.ne	LBB70_4
; %bb.2:                                ; %bb5
	ldr	x9, [x8]
	cbz	x9, LBB70_4
; %bb.3:                                ; %bb8
	sub	x9, x9, #1
	str	x9, [x8]
	add	x8, x8, x9, lsl #6
	ldur	q0, [x8, #8]
	ldur	q1, [x8, #24]
	stp	q0, q1, [sp, #-64]!
	ldur	q2, [x8, #40]
	ldur	q3, [x8, #56]
	stp	q2, q3, [sp, #32]
	str	xzr, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	stur	q0, [x0, #8]
	stur	q1, [x0, #24]
	stur	q2, [x0, #40]
	stur	q3, [x0, #56]
	add	sp, sp, #64
	ret
LBB70_4:                                ; %bb1
	str	xzr, [x0, #64]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0, #32]
	stp	q0, q0, [x0]
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_std.collections.slab.slab_free$instance$006b6d8e6441afd9
lCPI71_0:
	.quad	22                              ; 0x16
	.quad	33                              ; 0x21
lCPI71_1:
	.quad	44                              ; 0x2c
	.quad	55                              ; 0x37
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_std.collections.slab.slab_free$instance$006b6d8e6441afd9
	.p2align	2
_wf_std.collections.slab.slab_free$instance$006b6d8e6441afd9: ; @"wf_std.collections.slab.slab_free$instance$006b6d8e6441afd9"
; %bb.0:                                ; %entry
	sub	sp, sp, #192
	stp	x26, x25, [sp, #112]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #128]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #144]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #160]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #176]            ; 16-byte Folded Spill
	ldp	x22, x21, [x0]
	ldr	x19, [x0, #16]
	cbz	x22, LBB71_10
; %bb.1:                                ; %bb5.lr.ph
	mov	x20, x1
	ldp	x23, x24, [x1]
	mov	w8, #88                         ; =0x58
	madd	x8, x22, x8, x19
	sub	x25, x8, #88
	add	x26, sp, #32
Lloh164:
	adrp	x8, lCPI71_0@PAGE
Lloh165:
	ldr	q0, [x8, lCPI71_0@PAGEOFF]
	str	q0, [sp, #16]                   ; 16-byte Folded Spill
Lloh166:
	adrp	x8, lCPI71_1@PAGE
Lloh167:
	ldr	q0, [x8, lCPI71_1@PAGEOFF]
	str	q0, [sp]                        ; 16-byte Folded Spill
	b	LBB71_5
LBB71_2:                                ;   in Loop: Header=BB71_5 Depth=1
	mov	x10, #-1                        ; =0xffffffffffffffff
LBB71_3:                                ; %wf_indexed_edit_consume.exit
                                        ;   in Loop: Header=BB71_5 Depth=1
	add	x23, x23, #1
	add	x24, x24, x10
	stp	x23, x24, [x20]
	bl	_free
LBB71_4:                                ; %bb6
                                        ;   in Loop: Header=BB71_5 Depth=1
	sub	x25, x25, #88
	sub	x22, x22, #1
	cbz	x22, LBB71_10
LBB71_5:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q0, q1, [x25]
	stp	q0, q1, [sp, #32]
	ldp	q0, q1, [x25, #32]
	stp	q0, q1, [sp, #64]
	ldr	x8, [x25, #64]
	str	x8, [sp, #96]
	ldr	x8, [sp, #32]
	cbz	x8, LBB71_4
; %bb.6:                                ; %bb7
                                        ;   in Loop: Header=BB71_5 Depth=1
	sub	x9, x8, #1
	add	x8, x26, x9, lsl #6
	str	x9, [sp, #32]
	ldp	x0, x10, [x8, #8]
	ldp	x9, x11, [x0]
	add	x12, x9, #101
	cmp	x11, x12
	csinv	x9, x9, xzr, eq
	add	x11, x9, #11
	cmp	x10, x11
	b.ne	LBB71_2
; %bb.7:                                ; %bb3.i.i
                                        ;   in Loop: Header=BB71_5 Depth=1
	ldur	q0, [x8, #40]
	ldur	q1, [x8, #24]
	dup.2d	v2, x9
	ldp	q4, q3, [sp]                    ; 32-byte Folded Reload
	add.2d	v3, v2, v3
	add.2d	v2, v2, v4
	cmeq.2d	v0, v0, v2
	cmeq.2d	v1, v1, v3
	uzp1.4s	v0, v1, v0
	xtn.4h	v0, v0
	uminv.4h	h0, v0
	fmov	w11, s0
	mov	x10, #-1                        ; =0xffffffffffffffff
	tbz	w11, #0, LBB71_3
; %bb.8:                                ; %bb3.i.i
                                        ;   in Loop: Header=BB71_5 Depth=1
	ldr	x11, [x8, #56]
	add	x12, x9, #66
	cmp	x11, x12
	b.ne	LBB71_3
; %bb.9:                                ; %bb18.i.i
                                        ;   in Loop: Header=BB71_5 Depth=1
	ldr	x8, [x8, #64]
	add	x10, x9, #77
	cmp	x8, x10
	csinv	x10, x9, xzr, eq
	b	LBB71_3
LBB71_10:                               ; %bb4
	cbz	x21, LBB71_12
; %bb.11:                               ; %slots.release.drop.6.i
	mov	x0, x19
	bl	_free
LBB71_12:                               ; %"wf_free_empty$instance$81a0b1ff5783c983.exit"
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #176]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #160]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #144]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #128]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #192
	ret
	.loh AdrpLdr	Lloh166, Lloh167
	.loh AdrpAdrp	Lloh164, Lloh166
	.loh AdrpLdr	Lloh164, Lloh165
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_indexed_trace$instance$34505fe33827dcb3
lCPI72_0:
	.quad	15                              ; 0xf
	.quad	116                             ; 0x74
lCPI72_1:
	.quad	1                               ; 0x1
	.quad	901                             ; 0x385
lCPI72_2:
	.quad	8                               ; 0x8
	.quad	0                               ; 0x0
lCPI72_4:
	.quad	9                               ; 0x9
	.quad	110                             ; 0x6e
lCPI72_5:
	.quad	1                               ; 0x1
	.quad	10                              ; 0xa
lCPI72_6:
	.quad	10                              ; 0xa
	.quad	111                             ; 0x6f
lCPI72_7:
	.quad	11                              ; 0xb
	.quad	112                             ; 0x70
lCPI72_8:
	.quad	12                              ; 0xc
	.quad	113                             ; 0x71
lCPI72_9:
	.quad	13                              ; 0xd
	.quad	114                             ; 0x72
lCPI72_10:
	.quad	14                              ; 0xe
	.quad	115                             ; 0x73
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI72_3:
	.long	1                               ; 0x1
	.long	4                               ; 0x4
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_indexed_trace$instance$34505fe33827dcb3
	.p2align	2
_wf_indexed_trace$instance$34505fe33827dcb3: ; @"wf_indexed_trace$instance$34505fe33827dcb3"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	mov	w9, #5232                       ; =0x1470
Lloh168:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh169:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #1136
	.cfi_def_cfa_offset 5328
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x22, x0
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #903
	add	x26, sp, #208
	add	x23, x26, #2448
	add	x8, x26, #264
	str	x8, [sp, #96]                   ; 8-byte Folded Spill
	add	x10, x26, #312
	add	x8, x26, #360
	stp	x10, x8, [sp, #160]             ; 16-byte Folded Spill
	add	x10, x26, #440
	add	x8, x26, #512
	stp	x10, x8, [sp, #120]             ; 16-byte Folded Spill
	add	x10, x26, #536
	add	x8, x26, #584
	stp	x10, x8, [sp, #136]             ; 16-byte Folded Spill
	add	x8, x26, #608
	str	x8, [sp, #152]                  ; 8-byte Folded Spill
	add	x10, x26, #664
	add	x8, x26, #688
	stp	x10, x8, [sp, #40]              ; 16-byte Folded Spill
	add	x10, x26, #712
	add	x8, x26, #736
	stp	x10, x8, [sp, #56]              ; 16-byte Folded Spill
	add	x8, x26, #760
	str	x8, [sp, #72]                   ; 8-byte Folded Spill
	add	x10, x26, #816
	add	x8, x26, #840
	stp	x10, x8, [sp, #8]               ; 16-byte Folded Spill
	add	x10, x26, #856
	add	x11, x26, #872
	add	x8, x26, #992
	stp	x11, x8, [sp, #104]             ; 16-byte Folded Spill
	add	x19, x26, #1112
	add	x8, x26, #2424
	str	x8, [sp, #200]                  ; 8-byte Folded Spill
	mov	w8, #4472                       ; =0x1178
	add	x21, x26, x8
	mov	w8, #4592                       ; =0x11f0
	add	x8, x26, x8
	str	x8, [sp, #176]                  ; 8-byte Folded Spill
	mov	w8, #4736                       ; =0x1280
	add	x8, x26, x8
	stp	x10, x8, [sp, #24]              ; 16-byte Folded Spill
	mov	x0, x19
	mov	w1, #1312                       ; =0x520
	bl	_bzero
	strb	wzr, [x20, #9]
	strh	wzr, [x20]
	and	w24, wzr, #0xff
	and	w27, wzr, #0xff
	and	w28, wzr, #0xff
	mov	x0, x23
	mov	w1, #2024                       ; =0x7e8
	bl	_bzero
	str	x24, [sp, #2632]
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #2640]
	strb	w27, [sp, #2656]
	strb	w28, [sp, #2657]
	add	x8, x26, #2456
	str	q0, [x8]
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp, #2680]
	strb	w24, [sp, #2696]
	str	q0, [sp, #2704]
	strb	w27, [sp, #2720]
	strb	w28, [sp, #2721]
	add	x9, x26, #2520
	str	q0, [x9]
	str	x8, [sp, #2744]
	strb	w24, [sp, #2760]
	str	q0, [sp, #2768]
	strb	w27, [sp, #2784]
	strb	w28, [sp, #2785]
	add	x9, x26, #2584
	str	q0, [x9]
	str	x8, [sp, #2808]
	strb	w24, [sp, #2824]
	str	q0, [sp, #2832]
	strb	w27, [sp, #2848]
	strb	w28, [sp, #2849]
	add	x9, x26, #2648
	str	q0, [x9]
	str	x8, [sp, #2872]
	strb	w24, [sp, #2888]
	str	q0, [sp, #2896]
	strb	w27, [sp, #2912]
	strb	w28, [sp, #2913]
	add	x9, x26, #2712
	str	q0, [x9]
	str	x8, [sp, #2936]
	strb	w24, [sp, #2952]
	str	q0, [sp, #2960]
	strb	w27, [sp, #2976]
	strb	w28, [sp, #2977]
	add	x9, x26, #2776
	str	q0, [x9]
	str	x8, [sp, #3000]
	strb	w24, [sp, #3016]
	str	q0, [sp, #3024]
	strb	w27, [sp, #3040]
	strb	w28, [sp, #3041]
	add	x9, x26, #2840
	str	q0, [x9]
	str	x8, [sp, #3064]
	strb	w24, [sp, #3080]
	str	q0, [sp, #3088]
	strb	w27, [sp, #3104]
	strb	w28, [sp, #3105]
	add	x9, x26, #2904
	str	q0, [x9]
	str	x8, [sp, #3128]
	strb	w24, [sp, #3144]
	str	q0, [sp, #3152]
	strb	w27, [sp, #3168]
	strb	w28, [sp, #3169]
	add	x9, x26, #2968
	add	x10, x26, #2984
	str	x10, [sp, #80]                  ; 8-byte Folded Spill
	str	q0, [x9]
	str	x8, [sp, #3192]
	strb	w24, [sp, #3208]
	str	q0, [sp, #3216]
	strb	w27, [sp, #3232]
	strb	w28, [sp, #3233]
	add	x9, x26, #3032
	str	q0, [x9]
	str	x8, [sp, #3256]
	strb	w24, [sp, #3272]
	str	q0, [sp, #3280]
	strb	w27, [sp, #3296]
	strb	w28, [sp, #3297]
	add	x9, x26, #3096
	str	q0, [x9]
	str	x8, [sp, #3320]
	strb	w24, [sp, #3336]
	str	q0, [sp, #3344]
	strb	w27, [sp, #3360]
	strb	w28, [sp, #3361]
	add	x9, x26, #3160
	str	q0, [x9]
	str	x8, [sp, #3384]
	strb	w24, [sp, #3400]
	str	q0, [sp, #3408]
	strb	w27, [sp, #3424]
	strb	w28, [sp, #3425]
	add	x9, x26, #3224
	str	q0, [x9]
	str	x8, [sp, #3448]
	strb	w24, [sp, #3464]
	str	q0, [sp, #3472]
	strb	w27, [sp, #3488]
	strb	w28, [sp, #3489]
	add	x9, x26, #3288
	str	q0, [x9]
	str	x8, [sp, #3512]
	strb	w24, [sp, #3528]
	str	q0, [sp, #3536]
	strb	w27, [sp, #3552]
	strb	w28, [sp, #3553]
	add	x9, x26, #3352
	str	q0, [x9]
	str	x8, [sp, #3576]
	str	xzr, [sp, #3584]
	strb	w24, [sp, #3592]
	str	q0, [sp, #3600]
	strb	w27, [sp, #3616]
	strb	w28, [sp, #3617]
	add	x9, x26, #3416
	str	q0, [x9]
	str	x8, [sp, #3640]
	str	xzr, [sp, #3648]
	strb	w24, [sp, #3656]
	str	q0, [sp, #3664]
	strb	w27, [sp, #3680]
	strb	w28, [sp, #3681]
	add	x9, x26, #3480
	str	q0, [x9]
	str	x8, [sp, #3704]
	str	xzr, [sp, #3712]
	strb	w24, [sp, #3720]
	str	q0, [sp, #3728]
	strb	w27, [sp, #3744]
	strb	w28, [sp, #3745]
	add	x9, x26, #3544
	str	q0, [x9]
	str	x8, [sp, #3768]
	str	xzr, [sp, #3776]
	strb	w24, [sp, #3784]
	str	q0, [sp, #3792]
	strb	w27, [sp, #3808]
	strb	w28, [sp, #3809]
	add	x9, x26, #3608
	str	q0, [x9]
	str	x8, [sp, #3832]
	str	xzr, [sp, #3840]
	strb	w24, [sp, #3848]
	str	q0, [sp, #3856]
	strb	w27, [sp, #3872]
	strb	w28, [sp, #3873]
	add	x9, x26, #3672
	str	q0, [x9]
	str	x8, [sp, #3896]
	str	xzr, [sp, #3904]
	strb	w24, [sp, #3912]
	str	q0, [sp, #3920]
	strb	w27, [sp, #3936]
	strb	w28, [sp, #3937]
	add	x9, x26, #3736
	str	q0, [x9]
	str	x8, [sp, #3960]
	str	xzr, [sp, #3968]
	strb	w24, [sp, #3976]
	str	q0, [sp, #3984]
	strb	w27, [sp, #4000]
	strb	w28, [sp, #4001]
	add	x9, x26, #3800
	str	q0, [x9]
	str	x8, [sp, #4024]
	str	xzr, [sp, #4032]
	strb	w24, [sp, #4040]
	str	q0, [sp, #4048]
	strb	w27, [sp, #4064]
	strb	w28, [sp, #4065]
	add	x9, x26, #3864
	str	q0, [x9]
	str	x8, [sp, #4088]
	str	xzr, [sp, #4096]
	add	x9, sp, #9
	strb	w24, [x9, #4095]
	str	q0, [sp, #4112]
	add	x9, sp, #33
	strb	w27, [x9, #4095]
	add	x9, sp, #34
	strb	w28, [x9, #4095]
	add	x9, x26, #3928
	str	q0, [x9]
	str	x8, [sp, #4152]
	str	xzr, [sp, #4160]
	add	x9, sp, #73
	strb	w24, [x9, #4095]
	str	q0, [sp, #4176]
	strb	w27, [x26, #3984]
	strb	w28, [x26, #3985]
	add	x9, x26, #3992
	str	q0, [x9]
	str	x8, [sp, #4216]
	str	xzr, [sp, #4224]
	strb	w24, [x26, #4024]
	str	q0, [sp, #4240]
	strb	w27, [x26, #4048]
	strb	w28, [x26, #4049]
	add	x9, x26, #4056
	str	q0, [x9]
	str	x8, [sp, #4280]
	str	xzr, [sp, #4288]
	strb	w24, [x26, #4088]
	str	q0, [sp, #4304]
	strb	w27, [x23, #1664]
	mov	w9, #4120                       ; =0x1018
	str	q0, [x26, x9]
	strb	w28, [x23, #1665]
	str	x8, [sp, #4344]
	str	xzr, [sp, #4352]
	strb	w24, [x23, #1704]
	str	q0, [sp, #4368]
	strb	w27, [x23, #1728]
	strb	w28, [x23, #1729]
	mov	w9, #4184                       ; =0x1058
	str	q0, [x26, x9]
	str	x8, [sp, #4408]
	str	xzr, [sp, #4416]
	strb	w24, [x23, #1768]
	str	q0, [sp, #4432]
	strb	w27, [x23, #1792]
	mov	w9, #4248                       ; =0x1098
	str	q0, [x26, x9]
	strb	w28, [x23, #1793]
	str	x8, [sp, #4472]
	str	xzr, [sp, #4480]
	strb	w24, [x23, #1832]
	str	q0, [sp, #4496]
	strb	w27, [x23, #1856]
	strb	w28, [x23, #1857]
	mov	w9, #4312                       ; =0x10d8
	str	q0, [x26, x9]
	str	x8, [sp, #4536]
	str	xzr, [sp, #4544]
	strb	w24, [x23, #1896]
	str	q0, [sp, #4560]
	strb	w27, [x23, #1920]
	mov	w9, #4376                       ; =0x1118
	str	q0, [x26, x9]
	strb	w28, [x23, #1921]
	str	x8, [sp, #4600]
	str	xzr, [sp, #4608]
	strb	w24, [x23, #1960]
	str	q0, [sp, #4624]
	strb	w27, [x23, #1984]
	strb	w28, [x23, #1985]
	mov	w9, #4440                       ; =0x1158
	str	q0, [x26, x9]
	str	x8, [sp, #4664]
	str	xzr, [sp, #4672]
	mov	x0, x21
	mov	w1, #71                         ; =0x47
	str	w22, [sp, #188]                 ; 4-byte Folded Spill
	mov	x2, x22
	mov	w3, #8                          ; =0x8
	mov	x4, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	mov	x6, #0                          ; =0x0
	bl	_wf_record_store_new$instance$3ad8b32886f5e3ce
	mov	x28, #0                         ; =0x0
	mov	w27, #1                         ; =0x1
	mov	w25, #10                        ; =0xa
	mov	x20, #100                       ; =0x64
	str	x21, [sp, #192]                 ; 8-byte Folded Spill
	b	LBB72_2
LBB72_1:                                ; %"wf_indexed_schedule$instance$4a70da04567deb49.exit"
                                        ;   in Loop: Header=BB72_2 Depth=1
	strb	w27, [x22, #25]
	str	x28, [x22, #32]
	mov	x28, x24
	cmp	x24, #8
	b.eq	LBB72_11
LBB72_2:                                ; %bb2
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB72_7 Depth 2
	mov	w0, #16                         ; =0x10
	bl	_malloc
	cbz	x0, LBB72_299
; %bb.3:                                ; %wf_indexed_child.exit
                                        ;   in Loop: Header=BB72_2 Depth=1
	mov	x6, x0
	add	x24, x28, #1
	add	x8, x28, #102
	stp	x24, x8, [x0]
	add	x4, x28, #10
	mov	x0, x21
	ldr	x22, [sp, #200]                 ; 8-byte Folded Reload
	mov	x1, x22
	mov	x2, x19
	mov	x3, x28
	mov	x5, x24
	bl	_wf_indexed_accept$instance$34505fe33827dcb3
	add	x22, x22, x28, lsl #6
	mov	x0, x21
	ldr	x21, [x22, #8]
	ldur	q0, [x22, #40]
	str	q0, [sp, #5008]
	ldr	x8, [x22, #56]
	str	x8, [sp, #5024]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #912
	bl	_wf_record_store_attach$instance$3ad8b32886f5e3ce
	cbz	w0, LBB72_5
; %bb.4:                                ; %bb13.i.i
                                        ;   in Loop: Header=BB72_2 Depth=1
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_5:                                ; %bb2.i.preheader
                                        ;   in Loop: Header=BB72_2 Depth=1
	mov	x8, #0                          ; =0x0
	b	LBB72_7
LBB72_6:                                ; %bb8.i
                                        ;   in Loop: Header=BB72_7 Depth=2
	add	x8, x8, #64
	cmp	x8, #2048
	b.eq	LBB72_9
LBB72_7:                                ; %bb2.i
                                        ;   Parent Loop BB72_2 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x9, x26, x8
	ldr	x10, [x9, #2432]
	cmp	x10, x21
	b.ne	LBB72_6
; %bb.8:                                ; %bb6.i
                                        ;   in Loop: Header=BB72_7 Depth=2
	strb	wzr, [x9, #2448]
	b	LBB72_6
LBB72_9:                                ; %"wf_indexed_attach$instance$4a70da04567deb49.exit"
                                        ;   in Loop: Header=BB72_2 Depth=1
	lsl	x8, x28, #6
	strb	w27, [x23, x8]
	madd	x28, x28, x25, x20
	ldur	q0, [x22, #40]
	str	q0, [sp, #5008]
	ldur	x8, [x22, #56]
	str	x8, [sp, #5024]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #912
	ldr	x21, [sp, #192]                 ; 8-byte Folded Reload
	mov	x0, x21
	mov	x2, x28
	bl	_wf_record_store_schedule$instance$3ad8b32886f5e3ce
	cbz	w0, LBB72_1
; %bb.10:                               ; %bb13.i.i97
                                        ;   in Loop: Header=BB72_2 Depth=1
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
	b	LBB72_1
LBB72_11:                               ; %bb4
	mov	x0, x21
	ldr	x27, [sp, #200]                 ; 8-byte Folded Reload
	mov	x1, x27
	mov	x2, x19
	bl	_wf_indexed_check$instance$34505fe33827dcb3
	add	x8, sp, #208
	add	x28, x8, #2464
	ldr	q0, [sp, #2672]
	str	q0, [sp, #208]
	ldr	x8, [sp, #2688]
	str	x8, [sp, #224]
	add	x1, sp, #208
	mov	x0, x21
	bl	_wf_record_store_attach$instance$3ad8b32886f5e3ce
	cmp	w0, #1
	b.eq	LBB72_13
; %bb.12:                               ; %bb13.i
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_13:                               ; %wf_indexed_status.exit
	ldr	q0, [x28]
	stur	q0, [x26, #24]
	ldr	x8, [x28, #16]
	stur	x8, [x26, #40]
	add	x1, x26, #24
	mov	x0, x21
	mov	w2, #99                         ; =0x63
	bl	_wf_record_store_schedule$instance$3ad8b32886f5e3ce
	cmp	w0, #1
	add	x22, sp, #1, lsl #12            ; =4096
	add	x22, x22, #903
	ldr	x25, [sp, #176]                 ; 8-byte Folded Reload
	b.eq	LBB72_15
; %bb.14:                               ; %bb13.i109
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_15:                               ; %wf_indexed_status.exit122
	mov	x0, x21
	mov	x1, x27
	mov	x2, x19
	mov	x3, #0                          ; =0x0
	bl	_wf_indexed_cancel_position$instance$34505fe33827dcb3
	mov	x0, x21
	mov	x1, x27
	mov	x2, x19
	bl	_wf_indexed_check$instance$34505fe33827dcb3
	mov	x0, x21
	mov	x1, x27
	mov	x2, x19
	mov	w3, #4                          ; =0x4
	bl	_wf_indexed_cancel_position$instance$34505fe33827dcb3
	mov	x0, x21
	mov	x1, x27
	mov	x2, x19
	bl	_wf_indexed_check$instance$34505fe33827dcb3
	mov	x0, x21
	mov	x1, x27
	mov	x2, x19
	mov	w3, #7                          ; =0x7
	bl	_wf_indexed_cancel_position$instance$34505fe33827dcb3
	mov	x0, x21
	mov	x1, x27
	mov	x2, x19
	bl	_wf_indexed_check$instance$34505fe33827dcb3
	ldr	w8, [sp, #188]                  ; 4-byte Folded Reload
	and	w2, w8, #0x1
	mov	x0, x25
	mov	w1, #72                         ; =0x48
	mov	w3, #1                          ; =0x1
	mov	x4, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	mov	x6, #0                          ; =0x0
	bl	_wf_record_store_new$instance$3ad8b32886f5e3ce
	mov	w0, #16                         ; =0x10
	bl	_malloc
	cbz	x0, LBB72_299
; %bb.16:                               ; %wf_indexed_child.exit127
Lloh170:
	adrp	x8, lCPI72_0@PAGE
Lloh171:
	ldr	q0, [x8, lCPI72_0@PAGEOFF]
	str	q0, [x0]
	mov	w8, #901                        ; =0x385
	str	x8, [sp, #1440]
	strb	wzr, [x22, #9]
	ldr	x8, [sp, #4840]
	ldr	x10, [sp, #4816]
	cmp	x8, x10
	b.hs	LBB72_20
; %bb.17:                               ; %bb2.i.i
	ldr	x9, [sp, #4832]
	mov	w10, #56                        ; =0x38
	madd	x10, x8, x10, x9
	ldr	x9, [x10]
	cbnz	x9, LBB72_43
; %bb.18:                               ; %bb5.i.i
	ldr	x9, [x10, #40]
	cmp	x9, #2
	b.hi	LBB72_43
; %bb.19:                               ; %bb8.i.i
	ldr	x11, [x10, #48]
	str	x0, [x10, #16]
	strb	wzr, [x10, #24]
	mov	w12, #8                         ; =0x8
	str	x12, [x10, #32]
Lloh172:
	adrp	x12, lCPI72_1@PAGE
Lloh173:
	ldr	q0, [x12, lCPI72_1@PAGEOFF]
	str	q0, [x10]
	str	x11, [sp, #4840]
	b	LBB72_22
LBB72_20:                               ; %bb3.i.i
	ldr	x9, [sp, #4824]
	cmp	x10, x9
	b.hs	LBB72_43
; %bb.21:                               ; %bb11.i.i
	mov	x9, #0                          ; =0x0
	ldr	x11, [sp, #4832]
	mov	w12, #56                        ; =0x38
	madd	x11, x10, x12, x11
Lloh174:
	adrp	x12, lCPI72_1@PAGE
Lloh175:
	ldr	q0, [x12, lCPI72_1@PAGEOFF]
	str	q0, [x11]
	str	x0, [x11, #16]
	strb	wzr, [x11, #24]
Lloh176:
	adrp	x12, lCPI72_2@PAGE
Lloh177:
	ldr	q0, [x12, lCPI72_2@PAGEOFF]
	str	q0, [x11, #32]
	str	x8, [x11, #48]
	add	x8, x10, #1
	str	x8, [sp, #4816]
	mov	x8, x10
LBB72_22:                               ; %bb7
	ldr	x10, [sp, #4800]
	stp	xzr, x10, [sp, #256]
	stp	x8, x9, [sp, #272]
	add	x8, sp, #9
	ldur	q0, [x8, #255]
	stur	q0, [x26, #80]
	stur	x9, [x26, #96]
	add	x8, sp, #208
	ldr	q0, [sp, #272]
	stur	q0, [x26, #104]
	ldr	x9, [sp, #312]
	ldr	x10, [sp, #2680]
	cmp	x9, x10
	b.eq	LBB72_24
; %bb.23:                               ; %bb10
	ldr	x9, [sp, #2624]
	add	x9, x9, #1
	str	x9, [sp, #2624]
LBB72_24:                               ; %bb9
	ldur	q0, [x8, #88]
	stur	q0, [x26, #120]
	ldr	x8, [sp, #336]
	ldr	x9, [sp, #2688]
	cmp	x8, x9
	b.eq	LBB72_26
; %bb.25:                               ; %bb13
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_26:                               ; %bb12
	add	x1, x26, #80
	mov	x0, x21
	bl	_wf_record_store_attach$instance$3ad8b32886f5e3ce
	cmp	w0, #4
	b.eq	LBB72_28
; %bb.27:                               ; %bb13.i208
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_28:                               ; %wf_indexed_status.exit221
	add	x1, x26, #80
	mov	x0, x21
	bl	_wf_record_store_cancel$instance$3ad8b32886f5e3ce
	cmp	w0, #4
	b.eq	LBB72_30
; %bb.29:                               ; %bb13.i226
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_30:                               ; %wf_indexed_status.exit239
	add	x1, x26, #80
	mov	x0, x21
	mov	w2, #1                          ; =0x1
	bl	_wf_record_store_schedule$instance$3ad8b32886f5e3ce
	cmp	w0, #4
	b.eq	LBB72_32
; %bb.31:                               ; %bb13.i244
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_32:                               ; %wf_indexed_status.exit257
	add	x1, x26, #80
	mov	x0, x21
	mov	w2, #1                          ; =0x1
	bl	_wf_record_store_reschedule$instance$3ad8b32886f5e3ce
	cmp	w0, #4
	b.eq	LBB72_34
; %bb.33:                               ; %bb13.i262
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_34:                               ; %wf_indexed_status.exit275
	add	x2, x26, #80
	mov	x0, x21
	mov	w1, #10                         ; =0xa
	bl	_wf_record_store_detach$instance$3ad8b32886f5e3ce
	cmp	w0, #4
	b.eq	LBB72_36
; %bb.35:                               ; %bb13.i280
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_36:                               ; %wf_indexed_status.exit293
	ldp	x10, x8, [sp, #288]
	ldr	x9, [sp, #304]
	ldr	x11, [sp, #4680]
	cmp	x10, x11
	b.ne	LBB72_52
; %bb.37:                               ; %bb3.i.i295
	ldr	x11, [sp, #4696]
	cmp	x8, x11
	b.hs	LBB72_53
; %bb.38:                               ; %bb2.i.i.i
	ldr	x11, [sp, #4712]
	mov	w12, #56                        ; =0x38
	madd	x12, x8, x12, x11
	ldr	x13, [x12, #40]
	cmp	x13, x9
	b.ne	LBB72_53
; %bb.39:                               ; %bb5.i.i.i
	ldr	x13, [x12]
	cbz	x13, LBB72_53
; %bb.40:                               ; %bb2.i299
	ldrb	w14, [x12, #24]
	ldr	x15, [x12, #32]
	and	w14, w14, #0x1
	strb	w14, [x22, #1]
	ldrb	w16, [x23, #2032]
	cmp	x15, #8
	csinc	w14, w14, wzr, eq
	tbz	w16, #0, LBB72_292
; %bb.41:                               ; %bb2.i299
	tbz	w14, #0, LBB72_292
; %bb.42:
	mov	w11, #9                         ; =0x9
	b	LBB72_54
LBB72_43:                               ; %bb1.i.i
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x26, #48]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #256]
	ldr	x10, [sp, #2624]
	add	x8, x10, #1
	str	x8, [sp, #2624]
	strb	wzr, [x22, #9]
	ldr	x11, [sp, #1952]
	add	x11, x11, #1
	str	x0, [sp, #264]
	str	x11, [sp, #1952]
	ldrb	w11, [sp, #2616]
	tbz	w11, #0, LBB72_51
; %bb.44:                               ; %bb8.i.i194
	cbnz	w9, LBB72_46
; %bb.45:                               ; %bb11.i.i197
	add	x8, x10, #2
	str	x8, [sp, #2624]
LBB72_46:                               ; %bb13.i.i195
	ldr	x9, [sp, #2608]
	cmp	x9, #31
	b.hi	LBB72_49
; %bb.47:                               ; %bb13.i.i195
	ldr	x10, [sp, #2600]
	cmp	x9, x10
	b.hs	LBB72_49
; %bb.48:                               ; %bb20.i.i
	add	x10, sp, #208
	add	x10, x10, x9, lsl #3
	ldr	x10, [x10, #2136]
	cmp	x10, #15
	b.eq	LBB72_50
LBB72_49:                               ; %bb16.sink.split.i.i
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_50:                               ; %bb16.i.i
	add	x8, x9, #1
	str	x8, [sp, #2608]
LBB72_51:                               ; %"wf_indexed_release_payload$instance$cfa19887953541da.exit"
	bl	_free
	b	LBB72_64
LBB72_52:                               ; %bb17.thread1357
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #352]
Lloh178:
	adrp	x11, lCPI72_3@PAGE
Lloh179:
	ldr	d0, [x11, lCPI72_3@PAGEOFF]
	str	d0, [sp, #344]
	b	LBB72_55
LBB72_53:                               ; %bb17
	mov	w11, #3                         ; =0x3
LBB72_54:                               ; %bb13.i322
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #352]
	mov	w12, #1                         ; =0x1
	str	w12, [sp, #344]
	str	w11, [sp, #348]
	ldr	x11, [sp, #2624]
	add	x11, x11, #1
	str	x11, [sp, #2624]
LBB72_55:                               ; %bb15
	ldr	x11, [sp, #4800]
	cmp	x10, x11
	b.ne	LBB72_60
; %bb.56:                               ; %bb3.i.i312
	ldr	x10, [sp, #4816]
	cmp	x8, x10
	b.hs	LBB72_61
; %bb.57:                               ; %bb2.i.i.i.i
	ldr	x10, [sp, #4832]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB72_61
; %bb.58:                               ; %bb5.i.i.i.i
	ldr	x9, [x8]
	cbz	x9, LBB72_61
; %bb.59:                               ; %bb19
	ldr	x8, [x8, #16]
	ldp	x9, x8, [x8]
	add	x10, x9, #101
	cmp	x8, x10
	csinv	x8, x9, xzr, eq
	str	wzr, [sp, #416]
	str	x8, [sp, #424]
	str	wzr, [sp, #432]
	cmp	x8, #15
	b.ne	LBB72_63
	b	LBB72_64
LBB72_60:
	mov	w8, #4                          ; =0x4
	b	LBB72_62
LBB72_61:
	mov	w8, #3                          ; =0x3
LBB72_62:                               ; %bb20
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #416]
	str	xzr, [sp, #424]
	str	w8, [sp, #432]
LBB72_63:                               ; %bb22
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_64:                               ; %bb6
	mov	w0, #16                         ; =0x10
	bl	_malloc
	cbz	x0, LBB72_299
; %bb.65:                               ; %wf_indexed_child.exit135
Lloh180:
	adrp	x8, lCPI72_4@PAGE
Lloh181:
	ldr	q0, [x8, lCPI72_4@PAGEOFF]
	str	q0, [x0]
	mov	w8, #10                         ; =0xa
	str	x8, [sp, #1392]
	strb	wzr, [x22, #9]
	ldr	x8, [sp, #4720]
	ldr	x10, [sp, #4696]
	cmp	x8, x10
	b.hs	LBB72_69
; %bb.66:                               ; %bb2.i.i168
	ldr	x9, [sp, #4712]
	mov	w10, #56                        ; =0x38
	madd	x10, x8, x10, x9
	ldr	x9, [x10]
	cbnz	x9, LBB72_72
; %bb.67:                               ; %bb5.i.i175
	ldr	x9, [x10, #40]
	cmp	x9, #2
	b.hi	LBB72_72
; %bb.68:                               ; %bb8.i.i179
	ldr	x11, [x10, #48]
	str	x0, [x10, #16]
	strb	wzr, [x10, #24]
	mov	w12, #8                         ; =0x8
	str	x12, [x10, #32]
Lloh182:
	adrp	x12, lCPI72_5@PAGE
Lloh183:
	ldr	q0, [x12, lCPI72_5@PAGEOFF]
	str	q0, [x10]
	str	x11, [sp, #4720]
	b	LBB72_71
LBB72_69:                               ; %bb3.i.i143
	ldr	x9, [sp, #4704]
	cmp	x10, x9
	b.hs	LBB72_72
; %bb.70:                               ; %bb11.i.i149
	mov	x9, #0                          ; =0x0
	ldr	x11, [sp, #4712]
	mov	w12, #56                        ; =0x38
	madd	x11, x10, x12, x11
Lloh184:
	adrp	x12, lCPI72_5@PAGE
Lloh185:
	ldr	q0, [x12, lCPI72_5@PAGEOFF]
	str	q0, [x11]
	str	x0, [x11, #16]
	strb	wzr, [x11, #24]
Lloh186:
	adrp	x12, lCPI72_2@PAGE
Lloh187:
	ldr	q0, [x12, lCPI72_2@PAGEOFF]
	str	q0, [x11, #32]
	str	x8, [x11, #48]
	add	x8, x10, #1
	str	x8, [sp, #4696]
	mov	x8, x10
LBB72_71:                               ; %bb1.i161
	ldr	x10, [sp, #4680]
	stp	xzr, x10, [sp, #440]
	stp	x8, x9, [sp, #456]
	ldr	w8, [sp, #188]                  ; 4-byte Folded Reload
	tbnz	w8, #0, LBB72_73
	b	LBB72_78
LBB72_72:                               ; %bb2.i147
	movi.2d	v0, #0000000000000000
	stur	q0, [x26, #248]
	stur	q0, [x26, #232]
	mov	w8, #1                          ; =0x1
	str	w8, [sp, #440]
	str	x0, [sp, #448]
	ldr	w8, [sp, #188]                  ; 4-byte Folded Reload
	tbz	w8, #0, LBB72_78
LBB72_73:                               ; %bb25
	mov	x0, x21
	mov	x1, x27
	mov	x2, x19
	mov	x3, #0                          ; =0x0
	mov	w4, #9                          ; =0x9
	bl	_wf_indexed_delete$instance$34505fe33827dcb3
	ldr	x1, [sp, #2640]
	ldr	q0, [x28]
	str	q0, [sp, #5008]
	ldr	x8, [x28, #16]
	str	x8, [sp, #5024]
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #912
	mov	x0, x21
	bl	_wf_record_store_detach$instance$3ad8b32886f5e3ce
	cbz	w0, LBB72_75
; %bb.74:                               ; %bb13.i.i348
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_75:                               ; %"wf_indexed_detach$instance$4a70da04567deb49.exit"
	strb	wzr, [x23]
	mov	x0, x21
	mov	x1, x27
	mov	x2, x19
	mov	x3, #0                          ; =0x0
	mov	w4, #9                          ; =0x9
	bl	_wf_indexed_delete$instance$34505fe33827dcb3
	ldr	q0, [x28]
	str	q0, [sp, #5008]
	ldr	x8, [x28, #16]
	str	x8, [sp, #5024]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #912
	mov	x0, x21
	bl	_wf_record_store_cancel$instance$3ad8b32886f5e3ce
	cbz	w0, LBB72_77
; %bb.76:                               ; %bb13.i.i358
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_77:                               ; %"wf_indexed_cancel$instance$4a70da04567deb49.exit"
	strb	wzr, [x23, #1]
LBB72_78:                               ; %bb24
	mov	x0, x21
	mov	x1, x27
	mov	x2, x19
	mov	x3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	bl	_wf_indexed_delete$instance$34505fe33827dcb3
	ldr	w8, [sp, #440]
	cbz	w8, LBB72_83
; %bb.79:                               ; %bb29
	ldr	x6, [sp, #448]
	str	x6, [sp, #4920]
	ldr	x8, [x6]
	cmp	x8, #9
	b.ne	LBB72_81
; %bb.80:                               ; %bb29
	ldr	x9, [x6, #8]
	add	x8, x8, #101
	cmp	x9, x8
	b.eq	LBB72_82
LBB72_81:                               ; %bb31
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_82:                               ; %bb30
	mov	x0, x21
	mov	x1, x27
	mov	x2, x19
	mov	w3, #8                          ; =0x8
	mov	w4, #10                         ; =0xa
	mov	w5, #9                          ; =0x9
	bl	_wf_indexed_accept$instance$34505fe33827dcb3
	b	LBB72_84
LBB72_83:                               ; %bb28
	add	x8, sp, #208
	ldur	q0, [x8, #240]
	ldr	x9, [sp, #96]                   ; 8-byte Folded Reload
	str	q0, [x9]
	ldr	x8, [x8, #256]
	str	x8, [x9, #16]
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_84:                               ; %bb27
	mov	w8, #4608                       ; =0x1200
	mov	w9, #4488                       ; =0x1188
	add	x10, sp, #208
	ldr	x11, [sp, #3192]
	ldr	x12, [sp, #2680]
	cmp	x11, x12
	b.eq	LBB72_86
; %bb.85:                               ; %bb34
	ldr	x11, [sp, #2624]
	add	x11, x11, #1
	str	x11, [sp, #2624]
LBB72_86:                               ; %bb33
	add	x11, sp, #208
	add	x12, sp, #208
	add	x24, x10, #2976
	ldr	x10, [sp, #3200]
	cmp	x10, #1
	b.eq	LBB72_88
; %bb.87:                               ; %bb37
	ldr	x10, [sp, #2624]
	add	x10, x10, #1
	str	x10, [sp, #2624]
LBB72_88:                               ; %bb36
	add	x8, x11, x8
	str	x8, [sp, #96]                   ; 8-byte Folded Spill
	add	x8, x12, x9
	str	x8, [sp, #88]                   ; 8-byte Folded Spill
	ldr	x20, [sp, #3152]
	ldr	q0, [x24]
	str	q0, [sp, #5008]
	ldr	x8, [x24, #16]
	str	x8, [sp, #5024]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #912
	mov	x0, x21
	bl	_wf_record_store_attach$instance$3ad8b32886f5e3ce
	cbz	w0, LBB72_90
; %bb.89:                               ; %bb13.i.i380
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_90:                               ; %bb2.i385.preheader
	mov	w8, #32                         ; =0x20
	mov	x9, x23
	b	LBB72_92
LBB72_91:                               ; %bb8.i391
                                        ;   in Loop: Header=BB72_92 Depth=1
	add	x9, x9, #64
	subs	x8, x8, #1
	b.eq	LBB72_94
LBB72_92:                               ; %bb2.i385
                                        ; =>This Inner Loop Header: Depth=1
	ldur	x10, [x9, #-16]
	cmp	x10, x20
	b.ne	LBB72_91
; %bb.93:                               ; %bb6.i396
                                        ;   in Loop: Header=BB72_92 Depth=1
	strb	wzr, [x9]
	b	LBB72_91
LBB72_94:                               ; %"wf_indexed_attach$instance$4a70da04567deb49.exit398"
	mov	w8, #1                          ; =0x1
	strb	w8, [x26, #2960]
	ldr	w8, [sp, #188]                  ; 4-byte Folded Reload
	tbnz	w8, #0, LBB72_97
; %bb.95:                               ; %bb41
	ldr	q0, [x24]
	str	q0, [x26, #288]
	ldr	x8, [x24, #16]
	str	x8, [x26, #304]
	add	x1, x26, #288
	mov	x0, x21
	mov	w2, #1000                       ; =0x3e8
	bl	_wf_record_store_schedule$instance$3ad8b32886f5e3ce
	cmp	w0, #6
	b.eq	LBB72_97
; %bb.96:                               ; %bb13.i418
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_97:                               ; %bb39
	add	x20, sp, #208
	ldr	q0, [sp, #2736]
	str	q0, [sp, #5008]
	ldr	x8, [sp, #2752]
	str	x8, [sp, #5024]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #912
	mov	x0, x21
	bl	_wf_record_store_cancel$instance$3ad8b32886f5e3ce
	cbz	w0, LBB72_99
; %bb.98:                               ; %bb13.i.i407
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_99:                               ; %"wf_indexed_cancel$instance$4a70da04567deb49.exit413"
	add	x20, x20, #2528
	strb	wzr, [x23, #65]
	ldr	w8, [sp, #188]                  ; 4-byte Folded Reload
	tbz	w8, #0, LBB72_101
; %bb.100:                              ; %bb43
	mov	x0, x21
	mov	x1, x27
	mov	x2, x19
	mov	w3, #1                          ; =0x1
	mov	w4, #9                          ; =0x9
	bl	_wf_indexed_delete$instance$34505fe33827dcb3
LBB72_101:                              ; %bb42
	ldr	x1, [sp, #2704]
	ldr	q0, [x20]
	str	q0, [sp, #5008]
	ldr	x8, [x20, #16]
	str	x8, [sp, #5024]
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #912
	mov	x0, x21
	bl	_wf_record_store_detach$instance$3ad8b32886f5e3ce
	cbz	w0, LBB72_103
; %bb.102:                              ; %bb13.i.i438
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_103:                              ; %"wf_indexed_detach$instance$4a70da04567deb49.exit444"
	strb	wzr, [x23, #64]
	mov	w20, #1                         ; =0x1
	mov	x0, x21
	mov	x1, x27
	mov	x2, x19
	mov	w3, #1                          ; =0x1
	mov	x4, #0                          ; =0x0
	bl	_wf_indexed_delete$instance$34505fe33827dcb3
	ldr	q0, [x24]
	str	q0, [sp, #5008]
	ldr	x8, [x24, #16]
	str	x8, [sp, #5024]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #912
	mov	x0, x21
	mov	w2, #1000                       ; =0x3e8
	bl	_wf_record_store_schedule$instance$3ad8b32886f5e3ce
	cbz	w0, LBB72_105
; %bb.104:                              ; %bb13.i.i450
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_105:                              ; %"wf_indexed_schedule$instance$4a70da04567deb49.exit457"
	strb	w20, [x26, #2961]
	mov	w8, #1000                       ; =0x3e8
	str	x8, [sp, #3176]
	ldr	q0, [x28]
	ldr	x1, [sp, #160]                  ; 8-byte Folded Reload
	str	q0, [x1]
	ldr	x8, [x28, #16]
	str	x8, [x1, #16]
	mov	x0, x21
	bl	_wf_record_store_cancel$instance$3ad8b32886f5e3ce
	cmp	w0, #3
	b.eq	LBB72_107
; %bb.106:                              ; %bb13.i462
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_107:                              ; %wf_indexed_status.exit475
	ldr	q0, [x28]
	str	q0, [x26, #336]
	ldr	x8, [x28, #16]
	str	x8, [x26, #352]
	add	x1, x26, #336
	mov	x0, x21
	mov	w2, #1                          ; =0x1
	bl	_wf_record_store_reschedule$instance$3ad8b32886f5e3ce
	cmp	w0, #3
	b.eq	LBB72_109
; %bb.108:                              ; %bb13.i480
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_109:                              ; %wf_indexed_status.exit493
	ldr	q0, [x28]
	ldr	x2, [sp, #168]                  ; 8-byte Folded Reload
	str	q0, [x2]
	ldr	x8, [x28, #16]
	str	x8, [x2, #16]
	mov	x0, x21
	mov	w1, #10                         ; =0xa
	bl	_wf_record_store_detach$instance$3ad8b32886f5e3ce
	cmp	w0, #4
	b.hi	LBB72_111
; %bb.110:                              ; %bb13.i498
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_111:                              ; %wf_indexed_status.exit511
	mov	w0, #16                         ; =0x10
	bl	_malloc
	cbz	x0, LBB72_299
; %bb.112:                              ; %wf_indexed_child.exit516
	mov	x6, x0
Lloh188:
	adrp	x8, lCPI72_6@PAGE
Lloh189:
	ldr	q0, [x8, lCPI72_6@PAGEOFF]
	str	q0, [x0]
	mov	x0, x21
	mov	x1, x27
	mov	x2, x19
	mov	w3, #9                          ; =0x9
	mov	w4, #12                         ; =0xc
	mov	w5, #10                         ; =0xa
	bl	_wf_indexed_accept$instance$34505fe33827dcb3
	ldr	q0, [sp, #3248]
	str	q0, [x26, #384]
	ldr	x8, [sp, #3264]
	str	x8, [x26, #400]
	add	x1, x26, #384
	mov	x0, x21
	bl	_wf_record_store_attach$instance$3ad8b32886f5e3ce
	cmp	w0, #5
	b.eq	LBB72_114
; %bb.113:                              ; %bb13.i521
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_114:                              ; %wf_indexed_status.exit534
	mov	x0, x21
	mov	x1, x27
	mov	x2, x19
	mov	w3, #9                          ; =0x9
	mov	x4, #0                          ; =0x0
	bl	_wf_indexed_delete$instance$34505fe33827dcb3
	mov	w0, #16                         ; =0x10
	bl	_malloc
	cbz	x0, LBB72_299
; %bb.115:                              ; %wf_indexed_child.exit539
Lloh190:
	adrp	x8, lCPI72_7@PAGE
Lloh191:
	ldr	q0, [x8, lCPI72_7@PAGEOFF]
	str	q0, [x0]
	mov	w8, #12                         ; =0xc
	str	x8, [sp, #1408]
	ldr	x8, [sp, #4792]
	cbz	x8, LBB72_117
; %bb.116:                              ; %bb3.i.i.i.i.i
	mov	w9, #12                         ; =0xc
	udiv	x10, x9, x8
	msub	x9, x10, x8, x9
	ldr	x8, [sp, #4728]
	cbnz	x8, LBB72_118
	b	LBB72_129
LBB72_117:
	mov	x9, #0                          ; =0x0
	ldr	x8, [sp, #4728]
	cbz	x8, LBB72_129
LBB72_118:                              ; %bb3.i.i.i.i
	udiv	x10, x9, x8
	msub	x9, x10, x8, x9
	ldr	x10, [sp, #4744]
	mov	x11, x8
	b	LBB72_120
LBB72_119:                              ; %bb8.i.i.i.i
                                        ;   in Loop: Header=BB72_120 Depth=1
	add	x12, x9, #1
	cmp	x12, x8
	csinc	x9, xzr, x9, hs
	subs	x11, x11, #1
	b.eq	LBB72_129
LBB72_120:                              ; %bb5.i.i.i.i543
                                        ; =>This Inner Loop Header: Depth=1
	add	x12, x10, x9, lsl #5
	ldr	w13, [x12]
	cmp	w13, #1
	b.eq	LBB72_119
; %bb.121:                              ; %bb5.i.i.i.i543
                                        ;   in Loop: Header=BB72_120 Depth=1
	cmp	w13, #2
	b.ne	LBB72_129
; %bb.122:                              ; %bb9.i.i.i.i
                                        ;   in Loop: Header=BB72_120 Depth=1
	ldr	x13, [x12, #8]
	cmp	x13, #12
	b.ne	LBB72_119
; %bb.123:                              ; %bb3.i120.i.i.i
	ldr	x8, [x12, #16]
	ldr	x9, [sp, #4696]
	cmp	x8, x9
	b.hs	LBB72_259
; %bb.124:                              ; %bb2.i.i.i.i.i
	ldr	x10, [x12, #24]
	ldr	x9, [sp, #4712]
	mov	w11, #56                        ; =0x38
	madd	x9, x8, x11, x9
	ldr	x8, [x9, #40]
	cmp	x8, x10
	b.ne	LBB72_259
; %bb.125:                              ; %bb5.i.i.i.i.i
	ldr	x8, [x9]
	cbz	x8, LBB72_259
; %bb.126:                              ; %bb3.i.i.i
	ldr	x8, [x9, #8]
	cmp	x8, #12
	b.ne	LBB72_295
; %bb.127:                              ; %wf_indexed_status.exit567
	ldr	x8, [x9, #16]
	str	x0, [x9, #16]
	str	wzr, [sp, #616]
	str	x8, [sp, #624]
	str	x8, [sp, #4928]
	ldp	x10, x9, [x8]
	add	x11, x10, #101
	cmp	x10, #3
	ccmp	x9, x11, #0, eq
	b.eq	LBB72_298
; %bb.128:
	mov	x0, x8
	b	LBB72_131
LBB72_129:
	mov	w8, #2                          ; =0x2
LBB72_130:                              ; %wf_indexed_status.exit567.thread
	str	w8, [sp, #616]
	str	x0, [sp, #4928]
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x0, [sp, #624]
	str	x8, [sp, #2624]
	mov	x8, x0
LBB72_131:                              ; %bb46
	ldr	x9, [sp, #2624]
	add	x9, x9, #1
	str	x9, [sp, #2624]
	ldp	x10, x9, [x0]
LBB72_132:                              ; %bb45
	strb	wzr, [x22, #9]
	add	x11, x10, #101
	cmp	x9, x11
	csinv	x9, x10, xzr, eq
	cmp	x9, #64
	b.hs	LBB72_136
; %bb.133:                              ; %bb2.i.i614
	ldr	x10, [x19, x9, lsl #3]
	cmp	x10, #12
	b.eq	LBB72_135
; %bb.134:                              ; %bb5.i.i618
	ldr	x10, [sp, #2624]
	add	x10, x10, #1
	str	x10, [sp, #2624]
LBB72_135:                              ; %bb4.i.i622
	add	x10, sp, #208
	add	x10, x10, x9, lsl #3
	ldr	x11, [x10, #1624]
	add	x11, x11, #1
	str	x11, [x10, #1624]
	ldrb	w10, [sp, #2616]
	tbnz	w10, #0, LBB72_137
	b	LBB72_144
LBB72_136:                              ; %bb3.i.i584
	ldr	x10, [sp, #2624]
	add	x10, x10, #1
	str	x10, [sp, #2624]
	ldrb	w10, [sp, #2616]
	tbz	w10, #0, LBB72_144
LBB72_137:                              ; %bb8.i.i590
	mov	w10, #1                         ; =0x1
	cbnz	w10, LBB72_139
; %bb.138:                              ; %bb11.i.i610
	ldr	x10, [sp, #2624]
	add	x10, x10, #1
	str	x10, [sp, #2624]
LBB72_139:                              ; %bb13.i.i591
	ldr	x10, [sp, #2608]
	cmp	x10, #31
	b.hi	LBB72_142
; %bb.140:                              ; %bb13.i.i591
	ldr	x11, [sp, #2600]
	cmp	x10, x11
	b.hs	LBB72_142
; %bb.141:                              ; %bb20.i.i605
	add	x11, sp, #208
	add	x11, x11, x10, lsl #3
	ldr	x11, [x11, #2136]
	cmp	x11, x9
	b.eq	LBB72_143
LBB72_142:                              ; %bb16.sink.split.i.i599
	ldr	x9, [sp, #2624]
	add	x9, x9, #1
	str	x9, [sp, #2624]
LBB72_143:                              ; %bb16.i.i603
	add	x9, x10, #1
	str	x9, [sp, #2608]
LBB72_144:                              ; %"wf_indexed_release_payload$instance$cfa19887953541da.exit627"
	mov	x0, x8
	bl	_free
	mov	w8, #11                         ; =0xb
	str	x8, [sp, #2776]
	mov	w0, #16                         ; =0x10
	bl	_malloc
	cbz	x0, LBB72_299
; %bb.145:                              ; %wf_indexed_child.exit632
Lloh192:
	adrp	x8, lCPI72_8@PAGE
Lloh193:
	ldr	q0, [x8, lCPI72_8@PAGEOFF]
	str	q0, [x0]
	mov	w8, #999                        ; =0x3e7
	str	x8, [sp, #1416]
	ldr	x8, [sp, #4792]
	cbz	x8, LBB72_147
; %bb.146:                              ; %bb3.i.i.i.i.i636
	mov	w9, #999                        ; =0x3e7
	udiv	x10, x9, x8
	msub	x9, x10, x8, x9
	ldr	x8, [sp, #4728]
	cbnz	x8, LBB72_148
	b	LBB72_158
LBB72_147:
	mov	x9, #0                          ; =0x0
	ldr	x8, [sp, #4728]
	cbz	x8, LBB72_158
LBB72_148:                              ; %bb3.i.i.i.i642
	udiv	x10, x9, x8
	msub	x9, x10, x8, x9
	ldr	x10, [sp, #4744]
	mov	x11, x8
	b	LBB72_150
LBB72_149:                              ; %bb8.i.i.i.i651
                                        ;   in Loop: Header=BB72_150 Depth=1
	add	x12, x9, #1
	cmp	x12, x8
	csinc	x9, xzr, x9, hs
	subs	x11, x11, #1
	b.eq	LBB72_158
LBB72_150:                              ; %bb5.i.i.i.i646
                                        ; =>This Inner Loop Header: Depth=1
	add	x12, x10, x9, lsl #5
	ldr	w13, [x12]
	cmp	w13, #1
	b.eq	LBB72_149
; %bb.151:                              ; %bb5.i.i.i.i646
                                        ;   in Loop: Header=BB72_150 Depth=1
	cmp	w13, #2
	b.ne	LBB72_158
; %bb.152:                              ; %bb9.i.i.i.i661
                                        ;   in Loop: Header=BB72_150 Depth=1
	ldr	x13, [x12, #8]
	cmp	x13, #999
	b.ne	LBB72_149
; %bb.153:                              ; %bb3.i120.i.i.i665
	ldr	x8, [x12, #16]
	ldr	x9, [sp, #4696]
	cmp	x8, x9
	b.hs	LBB72_260
; %bb.154:                              ; %bb2.i.i.i.i.i673
	ldr	x10, [x12, #24]
	ldr	x9, [sp, #4712]
	mov	w11, #56                        ; =0x38
	madd	x9, x8, x11, x9
	ldr	x8, [x9, #40]
	cmp	x8, x10
	b.ne	LBB72_260
; %bb.155:                              ; %bb5.i.i.i.i.i681
	ldr	x8, [x9]
	cbz	x8, LBB72_260
; %bb.156:                              ; %bb3.i.i.i684
	ldr	x8, [x9, #8]
	cmp	x8, #999
	b.ne	LBB72_296
; %bb.157:                              ; %"wf_record_store_replace$instance$3ad8b32886f5e3ce.exit692.thread1275"
	mov	w8, #0                          ; =0x0
	ldr	x10, [x9, #16]
	str	x0, [x9, #16]
	mov	x0, x10
	b	LBB72_261
LBB72_158:                              ; %bb1.i694
	mov	w8, #2                          ; =0x2
	str	w8, [sp, #632]
	str	x0, [sp, #640]
	str	x0, [sp, #4936]
	mov	w9, #12                         ; =0xc
	mov	w8, #113                        ; =0x71
	cmp	x9, #12
	b.ne	LBB72_160
LBB72_159:                              ; %wf_indexed_status.exit710
	add	x9, x9, #101
	cmp	x8, x9
	b.eq	LBB72_161
LBB72_160:                              ; %bb49
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
	ldr	x8, [x0, #8]
LBB72_161:                              ; %bb48
	strb	wzr, [x22, #9]
	ldr	x9, [x0]
	add	x10, x9, #101
	cmp	x8, x10
	csinv	x8, x9, xzr, eq
	cmp	x8, #64
	b.hs	LBB72_165
; %bb.162:                              ; %bb2.i.i760
	ldr	x9, [x19, x8, lsl #3]
	cmp	x9, #999
	b.eq	LBB72_164
; %bb.163:                              ; %bb5.i.i764
	ldr	x9, [sp, #2624]
	add	x9, x9, #1
	str	x9, [sp, #2624]
LBB72_164:                              ; %bb4.i.i768
	add	x9, sp, #208
	add	x9, x9, x8, lsl #3
	ldr	x10, [x9, #1624]
	add	x10, x10, #1
	str	x10, [x9, #1624]
	ldrb	w9, [sp, #2616]
	tbnz	w9, #0, LBB72_166
	b	LBB72_173
LBB72_165:                              ; %bb3.i.i730
	ldr	x9, [sp, #2624]
	add	x9, x9, #1
	str	x9, [sp, #2624]
	ldrb	w9, [sp, #2616]
	tbz	w9, #0, LBB72_173
LBB72_166:                              ; %bb8.i.i736
	mov	w9, #1                          ; =0x1
	cbnz	w9, LBB72_168
; %bb.167:                              ; %bb11.i.i756
	ldr	x9, [sp, #2624]
	add	x9, x9, #1
	str	x9, [sp, #2624]
LBB72_168:                              ; %bb13.i.i737
	ldr	x9, [sp, #2608]
	cmp	x9, #31
	b.hi	LBB72_171
; %bb.169:                              ; %bb13.i.i737
	ldr	x10, [sp, #2600]
	cmp	x9, x10
	b.hs	LBB72_171
; %bb.170:                              ; %bb20.i.i751
	add	x10, sp, #208
	add	x10, x10, x9, lsl #3
	ldr	x10, [x10, #2136]
	cmp	x10, x8
	b.eq	LBB72_172
LBB72_171:                              ; %bb16.sink.split.i.i745
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_172:                              ; %bb16.i.i749
	add	x8, x9, #1
	str	x8, [sp, #2608]
LBB72_173:                              ; %"wf_indexed_release_payload$instance$cfa19887953541da.exit773"
	bl	_free
	add	x8, sp, #208
	add	x28, x8, #2592
	ldr	q0, [sp, #2800]
	ldr	x1, [sp, #120]                  ; 8-byte Folded Reload
	str	q0, [x1]
	ldr	x8, [sp, #2816]
	str	x8, [x1, #16]
	mov	x0, x21
	mov	w2, #1                          ; =0x1
	bl	_wf_record_store_reschedule$instance$3ad8b32886f5e3ce
	cbz	w0, LBB72_175
; %bb.174:                              ; %bb13.i778
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_175:                              ; %wf_indexed_status.exit791
	mov	w8, #1                          ; =0x1
	str	x8, [sp, #2792]
	ldr	x9, [x28, #16]
	str	x9, [x26, #480]
	ldr	q0, [x28]
	str	q0, [x26, #464]
	ldr	x9, [sp, #672]
	ldr	x10, [sp, #4680]
	cmp	x9, x10
	b.ne	LBB72_181
; %bb.176:                              ; %bb3.i.i.i796
	ldr	x9, [sp, #680]
	ldr	x10, [sp, #4696]
	cmp	x9, x10
	b.hs	LBB72_182
; %bb.177:                              ; %bb2.i.i.i.i800
	ldr	x11, [sp, #688]
	ldr	x10, [sp, #4712]
	mov	w12, #56                        ; =0x38
	madd	x12, x9, x12, x10
	ldr	x10, [x12, #40]
	cmp	x10, x11
	b.ne	LBB72_182
; %bb.178:                              ; %bb5.i.i.i.i808
	ldr	x10, [x12]
	cbz	x10, LBB72_182
; %bb.179:                              ; %bb2.i.i811
	ldr	x10, [x12, #32]
	cmp	x10, #8
	b.ne	LBB72_281
; %bb.180:
	mov	w9, #7                          ; =0x7
	b	LBB72_183
LBB72_181:
	mov	w9, #4                          ; =0x4
	b	LBB72_183
LBB72_182:
	mov	w9, #3                          ; =0x3
LBB72_183:                              ; %bb53
	str	w8, [sp, #696]
	str	xzr, [sp, #704]
	str	w9, [sp, #712]
LBB72_184:                              ; %bb51.sink.split
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_185:                              ; %bb51
	ldr	q0, [x28]
	ldr	x1, [sp, #128]                  ; 8-byte Folded Reload
	str	q0, [x1]
	ldr	x8, [x28, #16]
	str	x8, [x1, #16]
	mov	x0, x21
	mov	w2, #2000                       ; =0x7d0
	bl	_wf_record_store_reschedule$instance$3ad8b32886f5e3ce
	cbz	w0, LBB72_187
; %bb.186:                              ; %bb13.i824
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_187:                              ; %wf_indexed_status.exit837
	mov	w8, #2000                       ; =0x7d0
	str	x8, [sp, #2792]
	ldr	x8, [x28, #16]
	ldr	x9, [sp, #136]                  ; 8-byte Folded Reload
	str	x8, [x9, #16]
	ldr	q0, [x28]
	str	q0, [x9]
	ldr	x8, [sp, #744]
	ldr	x9, [sp, #4680]
	cmp	x8, x9
	b.ne	LBB72_193
; %bb.188:                              ; %bb3.i.i.i851
	ldr	x11, [sp, #752]
	ldr	x8, [sp, #4696]
	cmp	x11, x8
	b.hs	LBB72_194
; %bb.189:                              ; %bb2.i.i.i.i855
	ldr	x12, [sp, #760]
	ldr	x8, [sp, #4712]
	mov	w9, #56                         ; =0x38
	madd	x10, x11, x9, x8
	ldr	x8, [x10, #40]
	cmp	x8, x12
	b.ne	LBB72_194
; %bb.190:                              ; %bb5.i.i.i.i863
	ldr	x8, [x10]
	cbz	x8, LBB72_194
; %bb.191:                              ; %bb2.i.i866
	ldr	x9, [x10, #32]
	cmp	x9, #8
	b.ne	LBB72_285
; %bb.192:
	mov	w8, #7                          ; =0x7
	b	LBB72_195
LBB72_193:
	mov	w8, #4                          ; =0x4
	b	LBB72_195
LBB72_194:
	mov	w8, #3                          ; =0x3
LBB72_195:                              ; %bb59
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #768]
	str	xzr, [sp, #776]
	str	w8, [sp, #784]
LBB72_196:                              ; %bb57.sink.split
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_197:                              ; %bb57
	mov	x0, x21
	mov	x1, x27
	mov	x2, x19
	bl	_wf_indexed_check$instance$34505fe33827dcb3
	ldr	q0, [x28]
	ldr	x1, [sp, #144]                  ; 8-byte Folded Reload
	str	q0, [x1]
	ldr	x8, [x28, #16]
	str	x8, [x1, #16]
	mov	x0, x21
	mov	w2, #130                        ; =0x82
	bl	_wf_record_store_reschedule$instance$3ad8b32886f5e3ce
	cbz	w0, LBB72_199
; %bb.198:                              ; %bb13.i904
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_199:                              ; %wf_indexed_status.exit917
	mov	w28, #4520                      ; =0x11a8
	mov	w8, #130                        ; =0x82
	str	x8, [sp, #2792]
	ldr	x1, [sp, #3152]
	ldr	q0, [x24]
	str	q0, [sp, #5008]
	ldr	x8, [x24, #16]
	str	x8, [sp, #5024]
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #912
	mov	x0, x21
	bl	_wf_record_store_detach$instance$3ad8b32886f5e3ce
	cbz	w0, LBB72_201
; %bb.200:                              ; %bb13.i.i924
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_201:                              ; %"wf_indexed_detach$instance$4a70da04567deb49.exit930"
	add	x27, sp, #208
	strb	wzr, [x26, #2960]
	ldr	x8, [x24, #16]
	ldr	x9, [sp, #152]                  ; 8-byte Folded Reload
	str	x8, [x9, #16]
	ldr	q0, [x24]
	str	q0, [x9]
	ldr	x8, [sp, #816]
	ldr	x9, [sp, #4680]
	cmp	x8, x9
	b.ne	LBB72_209
; %bb.202:                              ; %bb3.i932
	ldr	x10, [sp, #824]
	ldr	x8, [sp, #4696]
	cmp	x10, x8
	b.hs	LBB72_210
; %bb.203:                              ; %bb2.i.i938
	ldr	x11, [sp, #832]
	ldr	x9, [sp, #4712]
	mov	w12, #56                        ; =0x38
	madd	x10, x10, x12, x9
	ldr	x12, [x10, #40]
	cmp	x12, x11
	b.ne	LBB72_210
; %bb.204:                              ; %bb5.i.i942
	ldr	x11, [x10]
	cbz	x11, LBB72_210
; %bb.205:                              ; %bb64
	ldr	x11, [x10, #8]
	ldrb	w12, [x10, #24]
	ldr	x10, [x10, #32]
	and	w12, w12, #0x1
	strb	w12, [x22, #9]
	add	x13, sp, #208
	add	x13, x13, #649
	str	xzr, [sp, #840]
	str	x11, [sp, #848]
	strb	w12, [sp, #856]
	str	wzr, [x13]
	str	wzr, [sp, #860]
	str	x10, [sp, #864]
	ldr	q0, [sp, #848]
	ldr	x11, [sp, #32]                  ; 8-byte Folded Reload
	str	q0, [x11]
	str	x10, [x11, #16]
	mov	w10, #99                        ; =0x63
	str	x10, [sp, #4968]
	ldr	x10, [sp, #80]                  ; 8-byte Folded Reload
	ldr	q0, [x10]
	ldr	x10, [sp, #40]                  ; 8-byte Folded Reload
	str	q0, [x10]
	ldr	x10, [sp, #872]
	cmp	x10, x8
	b.hs	LBB72_263
; %bb.206:                              ; %bb2.i.i1016
	ldr	x8, [sp, #880]
	mov	w11, #56                        ; =0x38
	madd	x9, x10, x11, x9
	ldr	x10, [x9, #40]
	cmp	x10, x8
	b.ne	LBB72_263
; %bb.207:                              ; %bb5.i.i1026
	ldr	x8, [x9]
	cbz	x8, LBB72_263
; %bb.208:                              ; %bb8.i.i1029
	mov	w8, #0                          ; =0x0
	mov	w10, #99                        ; =0x63
	str	x10, [x9, #32]
	b	LBB72_264
LBB72_209:
	mov	w8, #4                          ; =0x4
	b	LBB72_211
LBB72_210:                              ; %bb5.i936
	mov	w8, #3                          ; =0x3
LBB72_211:                              ; %bb65
	str	xzr, [sp, #864]
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #848]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #840]
	str	w8, [sp, #844]
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_212:                              ; %bb63
	add	x28, x27, x28
	ldr	x20, [sp, #3152]
	ldr	q0, [x24]
	str	q0, [sp, #5008]
	ldr	x8, [x24, #16]
	str	x8, [sp, #5024]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #912
	mov	x0, x21
	bl	_wf_record_store_attach$instance$3ad8b32886f5e3ce
	cbz	w0, LBB72_214
; %bb.213:                              ; %bb13.i.i957
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_214:                              ; %bb2.i962.preheader
	mov	w8, #32                         ; =0x20
	mov	x9, x23
	ldr	x24, [sp, #200]                 ; 8-byte Folded Reload
	b	LBB72_216
LBB72_215:                              ; %bb8.i968
                                        ;   in Loop: Header=BB72_216 Depth=1
	add	x9, x9, #64
	subs	x8, x8, #1
	b.eq	LBB72_218
LBB72_216:                              ; %bb2.i962
                                        ; =>This Inner Loop Header: Depth=1
	ldur	x10, [x9, #-16]
	cmp	x10, x20
	b.ne	LBB72_215
; %bb.217:                              ; %bb6.i973
                                        ;   in Loop: Header=BB72_216 Depth=1
	strb	wzr, [x9]
	b	LBB72_215
LBB72_218:                              ; %"wf_indexed_attach$instance$4a70da04567deb49.exit975"
	mov	w8, #1                          ; =0x1
	strb	w8, [x26, #2960]
	mov	x0, x21
	mov	x1, x24
	mov	x2, x19
	bl	_wf_indexed_check$instance$34505fe33827dcb3
	mov	x0, x21
	mov	x1, x24
	mov	x2, x19
	mov	w3, #150                        ; =0x96
	bl	_wf_indexed_expire$instance$34505fe33827dcb3
	ldr	x8, [sp, #4792]
	cbz	x8, LBB72_220
; %bb.219:                              ; %bb3.i.i.i978
	mov	w9, #10                         ; =0xa
	udiv	x10, x9, x8
	msub	x9, x10, x8, x9
	ldr	x8, [sp, #4728]
	cbnz	x8, LBB72_221
	b	LBB72_233
LBB72_220:
	mov	x9, #0                          ; =0x0
	ldr	x8, [sp, #4728]
	cbz	x8, LBB72_233
LBB72_221:                              ; %bb3.i.i979
	udiv	x10, x9, x8
	msub	x9, x10, x8, x9
	ldr	x10, [sp, #4744]
	mov	x11, x8
	b	LBB72_223
LBB72_222:                              ; %bb8.i.i985
                                        ;   in Loop: Header=BB72_223 Depth=1
	add	x12, x9, #1
	cmp	x12, x8
	csinc	x9, xzr, x9, hs
	subs	x11, x11, #1
	b.eq	LBB72_233
LBB72_223:                              ; %bb5.i.i982
                                        ; =>This Inner Loop Header: Depth=1
	add	x12, x10, x9, lsl #5
	ldr	w13, [x12]
	cmp	w13, #1
	b.eq	LBB72_222
; %bb.224:                              ; %bb5.i.i982
                                        ;   in Loop: Header=BB72_223 Depth=1
	cmp	w13, #2
	b.ne	LBB72_233
; %bb.225:                              ; %bb9.i.i
                                        ;   in Loop: Header=BB72_223 Depth=1
	ldr	x13, [x12, #8]
	cmp	x13, #10
	b.ne	LBB72_222
; %bb.226:                              ; %bb3.i120.i
	ldr	x8, [x12, #16]
	ldr	x9, [sp, #4696]
	cmp	x8, x9
	b.hs	LBB72_262
; %bb.227:                              ; %bb2.i.i.i995
	ldr	x9, [x12, #24]
	ldr	x10, [sp, #4712]
	mov	w11, #56                        ; =0x38
	madd	x10, x8, x11, x10
	ldr	x11, [x10, #40]
	cmp	x11, x9
	b.ne	LBB72_262
; %bb.228:                              ; %bb5.i.i.i1003
	ldr	x11, [x10]
	cbz	x11, LBB72_262
; %bb.229:                              ; %bb3.i1006
	ldr	x10, [x10, #8]
	cmp	x10, #10
	b.ne	LBB72_297
; %bb.230:                              ; %bb70
	ldr	x10, [sp, #4680]
	add	x11, sp, #208
	add	x12, x11, #792
	str	xzr, [sp, #992]
	str	x10, [sp, #1000]
	str	x8, [sp, #1008]
	str	x9, [sp, #1016]
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x9, [x8, #16]
	ldr	q0, [x12]
	str	q0, [x8]
	add	x8, x11, #824
	ldr	q0, [sp, #1008]
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	str	q0, [x9]
	ldr	x9, [sp, #1048]
	ldr	x10, [sp, #3192]
	cmp	x9, x10
	b.eq	LBB72_232
; %bb.231:                              ; %bb73
	ldr	x9, [sp, #2624]
	add	x9, x9, #1
	str	x9, [sp, #2624]
LBB72_232:                              ; %bb72
	ldr	q0, [x8]
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	q0, [x8]
	ldr	x8, [sp, #1072]
	ldr	x9, [sp, #3200]
	cmp	x8, x9
	b.eq	LBB72_236
	b	LBB72_235
LBB72_233:
	mov	w8, #2                          ; =0x2
LBB72_234:                              ; %bb71
	add	x9, sp, #208
	add	x9, x9, #792
	movi.2d	v0, #0000000000000000
	str	q0, [x9]
	str	xzr, [sp, #1016]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #992]
	str	w8, [sp, #996]
LBB72_235:                              ; %bb69.sink.split
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_236:                              ; %bb69
	mov	x0, x21
	mov	x1, x24
	mov	x2, x19
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	_wf_indexed_expire$instance$34505fe33827dcb3
	mov	x0, x21
	mov	x1, x24
	mov	x2, x19
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	_wf_indexed_expire$instance$34505fe33827dcb3
	mov	w0, #16                         ; =0x10
	bl	_malloc
	cbz	x0, LBB72_299
; %bb.237:                              ; %wf_indexed_child.exit1123
	mov	x6, x0
Lloh194:
	adrp	x8, lCPI72_9@PAGE
Lloh195:
	ldr	q0, [x8, lCPI72_9@PAGEOFF]
	str	q0, [x0]
	mov	x0, x21
	mov	x1, x24
	mov	x2, x19
	mov	w3, #10                         ; =0xa
	mov	w4, #313                        ; =0x139
	mov	w5, #13                         ; =0xd
	bl	_wf_indexed_accept$instance$34505fe33827dcb3
	ldr	x20, [sp, #3280]
	mov	x0, x21
	add	x21, sp, #208
	ldr	q0, [sp, #3312]
	str	q0, [sp, #5008]
	ldr	x8, [sp, #3328]
	str	x8, [sp, #5024]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #912
	bl	_wf_record_store_attach$instance$3ad8b32886f5e3ce
	cbz	w0, LBB72_239
; %bb.238:                              ; %bb13.i.i1130
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_239:                              ; %bb2.i1135.preheader
	add	x8, x21, #3104
	mov	w9, #32                         ; =0x20
	ldr	x21, [sp, #192]                 ; 8-byte Folded Reload
	b	LBB72_241
LBB72_240:                              ; %bb8.i1141
                                        ;   in Loop: Header=BB72_241 Depth=1
	add	x23, x23, #64
	subs	x9, x9, #1
	b.eq	LBB72_243
LBB72_241:                              ; %bb2.i1135
                                        ; =>This Inner Loop Header: Depth=1
	ldur	x10, [x23, #-16]
	cmp	x10, x20
	b.ne	LBB72_240
; %bb.242:                              ; %bb6.i1146
                                        ;   in Loop: Header=BB72_241 Depth=1
	strb	wzr, [x23]
	b	LBB72_240
LBB72_243:                              ; %"wf_indexed_attach$instance$4a70da04567deb49.exit1148"
	mov	w20, #1                         ; =0x1
	strb	w20, [x26, #3088]
	ldr	q0, [x8]
	str	q0, [sp, #5008]
	ldr	x8, [x8, #16]
	str	x8, [sp, #5024]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #912
	mov	x0, x21
	mov	w2, #10                         ; =0xa
	bl	_wf_record_store_schedule$instance$3ad8b32886f5e3ce
	cbz	w0, LBB72_245
; %bb.244:                              ; %bb13.i.i1154
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_245:                              ; %"wf_indexed_schedule$instance$4a70da04567deb49.exit1161"
	strb	w20, [x26, #3089]
	mov	w8, #10                         ; =0xa
	str	x8, [sp, #3304]
	mov	w0, #16                         ; =0x10
	bl	_malloc
	cbz	x0, LBB72_299
; %bb.246:                              ; %wf_indexed_child.exit1166
	mov	x6, x0
Lloh196:
	adrp	x8, lCPI72_10@PAGE
Lloh197:
	ldr	q0, [x8, lCPI72_10@PAGEOFF]
	str	q0, [x0]
	mov	x0, x21
	mov	x1, x24
	mov	x2, x19
	mov	w3, #11                         ; =0xb
	mov	w4, #314                        ; =0x13a
	mov	w5, #14                         ; =0xe
	bl	_wf_indexed_accept$instance$34505fe33827dcb3
	mov	x0, x21
	mov	x1, x24
	mov	x2, x19
	bl	_wf_indexed_check$instance$34505fe33827dcb3
	ldp	q1, q0, [x21, #64]
	ldp	q3, q2, [x21, #48]
	ldr	x9, [sp, #104]                  ; 8-byte Folded Reload
	stp	q2, q0, [x9, #64]
	ldp	q2, q0, [x21, #80]
	str	q0, [x9, #96]
	ldp	q0, q4, [x21]
	stp	q0, q4, [x9]
	ldp	q0, q6, [x21, #32]
	ldp	q5, q4, [x21]
	ldr	q7, [x21, #32]
	stp	q0, q6, [x9, #32]
	str	q1, [sp, #5072]
	str	q2, [sp, #5088]
	ldr	q0, [x21, #96]
	str	q0, [sp, #5104]
	str	q5, [sp, #5008]
	str	q4, [sp, #5024]
	ldr	x8, [x21, #112]
	str	x8, [x9, #112]
	ldr	x8, [x21, #112]
	str	q7, [sp, #5040]
	str	q3, [sp, #5056]
	ldr	x9, [sp, #88]                   ; 8-byte Folded Reload
	ldp	q0, q1, [x9]
	stur	q1, [x22, #145]
	stur	q0, [x22, #129]
	ldp	q0, q1, [x28]
	stur	q0, [x22, #161]
	ldr	x9, [x28, #32]
	str	x8, [sp, #5120]
	str	x9, [sp, #5192]
	stur	q1, [x22, #177]
	ldr	x8, [sp, #4784]
	ldr	q0, [sp, #4768]
	str	q0, [sp, #5200]
	ldr	x9, [sp, #5120]
	ldr	x10, [sp, #5168]
	str	x8, [sp, #5216]
	str	x9, [sp, #5224]
	cbz	x10, LBB72_248
; %bb.247:                              ; %slots.release.drop.6.i.i.i
	ldr	x0, [sp, #5176]
	bl	_free
LBB72_248:                              ; %"wf_std.collections.hash_map.hash_map_free$instance$062aa17160873f66.exit.i"
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #912
	ldr	x8, [sp, #5208]
	cbz	x8, LBB72_250
; %bb.249:                              ; %slots.release.drop.6.i.i2.i
	ldr	x0, [sp, #5216]
	bl	_free
LBB72_250:                              ; %"wf_record_store_free$instance$e67a16f596c8720d.exit"
	add	x0, x20, #120
	mov	x1, x19
	bl	_wf_std.collections.slab.slab_free$instance$7c376bc3f4ad4ade
	ldp	q1, q0, [x25, #64]
	ldp	q3, q2, [x25, #48]
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	stp	q2, q0, [x9, #64]
	ldp	q2, q0, [x25, #80]
	str	q0, [x9, #96]
	ldp	q0, q4, [x25]
	stp	q0, q4, [x9]
	ldp	q0, q6, [x25, #32]
	ldp	q5, q4, [x25]
	ldr	q7, [x25, #32]
	stp	q0, q6, [x9, #32]
	str	q1, [sp, #5072]
	str	q2, [sp, #5088]
	ldr	q0, [x25, #96]
	str	q0, [sp, #5104]
	str	q5, [sp, #5008]
	str	q4, [sp, #5024]
	ldr	x8, [x25, #112]
	str	x8, [x9, #112]
	ldr	x8, [x25, #112]
	str	q7, [sp, #5040]
	str	q3, [sp, #5056]
	ldr	x9, [sp, #96]                   ; 8-byte Folded Reload
	ldp	q0, q1, [x9]
	stur	q1, [x22, #145]
	stur	q0, [x22, #129]
	ldr	q0, [sp, #4848]
	stur	q0, [x22, #161]
	ldr	x9, [sp, #4880]
	str	x8, [sp, #5120]
	str	x9, [sp, #5192]
	ldr	q0, [sp, #4864]
	stur	q0, [x22, #177]
	mov	w8, #4680                       ; =0x1248
	add	x9, sp, #208
	ldr	q0, [x9, x8]
	ldr	x8, [sp, #4904]
	str	q0, [sp, #5200]
	ldr	x9, [sp, #5120]
	ldr	x10, [sp, #5168]
	str	x8, [sp, #5216]
	str	x9, [sp, #5224]
	cbz	x10, LBB72_252
; %bb.251:                              ; %slots.release.drop.6.i.i.i1180
	ldr	x0, [sp, #5176]
	bl	_free
LBB72_252:                              ; %"wf_std.collections.hash_map.hash_map_free$instance$062aa17160873f66.exit.i1183"
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #912
	ldr	x8, [sp, #5208]
	cbz	x8, LBB72_254
; %bb.253:                              ; %slots.release.drop.6.i.i2.i1187
	ldr	x0, [sp, #5216]
	bl	_free
LBB72_254:                              ; %"wf_record_store_free$instance$e67a16f596c8720d.exit1191"
	add	x0, x20, #120
	mov	x1, x19
	bl	_wf_std.collections.slab.slab_free$instance$7c376bc3f4ad4ade
	mov	w8, #64                         ; =0x40
	ldr	x0, [sp, #2624]
	b	LBB72_256
LBB72_255:                              ; %bb88
                                        ;   in Loop: Header=BB72_256 Depth=1
	add	x19, x19, #8
	subs	x8, x8, #1
	b.eq	LBB72_258
LBB72_256:                              ; %bb79
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x19]
	cmp	x9, #0
	cset	w9, ne
	ldr	x10, [x19, #512]
	cmp	x10, x9
	b.eq	LBB72_255
; %bb.257:                              ; %bb86
                                        ;   in Loop: Header=BB72_256 Depth=1
	add	x0, x0, #1
	str	x0, [sp, #2624]
	b	LBB72_255
LBB72_258:                              ; %bb81
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #1136
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB72_259:
	mov	w8, #3                          ; =0x3
	b	LBB72_130
LBB72_260:
	mov	w8, #3                          ; =0x3
LBB72_261:                              ; %bb13.i697
	str	w8, [sp, #632]
	str	x0, [sp, #4936]
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x0, [sp, #640]
	str	x8, [sp, #2624]
	ldp	x9, x8, [x0]
	cmp	x9, #12
	b.eq	LBB72_159
	b	LBB72_160
LBB72_262:
	mov	w8, #3                          ; =0x3
	b	LBB72_234
LBB72_263:
	mov	w8, #1                          ; =0x1
LBB72_264:                              ; %"wf_std.collections.slab.slab_edit$instance$f11a17af73d113d5.exit"
	str	w8, [sp, #888]
	strh	wzr, [sp, #892]
	ldr	q0, [x24]
	ldr	x1, [sp, #48]                   ; 8-byte Folded Reload
	str	q0, [x1]
	ldr	x8, [x24, #16]
	str	x8, [x1, #16]
	mov	x0, x21
	bl	_wf_record_store_cancel$instance$3ad8b32886f5e3ce
	cmp	w0, #7
	b.hi	LBB72_266
; %bb.265:                              ; %bb13.i1036
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_266:                              ; %wf_indexed_status.exit1049
	ldr	w8, [sp, #188]                  ; 4-byte Folded Reload
	tbz	w8, #0, LBB72_268
; %bb.267:                              ; %bb67
	mov	x0, x21
	ldr	x1, [sp, #200]                  ; 8-byte Folded Reload
	mov	x2, x19
	mov	w3, #8                          ; =0x8
	mov	w4, #9                          ; =0x9
	bl	_wf_indexed_delete$instance$34505fe33827dcb3
LBB72_268:                              ; %bb66
	str	xzr, [sp, #4976]
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	ldr	q0, [x8]
	ldr	x8, [sp, #56]                   ; 8-byte Folded Reload
	str	q0, [x8]
	ldr	x8, [sp, #920]
	ldr	x9, [sp, #4696]
	cmp	x8, x9
	b.hs	LBB72_272
; %bb.269:                              ; %bb2.i.i1060
	ldr	x10, [sp, #928]
	ldr	x9, [sp, #4712]
	mov	w11, #56                        ; =0x38
	madd	x9, x8, x11, x9
	ldr	x8, [x9, #40]
	cmp	x8, x10
	b.ne	LBB72_272
; %bb.270:                              ; %bb5.i.i1070
	ldr	x8, [x9]
	cbz	x8, LBB72_272
; %bb.271:                              ; %bb8.i.i1073
	mov	w8, #0                          ; =0x0
	str	xzr, [x9, #32]
	b	LBB72_273
LBB72_272:
	mov	w8, #1                          ; =0x1
LBB72_273:                              ; %"wf_std.collections.slab.slab_edit$instance$f11a17af73d113d5.exit1076"
	str	w8, [sp, #936]
	strh	wzr, [sp, #940]
	ldr	q0, [x24]
	ldr	x1, [sp, #64]                   ; 8-byte Folded Reload
	str	q0, [x1]
	ldr	x8, [x24, #16]
	str	x8, [x1, #16]
	mov	x0, x21
	mov	w2, #1                          ; =0x1
	bl	_wf_record_store_reschedule$instance$3ad8b32886f5e3ce
	cmp	w0, #7
	b.hi	LBB72_275
; %bb.274:                              ; %bb13.i1081
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
LBB72_275:                              ; %wf_indexed_status.exit1094
	ldp	x8, x9, [sp, #72]               ; 16-byte Folded Reload
	ldr	q0, [x9]
	str	q0, [x8]
	ldr	x8, [sp, #968]
	ldr	x9, [sp, #4696]
	cmp	x8, x9
	b.hs	LBB72_279
; %bb.276:                              ; %bb2.i.i1102
	ldr	x10, [sp, #976]
	ldr	x9, [sp, #4712]
	mov	w11, #56                        ; =0x38
	madd	x9, x8, x11, x9
	ldr	x8, [x9, #40]
	cmp	x8, x10
	b.ne	LBB72_279
; %bb.277:                              ; %bb5.i.i1112
	ldr	x8, [x9]
	cbz	x8, LBB72_279
; %bb.278:                              ; %bb8.i.i1115
	mov	w8, #0                          ; =0x0
	ldr	x10, [sp, #4960]
	str	x10, [x9, #32]
	b	LBB72_280
LBB72_279:
	mov	w8, #1                          ; =0x1
LBB72_280:                              ; %"wf_std.collections.slab.slab_edit$instance$f11a17af73d113d5.exit1118"
	str	w8, [sp, #984]
	strh	wzr, [sp, #988]
	b	LBB72_212
LBB72_281:                              ; %bb6.i.i
	ldr	x13, [sp, #4768]
	cmp	x10, x13
	b.hs	LBB72_290
; %bb.282:                              ; %bb8.i.i814
	ldr	x13, [sp, #4784]
	add	x13, x13, x10, lsl #5
	ldp	x14, x15, [x13, #16]
	cmp	x14, x9
	ccmp	x15, x11, #0, eq
	b.ne	LBB72_290
; %bb.283:                              ; %bb11.i.i816
	ldr	x9, [x12, #8]
	ldr	x11, [x13, #8]
	cmp	x11, x9
	b.ne	LBB72_290
; %bb.284:                              ; %bb52
	str	wzr, [sp, #696]
	str	x10, [sp, #704]
	str	wzr, [sp, #712]
	cbnz	x10, LBB72_184
	b	LBB72_185
LBB72_285:                              ; %bb6.i.i872
	ldr	x8, [sp, #4768]
	cmp	x9, x8
	b.hs	LBB72_291
; %bb.286:                              ; %bb8.i.i876
	ldr	x8, [sp, #4784]
	add	x13, x8, x9, lsl #5
	ldr	x14, [x13, #16]
	mov	w8, #8                          ; =0x8
	cmp	x14, x11
	b.ne	LBB72_195
; %bb.287:                              ; %bb8.i.i876
	ldr	x11, [x13, #24]
	cmp	x11, x12
	b.ne	LBB72_195
; %bb.288:                              ; %bb11.i.i888
	ldr	x8, [x10, #8]
	ldr	x10, [x13, #8]
	cmp	x10, x8
	b.ne	LBB72_291
; %bb.289:                              ; %bb58
	str	wzr, [sp, #768]
	str	x9, [sp, #776]
	str	wzr, [sp, #784]
	cbnz	x9, LBB72_197
	b	LBB72_196
LBB72_290:
	mov	w9, #8                          ; =0x8
	b	LBB72_183
LBB72_291:
	mov	w8, #8                          ; =0x8
	b	LBB72_195
LBB72_292:                              ; %bb8.i.i300
	sub	x10, x13, #1
	add	x13, x12, x10, lsl #5
	str	x10, [x12]
	ldur	q0, [x13, #8]
	str	q0, [sp, #5008]
	ldur	q0, [x13, #24]
	str	q0, [sp, #5024]
	cmp	x9, #1
	b.hi	LBB72_294
; %bb.293:                              ; %bb11.i.i302
	add	x9, x9, #1
	mov	w10, #56                        ; =0x38
	madd	x10, x8, x10, x11
	str	x9, [x10, #40]
	ldr	x9, [sp, #4720]
	str	x9, [x10, #48]
	str	x8, [sp, #4720]
LBB72_294:                              ; %bb16
	str	xzr, [sp, #344]
	ldr	q0, [sp, #5008]
	ldr	q1, [sp, #5024]
	stp	q0, q1, [sp, #352]
	stp	q0, q1, [x26, #176]
	ldr	x8, [sp, #2624]
	add	x8, x8, #1
	str	x8, [sp, #2624]
	add	x1, x26, #176
	mov	x0, x19
	bl	_wf_indexed_release$instance$cfa19887953541da
	ldp	x10, x8, [sp, #288]
	ldr	x9, [sp, #304]
	b	LBB72_55
LBB72_295:
	mov	w8, #5                          ; =0x5
	b	LBB72_130
LBB72_296:
	mov	w8, #5                          ; =0x5
	b	LBB72_261
LBB72_297:
	mov	w8, #5                          ; =0x5
	b	LBB72_234
LBB72_298:
	mov	w10, #3                         ; =0x3
	b	LBB72_132
LBB72_299:                              ; %box.new.oom.v1.i.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh170, Lloh171
	.loh AdrpLdr	Lloh172, Lloh173
	.loh AdrpLdr	Lloh176, Lloh177
	.loh AdrpAdrp	Lloh174, Lloh176
	.loh AdrpLdr	Lloh174, Lloh175
	.loh AdrpLdr	Lloh178, Lloh179
	.loh AdrpLdr	Lloh180, Lloh181
	.loh AdrpLdr	Lloh182, Lloh183
	.loh AdrpLdr	Lloh186, Lloh187
	.loh AdrpAdrp	Lloh184, Lloh186
	.loh AdrpLdr	Lloh184, Lloh185
	.loh AdrpLdr	Lloh188, Lloh189
	.loh AdrpLdr	Lloh190, Lloh191
	.loh AdrpLdr	Lloh192, Lloh193
	.loh AdrpLdr	Lloh194, Lloh195
	.loh AdrpLdr	Lloh196, Lloh197
	.loh AdrpLdrGot	Lloh168, Lloh169
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_indexed_trace$instance$276fd431a73a5d55
lCPI73_0:
	.quad	12                              ; 0xc
	.quad	23                              ; 0x17
lCPI73_1:
	.quad	34                              ; 0x22
	.quad	45                              ; 0x2d
lCPI73_2:
	.quad	67                              ; 0x43
	.quad	78                              ; 0x4e
lCPI73_3:
	.quad	15                              ; 0xf
	.quad	116                             ; 0x74
lCPI73_4:
	.quad	26                              ; 0x1a
	.quad	37                              ; 0x25
lCPI73_5:
	.quad	48                              ; 0x30
	.quad	59                              ; 0x3b
lCPI73_6:
	.quad	70                              ; 0x46
	.quad	81                              ; 0x51
lCPI73_7:
	.quad	1                               ; 0x1
	.quad	901                             ; 0x385
lCPI73_8:
	.quad	8                               ; 0x8
	.quad	0                               ; 0x0
lCPI73_10:
	.quad	22                              ; 0x16
	.quad	33                              ; 0x21
lCPI73_11:
	.quad	44                              ; 0x2c
	.quad	55                              ; 0x37
lCPI73_12:
	.quad	9                               ; 0x9
	.quad	110                             ; 0x6e
lCPI73_13:
	.quad	31                              ; 0x1f
	.quad	42                              ; 0x2a
lCPI73_14:
	.quad	53                              ; 0x35
	.quad	64                              ; 0x40
lCPI73_15:
	.quad	75                              ; 0x4b
	.quad	86                              ; 0x56
lCPI73_16:
	.quad	1                               ; 0x1
	.quad	10                              ; 0xa
lCPI73_17:
	.quad	20                              ; 0x14
	.quad	31                              ; 0x1f
lCPI73_18:
	.quad	42                              ; 0x2a
	.quad	53                              ; 0x35
lCPI73_19:
	.quad	64                              ; 0x40
	.quad	75                              ; 0x4b
lCPI73_20:
	.quad	10                              ; 0xa
	.quad	111                             ; 0x6f
lCPI73_21:
	.quad	32                              ; 0x20
	.quad	43                              ; 0x2b
lCPI73_22:
	.quad	54                              ; 0x36
	.quad	65                              ; 0x41
lCPI73_23:
	.quad	76                              ; 0x4c
	.quad	87                              ; 0x57
lCPI73_24:
	.quad	11                              ; 0xb
	.quad	112                             ; 0x70
lCPI73_25:
	.quad	66                              ; 0x42
	.quad	77                              ; 0x4d
lCPI73_26:
	.quad	12                              ; 0xc
	.quad	113                             ; 0x71
lCPI73_27:
	.quad	56                              ; 0x38
	.quad	67                              ; 0x43
lCPI73_28:
	.quad	78                              ; 0x4e
	.quad	89                              ; 0x59
lCPI73_29:
	.quad	13                              ; 0xd
	.quad	114                             ; 0x72
lCPI73_30:
	.quad	24                              ; 0x18
	.quad	35                              ; 0x23
lCPI73_31:
	.quad	46                              ; 0x2e
	.quad	57                              ; 0x39
lCPI73_32:
	.quad	68                              ; 0x44
	.quad	79                              ; 0x4f
lCPI73_33:
	.quad	14                              ; 0xe
	.quad	115                             ; 0x73
lCPI73_34:
	.quad	25                              ; 0x19
	.quad	36                              ; 0x24
lCPI73_35:
	.quad	47                              ; 0x2f
	.quad	58                              ; 0x3a
lCPI73_36:
	.quad	69                              ; 0x45
	.quad	80                              ; 0x50
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI73_9:
	.long	1                               ; 0x1
	.long	4                               ; 0x4
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_indexed_trace$instance$276fd431a73a5d55
	.p2align	2
_wf_indexed_trace$instance$276fd431a73a5d55: ; @"wf_indexed_trace$instance$276fd431a73a5d55"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	mov	w9, #6480                       ; =0x1950
Lloh198:
	adrp	x16, ___chkstk_darwin@GOTPAGE
Lloh199:
	ldr	x16, [x16, ___chkstk_darwin@GOTPAGEOFF]
	blr	x16
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2384
	.cfi_def_cfa_offset 6576
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	mov	x25, x0
	add	x24, sp, #1, lsl #12            ; =4096
	add	x24, x24, #2279
	add	x20, sp, #352
	add	x21, x20, #3520
	mov	x23, x21
	add	x10, x20, #640
	add	x8, x20, #712
	stp	x10, x8, [sp, #88]              ; 16-byte Folded Spill
	add	x8, x20, #800
	str	x8, [sp, #104]                  ; 8-byte Folded Spill
	add	x10, x20, #824
	add	x8, x20, #848
	stp	x10, x8, [sp, #240]             ; 16-byte Folded Spill
	add	x8, x20, #872
	str	x8, [sp, #256]                  ; 8-byte Folded Spill
	add	x10, x20, #960
	add	x8, x20, #984
	str	x8, [sp, #208]                  ; 8-byte Folded Spill
	add	x8, x20, #1120
	stp	x8, x10, [sp, #224]             ; 16-byte Folded Spill
	add	x10, x20, #1184
	add	x11, x20, #1320
	add	x8, x20, #1384
	stp	x11, x8, [sp, #136]             ; 16-byte Folded Spill
	add	x11, x20, #1408
	add	x8, x20, #1456
	stp	x11, x8, [sp, #152]             ; 16-byte Folded Spill
	add	x11, x20, #1480
	add	x8, x20, #1528
	stp	x11, x8, [sp, #168]             ; 16-byte Folded Spill
	add	x8, x20, #1552
	stp	x8, x10, [sp, #184]             ; 16-byte Folded Spill
	add	x8, x20, #1608
	str	x8, [sp, #40]                   ; 8-byte Folded Spill
	add	x10, x20, #1632
	add	x8, x20, #1656
	stp	x10, x8, [sp, #56]              ; 16-byte Folded Spill
	mov	w8, #5544                       ; =0x15a8
	add	x22, x20, x8
	mov	w8, #5664                       ; =0x1620
	add	x8, x20, x8
	str	x8, [sp, #272]                  ; 8-byte Folded Spill
	mov	w8, #5784                       ; =0x1698
	add	x8, x20, x8
	str	x8, [sp, #112]                  ; 8-byte Folded Spill
	mov	w8, #5848                       ; =0x16d8
	add	x8, x20, x8
	str	x8, [sp, #216]                  ; 8-byte Folded Spill
	mov	w8, #5912                       ; =0x1718
	add	x8, x20, x8
	str	x8, [sp, #200]                  ; 8-byte Folded Spill
	mov	w8, #5976                       ; =0x1758
	add	x8, x20, x8
	str	x8, [sp, #32]                   ; 8-byte Folded Spill
	add	x10, x20, #1680
	add	x8, x20, #1704
	stp	x10, x8, [sp, #72]              ; 16-byte Folded Spill
	add	x10, x20, #1760
	add	x8, x20, #1784
	stp	x10, x8, [sp, #8]               ; 16-byte Folded Spill
	add	x8, x20, #1800
	str	x8, [sp, #24]                   ; 8-byte Folded Spill
	add	x10, x20, #1944
	add	x8, x20, #2064
	stp	x10, x8, [sp, #120]             ; 16-byte Folded Spill
	add	x19, x20, #2184
	add	x8, x20, #3496
	str	x8, [sp, #344]                  ; 8-byte Folded Spill
	mov	x0, x19
	mov	w1, #1312                       ; =0x520
	bl	_bzero
	strb	wzr, [x24, #9]
	strh	wzr, [x24]
	and	w26, wzr, #0xff
	and	w27, wzr, #0xff
	and	w24, wzr, #0xff
	mov	x0, x21
	mov	w1, #2024                       ; =0x7e8
	bl	_bzero
	str	x26, [sp, #3848]
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #3856]
	strb	w27, [sp, #3872]
	strb	w24, [sp, #3873]
	add	x8, x20, #3528
	str	q0, [x8]
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp, #3896]
	strb	w26, [sp, #3912]
	str	q0, [sp, #3920]
	strb	w27, [sp, #3936]
	strb	w24, [sp, #3937]
	add	x9, x20, #3592
	str	q0, [x9]
	str	x8, [sp, #3960]
	strb	w26, [sp, #3976]
	str	q0, [sp, #3984]
	strb	w27, [sp, #4000]
	strb	w24, [sp, #4001]
	add	x9, x20, #3656
	str	q0, [x9]
	str	x8, [sp, #4024]
	strb	w26, [sp, #4040]
	str	q0, [sp, #4048]
	strb	w27, [sp, #4064]
	strb	w24, [sp, #4065]
	add	x9, x20, #3720
	str	q0, [x9]
	str	x8, [sp, #4088]
	add	x9, sp, #9
	strb	w26, [x9, #4095]
	str	q0, [sp, #4112]
	add	x9, sp, #33
	strb	w27, [x9, #4095]
	add	x9, sp, #34
	strb	w24, [x9, #4095]
	add	x9, x20, #3784
	str	q0, [x9]
	str	x8, [sp, #4152]
	add	x9, sp, #73
	strb	w26, [x9, #4095]
	str	q0, [sp, #4176]
	add	x9, sp, #97
	strb	w27, [x9, #4095]
	add	x9, sp, #98
	strb	w24, [x9, #4095]
	add	x9, x20, #3848
	str	q0, [x9]
	str	x8, [sp, #4216]
	add	x9, sp, #137
	strb	w26, [x9, #4095]
	str	q0, [sp, #4240]
	add	x9, sp, #161
	strb	w27, [x9, #4095]
	add	x9, sp, #162
	strb	w24, [x9, #4095]
	add	x9, x20, #3912
	str	q0, [x9]
	str	x8, [sp, #4280]
	add	x9, sp, #201
	strb	w26, [x9, #4095]
	str	q0, [sp, #4304]
	strb	w27, [x20, #3968]
	strb	w24, [x20, #3969]
	add	x9, x20, #3976
	str	q0, [x9]
	str	x8, [sp, #4344]
	strb	w26, [x20, #4008]
	str	q0, [sp, #4368]
	strb	w27, [x20, #4032]
	strb	w24, [x20, #4033]
	add	x9, x20, #4040
	add	x10, x20, #4056
	str	x10, [sp, #48]                  ; 8-byte Folded Spill
	str	q0, [x9]
	str	x8, [sp, #4408]
	strb	w26, [x20, #4072]
	str	q0, [sp, #4432]
	strb	w27, [x21, #576]
	strb	w24, [x21, #577]
	mov	w9, #4104                       ; =0x1008
	str	q0, [x20, x9]
	str	x8, [sp, #4472]
	strb	w26, [x21, #616]
	str	q0, [sp, #4496]
	strb	w27, [x21, #640]
	strb	w24, [x21, #641]
	mov	w9, #4168                       ; =0x1048
	str	q0, [x20, x9]
	str	x8, [sp, #4536]
	strb	w26, [x21, #680]
	str	q0, [sp, #4560]
	strb	w27, [x21, #704]
	mov	w9, #4232                       ; =0x1088
	str	q0, [x20, x9]
	strb	w24, [x21, #705]
	str	x8, [sp, #4600]
	strb	w26, [x21, #744]
	str	q0, [sp, #4624]
	strb	w27, [x21, #768]
	strb	w24, [x21, #769]
	mov	w9, #4296                       ; =0x10c8
	str	q0, [x20, x9]
	str	x8, [sp, #4664]
	strb	w26, [x21, #808]
	str	q0, [sp, #4688]
	strb	w27, [x21, #832]
	strb	w24, [x21, #833]
	mov	w9, #4360                       ; =0x1108
	str	q0, [x20, x9]
	str	x8, [sp, #4728]
	strb	w26, [x21, #872]
	str	q0, [sp, #4752]
	strb	w27, [x21, #896]
	mov	w9, #4424                       ; =0x1148
	str	q0, [x20, x9]
	strb	w24, [x21, #897]
	str	x8, [sp, #4792]
	str	xzr, [sp, #4800]
	strb	w26, [x21, #936]
	str	q0, [sp, #4816]
	strb	w27, [x21, #960]
	strb	w24, [x21, #961]
	mov	w9, #4488                       ; =0x1188
	str	q0, [x20, x9]
	str	x8, [sp, #4856]
	str	xzr, [sp, #4864]
	strb	w26, [x21, #1000]
	str	q0, [sp, #4880]
	strb	w27, [x21, #1024]
	mov	w9, #4552                       ; =0x11c8
	str	q0, [x20, x9]
	strb	w24, [x21, #1025]
	str	x8, [sp, #4920]
	str	xzr, [sp, #4928]
	strb	w26, [x21, #1064]
	str	q0, [sp, #4944]
	strb	w27, [x21, #1088]
	strb	w24, [x21, #1089]
	mov	w9, #4616                       ; =0x1208
	str	q0, [x20, x9]
	str	x8, [sp, #4984]
	str	xzr, [sp, #4992]
	strb	w26, [x21, #1128]
	str	q0, [sp, #5008]
	strb	w27, [x21, #1152]
	mov	w9, #4680                       ; =0x1248
	str	q0, [x20, x9]
	strb	w24, [x21, #1153]
	str	x8, [sp, #5048]
	str	xzr, [sp, #5056]
	strb	w26, [x21, #1192]
	str	q0, [sp, #5072]
	strb	w27, [x21, #1216]
	strb	w24, [x21, #1217]
	mov	w9, #4744                       ; =0x1288
	str	q0, [x20, x9]
	str	x8, [sp, #5112]
	str	xzr, [sp, #5120]
	strb	w26, [x21, #1256]
	str	q0, [sp, #5136]
	strb	w27, [x21, #1280]
	mov	w9, #4808                       ; =0x12c8
	str	q0, [x20, x9]
	strb	w24, [x21, #1281]
	str	x8, [sp, #5176]
	str	xzr, [sp, #5184]
	strb	w26, [x21, #1320]
	str	q0, [sp, #5200]
	strb	w27, [x21, #1344]
	strb	w24, [x21, #1345]
	mov	w9, #4872                       ; =0x1308
	str	q0, [x20, x9]
	str	x8, [sp, #5240]
	str	xzr, [sp, #5248]
	strb	w26, [x21, #1384]
	str	q0, [sp, #5264]
	strb	w27, [x21, #1408]
	mov	w9, #4936                       ; =0x1348
	str	q0, [x20, x9]
	strb	w24, [x21, #1409]
	str	x8, [sp, #5304]
	str	xzr, [sp, #5312]
	strb	w26, [x21, #1448]
	str	q0, [sp, #5328]
	strb	w27, [x21, #1472]
	strb	w24, [x21, #1473]
	mov	w9, #5000                       ; =0x1388
	str	q0, [x20, x9]
	str	x8, [sp, #5368]
	str	xzr, [sp, #5376]
	strb	w26, [x21, #1512]
	str	q0, [sp, #5392]
	strb	w27, [x21, #1536]
	mov	w9, #5064                       ; =0x13c8
	str	q0, [x20, x9]
	strb	w24, [x21, #1537]
	str	x8, [sp, #5432]
	str	xzr, [sp, #5440]
	strb	w26, [x21, #1576]
	str	q0, [sp, #5456]
	strb	w27, [x21, #1600]
	strb	w24, [x21, #1601]
	mov	w9, #5128                       ; =0x1408
	str	q0, [x20, x9]
	str	x8, [sp, #5496]
	str	xzr, [sp, #5504]
	strb	w26, [x21, #1640]
	str	q0, [sp, #5520]
	strb	w27, [x21, #1664]
	mov	w9, #5192                       ; =0x1448
	str	q0, [x20, x9]
	strb	w24, [x21, #1665]
	str	x8, [sp, #5560]
	str	xzr, [sp, #5568]
	strb	w26, [x21, #1704]
	str	q0, [sp, #5584]
	strb	w27, [x21, #1728]
	strb	w24, [x21, #1729]
	mov	w9, #5256                       ; =0x1488
	str	q0, [x20, x9]
	str	x8, [sp, #5624]
	str	xzr, [sp, #5632]
	strb	w26, [x21, #1768]
	str	q0, [sp, #5648]
	strb	w27, [x21, #1792]
	mov	w9, #5320                       ; =0x14c8
	str	q0, [x20, x9]
	strb	w24, [x21, #1793]
	str	x8, [sp, #5688]
	str	xzr, [sp, #5696]
	strb	w26, [x21, #1832]
	str	q0, [sp, #5712]
	strb	w27, [x21, #1856]
	strb	w24, [x21, #1857]
	mov	w9, #5384                       ; =0x1508
	str	q0, [x20, x9]
	str	x8, [sp, #5752]
	str	xzr, [sp, #5760]
	strb	w26, [x21, #1896]
	str	q0, [sp, #5776]
	strb	w27, [x21, #1920]
	mov	w9, #5448                       ; =0x1548
	str	q0, [x20, x9]
	strb	w24, [x21, #1921]
	str	x8, [sp, #5816]
	str	xzr, [sp, #5824]
	strb	w26, [x21, #1960]
	str	q0, [sp, #5840]
	strb	w27, [x21, #1984]
	str	x21, [sp, #264]                 ; 8-byte Folded Spill
	strb	w24, [x21, #1985]
	mov	w9, #5512                       ; =0x1588
	str	q0, [x20, x9]
	str	x8, [sp, #5880]
	str	xzr, [sp, #5888]
	mov	x0, x22
	mov	w1, #71                         ; =0x47
	str	w25, [sp, #284]                 ; 4-byte Folded Spill
	mov	x2, x25
	mov	w3, #8                          ; =0x8
	mov	x4, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	mov	x6, #0                          ; =0x0
	bl	_wf_record_store_new$instance$f8195bc386aec277
	mov	x27, #0                         ; =0x0
Lloh200:
	adrp	x8, lCPI73_0@PAGE
Lloh201:
	ldr	q0, [x8, lCPI73_0@PAGEOFF]
	str	q0, [sp, #304]                  ; 16-byte Folded Spill
Lloh202:
	adrp	x8, lCPI73_1@PAGE
Lloh203:
	ldr	q0, [x8, lCPI73_1@PAGEOFF]
	str	q0, [sp, #320]                  ; 16-byte Folded Spill
	mov	w24, #1                         ; =0x1
Lloh204:
	adrp	x8, lCPI73_2@PAGE
Lloh205:
	ldr	q0, [x8, lCPI73_2@PAGEOFF]
	str	q0, [sp, #288]                  ; 16-byte Folded Spill
	mov	w21, #10                        ; =0xa
	mov	x28, #100                       ; =0x64
	b	LBB73_2
LBB73_1:                                ; %"wf_indexed_schedule$instance$e1380248266a9ad2.exit"
                                        ;   in Loop: Header=BB73_2 Depth=1
	strb	w24, [x20, #25]
	str	x27, [x20, #32]
	mov	x27, x26
	cmp	x26, #8
	b.eq	LBB73_11
LBB73_2:                                ; %bb2
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB73_7 Depth 2
	mov	w0, #16                         ; =0x10
	bl	_malloc
	cbz	x0, LBB73_279
; %bb.3:                                ; %wf_indexed_wide.exit
                                        ;   in Loop: Header=BB73_2 Depth=1
	add	x26, x27, #1
	add	x8, x27, #102
	stp	x26, x8, [x0]
	dup.2d	v0, x27
	ldp	q1, q2, [sp, #304]              ; 32-byte Folded Reload
	add.2d	v1, v0, v1
	add.2d	v2, v0, v2
	orr	x8, x27, #0x38
	ldr	q3, [sp, #288]                  ; 16-byte Folded Reload
	add.2d	v0, v0, v3
	str	x0, [sp, #352]
	add	x9, sp, #105
	stur	q1, [x9, #255]
	add	x9, sp, #121
	stur	q2, [x9, #255]
	str	x8, [sp, #392]
	str	q0, [sp, #400]
	add	x4, x27, #10
	add	x6, sp, #352
	mov	x0, x22
	ldr	x20, [sp, #344]                 ; 8-byte Folded Reload
	mov	x1, x20
	mov	x2, x19
	mov	x3, x27
	mov	x5, x26
	bl	_wf_indexed_accept$instance$276fd431a73a5d55
	add	x20, x20, x27, lsl #6
	ldr	x25, [x20, #8]
	ldur	q0, [x20, #40]
	str	q0, [sp, #6384]
	ldr	x8, [x20, #56]
	str	x8, [sp, #6400]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2288
	mov	x0, x22
	bl	_wf_record_store_attach$instance$f8195bc386aec277
	cbz	w0, LBB73_5
; %bb.4:                                ; %bb13.i.i
                                        ;   in Loop: Header=BB73_2 Depth=1
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_5:                                ; %bb2.i.preheader
                                        ;   in Loop: Header=BB73_2 Depth=1
	mov	x8, x23
	mov	w9, #32                         ; =0x20
	b	LBB73_7
LBB73_6:                                ; %bb8.i
                                        ;   in Loop: Header=BB73_7 Depth=2
	add	x8, x8, #64
	subs	x9, x9, #1
	b.eq	LBB73_9
LBB73_7:                                ; %bb2.i
                                        ;   Parent Loop BB73_2 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	x10, [x8, #-16]
	cmp	x10, x25
	b.ne	LBB73_6
; %bb.8:                                ; %bb6.i
                                        ;   in Loop: Header=BB73_7 Depth=2
	strb	wzr, [x8]
	b	LBB73_6
LBB73_9:                                ; %"wf_indexed_attach$instance$e1380248266a9ad2.exit"
                                        ;   in Loop: Header=BB73_2 Depth=1
	lsl	x8, x27, #6
	strb	w24, [x23, x8]
	madd	x27, x27, x21, x28
	ldur	q0, [x20, #40]
	str	q0, [sp, #6384]
	ldur	x8, [x20, #56]
	str	x8, [sp, #6400]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2288
	mov	x0, x22
	mov	x2, x27
	bl	_wf_record_store_schedule$instance$f8195bc386aec277
	cbz	w0, LBB73_1
; %bb.10:                               ; %bb13.i.i100
                                        ;   in Loop: Header=BB73_2 Depth=1
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
	b	LBB73_1
LBB73_11:                               ; %bb4
	mov	x0, x22
	ldr	x21, [sp, #344]                 ; 8-byte Folded Reload
	mov	x1, x21
	mov	x2, x19
	bl	_wf_indexed_check$instance$276fd431a73a5d55
	add	x8, sp, #352
	add	x27, x8, #3536
	ldr	q0, [sp, #3888]
	add	x24, sp, #352
	stur	q0, [x24, #64]
	ldr	x8, [sp, #3904]
	stur	x8, [x24, #80]
	add	x1, x24, #64
	mov	x0, x22
	bl	_wf_record_store_attach$instance$f8195bc386aec277
	cmp	w0, #1
	b.eq	LBB73_13
; %bb.12:                               ; %bb13.i
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_13:                               ; %wf_indexed_status.exit
	ldr	q0, [x27]
	stur	q0, [x24, #88]
	ldr	x8, [x27, #16]
	stur	x8, [x24, #104]
	add	x1, x24, #88
	mov	x0, x22
	mov	w2, #99                         ; =0x63
	bl	_wf_record_store_schedule$instance$f8195bc386aec277
	cmp	w0, #1
	ldp	x28, x25, [sp, #264]            ; 16-byte Folded Reload
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #2279
	b.eq	LBB73_15
; %bb.14:                               ; %bb13.i113
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_15:                               ; %wf_indexed_status.exit126
	mov	x0, x22
	mov	x1, x21
	mov	x2, x19
	mov	x3, #0                          ; =0x0
	bl	_wf_indexed_cancel_position$instance$276fd431a73a5d55
	mov	x0, x22
	mov	x1, x21
	mov	x2, x19
	bl	_wf_indexed_check$instance$276fd431a73a5d55
	mov	x0, x22
	mov	x1, x21
	mov	x2, x19
	mov	w3, #4                          ; =0x4
	bl	_wf_indexed_cancel_position$instance$276fd431a73a5d55
	mov	x0, x22
	mov	x1, x21
	mov	x2, x19
	bl	_wf_indexed_check$instance$276fd431a73a5d55
	mov	x0, x22
	mov	x1, x21
	mov	x2, x19
	mov	w3, #7                          ; =0x7
	bl	_wf_indexed_cancel_position$instance$276fd431a73a5d55
	mov	x0, x22
	mov	x1, x21
	mov	x2, x19
	bl	_wf_indexed_check$instance$276fd431a73a5d55
	ldr	w8, [sp, #284]                  ; 4-byte Folded Reload
	and	w2, w8, #0x1
	mov	x0, x25
	mov	w1, #72                         ; =0x48
	mov	w3, #1                          ; =0x1
	mov	x4, #0                          ; =0x0
	mov	x5, #0                          ; =0x0
	mov	x6, #0                          ; =0x0
	bl	_wf_record_store_new$instance$f8195bc386aec277
	mov	w0, #16                         ; =0x10
	bl	_malloc
	cbz	x0, LBB73_279
; %bb.16:                               ; %wf_indexed_wide.exit138
Lloh206:
	adrp	x8, lCPI73_3@PAGE
Lloh207:
	ldr	q0, [x8, lCPI73_3@PAGEOFF]
	str	q0, [x0]
	str	x0, [sp, #464]
Lloh208:
	adrp	x8, lCPI73_4@PAGE
Lloh209:
	ldr	q0, [x8, lCPI73_4@PAGEOFF]
	add	x8, sp, #217
	stur	q0, [x8, #255]
Lloh210:
	adrp	x8, lCPI73_5@PAGE
Lloh211:
	ldr	q1, [x8, lCPI73_5@PAGEOFF]
	stur	q1, [x24, #136]
Lloh212:
	adrp	x8, lCPI73_6@PAGE
Lloh213:
	ldr	q2, [x8, lCPI73_6@PAGEOFF]
	stur	q2, [x24, #152]
	mov	w8, #92                         ; =0x5c
	mov	w9, #901                        ; =0x385
	str	x8, [sp, #520]
	str	x9, [sp, #2656]
	strb	wzr, [x20, #9]
	ldr	x8, [sp, #6056]
	adrp	x26, lCPI73_11@PAGE
	ldr	x10, [sp, #6032]
	cmp	x8, x10
	b.hs	LBB73_20
; %bb.17:                               ; %bb2.i1189
	ldr	x9, [sp, #6048]
	mov	w10, #112                       ; =0x70
	madd	x10, x8, x10, x9
	ldr	x9, [x10]
	cbnz	x9, LBB73_43
; %bb.18:                               ; %bb5.i1192
	ldr	x9, [x10, #96]
	cmp	x9, #2
	b.hi	LBB73_43
; %bb.19:                               ; %bb8.i1193
	ldr	x11, [x10, #104]
	str	x0, [x10, #16]
	stur	q0, [x10, #24]
	stur	q1, [x10, #40]
	stur	q2, [x10, #56]
	mov	w12, #92                        ; =0x5c
	str	x12, [x10, #72]
	strb	wzr, [x10, #80]
	mov	w12, #8                         ; =0x8
	str	x12, [x10, #88]
Lloh214:
	adrp	x12, lCPI73_7@PAGE
Lloh215:
	ldr	q0, [x12, lCPI73_7@PAGEOFF]
	str	q0, [x10]
	str	x11, [sp, #6056]
	b	LBB73_22
LBB73_20:                               ; %bb3.i1185
	ldr	x9, [sp, #6040]
	cmp	x10, x9
	b.hs	LBB73_43
; %bb.21:                               ; %bb11.i1188
	mov	x9, #0                          ; =0x0
	ldr	x11, [sp, #6048]
Lloh216:
	adrp	x12, lCPI73_7@PAGE
Lloh217:
	ldr	q3, [x12, lCPI73_7@PAGEOFF]
	mov	w12, #112                       ; =0x70
	madd	x11, x10, x12, x11
	str	q3, [x11]
	str	x0, [x11, #16]
	stur	q0, [x11, #24]
	stur	q1, [x11, #40]
	stur	q2, [x11, #56]
	mov	w12, #92                        ; =0x5c
	str	x12, [x11, #72]
	strb	wzr, [x11, #80]
Lloh218:
	adrp	x12, lCPI73_8@PAGE
Lloh219:
	ldr	q0, [x12, lCPI73_8@PAGEOFF]
	stur	q0, [x11, #88]
	str	x8, [x11, #104]
	add	x8, x10, #1
	str	x8, [sp, #6032]
	mov	x8, x10
LBB73_22:                               ; %bb7
	ldr	x10, [sp, #6016]
	movi.2d	v0, #0000000000000000
	stur	xzr, [x24, #240]
	stp	q0, q0, [x24, #208]
	stp	q0, q0, [x24, #176]
	str	x10, [sp, #536]
	str	x8, [sp, #544]
	str	x9, [sp, #552]
	ldur	q0, [x24, #184]
	stur	q0, [x24, #248]
	str	x9, [x24, #264]
	add	x8, sp, #352
	ldr	q0, [sp, #544]
	str	q0, [x24, #272]
	ldr	x9, [sp, #624]
	ldr	x10, [sp, #3896]
	cmp	x9, x10
	b.eq	LBB73_24
; %bb.23:                               ; %bb10
	ldr	x9, [sp, #3840]
	add	x9, x9, #1
	str	x9, [sp, #3840]
LBB73_24:                               ; %bb9
	ldr	q0, [x8, #256]
	str	q0, [x24, #288]
	ldr	x8, [sp, #648]
	ldr	x9, [sp, #3904]
	cmp	x8, x9
	b.eq	LBB73_26
; %bb.25:                               ; %bb13
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_26:                               ; %bb12
	add	x1, x24, #248
	mov	x0, x22
	bl	_wf_record_store_attach$instance$f8195bc386aec277
	cmp	w0, #4
	b.eq	LBB73_28
; %bb.27:                               ; %bb13.i190
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_28:                               ; %wf_indexed_status.exit203
	add	x1, x24, #248
	mov	x0, x22
	bl	_wf_record_store_cancel$instance$f8195bc386aec277
	cmp	w0, #4
	b.eq	LBB73_30
; %bb.29:                               ; %bb13.i208
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_30:                               ; %wf_indexed_status.exit221
	add	x1, x24, #248
	mov	x0, x22
	mov	w2, #1                          ; =0x1
	bl	_wf_record_store_schedule$instance$f8195bc386aec277
	cmp	w0, #4
	b.eq	LBB73_32
; %bb.31:                               ; %bb13.i226
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_32:                               ; %wf_indexed_status.exit239
	add	x1, x24, #248
	mov	x0, x22
	mov	w2, #1                          ; =0x1
	bl	_wf_record_store_reschedule$instance$f8195bc386aec277
	cmp	w0, #4
	b.eq	LBB73_34
; %bb.33:                               ; %bb13.i244
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_34:                               ; %wf_indexed_status.exit257
	add	x2, x24, #248
	mov	x0, x22
	mov	w1, #10                         ; =0xa
	bl	_wf_record_store_detach$instance$f8195bc386aec277
	cmp	w0, #4
	b.eq	LBB73_36
; %bb.35:                               ; %bb13.i262
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_36:                               ; %wf_indexed_status.exit275
	ldr	x10, [sp, #600]
	ldr	x8, [sp, #608]
	ldr	x9, [sp, #616]
	ldr	x11, [sp, #5896]
	cmp	x10, x11
	b.ne	LBB73_44
; %bb.37:                               ; %bb3.i.i
	ldr	x11, [sp, #5912]
	cmp	x8, x11
	b.hs	LBB73_45
; %bb.38:                               ; %bb2.i.i.i
	ldr	x11, [sp, #5928]
	mov	w12, #112                       ; =0x70
	madd	x12, x8, x12, x11
	ldr	x13, [x12, #96]
	cmp	x13, x9
	b.ne	LBB73_45
; %bb.39:                               ; %bb5.i.i.i
	ldr	x13, [x12]
	cbz	x13, LBB73_45
; %bb.40:                               ; %bb2.i278
	ldrb	w14, [x12, #80]
	ldr	x15, [x12, #88]
	and	w14, w14, #0x1
	strb	w14, [x20, #1]
	ldrb	w16, [x23, #2032]
	cmp	x15, #8
	csinc	w14, w14, wzr, eq
	tbz	w16, #0, LBB73_271
; %bb.41:                               ; %bb2.i278
	tbz	w14, #0, LBB73_271
; %bb.42:
	mov	w11, #9                         ; =0x9
	b	LBB73_46
LBB73_43:                               ; %bb8
	mov	w8, #1                          ; =0x1
	str	x8, [sp, #528]
	str	x0, [sp, #536]
	stp	q0, q1, [sp, #544]
	str	q2, [sp, #576]
	mov	w8, #92                         ; =0x5c
	ldr	x9, [sp, #3840]
	add	x9, x9, #1
	str	x8, [sp, #592]
	ldur	q0, [x24, #184]
	ldur	q1, [x24, #200]
	stp	q0, q1, [x24, #512]
	ldur	q2, [x24, #216]
	ldur	q3, [x24, #232]
	stp	q2, q3, [x24, #544]
	str	x9, [sp, #3840]
	mov	w8, #901                        ; =0x385
	stur	q0, [x20, #17]
	stur	q1, [x20, #33]
	stur	q2, [x20, #49]
	stur	q3, [x20, #65]
	strb	wzr, [x20, #81]
	mov	w9, #8                          ; =0x8
	str	x8, [sp, #6384]
	str	x9, [sp, #6464]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2288
	mov	x0, x19
	bl	_wf_indexed_release$instance$68c9432c50ad41ad
	b	LBB73_60
LBB73_44:                               ; %bb17.thread1476
	add	x11, sp, #352
	add	x11, x11, #312
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x11, #48]
	stp	q0, q0, [x11, #16]
	str	q0, [x11]
	str	xzr, [sp, #744]
Lloh220:
	adrp	x11, lCPI73_9@PAGE
Lloh221:
	ldr	d0, [x11, lCPI73_9@PAGEOFF]
	str	d0, [sp, #656]
	b	LBB73_47
LBB73_45:                               ; %bb17
	mov	w11, #3                         ; =0x3
LBB73_46:                               ; %bb13.i296
	add	x12, sp, #352
	add	x12, x12, #312
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x12, #48]
	stp	q0, q0, [x12, #16]
	str	q0, [x12]
	mov	w12, #1                         ; =0x1
	str	w12, [sp, #656]
	str	w11, [sp, #660]
	ldr	x11, [sp, #3840]
	add	x11, x11, #1
	str	xzr, [sp, #744]
	str	x11, [sp, #3840]
LBB73_47:                               ; %bb15
	ldr	x11, [sp, #6016]
	cmp	x10, x11
	b.ne	LBB73_56
; %bb.48:                               ; %bb3.i.i287
	ldr	x10, [sp, #6032]
	cmp	x8, x10
	b.hs	LBB73_57
; %bb.49:                               ; %bb2.i.i.i.i
	ldr	x10, [sp, #6048]
	mov	w11, #112                       ; =0x70
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #96]
	cmp	x10, x9
	b.ne	LBB73_57
; %bb.50:                               ; %bb5.i.i.i.i
	ldr	x9, [x8]
	cbz	x9, LBB73_57
; %bb.51:                               ; %bb8.i.i.i.i
	ldp	x9, x10, [x8, #16]
	ldp	x11, x9, [x9]
	add	x12, x11, #101
	cmp	x9, x12
	csinv	x9, x11, xzr, eq
	add	x11, x9, #11
	cmp	x10, x11
	b.ne	LBB73_269
; %bb.52:                               ; %bb3.i.i.i.i.i.i
	dup.2d	v0, x9
Lloh222:
	adrp	x10, lCPI73_10@PAGE
Lloh223:
	ldr	q1, [x10, lCPI73_10@PAGEOFF]
	add.2d	v1, v0, v1
	ldr	q2, [x26, lCPI73_11@PAGEOFF]
	add.2d	v0, v0, v2
	ldp	q2, q3, [x8, #32]
	cmeq.2d	v0, v3, v0
	cmeq.2d	v1, v2, v1
	uzp1.4s	v0, v1, v0
	xtn.4h	v0, v0
	uminv.4h	h0, v0
	fmov	w10, s0
	tbz	w10, #0, LBB73_269
; %bb.53:                               ; %bb3.i.i.i.i.i.i
	add	x10, x9, #66
	ldr	x11, [x8, #64]
	cmp	x11, x10
	b.ne	LBB73_269
; %bb.54:                               ; %bb18.i.i.i.i.i.i
	add	x10, x9, #77
	ldr	x8, [x8, #72]
	cmp	x8, x10
	b.ne	LBB73_269
; %bb.55:                               ; %bb19
	str	wzr, [sp, #840]
	str	x9, [sp, #848]
	str	wzr, [sp, #856]
	cmp	x9, #15
	b.ne	LBB73_59
	b	LBB73_60
LBB73_56:
	mov	w8, #4                          ; =0x4
	b	LBB73_58
LBB73_57:
	mov	w8, #3                          ; =0x3
LBB73_58:                               ; %bb20
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #840]
	str	xzr, [sp, #848]
	str	w8, [sp, #856]
LBB73_59:                               ; %bb22
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_60:                               ; %bb6
	mov	w0, #16                         ; =0x10
	bl	_malloc
	cbz	x0, LBB73_279
; %bb.61:                               ; %wf_indexed_wide.exit156
Lloh224:
	adrp	x8, lCPI73_12@PAGE
Lloh225:
	ldr	q0, [x8, lCPI73_12@PAGEOFF]
	str	q0, [x0]
	str	x0, [sp, #928]
	mov	w8, #20                         ; =0x14
	str	x8, [sp, #936]
Lloh226:
	adrp	x8, lCPI73_13@PAGE
Lloh227:
	ldr	q0, [x8, lCPI73_13@PAGEOFF]
Lloh228:
	adrp	x8, lCPI73_14@PAGE
Lloh229:
	ldr	q1, [x8, lCPI73_14@PAGEOFF]
	stp	q0, q1, [sp, #944]
Lloh230:
	adrp	x8, lCPI73_15@PAGE
Lloh231:
	ldr	q0, [x8, lCPI73_15@PAGEOFF]
	str	q0, [sp, #976]
	mov	w8, #10                         ; =0xa
	str	x8, [sp, #2608]
	strb	wzr, [x20, #9]
	ldr	x8, [sp, #5936]
	ldr	x10, [sp, #5912]
	cmp	x8, x10
	b.hs	LBB73_65
; %bb.62:                               ; %bb2.i1261
	ldr	x9, [sp, #5928]
	mov	w10, #112                       ; =0x70
	madd	x10, x8, x10, x9
	ldr	x9, [x10]
	cbnz	x9, LBB73_68
; %bb.63:                               ; %bb5.i1281
	ldr	x9, [x10, #96]
	cmp	x9, #2
	b.hi	LBB73_68
; %bb.64:                               ; %bb8.i1285
	ldr	x11, [x10, #104]
	str	x0, [x10, #16]
Lloh232:
	adrp	x12, lCPI73_17@PAGE
Lloh233:
	ldr	q0, [x12, lCPI73_17@PAGEOFF]
	stur	q0, [x10, #24]
Lloh234:
	adrp	x12, lCPI73_18@PAGE
Lloh235:
	ldr	q0, [x12, lCPI73_18@PAGEOFF]
	stur	q0, [x10, #40]
Lloh236:
	adrp	x12, lCPI73_19@PAGE
Lloh237:
	ldr	q0, [x12, lCPI73_19@PAGEOFF]
	stur	q0, [x10, #56]
	mov	w12, #86                        ; =0x56
	str	x12, [x10, #72]
	strb	wzr, [x10, #80]
	mov	w12, #8                         ; =0x8
	str	x12, [x10, #88]
Lloh238:
	adrp	x12, lCPI73_16@PAGE
Lloh239:
	ldr	q0, [x12, lCPI73_16@PAGEOFF]
	str	q0, [x10]
	str	x11, [sp, #5936]
	b	LBB73_67
LBB73_65:                               ; %bb3.i1223
	ldr	x9, [sp, #5920]
	cmp	x10, x9
	b.hs	LBB73_68
; %bb.66:                               ; %bb11.i1240
	mov	x9, #0                          ; =0x0
	ldr	x11, [sp, #5928]
Lloh240:
	adrp	x12, lCPI73_16@PAGE
Lloh241:
	ldr	q0, [x12, lCPI73_16@PAGEOFF]
	mov	w12, #112                       ; =0x70
	madd	x11, x10, x12, x11
	str	q0, [x11]
	str	x0, [x11, #16]
Lloh242:
	adrp	x12, lCPI73_17@PAGE
Lloh243:
	ldr	q0, [x12, lCPI73_17@PAGEOFF]
	stur	q0, [x11, #24]
Lloh244:
	adrp	x12, lCPI73_18@PAGE
Lloh245:
	ldr	q0, [x12, lCPI73_18@PAGEOFF]
	stur	q0, [x11, #40]
Lloh246:
	adrp	x12, lCPI73_19@PAGE
Lloh247:
	ldr	q0, [x12, lCPI73_19@PAGEOFF]
	stur	q0, [x11, #56]
	mov	w12, #86                        ; =0x56
	str	x12, [x11, #72]
	strb	wzr, [x11, #80]
Lloh248:
	adrp	x12, lCPI73_8@PAGE
Lloh249:
	ldr	q0, [x12, lCPI73_8@PAGEOFF]
	stur	q0, [x11, #88]
	str	x8, [x11, #104]
	add	x8, x10, #1
	str	x8, [sp, #5912]
	mov	x8, x10
LBB73_67:                               ; %bb1.i167
	ldr	x10, [sp, #5896]
	movi.2d	v0, #0000000000000000
	ldr	x11, [sp, #88]                  ; 8-byte Folded Reload
	str	xzr, [x11, #64]
	stp	q0, q0, [x11, #32]
	stp	q0, q0, [x11]
	str	x10, [sp, #1000]
	str	x8, [sp, #1008]
	str	x9, [sp, #1016]
	ldr	w8, [sp, #284]                  ; 4-byte Folded Reload
	tbnz	w8, #0, LBB73_69
	b	LBB73_74
LBB73_68:                               ; %bb2.i165
	mov	w8, #1                          ; =0x1
	str	x8, [sp, #992]
	str	x0, [sp, #1000]
Lloh250:
	adrp	x8, lCPI73_17@PAGE
Lloh251:
	ldr	q0, [x8, lCPI73_17@PAGEOFF]
Lloh252:
	adrp	x8, lCPI73_18@PAGE
Lloh253:
	ldr	q1, [x8, lCPI73_18@PAGEOFF]
	stp	q0, q1, [sp, #1008]
Lloh254:
	adrp	x8, lCPI73_19@PAGE
Lloh255:
	ldr	q0, [x8, lCPI73_19@PAGEOFF]
	str	q0, [sp, #1040]
	mov	w8, #86                         ; =0x56
	str	x8, [sp, #1056]
	ldr	w8, [sp, #284]                  ; 4-byte Folded Reload
	tbz	w8, #0, LBB73_74
LBB73_69:                               ; %bb25
	mov	x0, x22
	mov	x1, x21
	mov	x2, x19
	mov	x3, #0                          ; =0x0
	mov	w4, #9                          ; =0x9
	bl	_wf_indexed_delete$instance$276fd431a73a5d55
	ldr	x1, [sp, #3856]
	ldr	q0, [x27]
	str	q0, [sp, #6384]
	ldr	x8, [x27, #16]
	str	x8, [sp, #6400]
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #2288
	mov	x0, x22
	bl	_wf_record_store_detach$instance$f8195bc386aec277
	cbz	w0, LBB73_71
; %bb.70:                               ; %bb13.i.i322
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_71:                               ; %"wf_indexed_detach$instance$e1380248266a9ad2.exit"
	strb	wzr, [x23]
	mov	x0, x22
	mov	x1, x21
	mov	x2, x19
	mov	x3, #0                          ; =0x0
	mov	w4, #9                          ; =0x9
	bl	_wf_indexed_delete$instance$276fd431a73a5d55
	ldr	q0, [x27]
	str	q0, [sp, #6384]
	ldr	x8, [x27, #16]
	str	x8, [sp, #6400]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2288
	mov	x0, x22
	bl	_wf_record_store_cancel$instance$f8195bc386aec277
	cbz	w0, LBB73_73
; %bb.72:                               ; %bb13.i.i333
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_73:                               ; %"wf_indexed_cancel$instance$e1380248266a9ad2.exit"
	strb	wzr, [x23, #1]
LBB73_74:                               ; %bb24
	mov	x0, x22
	mov	x1, x21
	mov	x2, x19
	mov	x3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	bl	_wf_indexed_delete$instance$276fd431a73a5d55
	ldr	w9, [sp, #992]
	add	x8, sp, #352
	add	x8, x8, #648
	cbz	w9, LBB73_82
; %bb.75:                               ; %bb29
	ldp	q0, q1, [x8]
	ldr	x9, [sp, #112]                  ; 8-byte Folded Reload
	stp	q0, q1, [x9]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x9, #32]
	ldr	x9, [sp, #6136]
	ldp	x10, x9, [x9]
	add	x11, x10, #101
	cmp	x9, x11
	csinv	x9, x10, xzr, eq
	add	x10, x9, #11
	ldr	x11, [sp, #6144]
	cmp	x11, x10
	b.ne	LBB73_80
; %bb.76:                               ; %bb3.i344
	dup.2d	v0, x9
Lloh256:
	adrp	x10, lCPI73_10@PAGE
Lloh257:
	ldr	q1, [x10, lCPI73_10@PAGEOFF]
	add.2d	v1, v0, v1
	ldr	q2, [x26, lCPI73_11@PAGEOFF]
	add.2d	v0, v0, v2
	add	x10, x28, #2280
	ldp	q2, q3, [x10]
	cmeq.2d	v0, v3, v0
	cmeq.2d	v1, v2, v1
	uzp1.4s	v0, v1, v0
	xtn.4h	v0, v0
	uminv.4h	h0, v0
	fmov	w10, s0
	tbz	w10, #0, LBB73_80
; %bb.77:                               ; %bb3.i344
	add	x10, x9, #66
	ldr	x11, [sp, #6184]
	cmp	x11, x10
	b.ne	LBB73_80
; %bb.78:                               ; %bb18.i
	cmp	x9, #9
	b.ne	LBB73_80
; %bb.79:                               ; %bb18.i
	add	x9, x9, #77
	ldr	x10, [sp, #6192]
	cmp	x10, x9
	b.eq	LBB73_81
LBB73_80:                               ; %bb31
	ldr	x9, [sp, #3840]
	add	x9, x9, #1
	str	x9, [sp, #3840]
LBB73_81:                               ; %bb30
	ldp	q0, q1, [x8]
	stp	q0, q1, [x24, #736]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x24, #768]
	add	x6, x24, #736
	mov	x0, x22
	mov	x1, x21
	mov	x2, x19
	mov	w3, #8                          ; =0x8
	mov	w4, #10                         ; =0xa
	mov	w5, #9                          ; =0x9
	bl	_wf_indexed_accept$instance$276fd431a73a5d55
	b	LBB73_83
LBB73_82:                               ; %bb28
	ldr	q0, [x8]
	ldr	x9, [sp, #96]                   ; 8-byte Folded Reload
	str	q0, [x9]
	ldr	x8, [x8, #16]
	str	x8, [x9, #16]
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_83:                               ; %bb27
	add	x8, sp, #352
	ldr	x9, [sp, #4408]
	ldr	x10, [sp, #3896]
	cmp	x9, x10
	b.eq	LBB73_85
; %bb.84:                               ; %bb34
	ldr	x9, [sp, #3840]
	add	x9, x9, #1
	str	x9, [sp, #3840]
LBB73_85:                               ; %bb33
	add	x26, x8, #4048
	ldr	x8, [sp, #4416]
	cmp	x8, #1
	b.eq	LBB73_87
; %bb.86:                               ; %bb37
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_87:                               ; %bb36
	ldr	x20, [sp, #4368]
	ldr	q0, [x26]
	str	q0, [sp, #6384]
	ldr	x8, [x26, #16]
	str	x8, [sp, #6400]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2288
	mov	x0, x22
	bl	_wf_record_store_attach$instance$f8195bc386aec277
	cbz	w0, LBB73_89
; %bb.88:                               ; %bb13.i.i359
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_89:                               ; %bb2.i364.preheader
	mov	w8, #32                         ; =0x20
	mov	x9, x23
	b	LBB73_91
LBB73_90:                               ; %bb8.i370
                                        ;   in Loop: Header=BB73_91 Depth=1
	add	x9, x9, #64
	subs	x8, x8, #1
	b.eq	LBB73_93
LBB73_91:                               ; %bb2.i364
                                        ; =>This Inner Loop Header: Depth=1
	ldur	x10, [x9, #-16]
	cmp	x10, x20
	b.ne	LBB73_90
; %bb.92:                               ; %bb6.i375
                                        ;   in Loop: Header=BB73_91 Depth=1
	strb	wzr, [x9]
	b	LBB73_90
LBB73_93:                               ; %"wf_indexed_attach$instance$e1380248266a9ad2.exit377"
	mov	w8, #1                          ; =0x1
	strb	w8, [x24, #4032]
	ldr	w8, [sp, #284]                  ; 4-byte Folded Reload
	tbnz	w8, #0, LBB73_96
; %bb.94:                               ; %bb41
	ldr	q0, [x26]
	ldr	x1, [sp, #104]                  ; 8-byte Folded Reload
	str	q0, [x1]
	ldr	x8, [x26, #16]
	str	x8, [x1, #16]
	mov	x0, x22
	mov	w2, #1000                       ; =0x3e8
	bl	_wf_record_store_schedule$instance$f8195bc386aec277
	cmp	w0, #6
	b.eq	LBB73_96
; %bb.95:                               ; %bb13.i397
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_96:                               ; %bb39
	add	x20, sp, #352
	ldr	q0, [sp, #3952]
	str	q0, [sp, #6384]
	ldr	x8, [sp, #3968]
	str	x8, [sp, #6400]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2288
	mov	x0, x22
	bl	_wf_record_store_cancel$instance$f8195bc386aec277
	cbz	w0, LBB73_98
; %bb.97:                               ; %bb13.i.i386
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_98:                               ; %"wf_indexed_cancel$instance$e1380248266a9ad2.exit392"
	add	x20, x20, #3600
	strb	wzr, [x23, #65]
	ldr	w8, [sp, #284]                  ; 4-byte Folded Reload
	tbz	w8, #0, LBB73_100
; %bb.99:                               ; %bb43
	mov	x0, x22
	mov	x1, x21
	mov	x2, x19
	mov	w3, #1                          ; =0x1
	mov	w4, #9                          ; =0x9
	bl	_wf_indexed_delete$instance$276fd431a73a5d55
LBB73_100:                              ; %bb42
	ldr	x1, [sp, #3920]
	ldr	q0, [x20]
	str	q0, [sp, #6384]
	ldr	x8, [x20, #16]
	str	x8, [sp, #6400]
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #2288
	mov	x0, x22
	bl	_wf_record_store_detach$instance$f8195bc386aec277
	cbz	w0, LBB73_102
; %bb.101:                              ; %bb13.i.i417
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_102:                              ; %"wf_indexed_detach$instance$e1380248266a9ad2.exit423"
	strb	wzr, [x23, #64]
	mov	w20, #1                         ; =0x1
	mov	x0, x22
	mov	x1, x21
	mov	x2, x19
	mov	w3, #1                          ; =0x1
	mov	x4, #0                          ; =0x0
	bl	_wf_indexed_delete$instance$276fd431a73a5d55
	ldr	q0, [x26]
	str	q0, [sp, #6384]
	ldr	x8, [x26, #16]
	str	x8, [sp, #6400]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2288
	mov	x0, x22
	mov	w2, #1000                       ; =0x3e8
	bl	_wf_record_store_schedule$instance$f8195bc386aec277
	cbz	w0, LBB73_104
; %bb.103:                              ; %bb13.i.i429
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_104:                              ; %"wf_indexed_schedule$instance$e1380248266a9ad2.exit436"
	strb	w20, [x24, #4033]
	mov	w8, #1000                       ; =0x3e8
	str	x8, [sp, #4392]
	ldr	q0, [x27]
	ldr	x1, [sp, #240]                  ; 8-byte Folded Reload
	str	q0, [x1]
	ldr	x8, [x27, #16]
	str	x8, [x1, #16]
	mov	x0, x22
	bl	_wf_record_store_cancel$instance$f8195bc386aec277
	cmp	w0, #3
	b.eq	LBB73_106
; %bb.105:                              ; %bb13.i441
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_106:                              ; %wf_indexed_status.exit454
	ldr	q0, [x27]
	ldr	x1, [sp, #248]                  ; 8-byte Folded Reload
	str	q0, [x1]
	ldr	x8, [x27, #16]
	str	x8, [x1, #16]
	mov	x0, x22
	mov	w2, #1                          ; =0x1
	bl	_wf_record_store_reschedule$instance$f8195bc386aec277
	cmp	w0, #3
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #2279
	b.eq	LBB73_108
; %bb.107:                              ; %bb13.i459
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_108:                              ; %wf_indexed_status.exit472
	ldr	q0, [x27]
	ldr	x2, [sp, #256]                  ; 8-byte Folded Reload
	str	q0, [x2]
	ldr	x8, [x27, #16]
	str	x8, [x2, #16]
	mov	x0, x22
	mov	w1, #10                         ; =0xa
	bl	_wf_record_store_detach$instance$f8195bc386aec277
	cmp	w0, #4
	b.hi	LBB73_110
; %bb.109:                              ; %bb13.i477
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_110:                              ; %wf_indexed_status.exit490
	mov	w0, #16                         ; =0x10
	bl	_malloc
	cbz	x0, LBB73_279
; %bb.111:                              ; %wf_indexed_wide.exit502
Lloh258:
	adrp	x8, lCPI73_20@PAGE
Lloh259:
	ldr	q0, [x8, lCPI73_20@PAGEOFF]
	str	q0, [x0]
	str	x0, [sp, #1248]
	mov	w8, #21                         ; =0x15
	str	x8, [sp, #1256]
Lloh260:
	adrp	x8, lCPI73_21@PAGE
Lloh261:
	ldr	q0, [x8, lCPI73_21@PAGEOFF]
Lloh262:
	adrp	x8, lCPI73_22@PAGE
Lloh263:
	ldr	q1, [x8, lCPI73_22@PAGEOFF]
	str	q0, [sp, #1264]
	str	q1, [sp, #1280]
Lloh264:
	adrp	x8, lCPI73_23@PAGE
Lloh265:
	ldr	q0, [x8, lCPI73_23@PAGEOFF]
	str	q0, [sp, #1296]
	add	x6, x24, #896
	mov	x0, x22
	mov	x1, x21
	mov	x2, x19
	mov	w3, #9                          ; =0x9
	mov	w4, #12                         ; =0xc
	mov	w5, #10                         ; =0xa
	bl	_wf_indexed_accept$instance$276fd431a73a5d55
	ldr	q0, [sp, #4464]
	ldr	x1, [sp, #232]                  ; 8-byte Folded Reload
	str	q0, [x1]
	ldr	x8, [sp, #4480]
	str	x8, [x1, #16]
	mov	x0, x22
	bl	_wf_record_store_attach$instance$f8195bc386aec277
	cmp	w0, #5
	b.eq	LBB73_113
; %bb.112:                              ; %bb13.i507
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_113:                              ; %wf_indexed_status.exit520
	mov	x0, x22
	mov	x1, x21
	mov	x2, x19
	mov	w3, #9                          ; =0x9
	mov	x4, #0                          ; =0x0
	bl	_wf_indexed_delete$instance$276fd431a73a5d55
	mov	w0, #16                         ; =0x10
	bl	_malloc
	cbz	x0, LBB73_279
; %bb.114:                              ; %wf_indexed_wide.exit532
Lloh266:
	adrp	x8, lCPI73_24@PAGE
Lloh267:
	ldr	q0, [x8, lCPI73_24@PAGEOFF]
	str	q0, [x0]
	str	x0, [sp, #1336]
Lloh268:
	adrp	x8, lCPI73_10@PAGE
Lloh269:
	ldr	q4, [x8, lCPI73_10@PAGEOFF]
Lloh270:
	adrp	x8, lCPI73_11@PAGE
Lloh271:
	ldr	q5, [x8, lCPI73_11@PAGEOFF]
	str	q4, [sp, #1344]
	str	q5, [sp, #1360]
Lloh272:
	adrp	x8, lCPI73_25@PAGE
Lloh273:
	ldr	q0, [x8, lCPI73_25@PAGEOFF]
	str	q0, [sp, #1376]
	mov	w8, #88                         ; =0x58
	str	x8, [sp, #1392]
	mov	w8, #12                         ; =0xc
	str	x8, [sp, #2624]
	ldr	x8, [sp, #6008]
	ldr	x15, [sp, #216]                 ; 8-byte Folded Reload
	cbz	x8, LBB73_116
; %bb.115:                              ; %bb3.i.i.i.i
	mov	w9, #12                         ; =0xc
	udiv	x10, x9, x8
	msub	x8, x10, x8, x9
LBB73_116:                              ; %wf_record_id_hash.exit.i.i.i
	ldr	x9, [sp, #5944]
	cbz	x9, LBB73_127
; %bb.117:                              ; %bb3.i.i.i
	udiv	x10, x8, x9
	msub	x10, x10, x9, x8
	ldr	x11, [sp, #5960]
	mov	w8, #2                          ; =0x2
	mov	x12, x9
	b	LBB73_119
LBB73_118:                              ; %bb8.i.i.i
                                        ;   in Loop: Header=BB73_119 Depth=1
	add	x13, x10, #1
	cmp	x13, x9
	csinc	x10, xzr, x10, hs
	subs	x12, x12, #1
	b.eq	LBB73_129
LBB73_119:                              ; %bb5.i.i.i537
                                        ; =>This Inner Loop Header: Depth=1
	add	x13, x11, x10, lsl #5
	ldr	w14, [x13]
	cmp	w14, #1
	b.eq	LBB73_118
; %bb.120:                              ; %bb5.i.i.i537
                                        ;   in Loop: Header=BB73_119 Depth=1
	cmp	w14, #2
	b.ne	LBB73_129
; %bb.121:                              ; %bb9.i.i.i
                                        ;   in Loop: Header=BB73_119 Depth=1
	ldr	x14, [x13, #8]
	cmp	x14, #12
	b.ne	LBB73_118
; %bb.122:                              ; %bb3.i120.i.i
	ldr	x8, [x13, #16]
	ldr	x9, [sp, #5912]
	cmp	x8, x9
	b.hs	LBB73_128
; %bb.123:                              ; %bb2.i.i.i.i543
	ldr	x9, [x13, #24]
	ldr	x10, [sp, #5928]
	mov	w11, #112                       ; =0x70
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #96]
	cmp	x10, x9
	b.ne	LBB73_128
; %bb.124:                              ; %bb5.i.i.i.i551
	ldr	x9, [x8]
	cbz	x9, LBB73_128
; %bb.125:                              ; %bb3.i.i554
	ldr	x9, [x8, #8]
	cmp	x9, #12
	b.ne	LBB73_274
; %bb.126:                              ; %bb1.i558
	ldr	q0, [x8, #16]
	str	q0, [sp, #6384]
	ldr	q0, [x8, #32]
	str	q0, [sp, #6400]
	ldr	q0, [x8, #48]
	str	q0, [sp, #6416]
	ldr	q0, [x8, #64]
	str	q0, [sp, #6432]
	ldr	x9, [sp, #208]                  ; 8-byte Folded Reload
	ldp	q0, q1, [x9, #32]
	ldp	q3, q2, [x9]
	stp	q0, q1, [x8, #48]
	stp	q3, q2, [x8, #16]
	str	xzr, [sp, #1400]
	ldr	q0, [sp, #6384]
	ldr	q1, [sp, #6400]
	str	q0, [sp, #1408]
	str	q1, [sp, #1424]
	ldr	q2, [sp, #6416]
	ldr	q3, [sp, #6432]
	str	q2, [sp, #1440]
	str	q3, [sp, #1456]
	stp	q0, q1, [x15]
	stp	q2, q3, [x15, #32]
	b	LBB73_130
LBB73_127:
	mov	w8, #2                          ; =0x2
	b	LBB73_129
LBB73_128:
	mov	w8, #3                          ; =0x3
LBB73_129:                              ; %bb13.i561
	ldr	x9, [sp, #208]                  ; 8-byte Folded Reload
	ldp	q1, q0, [x9]
	str	q1, [sp, #1408]
	ldp	q1, q2, [x9]
	str	q0, [sp, #1424]
	ldp	q3, q0, [x9, #32]
	str	q3, [sp, #1440]
	str	q0, [sp, #1456]
	str	x8, [sp, #1400]
	stp	q1, q2, [x15]
	ldp	q3, q0, [x9, #32]
	stp	q3, q0, [x15, #32]
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_130:                              ; %wf_indexed_status.exit574
	ldr	x8, [sp, #6200]
	ldp	x9, x8, [x8]
	add	x10, x9, #101
	cmp	x8, x10
	csinv	x8, x9, xzr, eq
	add	x9, x8, #11
	ldr	x10, [sp, #6208]
	cmp	x10, x9
	b.ne	LBB73_135
; %bb.131:                              ; %bb3.i588
	dup.2d	v0, x8
	add.2d	v1, v0, v4
	add.2d	v0, v0, v5
	add	x9, x28, #2344
	ldp	q2, q3, [x9]
	cmeq.2d	v0, v3, v0
	cmeq.2d	v1, v2, v1
	uzp1.4s	v0, v1, v0
	xtn.4h	v0, v0
	uminv.4h	h0, v0
	fmov	w9, s0
	tbz	w9, #0, LBB73_135
; %bb.132:                              ; %bb3.i588
	add	x9, x8, #66
	ldr	x10, [sp, #6248]
	cmp	x10, x9
	b.ne	LBB73_135
; %bb.133:                              ; %bb18.i613
	cmp	x8, #3
	b.ne	LBB73_135
; %bb.134:                              ; %bb18.i613
	add	x8, x8, #77
	ldr	x9, [sp, #6256]
	cmp	x9, x8
	b.eq	LBB73_136
LBB73_135:                              ; %bb46
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_136:                              ; %bb45
	stp	q5, q4, [sp, #288]              ; 32-byte Folded Spill
	ldp	q0, q1, [x15]
	ldr	x8, [sp, #224]                  ; 8-byte Folded Reload
	stp	q0, q1, [x8]
	ldp	q0, q3, [x15, #32]
	ldp	q2, q1, [x15]
	ldr	q4, [x15, #32]
	stp	q0, q3, [x8, #32]
	stur	q2, [x20, #17]
	stur	q1, [x20, #33]
	mov	w8, #12                         ; =0xc
	stur	q4, [x20, #49]
	ldr	q0, [x15, #48]
	stur	q0, [x20, #65]
	strb	wzr, [x20, #81]
	mov	w9, #8                          ; =0x8
	str	x8, [sp, #6384]
	str	x9, [sp, #6464]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2288
	mov	x0, x19
	bl	_wf_indexed_release$instance$68c9432c50ad41ad
	mov	w8, #11                         ; =0xb
	str	x8, [sp, #3992]
	mov	w0, #16                         ; =0x10
	bl	_malloc
	cbz	x0, LBB73_279
; %bb.137:                              ; %wf_indexed_wide.exit635
Lloh274:
	adrp	x8, lCPI73_26@PAGE
Lloh275:
	ldr	q0, [x8, lCPI73_26@PAGEOFF]
	str	q0, [x0]
	str	x0, [sp, #1536]
	mov	w8, #23                         ; =0x17
	str	x8, [sp, #1544]
	ldr	q0, [sp, #320]                  ; 16-byte Folded Reload
	str	q0, [sp, #1552]
Lloh276:
	adrp	x8, lCPI73_27@PAGE
Lloh277:
	ldr	q0, [x8, lCPI73_27@PAGEOFF]
	str	q0, [sp, #1568]
Lloh278:
	adrp	x8, lCPI73_28@PAGE
Lloh279:
	ldr	q0, [x8, lCPI73_28@PAGEOFF]
	str	q0, [sp, #1584]
	mov	w8, #999                        ; =0x3e7
	str	x8, [sp, #2632]
	ldr	x8, [sp, #6008]
	cbz	x8, LBB73_139
; %bb.138:                              ; %bb3.i.i.i.i641
	mov	w9, #999                        ; =0x3e7
	udiv	x10, x9, x8
	msub	x9, x10, x8, x9
	b	LBB73_140
LBB73_139:
	mov	x9, #0                          ; =0x0
LBB73_140:                              ; %wf_record_id_hash.exit.i.i.i643
	ldr	q5, [sp, #288]                  ; 16-byte Folded Reload
	ldr	x8, [sp, #5944]
	cbz	x8, LBB73_151
; %bb.141:                              ; %bb3.i.i.i647
	udiv	x10, x9, x8
	msub	x9, x10, x8, x9
	ldr	x10, [sp, #5960]
	mov	x11, x8
	b	LBB73_143
LBB73_142:                              ; %bb8.i.i.i656
                                        ;   in Loop: Header=BB73_143 Depth=1
	add	x12, x9, #1
	cmp	x12, x8
	csinc	x9, xzr, x9, hs
	subs	x11, x11, #1
	b.eq	LBB73_151
LBB73_143:                              ; %bb5.i.i.i651
                                        ; =>This Inner Loop Header: Depth=1
	add	x12, x10, x9, lsl #5
	ldr	w13, [x12]
	cmp	w13, #1
	b.eq	LBB73_142
; %bb.144:                              ; %bb5.i.i.i651
                                        ;   in Loop: Header=BB73_143 Depth=1
	cmp	w13, #2
	b.ne	LBB73_151
; %bb.145:                              ; %bb9.i.i.i665
                                        ;   in Loop: Header=BB73_143 Depth=1
	ldr	x13, [x12, #8]
	cmp	x13, #999
	b.ne	LBB73_142
; %bb.146:                              ; %bb3.i120.i.i669
	ldr	x8, [x12, #16]
	ldr	x9, [sp, #5912]
	cmp	x8, x9
	b.hs	LBB73_237
; %bb.147:                              ; %bb2.i.i.i.i677
	ldr	x9, [x12, #24]
	ldr	x10, [sp, #5928]
	mov	w11, #112                       ; =0x70
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #96]
	cmp	x10, x9
	b.ne	LBB73_237
; %bb.148:                              ; %bb5.i.i.i.i685
	ldr	x9, [x8]
	cbz	x9, LBB73_237
; %bb.149:                              ; %bb3.i.i688
	ldr	x9, [x8, #8]
	cmp	x9, #999
	ldr	q4, [sp, #304]                  ; 16-byte Folded Reload
	b.ne	LBB73_275
; %bb.150:                              ; %"wf_record_store_replace$instance$f8195bc386aec277.exit696.thread"
	ldr	q0, [x8, #16]
	str	q0, [sp, #6384]
	ldr	q0, [x8, #32]
	str	q0, [sp, #6400]
	ldr	q0, [x8, #48]
	str	q0, [sp, #6416]
	ldr	q0, [x8, #64]
	str	q0, [sp, #6432]
	ldr	x9, [sp, #192]                  ; 8-byte Folded Reload
	ldp	q0, q1, [x9, #32]
	ldp	q3, q2, [x9]
	stp	q0, q1, [x8, #48]
	stp	q3, q2, [x8, #16]
	add	x8, sp, #352
	add	x9, x8, #1256
	str	xzr, [sp, #1600]
	ldr	q0, [sp, #6384]
	ldr	q1, [sp, #6400]
	stp	q0, q1, [x9]
	ldr	q0, [sp, #6416]
	ldr	q1, [sp, #6432]
	stp	q0, q1, [x9, #32]
	b	LBB73_276
LBB73_151:                              ; %bb1.i698
	add	x8, sp, #352
	ldp	x9, x11, [sp, #192]             ; 16-byte Folded Reload
	ldp	q0, q1, [x9]
	add	x8, x8, #1256
	stp	q0, q1, [x8]
	ldp	q0, q3, [x9, #32]
	ldp	q2, q1, [x9]
	stp	q0, q3, [x8, #32]
	mov	w8, #2                          ; =0x2
	str	x8, [sp, #1600]
	stp	q2, q1, [x11]
	ldp	q4, q0, [x9, #32]
	stp	q4, q0, [x11, #32]
	ldr	q4, [sp, #304]                  ; 16-byte Folded Reload
LBB73_152:                              ; %wf_indexed_status.exit714
	ldr	x8, [sp, #6264]
	ldp	x9, x8, [x8]
	add	x10, x9, #101
	cmp	x8, x10
	csinv	x8, x9, xzr, eq
	add	x9, x8, #11
	ldr	x10, [sp, #6272]
	cmp	x10, x9
	b.ne	LBB73_157
; %bb.153:                              ; %bb3.i728
	dup.2d	v0, x8
	add.2d	v1, v0, v4
	add.2d	v0, v0, v5
	add	x9, x28, #2408
	ldp	q2, q3, [x9]
	cmeq.2d	v0, v3, v0
	cmeq.2d	v1, v2, v1
	uzp1.4s	v0, v1, v0
	xtn.4h	v0, v0
	uminv.4h	h0, v0
	fmov	w9, s0
	tbz	w9, #0, LBB73_157
; %bb.154:                              ; %bb3.i728
	add	x9, x8, #66
	ldr	x10, [sp, #6312]
	cmp	x10, x9
	b.ne	LBB73_157
; %bb.155:                              ; %bb18.i753
	cmp	x8, #12
	b.ne	LBB73_157
; %bb.156:                              ; %bb18.i753
	add	x8, x8, #77
	ldr	x9, [sp, #6320]
	cmp	x9, x8
	b.eq	LBB73_158
LBB73_157:                              ; %bb49
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_158:                              ; %bb48
	ldp	q0, q1, [x11]
	ldr	x8, [sp, #136]                  ; 8-byte Folded Reload
	stp	q0, q1, [x8]
	ldp	q0, q3, [x11, #32]
	ldp	q2, q1, [x11]
	ldr	q4, [x11, #32]
	stp	q0, q3, [x8, #32]
	stur	q2, [x20, #17]
	stur	q1, [x20, #33]
	mov	w8, #999                        ; =0x3e7
	stur	q4, [x20, #49]
	ldr	q0, [x11, #48]
	stur	q0, [x20, #65]
	strb	wzr, [x20, #81]
	mov	w9, #8                          ; =0x8
	str	x8, [sp, #6384]
	str	x9, [sp, #6464]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2288
	mov	x0, x19
	bl	_wf_indexed_release$instance$68c9432c50ad41ad
	add	x8, sp, #352
	add	x21, x8, #3664
	ldr	q0, [sp, #4016]
	ldr	x1, [sp, #144]                  ; 8-byte Folded Reload
	str	q0, [x1]
	ldr	x8, [sp, #4032]
	str	x8, [x1, #16]
	mov	x0, x22
	mov	w2, #1                          ; =0x1
	bl	_wf_record_store_reschedule$instance$f8195bc386aec277
	cbz	w0, LBB73_160
; %bb.159:                              ; %bb13.i771
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_160:                              ; %wf_indexed_status.exit784
	mov	w8, #1                          ; =0x1
	str	x8, [sp, #4008]
	ldr	x9, [x21, #16]
	ldr	x10, [sp, #152]                 ; 8-byte Folded Reload
	str	x9, [x10, #16]
	ldr	q0, [x21]
	str	q0, [x10]
	ldr	x9, [sp, #1760]
	ldr	x10, [sp, #5896]
	cmp	x9, x10
	b.ne	LBB73_166
; %bb.161:                              ; %bb3.i.i.i789
	ldr	x12, [sp, #1768]
	ldr	x9, [sp, #5912]
	cmp	x12, x9
	b.hs	LBB73_167
; %bb.162:                              ; %bb2.i.i.i.i793
	ldr	x13, [sp, #1776]
	ldr	x9, [sp, #5928]
	mov	w10, #112                       ; =0x70
	madd	x11, x12, x10, x9
	ldr	x9, [x11, #96]
	cmp	x9, x13
	b.ne	LBB73_167
; %bb.163:                              ; %bb5.i.i.i.i801
	ldr	x9, [x11]
	cbz	x9, LBB73_167
; %bb.164:                              ; %bb2.i.i
	ldr	x10, [x11, #88]
	cmp	x10, #8
	b.ne	LBB73_258
; %bb.165:
	mov	w9, #7                          ; =0x7
	b	LBB73_168
LBB73_166:
	mov	w9, #4                          ; =0x4
	b	LBB73_168
LBB73_167:
	mov	w9, #3                          ; =0x3
LBB73_168:                              ; %bb53
	ldr	x1, [sp, #160]                  ; 8-byte Folded Reload
LBB73_169:                              ; %bb53
	str	w8, [sp, #1784]
	str	xzr, [sp, #1792]
	str	w9, [sp, #1800]
LBB73_170:                              ; %bb51.sink.split
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_171:                              ; %bb51
	ldr	q0, [x21]
	str	q0, [x1]
	ldr	x8, [x21, #16]
	str	x8, [x1, #16]
	mov	x0, x22
	mov	w2, #2000                       ; =0x7d0
	bl	_wf_record_store_reschedule$instance$f8195bc386aec277
	cbz	w0, LBB73_173
; %bb.172:                              ; %bb13.i818
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_173:                              ; %wf_indexed_status.exit831
	mov	w8, #2000                       ; =0x7d0
	str	x8, [sp, #4008]
	ldr	x8, [x21, #16]
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	str	x8, [x9, #16]
	ldr	q0, [x21]
	str	q0, [x9]
	ldr	x8, [sp, #1832]
	ldr	x9, [sp, #5896]
	cmp	x8, x9
	b.ne	LBB73_179
; %bb.174:                              ; %bb3.i.i.i845
	ldr	x11, [sp, #1840]
	ldr	x8, [sp, #5912]
	cmp	x11, x8
	b.hs	LBB73_180
; %bb.175:                              ; %bb2.i.i.i.i849
	ldr	x12, [sp, #1848]
	ldr	x8, [sp, #5928]
	mov	w9, #112                        ; =0x70
	madd	x10, x11, x9, x8
	ldr	x8, [x10, #96]
	cmp	x8, x12
	b.ne	LBB73_180
; %bb.176:                              ; %bb5.i.i.i.i857
	ldr	x8, [x10]
	cbz	x8, LBB73_180
; %bb.177:                              ; %bb2.i.i860
	ldr	x9, [x10, #88]
	cmp	x9, #8
	b.ne	LBB73_263
; %bb.178:
	mov	w8, #7                          ; =0x7
	b	LBB73_181
LBB73_179:
	mov	w8, #4                          ; =0x4
	b	LBB73_181
LBB73_180:
	mov	w8, #3                          ; =0x3
LBB73_181:                              ; %bb59
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #1856]
	str	xzr, [sp, #1864]
	str	w8, [sp, #1872]
LBB73_182:                              ; %bb57.sink.split
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_183:                              ; %bb57
	mov	x0, x22
	ldr	x1, [sp, #344]                  ; 8-byte Folded Reload
	mov	x2, x19
	bl	_wf_indexed_check$instance$276fd431a73a5d55
	ldr	q0, [x21]
	ldr	x1, [sp, #176]                  ; 8-byte Folded Reload
	str	q0, [x1]
	ldr	x8, [x21, #16]
	str	x8, [x1, #16]
	mov	x0, x22
	mov	w2, #130                        ; =0x82
	bl	_wf_record_store_reschedule$instance$f8195bc386aec277
	cbz	w0, LBB73_185
; %bb.184:                              ; %bb13.i898
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_185:                              ; %wf_indexed_status.exit911
	mov	w8, #130                        ; =0x82
	str	x8, [sp, #4008]
	ldr	x1, [sp, #4368]
	ldr	q0, [x26]
	str	q0, [sp, #6384]
	ldr	x8, [x26, #16]
	str	x8, [sp, #6400]
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #2288
	mov	x0, x22
	bl	_wf_record_store_detach$instance$f8195bc386aec277
	cbz	w0, LBB73_187
; %bb.186:                              ; %bb13.i.i918
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_187:                              ; %"wf_indexed_detach$instance$e1380248266a9ad2.exit924"
	strb	wzr, [x24, #4032]
	ldr	x8, [x26, #16]
	ldr	x9, [sp, #184]                  ; 8-byte Folded Reload
	str	x8, [x9, #16]
	ldr	q0, [x26]
	str	q0, [x9]
	ldr	x8, [sp, #1904]
	ldr	x9, [sp, #5896]
	cmp	x8, x9
	ldr	x21, [sp, #344]                 ; 8-byte Folded Reload
	b.ne	LBB73_195
; %bb.188:                              ; %bb3.i926
	ldr	x10, [sp, #1912]
	ldr	x8, [sp, #5912]
	cmp	x10, x8
	b.hs	LBB73_196
; %bb.189:                              ; %bb2.i.i931
	ldr	x11, [sp, #1920]
	ldr	x9, [sp, #5928]
	mov	w12, #112                       ; =0x70
	madd	x10, x10, x12, x9
	ldr	x12, [x10, #96]
	cmp	x12, x11
	b.ne	LBB73_196
; %bb.190:                              ; %bb5.i.i933
	ldr	x11, [x10]
	cbz	x11, LBB73_196
; %bb.191:                              ; %bb64
	ldr	x11, [x10, #8]
	ldrb	w12, [x10, #80]
	ldr	x10, [x10, #88]
	and	w12, w12, #0x1
	strb	w12, [x20, #9]
	add	x13, sp, #352
	add	x13, x13, #1593
	str	xzr, [sp, #1928]
	str	x11, [sp, #1936]
	strb	w12, [sp, #1944]
	str	wzr, [x13]
	str	wzr, [sp, #1948]
	str	x10, [sp, #1952]
	ldr	q0, [sp, #1936]
	ldr	x11, [sp, #32]                  ; 8-byte Folded Reload
	str	q0, [x11]
	str	x10, [x11, #16]
	mov	w10, #99                        ; =0x63
	str	x10, [sp, #6352]
	ldp	x10, x20, [sp, #40]             ; 16-byte Folded Reload
	ldr	q0, [x20]
	str	q0, [x10]
	ldr	x10, [sp, #1960]
	cmp	x10, x8
	b.hs	LBB73_240
; %bb.192:                              ; %bb2.i.i1005
	ldr	x8, [sp, #1968]
	mov	w11, #112                       ; =0x70
	madd	x9, x10, x11, x9
	ldr	x10, [x9, #96]
	cmp	x10, x8
	b.ne	LBB73_240
; %bb.193:                              ; %bb5.i.i1015
	ldr	x8, [x9]
	cbz	x8, LBB73_240
; %bb.194:                              ; %bb8.i.i1018
	mov	w8, #0                          ; =0x0
	mov	w10, #99                        ; =0x63
	str	x10, [x9, #88]
	b	LBB73_241
LBB73_195:
	mov	w8, #4                          ; =0x4
	b	LBB73_197
LBB73_196:                              ; %bb5.i929
	mov	w8, #3                          ; =0x3
LBB73_197:                              ; %bb65
	str	xzr, [sp, #1952]
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #1936]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #1928]
	str	w8, [sp, #1932]
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_198:                              ; %bb63
	ldr	x20, [sp, #4368]
	ldr	q0, [x26]
	str	q0, [sp, #6384]
	ldr	x8, [x26, #16]
	str	x8, [sp, #6400]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2288
	mov	x0, x22
	bl	_wf_record_store_attach$instance$f8195bc386aec277
	cbz	w0, LBB73_200
; %bb.199:                              ; %bb13.i.i947
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_200:                              ; %bb2.i952.preheader
	mov	w8, #32                         ; =0x20
	mov	x9, x23
	b	LBB73_202
LBB73_201:                              ; %bb8.i958
                                        ;   in Loop: Header=BB73_202 Depth=1
	add	x9, x9, #64
	subs	x8, x8, #1
	b.eq	LBB73_204
LBB73_202:                              ; %bb2.i952
                                        ; =>This Inner Loop Header: Depth=1
	ldur	x10, [x9, #-16]
	cmp	x10, x20
	b.ne	LBB73_201
; %bb.203:                              ; %bb6.i963
                                        ;   in Loop: Header=BB73_202 Depth=1
	strb	wzr, [x9]
	b	LBB73_201
LBB73_204:                              ; %"wf_indexed_attach$instance$e1380248266a9ad2.exit965"
	mov	w8, #1                          ; =0x1
	strb	w8, [x24, #4032]
	mov	x0, x22
	mov	x1, x21
	mov	x2, x19
	bl	_wf_indexed_check$instance$276fd431a73a5d55
	mov	x0, x22
	mov	x1, x21
	mov	x2, x19
	mov	w3, #150                        ; =0x96
	bl	_wf_indexed_expire$instance$276fd431a73a5d55
	ldr	x8, [sp, #6008]
	cbz	x8, LBB73_206
; %bb.205:                              ; %bb3.i.i.i968
	mov	w9, #10                         ; =0xa
	udiv	x10, x9, x8
	msub	x9, x10, x8, x9
	ldr	x8, [sp, #5944]
	cbnz	x8, LBB73_207
	b	LBB73_219
LBB73_206:
	mov	x9, #0                          ; =0x0
	ldr	x8, [sp, #5944]
	cbz	x8, LBB73_219
LBB73_207:                              ; %bb3.i.i970
	udiv	x10, x9, x8
	msub	x9, x10, x8, x9
	ldr	x10, [sp, #5960]
	mov	x11, x8
	b	LBB73_209
LBB73_208:                              ; %bb8.i.i975
                                        ;   in Loop: Header=BB73_209 Depth=1
	add	x12, x9, #1
	cmp	x12, x8
	csinc	x9, xzr, x9, hs
	subs	x11, x11, #1
	b.eq	LBB73_219
LBB73_209:                              ; %bb5.i.i973
                                        ; =>This Inner Loop Header: Depth=1
	add	x12, x10, x9, lsl #5
	ldr	w13, [x12]
	cmp	w13, #1
	b.eq	LBB73_208
; %bb.210:                              ; %bb5.i.i973
                                        ;   in Loop: Header=BB73_209 Depth=1
	cmp	w13, #2
	b.ne	LBB73_219
; %bb.211:                              ; %bb9.i.i
                                        ;   in Loop: Header=BB73_209 Depth=1
	ldr	x13, [x12, #8]
	cmp	x13, #10
	b.ne	LBB73_208
; %bb.212:                              ; %bb3.i120.i
	ldr	x8, [x12, #16]
	ldr	x9, [sp, #5912]
	cmp	x8, x9
	b.hs	LBB73_239
; %bb.213:                              ; %bb2.i.i.i984
	ldr	x9, [x12, #24]
	ldr	x10, [sp, #5928]
	mov	w11, #112                       ; =0x70
	madd	x10, x8, x11, x10
	ldr	x11, [x10, #96]
	cmp	x11, x9
	b.ne	LBB73_239
; %bb.214:                              ; %bb5.i.i.i992
	ldr	x11, [x10]
	cbz	x11, LBB73_239
; %bb.215:                              ; %bb3.i995
	ldr	x10, [x10, #8]
	cmp	x10, #10
	b.ne	LBB73_277
; %bb.216:                              ; %bb70
	ldr	x10, [sp, #5896]
	add	x11, sp, #352
	add	x12, x11, #1736
	str	xzr, [sp, #2080]
	str	x10, [sp, #2088]
	str	x8, [sp, #2096]
	str	x9, [sp, #2104]
	ldr	x8, [sp, #8]                    ; 8-byte Folded Reload
	str	x9, [x8, #16]
	ldr	q0, [x12]
	str	q0, [x8]
	add	x8, x11, #1768
	ldr	q0, [sp, #2096]
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	str	q0, [x9]
	ldr	x9, [sp, #2136]
	ldr	x10, [sp, #4408]
	cmp	x9, x10
	b.eq	LBB73_218
; %bb.217:                              ; %bb73
	ldr	x9, [sp, #3840]
	add	x9, x9, #1
	str	x9, [sp, #3840]
LBB73_218:                              ; %bb72
	ldr	q0, [x8]
	ldr	x8, [sp, #24]                   ; 8-byte Folded Reload
	str	q0, [x8]
	ldr	x8, [sp, #2160]
	ldr	x9, [sp, #4416]
	cmp	x8, x9
	b.eq	LBB73_222
	b	LBB73_221
LBB73_219:
	mov	w8, #2                          ; =0x2
LBB73_220:                              ; %bb71
	add	x9, sp, #352
	add	x9, x9, #1736
	movi.2d	v0, #0000000000000000
	str	q0, [x9]
	str	xzr, [sp, #2104]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #2080]
	str	w8, [sp, #2084]
LBB73_221:                              ; %bb69.sink.split
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_222:                              ; %bb69
	mov	x0, x22
	mov	x1, x21
	mov	x2, x19
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	_wf_indexed_expire$instance$276fd431a73a5d55
	mov	x0, x22
	mov	x1, x21
	mov	x2, x19
	mov	x3, #-1                         ; =0xffffffffffffffff
	bl	_wf_indexed_expire$instance$276fd431a73a5d55
	mov	w0, #16                         ; =0x10
	bl	_malloc
	cbz	x0, LBB73_279
; %bb.223:                              ; %wf_indexed_wide.exit1119
Lloh280:
	adrp	x8, lCPI73_29@PAGE
Lloh281:
	ldr	q0, [x8, lCPI73_29@PAGEOFF]
	str	q0, [x0]
	str	x0, [sp, #2168]
Lloh282:
	adrp	x8, lCPI73_30@PAGE
Lloh283:
	ldr	q0, [x8, lCPI73_30@PAGEOFF]
	str	q0, [sp, #2176]
Lloh284:
	adrp	x8, lCPI73_31@PAGE
Lloh285:
	ldr	q0, [x8, lCPI73_31@PAGEOFF]
	str	q0, [sp, #2192]
Lloh286:
	adrp	x8, lCPI73_32@PAGE
Lloh287:
	ldr	q0, [x8, lCPI73_32@PAGEOFF]
	str	q0, [sp, #2208]
	mov	w8, #90                         ; =0x5a
	str	x8, [sp, #2224]
	add	x6, x24, #1816
	mov	x0, x22
	mov	x1, x21
	mov	x2, x19
	mov	w3, #10                         ; =0xa
	mov	w4, #313                        ; =0x139
	mov	w5, #13                         ; =0xd
	bl	_wf_indexed_accept$instance$276fd431a73a5d55
	ldr	x21, [sp, #4496]
	mov	w8, #4176                       ; =0x1050
	add	x9, sp, #352
	add	x20, x9, x8
	ldr	q0, [sp, #4528]
	str	q0, [sp, #6384]
	ldr	x8, [sp, #4544]
	str	x8, [sp, #6400]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2288
	mov	x0, x22
	bl	_wf_record_store_attach$instance$f8195bc386aec277
	cbz	w0, LBB73_225
; %bb.224:                              ; %bb13.i.i1126
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_225:                              ; %bb2.i1131.preheader
	mov	w8, #32                         ; =0x20
	b	LBB73_227
LBB73_226:                              ; %bb8.i1137
                                        ;   in Loop: Header=BB73_227 Depth=1
	add	x23, x23, #64
	subs	x8, x8, #1
	b.eq	LBB73_229
LBB73_227:                              ; %bb2.i1131
                                        ; =>This Inner Loop Header: Depth=1
	ldur	x9, [x23, #-16]
	cmp	x9, x21
	b.ne	LBB73_226
; %bb.228:                              ; %bb6.i1142
                                        ;   in Loop: Header=BB73_227 Depth=1
	strb	wzr, [x23]
	b	LBB73_226
LBB73_229:                              ; %"wf_indexed_attach$instance$e1380248266a9ad2.exit1144"
	mov	w21, #1                         ; =0x1
	strb	w21, [x28, #640]
	ldr	q0, [x20]
	str	q0, [sp, #6384]
	ldr	x8, [x20, #16]
	str	x8, [sp, #6400]
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2288
	mov	x0, x22
	mov	w2, #10                         ; =0xa
	bl	_wf_record_store_schedule$instance$f8195bc386aec277
	cbz	w0, LBB73_231
; %bb.230:                              ; %bb13.i.i1150
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_231:                              ; %"wf_indexed_schedule$instance$e1380248266a9ad2.exit1157"
	strb	w21, [x28, #641]
	mov	w8, #10                         ; =0xa
	str	x8, [sp, #4520]
	mov	w0, #16                         ; =0x10
	bl	_malloc
	cbz	x0, LBB73_279
; %bb.232:                              ; %wf_indexed_wide.exit1169
Lloh288:
	adrp	x8, lCPI73_33@PAGE
Lloh289:
	ldr	q0, [x8, lCPI73_33@PAGEOFF]
	str	q0, [x0]
	str	x0, [sp, #2232]
Lloh290:
	adrp	x8, lCPI73_34@PAGE
Lloh291:
	ldr	q0, [x8, lCPI73_34@PAGEOFF]
	str	q0, [sp, #2240]
Lloh292:
	adrp	x8, lCPI73_35@PAGE
Lloh293:
	ldr	q0, [x8, lCPI73_35@PAGEOFF]
	str	q0, [sp, #2256]
Lloh294:
	adrp	x8, lCPI73_36@PAGE
Lloh295:
	ldr	q0, [x8, lCPI73_36@PAGEOFF]
	str	q0, [sp, #2272]
	mov	w8, #91                         ; =0x5b
	str	x8, [sp, #2288]
	add	x6, x24, #1880
	mov	x0, x22
	ldr	x20, [sp, #344]                 ; 8-byte Folded Reload
	mov	x1, x20
	mov	x2, x19
	mov	w3, #11                         ; =0xb
	mov	w4, #314                        ; =0x13a
	mov	w5, #14                         ; =0xe
	bl	_wf_indexed_accept$instance$276fd431a73a5d55
	mov	x0, x22
	mov	x1, x20
	mov	x2, x19
	bl	_wf_indexed_check$instance$276fd431a73a5d55
	ldp	q0, q1, [x22, #64]
	ldr	x0, [sp, #120]                  ; 8-byte Folded Reload
	stp	q0, q1, [x0, #64]
	ldr	q0, [x22, #96]
	str	q0, [x0, #96]
	ldr	x8, [x22, #112]
	str	x8, [x0, #112]
	ldp	q0, q1, [x22]
	stp	q0, q1, [x0]
	ldp	q0, q1, [x22, #32]
	stp	q0, q1, [x0, #32]
	mov	x1, x19
	bl	_wf_record_store_free$instance$dbfa3e54f7dd514a
	ldp	q0, q1, [x25, #64]
	ldr	x0, [sp, #128]                  ; 8-byte Folded Reload
	stp	q0, q1, [x0, #64]
	ldr	q0, [x25, #96]
	str	q0, [x0, #96]
	ldr	x8, [x25, #112]
	str	x8, [x0, #112]
	ldp	q0, q1, [x25]
	stp	q0, q1, [x0]
	ldp	q0, q1, [x25, #32]
	stp	q0, q1, [x0, #32]
	mov	x1, x19
	bl	_wf_record_store_free$instance$dbfa3e54f7dd514a
	mov	w8, #64                         ; =0x40
	ldr	x0, [sp, #3840]
	b	LBB73_234
LBB73_233:                              ; %bb88
                                        ;   in Loop: Header=BB73_234 Depth=1
	add	x19, x19, #8
	subs	x8, x8, #1
	b.eq	LBB73_236
LBB73_234:                              ; %bb79
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x19]
	cmp	x9, #0
	cset	w9, ne
	ldr	x10, [x19, #512]
	cmp	x10, x9
	b.eq	LBB73_233
; %bb.235:                              ; %bb86
                                        ;   in Loop: Header=BB73_234 Depth=1
	add	x0, x0, #1
	str	x0, [sp, #3840]
	b	LBB73_233
LBB73_236:                              ; %bb81
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2384
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
LBB73_237:                              ; %bb5.i710
	mov	w8, #3                          ; =0x3
	str	x8, [sp, #1600]
	add	x8, sp, #352
	add	x8, x8, #1256
	ldp	x9, x11, [sp, #192]             ; 16-byte Folded Reload
	ldp	q0, q1, [x9]
	stp	q0, q1, [x8]
	ldp	q0, q1, [x9, #32]
	stp	q0, q1, [x8, #32]
	ldr	q4, [sp, #304]                  ; 16-byte Folded Reload
LBB73_238:                              ; %bb13.i701
	ldp	q0, q1, [x9]
	stp	q0, q1, [x11]
	ldp	q0, q1, [x9, #32]
	stp	q0, q1, [x11, #32]
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
	b	LBB73_152
LBB73_239:
	mov	w8, #3                          ; =0x3
	b	LBB73_220
LBB73_240:
	mov	w8, #1                          ; =0x1
LBB73_241:                              ; %"wf_std.collections.slab.slab_edit$instance$6a5da7aad053cce4.exit"
	str	w8, [sp, #1976]
	strh	wzr, [sp, #1980]
	ldr	q0, [x26]
	ldr	x1, [sp, #56]                   ; 8-byte Folded Reload
	str	q0, [x1]
	ldr	x8, [x26, #16]
	str	x8, [x1, #16]
	mov	x0, x22
	bl	_wf_record_store_cancel$instance$f8195bc386aec277
	cmp	w0, #7
	b.hi	LBB73_243
; %bb.242:                              ; %bb13.i1025
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_243:                              ; %wf_indexed_status.exit1038
	ldr	w8, [sp, #284]                  ; 4-byte Folded Reload
	tbz	w8, #0, LBB73_245
; %bb.244:                              ; %bb67
	mov	x0, x22
	mov	x1, x21
	mov	x2, x19
	mov	w3, #8                          ; =0x8
	mov	w4, #9                          ; =0x9
	bl	_wf_indexed_delete$instance$276fd431a73a5d55
LBB73_245:                              ; %bb66
	str	xzr, [sp, #6360]
	ldr	q0, [x20]
	ldr	x8, [sp, #64]                   ; 8-byte Folded Reload
	str	q0, [x8]
	ldr	x8, [sp, #2008]
	ldr	x9, [sp, #5912]
	cmp	x8, x9
	b.hs	LBB73_249
; %bb.246:                              ; %bb2.i.i1049
	ldr	x10, [sp, #2016]
	ldr	x9, [sp, #5928]
	mov	w11, #112                       ; =0x70
	madd	x9, x8, x11, x9
	ldr	x8, [x9, #96]
	cmp	x8, x10
	b.ne	LBB73_249
; %bb.247:                              ; %bb5.i.i1059
	ldr	x8, [x9]
	cbz	x8, LBB73_249
; %bb.248:                              ; %bb8.i.i1062
	mov	w8, #0                          ; =0x0
	str	xzr, [x9, #88]
	b	LBB73_250
LBB73_249:
	mov	w8, #1                          ; =0x1
LBB73_250:                              ; %"wf_std.collections.slab.slab_edit$instance$6a5da7aad053cce4.exit1065"
	str	w8, [sp, #2024]
	strh	wzr, [sp, #2028]
	ldr	q0, [x26]
	ldr	x1, [sp, #72]                   ; 8-byte Folded Reload
	str	q0, [x1]
	ldr	x8, [x26, #16]
	str	x8, [x1, #16]
	mov	x0, x22
	mov	w2, #1                          ; =0x1
	bl	_wf_record_store_reschedule$instance$f8195bc386aec277
	cmp	w0, #7
	b.hi	LBB73_252
; %bb.251:                              ; %bb13.i1070
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
LBB73_252:                              ; %wf_indexed_status.exit1083
	ldr	q0, [x20]
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	str	q0, [x8]
	ldr	x8, [sp, #2056]
	ldr	x9, [sp, #5912]
	cmp	x8, x9
	b.hs	LBB73_256
; %bb.253:                              ; %bb2.i.i1091
	ldr	x10, [sp, #2064]
	ldr	x9, [sp, #5928]
	mov	w11, #112                       ; =0x70
	madd	x9, x8, x11, x9
	ldr	x8, [x9, #96]
	cmp	x8, x10
	b.ne	LBB73_256
; %bb.254:                              ; %bb5.i.i1101
	ldr	x8, [x9]
	cbz	x8, LBB73_256
; %bb.255:                              ; %bb8.i.i1104
	mov	w8, #0                          ; =0x0
	ldr	x10, [sp, #6344]
	str	x10, [x9, #88]
	b	LBB73_257
LBB73_256:
	mov	w8, #1                          ; =0x1
LBB73_257:                              ; %"wf_std.collections.slab.slab_edit$instance$6a5da7aad053cce4.exit1107"
	str	w8, [sp, #2072]
	strh	wzr, [sp, #2076]
	b	LBB73_198
LBB73_258:                              ; %bb6.i.i
	ldr	x9, [sp, #5984]
	cmp	x10, x9
	b.hs	LBB73_270
; %bb.259:                              ; %bb8.i.i808
	ldr	x9, [sp, #6000]
	add	x14, x9, x10, lsl #5
	ldr	x15, [x14, #16]
	mov	w9, #8                          ; =0x8
	cmp	x15, x12
	b.ne	LBB73_168
; %bb.260:                              ; %bb8.i.i808
	ldr	x12, [x14, #24]
	cmp	x12, x13
	ldr	x1, [sp, #160]                  ; 8-byte Folded Reload
	b.ne	LBB73_169
; %bb.261:                              ; %bb11.i.i810
	ldr	x9, [x11, #8]
	ldr	x11, [x14, #8]
	cmp	x11, x9
	b.ne	LBB73_278
; %bb.262:                              ; %bb52
	str	wzr, [sp, #1784]
	str	x10, [sp, #1792]
	str	wzr, [sp, #1800]
	cbnz	x10, LBB73_170
	b	LBB73_171
LBB73_263:                              ; %bb6.i.i866
	ldr	x8, [sp, #5984]
	cmp	x9, x8
	b.hs	LBB73_268
; %bb.264:                              ; %bb8.i.i870
	ldr	x8, [sp, #6000]
	add	x13, x8, x9, lsl #5
	ldr	x14, [x13, #16]
	mov	w8, #8                          ; =0x8
	cmp	x14, x11
	b.ne	LBB73_181
; %bb.265:                              ; %bb8.i.i870
	ldr	x11, [x13, #24]
	cmp	x11, x12
	b.ne	LBB73_181
; %bb.266:                              ; %bb11.i.i882
	ldr	x8, [x10, #8]
	ldr	x10, [x13, #8]
	cmp	x10, x8
	b.ne	LBB73_268
; %bb.267:                              ; %bb58
	str	wzr, [sp, #1856]
	str	x9, [sp, #1864]
	str	wzr, [sp, #1872]
	cbnz	x9, LBB73_183
	b	LBB73_182
LBB73_268:
	mov	w8, #8                          ; =0x8
	b	LBB73_181
LBB73_269:                              ; %bb19.thread
	str	wzr, [sp, #840]
	mov	x8, #-1                         ; =0xffffffffffffffff
	str	x8, [sp, #848]
	str	wzr, [sp, #856]
	b	LBB73_59
LBB73_270:
	mov	w9, #8                          ; =0x8
	b	LBB73_168
LBB73_271:                              ; %bb8.i.i
	sub	x10, x13, #1
	str	x10, [x12]
	mov	w10, #88                        ; =0x58
	madd	x10, x13, x10, x12
	ldur	q0, [x10, #-48]
	str	q0, [sp, #6416]
	ldur	q0, [x10, #-32]
	str	q0, [sp, #6432]
	ldur	q0, [x10, #-16]
	str	q0, [sp, #6448]
	ldr	x12, [x10]
	str	x12, [sp, #6464]
	ldur	q0, [x10, #-80]
	str	q0, [sp, #6384]
	ldur	q0, [x10, #-64]
	str	q0, [sp, #6400]
	cmp	x9, #1
	b.hi	LBB73_273
; %bb.272:                              ; %bb11.i.i
	add	x9, x9, #1
	mov	w10, #112                       ; =0x70
	madd	x10, x8, x10, x11
	str	x9, [x10, #96]
	ldr	x9, [sp, #5936]
	str	x9, [x10, #104]
	str	x8, [sp, #5936]
LBB73_273:                              ; %bb16
	add	x8, sp, #352
	add	x8, x8, #312
	ldr	q0, [sp, #6416]
	ldr	q1, [sp, #6432]
	stp	q0, q1, [x8, #32]
	ldr	q2, [sp, #6448]
	str	q2, [x8, #64]
	ldr	q3, [sp, #6384]
	ldr	q4, [sp, #6400]
	stp	q3, q4, [x8]
	ldr	x8, [sp, #6464]
	str	xzr, [sp, #656]
	str	x8, [sp, #744]
	stp	q0, q1, [x24, #432]
	str	q2, [x24, #464]
	str	x8, [x24, #480]
	stp	q3, q4, [x24, #400]
	ldr	x8, [sp, #3840]
	add	x8, x8, #1
	str	x8, [sp, #3840]
	add	x1, x24, #400
	mov	x0, x19
	bl	_wf_indexed_release$instance$68c9432c50ad41ad
	ldr	x10, [sp, #600]
	ldr	x8, [sp, #608]
	ldr	x9, [sp, #616]
	b	LBB73_47
LBB73_274:
	mov	w8, #5                          ; =0x5
	b	LBB73_129
LBB73_275:                              ; %bb7.i708
	mov	w8, #5                          ; =0x5
	str	x8, [sp, #1600]
	add	x8, sp, #352
	add	x8, x8, #1256
	ldr	x9, [sp, #192]                  ; 8-byte Folded Reload
	ldp	q0, q1, [x9]
	stp	q0, q1, [x8]
	ldp	q0, q1, [x9, #32]
	stp	q0, q1, [x8, #32]
LBB73_276:                              ; %bb13.i701
	ldr	x11, [sp, #200]                 ; 8-byte Folded Reload
	b	LBB73_238
LBB73_277:
	mov	w8, #5                          ; =0x5
	b	LBB73_220
LBB73_278:
	mov	w9, #8                          ; =0x8
	b	LBB73_169
LBB73_279:                              ; %box.new.oom.v1.i.i.i
	bl	l_wf_resource_abort
	.loh AdrpLdr	Lloh204, Lloh205
	.loh AdrpAdrp	Lloh202, Lloh204
	.loh AdrpLdr	Lloh202, Lloh203
	.loh AdrpAdrp	Lloh200, Lloh202
	.loh AdrpLdr	Lloh200, Lloh201
	.loh AdrpLdr	Lloh212, Lloh213
	.loh AdrpAdrp	Lloh210, Lloh212
	.loh AdrpLdr	Lloh210, Lloh211
	.loh AdrpLdr	Lloh208, Lloh209
	.loh AdrpAdrp	Lloh206, Lloh208
	.loh AdrpLdr	Lloh206, Lloh207
	.loh AdrpLdr	Lloh214, Lloh215
	.loh AdrpLdr	Lloh218, Lloh219
	.loh AdrpLdr	Lloh216, Lloh217
	.loh AdrpLdr	Lloh220, Lloh221
	.loh AdrpLdr	Lloh222, Lloh223
	.loh AdrpLdr	Lloh230, Lloh231
	.loh AdrpAdrp	Lloh228, Lloh230
	.loh AdrpLdr	Lloh228, Lloh229
	.loh AdrpAdrp	Lloh226, Lloh228
	.loh AdrpLdr	Lloh226, Lloh227
	.loh AdrpLdr	Lloh224, Lloh225
	.loh AdrpLdr	Lloh238, Lloh239
	.loh AdrpLdr	Lloh236, Lloh237
	.loh AdrpAdrp	Lloh234, Lloh236
	.loh AdrpLdr	Lloh234, Lloh235
	.loh AdrpAdrp	Lloh232, Lloh234
	.loh AdrpLdr	Lloh232, Lloh233
	.loh AdrpLdr	Lloh248, Lloh249
	.loh AdrpLdr	Lloh246, Lloh247
	.loh AdrpAdrp	Lloh244, Lloh246
	.loh AdrpLdr	Lloh244, Lloh245
	.loh AdrpAdrp	Lloh242, Lloh244
	.loh AdrpLdr	Lloh242, Lloh243
	.loh AdrpLdr	Lloh240, Lloh241
	.loh AdrpLdr	Lloh254, Lloh255
	.loh AdrpAdrp	Lloh252, Lloh254
	.loh AdrpLdr	Lloh252, Lloh253
	.loh AdrpAdrp	Lloh250, Lloh252
	.loh AdrpLdr	Lloh250, Lloh251
	.loh AdrpLdr	Lloh256, Lloh257
	.loh AdrpLdr	Lloh264, Lloh265
	.loh AdrpAdrp	Lloh262, Lloh264
	.loh AdrpLdr	Lloh262, Lloh263
	.loh AdrpAdrp	Lloh260, Lloh262
	.loh AdrpLdr	Lloh260, Lloh261
	.loh AdrpLdr	Lloh258, Lloh259
	.loh AdrpLdr	Lloh272, Lloh273
	.loh AdrpAdrp	Lloh270, Lloh272
	.loh AdrpLdr	Lloh270, Lloh271
	.loh AdrpAdrp	Lloh268, Lloh270
	.loh AdrpLdr	Lloh268, Lloh269
	.loh AdrpAdrp	Lloh266, Lloh268
	.loh AdrpLdr	Lloh266, Lloh267
	.loh AdrpLdr	Lloh278, Lloh279
	.loh AdrpAdrp	Lloh276, Lloh278
	.loh AdrpLdr	Lloh276, Lloh277
	.loh AdrpLdr	Lloh274, Lloh275
	.loh AdrpLdr	Lloh286, Lloh287
	.loh AdrpAdrp	Lloh284, Lloh286
	.loh AdrpLdr	Lloh284, Lloh285
	.loh AdrpAdrp	Lloh282, Lloh284
	.loh AdrpLdr	Lloh282, Lloh283
	.loh AdrpAdrp	Lloh280, Lloh282
	.loh AdrpLdr	Lloh280, Lloh281
	.loh AdrpLdr	Lloh294, Lloh295
	.loh AdrpAdrp	Lloh292, Lloh294
	.loh AdrpLdr	Lloh292, Lloh293
	.loh AdrpAdrp	Lloh290, Lloh292
	.loh AdrpLdr	Lloh290, Lloh291
	.loh AdrpAdrp	Lloh288, Lloh290
	.loh AdrpLdr	Lloh288, Lloh289
	.loh AdrpLdrGot	Lloh198, Lloh199
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_new$instance$1a625a3e6534a882 ; -- Begin function wf_std.collections.slab.slab_new$instance$1a625a3e6534a882
	.p2align	2
_wf_std.collections.slab.slab_new$instance$1a625a3e6534a882: ; @"wf_std.collections.slab.slab_new$instance$1a625a3e6534a882"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	mov	x20, x0
	cbz	x1, LBB74_3
; %bb.1:                                ; %window.payload.allocate.v1.i.i
	lsl	x8, x19, #6
	sub	x0, x8, x19, lsl #3
	bl	_malloc
	cbnz	x0, LBB74_4
; %bb.2:                                ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
LBB74_3:
Lloh296:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh297:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB74_4:                                ; %"wf_box_slots_new$instance$98bdc07c73822b42.exit"
	stp	xzr, x19, [x20]
	stp	x0, x19, [x20, #16]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh296, Lloh297
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_new$instance$4348312e8937ab7e ; -- Begin function wf_std.collections.hash_map.hash_map_new$instance$4348312e8937ab7e
	.p2align	2
_wf_std.collections.hash_map.hash_map_new$instance$4348312e8937ab7e: ; @"wf_std.collections.hash_map.hash_map_new$instance$4348312e8937ab7e"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x1
	mov	x19, x0
	cbz	x1, LBB75_4
; %bb.1:                                ; %window.payload.allocate.v1.i.i
	lsl	x0, x20, #5
	bl	_malloc
	cbz	x0, LBB75_6
; %bb.2:                                ; %bb5.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #8
LBB75_3:                                ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x9, #8]
	str	xzr, [x9], #32
	cmp	x20, x8
	b.ne	LBB75_3
	b	LBB75_5
LBB75_4:
Lloh298:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh299:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB75_5:                                ; %"wf_std.collections.hash_map.hash_map_extend$instance$4348312e8937ab7e.exit"
	stp	x20, x20, [x19]
	stp	xzr, xzr, [x19, #24]
	str	x0, [x19, #16]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB75_6:                                ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.loh AdrpAdd	Lloh298, Lloh299
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_heapify$instance$97f85d10896f0873 ; -- Begin function wf_collections.priority_queue.priority_queue_heapify$instance$97f85d10896f0873
	.p2align	2
_wf_collections.priority_queue.priority_queue_heapify$instance$97f85d10896f0873: ; @"wf_collections.priority_queue.priority_queue_heapify$instance$97f85d10896f0873"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	ldr	q0, [x0]
	str	q0, [sp]
	ldr	x8, [x0, #16]
	str	x8, [sp, #16]
	ldr	x19, [sp]
	cmp	x19, #2
	b.lo	LBB76_3
; %bb.1:                                ; %bb2.i.preheader
	lsr	x8, x19, #1
	sub	x20, x8, #1
LBB76_2:                                ; %bb2.i
                                        ; =>This Inner Loop Header: Depth=1
	mov	x0, sp
	mov	x1, x20
	mov	x2, x19
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$6843c1d81191f67a
	sub	x20, x20, #1
	cmn	x20, #1
	b.ne	LBB76_2
LBB76_3:                                ; %"wf_collections.priority_queue.priority_queue_heapify$instance$97f85d10896f0873.body.exit"
	ldp	x1, x2, [sp, #8]
	mov	x0, x19
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_record_store_insert$instance$50c6da9371c13a22
lCPI77_0:
	.quad	2                               ; 0x2
	.quad	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_record_store_insert$instance$50c6da9371c13a22
	.p2align	2
_wf_record_store_insert$instance$50c6da9371c13a22: ; @"wf_record_store_insert$instance$50c6da9371c13a22"
; %bb.0:                                ; %entry
	sub	sp, sp, #16
	strb	wzr, [sp, #8]
	ldr	x8, [x1, #40]
	ldr	x10, [x1, #16]
	cmp	x8, x10
	b.hs	LBB77_4
; %bb.1:                                ; %bb2.i
	ldr	x9, [x1, #32]
	mov	w10, #56                        ; =0x38
	madd	x10, x8, x10, x9
	ldr	x9, [x10]
	cbnz	x9, LBB77_7
; %bb.2:                                ; %bb5.i
	ldr	x9, [x10, #40]
	cmp	x9, #1
	b.hi	LBB77_7
; %bb.3:                                ; %bb8.i
	ldr	x11, [x10, #48]
	stp	x2, x3, [x10, #8]
	strb	wzr, [x10, #24]
	mov	w12, #2                         ; =0x2
	str	x12, [x10, #32]
	mov	w12, #1                         ; =0x1
	str	x12, [x10]
	str	x11, [x1, #40]
	b	LBB77_6
LBB77_4:                                ; %bb3.i
	ldr	x9, [x1, #24]
	cmp	x10, x9
	b.hs	LBB77_7
; %bb.5:                                ; %bb11.i
	mov	x9, #0                          ; =0x0
	ldr	x11, [x1, #32]
	mov	w12, #56                        ; =0x38
	madd	x11, x10, x12, x11
	mov	w12, #1                         ; =0x1
	stp	x12, x2, [x11]
	str	x3, [x11, #16]
	strb	wzr, [x11, #24]
Lloh300:
	adrp	x12, lCPI77_0@PAGE
Lloh301:
	ldr	q0, [x12, lCPI77_0@PAGEOFF]
	str	q0, [x11, #32]
	str	x8, [x11, #48]
	add	x8, x10, #1
	str	x8, [x1, #16]
	mov	x8, x10
LBB77_6:                                ; %bb1
	ldr	x10, [x1]
	stp	xzr, x10, [x0]
	stp	x8, x9, [x0, #16]
	add	sp, sp, #16
	ret
LBB77_7:                                ; %bb2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	str	x3, [x0, #8]
	add	sp, sp, #16
	ret
	.loh AdrpLdr	Lloh300, Lloh301
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_lookup$instance$246819263d9877ed ; -- Begin function wf_std.collections.hash_map.hash_map_lookup$instance$246819263d9877ed
	.p2align	2
_wf_std.collections.hash_map.hash_map_lookup$instance$246819263d9877ed: ; @"wf_std.collections.hash_map.hash_map_lookup$instance$246819263d9877ed"
; %bb.0:                                ; %entry
	ldr	x8, [x3]
	cbz	x8, LBB78_2
; %bb.1:                                ; %bb3.i
	ldr	x9, [x2]
	udiv	x10, x9, x8
	msub	x9, x10, x8, x9
	ldr	x8, [x1]
	cbnz	x8, LBB78_3
	b	LBB78_9
LBB78_2:
	mov	x9, #0                          ; =0x0
	ldr	x8, [x1]
	cbz	x8, LBB78_9
LBB78_3:                                ; %bb3
	udiv	x10, x9, x8
	msub	x9, x10, x8, x9
	ldr	x10, [x1, #16]
	mov	x11, x8
	b	LBB78_5
LBB78_4:                                ; %bb8
                                        ;   in Loop: Header=BB78_5 Depth=1
	add	x12, x9, #1
	cmp	x12, x8
	csinc	x9, xzr, x9, hs
	subs	x11, x11, #1
	b.eq	LBB78_9
LBB78_5:                                ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	add	x12, x10, x9, lsl #5
	ldr	w13, [x12]
	cmp	w13, #1
	b.eq	LBB78_4
; %bb.6:                                ; %bb5
                                        ;   in Loop: Header=BB78_5 Depth=1
	cmp	w13, #2
	b.ne	LBB78_9
; %bb.7:                                ; %bb9
                                        ;   in Loop: Header=BB78_5 Depth=1
	ldr	x13, [x12, #8]
	ldr	x14, [x2]
	cmp	x13, x14
	b.ne	LBB78_4
; %bb.8:                                ; %bb13
	ldr	q0, [x12, #16]
	str	xzr, [x0]
	stur	q0, [x0, #8]
	ret
LBB78_9:                                ; %bb2
	stp	xzr, xzr, [x0]
	str	xzr, [x0, #16]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	ret
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_find_index$instance$1a625a3e6534a882 ; -- Begin function wf_std.collections.slab.slab_find_index$instance$1a625a3e6534a882
	.p2align	2
_wf_std.collections.slab.slab_find_index$instance$1a625a3e6534a882: ; @"wf_std.collections.slab.slab_find_index$instance$1a625a3e6534a882"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.hs	LBB79_3
; %bb.1:                                ; %bb2.i
	ldr	x10, [x1, #8]
	ldr	x9, [x0, #16]
	mov	w11, #56                        ; =0x38
	madd	x9, x8, x11, x9
	ldr	x11, [x9, #40]
	cmp	x11, x10
	b.ne	LBB79_3
; %bb.2:                                ; %bb5.i
	ldr	x9, [x9]
	cmp	x9, #0
	csel	x1, xzr, x8, eq
	cset	w0, eq
	mov	w2, #0                          ; =0x0
	ret
LBB79_3:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_put$instance$603c8258fd999e20 ; -- Begin function wf_std.collections.hash_map.hash_map_put$instance$603c8258fd999e20
	.p2align	2
_wf_std.collections.hash_map.hash_map_put$instance$603c8258fd999e20: ; @"wf_std.collections.hash_map.hash_map_put$instance$603c8258fd999e20"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	ldr	q0, [x3]
	str	q0, [sp]
	ldr	x8, [x1]
	ldp	x9, x10, [x1, #24]
	adds	x9, x9, x10
	csinv	x9, x9, xzr, lo
	sub	x10, x8, x8, lsr #2
	cmp	x8, #1
	ccmp	x9, x10, #0, ls
	b.lo	LBB80_2
; %bb.1:                                ; %bb6
	cmp	x8, #0
	mov	w8, #1                          ; =0x1
	cinc	x8, x8, ne
	mov	x19, x0
	mov	x0, x1
	mov	x20, x1
	mov	x1, x8
	mov	x21, x2
	mov	x2, x4
	mov	x22, x4
	bl	_wf_std.collections.hash_map.hash_map_rebuild$instance$603c8258fd999e20
	mov	x0, x19
	mov	x1, x20
	mov	x2, x21
	mov	x4, x22
LBB80_2:                                ; %bb1
	mov	x3, sp
	bl	_wf_std.collections.hash_map.hash_map_try_put$instance$603c8258fd999e20
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_edit$instance$a9e961aace3223d0 ; -- Begin function wf_std.collections.slab.slab_edit$instance$a9e961aace3223d0
	.p2align	2
_wf_std.collections.slab.slab_edit$instance$a9e961aace3223d0: ; @"wf_std.collections.slab.slab_edit$instance$a9e961aace3223d0"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.hs	LBB81_4
; %bb.1:                                ; %bb2.i
	ldr	x9, [x1, #8]
	ldr	x10, [x0, #16]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB81_4
; %bb.2:                                ; %bb5.i
	ldr	x9, [x8]
	cbz	x9, LBB81_4
; %bb.3:                                ; %bb8.i
	mov	w0, #0                          ; =0x0
	ldrb	w9, [x2]
	strb	w9, [x8, #24]
	b	LBB81_5
LBB81_4:
	mov	w0, #1                          ; =0x1
LBB81_5:                                ; %"wf_std.collections.slab.slab_edit$instance$a9e961aace3223d0.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_record_store_position$instance$50c6da9371c13a22 ; -- Begin function wf_record_store_position$instance$50c6da9371c13a22
	.p2align	2
_wf_record_store_position$instance$50c6da9371c13a22: ; @"wf_record_store_position$instance$50c6da9371c13a22"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.ne	LBB82_6
; %bb.1:                                ; %bb3.i.i
	ldr	x8, [x1, #8]
	ldr	x9, [x0, #16]
	cmp	x8, x9
	b.hs	LBB82_7
; %bb.2:                                ; %bb2.i.i.i
	ldr	x9, [x1, #16]
	ldr	x10, [x0, #32]
	mov	w11, #56                        ; =0x38
	madd	x10, x8, x11, x10
	ldr	x11, [x10, #40]
	cmp	x11, x9
	b.ne	LBB82_7
; %bb.3:                                ; %bb5.i.i.i
	ldr	x11, [x10]
	cbz	x11, LBB82_7
; %bb.4:                                ; %bb2.i
	ldr	x1, [x10, #32]
	cmp	x1, #2
	b.ne	LBB82_8
; %bb.5:
	mov	x1, #0                          ; =0x0
	mov	w2, #7                          ; =0x7
	mov	w0, #1                          ; =0x1
	ret
LBB82_6:
	mov	x1, #0                          ; =0x0
	mov	w2, #4                          ; =0x4
	mov	w0, #1                          ; =0x1
	ret
LBB82_7:
	mov	x1, #0                          ; =0x0
	mov	w2, #3                          ; =0x3
	mov	w0, #1                          ; =0x1
	ret
LBB82_8:                                ; %bb6.i
	ldr	x11, [x0, #88]
	cmp	x1, x11
	b.hs	LBB82_12
; %bb.9:                                ; %bb8.i
	ldr	x11, [x0, #104]
	add	x11, x11, x1, lsl #5
	ldp	x12, x13, [x11, #16]
	cmp	x12, x8
	ccmp	x13, x9, #0, eq
	b.ne	LBB82_12
; %bb.10:                               ; %bb11.i
	ldr	x8, [x10, #8]
	ldr	x9, [x11, #8]
	cmp	x9, x8
	b.ne	LBB82_12
; %bb.11:                               ; %bb14.i
	mov	w0, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ret
LBB82_12:
	mov	x1, #0                          ; =0x0
	mov	w2, #8                          ; =0x8
	mov	w0, #1                          ; =0x1
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_push_indexed$instance$2a15825f0f6e194e ; -- Begin function wf_collections.priority_queue.priority_queue_push_indexed$instance$2a15825f0f6e194e
	.p2align	2
_wf_collections.priority_queue.priority_queue_push_indexed$instance$2a15825f0f6e194e: ; @"wf_collections.priority_queue.priority_queue_push_indexed$instance$2a15825f0f6e194e"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #80
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 80
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	ldp	q0, q1, [x2]
	stp	q0, q1, [sp]
	ldr	x20, [x1]
	cmp	x20, #2
	b.lo	LBB83_2
; %bb.1:                                ; %bb2
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	ldp	q0, q1, [sp]
	stur	q0, [x19, #8]
	stur	q1, [x19, #24]
	b	LBB83_14
LBB83_2:                                ; %bb3
	ldr	x8, [x1, #8]
	cmp	x8, x20
	b.ne	LBB83_9
; %bb.3:                                ; %bb3.i
	mov	x21, x4
	tbz	w20, #0, LBB83_6
; %bb.4:                                ; %bb11.i
	mov	x22, x1
	ldr	x0, [x1, #16]
	mov	w1, #64                         ; =0x40
	bl	_realloc
	cbz	x0, LBB83_15
; %bb.5:                                ; %"wf_grow$instance$57d99a800120d980.exit.i33.i"
	mov	w8, #2                          ; =0x2
	b	LBB83_8
LBB83_6:                                ; %bb5.i
	mov	x22, x1
	mov	w0, #32                         ; =0x20
	bl	_malloc
	cbz	x0, LBB83_15
; %bb.7:                                ; %window.grow.copy.ready.v2.i.i.i
	mov	w8, #1                          ; =0x1
LBB83_8:                                ; %"wf_collections.priority_queue.priority_queue_make_room$instance$a762b7cb0800ff6e.exit"
	mov	x1, x22
	stp	x8, x0, [x22, #8]
	mov	x4, x21
LBB83_9:                                ; %"wf_collections.priority_queue.priority_queue_make_room$instance$a762b7cb0800ff6e.exit"
	add	x9, x20, #1
	ldr	x8, [x1, #16]
	add	x8, x8, x20, lsl #5
	ldp	q1, q0, [sp]
	stp	q1, q0, [x8]
	str	x9, [x1]
	ldr	x9, [x8, #16]
	ldr	x10, [x4]
	cmp	x9, x10
	b.hs	LBB83_13
; %bb.10:                               ; %bb2.i.i.i
	ldr	x10, [x8, #24]
	ldr	x8, [x4, #16]
	mov	w11, #56                        ; =0x38
	madd	x8, x9, x11, x8
	ldr	x9, [x8, #40]
	cmp	x9, x10
	b.ne	LBB83_13
; %bb.11:                               ; %bb5.i.i.i
	ldr	x9, [x8]
	cbz	x9, LBB83_13
; %bb.12:                               ; %bb8.i.i.i
	str	x20, [x8, #32]
LBB83_13:                               ; %"wf_record_report_position$instance$50c6da9371c13a22.exit"
	mov	x0, x1
	mov	x1, x20
	bl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$2a15825f0f6e194e
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	str	xzr, [x19, #32]
LBB83_14:                               ; %bb2
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB83_15:                               ; %window.block.oom.v2.i.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_remove$instance$1a625a3e6534a882 ; -- Begin function wf_std.collections.slab.slab_remove$instance$1a625a3e6534a882
	.p2align	2
_wf_std.collections.slab.slab_remove$instance$1a625a3e6534a882: ; @"wf_std.collections.slab.slab_remove$instance$1a625a3e6534a882"
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	ldr	x9, [x1]
	cmp	x8, x9
	b.hs	LBB84_6
; %bb.1:                                ; %bb2
	ldr	x10, [x2, #8]
	ldr	x9, [x1, #16]
	mov	w11, #56                        ; =0x38
	madd	x11, x8, x11, x9
	ldr	x12, [x11, #40]
	cmp	x12, x10
	b.ne	LBB84_6
; %bb.2:                                ; %bb5
	ldr	x12, [x11]
	cbz	x12, LBB84_6
; %bb.3:                                ; %bb8
	sub	x12, x12, #1
	add	x13, x11, x12, lsl #5
	str	x12, [x11]
	ldur	q0, [x13, #8]
	ldur	q1, [x13, #24]
	stp	q0, q1, [sp, #-32]!
	cbnz	x10, LBB84_5
; %bb.4:                                ; %bb11
	mov	w10, #56                        ; =0x38
	madd	x9, x8, x10, x9
	ldr	x10, [x1, #24]
	mov	w11, #1                         ; =0x1
	stp	x11, x10, [x9, #40]
	str	x8, [x1, #24]
LBB84_5:                                ; %bb10
	str	xzr, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	ldp	q0, q1, [sp]
	stur	q0, [x0, #8]
	stur	q1, [x0, #24]
	add	sp, sp, #32
	ret
LBB84_6:                                ; %bb1
	str	xzr, [x0, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_visit$instance$e9d3a462625627a1 ; -- Begin function wf_std.collections.slab.slab_visit$instance$e9d3a462625627a1
	.p2align	2
_wf_std.collections.slab.slab_visit$instance$e9d3a462625627a1: ; @"wf_std.collections.slab.slab_visit$instance$e9d3a462625627a1"
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	ldr	x9, [x1]
	cmp	x8, x9
	b.hs	LBB85_4
; %bb.1:                                ; %bb2
	ldr	x9, [x2, #8]
	ldr	x10, [x1, #16]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB85_4
; %bb.2:                                ; %bb5
	ldr	x9, [x8]
	cbz	x9, LBB85_4
; %bb.3:                                ; %bb8
	sub	sp, sp, #16
	ldr	x9, [x8, #8]
	ldrb	w10, [x8, #24]
	ldr	x8, [x8, #32]
	and	w10, w10, #0x1
	strb	w10, [sp, #8]
	stp	x9, xzr, [x0, #8]
	str	xzr, [x0]
	strb	w10, [x0, #16]
	str	x8, [x0, #24]
	add	sp, sp, #16
	ret
LBB85_4:                                ; %bb1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_remove$instance$603c8258fd999e20 ; -- Begin function wf_std.collections.hash_map.hash_map_remove$instance$603c8258fd999e20
	.p2align	2
_wf_std.collections.hash_map.hash_map_remove$instance$603c8258fd999e20: ; @"wf_std.collections.hash_map.hash_map_remove$instance$603c8258fd999e20"
; %bb.0:                                ; %entry
	ldr	x8, [x1, #24]
	cbz	x8, LBB86_10
; %bb.1:                                ; %bb3
	ldr	x9, [x3]
	cbz	x9, LBB86_3
; %bb.2:                                ; %bb3.i.i.i
	ldr	x10, [x2]
	udiv	x11, x10, x9
	msub	x10, x11, x9, x10
	ldr	x9, [x1]
	cbnz	x9, LBB86_4
	b	LBB86_10
LBB86_3:
	mov	x10, #0                         ; =0x0
	ldr	x9, [x1]
	cbz	x9, LBB86_10
LBB86_4:                                ; %bb3.i.i
	udiv	x11, x10, x9
	msub	x10, x11, x9, x10
	ldr	x11, [x1, #16]
	mov	x12, x9
	b	LBB86_6
LBB86_5:                                ; %bb8.i.i
                                        ;   in Loop: Header=BB86_6 Depth=1
	add	x13, x10, #1
	cmp	x13, x9
	csinc	x10, xzr, x10, hs
	subs	x12, x12, #1
	b.eq	LBB86_10
LBB86_6:                                ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x13, x11, x10, lsl #5
	ldr	w14, [x13]
	cmp	w14, #1
	b.eq	LBB86_5
; %bb.7:                                ; %bb5.i.i
                                        ;   in Loop: Header=BB86_6 Depth=1
	cmp	w14, #2
	b.ne	LBB86_10
; %bb.8:                                ; %bb3.i3.i.i
                                        ;   in Loop: Header=BB86_6 Depth=1
	ldr	x14, [x13, #8]
	ldr	x15, [x2]
	cmp	x14, x15
	b.ne	LBB86_5
; %bb.9:                                ; %bb6
	mov	w9, #1                          ; =0x1
	str	w9, [x13]
	sub	x8, x8, #1
	ldr	q0, [x13, #16]
	stp	xzr, xzr, [x13, #16]
	str	xzr, [x13, #8]
	ldr	x10, [x1, #32]
	adds	x10, x10, #1
	csinv	x10, x10, xzr, lo
	stp	x8, x10, [x1, #24]
	stp	xzr, x14, [x0]
	str	w9, [x0]
	str	q0, [x0, #16]
	ret
LBB86_10:                               ; %bb2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_len$instance$a762b7cb0800ff6e ; -- Begin function wf_collections.priority_queue.priority_queue_len$instance$a762b7cb0800ff6e
	.p2align	2
_wf_collections.priority_queue.priority_queue_len$instance$a762b7cb0800ff6e: ; @"wf_collections.priority_queue.priority_queue_len$instance$a762b7cb0800ff6e"
; %bb.0:                                ; %entry
	ldr	x0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_peek$instance$e2f1cca2354fe4d1 ; -- Begin function wf_collections.priority_queue.priority_queue_peek$instance$e2f1cca2354fe4d1
	.p2align	2
_wf_collections.priority_queue.priority_queue_peek$instance$e2f1cca2354fe4d1: ; @"wf_collections.priority_queue.priority_queue_peek$instance$e2f1cca2354fe4d1"
; %bb.0:                                ; %entry
	ldr	x8, [x1, #16]
	ldp	q1, q0, [x8]
	stp	q1, q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$2a15825f0f6e194e ; -- Begin function wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$2a15825f0f6e194e
	.p2align	2
_wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$2a15825f0f6e194e: ; @"wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$2a15825f0f6e194e"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	mov	x19, x0
	ldr	x8, [x1]
	sub	x8, x8, #1
	ldr	x10, [x1, #16]
	add	x11, x10, x8, lsl #5
	str	x8, [x1]
	ldp	q0, q1, [x11]
	stp	q0, q1, [sp]
	cmp	x2, x8
	b.hs	LBB89_10
; %bb.1:                                ; %bb2
	add	x9, x10, x2, lsl #5
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp]
	ldp	q0, q1, [x11]
	stp	q0, q1, [x9]
	ldr	x11, [x9, #16]
	ldr	x12, [x4]
	cmp	x11, x12
	b.hs	LBB89_5
; %bb.2:                                ; %bb2.i.i.i
	ldr	x12, [x9, #24]
	ldr	x13, [x4, #16]
	mov	w14, #56                        ; =0x38
	madd	x11, x11, x14, x13
	ldr	x13, [x11, #40]
	cmp	x13, x12
	b.ne	LBB89_5
; %bb.3:                                ; %bb5.i.i.i
	ldr	x12, [x11]
	cbz	x12, LBB89_5
; %bb.4:                                ; %bb8.i.i.i
	str	x2, [x11, #32]
LBB89_5:                                ; %"wf_record_report_position$instance$50c6da9371c13a22.exit"
	cbz	x2, LBB89_7
; %bb.6:                                ; %bb2.i
	lsl	x11, x2, #4
	sub	x11, x11, #16
	and	x11, x11, #0xffffffffffffffe0
	add	x10, x10, x11
	ldr	x11, [x10]
	ldr	x12, [x9]
	cmp	x11, x12
	b.hs	LBB89_8
LBB89_7:                                ; %bb1.i
	mov	x0, x1
	mov	x1, x2
	mov	x2, x8
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$2a15825f0f6e194e
	b	LBB89_10
LBB89_8:                                ; %bb3.i.i
	b.ls	LBB89_11
LBB89_9:                                ; %bb5.i
	mov	x0, x1
	mov	x1, x2
	bl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$2a15825f0f6e194e
LBB89_10:                               ; %bb1
	ldp	q0, q1, [sp]
	stp	q0, q1, [x19]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB89_11:                               ; %bb6.i.i
	ldr	x11, [x10, #8]
	ldr	x12, [x9, #8]
	cmp	x11, x12
	b.lo	LBB89_7
; %bb.12:                               ; %bb9.i.i
	b.hi	LBB89_9
; %bb.13:                               ; %bb12.i.i
	ldr	x11, [x10, #16]
	ldr	x12, [x9, #16]
	cmp	x11, x12
	b.lo	LBB89_7
; %bb.14:                               ; %bb15.i.i
	b.hi	LBB89_9
; %bb.15:                               ; %bb18.i.i
	ldr	x10, [x10, #24]
	ldr	x9, [x9, #24]
	cmp	x10, x9
	b.ls	LBB89_7
	b	LBB89_9
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_edit$instance$79794de0ddcdada2 ; -- Begin function wf_std.collections.slab.slab_edit$instance$79794de0ddcdada2
	.p2align	2
_wf_std.collections.slab.slab_edit$instance$79794de0ddcdada2: ; @"wf_std.collections.slab.slab_edit$instance$79794de0ddcdada2"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.hs	LBB90_4
; %bb.1:                                ; %bb2.i
	ldr	x9, [x1, #8]
	ldr	x10, [x0, #16]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB90_4
; %bb.2:                                ; %bb5.i
	ldr	x9, [x8]
	cbz	x9, LBB90_4
; %bb.3:                                ; %bb8.i
	mov	w0, #0                          ; =0x0
	ldr	x9, [x2]
	str	x9, [x8, #32]
	b	LBB90_5
LBB90_4:
	mov	w0, #1                          ; =0x1
LBB90_5:                                ; %"wf_std.collections.slab.slab_edit$instance$79794de0ddcdada2.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_free$instance$d405037d8db33b6d ; -- Begin function wf_std.collections.hash_map.hash_map_free$instance$d405037d8db33b6d
	.p2align	2
_wf_std.collections.hash_map.hash_map_free$instance$d405037d8db33b6d: ; @"wf_std.collections.hash_map.hash_map_free$instance$d405037d8db33b6d"
; %bb.0:                                ; %entry
	ldr	x8, [x0, #8]
	cbz	x8, LBB91_2
; %bb.1:                                ; %slots.release.drop.6.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #16]
	bl	_free
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB91_2:                                ; %"wf_free_empty$instance$16f094be4fd843b6.exit"
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_free$instance$272f87483c69b364 ; -- Begin function wf_collections.priority_queue.priority_queue_free$instance$272f87483c69b364
	.p2align	2
_wf_collections.priority_queue.priority_queue_free$instance$272f87483c69b364: ; @"wf_collections.priority_queue.priority_queue_free$instance$272f87483c69b364"
; %bb.0:                                ; %entry
	ldr	x8, [x0, #8]
	cbz	x8, LBB92_2
; %bb.1:                                ; %slots.release.drop.6.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #16]
	bl	_free
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB92_2:                                ; %"wf_free_empty$instance$401ab120abe5d512.exit"
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_free$instance$9c203cb0f3c40552 ; -- Begin function wf_std.collections.slab.slab_free$instance$9c203cb0f3c40552
	.p2align	2
_wf_std.collections.slab.slab_free$instance$9c203cb0f3c40552: ; @"wf_std.collections.slab.slab_free$instance$9c203cb0f3c40552"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	ldp	x10, x8, [x0]
	ldr	x0, [x0, #16]
	cbz	x10, LBB93_8
; %bb.1:                                ; %bb5.lr.ph
	ldr	q0, [x1]
	ands	x11, x10, #0x7
	b.eq	LBB93_6
; %bb.2:                                ; %bb5.prol.preheader
	mov	w9, #56                         ; =0x38
	madd	x9, x10, x9, x0
	sub	x12, x9, #56
	mov	x13, sp
	mov	w9, #1                          ; =0x1
	dup.2d	v1, x9
	mov	x9, x10
	b	LBB93_4
LBB93_3:                                ; %bb6.prol
                                        ;   in Loop: Header=BB93_4 Depth=1
	sub	x12, x12, #56
	sub	x9, x9, #1
	sub	x11, x11, #1
	cbz	x11, LBB93_7
LBB93_4:                                ; %bb5.prol
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q2, q3, [x12]
	stp	q2, q3, [sp]
	ldr	x14, [x12, #32]
	str	x14, [sp, #32]
	ldr	x14, [sp]
	cbz	x14, LBB93_3
; %bb.5:                                ; %bb7.prol
                                        ;   in Loop: Header=BB93_4 Depth=1
	sub	x14, x14, #1
	str	x14, [sp]
	add	x14, x13, x14, lsl #5
	add	x14, x14, #16
	mov.16b	v2, v1
	ld1.d	{ v2 }[1], [x14]
	add.2d	v0, v0, v2
	str	q0, [x1]
	b	LBB93_3
LBB93_6:
	mov	x9, x10
LBB93_7:                                ; %bb5.prol.loopexit
	cmp	x10, #8
	b.hs	LBB93_11
LBB93_8:                                ; %bb4
	cbz	x8, LBB93_10
; %bb.9:                                ; %slots.release.drop.6.i
	bl	_free
LBB93_10:                               ; %"wf_free_empty$instance$e22bd0c72870f88b.exit"
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB93_11:                               ; %bb5.lr.ph.new
	mov	w10, #56                        ; =0x38
	madd	x10, x9, x10, x0
	sub	x10, x10, #224
	mov	x11, sp
	mov	w12, #1                         ; =0x1
	dup.2d	v1, x12
	b	LBB93_13
LBB93_12:                               ; %bb6.7
                                        ;   in Loop: Header=BB93_13 Depth=1
	sub	x10, x10, #448
	sub	x9, x9, #8
	cbz	x9, LBB93_8
LBB93_13:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	ldur	q2, [x10, #168]
	ldur	q3, [x10, #184]
	stp	q2, q3, [sp]
	ldr	x13, [x10, #200]
	str	x13, [sp, #32]
	ldr	x13, [sp]
	cbz	x13, LBB93_15
; %bb.14:                               ; %bb7
                                        ;   in Loop: Header=BB93_13 Depth=1
	sub	x13, x13, #1
	str	x13, [sp]
	add	x13, x11, x13, lsl #5
	add	x13, x13, #16
	dup.2d	v2, x12
	ld1.d	{ v2 }[1], [x13]
	add.2d	v0, v0, v2
	str	q0, [x1]
LBB93_15:                               ; %bb6
                                        ;   in Loop: Header=BB93_13 Depth=1
	ldp	q2, q3, [x10, #112]
	stp	q2, q3, [sp]
	ldr	x13, [x10, #144]
	str	x13, [sp, #32]
	ldr	x13, [sp]
	cbz	x13, LBB93_17
; %bb.16:                               ; %bb7.1
                                        ;   in Loop: Header=BB93_13 Depth=1
	sub	x13, x13, #1
	str	x13, [sp]
	add	x13, x11, x13, lsl #5
	add	x13, x13, #16
	dup.2d	v2, x12
	ld1.d	{ v2 }[1], [x13]
	add.2d	v0, v0, v2
	str	q0, [x1]
LBB93_17:                               ; %bb6.1
                                        ;   in Loop: Header=BB93_13 Depth=1
	ldur	q2, [x10, #56]
	ldur	q3, [x10, #72]
	stp	q2, q3, [sp]
	ldr	x13, [x10, #88]
	str	x13, [sp, #32]
	ldr	x13, [sp]
	cbz	x13, LBB93_19
; %bb.18:                               ; %bb7.2
                                        ;   in Loop: Header=BB93_13 Depth=1
	sub	x13, x13, #1
	str	x13, [sp]
	add	x13, x11, x13, lsl #5
	add	x13, x13, #16
	dup.2d	v2, x12
	ld1.d	{ v2 }[1], [x13]
	add.2d	v0, v0, v2
	str	q0, [x1]
LBB93_19:                               ; %bb6.2
                                        ;   in Loop: Header=BB93_13 Depth=1
	ldp	q2, q3, [x10]
	stp	q2, q3, [sp]
	ldr	x13, [x10, #32]
	str	x13, [sp, #32]
	ldr	x13, [sp]
	cbz	x13, LBB93_21
; %bb.20:                               ; %bb7.3
                                        ;   in Loop: Header=BB93_13 Depth=1
	sub	x13, x13, #1
	str	x13, [sp]
	add	x13, x11, x13, lsl #5
	add	x13, x13, #16
	dup.2d	v2, x12
	ld1.d	{ v2 }[1], [x13]
	add.2d	v0, v0, v2
	str	q0, [x1]
LBB93_21:                               ; %bb6.3
                                        ;   in Loop: Header=BB93_13 Depth=1
	ldur	q2, [x10, #-56]
	ldur	q3, [x10, #-40]
	stp	q2, q3, [sp]
	ldur	x13, [x10, #-24]
	str	x13, [sp, #32]
	ldr	x13, [sp]
	cbz	x13, LBB93_23
; %bb.22:                               ; %bb7.4
                                        ;   in Loop: Header=BB93_13 Depth=1
	sub	x13, x13, #1
	str	x13, [sp]
	add	x13, x11, x13, lsl #5
	add	x13, x13, #16
	dup.2d	v2, x12
	ld1.d	{ v2 }[1], [x13]
	add.2d	v0, v0, v2
	str	q0, [x1]
LBB93_23:                               ; %bb6.4
                                        ;   in Loop: Header=BB93_13 Depth=1
	ldp	q2, q3, [x10, #-112]
	stp	q2, q3, [sp]
	ldur	x13, [x10, #-80]
	str	x13, [sp, #32]
	ldr	x13, [sp]
	cbz	x13, LBB93_25
; %bb.24:                               ; %bb7.5
                                        ;   in Loop: Header=BB93_13 Depth=1
	sub	x13, x13, #1
	str	x13, [sp]
	add	x13, x11, x13, lsl #5
	add	x13, x13, #16
	dup.2d	v2, x12
	ld1.d	{ v2 }[1], [x13]
	add.2d	v0, v0, v2
	str	q0, [x1]
LBB93_25:                               ; %bb6.5
                                        ;   in Loop: Header=BB93_13 Depth=1
	ldur	q2, [x10, #-168]
	ldur	q3, [x10, #-152]
	stp	q2, q3, [sp]
	ldur	x13, [x10, #-136]
	str	x13, [sp, #32]
	ldr	x13, [sp]
	cbz	x13, LBB93_27
; %bb.26:                               ; %bb7.6
                                        ;   in Loop: Header=BB93_13 Depth=1
	sub	x13, x13, #1
	str	x13, [sp]
	add	x13, x11, x13, lsl #5
	add	x13, x13, #16
	dup.2d	v2, x12
	ld1.d	{ v2 }[1], [x13]
	add.2d	v0, v0, v2
	str	q0, [x1]
LBB93_27:                               ; %bb6.6
                                        ;   in Loop: Header=BB93_13 Depth=1
	ldp	q2, q3, [x10, #-224]
	stp	q2, q3, [sp]
	ldur	x13, [x10, #-192]
	str	x13, [sp, #32]
	ldr	x13, [sp]
	cbz	x13, LBB93_12
; %bb.28:                               ; %bb7.7
                                        ;   in Loop: Header=BB93_13 Depth=1
	sub	x13, x13, #1
	str	x13, [sp]
	add	x13, x11, x13, lsl #5
	add	x13, x13, #16
	mov.16b	v2, v1
	ld1.d	{ v2 }[1], [x13]
	add.2d	v0, v0, v2
	str	q0, [x1]
	b	LBB93_12
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_new$instance$85bcb7bfdda43087 ; -- Begin function wf_std.collections.slab.slab_new$instance$85bcb7bfdda43087
	.p2align	2
_wf_std.collections.slab.slab_new$instance$85bcb7bfdda43087: ; @"wf_std.collections.slab.slab_new$instance$85bcb7bfdda43087"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	mov	x20, x0
	cbz	x1, LBB94_3
; %bb.1:                                ; %window.payload.allocate.v1.i.i
	lsl	x8, x19, #6
	sub	x0, x8, x19, lsl #3
	bl	_malloc
	cbnz	x0, LBB94_4
; %bb.2:                                ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
LBB94_3:
Lloh302:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh303:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB94_4:                                ; %"wf_box_slots_new$instance$98bdc07c73822b42.exit"
	stp	xzr, x19, [x20]
	stp	x0, x19, [x20, #16]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh302, Lloh303
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_new$instance$bd5728c249450a41 ; -- Begin function wf_std.collections.hash_map.hash_map_new$instance$bd5728c249450a41
	.p2align	2
_wf_std.collections.hash_map.hash_map_new$instance$bd5728c249450a41: ; @"wf_std.collections.hash_map.hash_map_new$instance$bd5728c249450a41"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x1
	mov	x19, x0
	cbz	x1, LBB95_4
; %bb.1:                                ; %window.payload.allocate.v1.i.i
	lsl	x0, x20, #5
	bl	_malloc
	cbz	x0, LBB95_6
; %bb.2:                                ; %bb5.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #8
LBB95_3:                                ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x9, #8]
	str	xzr, [x9], #32
	cmp	x20, x8
	b.ne	LBB95_3
	b	LBB95_5
LBB95_4:
Lloh304:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh305:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB95_5:                                ; %"wf_std.collections.hash_map.hash_map_extend$instance$bd5728c249450a41.exit"
	stp	x20, x20, [x19]
	stp	xzr, xzr, [x19, #24]
	str	x0, [x19, #16]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB95_6:                                ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.loh AdrpAdd	Lloh304, Lloh305
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_heapify$instance$b1f8c2aa150dd109 ; -- Begin function wf_collections.priority_queue.priority_queue_heapify$instance$b1f8c2aa150dd109
	.p2align	2
_wf_collections.priority_queue.priority_queue_heapify$instance$b1f8c2aa150dd109: ; @"wf_collections.priority_queue.priority_queue_heapify$instance$b1f8c2aa150dd109"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	ldr	q0, [x0]
	str	q0, [sp]
	ldr	x8, [x0, #16]
	str	x8, [sp, #16]
	ldr	x19, [sp]
	cmp	x19, #2
	b.lo	LBB96_3
; %bb.1:                                ; %bb2.i.preheader
	lsr	x8, x19, #1
	sub	x20, x8, #1
LBB96_2:                                ; %bb2.i
                                        ; =>This Inner Loop Header: Depth=1
	mov	x0, sp
	mov	x1, x20
	mov	x2, x19
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$45e23263d9dc5d6a
	sub	x20, x20, #1
	cmn	x20, #1
	b.ne	LBB96_2
LBB96_3:                                ; %"wf_collections.priority_queue.priority_queue_heapify$instance$b1f8c2aa150dd109.body.exit"
	ldp	x1, x2, [sp, #8]
	mov	x0, x19
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function wf_record_store_info$instance$5ffcb0796f3480f6
lCPI97_0:
	.long	1                               ; 0x1
	.long	4                               ; 0x4
lCPI97_1:
	.long	1                               ; 0x1
	.long	3                               ; 0x3
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_record_store_info$instance$5ffcb0796f3480f6
	.p2align	2
_wf_record_store_info$instance$5ffcb0796f3480f6: ; @"wf_record_store_info$instance$5ffcb0796f3480f6"
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	ldr	x9, [x1]
	cmp	x8, x9
	b.ne	LBB97_5
; %bb.1:                                ; %bb3
	ldr	x8, [x2, #8]
	ldr	x9, [x1, #16]
	cmp	x8, x9
	b.hs	LBB97_6
; %bb.2:                                ; %bb2.i
	ldr	x9, [x2, #16]
	ldr	x10, [x1, #32]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB97_6
; %bb.3:                                ; %bb5.i
	ldr	x9, [x8]
	cbz	x9, LBB97_6
; %bb.4:                                ; %bb4
	sub	sp, sp, #16
	ldr	x9, [x8, #8]
	ldrb	w10, [x8, #24]
	ldr	x8, [x8, #32]
	and	w10, w10, #0x1
	strb	w10, [sp, #8]
	stp	xzr, x9, [x0]
	strb	w10, [x0, #16]
	stur	wzr, [x0, #17]
	str	wzr, [x0, #20]
	str	x8, [x0, #24]
	add	sp, sp, #16
	ret
LBB97_5:                                ; %bb2
	movi.2d	v0, #0000000000000000
	str	xzr, [x0, #24]
	mov.d	v0[1], v0[0]
	stur	q0, [x0, #8]
Lloh306:
	adrp	x8, lCPI97_0@PAGE
Lloh307:
	ldr	d0, [x8, lCPI97_0@PAGEOFF]
	str	d0, [x0]
	ret
LBB97_6:                                ; %bb5
	movi.2d	v0, #0000000000000000
	str	xzr, [x0, #24]
	mov.d	v0[1], v0[0]
	stur	q0, [x0, #8]
Lloh308:
	adrp	x8, lCPI97_1@PAGE
Lloh309:
	ldr	d0, [x8, lCPI97_1@PAGEOFF]
	str	d0, [x0]
	ret
	.loh AdrpLdr	Lloh306, Lloh307
	.loh AdrpLdr	Lloh308, Lloh309
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_remove$instance$85bcb7bfdda43087 ; -- Begin function wf_std.collections.slab.slab_remove$instance$85bcb7bfdda43087
	.p2align	2
_wf_std.collections.slab.slab_remove$instance$85bcb7bfdda43087: ; @"wf_std.collections.slab.slab_remove$instance$85bcb7bfdda43087"
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	ldr	x9, [x1]
	cmp	x8, x9
	b.hs	LBB98_6
; %bb.1:                                ; %bb2
	ldr	x10, [x2, #8]
	ldr	x9, [x1, #16]
	mov	w11, #56                        ; =0x38
	madd	x11, x8, x11, x9
	ldr	x12, [x11, #40]
	cmp	x12, x10
	b.ne	LBB98_6
; %bb.2:                                ; %bb5
	ldr	x12, [x11]
	cbz	x12, LBB98_6
; %bb.3:                                ; %bb8
	sub	x12, x12, #1
	add	x13, x11, x12, lsl #5
	str	x12, [x11]
	ldur	q0, [x13, #8]
	ldur	q1, [x13, #24]
	stp	q0, q1, [sp, #-32]!
	cbnz	x10, LBB98_5
; %bb.4:                                ; %bb11
	mov	w10, #56                        ; =0x38
	madd	x9, x8, x10, x9
	ldr	x10, [x1, #24]
	mov	w11, #1                         ; =0x1
	stp	x11, x10, [x9, #40]
	str	x8, [x1, #24]
LBB98_5:                                ; %bb10
	str	xzr, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	ldp	q0, q1, [sp]
	stur	q0, [x0, #8]
	stur	q1, [x0, #24]
	add	sp, sp, #32
	ret
LBB98_6:                                ; %bb1
	str	xzr, [x0, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_insert$instance$85bcb7bfdda43087 ; -- Begin function wf_std.collections.slab.slab_insert$instance$85bcb7bfdda43087
	.p2align	2
_wf_std.collections.slab.slab_insert$instance$85bcb7bfdda43087: ; @"wf_std.collections.slab.slab_insert$instance$85bcb7bfdda43087"
; %bb.0:                                ; %entry
	sub	sp, sp, #16
	ldp	x9, x12, [x2]
	ldrb	w10, [x2, #16]
	ldr	w11, [x2, #20]
	mov	x14, x2
	ldr	w13, [x14, #17]!
	ldr	x8, [x2, #24]
	str	w13, [sp, #8]
	stur	w11, [sp, #11]
	ldr	x11, [x1, #24]
	ldr	x13, [x1]
	cmp	x11, x13
	b.hs	LBB99_4
; %bb.1:                                ; %bb2
	ldr	x13, [x1, #16]
	mov	w14, #56                        ; =0x38
	madd	x14, x11, x14, x13
	ldr	x13, [x14]
	cbnz	x13, LBB99_6
; %bb.2:                                ; %bb5
	ldr	x13, [x14, #40]
	cmp	x13, #1
	b.hi	LBB99_6
; %bb.3:                                ; %bb8
	ldr	x15, [x14, #48]
	stp	x9, x12, [x14, #8]
	strb	w10, [x14, #24]
	ldr	w10, [sp, #8]
	stur	w10, [x14, #25]
	ldur	w10, [sp, #11]
	str	w10, [x14, #28]
	str	x8, [x14, #32]
	mov	w8, #1                          ; =0x1
	str	x8, [x14]
	str	x15, [x1, #24]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	str	xzr, [x0, #32]
	stp	x11, x13, [x0, #8]
	add	sp, sp, #16
	ret
LBB99_4:                                ; %bb3
	ldr	x15, [x1, #8]
	cmp	x13, x15
	b.hs	LBB99_6
; %bb.5:                                ; %bb11
	ldur	w15, [x14, #3]
	stur	w15, [sp, #3]
	ldr	w14, [x14]
	str	w14, [sp]
	ldr	x14, [x1, #16]
	mov	w15, #56                        ; =0x38
	madd	x14, x13, x15, x14
	mov	w15, #1                         ; =0x1
	stp	x15, x9, [x14]
	str	x12, [x14, #16]
	strb	w10, [x14, #24]
	ldr	w9, [sp]
	stur	w9, [x14, #25]
	ldur	w9, [sp, #3]
	str	w9, [x14, #28]
	stp	x8, xzr, [x14, #32]
	str	x11, [x14, #48]
	add	x8, x13, #1
	str	x8, [x1]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	str	xzr, [x0, #32]
	str	x13, [x0, #8]
	add	sp, sp, #16
	ret
LBB99_6:                                ; %bb4
	stp	xzr, x9, [x0]
	mov	w11, #1                         ; =0x1
	str	w11, [x0]
	str	x12, [x0, #16]
	strb	w10, [x0, #24]
	ldr	w9, [sp, #8]
	stur	w9, [x0, #25]
	ldur	w9, [sp, #11]
	str	w9, [x0, #28]
	str	x8, [x0, #32]
	add	sp, sp, #16
	ret
                                        ; -- End function
	.globl	_wf_record_store_position$instance$5ffcb0796f3480f6 ; -- Begin function wf_record_store_position$instance$5ffcb0796f3480f6
	.p2align	2
_wf_record_store_position$instance$5ffcb0796f3480f6: ; @"wf_record_store_position$instance$5ffcb0796f3480f6"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.ne	LBB100_6
; %bb.1:                                ; %bb3.i.i
	ldr	x8, [x1, #8]
	ldr	x9, [x0, #16]
	cmp	x8, x9
	b.hs	LBB100_7
; %bb.2:                                ; %bb2.i.i.i
	ldr	x9, [x1, #16]
	ldr	x10, [x0, #32]
	mov	w11, #56                        ; =0x38
	madd	x10, x8, x11, x10
	ldr	x11, [x10, #40]
	cmp	x11, x9
	b.ne	LBB100_7
; %bb.3:                                ; %bb5.i.i.i
	ldr	x11, [x10]
	cbz	x11, LBB100_7
; %bb.4:                                ; %bb2.i
	ldr	x1, [x10, #32]
	cmp	x1, #1
	b.ne	LBB100_8
; %bb.5:
	mov	x1, #0                          ; =0x0
	mov	w2, #7                          ; =0x7
	mov	w0, #1                          ; =0x1
	ret
LBB100_6:
	mov	x1, #0                          ; =0x0
	mov	w2, #4                          ; =0x4
	mov	w0, #1                          ; =0x1
	ret
LBB100_7:
	mov	x1, #0                          ; =0x0
	mov	w2, #3                          ; =0x3
	mov	w0, #1                          ; =0x1
	ret
LBB100_8:                               ; %bb6.i
	ldr	x11, [x0, #88]
	cmp	x1, x11
	b.hs	LBB100_12
; %bb.9:                                ; %bb8.i
	ldr	x11, [x0, #104]
	add	x11, x11, x1, lsl #5
	ldp	x12, x13, [x11, #16]
	cmp	x12, x8
	ccmp	x13, x9, #0, eq
	b.ne	LBB100_12
; %bb.10:                               ; %bb11.i
	ldr	x8, [x10, #8]
	ldr	x9, [x11, #8]
	cmp	x9, x8
	b.ne	LBB100_12
; %bb.11:                               ; %bb14.i
	mov	w0, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ret
LBB100_12:
	mov	x1, #0                          ; =0x0
	mov	w2, #8                          ; =0x8
	mov	w0, #1                          ; =0x1
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_push_indexed$instance$17afb96af21633a2 ; -- Begin function wf_collections.priority_queue.priority_queue_push_indexed$instance$17afb96af21633a2
	.p2align	2
_wf_collections.priority_queue.priority_queue_push_indexed$instance$17afb96af21633a2: ; @"wf_collections.priority_queue.priority_queue_push_indexed$instance$17afb96af21633a2"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #80
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 80
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	ldp	q0, q1, [x2]
	stp	q0, q1, [sp]
	ldr	x8, [x1]
	cbz	x8, LBB101_2
; %bb.1:                                ; %bb2
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	ldp	q0, q1, [sp]
	stur	q0, [x19, #8]
	stur	q1, [x19, #24]
	b	LBB101_11
LBB101_2:                               ; %bb3
	ldr	x8, [x1, #8]
	cbz	x8, LBB101_4
; %bb.3:                                ; %"bb3.wf_collections.priority_queue.priority_queue_make_room$instance$6fdaba65c7a2e99d.exit_crit_edge"
	ldr	x0, [x1, #16]
	b	LBB101_6
LBB101_4:                               ; %bb5.i
	mov	x20, x2
	mov	x22, x1
	mov	x21, x4
	mov	w0, #32                         ; =0x20
	bl	_malloc
	cbz	x0, LBB101_12
; %bb.5:                                ; %window.grow.copy.ready.v2.i.i.i
	mov	w8, #1                          ; =0x1
	mov	x1, x22
	stp	x8, x0, [x22, #8]
	mov	x4, x21
	mov	x2, x20
LBB101_6:                               ; %"wf_collections.priority_queue.priority_queue_make_room$instance$6fdaba65c7a2e99d.exit"
	ldp	q0, q1, [x2]
	stp	q0, q1, [x0]
	mov	w8, #1                          ; =0x1
	str	x8, [x1]
	ldr	x8, [x0, #16]
	ldr	x9, [x4]
	cmp	x8, x9
	b.hs	LBB101_10
; %bb.7:                                ; %bb2.i.i.i
	ldr	x9, [x0, #24]
	ldr	x10, [x4, #16]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB101_10
; %bb.8:                                ; %bb5.i.i.i
	ldr	x9, [x8]
	cbz	x9, LBB101_10
; %bb.9:                                ; %bb8.i.i.i
	str	xzr, [x8, #32]
LBB101_10:                              ; %"wf_record_report_position$instance$5ffcb0796f3480f6.exit"
	mov	x0, x1
	mov	x1, #0                          ; =0x0
	bl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$17afb96af21633a2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	str	xzr, [x19, #32]
LBB101_11:                              ; %bb2
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
LBB101_12:                              ; %window.block.oom.v2.i.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_free$instance$49bcdf956259ee48 ; -- Begin function wf_std.collections.hash_map.hash_map_free$instance$49bcdf956259ee48
	.p2align	2
_wf_std.collections.hash_map.hash_map_free$instance$49bcdf956259ee48: ; @"wf_std.collections.hash_map.hash_map_free$instance$49bcdf956259ee48"
; %bb.0:                                ; %entry
	ldr	x8, [x0, #8]
	cbz	x8, LBB102_2
; %bb.1:                                ; %slots.release.drop.6.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #16]
	bl	_free
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB102_2:                               ; %"wf_free_empty$instance$16f094be4fd843b6.exit"
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_free$instance$bc1a7c25f6fdb27b ; -- Begin function wf_collections.priority_queue.priority_queue_free$instance$bc1a7c25f6fdb27b
	.p2align	2
_wf_collections.priority_queue.priority_queue_free$instance$bc1a7c25f6fdb27b: ; @"wf_collections.priority_queue.priority_queue_free$instance$bc1a7c25f6fdb27b"
; %bb.0:                                ; %entry
	ldr	x8, [x0, #8]
	cbz	x8, LBB103_2
; %bb.1:                                ; %slots.release.drop.6.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #16]
	bl	_free
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB103_2:                               ; %"wf_free_empty$instance$401ab120abe5d512.exit"
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_free$instance$195c79590f9dde23 ; -- Begin function wf_std.collections.slab.slab_free$instance$195c79590f9dde23
	.p2align	2
_wf_std.collections.slab.slab_free$instance$195c79590f9dde23: ; @"wf_std.collections.slab.slab_free$instance$195c79590f9dde23"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	ldp	x10, x8, [x0]
	ldr	x0, [x0, #16]
	cbz	x10, LBB104_8
; %bb.1:                                ; %bb5.lr.ph
	ldr	q0, [x1]
	ands	x11, x10, #0x7
	b.eq	LBB104_6
; %bb.2:                                ; %bb5.prol.preheader
	mov	w9, #56                         ; =0x38
	madd	x9, x10, x9, x0
	sub	x12, x9, #56
	mov	x13, sp
	mov	w9, #1                          ; =0x1
	dup.2d	v1, x9
	mov	x9, x10
	b	LBB104_4
LBB104_3:                               ; %bb6.prol
                                        ;   in Loop: Header=BB104_4 Depth=1
	sub	x12, x12, #56
	sub	x9, x9, #1
	sub	x11, x11, #1
	cbz	x11, LBB104_7
LBB104_4:                               ; %bb5.prol
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q2, q3, [x12]
	stp	q2, q3, [sp]
	ldr	x14, [x12, #32]
	str	x14, [sp, #32]
	ldr	x14, [sp]
	cbz	x14, LBB104_3
; %bb.5:                                ; %bb7.prol
                                        ;   in Loop: Header=BB104_4 Depth=1
	sub	x14, x14, #1
	str	x14, [sp]
	add	x14, x13, x14, lsl #5
	add	x14, x14, #16
	mov.16b	v2, v1
	ld1.d	{ v2 }[1], [x14]
	add.2d	v0, v0, v2
	str	q0, [x1]
	b	LBB104_3
LBB104_6:
	mov	x9, x10
LBB104_7:                               ; %bb5.prol.loopexit
	cmp	x10, #8
	b.hs	LBB104_11
LBB104_8:                               ; %bb4
	cbz	x8, LBB104_10
; %bb.9:                                ; %slots.release.drop.6.i
	bl	_free
LBB104_10:                              ; %"wf_free_empty$instance$e22bd0c72870f88b.exit"
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB104_11:                              ; %bb5.lr.ph.new
	mov	w10, #56                        ; =0x38
	madd	x10, x9, x10, x0
	sub	x10, x10, #224
	mov	x11, sp
	mov	w12, #1                         ; =0x1
	dup.2d	v1, x12
	b	LBB104_13
LBB104_12:                              ; %bb6.7
                                        ;   in Loop: Header=BB104_13 Depth=1
	sub	x10, x10, #448
	sub	x9, x9, #8
	cbz	x9, LBB104_8
LBB104_13:                              ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	ldur	q2, [x10, #168]
	ldur	q3, [x10, #184]
	stp	q2, q3, [sp]
	ldr	x13, [x10, #200]
	str	x13, [sp, #32]
	ldr	x13, [sp]
	cbz	x13, LBB104_15
; %bb.14:                               ; %bb7
                                        ;   in Loop: Header=BB104_13 Depth=1
	sub	x13, x13, #1
	str	x13, [sp]
	add	x13, x11, x13, lsl #5
	add	x13, x13, #16
	dup.2d	v2, x12
	ld1.d	{ v2 }[1], [x13]
	add.2d	v0, v0, v2
	str	q0, [x1]
LBB104_15:                              ; %bb6
                                        ;   in Loop: Header=BB104_13 Depth=1
	ldp	q2, q3, [x10, #112]
	stp	q2, q3, [sp]
	ldr	x13, [x10, #144]
	str	x13, [sp, #32]
	ldr	x13, [sp]
	cbz	x13, LBB104_17
; %bb.16:                               ; %bb7.1
                                        ;   in Loop: Header=BB104_13 Depth=1
	sub	x13, x13, #1
	str	x13, [sp]
	add	x13, x11, x13, lsl #5
	add	x13, x13, #16
	dup.2d	v2, x12
	ld1.d	{ v2 }[1], [x13]
	add.2d	v0, v0, v2
	str	q0, [x1]
LBB104_17:                              ; %bb6.1
                                        ;   in Loop: Header=BB104_13 Depth=1
	ldur	q2, [x10, #56]
	ldur	q3, [x10, #72]
	stp	q2, q3, [sp]
	ldr	x13, [x10, #88]
	str	x13, [sp, #32]
	ldr	x13, [sp]
	cbz	x13, LBB104_19
; %bb.18:                               ; %bb7.2
                                        ;   in Loop: Header=BB104_13 Depth=1
	sub	x13, x13, #1
	str	x13, [sp]
	add	x13, x11, x13, lsl #5
	add	x13, x13, #16
	dup.2d	v2, x12
	ld1.d	{ v2 }[1], [x13]
	add.2d	v0, v0, v2
	str	q0, [x1]
LBB104_19:                              ; %bb6.2
                                        ;   in Loop: Header=BB104_13 Depth=1
	ldp	q2, q3, [x10]
	stp	q2, q3, [sp]
	ldr	x13, [x10, #32]
	str	x13, [sp, #32]
	ldr	x13, [sp]
	cbz	x13, LBB104_21
; %bb.20:                               ; %bb7.3
                                        ;   in Loop: Header=BB104_13 Depth=1
	sub	x13, x13, #1
	str	x13, [sp]
	add	x13, x11, x13, lsl #5
	add	x13, x13, #16
	dup.2d	v2, x12
	ld1.d	{ v2 }[1], [x13]
	add.2d	v0, v0, v2
	str	q0, [x1]
LBB104_21:                              ; %bb6.3
                                        ;   in Loop: Header=BB104_13 Depth=1
	ldur	q2, [x10, #-56]
	ldur	q3, [x10, #-40]
	stp	q2, q3, [sp]
	ldur	x13, [x10, #-24]
	str	x13, [sp, #32]
	ldr	x13, [sp]
	cbz	x13, LBB104_23
; %bb.22:                               ; %bb7.4
                                        ;   in Loop: Header=BB104_13 Depth=1
	sub	x13, x13, #1
	str	x13, [sp]
	add	x13, x11, x13, lsl #5
	add	x13, x13, #16
	dup.2d	v2, x12
	ld1.d	{ v2 }[1], [x13]
	add.2d	v0, v0, v2
	str	q0, [x1]
LBB104_23:                              ; %bb6.4
                                        ;   in Loop: Header=BB104_13 Depth=1
	ldp	q2, q3, [x10, #-112]
	stp	q2, q3, [sp]
	ldur	x13, [x10, #-80]
	str	x13, [sp, #32]
	ldr	x13, [sp]
	cbz	x13, LBB104_25
; %bb.24:                               ; %bb7.5
                                        ;   in Loop: Header=BB104_13 Depth=1
	sub	x13, x13, #1
	str	x13, [sp]
	add	x13, x11, x13, lsl #5
	add	x13, x13, #16
	dup.2d	v2, x12
	ld1.d	{ v2 }[1], [x13]
	add.2d	v0, v0, v2
	str	q0, [x1]
LBB104_25:                              ; %bb6.5
                                        ;   in Loop: Header=BB104_13 Depth=1
	ldur	q2, [x10, #-168]
	ldur	q3, [x10, #-152]
	stp	q2, q3, [sp]
	ldur	x13, [x10, #-136]
	str	x13, [sp, #32]
	ldr	x13, [sp]
	cbz	x13, LBB104_27
; %bb.26:                               ; %bb7.6
                                        ;   in Loop: Header=BB104_13 Depth=1
	sub	x13, x13, #1
	str	x13, [sp]
	add	x13, x11, x13, lsl #5
	add	x13, x13, #16
	dup.2d	v2, x12
	ld1.d	{ v2 }[1], [x13]
	add.2d	v0, v0, v2
	str	q0, [x1]
LBB104_27:                              ; %bb6.6
                                        ;   in Loop: Header=BB104_13 Depth=1
	ldp	q2, q3, [x10, #-224]
	stp	q2, q3, [sp]
	ldur	x13, [x10, #-192]
	str	x13, [sp, #32]
	ldr	x13, [sp]
	cbz	x13, LBB104_12
; %bb.28:                               ; %bb7.7
                                        ;   in Loop: Header=BB104_13 Depth=1
	sub	x13, x13, #1
	str	x13, [sp]
	add	x13, x11, x13, lsl #5
	add	x13, x13, #16
	mov.16b	v2, v1
	ld1.d	{ v2 }[1], [x13]
	add.2d	v0, v0, v2
	str	q0, [x1]
	b	LBB104_12
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_new$instance$4283ac555539d10e ; -- Begin function wf_std.collections.slab.slab_new$instance$4283ac555539d10e
	.p2align	2
_wf_std.collections.slab.slab_new$instance$4283ac555539d10e: ; @"wf_std.collections.slab.slab_new$instance$4283ac555539d10e"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	mov	x20, x0
	cbz	x1, LBB105_3
; %bb.1:                                ; %window.payload.allocate.v1.i.i
	lsl	x8, x19, #6
	sub	x0, x8, x19, lsl #3
	bl	_malloc
	cbnz	x0, LBB105_4
; %bb.2:                                ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
LBB105_3:
Lloh310:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh311:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB105_4:                               ; %"wf_box_slots_new$instance$98bdc07c73822b42.exit"
	stp	xzr, x19, [x20]
	stp	x0, x19, [x20, #16]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh310, Lloh311
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_new$instance$56bab2225b172a73 ; -- Begin function wf_std.collections.hash_map.hash_map_new$instance$56bab2225b172a73
	.p2align	2
_wf_std.collections.hash_map.hash_map_new$instance$56bab2225b172a73: ; @"wf_std.collections.hash_map.hash_map_new$instance$56bab2225b172a73"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x1
	mov	x19, x0
	cbz	x1, LBB106_4
; %bb.1:                                ; %window.payload.allocate.v1.i.i
	lsl	x0, x20, #5
	bl	_malloc
	cbz	x0, LBB106_6
; %bb.2:                                ; %bb5.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #8
LBB106_3:                               ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x9, #8]
	str	xzr, [x9], #32
	cmp	x20, x8
	b.ne	LBB106_3
	b	LBB106_5
LBB106_4:
Lloh312:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh313:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB106_5:                               ; %"wf_std.collections.hash_map.hash_map_extend$instance$56bab2225b172a73.exit"
	stp	x20, x20, [x19]
	stp	xzr, xzr, [x19, #24]
	str	x0, [x19, #16]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB106_6:                               ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.loh AdrpAdd	Lloh312, Lloh313
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_heapify$instance$e332b3dde67982e1 ; -- Begin function wf_collections.priority_queue.priority_queue_heapify$instance$e332b3dde67982e1
	.p2align	2
_wf_collections.priority_queue.priority_queue_heapify$instance$e332b3dde67982e1: ; @"wf_collections.priority_queue.priority_queue_heapify$instance$e332b3dde67982e1"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	ldr	q0, [x0]
	str	q0, [sp]
	ldr	x8, [x0, #16]
	str	x8, [sp, #16]
	ldr	x19, [sp]
	cmp	x19, #2
	b.lo	LBB107_3
; %bb.1:                                ; %bb2.i.preheader
	lsr	x8, x19, #1
	sub	x20, x8, #1
LBB107_2:                               ; %bb2.i
                                        ; =>This Inner Loop Header: Depth=1
	mov	x0, sp
	mov	x1, x20
	mov	x2, x19
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$ab518dd14902c4dc
	sub	x20, x20, #1
	cmn	x20, #1
	b.ne	LBB107_2
LBB107_3:                               ; %"wf_collections.priority_queue.priority_queue_heapify$instance$e332b3dde67982e1.body.exit"
	ldp	x1, x2, [sp, #8]
	mov	x0, x19
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_insert$instance$4283ac555539d10e ; -- Begin function wf_std.collections.slab.slab_insert$instance$4283ac555539d10e
	.p2align	2
_wf_std.collections.slab.slab_insert$instance$4283ac555539d10e: ; @"wf_std.collections.slab.slab_insert$instance$4283ac555539d10e"
; %bb.0:                                ; %entry
	sub	sp, sp, #16
	ldp	x9, x12, [x2]
	ldrb	w10, [x2, #16]
	ldr	w11, [x2, #20]
	mov	x14, x2
	ldr	w13, [x14, #17]!
	ldr	x8, [x2, #24]
	str	w13, [sp, #8]
	stur	w11, [sp, #11]
	ldr	x11, [x1, #24]
	ldr	x13, [x1]
	cmp	x11, x13
	b.hs	LBB108_4
; %bb.1:                                ; %bb2
	ldr	x13, [x1, #16]
	mov	w14, #56                        ; =0x38
	madd	x13, x11, x14, x13
	ldr	x14, [x13]
	cbnz	x14, LBB108_6
; %bb.2:                                ; %bb5
	ldr	x14, [x13, #40]
	cbnz	x14, LBB108_6
; %bb.3:                                ; %bb8
	ldr	x14, [x13, #48]
	stp	x9, x12, [x13, #8]
	strb	w10, [x13, #24]
	ldr	w10, [sp, #8]
	stur	w10, [x13, #25]
	ldur	w10, [sp, #11]
	str	w10, [x13, #28]
	str	x8, [x13, #32]
	mov	w8, #1                          ; =0x1
	str	x8, [x13]
	str	x14, [x1, #24]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	str	xzr, [x0, #32]
	str	x11, [x0, #8]
	add	sp, sp, #16
	ret
LBB108_4:                               ; %bb3
	ldr	x15, [x1, #8]
	cmp	x13, x15
	b.hs	LBB108_6
; %bb.5:                                ; %bb11
	ldur	w15, [x14, #3]
	stur	w15, [sp, #3]
	ldr	w14, [x14]
	str	w14, [sp]
	ldr	x14, [x1, #16]
	mov	w15, #56                        ; =0x38
	madd	x14, x13, x15, x14
	mov	w15, #1                         ; =0x1
	stp	x15, x9, [x14]
	str	x12, [x14, #16]
	strb	w10, [x14, #24]
	ldr	w9, [sp]
	stur	w9, [x14, #25]
	ldur	w9, [sp, #3]
	str	w9, [x14, #28]
	stp	x8, xzr, [x14, #32]
	str	x11, [x14, #48]
	add	x8, x13, #1
	str	x8, [x1]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	str	xzr, [x0, #32]
	str	x13, [x0, #8]
	add	sp, sp, #16
	ret
LBB108_6:                               ; %bb4
	stp	xzr, x9, [x0]
	mov	w11, #1                         ; =0x1
	str	w11, [x0]
	str	x12, [x0, #16]
	strb	w10, [x0, #24]
	ldr	w9, [sp, #8]
	stur	w9, [x0, #25]
	ldur	w9, [sp, #11]
	str	w9, [x0, #28]
	str	x8, [x0, #32]
	add	sp, sp, #16
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_len$instance$ebf8b73d1d9950bc ; -- Begin function wf_collections.priority_queue.priority_queue_len$instance$ebf8b73d1d9950bc
	.p2align	2
_wf_collections.priority_queue.priority_queue_len$instance$ebf8b73d1d9950bc: ; @"wf_collections.priority_queue.priority_queue_len$instance$ebf8b73d1d9950bc"
; %bb.0:                                ; %entry
	ldr	x0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_peek$instance$e00a3db4bb90bedd ; -- Begin function wf_collections.priority_queue.priority_queue_peek$instance$e00a3db4bb90bedd
	.p2align	2
_wf_collections.priority_queue.priority_queue_peek$instance$e00a3db4bb90bedd: ; @"wf_collections.priority_queue.priority_queue_peek$instance$e00a3db4bb90bedd"
; %bb.0:                                ; %entry
	ldr	x8, [x1, #16]
	ldp	q1, q0, [x8]
	stp	q1, q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$4a1731430e1da28f ; -- Begin function wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$4a1731430e1da28f
	.p2align	2
_wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$4a1731430e1da28f: ; @"wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$4a1731430e1da28f"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	mov	x19, x0
	ldr	x8, [x1]
	sub	x8, x8, #1
	ldr	x10, [x1, #16]
	add	x11, x10, x8, lsl #5
	str	x8, [x1]
	ldp	q0, q1, [x11]
	stp	q0, q1, [sp]
	cmp	x2, x8
	b.hs	LBB111_10
; %bb.1:                                ; %bb2
	add	x9, x10, x2, lsl #5
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp]
	ldp	q0, q1, [x11]
	stp	q0, q1, [x9]
	ldr	x11, [x9, #16]
	ldr	x12, [x4]
	cmp	x11, x12
	b.hs	LBB111_5
; %bb.2:                                ; %bb2.i.i.i
	ldr	x12, [x9, #24]
	ldr	x13, [x4, #16]
	mov	w14, #56                        ; =0x38
	madd	x11, x11, x14, x13
	ldr	x13, [x11, #40]
	cmp	x13, x12
	b.ne	LBB111_5
; %bb.3:                                ; %bb5.i.i.i
	ldr	x12, [x11]
	cbz	x12, LBB111_5
; %bb.4:                                ; %bb8.i.i.i
	str	x2, [x11, #32]
LBB111_5:                               ; %"wf_record_report_position$instance$aa2364d9cd38ac5f.exit"
	cbz	x2, LBB111_7
; %bb.6:                                ; %bb2.i
	lsl	x11, x2, #4
	sub	x11, x11, #16
	and	x11, x11, #0xffffffffffffffe0
	add	x10, x10, x11
	ldr	x11, [x10]
	ldr	x12, [x9]
	cmp	x11, x12
	b.hs	LBB111_8
LBB111_7:                               ; %bb1.i
	mov	x0, x1
	mov	x1, x2
	mov	x2, x8
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$4a1731430e1da28f
	b	LBB111_10
LBB111_8:                               ; %bb3.i.i
	b.ls	LBB111_11
LBB111_9:                               ; %bb5.i
	mov	x0, x1
	mov	x1, x2
	bl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$4a1731430e1da28f
LBB111_10:                              ; %bb1
	ldp	q0, q1, [sp]
	stp	q0, q1, [x19]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB111_11:                              ; %bb6.i.i
	ldr	x11, [x10, #8]
	ldr	x12, [x9, #8]
	cmp	x11, x12
	b.lo	LBB111_7
; %bb.12:                               ; %bb9.i.i
	b.hi	LBB111_9
; %bb.13:                               ; %bb12.i.i
	ldr	x11, [x10, #16]
	ldr	x12, [x9, #16]
	cmp	x11, x12
	b.lo	LBB111_7
; %bb.14:                               ; %bb15.i.i
	b.hi	LBB111_9
; %bb.15:                               ; %bb18.i.i
	ldr	x10, [x10, #24]
	ldr	x9, [x9, #24]
	cmp	x10, x9
	b.ls	LBB111_7
	b	LBB111_9
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_edit$instance$d0c575ce05c33b0e ; -- Begin function wf_std.collections.slab.slab_edit$instance$d0c575ce05c33b0e
	.p2align	2
_wf_std.collections.slab.slab_edit$instance$d0c575ce05c33b0e: ; @"wf_std.collections.slab.slab_edit$instance$d0c575ce05c33b0e"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.hs	LBB112_4
; %bb.1:                                ; %bb2.i
	ldr	x9, [x1, #8]
	ldr	x10, [x0, #16]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB112_4
; %bb.2:                                ; %bb5.i
	ldr	x9, [x8]
	cbz	x9, LBB112_4
; %bb.3:                                ; %bb8.i
	mov	w0, #0                          ; =0x0
	ldr	x9, [x2]
	str	x9, [x8, #32]
	b	LBB112_5
LBB112_4:
	mov	w0, #1                          ; =0x1
LBB112_5:                               ; %"wf_std.collections.slab.slab_edit$instance$d0c575ce05c33b0e.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_record_store_detach$instance$aa2364d9cd38ac5f ; -- Begin function wf_record_store_detach$instance$aa2364d9cd38ac5f
	.p2align	2
_wf_record_store_detach$instance$aa2364d9cd38ac5f: ; @"wf_record_store_detach$instance$aa2364d9cd38ac5f"
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	ldr	x9, [x0]
	cmp	x8, x9
	b.ne	LBB113_3
; %bb.1:                                ; %bb3
	ldr	x8, [x0, #112]
	cbz	x8, LBB113_5
; %bb.2:                                ; %bb3.i.i
	udiv	x9, x1, x8
	msub	x13, x9, x8, x1
	ldr	x11, [x0, #48]
	cbnz	x11, LBB113_6
	b	LBB113_26
LBB113_3:
	mov	w8, #4                          ; =0x4
LBB113_4:                               ; %common.ret
	mov	x0, x8
	ret
LBB113_5:
	mov	x13, #0                         ; =0x0
	ldr	x11, [x0, #48]
	cbz	x11, LBB113_26
LBB113_6:                               ; %bb3.i
	ldp	x10, x9, [x2, #8]
	mov	x12, x11
	udiv	x14, x13, x11
	msub	x14, x14, x11, x13
	ldr	x13, [x0, #64]
	mov	x15, x11
	b	LBB113_8
LBB113_7:                               ; %bb8.i
                                        ;   in Loop: Header=BB113_8 Depth=1
	add	x16, x14, #1
	cmp	x16, x11
	csinc	x14, xzr, x14, hs
	subs	x15, x15, #1
	b.eq	LBB113_26
LBB113_8:                               ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x16, x13, x14, lsl #5
	ldr	w17, [x16]
	cmp	w17, #1
	b.eq	LBB113_7
; %bb.9:                                ; %bb5.i
                                        ;   in Loop: Header=BB113_8 Depth=1
	cmp	w17, #2
	b.ne	LBB113_26
; %bb.10:                               ; %bb9.i
                                        ;   in Loop: Header=BB113_8 Depth=1
	ldr	x17, [x16, #8]
	cmp	x17, x1
	b.ne	LBB113_7
; %bb.11:                               ; %bb4
	ldp	x14, x15, [x16, #16]
	cmp	x14, x10
	ccmp	x15, x9, #0, eq
	b.eq	LBB113_13
; %bb.12:
	mov	w0, #5                          ; =0x5
	ret
LBB113_13:                              ; %bb7
	ldr	x14, [x0, #72]
	cbz	x14, LBB113_26
; %bb.14:                               ; %bb3.i5
	cbz	x8, LBB113_16
; %bb.15:                               ; %bb3.i.i.i.i
	udiv	x15, x1, x8
	msub	x8, x15, x8, x1
LBB113_16:                              ; %bb3.i.i.i
	udiv	x15, x8, x11
	msub	x15, x15, x11, x8
	b	LBB113_18
LBB113_17:                              ; %bb8.i.i.i
                                        ;   in Loop: Header=BB113_18 Depth=1
	add	x8, x15, #1
	cmp	x8, x11
	csinc	x15, xzr, x15, hs
	mov	w8, #2                          ; =0x2
	subs	x12, x12, #1
	b.eq	LBB113_4
LBB113_18:                              ; %bb5.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x8, x13, x15, lsl #5
	ldr	w16, [x8]
	cmp	w16, #1
	b.eq	LBB113_17
; %bb.19:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB113_18 Depth=1
	cmp	w16, #2
	b.ne	LBB113_26
; %bb.20:                               ; %bb3.i3.i.i.i
                                        ;   in Loop: Header=BB113_18 Depth=1
	ldr	x16, [x8, #8]
	cmp	x16, x1
	b.ne	LBB113_17
; %bb.21:                               ; %bb9
	mov	w11, #1                         ; =0x1
	str	w11, [x8]
	sub	x11, x14, #1
	stp	xzr, xzr, [x8, #16]
	str	xzr, [x8, #8]
	ldr	x8, [x0, #80]
	adds	x8, x8, #1
	csinv	x8, x8, xzr, lo
	stp	x11, x8, [x0, #72]
	ldr	x8, [x0, #16]
	cmp	x10, x8
	b.hs	LBB113_25
; %bb.22:                               ; %bb2.i.i
	ldr	x8, [x0, #32]
	mov	w11, #56                        ; =0x38
	madd	x10, x10, x11, x8
	ldr	x8, [x10, #40]
	cmp	x8, x9
	b.ne	LBB113_25
; %bb.23:                               ; %bb5.i.i
	ldr	x8, [x10]
	cbz	x8, LBB113_4
; %bb.24:                               ; %bb8.i.i
	strb	wzr, [x10, #24]
LBB113_25:
	mov	w0, #0                          ; =0x0
	ret
LBB113_26:
	mov	w0, #2                          ; =0x2
	ret
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function wf_record_store_delete$instance$aa2364d9cd38ac5f
lCPI114_0:
	.long	1                               ; 0x1
	.long	9                               ; 0x9
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_record_store_delete$instance$aa2364d9cd38ac5f
	.p2align	2
_wf_record_store_delete$instance$aa2364d9cd38ac5f: ; @"wf_record_store_delete$instance$aa2364d9cd38ac5f"
; %bb.0:                                ; %entry
	sub	sp, sp, #48
	ldr	x8, [x2]
	ldr	x9, [x1]
	cmp	x8, x9
	b.ne	LBB114_8
; %bb.1:                                ; %bb3.i
	ldr	x8, [x2, #8]
	ldr	x9, [x1, #16]
	cmp	x8, x9
	b.hs	LBB114_9
; %bb.2:                                ; %bb2.i.i
	ldr	x9, [x2, #16]
	ldr	x10, [x1, #32]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB114_9
; %bb.3:                                ; %bb5.i.i
	ldr	x9, [x8]
	cbz	x9, LBB114_9
; %bb.4:                                ; %bb2
	ldrb	w11, [x8, #24]
	ldr	x10, [x8, #32]
	and	w11, w11, #0x1
	strb	w11, [sp, #40]
	ldrb	w12, [x1, #8]
	tbz	w12, #0, LBB114_11
; %bb.5:                                ; %bb5
	cbnz	w11, LBB114_7
; %bb.6:                                ; %bb9
	cbz	x10, LBB114_11
LBB114_7:                               ; %bb8
	movi.2d	v0, #0000000000000000
	stur	q0, [x0, #24]
	stur	q0, [x0, #8]
Lloh314:
	adrp	x8, lCPI114_0@PAGE
Lloh315:
	ldr	d0, [x8, lCPI114_0@PAGEOFF]
	str	d0, [x0]
	add	sp, sp, #48
	ret
LBB114_8:
	mov	w8, #4                          ; =0x4
	b	LBB114_10
LBB114_9:                               ; %bb5.i
	mov	w8, #3                          ; =0x3
LBB114_10:                              ; %bb3
	movi.2d	v0, #0000000000000000
	stur	q0, [x0, #24]
	stur	q0, [x0, #8]
	mov	w9, #1                          ; =0x1
	stp	w9, w8, [x0]
	add	sp, sp, #48
	ret
LBB114_11:                              ; %bb13
	sub	x9, x9, #1
	add	x10, x8, x9, lsl #5
	str	x9, [x8]
	ldur	q0, [x10, #8]
	ldur	q1, [x10, #24]
	stp	q0, q1, [sp]
	str	xzr, [x0]
	stur	q0, [x0, #8]
	stur	q1, [x0, #24]
	add	sp, sp, #48
	ret
	.loh AdrpLdr	Lloh314, Lloh315
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_free$instance$254d3f8f5bda5a0a ; -- Begin function wf_std.collections.hash_map.hash_map_free$instance$254d3f8f5bda5a0a
	.p2align	2
_wf_std.collections.hash_map.hash_map_free$instance$254d3f8f5bda5a0a: ; @"wf_std.collections.hash_map.hash_map_free$instance$254d3f8f5bda5a0a"
; %bb.0:                                ; %entry
	ldr	x8, [x0, #8]
	cbz	x8, LBB115_2
; %bb.1:                                ; %slots.release.drop.6.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #16]
	bl	_free
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB115_2:                               ; %"wf_free_empty$instance$16f094be4fd843b6.exit"
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_free$instance$f600fe92c9d45040 ; -- Begin function wf_collections.priority_queue.priority_queue_free$instance$f600fe92c9d45040
	.p2align	2
_wf_collections.priority_queue.priority_queue_free$instance$f600fe92c9d45040: ; @"wf_collections.priority_queue.priority_queue_free$instance$f600fe92c9d45040"
; %bb.0:                                ; %entry
	ldr	x8, [x0, #8]
	cbz	x8, LBB116_2
; %bb.1:                                ; %slots.release.drop.6.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #16]
	bl	_free
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB116_2:                               ; %"wf_free_empty$instance$401ab120abe5d512.exit"
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_free$instance$b016683df5790773 ; -- Begin function wf_std.collections.slab.slab_free$instance$b016683df5790773
	.p2align	2
_wf_std.collections.slab.slab_free$instance$b016683df5790773: ; @"wf_std.collections.slab.slab_free$instance$b016683df5790773"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	ldp	x10, x8, [x0]
	ldr	x0, [x0, #16]
	cbz	x10, LBB117_8
; %bb.1:                                ; %bb5.lr.ph
	ldr	q0, [x1]
	ands	x11, x10, #0x7
	b.eq	LBB117_6
; %bb.2:                                ; %bb5.prol.preheader
	mov	w9, #56                         ; =0x38
	madd	x9, x10, x9, x0
	sub	x12, x9, #56
	mov	x13, sp
	mov	w9, #1                          ; =0x1
	dup.2d	v1, x9
	mov	x9, x10
	b	LBB117_4
LBB117_3:                               ; %bb6.prol
                                        ;   in Loop: Header=BB117_4 Depth=1
	sub	x12, x12, #56
	sub	x9, x9, #1
	sub	x11, x11, #1
	cbz	x11, LBB117_7
LBB117_4:                               ; %bb5.prol
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q2, q3, [x12]
	stp	q2, q3, [sp]
	ldr	x14, [x12, #32]
	str	x14, [sp, #32]
	ldr	x14, [sp]
	cbz	x14, LBB117_3
; %bb.5:                                ; %bb7.prol
                                        ;   in Loop: Header=BB117_4 Depth=1
	sub	x14, x14, #1
	str	x14, [sp]
	add	x14, x13, x14, lsl #5
	add	x14, x14, #16
	mov.16b	v2, v1
	ld1.d	{ v2 }[1], [x14]
	add.2d	v0, v0, v2
	str	q0, [x1]
	b	LBB117_3
LBB117_6:
	mov	x9, x10
LBB117_7:                               ; %bb5.prol.loopexit
	cmp	x10, #8
	b.hs	LBB117_11
LBB117_8:                               ; %bb4
	cbz	x8, LBB117_10
; %bb.9:                                ; %slots.release.drop.6.i
	bl	_free
LBB117_10:                              ; %"wf_free_empty$instance$e22bd0c72870f88b.exit"
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB117_11:                              ; %bb5.lr.ph.new
	mov	w10, #56                        ; =0x38
	madd	x10, x9, x10, x0
	sub	x10, x10, #224
	mov	x11, sp
	mov	w12, #1                         ; =0x1
	dup.2d	v1, x12
	b	LBB117_13
LBB117_12:                              ; %bb6.7
                                        ;   in Loop: Header=BB117_13 Depth=1
	sub	x10, x10, #448
	sub	x9, x9, #8
	cbz	x9, LBB117_8
LBB117_13:                              ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	ldur	q2, [x10, #168]
	ldur	q3, [x10, #184]
	stp	q2, q3, [sp]
	ldr	x13, [x10, #200]
	str	x13, [sp, #32]
	ldr	x13, [sp]
	cbz	x13, LBB117_15
; %bb.14:                               ; %bb7
                                        ;   in Loop: Header=BB117_13 Depth=1
	sub	x13, x13, #1
	str	x13, [sp]
	add	x13, x11, x13, lsl #5
	add	x13, x13, #16
	dup.2d	v2, x12
	ld1.d	{ v2 }[1], [x13]
	add.2d	v0, v0, v2
	str	q0, [x1]
LBB117_15:                              ; %bb6
                                        ;   in Loop: Header=BB117_13 Depth=1
	ldp	q2, q3, [x10, #112]
	stp	q2, q3, [sp]
	ldr	x13, [x10, #144]
	str	x13, [sp, #32]
	ldr	x13, [sp]
	cbz	x13, LBB117_17
; %bb.16:                               ; %bb7.1
                                        ;   in Loop: Header=BB117_13 Depth=1
	sub	x13, x13, #1
	str	x13, [sp]
	add	x13, x11, x13, lsl #5
	add	x13, x13, #16
	dup.2d	v2, x12
	ld1.d	{ v2 }[1], [x13]
	add.2d	v0, v0, v2
	str	q0, [x1]
LBB117_17:                              ; %bb6.1
                                        ;   in Loop: Header=BB117_13 Depth=1
	ldur	q2, [x10, #56]
	ldur	q3, [x10, #72]
	stp	q2, q3, [sp]
	ldr	x13, [x10, #88]
	str	x13, [sp, #32]
	ldr	x13, [sp]
	cbz	x13, LBB117_19
; %bb.18:                               ; %bb7.2
                                        ;   in Loop: Header=BB117_13 Depth=1
	sub	x13, x13, #1
	str	x13, [sp]
	add	x13, x11, x13, lsl #5
	add	x13, x13, #16
	dup.2d	v2, x12
	ld1.d	{ v2 }[1], [x13]
	add.2d	v0, v0, v2
	str	q0, [x1]
LBB117_19:                              ; %bb6.2
                                        ;   in Loop: Header=BB117_13 Depth=1
	ldp	q2, q3, [x10]
	stp	q2, q3, [sp]
	ldr	x13, [x10, #32]
	str	x13, [sp, #32]
	ldr	x13, [sp]
	cbz	x13, LBB117_21
; %bb.20:                               ; %bb7.3
                                        ;   in Loop: Header=BB117_13 Depth=1
	sub	x13, x13, #1
	str	x13, [sp]
	add	x13, x11, x13, lsl #5
	add	x13, x13, #16
	dup.2d	v2, x12
	ld1.d	{ v2 }[1], [x13]
	add.2d	v0, v0, v2
	str	q0, [x1]
LBB117_21:                              ; %bb6.3
                                        ;   in Loop: Header=BB117_13 Depth=1
	ldur	q2, [x10, #-56]
	ldur	q3, [x10, #-40]
	stp	q2, q3, [sp]
	ldur	x13, [x10, #-24]
	str	x13, [sp, #32]
	ldr	x13, [sp]
	cbz	x13, LBB117_23
; %bb.22:                               ; %bb7.4
                                        ;   in Loop: Header=BB117_13 Depth=1
	sub	x13, x13, #1
	str	x13, [sp]
	add	x13, x11, x13, lsl #5
	add	x13, x13, #16
	dup.2d	v2, x12
	ld1.d	{ v2 }[1], [x13]
	add.2d	v0, v0, v2
	str	q0, [x1]
LBB117_23:                              ; %bb6.4
                                        ;   in Loop: Header=BB117_13 Depth=1
	ldp	q2, q3, [x10, #-112]
	stp	q2, q3, [sp]
	ldur	x13, [x10, #-80]
	str	x13, [sp, #32]
	ldr	x13, [sp]
	cbz	x13, LBB117_25
; %bb.24:                               ; %bb7.5
                                        ;   in Loop: Header=BB117_13 Depth=1
	sub	x13, x13, #1
	str	x13, [sp]
	add	x13, x11, x13, lsl #5
	add	x13, x13, #16
	dup.2d	v2, x12
	ld1.d	{ v2 }[1], [x13]
	add.2d	v0, v0, v2
	str	q0, [x1]
LBB117_25:                              ; %bb6.5
                                        ;   in Loop: Header=BB117_13 Depth=1
	ldur	q2, [x10, #-168]
	ldur	q3, [x10, #-152]
	stp	q2, q3, [sp]
	ldur	x13, [x10, #-136]
	str	x13, [sp, #32]
	ldr	x13, [sp]
	cbz	x13, LBB117_27
; %bb.26:                               ; %bb7.6
                                        ;   in Loop: Header=BB117_13 Depth=1
	sub	x13, x13, #1
	str	x13, [sp]
	add	x13, x11, x13, lsl #5
	add	x13, x13, #16
	dup.2d	v2, x12
	ld1.d	{ v2 }[1], [x13]
	add.2d	v0, v0, v2
	str	q0, [x1]
LBB117_27:                              ; %bb6.6
                                        ;   in Loop: Header=BB117_13 Depth=1
	ldp	q2, q3, [x10, #-224]
	stp	q2, q3, [sp]
	ldur	x13, [x10, #-192]
	str	x13, [sp, #32]
	ldr	x13, [sp]
	cbz	x13, LBB117_12
; %bb.28:                               ; %bb7.7
                                        ;   in Loop: Header=BB117_13 Depth=1
	sub	x13, x13, #1
	str	x13, [sp]
	add	x13, x11, x13, lsl #5
	add	x13, x13, #16
	mov.16b	v2, v1
	ld1.d	{ v2 }[1], [x13]
	add.2d	v0, v0, v2
	str	q0, [x1]
	b	LBB117_12
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$4dbd7ca4639a1dfc ; -- Begin function wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$4dbd7ca4639a1dfc
	.p2align	2
_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$4dbd7ca4639a1dfc: ; @"wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$4dbd7ca4639a1dfc"
; %bb.0:                                ; %entry
	lsr	x8, x2, #1
	cmp	x1, x8
	b.hs	LBB118_27
; %bb.1:                                ; %bb5.lr.ph
	sub	sp, sp, #32
	ldr	x9, [x0]
	ldr	x10, [x0, #16]
	add	x11, x4, #64
	b	LBB118_4
LBB118_2:                               ; %bb3.i10
                                        ;   in Loop: Header=BB118_4 Depth=1
	ldr	x13, [x4, #128]
	add	x13, x13, #1
	str	x13, [x4, #128]
LBB118_3:                               ; %wf_indexed_placed.exit20
                                        ;   in Loop: Header=BB118_4 Depth=1
	mov	x1, x12
	cmp	x12, x8
	b.hs	LBB118_26
LBB118_4:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x12, x1, #1
	mov	w13, #1                         ; =0x1
	bfi	x13, x1, #1, #63
	add	x14, x12, #2
	cmp	x14, x9
	b.hs	LBB118_8
; %bb.5:                                ; %bb2.i
                                        ;   in Loop: Header=BB118_4 Depth=1
	add	x15, x10, x14, lsl #5
	add	x16, x10, x13, lsl #5
	ldr	x12, [x15]
	ldr	x17, [x16]
	cmp	x12, x17
	b.hs	LBB118_7
LBB118_6:                               ;   in Loop: Header=BB118_4 Depth=1
	mov	x12, x14
	b	LBB118_9
LBB118_7:                               ; %bb3.i.i
                                        ;   in Loop: Header=BB118_4 Depth=1
	b.ls	LBB118_21
LBB118_8:                               ;   in Loop: Header=BB118_4 Depth=1
	mov	x12, x13
LBB118_9:                               ; %"wf_collections.priority_queue.priority_queue_child$instance$88bf97c7fdbb23c4.exit"
                                        ;   in Loop: Header=BB118_4 Depth=1
	add	x14, x10, x1, lsl #5
	add	x13, x10, x12, lsl #5
	ldr	x15, [x14]
	ldr	x16, [x13]
	cmp	x15, x16
	b.lo	LBB118_26
; %bb.10:                               ; %bb3.i
                                        ;   in Loop: Header=BB118_4 Depth=1
	b.hi	LBB118_16
; %bb.11:                               ; %bb6.i
                                        ;   in Loop: Header=BB118_4 Depth=1
	ldr	x15, [x14, #8]
	ldr	x16, [x13, #8]
	cmp	x15, x16
	b.lo	LBB118_26
; %bb.12:                               ; %bb9.i
                                        ;   in Loop: Header=BB118_4 Depth=1
	b.hi	LBB118_16
; %bb.13:                               ; %bb12.i
                                        ;   in Loop: Header=BB118_4 Depth=1
	ldr	x15, [x14, #16]
	ldr	x16, [x13, #16]
	cmp	x15, x16
	b.lo	LBB118_26
; %bb.14:                               ; %bb15.i
                                        ;   in Loop: Header=BB118_4 Depth=1
	b.hi	LBB118_16
; %bb.15:                               ; %bb18.i
                                        ;   in Loop: Header=BB118_4 Depth=1
	ldr	x15, [x14, #24]
	ldr	x16, [x13, #24]
	cmp	x15, x16
	b.ls	LBB118_26
LBB118_16:                              ; %bb8
                                        ;   in Loop: Header=BB118_4 Depth=1
	ldp	q1, q0, [x14]
	ldp	q3, q2, [x13]
	stp	q3, q2, [x14]
	stp	q1, q0, [x13]
	ldr	x14, [x14, #8]
	cmp	x14, #7
	b.hi	LBB118_18
; %bb.17:                               ; %bb2.i5
                                        ;   in Loop: Header=BB118_4 Depth=1
	str	x1, [x4, x14, lsl #3]
	ldr	x15, [x11, x14, lsl #3]
	add	x15, x15, #1
	str	x15, [x11, x14, lsl #3]
	b	LBB118_19
LBB118_18:                              ; %bb3.i4
                                        ;   in Loop: Header=BB118_4 Depth=1
	ldr	x14, [x4, #128]
	add	x14, x14, #1
	str	x14, [x4, #128]
LBB118_19:                              ; %wf_indexed_placed.exit
                                        ;   in Loop: Header=BB118_4 Depth=1
	ldr	x13, [x13, #8]
	cmp	x13, #7
	b.hi	LBB118_2
; %bb.20:                               ; %bb2.i14
                                        ;   in Loop: Header=BB118_4 Depth=1
	str	x12, [x4, x13, lsl #3]
	ldr	x14, [x11, x13, lsl #3]
	add	x14, x14, #1
	str	x14, [x11, x13, lsl #3]
	b	LBB118_3
LBB118_21:                              ; %bb6.i.i
                                        ;   in Loop: Header=BB118_4 Depth=1
	ldr	x12, [x15, #8]
	ldr	x17, [x16, #8]
	cmp	x12, x17
	b.lo	LBB118_6
; %bb.22:                               ; %bb9.i.i
                                        ;   in Loop: Header=BB118_4 Depth=1
	b.hi	LBB118_8
; %bb.23:                               ; %bb12.i.i
                                        ;   in Loop: Header=BB118_4 Depth=1
	ldr	x17, [x15, #16]
	ldr	x0, [x16, #16]
	mov	x12, x14
	cmp	x17, x0
	b.lo	LBB118_9
; %bb.24:                               ; %bb15.i.i
                                        ;   in Loop: Header=BB118_4 Depth=1
	mov	x12, x13
	b.hi	LBB118_9
; %bb.25:                               ; %bb18.i.i
                                        ;   in Loop: Header=BB118_4 Depth=1
	ldr	x12, [x15, #24]
	ldr	x15, [x16, #24]
	cmp	x12, x15
	csel	x12, x14, x13, lo
	b	LBB118_9
LBB118_26:
	add	sp, sp, #32
LBB118_27:                              ; %common.ret
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$4dbd7ca4639a1dfc ; -- Begin function wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$4dbd7ca4639a1dfc
	.p2align	2
_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$4dbd7ca4639a1dfc: ; @"wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$4dbd7ca4639a1dfc"
; %bb.0:                                ; %entry
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	cbz	x1, LBB119_2
; %bb.1:                                ; %bb2
	lsl	x9, x1, #4
	ldr	x8, [x0, #16]
	sub	x9, x9, #16
	and	x9, x9, #0xffffffffffffffe0
	add	x9, x8, x9
	add	x10, x8, x1, lsl #5
	ldr	x11, [x9]
	ldr	x12, [x10]
	cmp	x11, x12
	b.hs	LBB119_4
LBB119_2:                               ; %bb1
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$4dbd7ca4639a1dfc
LBB119_3:                               ; %common.ret
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB119_4:                               ; %bb3.i
	b.ls	LBB119_20
LBB119_5:                               ; %bb5
	add	x9, x4, #64
	b	LBB119_8
LBB119_6:                               ; %bb3.i7.i
                                        ;   in Loop: Header=BB119_8 Depth=1
	ldr	x12, [x4, #128]
	add	x12, x12, #1
	str	x12, [x4, #128]
LBB119_7:                               ; %wf_indexed_placed.exit17.i
                                        ;   in Loop: Header=BB119_8 Depth=1
	mov	x1, x11
	cmp	x10, #2
	b.lo	LBB119_3
LBB119_8:                               ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	sub	x10, x1, #1
	lsr	x11, x10, #1
	add	x13, x8, x11, lsl #5
	add	x12, x8, x1, lsl #5
	ldr	x14, [x13]
	ldr	x15, [x12]
	cmp	x14, x15
	b.lo	LBB119_3
; %bb.9:                                ; %bb3.i.i
                                        ;   in Loop: Header=BB119_8 Depth=1
	b.hi	LBB119_15
; %bb.10:                               ; %bb6.i.i
                                        ;   in Loop: Header=BB119_8 Depth=1
	ldr	x14, [x13, #8]
	ldr	x15, [x12, #8]
	cmp	x14, x15
	b.lo	LBB119_3
; %bb.11:                               ; %bb9.i.i
                                        ;   in Loop: Header=BB119_8 Depth=1
	b.hi	LBB119_15
; %bb.12:                               ; %bb12.i.i
                                        ;   in Loop: Header=BB119_8 Depth=1
	ldr	x14, [x13, #16]
	ldr	x15, [x12, #16]
	cmp	x14, x15
	b.lo	LBB119_3
; %bb.13:                               ; %bb15.i.i
                                        ;   in Loop: Header=BB119_8 Depth=1
	b.hi	LBB119_15
; %bb.14:                               ; %bb18.i.i
                                        ;   in Loop: Header=BB119_8 Depth=1
	ldr	x14, [x13, #24]
	ldr	x15, [x12, #24]
	cmp	x14, x15
	b.ls	LBB119_3
LBB119_15:                              ; %bb8.i
                                        ;   in Loop: Header=BB119_8 Depth=1
	ldp	q1, q0, [x13]
	ldp	q3, q2, [x12]
	stp	q3, q2, [x13]
	stp	q1, q0, [x12]
	ldr	x13, [x13, #8]
	cmp	x13, #7
	b.hi	LBB119_17
; %bb.16:                               ; %bb2.i.i
                                        ;   in Loop: Header=BB119_8 Depth=1
	str	x11, [x4, x13, lsl #3]
	ldr	x14, [x9, x13, lsl #3]
	add	x14, x14, #1
	str	x14, [x9, x13, lsl #3]
	b	LBB119_18
LBB119_17:                              ; %bb3.i3.i
                                        ;   in Loop: Header=BB119_8 Depth=1
	ldr	x13, [x4, #128]
	add	x13, x13, #1
	str	x13, [x4, #128]
LBB119_18:                              ; %wf_indexed_placed.exit.i
                                        ;   in Loop: Header=BB119_8 Depth=1
	ldr	x12, [x12, #8]
	cmp	x12, #7
	b.hi	LBB119_6
; %bb.19:                               ; %bb2.i11.i
                                        ;   in Loop: Header=BB119_8 Depth=1
	str	x1, [x4, x12, lsl #3]
	ldr	x13, [x9, x12, lsl #3]
	add	x13, x13, #1
	str	x13, [x9, x12, lsl #3]
	b	LBB119_7
LBB119_20:                              ; %bb6.i
	ldr	x11, [x9, #8]
	ldr	x12, [x10, #8]
	cmp	x11, x12
	b.lo	LBB119_2
; %bb.21:                               ; %bb9.i
	b.hi	LBB119_5
; %bb.22:                               ; %bb12.i
	ldr	x11, [x9, #16]
	ldr	x12, [x10, #16]
	cmp	x11, x12
	b.lo	LBB119_2
; %bb.23:                               ; %bb15.i
	b.hi	LBB119_5
; %bb.24:                               ; %bb18.i
	ldr	x9, [x9, #24]
	ldr	x10, [x10, #24]
	cmp	x9, x10
	b.ls	LBB119_2
	b	LBB119_5
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$69744d0f61ea6fbe ; -- Begin function wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$69744d0f61ea6fbe
	.p2align	2
_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$69744d0f61ea6fbe: ; @"wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$69744d0f61ea6fbe"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	cbz	x1, LBB120_9
; %bb.1:                                ; %bb2
	ldr	x8, [x0, #16]
	ldr	x11, [x4, #40]
	add	x9, x4, x11, lsl #3
	add	x9, x9, #8
	b	LBB120_4
LBB120_2:                               ; %bb2.i10.i
                                        ;   in Loop: Header=BB120_4 Depth=1
	ldr	x13, [x13, #8]
	add	x13, x1, x13, lsl #4
	str	x13, [x9]
LBB120_3:                               ; %wf_indexed_rise_placed.exit16.i
                                        ;   in Loop: Header=BB120_4 Depth=1
	add	x11, x11, #1
	str	x11, [x4, #40]
	add	x9, x9, #16
	mov	x1, x12
	cmp	x10, #2
	b.lo	LBB120_10
LBB120_4:                               ; %bb5.i8
                                        ; =>This Inner Loop Header: Depth=1
	sub	x10, x1, #1
	lsr	x12, x10, #1
	add	x14, x8, x12, lsl #5
	add	x13, x8, x1, lsl #5
	ldp	q1, q0, [x14]
	ldp	q3, q2, [x13]
	stp	q3, q2, [x14]
	stp	q1, q0, [x13]
	cmp	x11, #4
	b.hi	LBB120_6
; %bb.5:                                ; %bb2.i.i18
                                        ;   in Loop: Header=BB120_4 Depth=1
	ldr	x14, [x14, #8]
	add	x14, x12, x14, lsl #4
	stur	x14, [x9, #-8]
	b	LBB120_7
LBB120_6:                               ; %bb3.i.i13
                                        ;   in Loop: Header=BB120_4 Depth=1
	ldr	x14, [x4, #48]
	add	x14, x14, #1
	str	x14, [x4, #48]
LBB120_7:                               ; %wf_indexed_rise_placed.exit.i16
                                        ;   in Loop: Header=BB120_4 Depth=1
	add	x11, x11, #1
	cmp	x11, #4
	b.ls	LBB120_2
; %bb.8:                                ; %bb3.i5.i
                                        ;   in Loop: Header=BB120_4 Depth=1
	ldr	x13, [x4, #48]
	add	x13, x13, #1
	str	x13, [x4, #48]
	b	LBB120_3
LBB120_9:                               ; %bb1
	cmp	x2, #2
	b.hs	LBB120_11
LBB120_10:                              ; %common.ret
	mov	w0, #0                          ; =0x0
	add	sp, sp, #64
	ret
LBB120_11:                              ; %bb5.lr.ph.i
	mov	x13, #0                         ; =0x0
	lsr	x8, x2, #1
	ldr	x9, [x0, #16]
	mov	w10, #1                         ; =0x1
	b	LBB120_14
LBB120_12:                              ; %bb3.i6.i
                                        ;   in Loop: Header=BB120_14 Depth=1
	ldr	x13, [x4, #48]
	add	x13, x13, #1
	str	x13, [x4, #48]
LBB120_13:                              ; %wf_indexed_rise_placed.exit17.i
                                        ;   in Loop: Header=BB120_14 Depth=1
	add	x12, x12, #2
	str	x12, [x4, #40]
	mov	x13, x11
	cmp	x11, x8
	b.hs	LBB120_10
LBB120_14:                              ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	orr	x11, x10, x13, lsl #1
	add	x15, x9, x13, lsl #5
	add	x14, x9, x11, lsl #5
	ldp	q1, q0, [x15]
	ldp	q3, q2, [x14]
	stp	q3, q2, [x15]
	stp	q1, q0, [x14]
	ldr	x12, [x4, #40]
	cmp	x12, #4
	b.hi	LBB120_16
; %bb.15:                               ; %bb2.i2.i
                                        ;   in Loop: Header=BB120_14 Depth=1
	ldr	x15, [x15, #8]
	add	x13, x13, x15, lsl #4
	str	x13, [x4, x12, lsl #3]
	b	LBB120_17
LBB120_16:                              ; %bb3.i.i
                                        ;   in Loop: Header=BB120_14 Depth=1
	ldr	x13, [x4, #48]
	add	x13, x13, #1
	str	x13, [x4, #48]
LBB120_17:                              ; %wf_indexed_rise_placed.exit.i
                                        ;   in Loop: Header=BB120_14 Depth=1
	add	x13, x12, #1
	cmp	x13, #4
	b.hi	LBB120_12
; %bb.18:                               ; %bb2.i11.i
                                        ;   in Loop: Header=BB120_14 Depth=1
	ldr	x14, [x14, #8]
	add	x14, x11, x14, lsl #4
	str	x14, [x4, x13, lsl #3]
	b	LBB120_13
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$b789e18464d776a7 ; -- Begin function wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$b789e18464d776a7
	.p2align	2
_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$b789e18464d776a7: ; @"wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$b789e18464d776a7"
; %bb.0:                                ; %entry
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	cbz	x1, LBB121_2
; %bb.1:                                ; %bb2
	lsl	x9, x1, #4
	ldr	x8, [x0, #16]
	sub	x9, x9, #16
	and	x9, x9, #0xffffffffffffffe0
	add	x9, x8, x9
	add	x10, x8, x1, lsl #5
	ldr	x11, [x9]
	ldr	x12, [x10]
	cmp	x11, x12
	b.hs	LBB121_4
LBB121_2:                               ; %bb1
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$b789e18464d776a7
LBB121_3:                               ; %common.ret
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB121_4:                               ; %bb3.i
	b.hi	LBB121_12
; %bb.5:                                ; %bb6.i
	ldr	x11, [x9, #8]
	ldr	x12, [x10, #8]
	cmp	x11, x12
	b.lo	LBB121_2
; %bb.6:                                ; %bb9.i
	b.hi	LBB121_12
; %bb.7:                                ; %bb12.i
	ldr	x11, [x9, #16]
	ldr	x12, [x10, #16]
	cmp	x11, x12
	b.lo	LBB121_2
; %bb.8:                                ; %bb15.i
	b.hi	LBB121_12
; %bb.9:                                ; %bb18.i
	ldr	x9, [x9, #24]
	ldr	x10, [x10, #24]
	cmp	x9, x10
	b.hi	LBB121_12
	b	LBB121_2
LBB121_10:                              ; %bb3.i7.i
                                        ;   in Loop: Header=BB121_12 Depth=1
	ldr	x11, [x4, #48]
	add	x11, x11, #1
	str	x11, [x4, #48]
LBB121_11:                              ; %wf_indexed_rise_placed.exit18.i
                                        ;   in Loop: Header=BB121_12 Depth=1
	add	x11, x13, #2
	str	x11, [x4, #40]
	mov	x1, x10
	cmp	x9, #2
	b.lo	LBB121_3
LBB121_12:                              ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	sub	x9, x1, #1
	lsr	x10, x9, #1
	add	x12, x8, x10, lsl #5
	add	x11, x8, x1, lsl #5
	ldr	x13, [x12]
	ldr	x14, [x11]
	cmp	x13, x14
	b.lo	LBB121_3
; %bb.13:                               ; %bb3.i.i
                                        ;   in Loop: Header=BB121_12 Depth=1
	b.hi	LBB121_19
; %bb.14:                               ; %bb6.i.i
                                        ;   in Loop: Header=BB121_12 Depth=1
	ldr	x13, [x12, #8]
	ldr	x14, [x11, #8]
	cmp	x13, x14
	b.lo	LBB121_3
; %bb.15:                               ; %bb9.i.i
                                        ;   in Loop: Header=BB121_12 Depth=1
	b.hi	LBB121_19
; %bb.16:                               ; %bb12.i.i
                                        ;   in Loop: Header=BB121_12 Depth=1
	ldr	x13, [x12, #16]
	ldr	x14, [x11, #16]
	cmp	x13, x14
	b.lo	LBB121_3
; %bb.17:                               ; %bb15.i.i
                                        ;   in Loop: Header=BB121_12 Depth=1
	b.hi	LBB121_19
; %bb.18:                               ; %bb18.i.i
                                        ;   in Loop: Header=BB121_12 Depth=1
	ldr	x13, [x12, #24]
	ldr	x14, [x11, #24]
	cmp	x13, x14
	b.ls	LBB121_3
LBB121_19:                              ; %bb8.i
                                        ;   in Loop: Header=BB121_12 Depth=1
	ldp	q1, q0, [x12]
	ldp	q3, q2, [x11]
	stp	q3, q2, [x12]
	stp	q1, q0, [x11]
	ldr	x13, [x4, #40]
	cmp	x13, #4
	b.hi	LBB121_21
; %bb.20:                               ; %bb2.i.i
                                        ;   in Loop: Header=BB121_12 Depth=1
	ldr	x12, [x12, #8]
	add	x12, x10, x12, lsl #4
	str	x12, [x4, x13, lsl #3]
	b	LBB121_22
LBB121_21:                              ; %bb3.i3.i
                                        ;   in Loop: Header=BB121_12 Depth=1
	ldr	x12, [x4, #48]
	add	x12, x12, #1
	str	x12, [x4, #48]
LBB121_22:                              ; %wf_indexed_rise_placed.exit.i
                                        ;   in Loop: Header=BB121_12 Depth=1
	add	x12, x13, #1
	cmp	x12, #4
	b.hi	LBB121_10
; %bb.23:                               ; %bb2.i12.i
                                        ;   in Loop: Header=BB121_12 Depth=1
	ldr	x11, [x11, #8]
	add	x11, x1, x11, lsl #4
	str	x11, [x4, x12, lsl #3]
	b	LBB121_11
                                        ; -- End function
	.globl	_wf_box_slots_new$instance$a165a2c3db63b7e9 ; -- Begin function wf_box_slots_new$instance$a165a2c3db63b7e9
	.p2align	2
_wf_box_slots_new$instance$a165a2c3db63b7e9: ; @"wf_box_slots_new$instance$a165a2c3db63b7e9"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	cbz	x0, LBB122_3
; %bb.1:                                ; %window.payload.allocate.v1.i
	mov	w8, #88                         ; =0x58
	mul	x0, x19, x8
	bl	_malloc
	mov	x2, x0
	cbnz	x0, LBB122_4
; %bb.2:                                ; %window.block.oom.v1.i
	bl	l_wf_resource_abort
LBB122_3:
Lloh316:
	adrp	x2, l_.wf.empty.slots.payload@PAGE
Lloh317:
	add	x2, x2, l_.wf.empty.slots.payload@PAGEOFF
LBB122_4:                               ; %"wf_box_slots_new$instance$a165a2c3db63b7e9.body.exit"
	mov	x0, #0                          ; =0x0
	mov	x1, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh316, Lloh317
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_slots_new$instance$9a7616e2f99ec8b9 ; -- Begin function wf_slots_new$instance$9a7616e2f99ec8b9
	.p2align	2
_wf_slots_new$instance$9a7616e2f99ec8b9: ; @"wf_slots_new$instance$9a7616e2f99ec8b9"
; %bb.0:                                ; %entry
	str	xzr, [x0, #64]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0, #32]
	stp	q0, q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_record_store_new$instance$3ad8b32886f5e3ce ; -- Begin function wf_record_store_new$instance$3ad8b32886f5e3ce
	.p2align	2
_wf_record_store_new$instance$3ad8b32886f5e3ce: ; @"wf_record_store_new$instance$3ad8b32886f5e3ce"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #208
	stp	x26, x25, [sp, #128]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #144]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #160]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #176]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 208
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x6
	mov	x22, x5
	mov	x24, x4
	mov	x25, x3
	mov	x21, x2
	mov	x23, x1
	mov	x20, x0
	cbz	x3, LBB124_2
; %bb.1:                                ; %window.payload.allocate.v1.i.i.i
	lsl	x8, x25, #6
	sub	x0, x8, x25, lsl #3
	bl	_malloc
	cbnz	x0, LBB124_3
	b	LBB124_10
LBB124_2:
Lloh318:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh319:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB124_3:                               ; %"wf_std.collections.slab.slab_new$instance$c07b06bae9914d5e.exit"
	stp	xzr, x25, [sp]
	stp	x0, x25, [sp, #16]
	cbz	x24, LBB124_7
; %bb.4:                                ; %window.payload.allocate.v1.i.i.i2
	lsl	x0, x24, #5
	bl	_malloc
	cbz	x0, LBB124_10
; %bb.5:                                ; %bb5.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #8
LBB124_6:                               ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x9, #8]
	str	xzr, [x9], #32
	cmp	x24, x8
	b.ne	LBB124_6
	b	LBB124_8
LBB124_7:
Lloh320:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh321:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB124_8:                               ; %"wf_std.collections.hash_map.hash_map_new$instance$615fa5221ee98b49.exit"
	stp	x24, x24, [sp, #32]
	stp	xzr, xzr, [sp, #56]
	str	x0, [sp, #48]
	cbz	x22, LBB124_11
; %bb.9:                                ; %window.payload.allocate.v1.i.i
	lsl	x0, x22, #5
	bl	_malloc
	cbnz	x0, LBB124_12
LBB124_10:                              ; %window.block.oom.v1.i.i.i
	bl	l_wf_resource_abort
LBB124_11:
Lloh322:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh323:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB124_12:                              ; %"wf_box_slots_new$instance$57d99a800120d980.exit"
	mov	x8, sp
	stp	xzr, x22, [sp, #72]
	stp	x0, xzr, [sp, #88]
	stp	x22, x0, [sp, #104]
	stp	x23, xzr, [x20]
	and	w9, w21, #0x1
	strb	w9, [x20, #8]
	ldp	q0, q1, [sp]
	stp	q0, q1, [x20, #16]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x20, #48]
	ldur	x8, [x8, #64]
	str	x8, [x20, #80]
	ldr	q0, [sp, #96]
	stur	q0, [x20, #88]
	stp	x0, x19, [x20, #104]
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #176]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #160]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #144]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
	.loh AdrpAdd	Lloh318, Lloh319
	.loh AdrpAdd	Lloh320, Lloh321
	.loh AdrpAdd	Lloh322, Lloh323
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_indexed_accept$instance$34505fe33827dcb3
lCPI125_0:
	.quad	8                               ; 0x8
	.quad	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_indexed_accept$instance$34505fe33827dcb3
	.p2align	2
_wf_indexed_accept$instance$34505fe33827dcb3: ; @"wf_indexed_accept$instance$34505fe33827dcb3"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	str	x4, [x2, x5, lsl #3]
	strb	wzr, [sp, #32]
	ldr	x8, [x0, #40]
	ldr	x10, [x0, #16]
	cmp	x8, x10
	b.hs	LBB125_4
; %bb.1:                                ; %bb2.i.i
	ldr	x9, [x0, #32]
	mov	w10, #56                        ; =0x38
	madd	x10, x8, x10, x9
	ldr	x9, [x10]
	cbnz	x9, LBB125_7
; %bb.2:                                ; %bb5.i.i
	ldr	x9, [x10, #40]
	cmp	x9, #2
	b.hi	LBB125_7
; %bb.3:                                ; %bb8.i.i
	ldr	x11, [x10, #48]
	stp	x4, x6, [x10, #8]
	strb	wzr, [x10, #24]
	mov	w12, #8                         ; =0x8
	str	x12, [x10, #32]
	mov	w12, #1                         ; =0x1
	str	x12, [x10]
	str	x11, [x0, #40]
	b	LBB125_6
LBB125_4:                               ; %bb3.i.i
	ldr	x9, [x0, #24]
	cmp	x10, x9
	b.hs	LBB125_7
; %bb.5:                                ; %bb11.i.i
	mov	x9, #0                          ; =0x0
	ldr	x11, [x0, #32]
	mov	w12, #56                        ; =0x38
	madd	x11, x10, x12, x11
	mov	w12, #1                         ; =0x1
	stp	x12, x4, [x11]
	str	x6, [x11, #16]
	strb	wzr, [x11, #24]
Lloh324:
	adrp	x12, lCPI125_0@PAGE
Lloh325:
	ldr	q0, [x12, lCPI125_0@PAGEOFF]
	str	q0, [x11, #32]
	str	x8, [x11, #48]
	add	x8, x10, #1
	str	x8, [x0, #16]
	mov	x8, x10
LBB125_6:                               ; %bb2
	ldr	x10, [x0]
	mov	w11, #1                         ; =0x1
	strb	w11, [sp, #24]
	strb	wzr, [sp, #16]
	strb	wzr, [sp, #15]
	add	x12, x1, x3, lsl #6
	strb	w11, [x12]
	stp	x4, x5, [x12, #8]
	strh	wzr, [x12, #24]
	stp	xzr, x10, [x12, #32]
	stp	x8, x9, [x12, #48]
	b	LBB125_20
LBB125_7:                               ; %bb3
	ldr	x9, [x2, #1304]
	add	x8, x9, #1
	str	x8, [x2, #1304]
	strb	wzr, [sp, #40]
	ldp	x8, x10, [x6]
	add	x11, x8, #101
	cmp	x10, x11
	csinv	x8, x8, xzr, eq
	cmp	x8, #64
	b.hs	LBB125_11
; %bb.8:                                ; %bb2.i.i13
	ldr	x10, [x2, x8, lsl #3]
	cmp	x10, x4
	b.eq	LBB125_10
; %bb.9:                                ; %bb5.i.i14
	add	x9, x9, #2
	str	x9, [x2, #1304]
LBB125_10:                              ; %bb4.i.i
	add	x9, x2, x8, lsl #3
	ldr	x10, [x9, #512]
	add	x10, x10, #1
	str	x10, [x9, #512]
	ldrb	w9, [x2, #1296]
	tbnz	w9, #0, LBB125_12
	b	LBB125_19
LBB125_11:                              ; %bb3.i.i8
	add	x9, x9, #2
	str	x9, [x2, #1304]
	ldrb	w9, [x2, #1296]
	tbz	w9, #0, LBB125_19
LBB125_12:                              ; %bb8.i.i10
	mov	w9, #1                          ; =0x1
	cbnz	w9, LBB125_14
; %bb.13:                               ; %bb11.i.i12
	ldr	x9, [x2, #1304]
	add	x9, x9, #1
	str	x9, [x2, #1304]
LBB125_14:                              ; %bb13.i.i
	ldr	x9, [x2, #1288]
	cmp	x9, #31
	b.hi	LBB125_17
; %bb.15:                               ; %bb13.i.i
	ldr	x10, [x2, #1280]
	cmp	x9, x10
	b.hs	LBB125_17
; %bb.16:                               ; %bb20.i.i
	add	x10, x2, x9, lsl #3
	ldr	x10, [x10, #1024]
	cmp	x10, x8
	b.eq	LBB125_18
LBB125_17:                              ; %bb16.sink.split.i.i
	ldr	x8, [x2, #1304]
	add	x8, x8, #1
	str	x8, [x2, #1304]
LBB125_18:                              ; %bb16.i.i
	add	x8, x9, #1
	str	x8, [x2, #1288]
LBB125_19:                              ; %"wf_indexed_release_payload$instance$cfa19887953541da.exit"
	mov	x0, x6
	bl	_free
LBB125_20:                              ; %bb1
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.loh AdrpLdr	Lloh324, Lloh325
                                        ; -- End function
	.globl	_wf_indexed_attach$instance$4a70da04567deb49 ; -- Begin function wf_indexed_attach$instance$4a70da04567deb49
	.p2align	2
_wf_indexed_attach$instance$4a70da04567deb49: ; @"wf_indexed_attach$instance$4a70da04567deb49"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #80
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 80
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x2
	mov	x19, x1
	add	x21, x1, x3, lsl #6
	ldr	x22, [x21, #8]
	ldur	q0, [x21, #40]
	str	q0, [sp]
	ldr	x8, [x21, #56]
	str	x8, [sp, #16]
	mov	x1, sp
	bl	_wf_record_store_attach$instance$3ad8b32886f5e3ce
	cbz	w0, LBB126_2
; %bb.1:                                ; %bb13.i
	ldr	x8, [x20, #1304]
	add	x8, x8, #1
	str	x8, [x20, #1304]
LBB126_2:                               ; %bb2.preheader
	add	x8, x19, #24
	mov	w9, #32                         ; =0x20
	b	LBB126_4
LBB126_3:                               ; %bb8
                                        ;   in Loop: Header=BB126_4 Depth=1
	add	x8, x8, #64
	subs	x9, x9, #1
	b.eq	LBB126_6
LBB126_4:                               ; %bb2
                                        ; =>This Inner Loop Header: Depth=1
	ldur	x10, [x8, #-16]
	cmp	x10, x22
	b.ne	LBB126_3
; %bb.5:                                ; %bb6
                                        ;   in Loop: Header=BB126_4 Depth=1
	strb	wzr, [x8]
	b	LBB126_3
LBB126_6:                               ; %bb4
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #24]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_indexed_schedule$instance$4a70da04567deb49 ; -- Begin function wf_indexed_schedule$instance$4a70da04567deb49
	.p2align	2
_wf_indexed_schedule$instance$4a70da04567deb49: ; @"wf_indexed_schedule$instance$4a70da04567deb49"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #80
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 80
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x4
	mov	x20, x2
	add	x21, x1, x3, lsl #6
	ldur	q0, [x21, #40]
	str	q0, [sp]
	ldr	x8, [x21, #56]
	str	x8, [sp, #16]
	mov	x1, sp
	mov	x2, x4
	bl	_wf_record_store_schedule$instance$3ad8b32886f5e3ce
	cbz	w0, LBB127_2
; %bb.1:                                ; %bb13.i
	ldr	x8, [x20, #1304]
	add	x8, x8, #1
	str	x8, [x20, #1304]
LBB127_2:                               ; %wf_indexed_status.exit
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #25]
	str	x19, [x21, #32]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_indexed_check$instance$34505fe33827dcb3 ; -- Begin function wf_indexed_check$instance$34505fe33827dcb3
	.p2align	2
_wf_indexed_check$instance$34505fe33827dcb3: ; @"wf_indexed_check$instance$34505fe33827dcb3"
; %bb.0:                                ; %entry
	sub	sp, sp, #32
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	mov	x8, #0                          ; =0x0
	ldr	x9, [x0]
	ldr	x10, [x0, #112]
	ldr	x13, [x2, #1304]
	add	x11, x1, #24
	mov	w12, #56                        ; =0x38
	b	LBB128_4
LBB128_1:                               ; %bb13.i146
                                        ;   in Loop: Header=BB128_4 Depth=1
	add	x13, x13, #1
LBB128_2:                               ; %bb79.sink.split
                                        ;   in Loop: Header=BB128_4 Depth=1
	str	x13, [x2, #1304]
LBB128_3:                               ; %bb79
                                        ;   in Loop: Header=BB128_4 Depth=1
	add	x8, x8, #1
	cmp	x8, #32
	b.eq	LBB128_54
LBB128_4:                               ; %bb2
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB128_18 Depth 2
                                        ;     Child Loop BB128_24 Depth 2
	add	x16, x1, x8, lsl #6
	ldr	x4, [x16, #16]
	cbz	x4, LBB128_3
; %bb.5:                                ; %bb6
                                        ;   in Loop: Header=BB128_4 Depth=1
	ldr	x14, [x16, #8]
	ldr	x15, [x16, #40]
	cmp	x15, x9
	b.ne	LBB128_15
; %bb.6:                                ; %bb3.i
                                        ;   in Loop: Header=BB128_4 Depth=1
	ldrb	w6, [x16]
	ldr	x15, [x16, #48]
	ldr	x17, [x0, #16]
	cmp	x15, x17
	b.hs	LBB128_14
; %bb.7:                                ; %bb2.i.i
                                        ;   in Loop: Header=BB128_4 Depth=1
	ldr	x17, [x16, #56]
	ldr	x3, [x0, #32]
	madd	x5, x15, x12, x3
	ldr	x3, [x5, #40]
	cmp	x3, x17
	b.ne	LBB128_14
; %bb.8:                                ; %bb5.i.i
                                        ;   in Loop: Header=BB128_4 Depth=1
	ldr	x3, [x5]
	cbz	x3, LBB128_14
; %bb.9:                                ; %bb9
                                        ;   in Loop: Header=BB128_4 Depth=1
	ldrb	w7, [x16, #24]
	ldrb	w16, [x16, #25]
	ldr	x3, [x5, #8]
	ldrb	w19, [x5, #24]
	and	w19, w19, #0x1
	strb	w19, [sp, #8]
	tbz	w6, #0, LBB128_15
; %bb.10:                               ; %bb12
                                        ;   in Loop: Header=BB128_4 Depth=1
	cmp	x3, x14
	b.eq	LBB128_12
; %bb.11:                               ; %bb15
                                        ;   in Loop: Header=BB128_4 Depth=1
	add	x13, x13, #1
	str	x13, [x2, #1304]
LBB128_12:                              ; %bb14
                                        ;   in Loop: Header=BB128_4 Depth=1
	tbz	w19, #0, LBB128_42
; %bb.13:                               ; %bb18
                                        ;   in Loop: Header=BB128_4 Depth=1
	tbz	w7, #0, LBB128_43
	b	LBB128_44
LBB128_14:                              ; %bb10
                                        ;   in Loop: Header=BB128_4 Depth=1
	tbz	w6, #0, LBB128_16
LBB128_15:                              ; %bb8.sink.split
                                        ;   in Loop: Header=BB128_4 Depth=1
	add	x13, x13, #1
	str	x13, [x2, #1304]
LBB128_16:                              ; %bb8
                                        ;   in Loop: Header=BB128_4 Depth=1
	mov	x16, #0                         ; =0x0
	mov	x17, x11
	mov	w15, #32                        ; =0x20
	b	LBB128_18
LBB128_17:                              ; %bb54
                                        ;   in Loop: Header=BB128_18 Depth=2
	add	x16, x16, #1
	add	x17, x17, #64
	cmp	x16, #32
	b.eq	LBB128_20
LBB128_18:                              ; %bb45
                                        ;   Parent Loop BB128_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	x3, [x17, #-16]
	cmp	x3, x14
	b.ne	LBB128_17
; %bb.19:                               ; %bb49
                                        ;   in Loop: Header=BB128_18 Depth=2
	ldrb	w3, [x17]
	cmp	w3, #0
	csel	x15, x16, x15, ne
	b	LBB128_17
LBB128_20:                              ; %bb47
                                        ;   in Loop: Header=BB128_4 Depth=1
	cbz	x10, LBB128_37
; %bb.21:                               ; %bb3.i.i.i91
                                        ;   in Loop: Header=BB128_4 Depth=1
	udiv	x16, x14, x10
	msub	x17, x16, x10, x14
	ldr	x16, [x0, #48]
	cbz	x16, LBB128_38
LBB128_22:                              ; %bb3.i.i92
                                        ;   in Loop: Header=BB128_4 Depth=1
	udiv	x3, x17, x16
	msub	x17, x3, x16, x17
	ldr	x3, [x0, #64]
	mov	x4, x16
	b	LBB128_24
LBB128_23:                              ; %bb8.i.i97
                                        ;   in Loop: Header=BB128_24 Depth=2
	add	x5, x17, #1
	cmp	x5, x16
	csinc	x17, xzr, x17, hs
	subs	x4, x4, #1
	b.eq	LBB128_36
LBB128_24:                              ; %bb5.i.i95
                                        ;   Parent Loop BB128_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x5, x3, x17, lsl #5
	ldr	w6, [x5]
	cmp	w6, #1
	b.eq	LBB128_23
; %bb.25:                               ; %bb5.i.i95
                                        ;   in Loop: Header=BB128_24 Depth=2
	cmp	w6, #2
	b.ne	LBB128_36
; %bb.26:                               ; %bb9.i.i
                                        ;   in Loop: Header=BB128_24 Depth=2
	ldr	x6, [x5, #8]
	cmp	x6, x14
	b.ne	LBB128_23
; %bb.27:                               ; %bb3.i120.i
                                        ;   in Loop: Header=BB128_4 Depth=1
	ldr	x16, [x5, #16]
	ldr	x17, [x0, #16]
	cmp	x16, x17
	b.hs	LBB128_39
; %bb.28:                               ; %bb2.i.i.i
                                        ;   in Loop: Header=BB128_4 Depth=1
	ldr	x17, [x5, #24]
	ldr	x3, [x0, #32]
	madd	x3, x16, x12, x3
	ldr	x4, [x3, #40]
	cmp	x4, x17
	b.ne	LBB128_39
; %bb.29:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB128_4 Depth=1
	ldr	x4, [x3]
	cbz	x4, LBB128_39
; %bb.30:                               ; %bb3.i103
                                        ;   in Loop: Header=BB128_4 Depth=1
	ldr	x3, [x3, #8]
	cmp	x3, x14
	b.ne	LBB128_52
; %bb.31:                               ; %bb56
                                        ;   in Loop: Header=BB128_4 Depth=1
	cmp	x15, #32
	b.hs	LBB128_1
; %bb.32:                               ; %bb59
                                        ;   in Loop: Header=BB128_4 Depth=1
	add	x3, x1, x15, lsl #6
	ldp	x14, x15, [x3, #40]
	ldr	x4, [x3, #56]
	cmp	x15, x16
	cinc	x13, x13, ne
	cmp	x4, x17
	cinc	x13, x13, ne
	cmp	x14, x9
	cinc	x13, x13, ne
	ldrb	w3, [x3]
	eor	w3, w3, #0x1
	and	x5, x3, #0x1
	add	x13, x13, x5
	cmp	x4, x17
	b.ne	LBB128_2
; %bb.33:                               ; %bb59
                                        ;   in Loop: Header=BB128_4 Depth=1
	tbnz	w3, #0, LBB128_2
; %bb.34:                               ; %bb59
                                        ;   in Loop: Header=BB128_4 Depth=1
	cmp	x15, x16
	b.ne	LBB128_2
; %bb.35:                               ; %bb59
                                        ;   in Loop: Header=BB128_4 Depth=1
	cmp	x14, x9
	b.eq	LBB128_3
	b	LBB128_2
LBB128_36:                              ;   in Loop: Header=BB128_4 Depth=1
	mov	w14, #0                         ; =0x0
	mov	w16, #0                         ; =0x0
	cmp	x15, #32
	b.lo	LBB128_40
	b	LBB128_53
LBB128_37:                              ;   in Loop: Header=BB128_4 Depth=1
	mov	x17, #0                         ; =0x0
	ldr	x16, [x0, #48]
	cbnz	x16, LBB128_22
LBB128_38:                              ;   in Loop: Header=BB128_4 Depth=1
	mov	w14, #0                         ; =0x0
	cmp	x15, #32
	b.lo	LBB128_40
	b	LBB128_53
LBB128_39:                              ;   in Loop: Header=BB128_4 Depth=1
	mov	w14, #1                         ; =0x1
	mov	w16, #1                         ; =0x1
	cmp	x15, #32
	b.hs	LBB128_53
LBB128_40:                              ; %bb74
                                        ;   in Loop: Header=BB128_4 Depth=1
	lsl	x14, x15, #6
	ldrb	w14, [x1, x14]
	tbnz	w14, #0, LBB128_1
; %bb.41:                               ; %bb78
                                        ;   in Loop: Header=BB128_4 Depth=1
	tbz	w16, #0, LBB128_1
	b	LBB128_3
LBB128_42:                              ; %bb19
                                        ;   in Loop: Header=BB128_4 Depth=1
	tbz	w7, #0, LBB128_44
LBB128_43:                              ; %bb27.sink.split
                                        ;   in Loop: Header=BB128_4 Depth=1
	add	x13, x13, #1
	str	x13, [x2, #1304]
LBB128_44:                              ; %bb27
                                        ;   in Loop: Header=BB128_4 Depth=1
	ldr	x6, [x5, #16]
	ldp	x7, x6, [x6]
	add	x19, x7, #101
	cmp	x6, x19
	csinv	x6, x7, xzr, eq
	cmp	x6, x4
	b.eq	LBB128_46
; %bb.45:                               ; %bb30
                                        ;   in Loop: Header=BB128_4 Depth=1
	add	x13, x13, #1
	str	x13, [x2, #1304]
LBB128_46:                              ; %bb2.i.i52
                                        ;   in Loop: Header=BB128_4 Depth=1
	ldr	x4, [x5, #32]
	cmp	x4, #8
	b.ne	LBB128_48
; %bb.47:                               ; %bb34.thread
                                        ;   in Loop: Header=BB128_4 Depth=1
	tbnz	w16, #0, LBB128_15
	b	LBB128_16
LBB128_48:                              ; %bb6.i.i
                                        ;   in Loop: Header=BB128_4 Depth=1
	ldr	x5, [x0, #88]
	cmp	x4, x5
	b.hs	LBB128_15
; %bb.49:                               ; %bb8.i.i
                                        ;   in Loop: Header=BB128_4 Depth=1
	ldr	x5, [x0, #104]
	add	x4, x5, x4, lsl #5
	ldp	x5, x6, [x4, #16]
	cmp	x5, x15
	ccmp	x6, x17, #0, eq
	b.ne	LBB128_15
; %bb.50:                               ; %bb11.i.i
                                        ;   in Loop: Header=BB128_4 Depth=1
	ldr	x15, [x4, #8]
	cmp	x15, x3
	b.ne	LBB128_15
; %bb.51:                               ; %bb11.i.i
                                        ;   in Loop: Header=BB128_4 Depth=1
	tbnz	w16, #0, LBB128_16
	b	LBB128_15
LBB128_52:                              ;   in Loop: Header=BB128_4 Depth=1
	mov	w16, #0                         ; =0x0
	mov	w14, #1                         ; =0x1
	cmp	x15, #32
	b.lo	LBB128_40
LBB128_53:                              ; %bb75
                                        ;   in Loop: Header=BB128_4 Depth=1
	cbnz	w14, LBB128_1
	b	LBB128_3
LBB128_54:                              ; %bb4
	mov	w0, #0                          ; =0x0
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.globl	_wf_record_store_attach$instance$3ad8b32886f5e3ce ; -- Begin function wf_record_store_attach$instance$3ad8b32886f5e3ce
	.p2align	2
_wf_record_store_attach$instance$3ad8b32886f5e3ce: ; @"wf_record_store_attach$instance$3ad8b32886f5e3ce"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	sub	sp, sp, #448
	.cfi_def_cfa_offset 512
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	ldr	q0, [x1]
	str	q0, [sp]
	ldr	x8, [x1, #16]
	str	x8, [sp, #16]
	ldr	x9, [sp]
	ldr	x10, [x0]
	cmp	x9, x10
	b.ne	LBB129_6
; %bb.1:                                ; %bb3.i
	ldr	x11, [sp, #8]
	ldr	x10, [x0, #16]
	cmp	x11, x10
	b.hs	LBB129_32
; %bb.2:                                ; %bb2.i.i
	ldr	x9, [x0, #32]
	mov	w12, #56                        ; =0x38
	madd	x11, x11, x12, x9
	ldr	x12, [x11, #40]
	cmp	x12, x8
	b.ne	LBB129_32
; %bb.3:                                ; %bb5.i.i
	ldr	x8, [x11]
	cbz	x8, LBB129_32
; %bb.4:                                ; %bb2
	mov	x22, sp
	ldr	x8, [x11, #8]
	ldrb	w12, [x11, #24]
	ldr	x11, [x11, #32]
	and	w12, w12, #0x1
	strb	w12, [sp, #432]
	stp	xzr, x8, [sp, #24]
	strb	w12, [sp, #40]
	stur	wzr, [sp, #41]
	str	wzr, [sp, #44]
	ldr	q0, [sp, #32]
	str	q0, [sp, #80]
	str	x11, [sp, #96]
	ldr	x8, [sp, #80]
	ldrb	w12, [sp, #88]
	stp	x11, x8, [sp, #48]
	strb	w12, [sp, #64]
	str	x11, [sp, #72]
	str	x11, [x22, #416]
	ldur	q0, [sp, #56]
	str	q0, [x22, #400]
	ldrb	w8, [x22, #408]
	cmp	w8, #1
	b.ne	LBB129_7
LBB129_5:
	mov	w0, #1                          ; =0x1
	b	LBB129_33
LBB129_6:
	mov	w0, #4                          ; =0x4
	b	LBB129_33
LBB129_7:                               ; %bb6
	mov	x19, x0
	ldr	x8, [x19, #112]!
	sub	x20, x19, #64
	cbz	x8, LBB129_20
; %bb.8:                                ; %bb3.i.i
	ldr	x11, [sp, #400]
	udiv	x12, x11, x8
	msub	x12, x12, x8, x11
	ldr	x8, [x20]
	cbz	x8, LBB129_21
LBB129_9:                               ; %bb3.i12
	add	x11, x22, #184
	udiv	x13, x12, x8
	msub	x12, x13, x8, x12
	ldr	x13, [x0, #64]
	ldr	x21, [sp, #400]
	mov	x14, x8
	b	LBB129_11
LBB129_10:                              ; %bb8.i
                                        ;   in Loop: Header=BB129_11 Depth=1
	add	x15, x12, #1
	cmp	x15, x8
	csinc	x12, xzr, x12, hs
	subs	x14, x14, #1
	b.eq	LBB129_19
LBB129_11:                              ; %bb5.i13
                                        ; =>This Inner Loop Header: Depth=1
	add	x15, x13, x12, lsl #5
	ldr	w16, [x15]
	cmp	w16, #1
	b.eq	LBB129_10
; %bb.12:                               ; %bb5.i13
                                        ;   in Loop: Header=BB129_11 Depth=1
	cmp	w16, #2
	b.ne	LBB129_19
; %bb.13:                               ; %bb9.i
                                        ;   in Loop: Header=BB129_11 Depth=1
	ldr	x16, [x15, #8]
	cmp	x16, x21
	b.ne	LBB129_10
; %bb.14:                               ; %bb8
	str	xzr, [sp, #104]
	ldr	q0, [x15, #16]
	str	q0, [sp, #112]
	ldr	q0, [sp, #112]
	ldur	q1, [x1, #8]
	stp	q0, q1, [x22, #128]
	ldp	x12, x13, [sp, #128]
	ldr	x14, [sp, #144]
	cmp	x12, x14
	b.ne	LBB129_16
; %bb.15:                               ; %bb8
	ldr	x14, [sp, #152]
	cmp	x13, x14
	b.eq	LBB129_5
LBB129_16:                              ; %bb12
	cmp	x12, x10
	b.hs	LBB129_34
; %bb.17:                               ; %bb2.i.i21
	mov	w10, #56                        ; =0x38
	madd	x9, x12, x10, x9
	ldr	x10, [x9, #40]
	cmp	x10, x13
	b.ne	LBB129_34
; %bb.18:                               ; %"wf_std.collections.slab.slab_find_index$instance$c07b06bae9914d5e.exit"
	ldr	x9, [x9]
	cmp	x9, #0
	csel	x10, xzr, x12, eq
	cset	w12, eq
	str	w12, [sp, #160]
	str	x10, [sp, #168]
	strb	wzr, [sp, #176]
	cbnz	x9, LBB129_36
	b	LBB129_35
LBB129_19:                              ; %bb10.i
	stp	xzr, xzr, [x22, #104]
	stur	xzr, [x22, #120]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #104]
	b	LBB129_22
LBB129_20:
	mov	x12, #0                         ; =0x0
	ldr	x8, [x20]
	cbnz	x8, LBB129_9
LBB129_21:                              ; %bb2.i14
	stp	xzr, xzr, [x22, #104]
	stur	xzr, [x22, #120]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #104]
	ldr	x21, [sp, #400]
LBB129_22:                              ; %bb7
	ldur	q0, [x1, #8]
	str	q0, [x22, #304]
	ldur	q0, [x1, #8]
	str	q0, [sp, #432]
	ldp	x9, x10, [x0, #72]
	mov	x23, x0
	adds	x10, x9, x10
	csinv	x11, x10, xzr, lo
	cmp	x8, #7
	b.hi	LBB129_25
; %bb.23:                               ; %bb7
	sub	x10, x8, x8, lsr #2
	cmp	x11, x10
	b.lo	LBB129_25
; %bb.24:                               ; %bb2.i16
	mov	w11, #4                         ; =0x4
	cmp	x8, #4
	csel	x11, x8, x11, lo
	lsl	x11, x11, #1
	cmp	x8, #0
	csinc	x11, x11, xzr, ne
	cmp	x9, x10, lsr #1
	csel	x1, x8, x11, lo
	mov	x0, x20
	mov	x2, x19
	bl	_wf_std.collections.hash_map.hash_map_rebuild$instance$cb1167c8d0732e77
LBB129_25:                              ; %"wf_std.collections.hash_map.hash_map_put$instance$cb1167c8d0732e77.exit"
	add	x0, x22, #320
	add	x3, sp, #432
	mov	x1, x20
	mov	x2, x21
	mov	x4, x19
	bl	_wf_std.collections.hash_map.hash_map_try_put$instance$cb1167c8d0732e77
	ldr	w8, [sp, #320]
	cbz	w8, LBB129_28
; %bb.26:                               ; %bb21
	mov	x8, sp
	add	x8, x8, #328
	ldrb	w9, [x22, #324]
	ldr	x10, [sp, #344]
	str	x10, [x22, #368]
	ldr	q0, [x8]
	str	q0, [x22, #352]
	tbz	w9, #0, LBB129_28
; %bb.27:
	mov	w0, #6                          ; =0x6
	b	LBB129_33
LBB129_28:                              ; %bb19
	add	x8, x22, #376
	orr	x9, x22, #0x8
	mov	w10, #1                         ; =0x1
	strb	w10, [x22, #424]
	ldr	q0, [x9]
	str	q0, [x8]
	ldr	x8, [sp, #376]
	ldr	x9, [x23, #16]
	cmp	x8, x9
	b.hs	LBB129_32
; %bb.29:                               ; %bb2.i.i37
	ldr	x9, [sp, #384]
	ldr	x10, [x23, #32]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB129_32
; %bb.30:                               ; %bb5.i.i47
	ldr	x9, [x8]
	cbz	x9, LBB129_32
; %bb.31:                               ; %bb8.i.i
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #24]
	b	LBB129_33
LBB129_32:                              ; %bb5.i
	mov	w0, #3                          ; =0x3
LBB129_33:                              ; %common.ret
	add	sp, sp, #448
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB129_34:                              ; %"wf_std.collections.slab.slab_find_index$instance$c07b06bae9914d5e.exit.thread"
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #160]
	str	xzr, [sp, #168]
	strb	wzr, [sp, #176]
LBB129_35:                              ; %bb15
	ldp	q0, q1, [x0]
	stp	q0, q1, [x11]
	ldp	q0, q1, [x0, #32]
	stp	q0, q1, [x11, #32]
	ldr	x9, [x0, #112]
	str	x9, [x11, #112]
	ldp	q0, q1, [x0, #80]
	stp	q0, q1, [x11, #80]
	ldr	q1, [x0, #64]
	str	q1, [x11, #64]
	ldrb	w9, [sp, #192]
	tbz	w9, #0, LBB129_22
LBB129_36:
	mov	w0, #5                          ; =0x5
	b	LBB129_33
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_record_store_schedule$instance$3ad8b32886f5e3ce ; -- Begin function wf_record_store_schedule$instance$3ad8b32886f5e3ce
	.p2align	2
_wf_record_store_schedule$instance$3ad8b32886f5e3ce: ; @"wf_record_store_schedule$instance$3ad8b32886f5e3ce"
	.cfi_startproc
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.ne	LBB130_7
; %bb.1:                                ; %bb3.i
	sub	sp, sp, #96
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 96
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	ldr	x8, [x1, #8]
	mov	x19, x0
	ldr	x22, [x19, #16]!
	cmp	x8, x22
	b.hs	LBB130_8
; %bb.2:                                ; %bb2.i.i
	ldr	x9, [x1, #16]
	ldr	x21, [x0, #32]
	mov	w10, #56                        ; =0x38
	madd	x10, x8, x10, x21
	ldr	x11, [x10, #40]
	cmp	x11, x9
	b.ne	LBB130_8
; %bb.3:                                ; %bb5.i.i
	ldr	x11, [x10]
	cbz	x11, LBB130_8
; %bb.4:                                ; %bb2
	ldr	x23, [x10, #8]
	ldr	x10, [x10, #32]
	cmp	x10, #8
	b.ne	LBB130_10
; %bb.5:                                ; %bb6
	ldur	q0, [x1, #8]
	str	q0, [sp]
	ldur	x20, [x0, #88]
	cmp	x20, #7
	b.ls	LBB130_13
; %bb.6:
	mov	w0, #6                          ; =0x6
	b	LBB130_9
LBB130_7:
	mov	w0, #4                          ; =0x4
	ret
LBB130_8:
	mov	w0, #3                          ; =0x3
LBB130_9:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB130_10:                              ; %bb2.i.i4
	ldur	x11, [x0, #88]
	cmp	x10, x11
	b.hs	LBB130_18
; %bb.11:                               ; %bb8.i.i
	ldr	x11, [x0, #104]
	add	x10, x11, x10, lsl #5
	ldp	x11, x12, [x10, #16]
	mov	w0, #8                          ; =0x8
	cmp	x11, x8
	ccmp	x12, x9, #0, eq
	b.ne	LBB130_9
; %bb.12:                               ; %bb11.i.i
	ldr	x8, [x10, #8]
	cmp	x8, x23
	csinc	w0, w0, wzr, ne
	b	LBB130_9
LBB130_13:                              ; %bb3.i6
	mov	x24, x0
	add	x0, x0, #88
	mov	x25, x2
	bl	_wf_collections.priority_queue.priority_queue_make_room$instance$8d53fd32336043f5
	mov	x8, x24
	ldr	x9, [x24, #88]
	ldr	x10, [x24, #104]
	add	x11, x10, x9, lsl #5
	stp	x25, x23, [x11]
	ldr	q0, [sp]
	str	q0, [x11, #16]
	add	x9, x9, #1
	str	x9, [x24, #88]
	add	x10, x10, x20, lsl #5
	ldr	x9, [x10, #16]
	cmp	x9, x22
	b.hs	LBB130_17
; %bb.14:                               ; %bb2.i.i.i.i10
	ldr	x10, [x10, #24]
	mov	w11, #56                        ; =0x38
	madd	x9, x9, x11, x21
	ldr	x11, [x9, #40]
	cmp	x11, x10
	b.ne	LBB130_17
; %bb.15:                               ; %bb5.i.i.i.i18
	ldr	x10, [x9]
	cbz	x10, LBB130_17
; %bb.16:                               ; %bb8.i.i.i.i
	str	x20, [x9, #32]
LBB130_17:                              ; %"wf_collections.priority_queue.priority_queue_push_indexed$instance$f0ce656cb92d5494.exit.thread"
	add	x0, x8, #88
	mov	x1, x20
	mov	x4, x19
	bl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$f0ce656cb92d5494
	mov	w0, #0                          ; =0x0
	b	LBB130_9
LBB130_18:
	mov	w0, #8                          ; =0x8
	b	LBB130_9
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_indexed_cancel_position$instance$34505fe33827dcb3 ; -- Begin function wf_indexed_cancel_position$instance$34505fe33827dcb3
	.p2align	2
_wf_indexed_cancel_position$instance$34505fe33827dcb3: ; @"wf_indexed_cancel_position$instance$34505fe33827dcb3"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #96
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 96
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x2
	mov	x20, x0
	mov	x8, #0                          ; =0x0
	ldr	x9, [x0]
	ldr	x23, [x2, #1304]
	add	x11, x1, #56
	mov	w10, #32                        ; =0x20
	mov	w12, #56                        ; =0x38
	b	LBB131_3
LBB131_1:                               ; %bb10
                                        ;   in Loop: Header=BB131_3 Depth=1
	add	x23, x23, #1
	str	x23, [x19, #1304]
LBB131_2:                               ; %bb14
                                        ;   in Loop: Header=BB131_3 Depth=1
	add	x8, x8, #1
	add	x11, x11, #64
	cmp	x8, #32
	b.eq	LBB131_9
LBB131_3:                               ; %bb2
                                        ; =>This Inner Loop Header: Depth=1
	ldurb	w13, [x11, #-56]
	tbz	w13, #0, LBB131_2
; %bb.4:                                ; %bb6
                                        ;   in Loop: Header=BB131_3 Depth=1
	ldur	x13, [x11, #-16]
	cmp	x13, x9
	b.ne	LBB131_1
; %bb.5:                                ; %bb3.i
                                        ;   in Loop: Header=BB131_3 Depth=1
	ldur	x13, [x11, #-8]
	ldr	x14, [x20, #16]
	cmp	x13, x14
	b.hs	LBB131_1
; %bb.6:                                ; %bb2.i.i
                                        ;   in Loop: Header=BB131_3 Depth=1
	ldr	x14, [x11]
	ldr	x15, [x20, #32]
	madd	x13, x13, x12, x15
	ldr	x15, [x13, #40]
	cmp	x15, x14
	b.ne	LBB131_1
; %bb.7:                                ; %bb5.i.i
                                        ;   in Loop: Header=BB131_3 Depth=1
	ldr	x14, [x13]
	cbz	x14, LBB131_1
; %bb.8:                                ; %bb9
                                        ;   in Loop: Header=BB131_3 Depth=1
	ldr	x13, [x13, #32]
	cmp	x13, x3
	csel	x10, x8, x10, eq
	b	LBB131_2
LBB131_9:                               ; %bb4
	cmp	x10, #32
	b.hs	LBB131_15
; %bb.10:                               ; %bb16
	mov	x22, x1
	add	x24, x1, x10, lsl #6
	ldr	x21, [x24, #32]
	ldur	q0, [x24, #40]
	str	q0, [sp]
	ldr	x8, [x24, #56]
	str	x8, [sp, #16]
	mov	x1, sp
	mov	x0, x20
	bl	_wf_record_store_cancel$instance$3ad8b32886f5e3ce
	cbz	w0, LBB131_12
; %bb.11:                               ; %bb13.i.i
	add	x8, x23, #1
	str	x8, [x19, #1304]
LBB131_12:                              ; %"wf_indexed_cancel$instance$4a70da04567deb49.exit"
	strb	wzr, [x24, #25]
	mov	x0, x20
	mov	x1, x22
	mov	x2, x19
	bl	_wf_indexed_check$instance$34505fe33827dcb3
	ldur	q0, [x24, #40]
	str	q0, [sp]
	ldur	x8, [x24, #56]
	str	x8, [sp, #16]
	mov	x1, sp
	mov	x0, x20
	mov	x2, x21
	bl	_wf_record_store_schedule$instance$3ad8b32886f5e3ce
	cbz	w0, LBB131_14
; %bb.13:                               ; %bb13.i.i10
	ldr	x8, [x19, #1304]
	add	x8, x8, #1
	str	x8, [x19, #1304]
LBB131_14:                              ; %"wf_indexed_schedule$instance$4a70da04567deb49.exit"
	mov	w8, #1                          ; =0x1
	strb	w8, [x24, #25]
	str	x21, [x24, #32]
	b	LBB131_16
LBB131_15:                              ; %bb17
	add	x8, x23, #1
	str	x8, [x19, #1304]
LBB131_16:                              ; %bb15
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_record_store_insert$instance$3ad8b32886f5e3ce
lCPI132_0:
	.quad	8                               ; 0x8
	.quad	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_record_store_insert$instance$3ad8b32886f5e3ce
	.p2align	2
_wf_record_store_insert$instance$3ad8b32886f5e3ce: ; @"wf_record_store_insert$instance$3ad8b32886f5e3ce"
; %bb.0:                                ; %entry
	sub	sp, sp, #16
	strb	wzr, [sp, #8]
	ldr	x8, [x1, #40]
	ldr	x10, [x1, #16]
	cmp	x8, x10
	b.hs	LBB132_4
; %bb.1:                                ; %bb2.i
	ldr	x9, [x1, #32]
	mov	w10, #56                        ; =0x38
	madd	x10, x8, x10, x9
	ldr	x9, [x10]
	cbnz	x9, LBB132_7
; %bb.2:                                ; %bb5.i
	ldr	x9, [x10, #40]
	cmp	x9, #2
	b.hi	LBB132_7
; %bb.3:                                ; %bb8.i
	ldr	x11, [x10, #48]
	stp	x2, x3, [x10, #8]
	strb	wzr, [x10, #24]
	mov	w12, #8                         ; =0x8
	str	x12, [x10, #32]
	mov	w12, #1                         ; =0x1
	str	x12, [x10]
	str	x11, [x1, #40]
	b	LBB132_6
LBB132_4:                               ; %bb3.i
	ldr	x9, [x1, #24]
	cmp	x10, x9
	b.hs	LBB132_7
; %bb.5:                                ; %bb11.i
	mov	x9, #0                          ; =0x0
	ldr	x11, [x1, #32]
	mov	w12, #56                        ; =0x38
	madd	x11, x10, x12, x11
	mov	w12, #1                         ; =0x1
	stp	x12, x2, [x11]
	str	x3, [x11, #16]
	strb	wzr, [x11, #24]
Lloh326:
	adrp	x12, lCPI132_0@PAGE
Lloh327:
	ldr	q0, [x12, lCPI132_0@PAGEOFF]
	str	q0, [x11, #32]
	str	x8, [x11, #48]
	add	x8, x10, #1
	str	x8, [x1, #16]
	mov	x8, x10
LBB132_6:                               ; %bb1
	ldr	x10, [x1]
	stp	xzr, x10, [x0]
	stp	x8, x9, [x0, #16]
	add	sp, sp, #16
	ret
LBB132_7:                               ; %bb2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	str	x3, [x0, #8]
	add	sp, sp, #16
	ret
	.loh AdrpLdr	Lloh326, Lloh327
                                        ; -- End function
	.globl	_wf_record_store_cancel$instance$3ad8b32886f5e3ce ; -- Begin function wf_record_store_cancel$instance$3ad8b32886f5e3ce
	.p2align	2
_wf_record_store_cancel$instance$3ad8b32886f5e3ce: ; @"wf_record_store_cancel$instance$3ad8b32886f5e3ce"
; %bb.0:                                ; %entry
	sub	sp, sp, #160
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	ldr	q0, [x1]
	str	q0, [sp]
	ldr	x8, [x1, #16]
	str	x8, [sp, #16]
	ldr	x9, [sp]
	ldr	x10, [x0]
	cmp	x9, x10
	b.ne	LBB133_6
; %bb.1:                                ; %bb3.i.i.i
	ldr	x9, [sp, #8]
	mov	x19, x0
	ldr	x10, [x19, #16]!
	cmp	x9, x10
	b.hs	LBB133_14
; %bb.2:                                ; %bb2.i.i.i.i
	ldr	x10, [x0, #32]
	mov	w11, #56                        ; =0x38
	madd	x10, x9, x11, x10
	ldr	x11, [x10, #40]
	cmp	x11, x8
	b.ne	LBB133_14
; %bb.3:                                ; %bb5.i.i.i.i
	ldr	x11, [x10]
	cbz	x11, LBB133_14
; %bb.4:                                ; %bb2.i.i
	ldr	x2, [x10, #32]
	cmp	x2, #8
	b.ne	LBB133_7
; %bb.5:
	mov	w0, #7                          ; =0x7
	b	LBB133_15
LBB133_6:
	mov	w0, #4                          ; =0x4
	b	LBB133_15
LBB133_7:                               ; %bb6.i.i
	mov	x1, x0
	ldr	x11, [x1, #88]!
	cmp	x2, x11
	b.hs	LBB133_16
; %bb.8:                                ; %bb8.i.i
	ldr	x11, [x0, #104]
	add	x11, x11, x2, lsl #5
	ldp	x12, x13, [x11, #16]
	cmp	x12, x9
	ccmp	x13, x8, #0, eq
	b.ne	LBB133_16
; %bb.9:                                ; %bb11.i.i
	ldr	x8, [x10, #8]
	ldr	x9, [x11, #8]
	cmp	x9, x8
	b.ne	LBB133_16
; %bb.10:                               ; %bb2
	mov	x20, x0
	mov	x8, sp
	orr	x21, x8, #0x8
	add	x0, x8, #48
	add	x3, x8, #104
	mov	x4, x19
	bl	_wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$f0ce656cb92d5494
	ldr	q0, [x21]
	str	q0, [sp, #80]
	ldr	x8, [sp, #80]
	ldr	x9, [x19]
	cmp	x8, x9
	b.hs	LBB133_14
; %bb.11:                               ; %bb2.i.i6
	ldr	x9, [sp, #88]
	ldr	x10, [x20, #32]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB133_14
; %bb.12:                               ; %bb5.i.i
	ldr	x9, [x8]
	cbz	x9, LBB133_14
; %bb.13:                               ; %bb8.i.i8
	mov	w0, #0                          ; =0x0
	mov	w9, #8                          ; =0x8
	str	x9, [x8, #32]
	b	LBB133_15
LBB133_14:
	mov	w0, #3                          ; =0x3
LBB133_15:                              ; %common.ret
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB133_16:
	mov	w0, #8                          ; =0x8
	b	LBB133_15
                                        ; -- End function
	.globl	_wf_record_store_reschedule$instance$3ad8b32886f5e3ce ; -- Begin function wf_record_store_reschedule$instance$3ad8b32886f5e3ce
	.p2align	2
_wf_record_store_reschedule$instance$3ad8b32886f5e3ce: ; @"wf_record_store_reschedule$instance$3ad8b32886f5e3ce"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.ne	LBB134_6
; %bb.1:                                ; %bb3.i.i.i
	ldr	x9, [x1, #8]
	mov	x5, x0
	ldr	x8, [x5, #16]!
	cmp	x9, x8
	b.hs	LBB134_7
; %bb.2:                                ; %bb2.i.i.i.i
	ldr	x10, [x1, #16]
	ldr	x8, [x0, #32]
	mov	w11, #56                        ; =0x38
	madd	x11, x9, x11, x8
	ldr	x8, [x11, #40]
	cmp	x8, x10
	b.ne	LBB134_7
; %bb.3:                                ; %bb5.i.i.i.i
	ldr	x8, [x11]
	cbz	x8, LBB134_7
; %bb.4:                                ; %bb2.i.i
	ldr	x8, [x11, #32]
	cmp	x8, #8
	b.ne	LBB134_8
; %bb.5:
	mov	w0, #7                          ; =0x7
	ret
LBB134_6:
	mov	w0, #4                          ; =0x4
	ret
LBB134_7:
	mov	w0, #3                          ; =0x3
	ret
LBB134_8:                               ; %bb6.i.i
	mov	x1, x0
	ldr	x12, [x1, #88]!
	cmp	x8, x12
	b.hs	LBB134_12
; %bb.9:                                ; %bb8.i.i
	ldr	x12, [x0, #104]
	add	x12, x12, x8, lsl #5
	ldp	x13, x14, [x12, #16]
	cmp	x13, x9
	ccmp	x14, x10, #0, eq
	b.ne	LBB134_12
; %bb.10:                               ; %bb11.i.i
	ldr	x9, [x11, #8]
	ldr	x10, [x12, #8]
	cmp	x10, x9
	b.ne	LBB134_12
; %bb.11:                               ; %bb2
	sub	sp, sp, #160
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	ldr	x9, [x0, #104]
	add	x9, x9, x8, lsl #5
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp, #32]
	str	wzr, [sp, #8]
	str	x8, [sp, #16]
	str	wzr, [sp, #24]
	add	x9, sp, #8
	ldr	x10, [sp, #40]
	stur	q1, [sp, #64]
	stp	x2, x10, [sp, #80]
	stur	q1, [sp, #96]
	add	x0, x9, #104
	add	x3, x9, #72
	add	x4, x9, #136
	mov	x2, x8
	bl	_wf_collections.priority_queue.priority_queue_replace_at_indexed$instance$f0ce656cb92d5494
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB134_12:
	mov	w0, #8                          ; =0x8
	ret
                                        ; -- End function
	.globl	_wf_record_store_detach$instance$3ad8b32886f5e3ce ; -- Begin function wf_record_store_detach$instance$3ad8b32886f5e3ce
	.p2align	2
_wf_record_store_detach$instance$3ad8b32886f5e3ce: ; @"wf_record_store_detach$instance$3ad8b32886f5e3ce"
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	ldr	x9, [x0]
	cmp	x8, x9
	b.ne	LBB135_3
; %bb.1:                                ; %bb3
	ldr	x8, [x0, #112]
	cbz	x8, LBB135_5
; %bb.2:                                ; %bb3.i.i
	udiv	x9, x1, x8
	msub	x13, x9, x8, x1
	ldr	x11, [x0, #48]
	cbnz	x11, LBB135_6
	b	LBB135_26
LBB135_3:
	mov	w8, #4                          ; =0x4
LBB135_4:                               ; %common.ret
	mov	x0, x8
	ret
LBB135_5:
	mov	x13, #0                         ; =0x0
	ldr	x11, [x0, #48]
	cbz	x11, LBB135_26
LBB135_6:                               ; %bb3.i
	ldp	x10, x9, [x2, #8]
	mov	x12, x11
	udiv	x14, x13, x11
	msub	x14, x14, x11, x13
	ldr	x13, [x0, #64]
	mov	x15, x11
	b	LBB135_8
LBB135_7:                               ; %bb8.i
                                        ;   in Loop: Header=BB135_8 Depth=1
	add	x16, x14, #1
	cmp	x16, x11
	csinc	x14, xzr, x14, hs
	subs	x15, x15, #1
	b.eq	LBB135_26
LBB135_8:                               ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x16, x13, x14, lsl #5
	ldr	w17, [x16]
	cmp	w17, #1
	b.eq	LBB135_7
; %bb.9:                                ; %bb5.i
                                        ;   in Loop: Header=BB135_8 Depth=1
	cmp	w17, #2
	b.ne	LBB135_26
; %bb.10:                               ; %bb9.i
                                        ;   in Loop: Header=BB135_8 Depth=1
	ldr	x17, [x16, #8]
	cmp	x17, x1
	b.ne	LBB135_7
; %bb.11:                               ; %bb4
	ldp	x14, x15, [x16, #16]
	cmp	x14, x10
	ccmp	x15, x9, #0, eq
	b.eq	LBB135_13
; %bb.12:
	mov	w0, #5                          ; =0x5
	ret
LBB135_13:                              ; %bb7
	ldr	x14, [x0, #72]
	cbz	x14, LBB135_26
; %bb.14:                               ; %bb3.i5
	cbz	x8, LBB135_16
; %bb.15:                               ; %bb3.i.i.i.i
	udiv	x15, x1, x8
	msub	x8, x15, x8, x1
LBB135_16:                              ; %bb3.i.i.i
	udiv	x15, x8, x11
	msub	x15, x15, x11, x8
	b	LBB135_18
LBB135_17:                              ; %bb8.i.i.i
                                        ;   in Loop: Header=BB135_18 Depth=1
	add	x8, x15, #1
	cmp	x8, x11
	csinc	x15, xzr, x15, hs
	mov	w8, #2                          ; =0x2
	subs	x12, x12, #1
	b.eq	LBB135_4
LBB135_18:                              ; %bb5.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x8, x13, x15, lsl #5
	ldr	w16, [x8]
	cmp	w16, #1
	b.eq	LBB135_17
; %bb.19:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB135_18 Depth=1
	cmp	w16, #2
	b.ne	LBB135_26
; %bb.20:                               ; %bb3.i3.i.i.i
                                        ;   in Loop: Header=BB135_18 Depth=1
	ldr	x16, [x8, #8]
	cmp	x16, x1
	b.ne	LBB135_17
; %bb.21:                               ; %bb9
	mov	w11, #1                         ; =0x1
	str	w11, [x8]
	sub	x11, x14, #1
	stp	xzr, xzr, [x8, #16]
	str	xzr, [x8, #8]
	ldr	x8, [x0, #80]
	adds	x8, x8, #1
	csinv	x8, x8, xzr, lo
	stp	x11, x8, [x0, #72]
	ldr	x8, [x0, #16]
	cmp	x10, x8
	b.hs	LBB135_25
; %bb.22:                               ; %bb2.i.i
	ldr	x8, [x0, #32]
	mov	w11, #56                        ; =0x38
	madd	x10, x10, x11, x8
	ldr	x8, [x10, #40]
	cmp	x8, x9
	b.ne	LBB135_25
; %bb.23:                               ; %bb5.i.i
	ldr	x8, [x10]
	cbz	x8, LBB135_4
; %bb.24:                               ; %bb8.i.i
	strb	wzr, [x10, #24]
LBB135_25:
	mov	w0, #0                          ; =0x0
	ret
LBB135_26:
	mov	w0, #2                          ; =0x2
	ret
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function wf_record_store_delete$instance$3ad8b32886f5e3ce
lCPI136_0:
	.long	1                               ; 0x1
	.long	9                               ; 0x9
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_record_store_delete$instance$3ad8b32886f5e3ce
	.p2align	2
_wf_record_store_delete$instance$3ad8b32886f5e3ce: ; @"wf_record_store_delete$instance$3ad8b32886f5e3ce"
; %bb.0:                                ; %entry
	sub	sp, sp, #48
	ldr	x8, [x2]
	ldr	x9, [x1]
	cmp	x8, x9
	b.ne	LBB136_10
; %bb.1:                                ; %bb3.i
	ldr	x8, [x2, #8]
	ldr	x9, [x1, #16]
	cmp	x8, x9
	b.hs	LBB136_11
; %bb.2:                                ; %bb2.i.i
	ldr	x10, [x2, #16]
	ldr	x9, [x1, #32]
	mov	w11, #56                        ; =0x38
	madd	x11, x8, x11, x9
	ldr	x12, [x11, #40]
	cmp	x12, x10
	b.ne	LBB136_11
; %bb.3:                                ; %bb5.i.i
	ldr	x12, [x11]
	cbz	x12, LBB136_11
; %bb.4:                                ; %bb2
	ldrb	w14, [x11, #24]
	ldr	x13, [x11, #32]
	and	w14, w14, #0x1
	strb	w14, [sp, #8]
	ldrb	w15, [x1, #8]
	tbz	w15, #0, LBB136_7
; %bb.5:                                ; %bb5
	cbnz	w14, LBB136_13
; %bb.6:                                ; %bb9
	cmp	x13, #8
	b.ne	LBB136_13
LBB136_7:                               ; %bb8.i
	sub	x12, x12, #1
	add	x13, x11, x12, lsl #5
	str	x12, [x11]
	ldur	q0, [x13, #8]
	ldur	q1, [x13, #24]
	stp	q0, q1, [sp, #16]
	cmp	x10, #1
	b.hi	LBB136_9
; %bb.8:                                ; %bb11.i
	add	x10, x10, #1
	mov	w11, #56                        ; =0x38
	ldr	x12, [x1, #40]
	madd	x9, x8, x11, x9
	stp	x10, x12, [x9, #40]
	str	x8, [x1, #40]
LBB136_9:                               ; %bb13
	str	xzr, [x0]
	ldp	q0, q1, [sp, #16]
	stur	q0, [x0, #8]
	stur	q1, [x0, #24]
	add	sp, sp, #48
	ret
LBB136_10:
	mov	w8, #4                          ; =0x4
	b	LBB136_12
LBB136_11:                              ; %bb5.i
	mov	w8, #3                          ; =0x3
LBB136_12:                              ; %bb3
	movi.2d	v0, #0000000000000000
	stur	q0, [x0, #24]
	stur	q0, [x0, #8]
	mov	w9, #1                          ; =0x1
	stp	w9, w8, [x0]
	add	sp, sp, #48
	ret
LBB136_13:                              ; %bb8
	movi.2d	v0, #0000000000000000
	stur	q0, [x0, #24]
	stur	q0, [x0, #8]
Lloh328:
	adrp	x8, lCPI136_0@PAGE
Lloh329:
	ldr	d0, [x8, lCPI136_0@PAGEOFF]
	str	d0, [x0]
	add	sp, sp, #48
	ret
	.loh AdrpLdr	Lloh328, Lloh329
                                        ; -- End function
	.globl	_wf_indexed_release$instance$cfa19887953541da ; -- Begin function wf_indexed_release$instance$cfa19887953541da
	.p2align	2
_wf_indexed_release$instance$cfa19887953541da: ; @"wf_indexed_release$instance$cfa19887953541da"
; %bb.0:                                ; %entry
	mov	x8, x0
	ldr	x0, [x1, #8]
	ldp	x9, x10, [x0]
	add	x11, x9, #101
	cmp	x10, x11
	csinv	x9, x9, xzr, eq
	cmp	x9, #64
	b.hs	LBB137_4
; %bb.1:                                ; %bb2
	ldr	x10, [x1]
	ldr	x11, [x8, x9, lsl #3]
	cmp	x11, x10
	b.eq	LBB137_3
; %bb.2:                                ; %bb5
	ldr	x10, [x8, #1304]
	add	x10, x10, #1
	str	x10, [x8, #1304]
LBB137_3:                               ; %bb4
	add	x10, x8, x9, lsl #3
	ldr	x11, [x10, #512]
	add	x11, x11, #1
	str	x11, [x10, #512]
	ldrb	w10, [x8, #1296]
	tbnz	w10, #0, LBB137_5
	b	LBB137_14
LBB137_4:                               ; %bb3
	ldr	x10, [x8, #1304]
	add	x10, x10, #1
	str	x10, [x8, #1304]
	ldrb	w10, [x8, #1296]
	tbz	w10, #0, LBB137_14
LBB137_5:                               ; %bb8
	ldrb	w11, [x1, #16]
	ldr	x10, [x1, #24]
	tbz	w11, #0, LBB137_7
; %bb.6:                                ; %bb11
	ldr	x11, [x8, #1304]
	add	x11, x11, #1
	str	x11, [x8, #1304]
LBB137_7:                               ; %bb10
	cmp	x10, #8
	b.eq	LBB137_9
; %bb.8:                                ; %bb14
	ldr	x10, [x8, #1304]
	add	x10, x10, #1
	str	x10, [x8, #1304]
LBB137_9:                               ; %bb13
	ldr	x10, [x8, #1288]
	ldr	x11, [x8, #1280]
	cmp	x10, x11
	b.hs	LBB137_12
; %bb.10:                               ; %bb13
	cmp	x10, #32
	b.hs	LBB137_12
; %bb.11:                               ; %bb20
	add	x11, x8, x10, lsl #3
	ldr	x11, [x11, #1024]
	cmp	x11, x9
	b.eq	LBB137_13
LBB137_12:                              ; %bb16.sink.split
	ldr	x9, [x8, #1304]
	add	x9, x9, #1
	str	x9, [x8, #1304]
LBB137_13:                              ; %bb16
	add	x9, x10, #1
	str	x9, [x8, #1288]
LBB137_14:                              ; %bb7
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	bl	_free
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_record_store_visit$instance$4c55b9d2a9718ad5 ; -- Begin function wf_record_store_visit$instance$4c55b9d2a9718ad5
	.p2align	2
_wf_record_store_visit$instance$4c55b9d2a9718ad5: ; @"wf_record_store_visit$instance$4c55b9d2a9718ad5"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.ne	LBB138_5
; %bb.1:                                ; %bb3.i
	ldr	x8, [x1, #8]
	ldr	x9, [x0, #16]
	cmp	x8, x9
	b.hs	LBB138_6
; %bb.2:                                ; %bb2.i.i.i
	ldr	x9, [x1, #16]
	ldr	x10, [x0, #32]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB138_6
; %bb.3:                                ; %bb5.i.i.i
	ldr	x9, [x8]
	cbz	x9, LBB138_6
; %bb.4:                                ; %bb4.i
	mov	w0, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ldr	x8, [x8, #16]
	ldp	x9, x8, [x8]
	add	x10, x9, #101
	cmp	x8, x10
	csinv	x1, x9, xzr, eq
	ret
LBB138_5:
	mov	x1, #0                          ; =0x0
	mov	w2, #4                          ; =0x4
	mov	w0, #1                          ; =0x1
	ret
LBB138_6:
	mov	x1, #0                          ; =0x0
	mov	w2, #3                          ; =0x3
	mov	w0, #1                          ; =0x1
	ret
                                        ; -- End function
	.globl	_wf_indexed_release_payload$instance$cfa19887953541da ; -- Begin function wf_indexed_release_payload$instance$cfa19887953541da
	.p2align	2
_wf_indexed_release_payload$instance$cfa19887953541da: ; @"wf_indexed_release_payload$instance$cfa19887953541da"
; %bb.0:                                ; %entry
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	strb	wzr, [sp, #8]
	ldp	x8, x9, [x2]
	add	x10, x8, #101
	cmp	x9, x10
	csinv	x8, x8, xzr, eq
	cmp	x8, #64
	b.hs	LBB139_4
; %bb.1:                                ; %bb2.i
	ldr	x9, [x0, x8, lsl #3]
	cmp	x9, x1
	b.eq	LBB139_3
; %bb.2:                                ; %bb5.i
	ldr	x9, [x0, #1304]
	add	x9, x9, #1
	str	x9, [x0, #1304]
LBB139_3:                               ; %bb4.i
	add	x9, x0, x8, lsl #3
	ldr	x10, [x9, #512]
	add	x10, x10, #1
	str	x10, [x9, #512]
	ldrb	w9, [x0, #1296]
	tbnz	w9, #0, LBB139_5
	b	LBB139_12
LBB139_4:                               ; %bb3.i
	ldr	x9, [x0, #1304]
	add	x9, x9, #1
	str	x9, [x0, #1304]
	ldrb	w9, [x0, #1296]
	tbz	w9, #0, LBB139_12
LBB139_5:                               ; %bb8.i
	mov	w9, #1                          ; =0x1
	cbnz	w9, LBB139_7
; %bb.6:                                ; %bb11.i
	ldr	x9, [x0, #1304]
	add	x9, x9, #1
	str	x9, [x0, #1304]
LBB139_7:                               ; %bb13.i
	ldr	x9, [x0, #1288]
	cmp	x9, #31
	b.hi	LBB139_10
; %bb.8:                                ; %bb13.i
	ldr	x10, [x0, #1280]
	cmp	x9, x10
	b.hs	LBB139_10
; %bb.9:                                ; %bb20.i
	add	x10, x0, x9, lsl #3
	ldr	x10, [x10, #1024]
	cmp	x10, x8
	b.eq	LBB139_11
LBB139_10:                              ; %bb16.sink.split.i
	ldr	x8, [x0, #1304]
	add	x8, x8, #1
	str	x8, [x0, #1304]
LBB139_11:                              ; %bb16.i
	add	x8, x9, #1
	str	x8, [x0, #1288]
LBB139_12:                              ; %"wf_indexed_release$instance$cfa19887953541da.exit"
	mov	x0, x2
	bl	_free
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
                                        ; -- End function
	.globl	_wf_indexed_delete$instance$34505fe33827dcb3 ; -- Begin function wf_indexed_delete$instance$34505fe33827dcb3
	.p2align	2
_wf_indexed_delete$instance$34505fe33827dcb3: ; @"wf_indexed_delete$instance$34505fe33827dcb3"
; %bb.0:                                ; %entry
	sub	sp, sp, #48
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	add	x19, x1, x3, lsl #6
	ldr	x8, [x19, #40]
	ldr	x9, [x0]
	cmp	x8, x9
	b.ne	LBB140_7
; %bb.1:                                ; %bb3.i.i
	ldr	x9, [x19, #48]
	ldr	x8, [x0, #16]
	cmp	x9, x8
	b.hs	LBB140_8
; %bb.2:                                ; %bb2.i.i.i
	ldr	x12, [x19, #56]
	ldr	x11, [x0, #32]
	mov	w8, #56                         ; =0x38
	madd	x10, x9, x8, x11
	ldr	x8, [x10, #40]
	cmp	x8, x12
	b.ne	LBB140_8
; %bb.3:                                ; %bb5.i.i.i
	ldr	x8, [x10]
	cbz	x8, LBB140_8
; %bb.4:                                ; %bb2.i
	ldrb	w13, [x10, #24]
	ldr	x14, [x10, #32]
	and	w13, w13, #0x1
	strb	w13, [sp, #8]
	ldrb	w15, [x0, #8]
	cmp	x14, #8
	csinc	w13, w13, wzr, eq
	tbz	w15, #0, LBB140_11
; %bb.5:                                ; %bb2.i
	tbz	w13, #0, LBB140_11
; %bb.6:
	mov	w8, #9                          ; =0x9
	cmp	x8, x4
	b.ne	LBB140_9
	b	LBB140_10
LBB140_7:
	mov	w8, #4                          ; =0x4
	cmp	x8, x4
	b.ne	LBB140_9
	b	LBB140_10
LBB140_8:                               ; %bb5.i8
	mov	w8, #3                          ; =0x3
	cmp	x8, x4
	b.eq	LBB140_10
LBB140_9:                               ; %bb13.i5
	ldr	x8, [x2, #1304]
	add	x8, x8, #1
	str	x8, [x2, #1304]
LBB140_10:                              ; %bb1
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB140_11:                              ; %bb8.i.i
	mov	x13, x0
	sub	x14, x8, #1
	add	x8, x10, x14, lsl #5
	str	x14, [x10]
	ldp	x10, x0, [x8, #8]
	cmp	x12, #1
	b.hi	LBB140_13
; %bb.12:                               ; %bb11.i.i
	add	x12, x12, #1
	mov	w14, #56                        ; =0x38
	ldr	x15, [x13, #40]
	madd	x11, x9, x14, x11
	stp	x12, x15, [x11, #40]
	str	x9, [x13, #40]
LBB140_13:                              ; %bb2
	cbz	x4, LBB140_15
; %bb.14:                               ; %bb5
	ldr	x9, [x2, #1304]
	add	x9, x9, #1
	str	x9, [x2, #1304]
LBB140_15:                              ; %bb4
	ldp	x9, x11, [x0]
	add	x12, x9, #101
	cmp	x11, x12
	csinv	x9, x9, xzr, eq
	ldr	x11, [x19, #16]
	cmp	x9, x11
	b.eq	LBB140_17
; %bb.16:                               ; %bb8
	ldr	x11, [x2, #1304]
	add	x11, x11, #1
	str	x11, [x2, #1304]
LBB140_17:                              ; %bb7
	cmp	x9, #64
	b.hs	LBB140_21
; %bb.18:                               ; %bb2.i24
	ldr	x11, [x2, x9, lsl #3]
	cmp	x11, x10
	b.eq	LBB140_20
; %bb.19:                               ; %bb5.i26
	ldr	x10, [x2, #1304]
	add	x10, x10, #1
	str	x10, [x2, #1304]
LBB140_20:                              ; %bb4.i27
	add	x10, x2, x9, lsl #3
	ldr	x11, [x10, #512]
	add	x11, x11, #1
	str	x11, [x10, #512]
	b	LBB140_22
LBB140_21:                              ; %bb3.i14
	ldr	x10, [x2, #1304]
	add	x10, x10, #1
	str	x10, [x2, #1304]
LBB140_22:                              ; %bb1.i17
	ldrb	w10, [x2, #1296]
	tbz	w10, #0, LBB140_32
; %bb.23:                               ; %bb8.i19
	ldrb	w10, [x8, #24]
	ldr	x8, [x8, #32]
	tbz	w10, #0, LBB140_25
; %bb.24:                               ; %bb11.i23
	ldr	x10, [x2, #1304]
	add	x10, x10, #1
	str	x10, [x2, #1304]
LBB140_25:                              ; %bb10.i20
	cmp	x8, #8
	b.eq	LBB140_27
; %bb.26:                               ; %bb14.i
	ldr	x8, [x2, #1304]
	add	x8, x8, #1
	str	x8, [x2, #1304]
LBB140_27:                              ; %bb13.i21
	ldr	x8, [x2, #1288]
	cmp	x8, #31
	b.hi	LBB140_30
; %bb.28:                               ; %bb13.i21
	ldr	x10, [x2, #1280]
	cmp	x8, x10
	b.hs	LBB140_30
; %bb.29:                               ; %bb20.i
	add	x10, x2, x8, lsl #3
	ldr	x10, [x10, #1024]
	cmp	x10, x9
	b.eq	LBB140_31
LBB140_30:                              ; %bb16.sink.split.i
	ldr	x9, [x2, #1304]
	add	x9, x9, #1
	str	x9, [x2, #1304]
LBB140_31:                              ; %bb16.i
	add	x8, x8, #1
	str	x8, [x2, #1288]
LBB140_32:                              ; %"wf_indexed_release$instance$cfa19887953541da.exit"
	bl	_free
	strb	wzr, [x19]
	b	LBB140_10
                                        ; -- End function
	.globl	_wf_indexed_detach$instance$4a70da04567deb49 ; -- Begin function wf_indexed_detach$instance$4a70da04567deb49
	.p2align	2
_wf_indexed_detach$instance$4a70da04567deb49: ; @"wf_indexed_detach$instance$4a70da04567deb49"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	mov	x19, x2
	add	x20, x1, x3, lsl #6
	ldr	x1, [x20, #8]
	ldur	q0, [x20, #40]
	str	q0, [sp]
	ldr	x8, [x20, #56]
	str	x8, [sp, #16]
	mov	x2, sp
	bl	_wf_record_store_detach$instance$3ad8b32886f5e3ce
	cbz	w0, LBB141_2
; %bb.1:                                ; %bb13.i
	ldr	x8, [x19, #1304]
	add	x8, x8, #1
	str	x8, [x19, #1304]
LBB141_2:                               ; %wf_indexed_status.exit
	strb	wzr, [x20, #24]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
                                        ; -- End function
	.globl	_wf_indexed_cancel$instance$4a70da04567deb49 ; -- Begin function wf_indexed_cancel$instance$4a70da04567deb49
	.p2align	2
_wf_indexed_cancel$instance$4a70da04567deb49: ; @"wf_indexed_cancel$instance$4a70da04567deb49"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	mov	x19, x2
	add	x20, x1, x3, lsl #6
	ldur	q0, [x20, #40]
	str	q0, [sp]
	ldr	x8, [x20, #56]
	str	x8, [sp, #16]
	mov	x1, sp
	bl	_wf_record_store_cancel$instance$3ad8b32886f5e3ce
	cbz	w0, LBB142_2
; %bb.1:                                ; %bb13.i
	ldr	x8, [x19, #1304]
	add	x8, x8, #1
	str	x8, [x19, #1304]
LBB142_2:                               ; %wf_indexed_status.exit
	strb	wzr, [x20, #25]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
                                        ; -- End function
	.globl	_wf_record_store_replace$instance$3ad8b32886f5e3ce ; -- Begin function wf_record_store_replace$instance$3ad8b32886f5e3ce
	.p2align	2
_wf_record_store_replace$instance$3ad8b32886f5e3ce: ; @"wf_record_store_replace$instance$3ad8b32886f5e3ce"
; %bb.0:                                ; %entry
	ldr	x8, [x0, #112]
	cbz	x8, LBB143_2
; %bb.1:                                ; %bb3.i.i.i.i
	udiv	x9, x1, x8
	msub	x9, x9, x8, x1
	ldr	x8, [x0, #48]
	cbnz	x8, LBB143_3
	b	LBB143_13
LBB143_2:
	mov	x9, #0                          ; =0x0
	ldr	x8, [x0, #48]
	cbz	x8, LBB143_13
LBB143_3:                               ; %bb3.i.i.i
	udiv	x10, x9, x8
	msub	x9, x10, x8, x9
	ldr	x10, [x0, #64]
	mov	x11, x8
	b	LBB143_5
LBB143_4:                               ; %bb8.i.i.i
                                        ;   in Loop: Header=BB143_5 Depth=1
	add	x12, x9, #1
	cmp	x12, x8
	csinc	x9, xzr, x9, hs
	subs	x11, x11, #1
	b.eq	LBB143_13
LBB143_5:                               ; %bb5.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x12, x10, x9, lsl #5
	ldr	w13, [x12]
	cmp	w13, #1
	b.eq	LBB143_4
; %bb.6:                                ; %bb5.i.i.i
                                        ;   in Loop: Header=BB143_5 Depth=1
	cmp	w13, #2
	b.ne	LBB143_13
; %bb.7:                                ; %bb9.i.i.i
                                        ;   in Loop: Header=BB143_5 Depth=1
	ldr	x13, [x12, #8]
	cmp	x13, x1
	b.ne	LBB143_4
; %bb.8:                                ; %bb3.i120.i.i
	ldr	x8, [x12, #16]
	ldr	x9, [x0, #16]
	cmp	x8, x9
	b.hs	LBB143_14
; %bb.9:                                ; %bb2.i.i.i.i
	ldr	x9, [x12, #24]
	ldr	x10, [x0, #32]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB143_14
; %bb.10:                               ; %bb5.i.i.i.i
	ldr	x9, [x8]
	cbz	x9, LBB143_14
; %bb.11:                               ; %bb3.i.i
	ldr	x9, [x8, #8]
	cmp	x9, x1
	b.ne	LBB143_15
; %bb.12:                               ; %bb4.i
	mov	w0, #0                          ; =0x0
	ldr	x9, [x8, #16]
	str	x2, [x8, #16]
	mov	x1, x9
	ret
LBB143_13:
	mov	w0, #2                          ; =0x2
	mov	x1, x2
	ret
LBB143_14:
	mov	w0, #3                          ; =0x3
	mov	x1, x2
	ret
LBB143_15:
	mov	w0, #5                          ; =0x5
	mov	x1, x2
	ret
                                        ; -- End function
	.globl	_wf_record_store_position$instance$3ad8b32886f5e3ce ; -- Begin function wf_record_store_position$instance$3ad8b32886f5e3ce
	.p2align	2
_wf_record_store_position$instance$3ad8b32886f5e3ce: ; @"wf_record_store_position$instance$3ad8b32886f5e3ce"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.ne	LBB144_6
; %bb.1:                                ; %bb3.i.i
	ldr	x8, [x1, #8]
	ldr	x9, [x0, #16]
	cmp	x8, x9
	b.hs	LBB144_7
; %bb.2:                                ; %bb2.i.i.i
	ldr	x9, [x1, #16]
	ldr	x10, [x0, #32]
	mov	w11, #56                        ; =0x38
	madd	x10, x8, x11, x10
	ldr	x11, [x10, #40]
	cmp	x11, x9
	b.ne	LBB144_7
; %bb.3:                                ; %bb5.i.i.i
	ldr	x11, [x10]
	cbz	x11, LBB144_7
; %bb.4:                                ; %bb2.i
	ldr	x1, [x10, #32]
	cmp	x1, #8
	b.ne	LBB144_8
; %bb.5:
	mov	x1, #0                          ; =0x0
	mov	w2, #7                          ; =0x7
	mov	w0, #1                          ; =0x1
	ret
LBB144_6:
	mov	x1, #0                          ; =0x0
	mov	w2, #4                          ; =0x4
	mov	w0, #1                          ; =0x1
	ret
LBB144_7:
	mov	x1, #0                          ; =0x0
	mov	w2, #3                          ; =0x3
	mov	w0, #1                          ; =0x1
	ret
LBB144_8:                               ; %bb6.i
	ldr	x11, [x0, #88]
	cmp	x1, x11
	b.hs	LBB144_12
; %bb.9:                                ; %bb8.i
	ldr	x11, [x0, #104]
	add	x11, x11, x1, lsl #5
	ldp	x12, x13, [x11, #16]
	cmp	x12, x8
	ccmp	x13, x9, #0, eq
	b.ne	LBB144_12
; %bb.10:                               ; %bb11.i
	ldr	x8, [x10, #8]
	ldr	x9, [x11, #8]
	cmp	x9, x8
	b.ne	LBB144_12
; %bb.11:                               ; %bb14.i
	mov	w0, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ret
LBB144_12:
	mov	x1, #0                          ; =0x0
	mov	w2, #8                          ; =0x8
	mov	w0, #1                          ; =0x1
	ret
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function wf_record_store_info$instance$3ad8b32886f5e3ce
lCPI145_0:
	.long	1                               ; 0x1
	.long	4                               ; 0x4
lCPI145_1:
	.long	1                               ; 0x1
	.long	3                               ; 0x3
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_record_store_info$instance$3ad8b32886f5e3ce
	.p2align	2
_wf_record_store_info$instance$3ad8b32886f5e3ce: ; @"wf_record_store_info$instance$3ad8b32886f5e3ce"
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	ldr	x9, [x1]
	cmp	x8, x9
	b.ne	LBB145_5
; %bb.1:                                ; %bb3
	ldr	x8, [x2, #8]
	ldr	x9, [x1, #16]
	cmp	x8, x9
	b.hs	LBB145_6
; %bb.2:                                ; %bb2.i
	ldr	x9, [x2, #16]
	ldr	x10, [x1, #32]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB145_6
; %bb.3:                                ; %bb5.i
	ldr	x9, [x8]
	cbz	x9, LBB145_6
; %bb.4:                                ; %bb4
	sub	sp, sp, #16
	ldr	x9, [x8, #8]
	ldrb	w10, [x8, #24]
	ldr	x8, [x8, #32]
	and	w10, w10, #0x1
	strb	w10, [sp, #8]
	stp	xzr, x9, [x0]
	strb	w10, [x0, #16]
	stur	wzr, [x0, #17]
	str	wzr, [x0, #20]
	str	x8, [x0, #24]
	add	sp, sp, #16
	ret
LBB145_5:                               ; %bb2
	movi.2d	v0, #0000000000000000
	str	xzr, [x0, #24]
	mov.d	v0[1], v0[0]
	stur	q0, [x0, #8]
Lloh330:
	adrp	x8, lCPI145_0@PAGE
Lloh331:
	ldr	d0, [x8, lCPI145_0@PAGEOFF]
	str	d0, [x0]
	ret
LBB145_6:                               ; %bb5
	movi.2d	v0, #0000000000000000
	str	xzr, [x0, #24]
	mov.d	v0[1], v0[0]
	stur	q0, [x0, #8]
Lloh332:
	adrp	x8, lCPI145_1@PAGE
Lloh333:
	ldr	d0, [x8, lCPI145_1@PAGEOFF]
	str	d0, [x0]
	ret
	.loh AdrpLdr	Lloh330, Lloh331
	.loh AdrpLdr	Lloh332, Lloh333
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_edit$instance$f11a17af73d113d5 ; -- Begin function wf_std.collections.slab.slab_edit$instance$f11a17af73d113d5
	.p2align	2
_wf_std.collections.slab.slab_edit$instance$f11a17af73d113d5: ; @"wf_std.collections.slab.slab_edit$instance$f11a17af73d113d5"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.hs	LBB146_4
; %bb.1:                                ; %bb2.i
	ldr	x9, [x1, #8]
	ldr	x10, [x0, #16]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB146_4
; %bb.2:                                ; %bb5.i
	ldr	x9, [x8]
	cbz	x9, LBB146_4
; %bb.3:                                ; %bb8.i
	mov	w0, #0                          ; =0x0
	ldr	x9, [x2]
	str	x9, [x8, #32]
	b	LBB146_5
LBB146_4:
	mov	w0, #1                          ; =0x1
LBB146_5:                               ; %"wf_std.collections.slab.slab_edit$instance$f11a17af73d113d5.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_indexed_expire$instance$34505fe33827dcb3 ; -- Begin function wf_indexed_expire$instance$34505fe33827dcb3
	.p2align	2
_wf_indexed_expire$instance$34505fe33827dcb3: ; @"wf_indexed_expire$instance$34505fe33827dcb3"
; %bb.0:                                ; %entry
	sub	sp, sp, #304
	stp	x22, x21, [sp, #256]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #272]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #288]            ; 16-byte Folded Spill
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #224]
	stp	q0, q0, [sp, #192]
	stp	q0, q0, [sp, #160]
	stp	q0, q0, [sp, #128]
	stp	q0, q0, [sp, #96]
	stp	q0, q0, [sp, #64]
	stp	q0, q0, [sp, #32]
	stp	q0, q0, [sp]
	mov	x10, sp
	sub	x11, x10, #8
	ldr	x12, [x2, #1304]
	b	LBB147_3
LBB147_1:                               ; %bb15
                                        ;   in Loop: Header=BB147_3 Depth=1
	add	x12, x12, #1
	str	x12, [x19, #1304]
LBB147_2:                               ; %bb19
                                        ;   in Loop: Header=BB147_3 Depth=1
	add	x9, x9, #1
	add	x11, x11, #8
	sub	x8, x8, #1
	cmp	x9, #32
	b.eq	LBB147_12
LBB147_3:                               ; %bb2
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB147_5 Depth 2
	str	x9, [x10, x9, lsl #3]
	cbz	x9, LBB147_2
; %bb.4:                                ; %bb9.preheader
                                        ;   in Loop: Header=BB147_3 Depth=1
	add	x13, x20, x9, lsl #6
	mov	x14, x8
	mov	x15, x11
LBB147_5:                               ; %bb11
                                        ;   Parent Loop BB147_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x16, [x15]
	cmp	x16, #31
	b.hi	LBB147_1
; %bb.6:                                ; %bb14
                                        ;   in Loop: Header=BB147_5 Depth=2
	ldr	x0, [x13, #32]
	add	x17, x20, x16, lsl #6
	ldr	x1, [x17, #32]
	cmp	x0, x1
	b.ne	LBB147_10
; %bb.7:                                ; %bb3.i
                                        ;   in Loop: Header=BB147_5 Depth=2
	ldr	x0, [x13, #8]
	ldr	x1, [x17, #8]
	cmp	x0, x1
	b.ne	LBB147_10
; %bb.8:                                ; %bb6.i
                                        ;   in Loop: Header=BB147_5 Depth=2
	ldr	x0, [x13, #48]
	ldr	x1, [x17, #48]
	cmp	x0, x1
	b.ne	LBB147_10
; %bb.9:                                ; %bb9.i
                                        ;   in Loop: Header=BB147_5 Depth=2
	ldr	x0, [x13, #56]
	ldr	x17, [x17, #56]
	cmp	x0, x17
LBB147_10:                              ; %bb2.i
                                        ;   in Loop: Header=BB147_5 Depth=2
	b.hs	LBB147_2
; %bb.11:                               ; %bb17
                                        ;   in Loop: Header=BB147_5 Depth=2
	stp	x9, x16, [x15], #-8
	adds	x14, x14, #1
	b.lo	LBB147_5
	b	LBB147_2
LBB147_12:                              ; %bb4
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	add	x10, x19, #1280
	add	x11, x19, #1024
	movi.2d	v0, #0000000000000000
	str	q0, [x19, #1280]
	mov	x12, sp
	b	LBB147_15
LBB147_13:                              ; %bb26
                                        ;   in Loop: Header=BB147_15 Depth=1
	ldr	x13, [x19, #1304]
	add	x13, x13, #1
	str	x13, [x19, #1304]
LBB147_14:                              ; %bb39
                                        ;   in Loop: Header=BB147_15 Depth=1
	add	x8, x8, #8
	cmp	x8, #256
	b.eq	LBB147_22
LBB147_15:                              ; %bb21
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x13, [x12, x8]
	cmp	x13, #32
	b.hs	LBB147_13
; %bb.16:                               ; %bb25
                                        ;   in Loop: Header=BB147_15 Depth=1
	add	x13, x20, x13, lsl #6
	ldrb	w14, [x13, #25]
	tbz	w14, #0, LBB147_14
; %bb.17:                               ; %bb28
                                        ;   in Loop: Header=BB147_15 Depth=1
	ldr	x14, [x13, #32]
	cmp	x14, x3
	b.hi	LBB147_14
; %bb.18:                               ; %bb31
                                        ;   in Loop: Header=BB147_15 Depth=1
	ldrb	w15, [x13]
	ldr	x14, [x13, #16]
	strh	wzr, [x13, #24]
	tbz	w15, #0, LBB147_14
; %bb.19:                               ; %bb34
                                        ;   in Loop: Header=BB147_15 Depth=1
	cmp	x9, #32
	b.hs	LBB147_21
; %bb.20:                               ; %bb37
                                        ;   in Loop: Header=BB147_15 Depth=1
	str	x14, [x11, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x10]
	strb	wzr, [x13]
	b	LBB147_14
LBB147_21:                              ; %bb38
                                        ;   in Loop: Header=BB147_15 Depth=1
	ldr	x14, [x19, #1304]
	add	x14, x14, #1
	str	x14, [x19, #1304]
	strb	wzr, [x13]
	b	LBB147_14
LBB147_22:                              ; %bb23
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #1296]
	mov	x0, x21
	mov	x1, x3
	mov	x2, x19
	bl	_wf_record_store_expire$instance$e67a16f596c8720d
	ldr	x8, [x19, #1280]
	cmp	x0, x8
	b.eq	LBB147_24
; %bb.23:                               ; %bb41
	ldr	x9, [x19, #1304]
	add	x9, x9, #1
	str	x9, [x19, #1304]
LBB147_24:                              ; %bb40
	ldr	x9, [x19, #1288]
	cmp	x9, x8
	b.eq	LBB147_26
; %bb.25:                               ; %bb44
	ldr	x8, [x19, #1304]
	add	x8, x8, #1
	str	x8, [x19, #1304]
LBB147_26:                              ; %bb43
	strb	wzr, [x19, #1296]
	mov	x0, x21
	mov	x1, x20
	mov	x2, x19
	bl	_wf_indexed_check$instance$34505fe33827dcb3
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #288]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #272]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #256]            ; 16-byte Folded Reload
	add	sp, sp, #304
	ret
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function wf_record_store_lookup$instance$3ad8b32886f5e3ce
lCPI148_0:
	.long	1                               ; 0x1
	.long	5                               ; 0x5
lCPI148_1:
	.long	1                               ; 0x1
	.long	3                               ; 0x3
lCPI148_2:
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_record_store_lookup$instance$3ad8b32886f5e3ce
	.p2align	2
_wf_record_store_lookup$instance$3ad8b32886f5e3ce: ; @"wf_record_store_lookup$instance$3ad8b32886f5e3ce"
; %bb.0:                                ; %entry
	ldr	x8, [x1, #112]
	cbz	x8, LBB148_2
; %bb.1:                                ; %bb3.i.i
	udiv	x9, x2, x8
	msub	x9, x9, x8, x2
	ldr	x8, [x1, #48]
	cbnz	x8, LBB148_3
	b	LBB148_13
LBB148_2:
	mov	x9, #0                          ; =0x0
	ldr	x8, [x1, #48]
	cbz	x8, LBB148_13
LBB148_3:                               ; %bb3.i
	udiv	x10, x9, x8
	msub	x9, x10, x8, x9
	ldr	x10, [x1, #64]
	mov	x11, x8
	b	LBB148_5
LBB148_4:                               ; %bb8.i
                                        ;   in Loop: Header=BB148_5 Depth=1
	add	x12, x9, #1
	cmp	x12, x8
	csinc	x9, xzr, x9, hs
	subs	x11, x11, #1
	b.eq	LBB148_13
LBB148_5:                               ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x12, x10, x9, lsl #5
	ldr	w13, [x12]
	cmp	w13, #1
	b.eq	LBB148_4
; %bb.6:                                ; %bb5.i
                                        ;   in Loop: Header=BB148_5 Depth=1
	cmp	w13, #2
	b.ne	LBB148_13
; %bb.7:                                ; %bb9.i
                                        ;   in Loop: Header=BB148_5 Depth=1
	ldr	x13, [x12, #8]
	cmp	x13, x2
	b.ne	LBB148_4
; %bb.8:                                ; %bb3.i120
	ldr	x8, [x12, #16]
	ldr	x9, [x1, #16]
	cmp	x8, x9
	b.hs	LBB148_14
; %bb.9:                                ; %bb2.i.i
	ldr	x9, [x12, #24]
	ldr	x10, [x1, #32]
	mov	w11, #56                        ; =0x38
	madd	x10, x8, x11, x10
	ldr	x11, [x10, #40]
	cmp	x11, x9
	b.ne	LBB148_14
; %bb.10:                               ; %bb5.i.i
	ldr	x11, [x10]
	cbz	x11, LBB148_14
; %bb.11:                               ; %bb3
	ldr	x10, [x10, #8]
	cmp	x10, x2
	b.ne	LBB148_15
; %bb.12:                               ; %bb6
	ldr	x10, [x1]
	stp	xzr, x10, [x0]
	stp	x8, x9, [x0, #16]
	ret
LBB148_13:                              ; %bb2
	movi.2d	v0, #0000000000000000
	str	xzr, [x0, #24]
	mov.d	v0[1], v0[0]
	stur	q0, [x0, #8]
Lloh334:
	adrp	x8, lCPI148_2@PAGE
Lloh335:
	ldr	d0, [x8, lCPI148_2@PAGEOFF]
	str	d0, [x0]
	ret
LBB148_14:                              ; %bb4
	movi.2d	v0, #0000000000000000
	str	xzr, [x0, #24]
	mov.d	v0[1], v0[0]
	stur	q0, [x0, #8]
Lloh336:
	adrp	x8, lCPI148_1@PAGE
Lloh337:
	ldr	d0, [x8, lCPI148_1@PAGEOFF]
	str	d0, [x0]
	ret
LBB148_15:                              ; %bb7
	movi.2d	v0, #0000000000000000
	str	xzr, [x0, #24]
	mov.d	v0[1], v0[0]
	stur	q0, [x0, #8]
Lloh338:
	adrp	x8, lCPI148_0@PAGE
Lloh339:
	ldr	d0, [x8, lCPI148_0@PAGEOFF]
	str	d0, [x0]
	ret
	.loh AdrpLdr	Lloh334, Lloh335
	.loh AdrpLdr	Lloh336, Lloh337
	.loh AdrpLdr	Lloh338, Lloh339
                                        ; -- End function
	.globl	_wf_record_store_free$instance$e67a16f596c8720d ; -- Begin function wf_record_store_free$instance$e67a16f596c8720d
	.p2align	2
_wf_record_store_free$instance$e67a16f596c8720d: ; @"wf_record_store_free$instance$e67a16f596c8720d"
; %bb.0:                                ; %entry
	sub	sp, sp, #272
	stp	x28, x27, [sp, #224]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #240]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #256]            ; 16-byte Folded Spill
	mov	x19, x1
	ldp	q1, q0, [x0, #48]
	ldp	q3, q2, [x0, #64]
	stp	q0, q2, [sp, #64]
	ldr	q0, [x0, #96]
	str	q0, [sp, #96]
	ldp	q0, q2, [x0, #32]
	stp	q0, q2, [sp, #32]
	ldp	q2, q4, [x0]
	stp	q2, q4, [sp]
	stur	q4, [sp, #120]
	mov	x20, sp
	ldp	x9, x8, [x0, #104]
	str	x8, [sp, #112]
	stur	q0, [x20, #136]
	stur	q1, [x20, #152]
	ldr	x8, [x0, #80]
	str	x8, [sp, #184]
	stur	q3, [x20, #168]
	ldur	q0, [x0, #88]
	str	q0, [sp, #192]
	ldr	x8, [sp, #112]
	ldr	x10, [sp, #160]
	stp	x9, x8, [sp, #208]
	cbz	x10, LBB149_2
; %bb.1:                                ; %slots.release.drop.6.i.i
	ldr	x0, [sp, #168]
	bl	_free
LBB149_2:                               ; %"wf_std.collections.hash_map.hash_map_free$instance$062aa17160873f66.exit"
	ldr	x8, [sp, #200]
	cbz	x8, LBB149_4
; %bb.3:                                ; %slots.release.drop.6.i.i2
	ldr	x0, [sp, #208]
	bl	_free
LBB149_4:                               ; %"wf_collections.priority_queue.priority_queue_free$instance$45ff9783f97b77eb.exit"
	add	x0, x20, #120
	mov	x1, x19
	bl	_wf_std.collections.slab.slab_free$instance$7c376bc3f4ad4ade
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #256]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #240]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #224]            ; 16-byte Folded Reload
	add	sp, sp, #272
	ret
                                        ; -- End function
	.globl	_wf_record_store_new$instance$f8195bc386aec277 ; -- Begin function wf_record_store_new$instance$f8195bc386aec277
	.p2align	2
_wf_record_store_new$instance$f8195bc386aec277: ; @"wf_record_store_new$instance$f8195bc386aec277"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #208
	stp	x26, x25, [sp, #128]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #144]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #160]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #176]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #192]            ; 16-byte Folded Spill
	.cfi_def_cfa_offset 208
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	mov	x19, x6
	mov	x22, x5
	mov	x24, x4
	mov	x25, x3
	mov	x21, x2
	mov	x23, x1
	mov	x20, x0
	cbz	x3, LBB150_2
; %bb.1:                                ; %window.payload.allocate.v1.i.i.i
	lsl	x8, x25, #7
	sub	x0, x8, x25, lsl #4
	bl	_malloc
	cbnz	x0, LBB150_3
	b	LBB150_10
LBB150_2:
Lloh340:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh341:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB150_3:                               ; %"wf_std.collections.slab.slab_new$instance$b7e941dde1ad180f.exit"
	stp	xzr, x25, [sp]
	stp	x0, x25, [sp, #16]
	cbz	x24, LBB150_7
; %bb.4:                                ; %window.payload.allocate.v1.i.i.i2
	lsl	x0, x24, #5
	bl	_malloc
	cbz	x0, LBB150_10
; %bb.5:                                ; %bb5.i.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #8
LBB150_6:                               ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x9, #8]
	str	xzr, [x9], #32
	cmp	x24, x8
	b.ne	LBB150_6
	b	LBB150_8
LBB150_7:
Lloh342:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh343:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB150_8:                               ; %"wf_std.collections.hash_map.hash_map_new$instance$615fa5221ee98b49.exit"
	stp	x24, x24, [sp, #32]
	stp	xzr, xzr, [sp, #56]
	str	x0, [sp, #48]
	cbz	x22, LBB150_11
; %bb.9:                                ; %window.payload.allocate.v1.i.i
	lsl	x0, x22, #5
	bl	_malloc
	cbnz	x0, LBB150_12
LBB150_10:                              ; %window.block.oom.v1.i.i.i
	bl	l_wf_resource_abort
LBB150_11:
Lloh344:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh345:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB150_12:                              ; %"wf_box_slots_new$instance$57d99a800120d980.exit"
	mov	x8, sp
	stp	xzr, x22, [sp, #72]
	stp	x0, xzr, [sp, #88]
	stp	x22, x0, [sp, #104]
	stp	x23, xzr, [x20]
	and	w9, w21, #0x1
	strb	w9, [x20, #8]
	ldp	q0, q1, [sp]
	stp	q0, q1, [x20, #16]
	ldp	q0, q1, [x8, #32]
	stp	q0, q1, [x20, #48]
	ldur	x8, [x8, #64]
	str	x8, [x20, #80]
	ldr	q0, [sp, #96]
	stur	q0, [x20, #88]
	stp	x0, x19, [x20, #104]
	ldp	x29, x30, [sp, #192]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #176]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #160]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #144]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #128]            ; 16-byte Folded Reload
	add	sp, sp, #208
	ret
	.loh AdrpAdd	Lloh340, Lloh341
	.loh AdrpAdd	Lloh342, Lloh343
	.loh AdrpAdd	Lloh344, Lloh345
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_indexed_accept$instance$276fd431a73a5d55 ; -- Begin function wf_indexed_accept$instance$276fd431a73a5d55
	.p2align	2
_wf_indexed_accept$instance$276fd431a73a5d55: ; @"wf_indexed_accept$instance$276fd431a73a5d55"
; %bb.0:                                ; %entry
	sub	sp, sp, #336
	stp	x26, x25, [sp, #256]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #272]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #288]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #304]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #320]            ; 16-byte Folded Spill
	mov	x21, x5
	mov	x19, x4
	mov	x22, x3
	mov	x20, x2
	mov	x23, x1
	mov	x24, x0
	ldp	q0, q1, [x6]
	add	x25, sp, #72
	stur	q0, [x25, #104]
	stur	q1, [x25, #120]
	ldp	q0, q1, [x6, #32]
	stur	q0, [x25, #136]
	stur	q1, [x25, #152]
	str	x4, [x2, x5, lsl #3]
	str	x4, [x25, #96]
	strb	wzr, [sp, #240]
	mov	w8, #8                          ; =0x8
	str	x8, [x25, #176]
	add	x0, sp, #72
	add	x1, x24, #16
	add	x2, sp, #168
	bl	_wf_std.collections.slab.slab_insert$instance$b7e941dde1ad180f
	ldr	w8, [sp, #72]
	cbz	w8, LBB151_2
; %bb.1:                                ; %bb3
	ldr	x8, [sp, #104]
	ldp	q0, q1, [sp, #112]
	stp	q0, q1, [sp, #32]
	ldr	x9, [x25, #72]
	stp	x9, x19, [sp, #64]
	ldur	q2, [sp, #88]
	stur	q0, [sp, #104]
	stur	q1, [sp, #120]
	str	x9, [sp, #136]
	ldr	x9, [x20, #1304]
	add	x9, x9, #1
	str	x9, [x20, #1304]
	stur	q2, [sp, #80]
	str	x8, [sp, #96]
	strb	wzr, [sp, #144]
	mov	w8, #8                          ; =0x8
	str	x8, [x25, #80]
	add	x1, sp, #72
	mov	x0, x20
	bl	_wf_indexed_release$instance$68c9432c50ad41ad
	b	LBB151_3
LBB151_2:                               ; %bb2
	ldr	x8, [x24]
	ldur	q0, [sp, #80]
	add	x9, x23, x22, lsl #6
	mov	w10, #1                         ; =0x1
	strb	w10, [sp, #24]
	strb	wzr, [sp, #16]
	strb	wzr, [sp, #15]
	strb	w10, [x9]
	stp	x19, x21, [x9, #8]
	strh	wzr, [x9, #24]
	stp	xzr, x8, [x9, #32]
	str	q0, [x9, #48]
LBB151_3:                               ; %bb1
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #320]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #304]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #288]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #272]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #256]            ; 16-byte Folded Reload
	add	sp, sp, #336
	ret
                                        ; -- End function
	.globl	_wf_indexed_attach$instance$e1380248266a9ad2 ; -- Begin function wf_indexed_attach$instance$e1380248266a9ad2
	.p2align	2
_wf_indexed_attach$instance$e1380248266a9ad2: ; @"wf_indexed_attach$instance$e1380248266a9ad2"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #80
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 80
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x20, x2
	mov	x19, x1
	add	x21, x1, x3, lsl #6
	ldr	x22, [x21, #8]
	ldur	q0, [x21, #40]
	str	q0, [sp]
	ldr	x8, [x21, #56]
	str	x8, [sp, #16]
	mov	x1, sp
	bl	_wf_record_store_attach$instance$f8195bc386aec277
	cbz	w0, LBB152_2
; %bb.1:                                ; %bb13.i
	ldr	x8, [x20, #1304]
	add	x8, x8, #1
	str	x8, [x20, #1304]
LBB152_2:                               ; %bb2.preheader
	add	x8, x19, #24
	mov	w9, #32                         ; =0x20
	b	LBB152_4
LBB152_3:                               ; %bb8
                                        ;   in Loop: Header=BB152_4 Depth=1
	add	x8, x8, #64
	subs	x9, x9, #1
	b.eq	LBB152_6
LBB152_4:                               ; %bb2
                                        ; =>This Inner Loop Header: Depth=1
	ldur	x10, [x8, #-16]
	cmp	x10, x22
	b.ne	LBB152_3
; %bb.5:                                ; %bb6
                                        ;   in Loop: Header=BB152_4 Depth=1
	strb	wzr, [x8]
	b	LBB152_3
LBB152_6:                               ; %bb4
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #24]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_indexed_schedule$instance$e1380248266a9ad2 ; -- Begin function wf_indexed_schedule$instance$e1380248266a9ad2
	.p2align	2
_wf_indexed_schedule$instance$e1380248266a9ad2: ; @"wf_indexed_schedule$instance$e1380248266a9ad2"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #80
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 80
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x4
	mov	x20, x2
	add	x21, x1, x3, lsl #6
	ldur	q0, [x21, #40]
	str	q0, [sp]
	ldr	x8, [x21, #56]
	str	x8, [sp, #16]
	mov	x1, sp
	mov	x2, x4
	bl	_wf_record_store_schedule$instance$f8195bc386aec277
	cbz	w0, LBB153_2
; %bb.1:                                ; %bb13.i
	ldr	x8, [x20, #1304]
	add	x8, x8, #1
	str	x8, [x20, #1304]
LBB153_2:                               ; %wf_indexed_status.exit
	mov	w8, #1                          ; =0x1
	strb	w8, [x21, #25]
	str	x19, [x21, #32]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_indexed_check$instance$276fd431a73a5d55
lCPI154_0:
	.quad	22                              ; 0x16
	.quad	33                              ; 0x21
lCPI154_1:
	.quad	44                              ; 0x2c
	.quad	55                              ; 0x37
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_indexed_check$instance$276fd431a73a5d55
	.p2align	2
_wf_indexed_check$instance$276fd431a73a5d55: ; @"wf_indexed_check$instance$276fd431a73a5d55"
; %bb.0:                                ; %entry
	sub	sp, sp, #32
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	mov	x8, #0                          ; =0x0
	ldr	x9, [x0]
	ldr	x10, [x0, #112]
	ldr	x13, [x2, #1304]
	add	x11, x1, #24
	mov	w12, #112                       ; =0x70
Lloh346:
	adrp	x14, lCPI154_0@PAGE
Lloh347:
	ldr	q0, [x14, lCPI154_0@PAGEOFF]
Lloh348:
	adrp	x14, lCPI154_1@PAGE
Lloh349:
	ldr	q1, [x14, lCPI154_1@PAGEOFF]
	b	LBB154_4
LBB154_1:                               ; %bb13.i147
                                        ;   in Loop: Header=BB154_4 Depth=1
	add	x13, x13, #1
LBB154_2:                               ; %bb79.sink.split
                                        ;   in Loop: Header=BB154_4 Depth=1
	str	x13, [x2, #1304]
LBB154_3:                               ; %bb79
                                        ;   in Loop: Header=BB154_4 Depth=1
	add	x8, x8, #1
	cmp	x8, #32
	b.eq	LBB154_59
LBB154_4:                               ; %bb2
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB154_18 Depth 2
                                        ;     Child Loop BB154_24 Depth 2
	add	x16, x1, x8, lsl #6
	ldr	x4, [x16, #16]
	cbz	x4, LBB154_3
; %bb.5:                                ; %bb6
                                        ;   in Loop: Header=BB154_4 Depth=1
	ldr	x14, [x16, #8]
	ldr	x15, [x16, #40]
	cmp	x15, x9
	b.ne	LBB154_15
; %bb.6:                                ; %bb3.i
                                        ;   in Loop: Header=BB154_4 Depth=1
	ldrb	w6, [x16]
	ldr	x15, [x16, #48]
	ldr	x17, [x0, #16]
	cmp	x15, x17
	b.hs	LBB154_14
; %bb.7:                                ; %bb2.i.i
                                        ;   in Loop: Header=BB154_4 Depth=1
	ldr	x17, [x16, #56]
	ldr	x3, [x0, #32]
	madd	x5, x15, x12, x3
	ldr	x3, [x5, #96]
	cmp	x3, x17
	b.ne	LBB154_14
; %bb.8:                                ; %bb5.i.i
                                        ;   in Loop: Header=BB154_4 Depth=1
	ldr	x3, [x5]
	cbz	x3, LBB154_14
; %bb.9:                                ; %bb9
                                        ;   in Loop: Header=BB154_4 Depth=1
	ldrb	w7, [x16, #24]
	ldrb	w16, [x16, #25]
	ldr	x3, [x5, #8]
	ldrb	w19, [x5, #80]
	and	w19, w19, #0x1
	strb	w19, [sp, #8]
	tbz	w6, #0, LBB154_15
; %bb.10:                               ; %bb12
                                        ;   in Loop: Header=BB154_4 Depth=1
	cmp	x3, x14
	b.eq	LBB154_12
; %bb.11:                               ; %bb15
                                        ;   in Loop: Header=BB154_4 Depth=1
	add	x13, x13, #1
	str	x13, [x2, #1304]
LBB154_12:                              ; %bb14
                                        ;   in Loop: Header=BB154_4 Depth=1
	tbz	w19, #0, LBB154_42
; %bb.13:                               ; %bb18
                                        ;   in Loop: Header=BB154_4 Depth=1
	tbz	w7, #0, LBB154_43
	b	LBB154_44
LBB154_14:                              ; %bb10
                                        ;   in Loop: Header=BB154_4 Depth=1
	tbz	w6, #0, LBB154_16
LBB154_15:                              ; %bb8.sink.split
                                        ;   in Loop: Header=BB154_4 Depth=1
	add	x13, x13, #1
	str	x13, [x2, #1304]
LBB154_16:                              ; %bb8
                                        ;   in Loop: Header=BB154_4 Depth=1
	mov	x16, #0                         ; =0x0
	mov	x17, x11
	mov	w15, #32                        ; =0x20
	b	LBB154_18
LBB154_17:                              ; %bb54
                                        ;   in Loop: Header=BB154_18 Depth=2
	add	x16, x16, #1
	add	x17, x17, #64
	cmp	x16, #32
	b.eq	LBB154_20
LBB154_18:                              ; %bb45
                                        ;   Parent Loop BB154_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldur	x3, [x17, #-16]
	cmp	x3, x14
	b.ne	LBB154_17
; %bb.19:                               ; %bb49
                                        ;   in Loop: Header=BB154_18 Depth=2
	ldrb	w3, [x17]
	cmp	w3, #0
	csel	x15, x16, x15, ne
	b	LBB154_17
LBB154_20:                              ; %bb47
                                        ;   in Loop: Header=BB154_4 Depth=1
	cbz	x10, LBB154_37
; %bb.21:                               ; %bb3.i.i.i92
                                        ;   in Loop: Header=BB154_4 Depth=1
	udiv	x16, x14, x10
	msub	x17, x16, x10, x14
	ldr	x16, [x0, #48]
	cbz	x16, LBB154_38
LBB154_22:                              ; %bb3.i.i93
                                        ;   in Loop: Header=BB154_4 Depth=1
	udiv	x3, x17, x16
	msub	x17, x3, x16, x17
	ldr	x3, [x0, #64]
	mov	x4, x16
	b	LBB154_24
LBB154_23:                              ; %bb8.i.i98
                                        ;   in Loop: Header=BB154_24 Depth=2
	add	x5, x17, #1
	cmp	x5, x16
	csinc	x17, xzr, x17, hs
	subs	x4, x4, #1
	b.eq	LBB154_36
LBB154_24:                              ; %bb5.i.i96
                                        ;   Parent Loop BB154_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x5, x3, x17, lsl #5
	ldr	w6, [x5]
	cmp	w6, #1
	b.eq	LBB154_23
; %bb.25:                               ; %bb5.i.i96
                                        ;   in Loop: Header=BB154_24 Depth=2
	cmp	w6, #2
	b.ne	LBB154_36
; %bb.26:                               ; %bb9.i.i
                                        ;   in Loop: Header=BB154_24 Depth=2
	ldr	x6, [x5, #8]
	cmp	x6, x14
	b.ne	LBB154_23
; %bb.27:                               ; %bb3.i120.i
                                        ;   in Loop: Header=BB154_4 Depth=1
	ldr	x16, [x5, #16]
	ldr	x17, [x0, #16]
	cmp	x16, x17
	b.hs	LBB154_39
; %bb.28:                               ; %bb2.i.i.i
                                        ;   in Loop: Header=BB154_4 Depth=1
	ldr	x17, [x5, #24]
	ldr	x3, [x0, #32]
	madd	x3, x16, x12, x3
	ldr	x4, [x3, #96]
	cmp	x4, x17
	b.ne	LBB154_39
; %bb.29:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB154_4 Depth=1
	ldr	x4, [x3]
	cbz	x4, LBB154_39
; %bb.30:                               ; %bb3.i104
                                        ;   in Loop: Header=BB154_4 Depth=1
	ldr	x3, [x3, #8]
	cmp	x3, x14
	b.ne	LBB154_57
; %bb.31:                               ; %bb56
                                        ;   in Loop: Header=BB154_4 Depth=1
	cmp	x15, #32
	b.hs	LBB154_1
; %bb.32:                               ; %bb59
                                        ;   in Loop: Header=BB154_4 Depth=1
	add	x3, x1, x15, lsl #6
	ldp	x14, x15, [x3, #40]
	ldr	x4, [x3, #56]
	cmp	x15, x16
	cinc	x13, x13, ne
	cmp	x4, x17
	cinc	x13, x13, ne
	cmp	x14, x9
	cinc	x13, x13, ne
	ldrb	w3, [x3]
	eor	w3, w3, #0x1
	and	x5, x3, #0x1
	add	x13, x13, x5
	cmp	x4, x17
	b.ne	LBB154_2
; %bb.33:                               ; %bb59
                                        ;   in Loop: Header=BB154_4 Depth=1
	tbnz	w3, #0, LBB154_2
; %bb.34:                               ; %bb59
                                        ;   in Loop: Header=BB154_4 Depth=1
	cmp	x15, x16
	b.ne	LBB154_2
; %bb.35:                               ; %bb59
                                        ;   in Loop: Header=BB154_4 Depth=1
	cmp	x14, x9
	b.eq	LBB154_3
	b	LBB154_2
LBB154_36:                              ;   in Loop: Header=BB154_4 Depth=1
	mov	w14, #0                         ; =0x0
	mov	w16, #0                         ; =0x0
	cmp	x15, #32
	b.lo	LBB154_40
	b	LBB154_58
LBB154_37:                              ;   in Loop: Header=BB154_4 Depth=1
	mov	x17, #0                         ; =0x0
	ldr	x16, [x0, #48]
	cbnz	x16, LBB154_22
LBB154_38:                              ;   in Loop: Header=BB154_4 Depth=1
	mov	w14, #0                         ; =0x0
	cmp	x15, #32
	b.lo	LBB154_40
	b	LBB154_58
LBB154_39:                              ;   in Loop: Header=BB154_4 Depth=1
	mov	w14, #1                         ; =0x1
	mov	w16, #1                         ; =0x1
	cmp	x15, #32
	b.hs	LBB154_58
LBB154_40:                              ; %bb74
                                        ;   in Loop: Header=BB154_4 Depth=1
	lsl	x14, x15, #6
	ldrb	w14, [x1, x14]
	tbnz	w14, #0, LBB154_1
; %bb.41:                               ; %bb78
                                        ;   in Loop: Header=BB154_4 Depth=1
	tbz	w16, #0, LBB154_1
	b	LBB154_3
LBB154_42:                              ; %bb19
                                        ;   in Loop: Header=BB154_4 Depth=1
	tbz	w7, #0, LBB154_44
LBB154_43:                              ; %bb8.i.i.i.i.sink.split
                                        ;   in Loop: Header=BB154_4 Depth=1
	add	x13, x13, #1
	str	x13, [x2, #1304]
LBB154_44:                              ; %bb8.i.i.i.i
                                        ;   in Loop: Header=BB154_4 Depth=1
	ldp	x6, x7, [x5, #16]
	ldp	x19, x6, [x6]
	add	x20, x19, #101
	cmp	x6, x20
	csinv	x6, x19, xzr, eq
	add	x19, x6, #11
	cmp	x7, x19
	b.ne	LBB154_48
; %bb.45:                               ; %bb3.i.i.i.i.i.i
                                        ;   in Loop: Header=BB154_4 Depth=1
	dup.2d	v2, x6
	add.2d	v3, v2, v0
	add.2d	v2, v2, v1
	ldp	q4, q5, [x5, #32]
	cmeq.2d	v2, v5, v2
	cmeq.2d	v3, v4, v3
	uzp1.4s	v2, v3, v2
	xtn.4h	v2, v2
	uminv.4h	h2, v2
	fmov	w19, s2
	mov	x7, #-1                         ; =0xffffffffffffffff
	tbz	w19, #0, LBB154_49
; %bb.46:                               ; %bb3.i.i.i.i.i.i
                                        ;   in Loop: Header=BB154_4 Depth=1
	add	x19, x6, #66
	ldr	x20, [x5, #64]
	cmp	x20, x19
	b.ne	LBB154_49
; %bb.47:                               ; %bb18.i.i.i.i.i.i
                                        ;   in Loop: Header=BB154_4 Depth=1
	add	x7, x6, #77
	ldr	x19, [x5, #72]
	cmp	x19, x7
	csinv	x7, x6, xzr, eq
	b	LBB154_49
LBB154_48:                              ;   in Loop: Header=BB154_4 Depth=1
	mov	x7, #-1                         ; =0xffffffffffffffff
LBB154_49:                              ; %bb27
                                        ;   in Loop: Header=BB154_4 Depth=1
	cmp	x7, x4
	b.eq	LBB154_51
; %bb.50:                               ; %bb30
                                        ;   in Loop: Header=BB154_4 Depth=1
	add	x13, x13, #1
	str	x13, [x2, #1304]
LBB154_51:                              ; %bb2.i.i52
                                        ;   in Loop: Header=BB154_4 Depth=1
	ldr	x4, [x5, #88]
	cmp	x4, #8
	b.ne	LBB154_53
; %bb.52:                               ; %bb34.thread
                                        ;   in Loop: Header=BB154_4 Depth=1
	tbnz	w16, #0, LBB154_15
	b	LBB154_16
LBB154_53:                              ; %bb6.i.i
                                        ;   in Loop: Header=BB154_4 Depth=1
	ldr	x5, [x0, #88]
	cmp	x4, x5
	b.hs	LBB154_15
; %bb.54:                               ; %bb8.i.i
                                        ;   in Loop: Header=BB154_4 Depth=1
	ldr	x5, [x0, #104]
	add	x4, x5, x4, lsl #5
	ldp	x5, x6, [x4, #16]
	cmp	x5, x15
	ccmp	x6, x17, #0, eq
	b.ne	LBB154_15
; %bb.55:                               ; %bb11.i.i
                                        ;   in Loop: Header=BB154_4 Depth=1
	ldr	x15, [x4, #8]
	cmp	x15, x3
	b.ne	LBB154_15
; %bb.56:                               ; %bb11.i.i
                                        ;   in Loop: Header=BB154_4 Depth=1
	tbnz	w16, #0, LBB154_16
	b	LBB154_15
LBB154_57:                              ;   in Loop: Header=BB154_4 Depth=1
	mov	w16, #0                         ; =0x0
	mov	w14, #1                         ; =0x1
	cmp	x15, #32
	b.lo	LBB154_40
LBB154_58:                              ; %bb75
                                        ;   in Loop: Header=BB154_4 Depth=1
	cbnz	w14, LBB154_1
	b	LBB154_3
LBB154_59:                              ; %bb4
	mov	w0, #0                          ; =0x0
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #32
	ret
	.loh AdrpLdr	Lloh348, Lloh349
	.loh AdrpAdrp	Lloh346, Lloh348
	.loh AdrpLdr	Lloh346, Lloh347
                                        ; -- End function
	.globl	_wf_record_store_attach$instance$f8195bc386aec277 ; -- Begin function wf_record_store_attach$instance$f8195bc386aec277
	.p2align	2
_wf_record_store_attach$instance$f8195bc386aec277: ; @"wf_record_store_attach$instance$f8195bc386aec277"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	sub	sp, sp, #448
	.cfi_def_cfa_offset 512
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	ldr	q0, [x1]
	str	q0, [sp]
	ldr	x8, [x1, #16]
	str	x8, [sp, #16]
	ldr	x9, [sp]
	ldr	x10, [x0]
	cmp	x9, x10
	b.ne	LBB155_6
; %bb.1:                                ; %bb3.i
	ldr	x11, [sp, #8]
	ldr	x10, [x0, #16]
	cmp	x11, x10
	b.hs	LBB155_32
; %bb.2:                                ; %bb2.i.i
	ldr	x9, [x0, #32]
	mov	w12, #112                       ; =0x70
	madd	x11, x11, x12, x9
	ldr	x12, [x11, #96]
	cmp	x12, x8
	b.ne	LBB155_32
; %bb.3:                                ; %bb5.i.i
	ldr	x8, [x11]
	cbz	x8, LBB155_32
; %bb.4:                                ; %bb2
	mov	x22, sp
	ldr	x8, [x11, #8]
	ldrb	w12, [x11, #80]
	ldr	x11, [x11, #88]
	and	w12, w12, #0x1
	strb	w12, [sp, #432]
	stp	xzr, x8, [sp, #24]
	strb	w12, [sp, #40]
	stur	wzr, [sp, #41]
	str	wzr, [sp, #44]
	ldr	q0, [sp, #32]
	str	q0, [sp, #80]
	str	x11, [sp, #96]
	ldr	x8, [sp, #80]
	ldrb	w12, [sp, #88]
	stp	x11, x8, [sp, #48]
	strb	w12, [sp, #64]
	str	x11, [sp, #72]
	str	x11, [x22, #416]
	ldur	q0, [sp, #56]
	str	q0, [x22, #400]
	ldrb	w8, [x22, #408]
	cmp	w8, #1
	b.ne	LBB155_7
LBB155_5:
	mov	w0, #1                          ; =0x1
	b	LBB155_33
LBB155_6:
	mov	w0, #4                          ; =0x4
	b	LBB155_33
LBB155_7:                               ; %bb6
	mov	x19, x0
	ldr	x8, [x19, #112]!
	sub	x20, x19, #64
	cbz	x8, LBB155_20
; %bb.8:                                ; %bb3.i.i
	ldr	x11, [sp, #400]
	udiv	x12, x11, x8
	msub	x12, x12, x8, x11
	ldr	x8, [x20]
	cbz	x8, LBB155_21
LBB155_9:                               ; %bb3.i12
	add	x11, x22, #184
	udiv	x13, x12, x8
	msub	x12, x13, x8, x12
	ldr	x13, [x0, #64]
	ldr	x21, [sp, #400]
	mov	x14, x8
	b	LBB155_11
LBB155_10:                              ; %bb8.i
                                        ;   in Loop: Header=BB155_11 Depth=1
	add	x15, x12, #1
	cmp	x15, x8
	csinc	x12, xzr, x12, hs
	subs	x14, x14, #1
	b.eq	LBB155_19
LBB155_11:                              ; %bb5.i13
                                        ; =>This Inner Loop Header: Depth=1
	add	x15, x13, x12, lsl #5
	ldr	w16, [x15]
	cmp	w16, #1
	b.eq	LBB155_10
; %bb.12:                               ; %bb5.i13
                                        ;   in Loop: Header=BB155_11 Depth=1
	cmp	w16, #2
	b.ne	LBB155_19
; %bb.13:                               ; %bb9.i
                                        ;   in Loop: Header=BB155_11 Depth=1
	ldr	x16, [x15, #8]
	cmp	x16, x21
	b.ne	LBB155_10
; %bb.14:                               ; %bb8
	str	xzr, [sp, #104]
	ldr	q0, [x15, #16]
	str	q0, [sp, #112]
	ldr	q0, [sp, #112]
	ldur	q1, [x1, #8]
	stp	q0, q1, [x22, #128]
	ldp	x12, x13, [sp, #128]
	ldr	x14, [sp, #144]
	cmp	x12, x14
	b.ne	LBB155_16
; %bb.15:                               ; %bb8
	ldr	x14, [sp, #152]
	cmp	x13, x14
	b.eq	LBB155_5
LBB155_16:                              ; %bb12
	cmp	x12, x10
	b.hs	LBB155_34
; %bb.17:                               ; %bb2.i.i21
	mov	w10, #112                       ; =0x70
	madd	x9, x12, x10, x9
	ldr	x10, [x9, #96]
	cmp	x10, x13
	b.ne	LBB155_34
; %bb.18:                               ; %"wf_std.collections.slab.slab_find_index$instance$b7e941dde1ad180f.exit"
	ldr	x9, [x9]
	cmp	x9, #0
	csel	x10, xzr, x12, eq
	cset	w12, eq
	str	w12, [sp, #160]
	str	x10, [sp, #168]
	strb	wzr, [sp, #176]
	cbnz	x9, LBB155_36
	b	LBB155_35
LBB155_19:                              ; %bb10.i
	stp	xzr, xzr, [x22, #104]
	stur	xzr, [x22, #120]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #104]
	b	LBB155_22
LBB155_20:
	mov	x12, #0                         ; =0x0
	ldr	x8, [x20]
	cbnz	x8, LBB155_9
LBB155_21:                              ; %bb2.i14
	stp	xzr, xzr, [x22, #104]
	stur	xzr, [x22, #120]
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #104]
	ldr	x21, [sp, #400]
LBB155_22:                              ; %bb7
	ldur	q0, [x1, #8]
	str	q0, [x22, #304]
	ldur	q0, [x1, #8]
	str	q0, [sp, #432]
	ldp	x9, x10, [x0, #72]
	mov	x23, x0
	adds	x10, x9, x10
	csinv	x11, x10, xzr, lo
	cmp	x8, #7
	b.hi	LBB155_25
; %bb.23:                               ; %bb7
	sub	x10, x8, x8, lsr #2
	cmp	x11, x10
	b.lo	LBB155_25
; %bb.24:                               ; %bb2.i16
	mov	w11, #4                         ; =0x4
	cmp	x8, #4
	csel	x11, x8, x11, lo
	lsl	x11, x11, #1
	cmp	x8, #0
	csinc	x11, x11, xzr, ne
	cmp	x9, x10, lsr #1
	csel	x1, x8, x11, lo
	mov	x0, x20
	mov	x2, x19
	bl	_wf_std.collections.hash_map.hash_map_rebuild$instance$cb1167c8d0732e77
LBB155_25:                              ; %"wf_std.collections.hash_map.hash_map_put$instance$cb1167c8d0732e77.exit"
	add	x0, x22, #320
	add	x3, sp, #432
	mov	x1, x20
	mov	x2, x21
	mov	x4, x19
	bl	_wf_std.collections.hash_map.hash_map_try_put$instance$cb1167c8d0732e77
	ldr	w8, [sp, #320]
	cbz	w8, LBB155_28
; %bb.26:                               ; %bb21
	mov	x8, sp
	add	x8, x8, #328
	ldrb	w9, [x22, #324]
	ldr	x10, [sp, #344]
	str	x10, [x22, #368]
	ldr	q0, [x8]
	str	q0, [x22, #352]
	tbz	w9, #0, LBB155_28
; %bb.27:
	mov	w0, #6                          ; =0x6
	b	LBB155_33
LBB155_28:                              ; %bb19
	add	x8, x22, #376
	orr	x9, x22, #0x8
	mov	w10, #1                         ; =0x1
	strb	w10, [x22, #424]
	ldr	q0, [x9]
	str	q0, [x8]
	ldr	x8, [sp, #376]
	ldr	x9, [x23, #16]
	cmp	x8, x9
	b.hs	LBB155_32
; %bb.29:                               ; %bb2.i.i37
	ldr	x9, [sp, #384]
	ldr	x10, [x23, #32]
	mov	w11, #112                       ; =0x70
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #96]
	cmp	x10, x9
	b.ne	LBB155_32
; %bb.30:                               ; %bb5.i.i47
	ldr	x9, [x8]
	cbz	x9, LBB155_32
; %bb.31:                               ; %bb8.i.i
	mov	w0, #0                          ; =0x0
	mov	w9, #1                          ; =0x1
	strb	w9, [x8, #80]
	b	LBB155_33
LBB155_32:                              ; %bb5.i
	mov	w0, #3                          ; =0x3
LBB155_33:                              ; %common.ret
	add	sp, sp, #448
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB155_34:                              ; %"wf_std.collections.slab.slab_find_index$instance$b7e941dde1ad180f.exit.thread"
	mov	w9, #1                          ; =0x1
	str	w9, [sp, #160]
	str	xzr, [sp, #168]
	strb	wzr, [sp, #176]
LBB155_35:                              ; %bb15
	ldp	q0, q1, [x0]
	stp	q0, q1, [x11]
	ldp	q0, q1, [x0, #32]
	stp	q0, q1, [x11, #32]
	ldr	x9, [x0, #112]
	str	x9, [x11, #112]
	ldp	q0, q1, [x0, #80]
	stp	q0, q1, [x11, #80]
	ldr	q1, [x0, #64]
	str	q1, [x11, #64]
	ldrb	w9, [sp, #192]
	tbz	w9, #0, LBB155_22
LBB155_36:
	mov	w0, #5                          ; =0x5
	b	LBB155_33
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_record_store_schedule$instance$f8195bc386aec277 ; -- Begin function wf_record_store_schedule$instance$f8195bc386aec277
	.p2align	2
_wf_record_store_schedule$instance$f8195bc386aec277: ; @"wf_record_store_schedule$instance$f8195bc386aec277"
	.cfi_startproc
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.ne	LBB156_7
; %bb.1:                                ; %bb3.i
	sub	sp, sp, #96
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 96
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	ldr	x8, [x1, #8]
	mov	x19, x0
	ldr	x22, [x19, #16]!
	cmp	x8, x22
	b.hs	LBB156_8
; %bb.2:                                ; %bb2.i.i
	ldr	x9, [x1, #16]
	ldr	x21, [x0, #32]
	mov	w10, #112                       ; =0x70
	madd	x10, x8, x10, x21
	ldr	x11, [x10, #96]
	cmp	x11, x9
	b.ne	LBB156_8
; %bb.3:                                ; %bb5.i.i
	ldr	x11, [x10]
	cbz	x11, LBB156_8
; %bb.4:                                ; %bb2
	ldr	x23, [x10, #8]
	ldr	x10, [x10, #88]
	cmp	x10, #8
	b.ne	LBB156_10
; %bb.5:                                ; %bb6
	ldur	q0, [x1, #8]
	str	q0, [sp]
	ldur	x20, [x0, #88]
	cmp	x20, #7
	b.ls	LBB156_13
; %bb.6:
	mov	w0, #6                          ; =0x6
	b	LBB156_9
LBB156_7:
	mov	w0, #4                          ; =0x4
	ret
LBB156_8:
	mov	w0, #3                          ; =0x3
LBB156_9:
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
LBB156_10:                              ; %bb2.i.i4
	ldur	x11, [x0, #88]
	cmp	x10, x11
	b.hs	LBB156_18
; %bb.11:                               ; %bb8.i.i
	ldr	x11, [x0, #104]
	add	x10, x11, x10, lsl #5
	ldp	x11, x12, [x10, #16]
	mov	w0, #8                          ; =0x8
	cmp	x11, x8
	ccmp	x12, x9, #0, eq
	b.ne	LBB156_9
; %bb.12:                               ; %bb11.i.i
	ldr	x8, [x10, #8]
	cmp	x8, x23
	csinc	w0, w0, wzr, ne
	b	LBB156_9
LBB156_13:                              ; %bb3.i6
	mov	x24, x0
	add	x0, x0, #88
	mov	x25, x2
	bl	_wf_collections.priority_queue.priority_queue_make_room$instance$8d53fd32336043f5
	mov	x8, x24
	ldr	x9, [x24, #88]
	ldr	x10, [x24, #104]
	add	x11, x10, x9, lsl #5
	stp	x25, x23, [x11]
	ldr	q0, [sp]
	str	q0, [x11, #16]
	add	x9, x9, #1
	str	x9, [x24, #88]
	add	x10, x10, x20, lsl #5
	ldr	x9, [x10, #16]
	cmp	x9, x22
	b.hs	LBB156_17
; %bb.14:                               ; %bb2.i.i.i.i10
	ldr	x10, [x10, #24]
	mov	w11, #112                       ; =0x70
	madd	x9, x9, x11, x21
	ldr	x11, [x9, #96]
	cmp	x11, x10
	b.ne	LBB156_17
; %bb.15:                               ; %bb5.i.i.i.i18
	ldr	x10, [x9]
	cbz	x10, LBB156_17
; %bb.16:                               ; %bb8.i.i.i.i
	str	x20, [x9, #88]
LBB156_17:                              ; %"wf_collections.priority_queue.priority_queue_push_indexed$instance$d383295a38079908.exit.thread"
	add	x0, x8, #88
	mov	x1, x20
	mov	x4, x19
	bl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$d383295a38079908
	mov	w0, #0                          ; =0x0
	b	LBB156_9
LBB156_18:
	mov	w0, #8                          ; =0x8
	b	LBB156_9
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_indexed_cancel_position$instance$276fd431a73a5d55 ; -- Begin function wf_indexed_cancel_position$instance$276fd431a73a5d55
	.p2align	2
_wf_indexed_cancel_position$instance$276fd431a73a5d55: ; @"wf_indexed_cancel_position$instance$276fd431a73a5d55"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #96
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 96
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x2
	mov	x20, x0
	mov	x8, #0                          ; =0x0
	ldr	x9, [x0]
	ldr	x23, [x2, #1304]
	add	x11, x1, #56
	mov	w10, #32                        ; =0x20
	mov	w12, #112                       ; =0x70
	b	LBB157_3
LBB157_1:                               ; %bb10
                                        ;   in Loop: Header=BB157_3 Depth=1
	add	x23, x23, #1
	str	x23, [x19, #1304]
LBB157_2:                               ; %bb14
                                        ;   in Loop: Header=BB157_3 Depth=1
	add	x8, x8, #1
	add	x11, x11, #64
	cmp	x8, #32
	b.eq	LBB157_9
LBB157_3:                               ; %bb2
                                        ; =>This Inner Loop Header: Depth=1
	ldurb	w13, [x11, #-56]
	tbz	w13, #0, LBB157_2
; %bb.4:                                ; %bb6
                                        ;   in Loop: Header=BB157_3 Depth=1
	ldur	x13, [x11, #-16]
	cmp	x13, x9
	b.ne	LBB157_1
; %bb.5:                                ; %bb3.i
                                        ;   in Loop: Header=BB157_3 Depth=1
	ldur	x13, [x11, #-8]
	ldr	x14, [x20, #16]
	cmp	x13, x14
	b.hs	LBB157_1
; %bb.6:                                ; %bb2.i.i
                                        ;   in Loop: Header=BB157_3 Depth=1
	ldr	x14, [x11]
	ldr	x15, [x20, #32]
	madd	x13, x13, x12, x15
	ldr	x15, [x13, #96]
	cmp	x15, x14
	b.ne	LBB157_1
; %bb.7:                                ; %bb5.i.i
                                        ;   in Loop: Header=BB157_3 Depth=1
	ldr	x14, [x13]
	cbz	x14, LBB157_1
; %bb.8:                                ; %bb9
                                        ;   in Loop: Header=BB157_3 Depth=1
	ldr	x13, [x13, #88]
	cmp	x13, x3
	csel	x10, x8, x10, eq
	b	LBB157_2
LBB157_9:                               ; %bb4
	cmp	x10, #32
	b.hs	LBB157_15
; %bb.10:                               ; %bb16
	mov	x22, x1
	add	x24, x1, x10, lsl #6
	ldr	x21, [x24, #32]
	ldur	q0, [x24, #40]
	str	q0, [sp]
	ldr	x8, [x24, #56]
	str	x8, [sp, #16]
	mov	x1, sp
	mov	x0, x20
	bl	_wf_record_store_cancel$instance$f8195bc386aec277
	cbz	w0, LBB157_12
; %bb.11:                               ; %bb13.i.i
	add	x8, x23, #1
	str	x8, [x19, #1304]
LBB157_12:                              ; %"wf_indexed_cancel$instance$e1380248266a9ad2.exit"
	strb	wzr, [x24, #25]
	mov	x0, x20
	mov	x1, x22
	mov	x2, x19
	bl	_wf_indexed_check$instance$276fd431a73a5d55
	ldur	q0, [x24, #40]
	str	q0, [sp]
	ldur	x8, [x24, #56]
	str	x8, [sp, #16]
	mov	x1, sp
	mov	x0, x20
	mov	x2, x21
	bl	_wf_record_store_schedule$instance$f8195bc386aec277
	cbz	w0, LBB157_14
; %bb.13:                               ; %bb13.i.i10
	ldr	x8, [x19, #1304]
	add	x8, x8, #1
	str	x8, [x19, #1304]
LBB157_14:                              ; %"wf_indexed_schedule$instance$e1380248266a9ad2.exit"
	mov	w8, #1                          ; =0x1
	strb	w8, [x24, #25]
	str	x21, [x24, #32]
	b	LBB157_16
LBB157_15:                              ; %bb17
	add	x8, x23, #1
	str	x8, [x19, #1304]
LBB157_16:                              ; %bb15
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #96
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_record_store_insert$instance$f8195bc386aec277 ; -- Begin function wf_record_store_insert$instance$f8195bc386aec277
	.p2align	2
_wf_record_store_insert$instance$f8195bc386aec277: ; @"wf_record_store_insert$instance$f8195bc386aec277"
; %bb.0:                                ; %entry
	sub	sp, sp, #224
	stp	x20, x19, [sp, #192]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #208]            ; 16-byte Folded Spill
	mov	x20, x1
	mov	x19, x0
	add	x8, sp, #104
	ldp	q0, q1, [x3]
	stp	q0, q1, [sp, #112]
	ldp	q0, q1, [x3, #32]
	stur	q0, [x8, #40]
	str	x2, [sp, #104]
	stur	q1, [x8, #56]
	strb	wzr, [sp, #176]
	mov	w8, #8                          ; =0x8
	str	x8, [sp, #184]
	add	x0, sp, #8
	add	x1, x1, #16
	add	x2, sp, #104
	bl	_wf_std.collections.slab.slab_insert$instance$b7e941dde1ad180f
	ldr	w8, [sp, #8]
	cbz	w8, LBB158_2
; %bb.1:                                ; %bb2
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	ldur	q0, [sp, #24]
	ldur	q1, [sp, #40]
	stur	q0, [x19, #8]
	stur	q1, [x19, #24]
	ldur	q0, [sp, #56]
	ldur	q1, [sp, #72]
	stur	q0, [x19, #40]
	stur	q1, [x19, #56]
	b	LBB158_3
LBB158_2:                               ; %bb1
	ldr	x8, [x20]
	movi.2d	v0, #0000000000000000
	ldur	q1, [sp, #16]
	stp	q0, q1, [x19]
	stp	q0, q0, [x19, #32]
	str	xzr, [x19, #64]
	str	x8, [x19, #8]
LBB158_3:                               ; %common.ret
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #192]            ; 16-byte Folded Reload
	add	sp, sp, #224
	ret
                                        ; -- End function
	.globl	_wf_record_store_cancel$instance$f8195bc386aec277 ; -- Begin function wf_record_store_cancel$instance$f8195bc386aec277
	.p2align	2
_wf_record_store_cancel$instance$f8195bc386aec277: ; @"wf_record_store_cancel$instance$f8195bc386aec277"
; %bb.0:                                ; %entry
	sub	sp, sp, #160
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	ldr	q0, [x1]
	str	q0, [sp]
	ldr	x8, [x1, #16]
	str	x8, [sp, #16]
	ldr	x9, [sp]
	ldr	x10, [x0]
	cmp	x9, x10
	b.ne	LBB159_6
; %bb.1:                                ; %bb3.i.i.i
	ldr	x9, [sp, #8]
	mov	x19, x0
	ldr	x10, [x19, #16]!
	cmp	x9, x10
	b.hs	LBB159_14
; %bb.2:                                ; %bb2.i.i.i.i
	ldr	x10, [x0, #32]
	mov	w11, #112                       ; =0x70
	madd	x10, x9, x11, x10
	ldr	x11, [x10, #96]
	cmp	x11, x8
	b.ne	LBB159_14
; %bb.3:                                ; %bb5.i.i.i.i
	ldr	x11, [x10]
	cbz	x11, LBB159_14
; %bb.4:                                ; %bb2.i.i
	ldr	x2, [x10, #88]
	cmp	x2, #8
	b.ne	LBB159_7
; %bb.5:
	mov	w0, #7                          ; =0x7
	b	LBB159_15
LBB159_6:
	mov	w0, #4                          ; =0x4
	b	LBB159_15
LBB159_7:                               ; %bb6.i.i
	mov	x1, x0
	ldr	x11, [x1, #88]!
	cmp	x2, x11
	b.hs	LBB159_16
; %bb.8:                                ; %bb8.i.i
	ldr	x11, [x0, #104]
	add	x11, x11, x2, lsl #5
	ldp	x12, x13, [x11, #16]
	cmp	x12, x9
	ccmp	x13, x8, #0, eq
	b.ne	LBB159_16
; %bb.9:                                ; %bb11.i.i
	ldr	x8, [x10, #8]
	ldr	x9, [x11, #8]
	cmp	x9, x8
	b.ne	LBB159_16
; %bb.10:                               ; %bb2
	mov	x20, x0
	mov	x8, sp
	orr	x21, x8, #0x8
	add	x0, x8, #48
	add	x3, x8, #104
	mov	x4, x19
	bl	_wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$d383295a38079908
	ldr	q0, [x21]
	str	q0, [sp, #80]
	ldr	x8, [sp, #80]
	ldr	x9, [x19]
	cmp	x8, x9
	b.hs	LBB159_14
; %bb.11:                               ; %bb2.i.i6
	ldr	x9, [sp, #88]
	ldr	x10, [x20, #32]
	mov	w11, #112                       ; =0x70
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #96]
	cmp	x10, x9
	b.ne	LBB159_14
; %bb.12:                               ; %bb5.i.i
	ldr	x9, [x8]
	cbz	x9, LBB159_14
; %bb.13:                               ; %bb8.i.i8
	mov	w0, #0                          ; =0x0
	mov	w9, #8                          ; =0x8
	str	x9, [x8, #88]
	b	LBB159_15
LBB159_14:
	mov	w0, #3                          ; =0x3
LBB159_15:                              ; %common.ret
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB159_16:
	mov	w0, #8                          ; =0x8
	b	LBB159_15
                                        ; -- End function
	.globl	_wf_record_store_reschedule$instance$f8195bc386aec277 ; -- Begin function wf_record_store_reschedule$instance$f8195bc386aec277
	.p2align	2
_wf_record_store_reschedule$instance$f8195bc386aec277: ; @"wf_record_store_reschedule$instance$f8195bc386aec277"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.ne	LBB160_6
; %bb.1:                                ; %bb3.i.i.i
	ldr	x9, [x1, #8]
	mov	x5, x0
	ldr	x8, [x5, #16]!
	cmp	x9, x8
	b.hs	LBB160_7
; %bb.2:                                ; %bb2.i.i.i.i
	ldr	x10, [x1, #16]
	ldr	x8, [x0, #32]
	mov	w11, #112                       ; =0x70
	madd	x11, x9, x11, x8
	ldr	x8, [x11, #96]
	cmp	x8, x10
	b.ne	LBB160_7
; %bb.3:                                ; %bb5.i.i.i.i
	ldr	x8, [x11]
	cbz	x8, LBB160_7
; %bb.4:                                ; %bb2.i.i
	ldr	x8, [x11, #88]
	cmp	x8, #8
	b.ne	LBB160_8
; %bb.5:
	mov	w0, #7                          ; =0x7
	ret
LBB160_6:
	mov	w0, #4                          ; =0x4
	ret
LBB160_7:
	mov	w0, #3                          ; =0x3
	ret
LBB160_8:                               ; %bb6.i.i
	mov	x1, x0
	ldr	x12, [x1, #88]!
	cmp	x8, x12
	b.hs	LBB160_12
; %bb.9:                                ; %bb8.i.i
	ldr	x12, [x0, #104]
	add	x12, x12, x8, lsl #5
	ldp	x13, x14, [x12, #16]
	cmp	x13, x9
	ccmp	x14, x10, #0, eq
	b.ne	LBB160_12
; %bb.10:                               ; %bb11.i.i
	ldr	x9, [x11, #8]
	ldr	x10, [x12, #8]
	cmp	x10, x9
	b.ne	LBB160_12
; %bb.11:                               ; %bb2
	sub	sp, sp, #160
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	ldr	x9, [x0, #104]
	add	x9, x9, x8, lsl #5
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp, #32]
	str	wzr, [sp, #8]
	str	x8, [sp, #16]
	str	wzr, [sp, #24]
	add	x9, sp, #8
	ldr	x10, [sp, #40]
	stur	q1, [sp, #64]
	stp	x2, x10, [sp, #80]
	stur	q1, [sp, #96]
	add	x0, x9, #104
	add	x3, x9, #72
	add	x4, x9, #136
	mov	x2, x8
	bl	_wf_collections.priority_queue.priority_queue_replace_at_indexed$instance$d383295a38079908
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	add	sp, sp, #160
	ret
LBB160_12:
	mov	w0, #8                          ; =0x8
	ret
                                        ; -- End function
	.globl	_wf_record_store_detach$instance$f8195bc386aec277 ; -- Begin function wf_record_store_detach$instance$f8195bc386aec277
	.p2align	2
_wf_record_store_detach$instance$f8195bc386aec277: ; @"wf_record_store_detach$instance$f8195bc386aec277"
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	ldr	x9, [x0]
	cmp	x8, x9
	b.ne	LBB161_3
; %bb.1:                                ; %bb3
	ldr	x8, [x0, #112]
	cbz	x8, LBB161_5
; %bb.2:                                ; %bb3.i.i
	udiv	x9, x1, x8
	msub	x13, x9, x8, x1
	ldr	x11, [x0, #48]
	cbnz	x11, LBB161_6
	b	LBB161_26
LBB161_3:
	mov	w8, #4                          ; =0x4
LBB161_4:                               ; %common.ret
	mov	x0, x8
	ret
LBB161_5:
	mov	x13, #0                         ; =0x0
	ldr	x11, [x0, #48]
	cbz	x11, LBB161_26
LBB161_6:                               ; %bb3.i
	ldp	x10, x9, [x2, #8]
	mov	x12, x11
	udiv	x14, x13, x11
	msub	x14, x14, x11, x13
	ldr	x13, [x0, #64]
	mov	x15, x11
	b	LBB161_8
LBB161_7:                               ; %bb8.i
                                        ;   in Loop: Header=BB161_8 Depth=1
	add	x16, x14, #1
	cmp	x16, x11
	csinc	x14, xzr, x14, hs
	subs	x15, x15, #1
	b.eq	LBB161_26
LBB161_8:                               ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x16, x13, x14, lsl #5
	ldr	w17, [x16]
	cmp	w17, #1
	b.eq	LBB161_7
; %bb.9:                                ; %bb5.i
                                        ;   in Loop: Header=BB161_8 Depth=1
	cmp	w17, #2
	b.ne	LBB161_26
; %bb.10:                               ; %bb9.i
                                        ;   in Loop: Header=BB161_8 Depth=1
	ldr	x17, [x16, #8]
	cmp	x17, x1
	b.ne	LBB161_7
; %bb.11:                               ; %bb4
	ldp	x14, x15, [x16, #16]
	cmp	x14, x10
	ccmp	x15, x9, #0, eq
	b.eq	LBB161_13
; %bb.12:
	mov	w0, #5                          ; =0x5
	ret
LBB161_13:                              ; %bb7
	ldr	x14, [x0, #72]
	cbz	x14, LBB161_26
; %bb.14:                               ; %bb3.i5
	cbz	x8, LBB161_16
; %bb.15:                               ; %bb3.i.i.i.i
	udiv	x15, x1, x8
	msub	x8, x15, x8, x1
LBB161_16:                              ; %bb3.i.i.i
	udiv	x15, x8, x11
	msub	x15, x15, x11, x8
	b	LBB161_18
LBB161_17:                              ; %bb8.i.i.i
                                        ;   in Loop: Header=BB161_18 Depth=1
	add	x8, x15, #1
	cmp	x8, x11
	csinc	x15, xzr, x15, hs
	mov	w8, #2                          ; =0x2
	subs	x12, x12, #1
	b.eq	LBB161_4
LBB161_18:                              ; %bb5.i.i.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x8, x13, x15, lsl #5
	ldr	w16, [x8]
	cmp	w16, #1
	b.eq	LBB161_17
; %bb.19:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB161_18 Depth=1
	cmp	w16, #2
	b.ne	LBB161_26
; %bb.20:                               ; %bb3.i3.i.i.i
                                        ;   in Loop: Header=BB161_18 Depth=1
	ldr	x16, [x8, #8]
	cmp	x16, x1
	b.ne	LBB161_17
; %bb.21:                               ; %bb9
	mov	w11, #1                         ; =0x1
	str	w11, [x8]
	sub	x11, x14, #1
	stp	xzr, xzr, [x8, #16]
	str	xzr, [x8, #8]
	ldr	x8, [x0, #80]
	adds	x8, x8, #1
	csinv	x8, x8, xzr, lo
	stp	x11, x8, [x0, #72]
	ldr	x8, [x0, #16]
	cmp	x10, x8
	b.hs	LBB161_25
; %bb.22:                               ; %bb2.i.i
	ldr	x8, [x0, #32]
	mov	w11, #112                       ; =0x70
	madd	x10, x10, x11, x8
	ldr	x8, [x10, #96]
	cmp	x8, x9
	b.ne	LBB161_25
; %bb.23:                               ; %bb5.i.i
	ldr	x8, [x10]
	cbz	x8, LBB161_4
; %bb.24:                               ; %bb8.i.i
	strb	wzr, [x10, #80]
LBB161_25:
	mov	w0, #0                          ; =0x0
	ret
LBB161_26:
	mov	w0, #2                          ; =0x2
	ret
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function wf_record_store_delete$instance$f8195bc386aec277
lCPI162_0:
	.long	1                               ; 0x1
	.long	9                               ; 0x9
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_record_store_delete$instance$f8195bc386aec277
	.p2align	2
_wf_record_store_delete$instance$f8195bc386aec277: ; @"wf_record_store_delete$instance$f8195bc386aec277"
; %bb.0:                                ; %entry
	sub	sp, sp, #112
	ldr	x8, [x2]
	ldr	x9, [x1]
	cmp	x8, x9
	b.ne	LBB162_10
; %bb.1:                                ; %bb3.i
	ldr	x8, [x2, #8]
	ldr	x9, [x1, #16]
	cmp	x8, x9
	b.hs	LBB162_11
; %bb.2:                                ; %bb2.i.i
	ldr	x10, [x2, #16]
	ldr	x9, [x1, #32]
	mov	w11, #112                       ; =0x70
	madd	x11, x8, x11, x9
	ldr	x12, [x11, #96]
	cmp	x12, x10
	b.ne	LBB162_11
; %bb.3:                                ; %bb5.i.i
	ldr	x12, [x11]
	cbz	x12, LBB162_11
; %bb.4:                                ; %bb2
	ldrb	w14, [x11, #80]
	ldr	x13, [x11, #88]
	and	w14, w14, #0x1
	strb	w14, [sp, #8]
	ldrb	w15, [x1, #8]
	tbz	w15, #0, LBB162_7
; %bb.5:                                ; %bb5
	cbnz	w14, LBB162_13
; %bb.6:                                ; %bb9
	cmp	x13, #8
	b.ne	LBB162_13
LBB162_7:                               ; %bb8.i
	sub	x13, x12, #1
	str	x13, [x11]
	mov	w13, #88                        ; =0x58
	madd	x11, x12, x13, x11
	ldp	q0, q1, [x11, #-48]
	stp	q0, q1, [sp, #48]
	ldur	q0, [x11, #-16]
	str	q0, [sp, #80]
	ldr	x12, [x11]
	str	x12, [sp, #96]
	ldp	q0, q1, [x11, #-80]
	stp	q0, q1, [sp, #16]
	cmp	x10, #1
	b.hi	LBB162_9
; %bb.8:                                ; %bb11.i
	add	x10, x10, #1
	mov	w11, #112                       ; =0x70
	ldr	x12, [x1, #40]
	madd	x9, x8, x11, x9
	stp	x10, x12, [x9, #96]
	str	x8, [x1, #40]
LBB162_9:                               ; %bb13
	str	xzr, [x0]
	ldp	q0, q1, [sp, #48]
	stur	q0, [x0, #40]
	stur	q1, [x0, #56]
	ldr	q0, [sp, #80]
	stur	q0, [x0, #72]
	ldr	x8, [sp, #96]
	str	x8, [x0, #88]
	ldp	q0, q1, [sp, #16]
	stur	q0, [x0, #8]
	stur	q1, [x0, #24]
	add	sp, sp, #112
	ret
LBB162_10:
	mov	w8, #4                          ; =0x4
	b	LBB162_12
LBB162_11:                              ; %bb5.i
	mov	w8, #3                          ; =0x3
LBB162_12:                              ; %bb3
	str	xzr, [x0, #88]
	movi.2d	v0, #0000000000000000
	stur	q0, [x0, #72]
	stur	q0, [x0, #56]
	stur	q0, [x0, #40]
	stur	q0, [x0, #24]
	stur	q0, [x0, #8]
	mov	w9, #1                          ; =0x1
	stp	w9, w8, [x0]
	add	sp, sp, #112
	ret
LBB162_13:                              ; %bb8
	str	xzr, [x0, #88]
	movi.2d	v0, #0000000000000000
	stur	q0, [x0, #72]
	stur	q0, [x0, #56]
	stur	q0, [x0, #40]
	stur	q0, [x0, #24]
	stur	q0, [x0, #8]
Lloh350:
	adrp	x8, lCPI162_0@PAGE
Lloh351:
	ldr	d0, [x8, lCPI162_0@PAGEOFF]
	str	d0, [x0]
	add	sp, sp, #112
	ret
	.loh AdrpLdr	Lloh350, Lloh351
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_indexed_release$instance$68c9432c50ad41ad
lCPI163_0:
	.quad	22                              ; 0x16
	.quad	33                              ; 0x21
lCPI163_1:
	.quad	44                              ; 0x2c
	.quad	55                              ; 0x37
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_indexed_release$instance$68c9432c50ad41ad
	.p2align	2
_wf_indexed_release$instance$68c9432c50ad41ad: ; @"wf_indexed_release$instance$68c9432c50ad41ad"
; %bb.0:                                ; %entry
	mov	x8, x0
	ldp	x0, x9, [x1, #8]
	ldp	x10, x11, [x0]
	add	x12, x10, #101
	cmp	x11, x12
	csinv	x11, x10, xzr, eq
	add	x12, x11, #11
	cmp	x9, x12
	b.ne	LBB163_7
; %bb.1:                                ; %bb3.i
	ldr	x9, [x1, #56]
	dup.2d	v0, x11
	add	x12, x11, #66
Lloh352:
	adrp	x13, lCPI163_0@PAGE
Lloh353:
	ldr	q1, [x13, lCPI163_0@PAGEOFF]
	add.2d	v1, v0, v1
Lloh354:
	adrp	x13, lCPI163_1@PAGE
Lloh355:
	ldr	q2, [x13, lCPI163_1@PAGEOFF]
	add.2d	v0, v0, v2
	ldur	q2, [x1, #24]
	ldur	q3, [x1, #40]
	cmp	x9, x12
	cset	w12, eq
	cmeq.2d	v0, v3, v0
	cmeq.2d	v1, v2, v1
	uzp1.4s	v0, v1, v0
	xtn.4h	v0, v0
	uminv.4h	h0, v0
	fmov	w13, s0
	mov	x9, #-1                         ; =0xffffffffffffffff
	tbz	w13, #0, LBB163_8
; %bb.2:                                ; %bb3.i
	add	x13, x11, #77
	ldr	x14, [x1, #64]
	cmp	w12, #0
	ccmp	x14, x13, #0, ne
	b.ne	LBB163_8
; %bb.3:                                ; %wf_indexed_wide_read.exit
	cmp	x11, #64
	b.hs	LBB163_19
; %bb.4:                                ; %bb2
	ldr	x9, [x1]
	ldr	x12, [x8, x11, lsl #3]
	cmp	x12, x9
	b.eq	LBB163_6
; %bb.5:                                ; %bb5
	ldr	x9, [x8, #1304]
	add	x9, x9, #1
	str	x9, [x8, #1304]
LBB163_6:                               ; %bb4
	add	x9, x8, x11, lsl #3
	ldr	x11, [x9, #512]
	add	x11, x11, #1
	str	x11, [x9, #512]
	mov	x9, x10
	ldrb	w10, [x8, #1296]
	tbnz	w10, #0, LBB163_9
	b	LBB163_18
LBB163_7:
	mov	x9, #-1                         ; =0xffffffffffffffff
LBB163_8:                               ; %bb3
	ldr	x10, [x8, #1304]
	add	x10, x10, #1
	str	x10, [x8, #1304]
	ldrb	w10, [x8, #1296]
	tbz	w10, #0, LBB163_18
LBB163_9:                               ; %bb8
	ldrb	w11, [x1, #72]
	ldr	x10, [x1, #80]
	tbz	w11, #0, LBB163_11
; %bb.10:                               ; %bb11
	ldr	x11, [x8, #1304]
	add	x11, x11, #1
	str	x11, [x8, #1304]
LBB163_11:                              ; %bb10
	cmp	x10, #8
	b.eq	LBB163_13
; %bb.12:                               ; %bb14
	ldr	x10, [x8, #1304]
	add	x10, x10, #1
	str	x10, [x8, #1304]
LBB163_13:                              ; %bb13
	ldr	x10, [x8, #1288]
	ldr	x11, [x8, #1280]
	cmp	x10, x11
	b.hs	LBB163_16
; %bb.14:                               ; %bb13
	cmp	x10, #32
	b.hs	LBB163_16
; %bb.15:                               ; %bb20
	add	x11, x8, x10, lsl #3
	ldr	x11, [x11, #1024]
	cmp	x11, x9
	b.eq	LBB163_17
LBB163_16:                              ; %bb16.sink.split
	ldr	x9, [x8, #1304]
	add	x9, x9, #1
	str	x9, [x8, #1304]
LBB163_17:                              ; %bb16
	add	x9, x10, #1
	str	x9, [x8, #1288]
LBB163_18:                              ; %bb7
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	bl	_free
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB163_19:
	mov	x9, x11
	b	LBB163_8
	.loh AdrpLdr	Lloh354, Lloh355
	.loh AdrpAdrp	Lloh352, Lloh354
	.loh AdrpLdr	Lloh352, Lloh353
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_record_store_visit$instance$0a057dfeef8b7ec1
lCPI164_0:
	.quad	22                              ; 0x16
	.quad	33                              ; 0x21
lCPI164_1:
	.quad	44                              ; 0x2c
	.quad	55                              ; 0x37
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_record_store_visit$instance$0a057dfeef8b7ec1
	.p2align	2
_wf_record_store_visit$instance$0a057dfeef8b7ec1: ; @"wf_record_store_visit$instance$0a057dfeef8b7ec1"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.ne	LBB164_8
; %bb.1:                                ; %bb3.i
	ldr	x8, [x1, #8]
	ldr	x9, [x0, #16]
	cmp	x8, x9
	b.hs	LBB164_9
; %bb.2:                                ; %bb2.i.i.i
	ldr	x9, [x1, #16]
	ldr	x10, [x0, #32]
	mov	w11, #112                       ; =0x70
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #96]
	cmp	x10, x9
	b.ne	LBB164_9
; %bb.3:                                ; %bb5.i.i.i
	ldr	x9, [x8]
	cbz	x9, LBB164_9
; %bb.4:                                ; %bb8.i.i.i
	ldp	x9, x10, [x8, #16]
	ldp	x11, x9, [x9]
	add	x12, x11, #101
	cmp	x9, x12
	csinv	x9, x11, xzr, eq
	add	x11, x9, #11
	cmp	x10, x11
	b.ne	LBB164_12
; %bb.5:                                ; %bb3.i.i.i.i.i
	mov	w0, #0                          ; =0x0
	dup.2d	v0, x9
Lloh356:
	adrp	x10, lCPI164_0@PAGE
Lloh357:
	ldr	q1, [x10, lCPI164_0@PAGEOFF]
	add.2d	v1, v0, v1
Lloh358:
	adrp	x10, lCPI164_1@PAGE
Lloh359:
	ldr	q2, [x10, lCPI164_1@PAGEOFF]
	add.2d	v0, v0, v2
	ldp	q2, q3, [x8, #32]
	cmeq.2d	v0, v3, v0
	cmeq.2d	v1, v2, v1
	uzp1.4s	v0, v1, v0
	xtn.4h	v0, v0
	uminv.4h	h0, v0
	fmov	w10, s0
	mov	x1, #-1                         ; =0xffffffffffffffff
	tbz	w10, #0, LBB164_13
; %bb.6:                                ; %bb3.i.i.i.i.i
	add	x10, x9, #66
	ldr	x11, [x8, #64]
	mov	x2, x0
	cmp	x11, x10
	b.ne	LBB164_11
; %bb.7:                                ; %bb18.i.i.i.i.i
	mov	w0, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	add	x10, x9, #77
	ldr	x8, [x8, #72]
	cmp	x8, x10
	csinv	x1, x9, xzr, eq
	ret
LBB164_8:
	mov	x1, #0                          ; =0x0
	mov	w2, #4                          ; =0x4
	b	LBB164_10
LBB164_9:
	mov	x1, #0                          ; =0x0
	mov	w2, #3                          ; =0x3
LBB164_10:                              ; %"wf_record_store_visit$instance$0a057dfeef8b7ec1.body.exit"
	mov	w0, #1                          ; =0x1
LBB164_11:                              ; %"wf_record_store_visit$instance$0a057dfeef8b7ec1.body.exit"
	ret
LBB164_12:
	mov	w0, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	mov	x1, #-1                         ; =0xffffffffffffffff
	ret
LBB164_13:
	mov	x2, x0
	ret
	.loh AdrpLdr	Lloh358, Lloh359
	.loh AdrpAdrp	Lloh356, Lloh358
	.loh AdrpLdr	Lloh356, Lloh357
                                        ; -- End function
	.globl	_wf_indexed_release_payload$instance$68c9432c50ad41ad ; -- Begin function wf_indexed_release_payload$instance$68c9432c50ad41ad
	.p2align	2
_wf_indexed_release_payload$instance$68c9432c50ad41ad: ; @"wf_indexed_release_payload$instance$68c9432c50ad41ad"
; %bb.0:                                ; %entry
	sub	sp, sp, #112
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	ldp	q0, q1, [x2]
	stp	q0, q1, [sp, #16]
	ldp	q0, q1, [x2, #32]
	stp	q0, q1, [sp, #48]
	str	x1, [sp, #8]
	strb	wzr, [sp, #80]
	mov	w8, #8                          ; =0x8
	str	x8, [sp, #88]
	add	x1, sp, #8
	bl	_wf_indexed_release$instance$68c9432c50ad41ad
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #112
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_indexed_delete$instance$276fd431a73a5d55
lCPI166_0:
	.quad	22                              ; 0x16
	.quad	33                              ; 0x21
lCPI166_1:
	.quad	44                              ; 0x2c
	.quad	55                              ; 0x37
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_indexed_delete$instance$276fd431a73a5d55
	.p2align	2
_wf_indexed_delete$instance$276fd431a73a5d55: ; @"wf_indexed_delete$instance$276fd431a73a5d55"
; %bb.0:                                ; %entry
	sub	sp, sp, #144
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x19, x1, x3, lsl #6
	ldr	x8, [x19, #40]
	ldr	x9, [x0]
	cmp	x8, x9
	b.ne	LBB166_7
; %bb.1:                                ; %bb3.i.i
	ldr	x17, [x19, #48]
	ldr	x8, [x0, #16]
	cmp	x17, x8
	b.hs	LBB166_8
; %bb.2:                                ; %bb2.i.i.i
	ldr	x3, [x19, #56]
	ldr	x1, [x0, #32]
	mov	w8, #112                        ; =0x70
	madd	x8, x17, x8, x1
	ldr	x9, [x8, #96]
	cmp	x9, x3
	b.ne	LBB166_8
; %bb.3:                                ; %bb5.i.i.i
	ldr	x9, [x8]
	cbz	x9, LBB166_8
; %bb.4:                                ; %bb2.i
	ldrb	w10, [x8, #80]
	ldr	x11, [x8, #88]
	and	w10, w10, #0x1
	strb	w10, [sp, #88]
	ldrb	w12, [x0, #8]
	cmp	x11, #8
	csinc	w10, w10, wzr, eq
	tbz	w12, #0, LBB166_11
; %bb.5:                                ; %bb2.i
	tbz	w10, #0, LBB166_11
; %bb.6:
	mov	w8, #9                          ; =0x9
	cmp	x8, x4
	b.ne	LBB166_9
	b	LBB166_10
LBB166_7:
	mov	w8, #4                          ; =0x4
	cmp	x8, x4
	b.ne	LBB166_9
	b	LBB166_10
LBB166_8:                               ; %bb5.i8
	mov	w8, #3                          ; =0x3
	cmp	x8, x4
	b.eq	LBB166_10
LBB166_9:                               ; %bb13.i5
	ldr	x8, [x2, #1304]
	add	x8, x8, #1
	str	x8, [x2, #1304]
LBB166_10:                              ; %bb1
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	add	sp, sp, #144
	ret
LBB166_11:                              ; %bb8.i.i
	sub	x10, x9, #1
	str	x10, [x8]
	mov	w10, #88                        ; =0x58
	madd	x5, x9, x10, x8
	ldp	x9, x8, [x5, #-80]
	ldp	x10, x16, [x5, #-64]
	ldur	q1, [x5, #-40]
	ldur	q0, [x5, #-56]
	ldp	x12, x11, [x5, #-40]
	ldur	x15, [x5, #-48]
	ldp	x13, x14, [x5, #-24]
	ldur	q2, [x5, #-8]
	str	q2, [sp, #96]
	cmp	x3, #1
	b.hi	LBB166_13
; %bb.12:                               ; %bb11.i.i
	add	x3, x3, #1
	mov	w5, #112                        ; =0x70
	ldr	x6, [x0, #40]
	madd	x1, x17, x5, x1
	stp	x3, x6, [x1, #96]
	str	x17, [x0, #40]
LBB166_13:                              ; %bb2
	cbz	x4, LBB166_15
; %bb.14:                               ; %bb5
	ldr	x17, [x2, #1304]
	add	x17, x17, #1
	str	x17, [x2, #1304]
LBB166_15:                              ; %bb4
	ldp	x17, x0, [x8]
	add	x1, x17, #101
	cmp	x0, x1
	csinv	x17, x17, xzr, eq
	add	x0, x17, #11
	cmp	x10, x0
	b.ne	LBB166_19
; %bb.16:                               ; %bb3.i11
	dup.2d	v2, x17
Lloh360:
	adrp	x0, lCPI166_0@PAGE
Lloh361:
	ldr	q3, [x0, lCPI166_0@PAGEOFF]
	add.2d	v3, v2, v3
Lloh362:
	adrp	x0, lCPI166_1@PAGE
Lloh363:
	ldr	q4, [x0, lCPI166_1@PAGEOFF]
	add.2d	v2, v2, v4
	cmeq.2d	v1, v1, v2
	cmeq.2d	v0, v0, v3
	uzp1.4s	v0, v0, v1
	xtn.4h	v0, v0
	uminv.4h	h0, v0
	fmov	w1, s0
	mov	x0, #-1                         ; =0xffffffffffffffff
	tbz	w1, #0, LBB166_20
; %bb.17:                               ; %bb3.i11
	add	x1, x17, #66
	cmp	x13, x1
	b.ne	LBB166_20
; %bb.18:                               ; %bb18.i
	add	x0, x17, #77
	cmp	x14, x0
	csinv	x0, x17, xzr, eq
	b	LBB166_20
LBB166_19:
	mov	x0, #-1                         ; =0xffffffffffffffff
LBB166_20:                              ; %wf_indexed_wide_read.exit
	ldr	x17, [x19, #16]
	cmp	x0, x17
	b.eq	LBB166_22
; %bb.21:                               ; %bb8
	ldr	x17, [x2, #1304]
	add	x17, x17, #1
	str	x17, [x2, #1304]
LBB166_22:                              ; %bb7
	stp	x9, x8, [sp]
	stp	x10, x16, [sp, #16]
	stp	x15, x12, [sp, #32]
	stp	x11, x13, [sp, #48]
	str	x14, [sp, #64]
	ldr	q0, [sp, #96]
	stur	q0, [sp, #72]
	mov	x1, sp
	mov	x0, x2
	bl	_wf_indexed_release$instance$68c9432c50ad41ad
	strb	wzr, [x19]
	b	LBB166_10
	.loh AdrpLdr	Lloh362, Lloh363
	.loh AdrpAdrp	Lloh360, Lloh362
	.loh AdrpLdr	Lloh360, Lloh361
                                        ; -- End function
	.globl	_wf_indexed_detach$instance$e1380248266a9ad2 ; -- Begin function wf_indexed_detach$instance$e1380248266a9ad2
	.p2align	2
_wf_indexed_detach$instance$e1380248266a9ad2: ; @"wf_indexed_detach$instance$e1380248266a9ad2"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	mov	x19, x2
	add	x20, x1, x3, lsl #6
	ldr	x1, [x20, #8]
	ldur	q0, [x20, #40]
	str	q0, [sp]
	ldr	x8, [x20, #56]
	str	x8, [sp, #16]
	mov	x2, sp
	bl	_wf_record_store_detach$instance$f8195bc386aec277
	cbz	w0, LBB167_2
; %bb.1:                                ; %bb13.i
	ldr	x8, [x19, #1304]
	add	x8, x8, #1
	str	x8, [x19, #1304]
LBB167_2:                               ; %wf_indexed_status.exit
	strb	wzr, [x20, #24]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
                                        ; -- End function
	.globl	_wf_indexed_cancel$instance$e1380248266a9ad2 ; -- Begin function wf_indexed_cancel$instance$e1380248266a9ad2
	.p2align	2
_wf_indexed_cancel$instance$e1380248266a9ad2: ; @"wf_indexed_cancel$instance$e1380248266a9ad2"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	mov	x19, x2
	add	x20, x1, x3, lsl #6
	ldur	q0, [x20, #40]
	str	q0, [sp]
	ldr	x8, [x20, #56]
	str	x8, [sp, #16]
	mov	x1, sp
	bl	_wf_record_store_cancel$instance$f8195bc386aec277
	cbz	w0, LBB168_2
; %bb.1:                                ; %bb13.i
	ldr	x8, [x19, #1304]
	add	x8, x8, #1
	str	x8, [x19, #1304]
LBB168_2:                               ; %wf_indexed_status.exit
	strb	wzr, [x20, #25]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
                                        ; -- End function
	.globl	_wf_record_store_replace$instance$f8195bc386aec277 ; -- Begin function wf_record_store_replace$instance$f8195bc386aec277
	.p2align	2
_wf_record_store_replace$instance$f8195bc386aec277: ; @"wf_record_store_replace$instance$f8195bc386aec277"
; %bb.0:                                ; %entry
	sub	sp, sp, #128
	ldr	x8, [x1, #112]
	cbz	x8, LBB169_2
; %bb.1:                                ; %bb3.i.i.i
	udiv	x9, x2, x8
	msub	x9, x9, x8, x2
	ldr	x8, [x1, #48]
	cbnz	x8, LBB169_3
	b	LBB169_13
LBB169_2:
	mov	x9, #0                          ; =0x0
	ldr	x8, [x1, #48]
	cbz	x8, LBB169_13
LBB169_3:                               ; %bb3.i.i
	udiv	x10, x9, x8
	msub	x9, x10, x8, x9
	ldr	x10, [x1, #64]
	mov	x11, x8
	b	LBB169_5
LBB169_4:                               ; %bb8.i.i
                                        ;   in Loop: Header=BB169_5 Depth=1
	add	x12, x9, #1
	cmp	x12, x8
	csinc	x9, xzr, x9, hs
	subs	x11, x11, #1
	b.eq	LBB169_13
LBB169_5:                               ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x12, x10, x9, lsl #5
	ldr	w13, [x12]
	cmp	w13, #1
	b.eq	LBB169_4
; %bb.6:                                ; %bb5.i.i
                                        ;   in Loop: Header=BB169_5 Depth=1
	cmp	w13, #2
	b.ne	LBB169_13
; %bb.7:                                ; %bb9.i.i
                                        ;   in Loop: Header=BB169_5 Depth=1
	ldr	x13, [x12, #8]
	cmp	x13, x2
	b.ne	LBB169_4
; %bb.8:                                ; %bb3.i120.i
	ldr	x8, [x12, #16]
	ldr	x9, [x1, #16]
	cmp	x8, x9
	b.hs	LBB169_15
; %bb.9:                                ; %bb2.i.i.i
	ldr	x9, [x12, #24]
	ldr	x10, [x1, #32]
	mov	w11, #112                       ; =0x70
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #96]
	cmp	x10, x9
	b.ne	LBB169_15
; %bb.10:                               ; %bb5.i.i.i
	ldr	x9, [x8]
	cbz	x9, LBB169_15
; %bb.11:                               ; %bb3.i
	ldr	x9, [x8, #8]
	cmp	x9, x2
	b.ne	LBB169_16
; %bb.12:                               ; %bb4
	ldp	q0, q1, [x8, #16]
	stp	q0, q1, [sp]
	ldp	q0, q1, [x8, #48]
	stp	q0, q1, [sp, #32]
	ldp	q0, q1, [x3, #32]
	ldp	q3, q2, [x3]
	stp	q0, q1, [x8, #48]
	stp	q3, q2, [x8, #16]
	str	xzr, [x0]
	ldp	q0, q1, [sp]
	stur	q0, [x0, #8]
	stur	q1, [x0, #24]
	ldp	q0, q1, [sp, #32]
	stur	q0, [x0, #40]
	stur	q1, [x0, #56]
	add	sp, sp, #128
	ret
LBB169_13:
	mov	w8, #2                          ; =0x2
LBB169_14:                              ; %bb3
	ldp	q0, q1, [x3]
	stp	q0, q1, [sp, #64]
	ldp	q2, q3, [x3, #32]
	stp	q2, q3, [sp, #96]
	str	xzr, [x0]
	str	w8, [x0]
	stur	q0, [x0, #8]
	stur	q1, [x0, #24]
	stur	q2, [x0, #40]
	stur	q3, [x0, #56]
	add	sp, sp, #128
	ret
LBB169_15:
	mov	w8, #3                          ; =0x3
	b	LBB169_14
LBB169_16:
	mov	w8, #5                          ; =0x5
	b	LBB169_14
                                        ; -- End function
	.globl	_wf_record_store_position$instance$f8195bc386aec277 ; -- Begin function wf_record_store_position$instance$f8195bc386aec277
	.p2align	2
_wf_record_store_position$instance$f8195bc386aec277: ; @"wf_record_store_position$instance$f8195bc386aec277"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.ne	LBB170_6
; %bb.1:                                ; %bb3.i.i
	ldr	x8, [x1, #8]
	ldr	x9, [x0, #16]
	cmp	x8, x9
	b.hs	LBB170_7
; %bb.2:                                ; %bb2.i.i.i
	ldr	x9, [x1, #16]
	ldr	x10, [x0, #32]
	mov	w11, #112                       ; =0x70
	madd	x10, x8, x11, x10
	ldr	x11, [x10, #96]
	cmp	x11, x9
	b.ne	LBB170_7
; %bb.3:                                ; %bb5.i.i.i
	ldr	x11, [x10]
	cbz	x11, LBB170_7
; %bb.4:                                ; %bb2.i
	ldr	x1, [x10, #88]
	cmp	x1, #8
	b.ne	LBB170_8
; %bb.5:
	mov	x1, #0                          ; =0x0
	mov	w2, #7                          ; =0x7
	mov	w0, #1                          ; =0x1
	ret
LBB170_6:
	mov	x1, #0                          ; =0x0
	mov	w2, #4                          ; =0x4
	mov	w0, #1                          ; =0x1
	ret
LBB170_7:
	mov	x1, #0                          ; =0x0
	mov	w2, #3                          ; =0x3
	mov	w0, #1                          ; =0x1
	ret
LBB170_8:                               ; %bb6.i
	ldr	x11, [x0, #88]
	cmp	x1, x11
	b.hs	LBB170_12
; %bb.9:                                ; %bb8.i
	ldr	x11, [x0, #104]
	add	x11, x11, x1, lsl #5
	ldp	x12, x13, [x11, #16]
	cmp	x12, x8
	ccmp	x13, x9, #0, eq
	b.ne	LBB170_12
; %bb.10:                               ; %bb11.i
	ldr	x8, [x10, #8]
	ldr	x9, [x11, #8]
	cmp	x9, x8
	b.ne	LBB170_12
; %bb.11:                               ; %bb14.i
	mov	w0, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ret
LBB170_12:
	mov	x1, #0                          ; =0x0
	mov	w2, #8                          ; =0x8
	mov	w0, #1                          ; =0x1
	ret
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function wf_record_store_info$instance$f8195bc386aec277
lCPI171_0:
	.long	1                               ; 0x1
	.long	4                               ; 0x4
lCPI171_1:
	.long	1                               ; 0x1
	.long	3                               ; 0x3
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_record_store_info$instance$f8195bc386aec277
	.p2align	2
_wf_record_store_info$instance$f8195bc386aec277: ; @"wf_record_store_info$instance$f8195bc386aec277"
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	ldr	x9, [x1]
	cmp	x8, x9
	b.ne	LBB171_5
; %bb.1:                                ; %bb3
	ldr	x8, [x2, #8]
	ldr	x9, [x1, #16]
	cmp	x8, x9
	b.hs	LBB171_6
; %bb.2:                                ; %bb2.i
	ldr	x9, [x2, #16]
	ldr	x10, [x1, #32]
	mov	w11, #112                       ; =0x70
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #96]
	cmp	x10, x9
	b.ne	LBB171_6
; %bb.3:                                ; %bb5.i
	ldr	x9, [x8]
	cbz	x9, LBB171_6
; %bb.4:                                ; %bb4
	sub	sp, sp, #16
	ldr	x9, [x8, #8]
	ldrb	w10, [x8, #80]
	ldr	x8, [x8, #88]
	and	w10, w10, #0x1
	strb	w10, [sp, #8]
	stp	xzr, x9, [x0]
	strb	w10, [x0, #16]
	stur	wzr, [x0, #17]
	str	wzr, [x0, #20]
	str	x8, [x0, #24]
	add	sp, sp, #16
	ret
LBB171_5:                               ; %bb2
	movi.2d	v0, #0000000000000000
	str	xzr, [x0, #24]
	mov.d	v0[1], v0[0]
	stur	q0, [x0, #8]
Lloh364:
	adrp	x8, lCPI171_0@PAGE
Lloh365:
	ldr	d0, [x8, lCPI171_0@PAGEOFF]
	str	d0, [x0]
	ret
LBB171_6:                               ; %bb5
	movi.2d	v0, #0000000000000000
	str	xzr, [x0, #24]
	mov.d	v0[1], v0[0]
	stur	q0, [x0, #8]
Lloh366:
	adrp	x8, lCPI171_1@PAGE
Lloh367:
	ldr	d0, [x8, lCPI171_1@PAGEOFF]
	str	d0, [x0]
	ret
	.loh AdrpLdr	Lloh364, Lloh365
	.loh AdrpLdr	Lloh366, Lloh367
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_edit$instance$6a5da7aad053cce4 ; -- Begin function wf_std.collections.slab.slab_edit$instance$6a5da7aad053cce4
	.p2align	2
_wf_std.collections.slab.slab_edit$instance$6a5da7aad053cce4: ; @"wf_std.collections.slab.slab_edit$instance$6a5da7aad053cce4"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.hs	LBB172_4
; %bb.1:                                ; %bb2.i
	ldr	x9, [x1, #8]
	ldr	x10, [x0, #16]
	mov	w11, #112                       ; =0x70
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #96]
	cmp	x10, x9
	b.ne	LBB172_4
; %bb.2:                                ; %bb5.i
	ldr	x9, [x8]
	cbz	x9, LBB172_4
; %bb.3:                                ; %bb8.i
	mov	w0, #0                          ; =0x0
	ldr	x9, [x2]
	str	x9, [x8, #88]
	b	LBB172_5
LBB172_4:
	mov	w0, #1                          ; =0x1
LBB172_5:                               ; %"wf_std.collections.slab.slab_edit$instance$6a5da7aad053cce4.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_indexed_expire$instance$276fd431a73a5d55 ; -- Begin function wf_indexed_expire$instance$276fd431a73a5d55
	.p2align	2
_wf_indexed_expire$instance$276fd431a73a5d55: ; @"wf_indexed_expire$instance$276fd431a73a5d55"
; %bb.0:                                ; %entry
	sub	sp, sp, #304
	stp	x22, x21, [sp, #256]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #272]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #288]            ; 16-byte Folded Spill
	mov	x19, x2
	mov	x20, x1
	mov	x21, x0
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [sp, #224]
	stp	q0, q0, [sp, #192]
	stp	q0, q0, [sp, #160]
	stp	q0, q0, [sp, #128]
	stp	q0, q0, [sp, #96]
	stp	q0, q0, [sp, #64]
	stp	q0, q0, [sp, #32]
	stp	q0, q0, [sp]
	mov	x10, sp
	sub	x11, x10, #8
	ldr	x12, [x2, #1304]
	b	LBB173_3
LBB173_1:                               ; %bb15
                                        ;   in Loop: Header=BB173_3 Depth=1
	add	x12, x12, #1
	str	x12, [x19, #1304]
LBB173_2:                               ; %bb19
                                        ;   in Loop: Header=BB173_3 Depth=1
	add	x9, x9, #1
	add	x11, x11, #8
	sub	x8, x8, #1
	cmp	x9, #32
	b.eq	LBB173_12
LBB173_3:                               ; %bb2
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB173_5 Depth 2
	str	x9, [x10, x9, lsl #3]
	cbz	x9, LBB173_2
; %bb.4:                                ; %bb9.preheader
                                        ;   in Loop: Header=BB173_3 Depth=1
	add	x13, x20, x9, lsl #6
	mov	x14, x8
	mov	x15, x11
LBB173_5:                               ; %bb11
                                        ;   Parent Loop BB173_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	x16, [x15]
	cmp	x16, #31
	b.hi	LBB173_1
; %bb.6:                                ; %bb14
                                        ;   in Loop: Header=BB173_5 Depth=2
	ldr	x0, [x13, #32]
	add	x17, x20, x16, lsl #6
	ldr	x1, [x17, #32]
	cmp	x0, x1
	b.ne	LBB173_10
; %bb.7:                                ; %bb3.i
                                        ;   in Loop: Header=BB173_5 Depth=2
	ldr	x0, [x13, #8]
	ldr	x1, [x17, #8]
	cmp	x0, x1
	b.ne	LBB173_10
; %bb.8:                                ; %bb6.i
                                        ;   in Loop: Header=BB173_5 Depth=2
	ldr	x0, [x13, #48]
	ldr	x1, [x17, #48]
	cmp	x0, x1
	b.ne	LBB173_10
; %bb.9:                                ; %bb9.i
                                        ;   in Loop: Header=BB173_5 Depth=2
	ldr	x0, [x13, #56]
	ldr	x17, [x17, #56]
	cmp	x0, x17
LBB173_10:                              ; %bb2.i
                                        ;   in Loop: Header=BB173_5 Depth=2
	b.hs	LBB173_2
; %bb.11:                               ; %bb17
                                        ;   in Loop: Header=BB173_5 Depth=2
	stp	x9, x16, [x15], #-8
	adds	x14, x14, #1
	b.lo	LBB173_5
	b	LBB173_2
LBB173_12:                              ; %bb4
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	add	x10, x19, #1280
	add	x11, x19, #1024
	movi.2d	v0, #0000000000000000
	str	q0, [x19, #1280]
	mov	x12, sp
	b	LBB173_15
LBB173_13:                              ; %bb26
                                        ;   in Loop: Header=BB173_15 Depth=1
	ldr	x13, [x19, #1304]
	add	x13, x13, #1
	str	x13, [x19, #1304]
LBB173_14:                              ; %bb39
                                        ;   in Loop: Header=BB173_15 Depth=1
	add	x8, x8, #8
	cmp	x8, #256
	b.eq	LBB173_22
LBB173_15:                              ; %bb21
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x13, [x12, x8]
	cmp	x13, #32
	b.hs	LBB173_13
; %bb.16:                               ; %bb25
                                        ;   in Loop: Header=BB173_15 Depth=1
	add	x13, x20, x13, lsl #6
	ldrb	w14, [x13, #25]
	tbz	w14, #0, LBB173_14
; %bb.17:                               ; %bb28
                                        ;   in Loop: Header=BB173_15 Depth=1
	ldr	x14, [x13, #32]
	cmp	x14, x3
	b.hi	LBB173_14
; %bb.18:                               ; %bb31
                                        ;   in Loop: Header=BB173_15 Depth=1
	ldrb	w15, [x13]
	ldr	x14, [x13, #16]
	strh	wzr, [x13, #24]
	tbz	w15, #0, LBB173_14
; %bb.19:                               ; %bb34
                                        ;   in Loop: Header=BB173_15 Depth=1
	cmp	x9, #32
	b.hs	LBB173_21
; %bb.20:                               ; %bb37
                                        ;   in Loop: Header=BB173_15 Depth=1
	str	x14, [x11, x9, lsl #3]
	add	x9, x9, #1
	str	x9, [x10]
	strb	wzr, [x13]
	b	LBB173_14
LBB173_21:                              ; %bb38
                                        ;   in Loop: Header=BB173_15 Depth=1
	ldr	x14, [x19, #1304]
	add	x14, x14, #1
	str	x14, [x19, #1304]
	strb	wzr, [x13]
	b	LBB173_14
LBB173_22:                              ; %bb23
	mov	w8, #1                          ; =0x1
	strb	w8, [x19, #1296]
	mov	x0, x21
	mov	x1, x3
	mov	x2, x19
	bl	_wf_record_store_expire$instance$dbfa3e54f7dd514a
	ldr	x8, [x19, #1280]
	cmp	x0, x8
	b.eq	LBB173_24
; %bb.23:                               ; %bb41
	ldr	x9, [x19, #1304]
	add	x9, x9, #1
	str	x9, [x19, #1304]
LBB173_24:                              ; %bb40
	ldr	x9, [x19, #1288]
	cmp	x9, x8
	b.eq	LBB173_26
; %bb.25:                               ; %bb44
	ldr	x8, [x19, #1304]
	add	x8, x8, #1
	str	x8, [x19, #1304]
LBB173_26:                              ; %bb43
	strb	wzr, [x19, #1296]
	mov	x0, x21
	mov	x1, x20
	mov	x2, x19
	bl	_wf_indexed_check$instance$276fd431a73a5d55
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #288]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #272]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #256]            ; 16-byte Folded Reload
	add	sp, sp, #304
	ret
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function wf_record_store_lookup$instance$f8195bc386aec277
lCPI174_0:
	.long	1                               ; 0x1
	.long	5                               ; 0x5
lCPI174_1:
	.long	1                               ; 0x1
	.long	3                               ; 0x3
lCPI174_2:
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_record_store_lookup$instance$f8195bc386aec277
	.p2align	2
_wf_record_store_lookup$instance$f8195bc386aec277: ; @"wf_record_store_lookup$instance$f8195bc386aec277"
; %bb.0:                                ; %entry
	ldr	x8, [x1, #112]
	cbz	x8, LBB174_2
; %bb.1:                                ; %bb3.i.i
	udiv	x9, x2, x8
	msub	x9, x9, x8, x2
	ldr	x8, [x1, #48]
	cbnz	x8, LBB174_3
	b	LBB174_13
LBB174_2:
	mov	x9, #0                          ; =0x0
	ldr	x8, [x1, #48]
	cbz	x8, LBB174_13
LBB174_3:                               ; %bb3.i
	udiv	x10, x9, x8
	msub	x9, x10, x8, x9
	ldr	x10, [x1, #64]
	mov	x11, x8
	b	LBB174_5
LBB174_4:                               ; %bb8.i
                                        ;   in Loop: Header=BB174_5 Depth=1
	add	x12, x9, #1
	cmp	x12, x8
	csinc	x9, xzr, x9, hs
	subs	x11, x11, #1
	b.eq	LBB174_13
LBB174_5:                               ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x12, x10, x9, lsl #5
	ldr	w13, [x12]
	cmp	w13, #1
	b.eq	LBB174_4
; %bb.6:                                ; %bb5.i
                                        ;   in Loop: Header=BB174_5 Depth=1
	cmp	w13, #2
	b.ne	LBB174_13
; %bb.7:                                ; %bb9.i
                                        ;   in Loop: Header=BB174_5 Depth=1
	ldr	x13, [x12, #8]
	cmp	x13, x2
	b.ne	LBB174_4
; %bb.8:                                ; %bb3.i120
	ldr	x8, [x12, #16]
	ldr	x9, [x1, #16]
	cmp	x8, x9
	b.hs	LBB174_14
; %bb.9:                                ; %bb2.i.i
	ldr	x9, [x12, #24]
	ldr	x10, [x1, #32]
	mov	w11, #112                       ; =0x70
	madd	x10, x8, x11, x10
	ldr	x11, [x10, #96]
	cmp	x11, x9
	b.ne	LBB174_14
; %bb.10:                               ; %bb5.i.i
	ldr	x11, [x10]
	cbz	x11, LBB174_14
; %bb.11:                               ; %bb3
	ldr	x10, [x10, #8]
	cmp	x10, x2
	b.ne	LBB174_15
; %bb.12:                               ; %bb6
	ldr	x10, [x1]
	stp	xzr, x10, [x0]
	stp	x8, x9, [x0, #16]
	ret
LBB174_13:                              ; %bb2
	movi.2d	v0, #0000000000000000
	str	xzr, [x0, #24]
	mov.d	v0[1], v0[0]
	stur	q0, [x0, #8]
Lloh368:
	adrp	x8, lCPI174_2@PAGE
Lloh369:
	ldr	d0, [x8, lCPI174_2@PAGEOFF]
	str	d0, [x0]
	ret
LBB174_14:                              ; %bb4
	movi.2d	v0, #0000000000000000
	str	xzr, [x0, #24]
	mov.d	v0[1], v0[0]
	stur	q0, [x0, #8]
Lloh370:
	adrp	x8, lCPI174_1@PAGE
Lloh371:
	ldr	d0, [x8, lCPI174_1@PAGEOFF]
	str	d0, [x0]
	ret
LBB174_15:                              ; %bb7
	movi.2d	v0, #0000000000000000
	str	xzr, [x0, #24]
	mov.d	v0[1], v0[0]
	stur	q0, [x0, #8]
Lloh372:
	adrp	x8, lCPI174_0@PAGE
Lloh373:
	ldr	d0, [x8, lCPI174_0@PAGEOFF]
	str	d0, [x0]
	ret
	.loh AdrpLdr	Lloh368, Lloh369
	.loh AdrpLdr	Lloh370, Lloh371
	.loh AdrpLdr	Lloh372, Lloh373
                                        ; -- End function
	.globl	_wf_record_store_free$instance$dbfa3e54f7dd514a ; -- Begin function wf_record_store_free$instance$dbfa3e54f7dd514a
	.p2align	2
_wf_record_store_free$instance$dbfa3e54f7dd514a: ; @"wf_record_store_free$instance$dbfa3e54f7dd514a"
; %bb.0:                                ; %entry
	sub	sp, sp, #176
	stp	x26, x25, [sp, #96]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #112]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	mov	x20, x1
	ldp	x23, x22, [x0, #16]
	ldr	x19, [x0, #32]
	ldr	x8, [x0, #56]
	ldp	x24, x21, [x0, #96]
	cbz	x8, LBB175_2
; %bb.1:                                ; %slots.release.drop.6.i.i
	ldr	x0, [x0, #64]
	bl	_free
LBB175_2:                               ; %"wf_std.collections.hash_map.hash_map_free$instance$062aa17160873f66.exit"
	cbz	x24, LBB175_4
; %bb.3:                                ; %slots.release.drop.6.i.i2
	mov	x0, x21
	bl	_free
LBB175_4:                               ; %"wf_collections.priority_queue.priority_queue_free$instance$45ff9783f97b77eb.exit"
	cbz	x23, LBB175_9
; %bb.5:                                ; %bb5.i.preheader
	mov	w8, #112                        ; =0x70
	madd	x8, x23, x8, x19
	sub	x21, x8, #112
	mov	w24, #88                        ; =0x58
	mov	x25, sp
	b	LBB175_7
LBB175_6:                               ; %bb6.i
                                        ;   in Loop: Header=BB175_7 Depth=1
	sub	x21, x21, #112
	sub	x23, x23, #1
	cbz	x23, LBB175_9
LBB175_7:                               ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q0, q1, [x21, #32]
	stp	q0, q1, [sp, #32]
	ldp	q0, q1, [x21, #64]
	stp	q0, q1, [sp, #64]
	ldp	q0, q1, [x21]
	stp	q0, q1, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB175_6
; %bb.8:                                ; %bb7.i
                                        ;   in Loop: Header=BB175_7 Depth=1
	sub	x9, x8, #1
	madd	x8, x8, x24, x25
	sub	x1, x8, #80
	str	x9, [sp]
	mov	x0, x20
	bl	_wf_indexed_release$instance$68c9432c50ad41ad
	b	LBB175_6
LBB175_9:                               ; %bb4.i
	cbz	x22, LBB175_11
; %bb.10:                               ; %slots.release.drop.6.i.i8
	mov	x0, x19
	bl	_free
LBB175_11:                              ; %"wf_std.collections.slab.slab_free$instance$35920b2025f188fb.exit"
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #144]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
                                        ; -- End function
	.globl	_wf_box_slots_new$instance$98bdc07c73822b42 ; -- Begin function wf_box_slots_new$instance$98bdc07c73822b42
	.p2align	2
_wf_box_slots_new$instance$98bdc07c73822b42: ; @"wf_box_slots_new$instance$98bdc07c73822b42"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	cbz	x0, LBB176_3
; %bb.1:                                ; %window.payload.allocate.v1.i
	lsl	x8, x19, #6
	sub	x0, x8, x19, lsl #3
	bl	_malloc
	mov	x2, x0
	cbnz	x0, LBB176_4
; %bb.2:                                ; %window.block.oom.v1.i
	bl	l_wf_resource_abort
LBB176_3:
Lloh374:
	adrp	x2, l_.wf.empty.slots.payload@PAGE
Lloh375:
	add	x2, x2, l_.wf.empty.slots.payload@PAGEOFF
LBB176_4:                               ; %"wf_box_slots_new$instance$98bdc07c73822b42.body.exit"
	mov	x0, #0                          ; =0x0
	mov	x1, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh374, Lloh375
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_box_slots_new$instance$29b61f0cf25c44c5 ; -- Begin function wf_box_slots_new$instance$29b61f0cf25c44c5
	.p2align	2
_wf_box_slots_new$instance$29b61f0cf25c44c5: ; @"wf_box_slots_new$instance$29b61f0cf25c44c5"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	cbz	x0, LBB177_3
; %bb.1:                                ; %window.payload.allocate.v1.i
	lsl	x0, x19, #5
	bl	_malloc
	mov	x2, x0
	cbnz	x0, LBB177_4
; %bb.2:                                ; %window.block.oom.v1.i
	bl	l_wf_resource_abort
LBB177_3:
Lloh376:
	adrp	x2, l_.wf.empty.slots.payload@PAGE
Lloh377:
	add	x2, x2, l_.wf.empty.slots.payload@PAGEOFF
LBB177_4:                               ; %"wf_box_slots_new$instance$29b61f0cf25c44c5.body.exit"
	mov	x0, #0                          ; =0x0
	mov	x1, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh376, Lloh377
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_extend$instance$4348312e8937ab7e ; -- Begin function wf_std.collections.hash_map.hash_map_extend$instance$4348312e8937ab7e
	.p2align	2
_wf_std.collections.hash_map.hash_map_extend$instance$4348312e8937ab7e: ; @"wf_std.collections.hash_map.hash_map_extend$instance$4348312e8937ab7e"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x1
	mov	x19, x0
	ldp	x23, x22, [x0]
	cmp	x22, x1
	b.hs	LBB178_7
; %bb.1:                                ; %bb2
	ldr	x21, [x19, #16]
	lsl	x1, x20, #5
	cmp	x22, #0
	ccmp	x23, x22, #0, ne
	b.eq	LBB178_5
; %bb.2:                                ; %window.grow.copy.v2.i
	mov	x0, x1
	bl	_malloc
	cbz	x0, LBB178_12
; %bb.3:                                ; %window.grow.copy.ready.v2.i
	cbz	x22, LBB178_6
; %bb.4:                                ; %window.grow.copy.old.v2.i
	lsl	x2, x23, #5
	mov	x22, x0
	mov	x1, x21
	bl	_memcpy
	mov	x0, x21
	bl	_free
	mov	x0, x22
	b	LBB178_6
LBB178_5:                               ; %window.grow.reallocate.v2.i
	mov	x0, x21
	bl	_realloc
	cbz	x0, LBB178_12
LBB178_6:                               ; %"wf_grow$instance$29b61f0cf25c44c5.exit"
	stp	x20, x0, [x19, #8]
LBB178_7:                               ; %bb1
	cmp	x23, x20
	b.hs	LBB178_11
; %bb.8:                                ; %bb5.lr.ph
	ldr	x8, [x19, #16]
	add	x8, x8, x23, lsl #5
	add	x8, x8, #8
LBB178_9:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x8, #-8]
	add	x23, x23, #1
	stp	xzr, xzr, [x8, #8]
	str	xzr, [x8], #32
	cmp	x20, x23
	b.ne	LBB178_9
; %bb.10:                               ; %bb4.bb7_crit_edge
	str	x23, [x19]
LBB178_11:                              ; %bb7
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB178_12:                              ; %window.block.oom.v2.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_sift_sink$instance$97f85d10896f0873 ; -- Begin function wf_collections.priority_queue.priority_queue_sift_sink$instance$97f85d10896f0873
	.p2align	2
_wf_collections.priority_queue.priority_queue_sift_sink$instance$97f85d10896f0873: ; @"wf_collections.priority_queue.priority_queue_sift_sink$instance$97f85d10896f0873"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$6843c1d81191f67a
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_insert$instance$1a625a3e6534a882 ; -- Begin function wf_std.collections.slab.slab_insert$instance$1a625a3e6534a882
	.p2align	2
_wf_std.collections.slab.slab_insert$instance$1a625a3e6534a882: ; @"wf_std.collections.slab.slab_insert$instance$1a625a3e6534a882"
; %bb.0:                                ; %entry
	sub	sp, sp, #16
	ldp	x9, x12, [x2]
	ldrb	w10, [x2, #16]
	ldr	w11, [x2, #20]
	mov	x14, x2
	ldr	w13, [x14, #17]!
	ldr	x8, [x2, #24]
	str	w13, [sp, #8]
	stur	w11, [sp, #11]
	ldr	x11, [x1, #24]
	ldr	x13, [x1]
	cmp	x11, x13
	b.hs	LBB180_4
; %bb.1:                                ; %bb2
	ldr	x13, [x1, #16]
	mov	w14, #56                        ; =0x38
	madd	x14, x11, x14, x13
	ldr	x13, [x14]
	cbnz	x13, LBB180_6
; %bb.2:                                ; %bb5
	ldr	x13, [x14, #40]
	cmp	x13, #1
	b.hi	LBB180_6
; %bb.3:                                ; %bb8
	ldr	x15, [x14, #48]
	stp	x9, x12, [x14, #8]
	strb	w10, [x14, #24]
	ldr	w10, [sp, #8]
	stur	w10, [x14, #25]
	ldur	w10, [sp, #11]
	str	w10, [x14, #28]
	str	x8, [x14, #32]
	mov	w8, #1                          ; =0x1
	str	x8, [x14]
	str	x15, [x1, #24]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	str	xzr, [x0, #32]
	stp	x11, x13, [x0, #8]
	add	sp, sp, #16
	ret
LBB180_4:                               ; %bb3
	ldr	x15, [x1, #8]
	cmp	x13, x15
	b.hs	LBB180_6
; %bb.5:                                ; %bb11
	ldur	w15, [x14, #3]
	stur	w15, [sp, #3]
	ldr	w14, [x14]
	str	w14, [sp]
	ldr	x14, [x1, #16]
	mov	w15, #56                        ; =0x38
	madd	x14, x13, x15, x14
	mov	w15, #1                         ; =0x1
	stp	x15, x9, [x14]
	str	x12, [x14, #16]
	strb	w10, [x14, #24]
	ldr	w9, [sp]
	stur	w9, [x14, #25]
	ldur	w9, [sp, #3]
	str	w9, [x14, #28]
	stp	x8, xzr, [x14, #32]
	str	x11, [x14, #48]
	add	x8, x13, #1
	str	x8, [x1]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	str	xzr, [x0, #32]
	str	x13, [x0, #8]
	add	sp, sp, #16
	ret
LBB180_6:                               ; %bb4
	stp	xzr, x9, [x0]
	mov	w11, #1                         ; =0x1
	str	w11, [x0]
	str	x12, [x0, #16]
	strb	w10, [x0, #24]
	ldr	w9, [sp, #8]
	stur	w9, [x0, #25]
	ldur	w9, [sp, #11]
	str	w9, [x0, #28]
	str	x8, [x0, #32]
	add	sp, sp, #16
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_rebuild$instance$603c8258fd999e20 ; -- Begin function wf_std.collections.hash_map.hash_map_rebuild$instance$603c8258fd999e20
	.p2align	2
_wf_std.collections.hash_map.hash_map_rebuild$instance$603c8258fd999e20: ; @"wf_std.collections.hash_map.hash_map_rebuild$instance$603c8258fd999e20"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	cmp	x1, #2
	b.hi	LBB181_2
; %bb.1:                                ; %bb3.i
	ldr	x20, [x0]
	cmp	x1, x20
	b.hs	LBB181_4
LBB181_2:
	mov	w0, #1                          ; =0x1
LBB181_3:                               ; %"wf_std.collections.hash_map.hash_map_rebuild$instance$603c8258fd999e20.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB181_4:                               ; %bb6.i
	cbz	x1, LBB181_23
; %bb.5:                                ; %window.payload.allocate.v1.i.i.i
	mov	x21, x2
	mov	x19, x0
	mov	x22, x1
	lsl	x0, x1, #5
	bl	_malloc
	cbz	x0, LBB181_24
; %bb.6:                                ; %bb5.i.i.preheader
	mov	x9, #0                          ; =0x0
	add	x8, x0, #8
	mov	x10, x19
	mov	x11, x22
	mov	x13, x21
LBB181_7:                               ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x8, #-8]
	add	x9, x9, #1
	stp	xzr, xzr, [x8, #8]
	str	xzr, [x8], #32
	cmp	x11, x9
	b.ne	LBB181_7
; %bb.8:                                ; %"wf_std.collections.hash_map.hash_map_extend$instance$4348312e8937ab7e.exit.i"
	ldp	x12, x8, [x10, #8]
	stp	x11, x11, [x10]
	str	x0, [x10, #16]
	cbz	x20, LBB181_20
; %bb.9:                                ; %bb14.lr.ph.i
	ldr	x13, [x13]
	mov	w14, #2                         ; =0x2
	b	LBB181_12
LBB181_10:                              ; %"wf_std.collections.hash_map.hash_map_migrate_owner$instance$603c8258fd999e20.exit.i"
                                        ;   in Loop: Header=BB181_12 Depth=1
	add	x16, x0, x4, lsl #5
	str	w14, [x16]
	stur	q0, [x16, #8]
	str	x15, [x16, #24]
LBB181_11:                              ; %bb15.i
                                        ;   in Loop: Header=BB181_12 Depth=1
	cbz	x20, LBB181_20
LBB181_12:                              ; %bb14.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB181_14 Depth 2
                                        ;       Child Loop BB181_18 Depth 3
	sub	x20, x20, #1
	add	x15, x8, x20, lsl #5
	ldr	w16, [x15]
	cmp	w16, #2
	b.lo	LBB181_11
; %bb.13:                               ;   in Loop: Header=BB181_12 Depth=1
	ldur	q0, [x15, #8]
	ldr	x16, [x15, #8]
	ldr	x15, [x15, #24]
LBB181_14:                              ; %bb1.i9.i
                                        ;   Parent Loop BB181_12 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB181_18 Depth 3
	cbz	x13, LBB181_16
; %bb.15:                               ; %bb3.i.i.i
                                        ;   in Loop: Header=BB181_14 Depth=2
	udiv	x17, x16, x13
	msub	x1, x17, x13, x16
	b	LBB181_17
LBB181_16:                              ;   in Loop: Header=BB181_14 Depth=2
	mov	x1, #0                          ; =0x0
LBB181_17:                              ; %wf_record_id_hash.exit.i.i
                                        ;   in Loop: Header=BB181_14 Depth=2
	mov	x17, #0                         ; =0x0
	udiv	x2, x1, x11
	msub	x1, x2, x11, x1
	sub	x2, x11, x1
	neg	x3, x2
LBB181_18:                              ; %bb3.i.i
                                        ;   Parent Loop BB181_12 Depth=1
                                        ;     Parent Loop BB181_14 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x17, x2
	csel	x4, x1, x3, lo
	add	x4, x4, x17
	lsl	x5, x4, #5
	ldr	w5, [x0, x5]
	cmp	w5, #1
	b.ls	LBB181_10
; %bb.19:                               ; %bb2.i12.i
                                        ;   in Loop: Header=BB181_18 Depth=3
	add	x17, x17, #1
	cmp	x9, x17
	b.ne	LBB181_18
	b	LBB181_14
LBB181_20:                              ; %bb13.i
	cbz	x12, LBB181_22
; %bb.21:                               ; %slots.release.drop.6.i.i
	mov	x0, x8
	bl	_free
	mov	x10, x19
LBB181_22:                              ; %"wf_free_empty$instance$16f094be4fd843b6.exit.i"
	mov	w0, #0                          ; =0x0
	str	xzr, [x10, #32]
	b	LBB181_3
LBB181_23:
	mov	w0, #0                          ; =0x0
	b	LBB181_3
LBB181_24:                              ; %window.block.oom.v1.i.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_try_put$instance$603c8258fd999e20 ; -- Begin function wf_std.collections.hash_map.hash_map_try_put$instance$603c8258fd999e20
	.p2align	2
_wf_std.collections.hash_map.hash_map_try_put$instance$603c8258fd999e20: ; @"wf_std.collections.hash_map.hash_map_try_put$instance$603c8258fd999e20"
; %bb.0:                                ; %entry
	ldr	x8, [x4]
	cbz	x8, LBB182_9
; %bb.1:                                ; %bb3.i
	udiv	x9, x2, x8
	msub	x9, x9, x8, x2
	ldr	x8, [x1]
	cbz	x8, LBB182_10
LBB182_2:                               ; %bb2
	udiv	x10, x9, x8
	msub	x10, x10, x8, x9
	ldr	x11, [x1, #16]
	mov	x12, x8
	mov	x9, x8
	b	LBB182_5
LBB182_3:                               ; %bb11
                                        ;   in Loop: Header=BB182_5 Depth=1
	cmp	x9, x8
	csel	x9, x10, x9, eq
LBB182_4:                               ; %bb8
                                        ;   in Loop: Header=BB182_5 Depth=1
	add	x13, x10, #1
	cmp	x13, x8
	csinc	x10, xzr, x10, hs
	subs	x12, x12, #1
	b.eq	LBB182_11
LBB182_5:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	add	x13, x11, x10, lsl #5
	ldr	w14, [x13]
	cmp	w14, #1
	b.eq	LBB182_3
; %bb.6:                                ; %bb5
                                        ;   in Loop: Header=BB182_5 Depth=1
	cmp	w14, #2
	b.ne	LBB182_15
; %bb.7:                                ; %bb3.i11
                                        ;   in Loop: Header=BB182_5 Depth=1
	ldr	x14, [x13, #8]
	cmp	x14, x2
	b.ne	LBB182_4
; %bb.8:                                ; %"wf_std.collections.hash_map.hash_map_exchange$instance$44a98dc5bf86badc.exit"
	ldr	q0, [x3]
	mov	w8, #2                          ; =0x2
	str	w8, [x13]
	ldr	q1, [x13, #16]
	str	q0, [x13, #16]
	mov	w8, #1                          ; =0x1
	stp	x8, x2, [x0]
	str	q1, [x0, #16]
	ret
LBB182_9:
	mov	x9, #0                          ; =0x0
	ldr	x8, [x1]
	cbnz	x8, LBB182_2
LBB182_10:
	mov	x9, #0                          ; =0x0
LBB182_11:                              ; %bb1
	cmp	x9, x8
	b.hs	LBB182_16
LBB182_12:                              ; %bb24
	ldr	x8, [x1, #24]
	cmp	x8, #1
	b.hi	LBB182_16
; %bb.13:                               ; %bb27
	add	x8, x8, #1
	str	x8, [x1, #24]
	ldr	x8, [x1, #16]
	add	x8, x8, x9, lsl #5
	ldr	w9, [x8]
	cmp	w9, #1
	b.ne	LBB182_17
; %bb.14:                               ; %bb29.thread
	ldr	x9, [x1, #32]
	subs	x9, x9, #1
	csel	x9, xzr, x9, lo
	str	x9, [x1, #32]
	ldr	q0, [x3]
	mov	w9, #2                          ; =0x2
	str	w9, [x8]
	str	x2, [x8, #8]
	str	q0, [x8, #16]
	b	LBB182_19
LBB182_15:                              ; %bb10
	cmp	x9, x8
	csel	x9, x10, x9, eq
	cmp	x9, x8
	b.lo	LBB182_12
LBB182_16:                              ; %bb23
	ldr	q0, [x3]
	stp	xzr, x2, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	strb	w8, [x0, #4]
	str	q0, [x0, #16]
	ret
LBB182_17:                              ; %bb29
	ldur	q0, [x8, #8]
	ldr	x10, [x8, #24]
	ldr	q1, [x3]
	mov	w11, #2                         ; =0x2
	str	w11, [x8]
	str	x2, [x8, #8]
	str	q1, [x8, #16]
	cbz	w9, LBB182_19
; %bb.18:                               ; %bb3.i32
	mov	w8, #1                          ; =0x1
	str	x8, [x0]
	stur	q0, [x0, #8]
	str	x10, [x0, #24]
	ret
LBB182_19:                              ; %bb1.i37
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_record_set_id_member$instance$e194368921a477a7 ; -- Begin function wf_record_set_id_member$instance$e194368921a477a7
	.p2align	2
_wf_record_set_id_member$instance$e194368921a477a7: ; @"wf_record_set_id_member$instance$e194368921a477a7"
; %bb.0:                                ; %entry
	ldrb	w8, [x0]
	strb	w8, [x1, #16]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_peek_at$instance$e2f1cca2354fe4d1 ; -- Begin function wf_collections.priority_queue.priority_queue_peek_at$instance$e2f1cca2354fe4d1
	.p2align	2
_wf_collections.priority_queue.priority_queue_peek_at$instance$e2f1cca2354fe4d1: ; @"wf_collections.priority_queue.priority_queue_peek_at$instance$e2f1cca2354fe4d1"
; %bb.0:                                ; %entry
	ldr	x8, [x1, #16]
	add	x8, x8, x2, lsl #5
	ldp	q1, q0, [x8]
	stp	q1, q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_record_report_position$instance$50c6da9371c13a22 ; -- Begin function wf_record_report_position$instance$50c6da9371c13a22
	.p2align	2
_wf_record_report_position$instance$50c6da9371c13a22: ; @"wf_record_report_position$instance$50c6da9371c13a22"
; %bb.0:                                ; %entry
	ldr	x8, [x1, #16]
	ldr	x9, [x0]
	cmp	x8, x9
	b.hs	LBB185_4
; %bb.1:                                ; %bb2.i.i
	ldr	x9, [x1, #24]
	ldr	x10, [x0, #16]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB185_4
; %bb.2:                                ; %bb5.i.i
	ldr	x9, [x8]
	cbz	x9, LBB185_4
; %bb.3:                                ; %bb8.i.i
	str	x2, [x8, #32]
LBB185_4:                               ; %"wf_std.collections.slab.slab_edit$instance$79794de0ddcdada2.exit"
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_make_room$instance$a762b7cb0800ff6e ; -- Begin function wf_collections.priority_queue.priority_queue_make_room$instance$a762b7cb0800ff6e
	.p2align	2
_wf_collections.priority_queue.priority_queue_make_room$instance$a762b7cb0800ff6e: ; @"wf_collections.priority_queue.priority_queue_make_room$instance$a762b7cb0800ff6e"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldp	x9, x8, [x0]
	cmp	x8, x9
	b.ne	LBB186_8
; %bb.1:                                ; %bb3
	cmp	x8, #1
	b.eq	LBB186_5
; %bb.2:                                ; %bb3
	cbnz	x8, LBB186_8
; %bb.3:                                ; %bb5
	mov	x19, x0
	mov	w0, #32                         ; =0x20
	bl	_malloc
	cbz	x0, LBB186_9
; %bb.4:                                ; %window.grow.copy.ready.v2.i.i
	str	x0, [x19, #16]
	mov	w8, #1                          ; =0x1
	b	LBB186_7
LBB186_5:                               ; %bb11
	mov	x19, x0
	ldr	x0, [x0, #16]
	mov	w1, #64                         ; =0x40
	bl	_realloc
	cbz	x0, LBB186_9
; %bb.6:                                ; %"wf_grow$instance$57d99a800120d980.exit.i33"
	str	x0, [x19, #16]
	mov	w8, #2                          ; =0x2
LBB186_7:                               ; %common.ret.sink.split
	str	x8, [x19, #8]
LBB186_8:                               ; %common.ret
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB186_9:                               ; %window.block.oom.v2.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$2a15825f0f6e194e ; -- Begin function wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$2a15825f0f6e194e
	.p2align	2
_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$2a15825f0f6e194e: ; @"wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$2a15825f0f6e194e"
; %bb.0:                                ; %entry
	cbz	x1, LBB187_19
; %bb.1:                                ; %bb5.lr.ph
	sub	sp, sp, #32
	ldr	x8, [x0, #16]
	mov	w9, #56                         ; =0x38
	b	LBB187_3
LBB187_2:                               ; %"wf_record_report_position$instance$50c6da9371c13a22.exit23"
                                        ;   in Loop: Header=BB187_3 Depth=1
	cmp	x10, #2
	b.lo	LBB187_18
LBB187_3:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	mov	x11, x1
	sub	x10, x1, #1
	lsr	x1, x10, #1
	add	x13, x8, x1, lsl #5
	add	x12, x8, x11, lsl #5
	ldr	x14, [x13]
	ldr	x15, [x12]
	cmp	x14, x15
	b.lo	LBB187_18
; %bb.4:                                ; %bb3.i
                                        ;   in Loop: Header=BB187_3 Depth=1
	b.hi	LBB187_10
; %bb.5:                                ; %bb6.i
                                        ;   in Loop: Header=BB187_3 Depth=1
	ldr	x14, [x13, #8]
	ldr	x15, [x12, #8]
	cmp	x14, x15
	b.lo	LBB187_18
; %bb.6:                                ; %bb9.i
                                        ;   in Loop: Header=BB187_3 Depth=1
	b.hi	LBB187_10
; %bb.7:                                ; %bb12.i
                                        ;   in Loop: Header=BB187_3 Depth=1
	ldr	x14, [x13, #16]
	ldr	x15, [x12, #16]
	cmp	x14, x15
	b.lo	LBB187_18
; %bb.8:                                ; %bb15.i
                                        ;   in Loop: Header=BB187_3 Depth=1
	b.hi	LBB187_10
; %bb.9:                                ; %bb18.i
                                        ;   in Loop: Header=BB187_3 Depth=1
	ldr	x14, [x13, #24]
	ldr	x15, [x12, #24]
	cmp	x14, x15
	b.ls	LBB187_18
LBB187_10:                              ; %bb8
                                        ;   in Loop: Header=BB187_3 Depth=1
	ldp	q1, q0, [x13]
	ldp	q3, q2, [x12]
	stp	q3, q2, [x13]
	stp	q1, q0, [x12]
	ldr	x15, [x13, #16]
	ldr	x14, [x4]
	cmp	x15, x14
	b.hs	LBB187_14
; %bb.11:                               ; %bb2.i.i.i
                                        ;   in Loop: Header=BB187_3 Depth=1
	ldr	x16, [x13, #24]
	ldr	x13, [x4, #16]
	madd	x13, x15, x9, x13
	ldr	x15, [x13, #40]
	cmp	x15, x16
	b.ne	LBB187_14
; %bb.12:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB187_3 Depth=1
	ldr	x15, [x13]
	cbz	x15, LBB187_14
; %bb.13:                               ; %bb8.i.i.i
                                        ;   in Loop: Header=BB187_3 Depth=1
	str	x1, [x13, #32]
LBB187_14:                              ; %"wf_record_report_position$instance$50c6da9371c13a22.exit"
                                        ;   in Loop: Header=BB187_3 Depth=1
	ldr	x13, [x12, #16]
	cmp	x13, x14
	b.hs	LBB187_2
; %bb.15:                               ; %bb2.i.i.i10
                                        ;   in Loop: Header=BB187_3 Depth=1
	ldr	x14, [x12, #24]
	ldr	x12, [x4, #16]
	madd	x12, x13, x9, x12
	ldr	x13, [x12, #40]
	cmp	x13, x14
	b.ne	LBB187_2
; %bb.16:                               ; %bb5.i.i.i18
                                        ;   in Loop: Header=BB187_3 Depth=1
	ldr	x13, [x12]
	cbz	x13, LBB187_2
; %bb.17:                               ; %bb8.i.i.i21
                                        ;   in Loop: Header=BB187_3 Depth=1
	str	x11, [x12, #32]
	b	LBB187_2
LBB187_18:
	add	sp, sp, #32
LBB187_19:                              ; %common.ret
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_record_read_info$instance$e194368921a477a7 ; -- Begin function wf_record_read_info$instance$e194368921a477a7
	.p2align	2
_wf_record_read_info$instance$e194368921a477a7: ; @"wf_record_read_info$instance$e194368921a477a7"
; %bb.0:                                ; %entry
	ldr	x0, [x1]
	ldr	x2, [x1, #24]
	ldrb	w8, [x1, #16]
	and	w1, w8, #0x1
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_find$instance$603c8258fd999e20 ; -- Begin function wf_std.collections.hash_map.hash_map_find$instance$603c8258fd999e20
	.p2align	2
_wf_std.collections.hash_map.hash_map_find$instance$603c8258fd999e20: ; @"wf_std.collections.hash_map.hash_map_find$instance$603c8258fd999e20"
; %bb.0:                                ; %entry
	mov	x8, x1
	ldr	x9, [x2]
	cbz	x9, LBB189_2
; %bb.1:                                ; %bb3.i.i
	ldr	x10, [x8]
	udiv	x11, x10, x9
	msub	x10, x11, x9, x10
	ldr	x9, [x0]
	cbnz	x9, LBB189_3
	b	LBB189_9
LBB189_2:
	mov	x10, #0                         ; =0x0
	ldr	x9, [x0]
	cbz	x9, LBB189_9
LBB189_3:                               ; %bb3.i
	udiv	x11, x10, x9
	msub	x1, x11, x9, x10
	ldr	x10, [x0, #16]
	mov	x11, x9
	b	LBB189_5
LBB189_4:                               ; %bb8.i
                                        ;   in Loop: Header=BB189_5 Depth=1
	add	x12, x1, #1
	cmp	x12, x9
	csinc	x1, xzr, x1, hs
	subs	x11, x11, #1
	b.eq	LBB189_9
LBB189_5:                               ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x13, x10, x1, lsl #5
	ldr	w12, [x13]
	cmp	w12, #1
	b.eq	LBB189_4
; %bb.6:                                ; %bb5.i
                                        ;   in Loop: Header=BB189_5 Depth=1
	cmp	w12, #2
	b.ne	LBB189_10
; %bb.7:                                ; %bb3.i3.i
                                        ;   in Loop: Header=BB189_5 Depth=1
	ldr	x12, [x13, #8]
	ldr	x13, [x8]
	cmp	x12, x13
	b.ne	LBB189_4
; %bb.8:
	mov	w0, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ret
LBB189_9:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	ret
LBB189_10:
	mov	w0, #1                          ; =0x1
	mov	x1, x12
	mov	w2, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$2a15825f0f6e194e ; -- Begin function wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$2a15825f0f6e194e
	.p2align	2
_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$2a15825f0f6e194e: ; @"wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$2a15825f0f6e194e"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	cbz	x1, LBB190_2
; %bb.1:                                ; %bb2
	lsl	x8, x1, #4
	ldr	x9, [x0, #16]
	sub	x8, x8, #16
	and	x8, x8, #0xffffffffffffffe0
	add	x8, x9, x8
	add	x9, x9, x1, lsl #5
	ldr	x10, [x8]
	ldr	x11, [x9]
	cmp	x10, x11
	b.hs	LBB190_3
LBB190_2:                               ; %bb1
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$2a15825f0f6e194e
	b	LBB190_5
LBB190_3:                               ; %bb3.i
	b.ls	LBB190_6
LBB190_4:                               ; %bb5
	bl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$2a15825f0f6e194e
LBB190_5:                               ; %common.ret
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB190_6:                               ; %bb6.i
	ldr	x10, [x8, #8]
	ldr	x11, [x9, #8]
	cmp	x10, x11
	b.lo	LBB190_2
; %bb.7:                                ; %bb9.i
	b.hi	LBB190_4
; %bb.8:                                ; %bb12.i
	ldr	x10, [x8, #16]
	ldr	x11, [x9, #16]
	cmp	x10, x11
	b.lo	LBB190_2
; %bb.9:                                ; %bb15.i
	b.hi	LBB190_4
; %bb.10:                               ; %bb18.i
	ldr	x8, [x8, #24]
	ldr	x9, [x9, #24]
	cmp	x8, x9
	b.ls	LBB190_2
	b	LBB190_4
                                        ; -- End function
	.globl	_wf_record_set_position$instance$e194368921a477a7 ; -- Begin function wf_record_set_position$instance$e194368921a477a7
	.p2align	2
_wf_record_set_position$instance$e194368921a477a7: ; @"wf_record_set_position$instance$e194368921a477a7"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	str	x8, [x1, #24]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_extend$instance$bd5728c249450a41 ; -- Begin function wf_std.collections.hash_map.hash_map_extend$instance$bd5728c249450a41
	.p2align	2
_wf_std.collections.hash_map.hash_map_extend$instance$bd5728c249450a41: ; @"wf_std.collections.hash_map.hash_map_extend$instance$bd5728c249450a41"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x1
	mov	x19, x0
	ldp	x23, x22, [x0]
	cmp	x22, x1
	b.hs	LBB192_7
; %bb.1:                                ; %bb2
	ldr	x21, [x19, #16]
	lsl	x1, x20, #5
	cmp	x22, #0
	ccmp	x23, x22, #0, ne
	b.eq	LBB192_5
; %bb.2:                                ; %window.grow.copy.v2.i
	mov	x0, x1
	bl	_malloc
	cbz	x0, LBB192_12
; %bb.3:                                ; %window.grow.copy.ready.v2.i
	cbz	x22, LBB192_6
; %bb.4:                                ; %window.grow.copy.old.v2.i
	lsl	x2, x23, #5
	mov	x22, x0
	mov	x1, x21
	bl	_memcpy
	mov	x0, x21
	bl	_free
	mov	x0, x22
	b	LBB192_6
LBB192_5:                               ; %window.grow.reallocate.v2.i
	mov	x0, x21
	bl	_realloc
	cbz	x0, LBB192_12
LBB192_6:                               ; %"wf_grow$instance$29b61f0cf25c44c5.exit"
	stp	x20, x0, [x19, #8]
LBB192_7:                               ; %bb1
	cmp	x23, x20
	b.hs	LBB192_11
; %bb.8:                                ; %bb5.lr.ph
	ldr	x8, [x19, #16]
	add	x8, x8, x23, lsl #5
	add	x8, x8, #8
LBB192_9:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x8, #-8]
	add	x23, x23, #1
	stp	xzr, xzr, [x8, #8]
	str	xzr, [x8], #32
	cmp	x20, x23
	b.ne	LBB192_9
; %bb.10:                               ; %bb4.bb7_crit_edge
	str	x23, [x19]
LBB192_11:                              ; %bb7
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB192_12:                              ; %window.block.oom.v2.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_sift_sink$instance$b1f8c2aa150dd109 ; -- Begin function wf_collections.priority_queue.priority_queue_sift_sink$instance$b1f8c2aa150dd109
	.p2align	2
_wf_collections.priority_queue.priority_queue_sift_sink$instance$b1f8c2aa150dd109: ; @"wf_collections.priority_queue.priority_queue_sift_sink$instance$b1f8c2aa150dd109"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$45e23263d9dc5d6a
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_visit$instance$d498fd0758c25846 ; -- Begin function wf_std.collections.slab.slab_visit$instance$d498fd0758c25846
	.p2align	2
_wf_std.collections.slab.slab_visit$instance$d498fd0758c25846: ; @"wf_std.collections.slab.slab_visit$instance$d498fd0758c25846"
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	ldr	x9, [x1]
	cmp	x8, x9
	b.hs	LBB194_4
; %bb.1:                                ; %bb2
	ldr	x9, [x2, #8]
	ldr	x10, [x1, #16]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB194_4
; %bb.2:                                ; %bb5
	ldr	x9, [x8]
	cbz	x9, LBB194_4
; %bb.3:                                ; %bb8
	sub	sp, sp, #16
	ldr	x9, [x8, #8]
	ldrb	w10, [x8, #24]
	ldr	x8, [x8, #32]
	and	w10, w10, #0x1
	strb	w10, [sp, #8]
	stp	x9, xzr, [x0, #8]
	str	xzr, [x0]
	strb	w10, [x0, #16]
	str	x8, [x0, #24]
	add	sp, sp, #16
	ret
LBB194_4:                               ; %bb1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	ret
                                        ; -- End function
	.globl	_wf_slots_new$instance$1041f573a20e5bc9 ; -- Begin function wf_slots_new$instance$1041f573a20e5bc9
	.p2align	2
_wf_slots_new$instance$1041f573a20e5bc9: ; @"wf_slots_new$instance$1041f573a20e5bc9"
; %bb.0:                                ; %entry
	str	xzr, [x0, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_len$instance$6fdaba65c7a2e99d ; -- Begin function wf_collections.priority_queue.priority_queue_len$instance$6fdaba65c7a2e99d
	.p2align	2
_wf_collections.priority_queue.priority_queue_len$instance$6fdaba65c7a2e99d: ; @"wf_collections.priority_queue.priority_queue_len$instance$6fdaba65c7a2e99d"
; %bb.0:                                ; %entry
	ldr	x0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_peek_at$instance$a51738a7def77921 ; -- Begin function wf_collections.priority_queue.priority_queue_peek_at$instance$a51738a7def77921
	.p2align	2
_wf_collections.priority_queue.priority_queue_peek_at$instance$a51738a7def77921: ; @"wf_collections.priority_queue.priority_queue_peek_at$instance$a51738a7def77921"
; %bb.0:                                ; %entry
	ldr	x8, [x1, #16]
	add	x8, x8, x2, lsl #5
	ldp	q1, q0, [x8]
	stp	q1, q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_record_report_position$instance$5ffcb0796f3480f6 ; -- Begin function wf_record_report_position$instance$5ffcb0796f3480f6
	.p2align	2
_wf_record_report_position$instance$5ffcb0796f3480f6: ; @"wf_record_report_position$instance$5ffcb0796f3480f6"
; %bb.0:                                ; %entry
	ldr	x8, [x1, #16]
	ldr	x9, [x0]
	cmp	x8, x9
	b.hs	LBB198_4
; %bb.1:                                ; %bb2.i.i
	ldr	x9, [x1, #24]
	ldr	x10, [x0, #16]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB198_4
; %bb.2:                                ; %bb5.i.i
	ldr	x9, [x8]
	cbz	x9, LBB198_4
; %bb.3:                                ; %bb8.i.i
	str	x2, [x8, #32]
LBB198_4:                               ; %"wf_std.collections.slab.slab_edit$instance$8849ff7cbb1262dd.exit"
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_make_room$instance$6fdaba65c7a2e99d ; -- Begin function wf_collections.priority_queue.priority_queue_make_room$instance$6fdaba65c7a2e99d
	.p2align	2
_wf_collections.priority_queue.priority_queue_make_room$instance$6fdaba65c7a2e99d: ; @"wf_collections.priority_queue.priority_queue_make_room$instance$6fdaba65c7a2e99d"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldp	x9, x8, [x0]
	orr	x8, x8, x9
	cbnz	x8, LBB199_3
; %bb.1:                                ; %bb5
	mov	x19, x0
	mov	w0, #32                         ; =0x20
	bl	_malloc
	cbz	x0, LBB199_4
; %bb.2:                                ; %window.grow.copy.ready.v2.i.i
	mov	w8, #1                          ; =0x1
	stp	x8, x0, [x19, #8]
LBB199_3:                               ; %common.ret
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB199_4:                               ; %window.block.oom.v2.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$17afb96af21633a2 ; -- Begin function wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$17afb96af21633a2
	.p2align	2
_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$17afb96af21633a2: ; @"wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$17afb96af21633a2"
; %bb.0:                                ; %entry
	cbz	x1, LBB200_19
; %bb.1:                                ; %bb5.lr.ph
	sub	sp, sp, #32
	ldr	x8, [x0, #16]
	mov	w9, #56                         ; =0x38
	b	LBB200_3
LBB200_2:                               ; %"wf_record_report_position$instance$5ffcb0796f3480f6.exit23"
                                        ;   in Loop: Header=BB200_3 Depth=1
	cmp	x10, #2
	b.lo	LBB200_18
LBB200_3:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	mov	x11, x1
	sub	x10, x1, #1
	lsr	x1, x10, #1
	add	x13, x8, x1, lsl #5
	add	x12, x8, x11, lsl #5
	ldr	x14, [x13]
	ldr	x15, [x12]
	cmp	x14, x15
	b.lo	LBB200_18
; %bb.4:                                ; %bb3.i
                                        ;   in Loop: Header=BB200_3 Depth=1
	b.hi	LBB200_10
; %bb.5:                                ; %bb6.i
                                        ;   in Loop: Header=BB200_3 Depth=1
	ldr	x14, [x13, #8]
	ldr	x15, [x12, #8]
	cmp	x14, x15
	b.lo	LBB200_18
; %bb.6:                                ; %bb9.i
                                        ;   in Loop: Header=BB200_3 Depth=1
	b.hi	LBB200_10
; %bb.7:                                ; %bb12.i
                                        ;   in Loop: Header=BB200_3 Depth=1
	ldr	x14, [x13, #16]
	ldr	x15, [x12, #16]
	cmp	x14, x15
	b.lo	LBB200_18
; %bb.8:                                ; %bb15.i
                                        ;   in Loop: Header=BB200_3 Depth=1
	b.hi	LBB200_10
; %bb.9:                                ; %bb18.i
                                        ;   in Loop: Header=BB200_3 Depth=1
	ldr	x14, [x13, #24]
	ldr	x15, [x12, #24]
	cmp	x14, x15
	b.ls	LBB200_18
LBB200_10:                              ; %bb8
                                        ;   in Loop: Header=BB200_3 Depth=1
	ldp	q1, q0, [x13]
	ldp	q3, q2, [x12]
	stp	q3, q2, [x13]
	stp	q1, q0, [x12]
	ldr	x15, [x13, #16]
	ldr	x14, [x4]
	cmp	x15, x14
	b.hs	LBB200_14
; %bb.11:                               ; %bb2.i.i.i
                                        ;   in Loop: Header=BB200_3 Depth=1
	ldr	x16, [x13, #24]
	ldr	x13, [x4, #16]
	madd	x13, x15, x9, x13
	ldr	x15, [x13, #40]
	cmp	x15, x16
	b.ne	LBB200_14
; %bb.12:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB200_3 Depth=1
	ldr	x15, [x13]
	cbz	x15, LBB200_14
; %bb.13:                               ; %bb8.i.i.i
                                        ;   in Loop: Header=BB200_3 Depth=1
	str	x1, [x13, #32]
LBB200_14:                              ; %"wf_record_report_position$instance$5ffcb0796f3480f6.exit"
                                        ;   in Loop: Header=BB200_3 Depth=1
	ldr	x13, [x12, #16]
	cmp	x13, x14
	b.hs	LBB200_2
; %bb.15:                               ; %bb2.i.i.i10
                                        ;   in Loop: Header=BB200_3 Depth=1
	ldr	x14, [x12, #24]
	ldr	x12, [x4, #16]
	madd	x12, x13, x9, x12
	ldr	x13, [x12, #40]
	cmp	x13, x14
	b.ne	LBB200_2
; %bb.16:                               ; %bb5.i.i.i18
                                        ;   in Loop: Header=BB200_3 Depth=1
	ldr	x13, [x12]
	cbz	x13, LBB200_2
; %bb.17:                               ; %bb8.i.i.i21
                                        ;   in Loop: Header=BB200_3 Depth=1
	str	x11, [x12, #32]
	b	LBB200_2
LBB200_18:
	add	sp, sp, #32
LBB200_19:                              ; %common.ret
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_extend$instance$56bab2225b172a73 ; -- Begin function wf_std.collections.hash_map.hash_map_extend$instance$56bab2225b172a73
	.p2align	2
_wf_std.collections.hash_map.hash_map_extend$instance$56bab2225b172a73: ; @"wf_std.collections.hash_map.hash_map_extend$instance$56bab2225b172a73"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x1
	mov	x19, x0
	ldp	x23, x22, [x0]
	cmp	x22, x1
	b.hs	LBB201_7
; %bb.1:                                ; %bb2
	ldr	x21, [x19, #16]
	lsl	x1, x20, #5
	cmp	x22, #0
	ccmp	x23, x22, #0, ne
	b.eq	LBB201_5
; %bb.2:                                ; %window.grow.copy.v2.i
	mov	x0, x1
	bl	_malloc
	cbz	x0, LBB201_12
; %bb.3:                                ; %window.grow.copy.ready.v2.i
	cbz	x22, LBB201_6
; %bb.4:                                ; %window.grow.copy.old.v2.i
	lsl	x2, x23, #5
	mov	x22, x0
	mov	x1, x21
	bl	_memcpy
	mov	x0, x21
	bl	_free
	mov	x0, x22
	b	LBB201_6
LBB201_5:                               ; %window.grow.reallocate.v2.i
	mov	x0, x21
	bl	_realloc
	cbz	x0, LBB201_12
LBB201_6:                               ; %"wf_grow$instance$29b61f0cf25c44c5.exit"
	stp	x20, x0, [x19, #8]
LBB201_7:                               ; %bb1
	cmp	x23, x20
	b.hs	LBB201_11
; %bb.8:                                ; %bb5.lr.ph
	ldr	x8, [x19, #16]
	add	x8, x8, x23, lsl #5
	add	x8, x8, #8
LBB201_9:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x8, #-8]
	add	x23, x23, #1
	stp	xzr, xzr, [x8, #8]
	str	xzr, [x8], #32
	cmp	x20, x23
	b.ne	LBB201_9
; %bb.10:                               ; %bb4.bb7_crit_edge
	str	x23, [x19]
LBB201_11:                              ; %bb7
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB201_12:                              ; %window.block.oom.v2.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_sift_sink$instance$e332b3dde67982e1 ; -- Begin function wf_collections.priority_queue.priority_queue_sift_sink$instance$e332b3dde67982e1
	.p2align	2
_wf_collections.priority_queue.priority_queue_sift_sink$instance$e332b3dde67982e1: ; @"wf_collections.priority_queue.priority_queue_sift_sink$instance$e332b3dde67982e1"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$ab518dd14902c4dc
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_record_report_position$instance$aa2364d9cd38ac5f ; -- Begin function wf_record_report_position$instance$aa2364d9cd38ac5f
	.p2align	2
_wf_record_report_position$instance$aa2364d9cd38ac5f: ; @"wf_record_report_position$instance$aa2364d9cd38ac5f"
; %bb.0:                                ; %entry
	ldr	x8, [x1, #16]
	ldr	x9, [x0]
	cmp	x8, x9
	b.hs	LBB203_4
; %bb.1:                                ; %bb2.i.i
	ldr	x9, [x1, #24]
	ldr	x10, [x0, #16]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB203_4
; %bb.2:                                ; %bb5.i.i
	ldr	x9, [x8]
	cbz	x9, LBB203_4
; %bb.3:                                ; %bb8.i.i
	str	x2, [x8, #32]
LBB203_4:                               ; %"wf_std.collections.slab.slab_edit$instance$d0c575ce05c33b0e.exit"
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$4a1731430e1da28f ; -- Begin function wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$4a1731430e1da28f
	.p2align	2
_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$4a1731430e1da28f: ; @"wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$4a1731430e1da28f"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	cbz	x1, LBB204_2
; %bb.1:                                ; %bb2
	lsl	x8, x1, #4
	ldr	x9, [x0, #16]
	sub	x8, x8, #16
	and	x8, x8, #0xffffffffffffffe0
	add	x8, x9, x8
	add	x9, x9, x1, lsl #5
	ldr	x10, [x8]
	ldr	x11, [x9]
	cmp	x10, x11
	b.hs	LBB204_3
LBB204_2:                               ; %bb1
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$4a1731430e1da28f
	b	LBB204_5
LBB204_3:                               ; %bb3.i
	b.ls	LBB204_6
LBB204_4:                               ; %bb5
	bl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$4a1731430e1da28f
LBB204_5:                               ; %common.ret
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB204_6:                               ; %bb6.i
	ldr	x10, [x8, #8]
	ldr	x11, [x9, #8]
	cmp	x10, x11
	b.lo	LBB204_2
; %bb.7:                                ; %bb9.i
	b.hi	LBB204_4
; %bb.8:                                ; %bb12.i
	ldr	x10, [x8, #16]
	ldr	x11, [x9, #16]
	cmp	x10, x11
	b.lo	LBB204_2
; %bb.9:                                ; %bb15.i
	b.hi	LBB204_4
; %bb.10:                               ; %bb18.i
	ldr	x8, [x8, #24]
	ldr	x9, [x9, #24]
	cmp	x8, x9
	b.ls	LBB204_2
	b	LBB204_4
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_lookup$instance$747573d93540fe7d ; -- Begin function wf_std.collections.hash_map.hash_map_lookup$instance$747573d93540fe7d
	.p2align	2
_wf_std.collections.hash_map.hash_map_lookup$instance$747573d93540fe7d: ; @"wf_std.collections.hash_map.hash_map_lookup$instance$747573d93540fe7d"
; %bb.0:                                ; %entry
	ldr	x8, [x3]
	cbz	x8, LBB205_2
; %bb.1:                                ; %bb3.i
	ldr	x9, [x2]
	udiv	x10, x9, x8
	msub	x9, x10, x8, x9
	ldr	x8, [x1]
	cbnz	x8, LBB205_3
	b	LBB205_9
LBB205_2:
	mov	x9, #0                          ; =0x0
	ldr	x8, [x1]
	cbz	x8, LBB205_9
LBB205_3:                               ; %bb3
	udiv	x10, x9, x8
	msub	x9, x10, x8, x9
	ldr	x10, [x1, #16]
	mov	x11, x8
	b	LBB205_5
LBB205_4:                               ; %bb8
                                        ;   in Loop: Header=BB205_5 Depth=1
	add	x12, x9, #1
	cmp	x12, x8
	csinc	x9, xzr, x9, hs
	subs	x11, x11, #1
	b.eq	LBB205_9
LBB205_5:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	add	x12, x10, x9, lsl #5
	ldr	w13, [x12]
	cmp	w13, #1
	b.eq	LBB205_4
; %bb.6:                                ; %bb5
                                        ;   in Loop: Header=BB205_5 Depth=1
	cmp	w13, #2
	b.ne	LBB205_9
; %bb.7:                                ; %bb9
                                        ;   in Loop: Header=BB205_5 Depth=1
	ldr	x13, [x12, #8]
	ldr	x14, [x2]
	cmp	x13, x14
	b.ne	LBB205_4
; %bb.8:                                ; %bb13
	ldr	q0, [x12, #16]
	str	xzr, [x0]
	stur	q0, [x0, #8]
	ret
LBB205_9:                               ; %bb2
	stp	xzr, xzr, [x0]
	str	xzr, [x0, #16]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_remove$instance$2c23e55f2c711739 ; -- Begin function wf_std.collections.hash_map.hash_map_remove$instance$2c23e55f2c711739
	.p2align	2
_wf_std.collections.hash_map.hash_map_remove$instance$2c23e55f2c711739: ; @"wf_std.collections.hash_map.hash_map_remove$instance$2c23e55f2c711739"
; %bb.0:                                ; %entry
	ldr	x8, [x1, #24]
	cbz	x8, LBB206_10
; %bb.1:                                ; %bb3
	ldr	x9, [x3]
	cbz	x9, LBB206_3
; %bb.2:                                ; %bb3.i.i.i
	ldr	x10, [x2]
	udiv	x11, x10, x9
	msub	x10, x11, x9, x10
	ldr	x9, [x1]
	cbnz	x9, LBB206_4
	b	LBB206_10
LBB206_3:
	mov	x10, #0                         ; =0x0
	ldr	x9, [x1]
	cbz	x9, LBB206_10
LBB206_4:                               ; %bb3.i.i
	udiv	x11, x10, x9
	msub	x10, x11, x9, x10
	ldr	x11, [x1, #16]
	mov	x12, x9
	b	LBB206_6
LBB206_5:                               ; %bb8.i.i
                                        ;   in Loop: Header=BB206_6 Depth=1
	add	x13, x10, #1
	cmp	x13, x9
	csinc	x10, xzr, x10, hs
	subs	x12, x12, #1
	b.eq	LBB206_10
LBB206_6:                               ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x13, x11, x10, lsl #5
	ldr	w14, [x13]
	cmp	w14, #1
	b.eq	LBB206_5
; %bb.7:                                ; %bb5.i.i
                                        ;   in Loop: Header=BB206_6 Depth=1
	cmp	w14, #2
	b.ne	LBB206_10
; %bb.8:                                ; %bb3.i3.i.i
                                        ;   in Loop: Header=BB206_6 Depth=1
	ldr	x14, [x13, #8]
	ldr	x15, [x2]
	cmp	x14, x15
	b.ne	LBB206_5
; %bb.9:                                ; %bb6
	mov	w9, #1                          ; =0x1
	str	w9, [x13]
	sub	x8, x8, #1
	ldr	q0, [x13, #16]
	stp	xzr, xzr, [x13, #16]
	str	xzr, [x13, #8]
	ldr	x10, [x1, #32]
	adds	x10, x10, #1
	csinv	x10, x10, xzr, lo
	stp	x8, x10, [x1, #24]
	stp	xzr, x14, [x0]
	str	w9, [x0]
	str	q0, [x0, #16]
	ret
LBB206_10:                              ; %bb2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_edit$instance$388b72c2b59793d5 ; -- Begin function wf_std.collections.slab.slab_edit$instance$388b72c2b59793d5
	.p2align	2
_wf_std.collections.slab.slab_edit$instance$388b72c2b59793d5: ; @"wf_std.collections.slab.slab_edit$instance$388b72c2b59793d5"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.hs	LBB207_4
; %bb.1:                                ; %bb2.i
	ldr	x9, [x1, #8]
	ldr	x10, [x0, #16]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB207_4
; %bb.2:                                ; %bb5.i
	ldr	x9, [x8]
	cbz	x9, LBB207_4
; %bb.3:                                ; %bb8.i
	mov	w0, #0                          ; =0x0
	ldrb	w9, [x2]
	strb	w9, [x8, #24]
	b	LBB207_5
LBB207_4:
	mov	w0, #1                          ; =0x1
LBB207_5:                               ; %"wf_std.collections.slab.slab_edit$instance$388b72c2b59793d5.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ret
                                        ; -- End function
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0                          ; -- Begin function wf_record_store_info$instance$aa2364d9cd38ac5f
lCPI208_0:
	.long	1                               ; 0x1
	.long	4                               ; 0x4
lCPI208_1:
	.long	1                               ; 0x1
	.long	3                               ; 0x3
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_record_store_info$instance$aa2364d9cd38ac5f
	.p2align	2
_wf_record_store_info$instance$aa2364d9cd38ac5f: ; @"wf_record_store_info$instance$aa2364d9cd38ac5f"
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	ldr	x9, [x1]
	cmp	x8, x9
	b.ne	LBB208_5
; %bb.1:                                ; %bb3
	ldr	x8, [x2, #8]
	ldr	x9, [x1, #16]
	cmp	x8, x9
	b.hs	LBB208_6
; %bb.2:                                ; %bb2.i
	ldr	x9, [x2, #16]
	ldr	x10, [x1, #32]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB208_6
; %bb.3:                                ; %bb5.i
	ldr	x9, [x8]
	cbz	x9, LBB208_6
; %bb.4:                                ; %bb4
	sub	sp, sp, #16
	ldr	x9, [x8, #8]
	ldrb	w10, [x8, #24]
	ldr	x8, [x8, #32]
	and	w10, w10, #0x1
	strb	w10, [sp, #8]
	stp	xzr, x9, [x0]
	strb	w10, [x0, #16]
	stur	wzr, [x0, #17]
	str	wzr, [x0, #20]
	str	x8, [x0, #24]
	add	sp, sp, #16
	ret
LBB208_5:                               ; %bb2
	movi.2d	v0, #0000000000000000
	str	xzr, [x0, #24]
	mov.d	v0[1], v0[0]
	stur	q0, [x0, #8]
Lloh378:
	adrp	x8, lCPI208_0@PAGE
Lloh379:
	ldr	d0, [x8, lCPI208_0@PAGEOFF]
	str	d0, [x0]
	ret
LBB208_6:                               ; %bb5
	movi.2d	v0, #0000000000000000
	str	xzr, [x0, #24]
	mov.d	v0[1], v0[0]
	stur	q0, [x0, #8]
Lloh380:
	adrp	x8, lCPI208_1@PAGE
Lloh381:
	ldr	d0, [x8, lCPI208_1@PAGEOFF]
	str	d0, [x0]
	ret
	.loh AdrpLdr	Lloh378, Lloh379
	.loh AdrpLdr	Lloh380, Lloh381
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_remove$instance$4283ac555539d10e ; -- Begin function wf_std.collections.slab.slab_remove$instance$4283ac555539d10e
	.p2align	2
_wf_std.collections.slab.slab_remove$instance$4283ac555539d10e: ; @"wf_std.collections.slab.slab_remove$instance$4283ac555539d10e"
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	ldr	x9, [x1]
	cmp	x8, x9
	b.hs	LBB209_4
; %bb.1:                                ; %bb2
	ldr	x9, [x2, #8]
	ldr	x10, [x1, #16]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB209_4
; %bb.2:                                ; %bb5
	ldr	x9, [x8]
	cbz	x9, LBB209_4
; %bb.3:                                ; %bb8
	sub	x9, x9, #1
	add	x10, x8, x9, lsl #5
	str	x9, [x8]
	ldur	q0, [x10, #8]
	ldur	q1, [x10, #24]
	stp	q0, q1, [sp, #-32]!
	str	xzr, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	stur	q0, [x0, #8]
	stur	q1, [x0, #24]
	add	sp, sp, #32
	ret
LBB209_4:                               ; %bb1
	str	xzr, [x0, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_child$instance$88bf97c7fdbb23c4 ; -- Begin function wf_collections.priority_queue.priority_queue_child$instance$88bf97c7fdbb23c4
	.p2align	2
_wf_collections.priority_queue.priority_queue_child$instance$88bf97c7fdbb23c4: ; @"wf_collections.priority_queue.priority_queue_child$instance$88bf97c7fdbb23c4"
; %bb.0:                                ; %entry
	mov	x8, x0
	add	x0, x1, #1
	ldr	x9, [x8]
	cmp	x0, x9
	b.hs	LBB210_3
; %bb.1:                                ; %bb2
	ldr	x9, [x8, #16]
	add	x8, x9, x0, lsl #5
	add	x9, x9, x1, lsl #5
	ldr	x10, [x8]
	ldr	x11, [x9]
	cmp	x10, x11
	b.lo	LBB210_4
; %bb.2:                                ; %bb3.i
	b.ls	LBB210_5
LBB210_3:
	mov	x0, x1
LBB210_4:                               ; %common.ret
	ret
LBB210_5:                               ; %bb6.i
	ldr	x10, [x8, #8]
	ldr	x11, [x9, #8]
	cmp	x10, x11
	b.lo	LBB210_4
; %bb.6:                                ; %bb9.i
	b.hi	LBB210_3
; %bb.7:                                ; %bb12.i
	ldr	x10, [x8, #16]
	ldr	x11, [x9, #16]
	cmp	x10, x11
	b.lo	LBB210_4
; %bb.8:                                ; %bb15.i
	b.hi	LBB210_3
; %bb.9:                                ; %bb18.i
	ldr	x8, [x8, #24]
	ldr	x9, [x9, #24]
	cmp	x8, x9
	csel	x0, x0, x1, lo
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$4dbd7ca4639a1dfc ; -- Begin function wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$4dbd7ca4639a1dfc
	.p2align	2
_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$4dbd7ca4639a1dfc: ; @"wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$4dbd7ca4639a1dfc"
; %bb.0:                                ; %entry
	cbz	x1, LBB211_17
; %bb.1:                                ; %bb5.lr.ph
	sub	sp, sp, #32
	ldr	x8, [x0, #16]
	add	x9, x4, #64
	b	LBB211_4
LBB211_2:                               ; %bb3.i7
                                        ;   in Loop: Header=BB211_4 Depth=1
	ldr	x12, [x4, #128]
	add	x12, x12, #1
	str	x12, [x4, #128]
LBB211_3:                               ; %wf_indexed_placed.exit17
                                        ;   in Loop: Header=BB211_4 Depth=1
	mov	x1, x11
	cmp	x10, #2
	b.lo	LBB211_16
LBB211_4:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	sub	x10, x1, #1
	lsr	x11, x10, #1
	add	x13, x8, x11, lsl #5
	add	x12, x8, x1, lsl #5
	ldr	x14, [x13]
	ldr	x15, [x12]
	cmp	x14, x15
	b.lo	LBB211_16
; %bb.5:                                ; %bb3.i
                                        ;   in Loop: Header=BB211_4 Depth=1
	b.hi	LBB211_11
; %bb.6:                                ; %bb6.i
                                        ;   in Loop: Header=BB211_4 Depth=1
	ldr	x14, [x13, #8]
	ldr	x15, [x12, #8]
	cmp	x14, x15
	b.lo	LBB211_16
; %bb.7:                                ; %bb9.i
                                        ;   in Loop: Header=BB211_4 Depth=1
	b.hi	LBB211_11
; %bb.8:                                ; %bb12.i
                                        ;   in Loop: Header=BB211_4 Depth=1
	ldr	x14, [x13, #16]
	ldr	x15, [x12, #16]
	cmp	x14, x15
	b.lo	LBB211_16
; %bb.9:                                ; %bb15.i
                                        ;   in Loop: Header=BB211_4 Depth=1
	b.hi	LBB211_11
; %bb.10:                               ; %bb18.i
                                        ;   in Loop: Header=BB211_4 Depth=1
	ldr	x14, [x13, #24]
	ldr	x15, [x12, #24]
	cmp	x14, x15
	b.ls	LBB211_16
LBB211_11:                              ; %bb8
                                        ;   in Loop: Header=BB211_4 Depth=1
	ldp	q1, q0, [x13]
	ldp	q3, q2, [x12]
	stp	q3, q2, [x13]
	stp	q1, q0, [x12]
	ldr	x13, [x13, #8]
	cmp	x13, #7
	b.hi	LBB211_13
; %bb.12:                               ; %bb2.i
                                        ;   in Loop: Header=BB211_4 Depth=1
	str	x11, [x4, x13, lsl #3]
	ldr	x14, [x9, x13, lsl #3]
	add	x14, x14, #1
	str	x14, [x9, x13, lsl #3]
	b	LBB211_14
LBB211_13:                              ; %bb3.i3
                                        ;   in Loop: Header=BB211_4 Depth=1
	ldr	x13, [x4, #128]
	add	x13, x13, #1
	str	x13, [x4, #128]
LBB211_14:                              ; %wf_indexed_placed.exit
                                        ;   in Loop: Header=BB211_4 Depth=1
	ldr	x12, [x12, #8]
	cmp	x12, #7
	b.hi	LBB211_2
; %bb.15:                               ; %bb2.i11
                                        ;   in Loop: Header=BB211_4 Depth=1
	str	x1, [x4, x12, lsl #3]
	ldr	x13, [x9, x12, lsl #3]
	add	x13, x13, #1
	str	x13, [x9, x12, lsl #3]
	b	LBB211_3
LBB211_16:
	add	sp, sp, #32
LBB211_17:                              ; %common.ret
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$69744d0f61ea6fbe ; -- Begin function wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$69744d0f61ea6fbe
	.p2align	2
_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$69744d0f61ea6fbe: ; @"wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$69744d0f61ea6fbe"
; %bb.0:                                ; %entry
	cbz	x1, LBB212_10
; %bb.1:                                ; %bb5.lr.ph
	sub	sp, sp, #32
	ldr	x8, [x0, #16]
	ldr	x9, [x4, #40]
	b	LBB212_4
LBB212_2:                               ; %bb2.i10
                                        ;   in Loop: Header=BB212_4 Depth=1
	ldr	x12, [x12, #8]
	add	x9, x4, x9, lsl #3
	add	x12, x1, x12, lsl #4
	str	x12, [x9, #8]
LBB212_3:                               ; %wf_indexed_rise_placed.exit16
                                        ;   in Loop: Header=BB212_4 Depth=1
	add	x9, x13, #1
	str	x9, [x4, #40]
	mov	x1, x11
	cmp	x10, #2
	b.lo	LBB212_9
LBB212_4:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	sub	x10, x1, #1
	lsr	x11, x10, #1
	add	x13, x8, x11, lsl #5
	add	x12, x8, x1, lsl #5
	ldp	q1, q0, [x13]
	ldp	q3, q2, [x12]
	stp	q3, q2, [x13]
	stp	q1, q0, [x12]
	cmp	x9, #4
	b.hi	LBB212_6
; %bb.5:                                ; %bb2.i
                                        ;   in Loop: Header=BB212_4 Depth=1
	ldr	x13, [x13, #8]
	add	x13, x11, x13, lsl #4
	str	x13, [x4, x9, lsl #3]
	b	LBB212_7
LBB212_6:                               ; %bb3.i
                                        ;   in Loop: Header=BB212_4 Depth=1
	ldr	x13, [x4, #48]
	add	x13, x13, #1
	str	x13, [x4, #48]
LBB212_7:                               ; %wf_indexed_rise_placed.exit
                                        ;   in Loop: Header=BB212_4 Depth=1
	add	x13, x9, #1
	cmp	x13, #4
	b.ls	LBB212_2
; %bb.8:                                ; %bb3.i5
                                        ;   in Loop: Header=BB212_4 Depth=1
	ldr	x9, [x4, #48]
	add	x9, x9, #1
	str	x9, [x4, #48]
	b	LBB212_3
LBB212_9:
	add	sp, sp, #32
LBB212_10:                              ; %bb4
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$69744d0f61ea6fbe ; -- Begin function wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$69744d0f61ea6fbe
	.p2align	2
_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$69744d0f61ea6fbe: ; @"wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$69744d0f61ea6fbe"
; %bb.0:                                ; %entry
	lsr	x8, x2, #1
	cmp	x1, x8
	b.hs	LBB213_10
; %bb.1:                                ; %bb5.lr.ph
	sub	sp, sp, #32
	ldr	x9, [x0, #16]
	mov	w10, #1                         ; =0x1
	b	LBB213_4
LBB213_2:                               ; %bb3.i6
                                        ;   in Loop: Header=BB213_4 Depth=1
	ldr	x13, [x4, #48]
	add	x13, x13, #1
	str	x13, [x4, #48]
LBB213_3:                               ; %wf_indexed_rise_placed.exit17
                                        ;   in Loop: Header=BB213_4 Depth=1
	add	x12, x12, #2
	str	x12, [x4, #40]
	mov	x1, x11
	cmp	x11, x8
	b.hs	LBB213_9
LBB213_4:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	orr	x11, x10, x1, lsl #1
	add	x14, x9, x1, lsl #5
	add	x13, x9, x11, lsl #5
	ldp	q1, q0, [x14]
	ldp	q3, q2, [x13]
	stp	q3, q2, [x14]
	stp	q1, q0, [x13]
	ldr	x12, [x4, #40]
	cmp	x12, #4
	b.hi	LBB213_6
; %bb.5:                                ; %bb2.i2
                                        ;   in Loop: Header=BB213_4 Depth=1
	ldr	x14, [x14, #8]
	add	x14, x1, x14, lsl #4
	str	x14, [x4, x12, lsl #3]
	b	LBB213_7
LBB213_6:                               ; %bb3.i
                                        ;   in Loop: Header=BB213_4 Depth=1
	ldr	x14, [x4, #48]
	add	x14, x14, #1
	str	x14, [x4, #48]
LBB213_7:                               ; %wf_indexed_rise_placed.exit
                                        ;   in Loop: Header=BB213_4 Depth=1
	add	x14, x12, #1
	cmp	x14, #4
	b.hi	LBB213_2
; %bb.8:                                ; %bb2.i11
                                        ;   in Loop: Header=BB213_4 Depth=1
	ldr	x13, [x13, #8]
	add	x13, x11, x13, lsl #4
	str	x13, [x4, x14, lsl #3]
	b	LBB213_3
LBB213_9:
	add	sp, sp, #32
LBB213_10:                              ; %bb4
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$b789e18464d776a7 ; -- Begin function wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$b789e18464d776a7
	.p2align	2
_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$b789e18464d776a7: ; @"wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$b789e18464d776a7"
; %bb.0:                                ; %entry
	cbz	x1, LBB214_17
; %bb.1:                                ; %bb5.lr.ph
	sub	sp, sp, #32
	ldr	x8, [x0, #16]
	b	LBB214_4
LBB214_2:                               ; %bb3.i7
                                        ;   in Loop: Header=BB214_4 Depth=1
	ldr	x11, [x4, #48]
	add	x11, x11, #1
	str	x11, [x4, #48]
LBB214_3:                               ; %wf_indexed_rise_placed.exit18
                                        ;   in Loop: Header=BB214_4 Depth=1
	add	x11, x13, #2
	str	x11, [x4, #40]
	mov	x1, x10
	cmp	x9, #2
	b.lo	LBB214_16
LBB214_4:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	sub	x9, x1, #1
	lsr	x10, x9, #1
	add	x12, x8, x10, lsl #5
	add	x11, x8, x1, lsl #5
	ldr	x13, [x12]
	ldr	x14, [x11]
	cmp	x13, x14
	b.lo	LBB214_16
; %bb.5:                                ; %bb3.i
                                        ;   in Loop: Header=BB214_4 Depth=1
	b.hi	LBB214_11
; %bb.6:                                ; %bb6.i
                                        ;   in Loop: Header=BB214_4 Depth=1
	ldr	x13, [x12, #8]
	ldr	x14, [x11, #8]
	cmp	x13, x14
	b.lo	LBB214_16
; %bb.7:                                ; %bb9.i
                                        ;   in Loop: Header=BB214_4 Depth=1
	b.hi	LBB214_11
; %bb.8:                                ; %bb12.i
                                        ;   in Loop: Header=BB214_4 Depth=1
	ldr	x13, [x12, #16]
	ldr	x14, [x11, #16]
	cmp	x13, x14
	b.lo	LBB214_16
; %bb.9:                                ; %bb15.i
                                        ;   in Loop: Header=BB214_4 Depth=1
	b.hi	LBB214_11
; %bb.10:                               ; %bb18.i
                                        ;   in Loop: Header=BB214_4 Depth=1
	ldr	x13, [x12, #24]
	ldr	x14, [x11, #24]
	cmp	x13, x14
	b.ls	LBB214_16
LBB214_11:                              ; %bb8
                                        ;   in Loop: Header=BB214_4 Depth=1
	ldp	q1, q0, [x12]
	ldp	q3, q2, [x11]
	stp	q3, q2, [x12]
	stp	q1, q0, [x11]
	ldr	x13, [x4, #40]
	cmp	x13, #4
	b.hi	LBB214_13
; %bb.12:                               ; %bb2.i
                                        ;   in Loop: Header=BB214_4 Depth=1
	ldr	x12, [x12, #8]
	add	x12, x10, x12, lsl #4
	str	x12, [x4, x13, lsl #3]
	b	LBB214_14
LBB214_13:                              ; %bb3.i3
                                        ;   in Loop: Header=BB214_4 Depth=1
	ldr	x12, [x4, #48]
	add	x12, x12, #1
	str	x12, [x4, #48]
LBB214_14:                              ; %wf_indexed_rise_placed.exit
                                        ;   in Loop: Header=BB214_4 Depth=1
	add	x12, x13, #1
	cmp	x12, #4
	b.hi	LBB214_2
; %bb.15:                               ; %bb2.i12
                                        ;   in Loop: Header=BB214_4 Depth=1
	ldr	x11, [x11, #8]
	add	x11, x1, x11, lsl #4
	str	x11, [x4, x12, lsl #3]
	b	LBB214_3
LBB214_16:
	add	sp, sp, #32
LBB214_17:                              ; %common.ret
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$b789e18464d776a7 ; -- Begin function wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$b789e18464d776a7
	.p2align	2
_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$b789e18464d776a7: ; @"wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$b789e18464d776a7"
; %bb.0:                                ; %entry
	lsr	x8, x2, #1
	cmp	x1, x8
	b.hs	LBB215_27
; %bb.1:                                ; %bb5.lr.ph
	sub	sp, sp, #32
	ldr	x9, [x0]
	ldr	x10, [x0, #16]
	b	LBB215_4
LBB215_2:                               ; %bb3.i10
                                        ;   in Loop: Header=BB215_4 Depth=1
	ldr	x12, [x4, #48]
	add	x12, x12, #1
	str	x12, [x4, #48]
LBB215_3:                               ; %wf_indexed_rise_placed.exit21
                                        ;   in Loop: Header=BB215_4 Depth=1
	add	x12, x14, #2
	str	x12, [x4, #40]
	mov	x1, x11
	cmp	x11, x8
	b.hs	LBB215_26
LBB215_4:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x11, x1, #1
	mov	w12, #1                         ; =0x1
	bfi	x12, x1, #1, #63
	add	x13, x11, #2
	cmp	x13, x9
	b.hs	LBB215_8
; %bb.5:                                ; %bb2.i
                                        ;   in Loop: Header=BB215_4 Depth=1
	add	x14, x10, x13, lsl #5
	add	x15, x10, x12, lsl #5
	ldr	x11, [x14]
	ldr	x16, [x15]
	cmp	x11, x16
	b.hs	LBB215_7
LBB215_6:                               ;   in Loop: Header=BB215_4 Depth=1
	mov	x11, x13
	b	LBB215_9
LBB215_7:                               ; %bb3.i.i
                                        ;   in Loop: Header=BB215_4 Depth=1
	b.ls	LBB215_21
LBB215_8:                               ;   in Loop: Header=BB215_4 Depth=1
	mov	x11, x12
LBB215_9:                               ; %"wf_collections.priority_queue.priority_queue_child$instance$88bf97c7fdbb23c4.exit"
                                        ;   in Loop: Header=BB215_4 Depth=1
	add	x13, x10, x1, lsl #5
	add	x12, x10, x11, lsl #5
	ldr	x14, [x13]
	ldr	x15, [x12]
	cmp	x14, x15
	b.lo	LBB215_26
; %bb.10:                               ; %bb3.i
                                        ;   in Loop: Header=BB215_4 Depth=1
	b.hi	LBB215_16
; %bb.11:                               ; %bb6.i
                                        ;   in Loop: Header=BB215_4 Depth=1
	ldr	x14, [x13, #8]
	ldr	x15, [x12, #8]
	cmp	x14, x15
	b.lo	LBB215_26
; %bb.12:                               ; %bb9.i
                                        ;   in Loop: Header=BB215_4 Depth=1
	b.hi	LBB215_16
; %bb.13:                               ; %bb12.i
                                        ;   in Loop: Header=BB215_4 Depth=1
	ldr	x14, [x13, #16]
	ldr	x15, [x12, #16]
	cmp	x14, x15
	b.lo	LBB215_26
; %bb.14:                               ; %bb15.i
                                        ;   in Loop: Header=BB215_4 Depth=1
	b.hi	LBB215_16
; %bb.15:                               ; %bb18.i
                                        ;   in Loop: Header=BB215_4 Depth=1
	ldr	x14, [x13, #24]
	ldr	x15, [x12, #24]
	cmp	x14, x15
	b.ls	LBB215_26
LBB215_16:                              ; %bb8
                                        ;   in Loop: Header=BB215_4 Depth=1
	ldp	q1, q0, [x13]
	ldp	q3, q2, [x12]
	stp	q3, q2, [x13]
	stp	q1, q0, [x12]
	ldr	x14, [x4, #40]
	cmp	x14, #4
	b.hi	LBB215_18
; %bb.17:                               ; %bb2.i5
                                        ;   in Loop: Header=BB215_4 Depth=1
	ldr	x13, [x13, #8]
	add	x13, x1, x13, lsl #4
	str	x13, [x4, x14, lsl #3]
	b	LBB215_19
LBB215_18:                              ; %bb3.i4
                                        ;   in Loop: Header=BB215_4 Depth=1
	ldr	x13, [x4, #48]
	add	x13, x13, #1
	str	x13, [x4, #48]
LBB215_19:                              ; %wf_indexed_rise_placed.exit
                                        ;   in Loop: Header=BB215_4 Depth=1
	add	x13, x14, #1
	cmp	x13, #4
	b.hi	LBB215_2
; %bb.20:                               ; %bb2.i15
                                        ;   in Loop: Header=BB215_4 Depth=1
	ldr	x12, [x12, #8]
	add	x12, x11, x12, lsl #4
	str	x12, [x4, x13, lsl #3]
	b	LBB215_3
LBB215_21:                              ; %bb6.i.i
                                        ;   in Loop: Header=BB215_4 Depth=1
	ldr	x11, [x14, #8]
	ldr	x16, [x15, #8]
	cmp	x11, x16
	b.lo	LBB215_6
; %bb.22:                               ; %bb9.i.i
                                        ;   in Loop: Header=BB215_4 Depth=1
	b.hi	LBB215_8
; %bb.23:                               ; %bb12.i.i
                                        ;   in Loop: Header=BB215_4 Depth=1
	ldr	x16, [x14, #16]
	ldr	x17, [x15, #16]
	mov	x11, x13
	cmp	x16, x17
	b.lo	LBB215_9
; %bb.24:                               ; %bb15.i.i
                                        ;   in Loop: Header=BB215_4 Depth=1
	mov	x11, x12
	b.hi	LBB215_9
; %bb.25:                               ; %bb18.i.i
                                        ;   in Loop: Header=BB215_4 Depth=1
	ldr	x11, [x14, #24]
	ldr	x14, [x15, #24]
	cmp	x11, x14
	csel	x11, x13, x12, lo
	b	LBB215_9
LBB215_26:
	add	sp, sp, #32
LBB215_27:                              ; %common.ret
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_new$instance$c07b06bae9914d5e ; -- Begin function wf_std.collections.slab.slab_new$instance$c07b06bae9914d5e
	.p2align	2
_wf_std.collections.slab.slab_new$instance$c07b06bae9914d5e: ; @"wf_std.collections.slab.slab_new$instance$c07b06bae9914d5e"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	mov	x20, x0
	cbz	x1, LBB216_3
; %bb.1:                                ; %window.payload.allocate.v1.i.i
	lsl	x8, x19, #6
	sub	x0, x8, x19, lsl #3
	bl	_malloc
	cbnz	x0, LBB216_4
; %bb.2:                                ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
LBB216_3:
Lloh382:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh383:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB216_4:                               ; %"wf_box_slots_new$instance$9ec8bbf9e58caef6.exit"
	stp	xzr, x19, [x20]
	stp	x0, x19, [x20, #16]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh382, Lloh383
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_new$instance$615fa5221ee98b49 ; -- Begin function wf_std.collections.hash_map.hash_map_new$instance$615fa5221ee98b49
	.p2align	2
_wf_std.collections.hash_map.hash_map_new$instance$615fa5221ee98b49: ; @"wf_std.collections.hash_map.hash_map_new$instance$615fa5221ee98b49"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x20, x1
	mov	x19, x0
	cbz	x1, LBB217_4
; %bb.1:                                ; %window.payload.allocate.v1.i.i
	lsl	x0, x20, #5
	bl	_malloc
	cbz	x0, LBB217_6
; %bb.2:                                ; %bb5.i.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x0, #8
LBB217_3:                               ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x9, #-8]
	add	x8, x8, #1
	stp	xzr, xzr, [x9, #8]
	str	xzr, [x9], #32
	cmp	x20, x8
	b.ne	LBB217_3
	b	LBB217_5
LBB217_4:
Lloh384:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh385:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB217_5:                               ; %"wf_std.collections.hash_map.hash_map_extend$instance$615fa5221ee98b49.exit"
	stp	x20, x20, [x19]
	stp	xzr, xzr, [x19, #24]
	str	x0, [x19, #16]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB217_6:                               ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
	.loh AdrpAdd	Lloh384, Lloh385
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_heapify$instance$64bc39c2fec80944 ; -- Begin function wf_collections.priority_queue.priority_queue_heapify$instance$64bc39c2fec80944
	.p2align	2
_wf_collections.priority_queue.priority_queue_heapify$instance$64bc39c2fec80944: ; @"wf_collections.priority_queue.priority_queue_heapify$instance$64bc39c2fec80944"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	ldr	q0, [x0]
	str	q0, [sp]
	ldr	x8, [x0, #16]
	str	x8, [sp, #16]
	ldr	x19, [sp]
	cmp	x19, #2
	b.lo	LBB218_3
; %bb.1:                                ; %bb2.i.preheader
	lsr	x8, x19, #1
	sub	x20, x8, #1
LBB218_2:                               ; %bb2.i
                                        ; =>This Inner Loop Header: Depth=1
	mov	x0, sp
	mov	x1, x20
	mov	x2, x19
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$e011e8cc7b7461b9
	sub	x20, x20, #1
	cmn	x20, #1
	b.ne	LBB218_2
LBB218_3:                               ; %"wf_collections.priority_queue.priority_queue_heapify$instance$64bc39c2fec80944.body.exit"
	ldp	x1, x2, [sp, #8]
	mov	x0, x19
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_lookup$instance$bcf785cf2e268cb8 ; -- Begin function wf_std.collections.hash_map.hash_map_lookup$instance$bcf785cf2e268cb8
	.p2align	2
_wf_std.collections.hash_map.hash_map_lookup$instance$bcf785cf2e268cb8: ; @"wf_std.collections.hash_map.hash_map_lookup$instance$bcf785cf2e268cb8"
; %bb.0:                                ; %entry
	ldr	x8, [x3]
	cbz	x8, LBB219_2
; %bb.1:                                ; %bb3.i
	ldr	x9, [x2]
	udiv	x10, x9, x8
	msub	x9, x10, x8, x9
	ldr	x8, [x1]
	cbnz	x8, LBB219_3
	b	LBB219_9
LBB219_2:
	mov	x9, #0                          ; =0x0
	ldr	x8, [x1]
	cbz	x8, LBB219_9
LBB219_3:                               ; %bb3
	udiv	x10, x9, x8
	msub	x9, x10, x8, x9
	ldr	x10, [x1, #16]
	mov	x11, x8
	b	LBB219_5
LBB219_4:                               ; %bb8
                                        ;   in Loop: Header=BB219_5 Depth=1
	add	x12, x9, #1
	cmp	x12, x8
	csinc	x9, xzr, x9, hs
	subs	x11, x11, #1
	b.eq	LBB219_9
LBB219_5:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	add	x12, x10, x9, lsl #5
	ldr	w13, [x12]
	cmp	w13, #1
	b.eq	LBB219_4
; %bb.6:                                ; %bb5
                                        ;   in Loop: Header=BB219_5 Depth=1
	cmp	w13, #2
	b.ne	LBB219_9
; %bb.7:                                ; %bb9
                                        ;   in Loop: Header=BB219_5 Depth=1
	ldr	x13, [x12, #8]
	ldr	x14, [x2]
	cmp	x13, x14
	b.ne	LBB219_4
; %bb.8:                                ; %bb13
	ldr	q0, [x12, #16]
	str	xzr, [x0]
	stur	q0, [x0, #8]
	ret
LBB219_9:                               ; %bb2
	stp	xzr, xzr, [x0]
	str	xzr, [x0, #16]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	ret
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_find_index$instance$c07b06bae9914d5e ; -- Begin function wf_std.collections.slab.slab_find_index$instance$c07b06bae9914d5e
	.p2align	2
_wf_std.collections.slab.slab_find_index$instance$c07b06bae9914d5e: ; @"wf_std.collections.slab.slab_find_index$instance$c07b06bae9914d5e"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.hs	LBB220_3
; %bb.1:                                ; %bb2.i
	ldr	x10, [x1, #8]
	ldr	x9, [x0, #16]
	mov	w11, #56                        ; =0x38
	madd	x9, x8, x11, x9
	ldr	x11, [x9, #40]
	cmp	x11, x10
	b.ne	LBB220_3
; %bb.2:                                ; %bb5.i
	ldr	x9, [x9]
	cmp	x9, #0
	csel	x1, xzr, x8, eq
	cset	w0, eq
	mov	w2, #0                          ; =0x0
	ret
LBB220_3:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_put$instance$cb1167c8d0732e77 ; -- Begin function wf_std.collections.hash_map.hash_map_put$instance$cb1167c8d0732e77
	.p2align	2
_wf_std.collections.hash_map.hash_map_put$instance$cb1167c8d0732e77: ; @"wf_std.collections.hash_map.hash_map_put$instance$cb1167c8d0732e77"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	ldr	q0, [x3]
	str	q0, [sp]
	ldr	x8, [x1]
	ldp	x9, x10, [x1, #24]
	adds	x10, x9, x10
	csinv	x11, x10, xzr, lo
	sub	x10, x8, x8, lsr #2
	cmp	x8, #7
	ccmp	x11, x10, #0, ls
	b.lo	LBB221_2
; %bb.1:                                ; %bb2
	mov	w11, #1                         ; =0x1
	mov	w12, #4                         ; =0x4
	cmp	x8, #4
	csel	x12, x8, x12, lo
	lsl	x12, x12, #1
	cmp	x8, #0
	csel	x11, x11, x12, eq
	cmp	x9, x10, lsr #1
	csel	x8, x11, x8, hs
	mov	x19, x0
	mov	x0, x1
	mov	x20, x1
	mov	x1, x8
	mov	x21, x2
	mov	x2, x4
	mov	x22, x4
	bl	_wf_std.collections.hash_map.hash_map_rebuild$instance$cb1167c8d0732e77
	mov	x0, x19
	mov	x1, x20
	mov	x2, x21
	mov	x4, x22
LBB221_2:                               ; %bb1
	mov	x3, sp
	bl	_wf_std.collections.hash_map.hash_map_try_put$instance$cb1167c8d0732e77
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_edit$instance$e15ab76f31b8a15f ; -- Begin function wf_std.collections.slab.slab_edit$instance$e15ab76f31b8a15f
	.p2align	2
_wf_std.collections.slab.slab_edit$instance$e15ab76f31b8a15f: ; @"wf_std.collections.slab.slab_edit$instance$e15ab76f31b8a15f"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.hs	LBB222_4
; %bb.1:                                ; %bb2.i
	ldr	x9, [x1, #8]
	ldr	x10, [x0, #16]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB222_4
; %bb.2:                                ; %bb5.i
	ldr	x9, [x8]
	cbz	x9, LBB222_4
; %bb.3:                                ; %bb8.i
	mov	w0, #0                          ; =0x0
	ldrb	w9, [x2]
	strb	w9, [x8, #24]
	b	LBB222_5
LBB222_4:
	mov	w0, #1                          ; =0x1
LBB222_5:                               ; %"wf_std.collections.slab.slab_edit$instance$e15ab76f31b8a15f.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_push_indexed$instance$f0ce656cb92d5494 ; -- Begin function wf_collections.priority_queue.priority_queue_push_indexed$instance$f0ce656cb92d5494
	.p2align	2
_wf_collections.priority_queue.priority_queue_push_indexed$instance$f0ce656cb92d5494: ; @"wf_collections.priority_queue.priority_queue_push_indexed$instance$f0ce656cb92d5494"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #80
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 80
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	ldp	q0, q1, [x2]
	stp	q0, q1, [sp]
	ldr	x21, [x1]
	cmp	x21, #8
	b.lo	LBB223_2
; %bb.1:                                ; %bb2
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	ldp	q0, q1, [sp]
	stur	q0, [x19, #8]
	stur	q1, [x19, #24]
	b	LBB223_7
LBB223_2:                               ; %bb3
	mov	x20, x1
	mov	x0, x1
	mov	x22, x4
	bl	_wf_collections.priority_queue.priority_queue_make_room$instance$8d53fd32336043f5
	mov	x4, x22
	ldr	x8, [x20]
	ldr	x9, [x20, #16]
	add	x10, x9, x8, lsl #5
	ldp	q1, q0, [sp]
	stp	q1, q0, [x10]
	add	x8, x8, #1
	str	x8, [x20]
	add	x9, x9, x21, lsl #5
	ldr	x8, [x9, #16]
	ldr	x10, [x22]
	cmp	x8, x10
	b.hs	LBB223_6
; %bb.3:                                ; %bb2.i.i.i
	ldr	x9, [x9, #24]
	ldr	x10, [x4, #16]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB223_6
; %bb.4:                                ; %bb5.i.i.i
	ldr	x9, [x8]
	cbz	x9, LBB223_6
; %bb.5:                                ; %bb8.i.i.i
	str	x21, [x8, #32]
LBB223_6:                               ; %"wf_record_report_position$instance$3ad8b32886f5e3ce.exit"
	mov	x0, x20
	mov	x1, x21
	bl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$f0ce656cb92d5494
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	str	xzr, [x19, #32]
LBB223_7:                               ; %bb2
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_insert$instance$c07b06bae9914d5e ; -- Begin function wf_std.collections.slab.slab_insert$instance$c07b06bae9914d5e
	.p2align	2
_wf_std.collections.slab.slab_insert$instance$c07b06bae9914d5e: ; @"wf_std.collections.slab.slab_insert$instance$c07b06bae9914d5e"
; %bb.0:                                ; %entry
	sub	sp, sp, #16
	ldp	x9, x12, [x2]
	ldrb	w10, [x2, #16]
	ldr	w11, [x2, #20]
	mov	x14, x2
	ldr	w13, [x14, #17]!
	ldr	x8, [x2, #24]
	str	w13, [sp, #8]
	stur	w11, [sp, #11]
	ldr	x11, [x1, #24]
	ldr	x13, [x1]
	cmp	x11, x13
	b.hs	LBB224_4
; %bb.1:                                ; %bb2
	ldr	x13, [x1, #16]
	mov	w14, #56                        ; =0x38
	madd	x14, x11, x14, x13
	ldr	x13, [x14]
	cbnz	x13, LBB224_6
; %bb.2:                                ; %bb5
	ldr	x13, [x14, #40]
	cmp	x13, #2
	b.hi	LBB224_6
; %bb.3:                                ; %bb8
	ldr	x15, [x14, #48]
	stp	x9, x12, [x14, #8]
	strb	w10, [x14, #24]
	ldr	w10, [sp, #8]
	stur	w10, [x14, #25]
	ldur	w10, [sp, #11]
	str	w10, [x14, #28]
	str	x8, [x14, #32]
	mov	w8, #1                          ; =0x1
	str	x8, [x14]
	str	x15, [x1, #24]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	str	xzr, [x0, #32]
	stp	x11, x13, [x0, #8]
	add	sp, sp, #16
	ret
LBB224_4:                               ; %bb3
	ldr	x15, [x1, #8]
	cmp	x13, x15
	b.hs	LBB224_6
; %bb.5:                                ; %bb11
	ldur	w15, [x14, #3]
	stur	w15, [sp, #3]
	ldr	w14, [x14]
	str	w14, [sp]
	ldr	x14, [x1, #16]
	mov	w15, #56                        ; =0x38
	madd	x14, x13, x15, x14
	mov	w15, #1                         ; =0x1
	stp	x15, x9, [x14]
	str	x12, [x14, #16]
	strb	w10, [x14, #24]
	ldr	w9, [sp]
	stur	w9, [x14, #25]
	ldur	w9, [sp, #3]
	str	w9, [x14, #28]
	stp	x8, xzr, [x14, #32]
	str	x11, [x14, #48]
	add	x8, x13, #1
	str	x8, [x1]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	str	xzr, [x0, #32]
	str	x13, [x0, #8]
	add	sp, sp, #16
	ret
LBB224_6:                               ; %bb4
	stp	xzr, x9, [x0]
	mov	w11, #1                         ; =0x1
	str	w11, [x0]
	str	x12, [x0, #16]
	strb	w10, [x0, #24]
	ldr	w9, [sp, #8]
	stur	w9, [x0, #25]
	ldur	w9, [sp, #11]
	str	w9, [x0, #28]
	str	x8, [x0, #32]
	add	sp, sp, #16
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$f0ce656cb92d5494 ; -- Begin function wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$f0ce656cb92d5494
	.p2align	2
_wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$f0ce656cb92d5494: ; @"wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$f0ce656cb92d5494"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	mov	x19, x0
	ldr	x8, [x1]
	sub	x8, x8, #1
	ldr	x10, [x1, #16]
	add	x11, x10, x8, lsl #5
	str	x8, [x1]
	ldp	q0, q1, [x11]
	stp	q0, q1, [sp]
	cmp	x2, x8
	b.hs	LBB225_10
; %bb.1:                                ; %bb2
	add	x9, x10, x2, lsl #5
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp]
	ldp	q0, q1, [x11]
	stp	q0, q1, [x9]
	ldr	x11, [x9, #16]
	ldr	x12, [x4]
	cmp	x11, x12
	b.hs	LBB225_5
; %bb.2:                                ; %bb2.i.i.i
	ldr	x12, [x9, #24]
	ldr	x13, [x4, #16]
	mov	w14, #56                        ; =0x38
	madd	x11, x11, x14, x13
	ldr	x13, [x11, #40]
	cmp	x13, x12
	b.ne	LBB225_5
; %bb.3:                                ; %bb5.i.i.i
	ldr	x12, [x11]
	cbz	x12, LBB225_5
; %bb.4:                                ; %bb8.i.i.i
	str	x2, [x11, #32]
LBB225_5:                               ; %"wf_record_report_position$instance$3ad8b32886f5e3ce.exit"
	cbz	x2, LBB225_7
; %bb.6:                                ; %bb2.i
	lsl	x11, x2, #4
	sub	x11, x11, #16
	and	x11, x11, #0xffffffffffffffe0
	add	x10, x10, x11
	ldr	x11, [x10]
	ldr	x12, [x9]
	cmp	x11, x12
	b.hs	LBB225_8
LBB225_7:                               ; %bb1.i
	mov	x0, x1
	mov	x1, x2
	mov	x2, x8
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$f0ce656cb92d5494
	b	LBB225_10
LBB225_8:                               ; %bb3.i.i
	b.ls	LBB225_11
LBB225_9:                               ; %bb5.i
	mov	x0, x1
	mov	x1, x2
	bl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$f0ce656cb92d5494
LBB225_10:                              ; %bb1
	ldp	q0, q1, [sp]
	stp	q0, q1, [x19]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB225_11:                              ; %bb6.i.i
	ldr	x11, [x10, #8]
	ldr	x12, [x9, #8]
	cmp	x11, x12
	b.lo	LBB225_7
; %bb.12:                               ; %bb9.i.i
	b.hi	LBB225_9
; %bb.13:                               ; %bb12.i.i
	ldr	x11, [x10, #16]
	ldr	x12, [x9, #16]
	cmp	x11, x12
	b.lo	LBB225_7
; %bb.14:                               ; %bb15.i.i
	b.hi	LBB225_9
; %bb.15:                               ; %bb18.i.i
	ldr	x10, [x10, #24]
	ldr	x9, [x9, #24]
	cmp	x10, x9
	b.ls	LBB225_7
	b	LBB225_9
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_peek_at$instance$89e474f4c5bc47c4 ; -- Begin function wf_collections.priority_queue.priority_queue_peek_at$instance$89e474f4c5bc47c4
	.p2align	2
_wf_collections.priority_queue.priority_queue_peek_at$instance$89e474f4c5bc47c4: ; @"wf_collections.priority_queue.priority_queue_peek_at$instance$89e474f4c5bc47c4"
; %bb.0:                                ; %entry
	ldr	x8, [x1, #16]
	add	x8, x8, x2, lsl #5
	ldp	q1, q0, [x8]
	stp	q1, q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_replace_at_indexed$instance$f0ce656cb92d5494 ; -- Begin function wf_collections.priority_queue.priority_queue_replace_at_indexed$instance$f0ce656cb92d5494
	.p2align	2
_wf_collections.priority_queue.priority_queue_replace_at_indexed$instance$f0ce656cb92d5494: ; @"wf_collections.priority_queue.priority_queue_replace_at_indexed$instance$f0ce656cb92d5494"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	mov	x4, x5
	mov	x8, x2
	mov	x19, x0
	ldr	x2, [x1]
	ldr	x10, [x1, #16]
	add	x9, x10, x8, lsl #5
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp]
	ldp	q0, q1, [x3]
	stp	q0, q1, [x9]
	ldr	x11, [x9, #16]
	ldr	x12, [x5]
	cmp	x11, x12
	b.hs	LBB227_4
; %bb.1:                                ; %bb2.i.i.i
	ldr	x12, [x9, #24]
	ldr	x13, [x4, #16]
	mov	w14, #56                        ; =0x38
	madd	x11, x11, x14, x13
	ldr	x13, [x11, #40]
	cmp	x13, x12
	b.ne	LBB227_4
; %bb.2:                                ; %bb5.i.i.i
	ldr	x12, [x11]
	cbz	x12, LBB227_4
; %bb.3:                                ; %bb8.i.i.i
	str	x8, [x11, #32]
LBB227_4:                               ; %"wf_record_report_position$instance$3ad8b32886f5e3ce.exit"
	cbz	x8, LBB227_6
; %bb.5:                                ; %bb2.i
	lsl	x11, x8, #4
	sub	x11, x11, #16
	and	x11, x11, #0xffffffffffffffe0
	add	x10, x10, x11
	ldr	x11, [x10]
	ldr	x12, [x9]
	cmp	x11, x12
	b.hs	LBB227_7
LBB227_6:                               ; %bb1.i
	mov	x0, x1
	mov	x1, x8
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$f0ce656cb92d5494
	b	LBB227_9
LBB227_7:                               ; %bb3.i.i
	b.ls	LBB227_10
LBB227_8:                               ; %bb5.i
	mov	x0, x1
	mov	x1, x8
	bl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$f0ce656cb92d5494
LBB227_9:                               ; %"wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$f0ce656cb92d5494.exit"
	ldp	q0, q1, [sp]
	stp	q0, q1, [x19]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB227_10:                              ; %bb6.i.i
	ldr	x11, [x10, #8]
	ldr	x12, [x9, #8]
	cmp	x11, x12
	b.lo	LBB227_6
; %bb.11:                               ; %bb9.i.i
	b.hi	LBB227_8
; %bb.12:                               ; %bb12.i.i
	ldr	x11, [x10, #16]
	ldr	x12, [x9, #16]
	cmp	x11, x12
	b.lo	LBB227_6
; %bb.13:                               ; %bb15.i.i
	b.hi	LBB227_8
; %bb.14:                               ; %bb18.i.i
	ldr	x10, [x10, #24]
	ldr	x9, [x9, #24]
	cmp	x10, x9
	b.ls	LBB227_6
	b	LBB227_8
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_remove$instance$cb1167c8d0732e77 ; -- Begin function wf_std.collections.hash_map.hash_map_remove$instance$cb1167c8d0732e77
	.p2align	2
_wf_std.collections.hash_map.hash_map_remove$instance$cb1167c8d0732e77: ; @"wf_std.collections.hash_map.hash_map_remove$instance$cb1167c8d0732e77"
; %bb.0:                                ; %entry
	ldr	x8, [x1, #24]
	cbz	x8, LBB228_10
; %bb.1:                                ; %bb3
	ldr	x9, [x3]
	cbz	x9, LBB228_3
; %bb.2:                                ; %bb3.i.i.i
	ldr	x10, [x2]
	udiv	x11, x10, x9
	msub	x10, x11, x9, x10
	ldr	x9, [x1]
	cbnz	x9, LBB228_4
	b	LBB228_10
LBB228_3:
	mov	x10, #0                         ; =0x0
	ldr	x9, [x1]
	cbz	x9, LBB228_10
LBB228_4:                               ; %bb3.i.i
	udiv	x11, x10, x9
	msub	x10, x11, x9, x10
	ldr	x11, [x1, #16]
	mov	x12, x9
	b	LBB228_6
LBB228_5:                               ; %bb8.i.i
                                        ;   in Loop: Header=BB228_6 Depth=1
	add	x13, x10, #1
	cmp	x13, x9
	csinc	x10, xzr, x10, hs
	subs	x12, x12, #1
	b.eq	LBB228_10
LBB228_6:                               ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x13, x11, x10, lsl #5
	ldr	w14, [x13]
	cmp	w14, #1
	b.eq	LBB228_5
; %bb.7:                                ; %bb5.i.i
                                        ;   in Loop: Header=BB228_6 Depth=1
	cmp	w14, #2
	b.ne	LBB228_10
; %bb.8:                                ; %bb3.i3.i.i
                                        ;   in Loop: Header=BB228_6 Depth=1
	ldr	x14, [x13, #8]
	ldr	x15, [x2]
	cmp	x14, x15
	b.ne	LBB228_5
; %bb.9:                                ; %bb6
	mov	w9, #1                          ; =0x1
	str	w9, [x13]
	sub	x8, x8, #1
	ldr	q0, [x13, #16]
	stp	xzr, xzr, [x13, #16]
	str	xzr, [x13, #8]
	ldr	x10, [x1, #32]
	adds	x10, x10, #1
	csinv	x10, x10, xzr, lo
	stp	x8, x10, [x1, #24]
	stp	xzr, x14, [x0]
	str	w9, [x0]
	str	q0, [x0, #16]
	ret
LBB228_10:                              ; %bb2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_remove$instance$c07b06bae9914d5e ; -- Begin function wf_std.collections.slab.slab_remove$instance$c07b06bae9914d5e
	.p2align	2
_wf_std.collections.slab.slab_remove$instance$c07b06bae9914d5e: ; @"wf_std.collections.slab.slab_remove$instance$c07b06bae9914d5e"
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	ldr	x9, [x1]
	cmp	x8, x9
	b.hs	LBB229_6
; %bb.1:                                ; %bb2
	ldr	x10, [x2, #8]
	ldr	x9, [x1, #16]
	mov	w11, #56                        ; =0x38
	madd	x11, x8, x11, x9
	ldr	x12, [x11, #40]
	cmp	x12, x10
	b.ne	LBB229_6
; %bb.2:                                ; %bb5
	ldr	x12, [x11]
	cbz	x12, LBB229_6
; %bb.3:                                ; %bb8
	sub	x12, x12, #1
	add	x13, x11, x12, lsl #5
	str	x12, [x11]
	ldur	q0, [x13, #8]
	ldur	q1, [x13, #24]
	stp	q0, q1, [sp, #-32]!
	cmp	x10, #2
	b.hs	LBB229_5
; %bb.4:                                ; %bb11
	add	x10, x10, #1
	mov	w11, #56                        ; =0x38
	ldr	x12, [x1, #24]
	madd	x9, x8, x11, x9
	stp	x10, x12, [x9, #40]
	str	x8, [x1, #24]
LBB229_5:                               ; %bb10
	str	xzr, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	ldp	q0, q1, [sp]
	stur	q0, [x0, #8]
	stur	q1, [x0, #24]
	add	sp, sp, #32
	ret
LBB229_6:                               ; %bb1
	str	xzr, [x0, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_indexed_read$instance$d1c030b182ed6bbc ; -- Begin function wf_indexed_read$instance$d1c030b182ed6bbc
	.p2align	2
_wf_indexed_read$instance$d1c030b182ed6bbc: ; @"wf_indexed_read$instance$d1c030b182ed6bbc"
; %bb.0:                                ; %entry
	ldr	x8, [x1, #8]
	ldp	x9, x8, [x8]
	add	x10, x9, #101
	cmp	x8, x10
	csinv	x0, x9, xzr, eq
	ret
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_visit$instance$6239a00b3a29f168 ; -- Begin function wf_std.collections.slab.slab_visit$instance$6239a00b3a29f168
	.p2align	2
_wf_std.collections.slab.slab_visit$instance$6239a00b3a29f168: ; @"wf_std.collections.slab.slab_visit$instance$6239a00b3a29f168"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.hs	LBB231_4
; %bb.1:                                ; %bb2.i
	ldr	x9, [x1, #8]
	ldr	x10, [x0, #16]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB231_4
; %bb.2:                                ; %bb5.i
	ldr	x9, [x8]
	cbz	x9, LBB231_4
; %bb.3:                                ; %bb8.i
	mov	w0, #0                          ; =0x0
	ldr	x8, [x8, #16]
	ldp	x9, x8, [x8]
	add	x10, x9, #101
	cmp	x8, x10
	csinv	x1, x9, xzr, eq
	mov	w2, #0                          ; =0x0
	ret
LBB231_4:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_edit$instance$77325daaae41e62d ; -- Begin function wf_std.collections.slab.slab_edit$instance$77325daaae41e62d
	.p2align	2
_wf_std.collections.slab.slab_edit$instance$77325daaae41e62d: ; @"wf_std.collections.slab.slab_edit$instance$77325daaae41e62d"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.hs	LBB232_4
; %bb.1:                                ; %bb2.i
	ldr	x9, [x1, #8]
	ldr	x10, [x0, #16]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB232_4
; %bb.2:                                ; %bb5.i
	ldr	x9, [x8]
	cbz	x9, LBB232_4
; %bb.3:                                ; %bb8.i
	mov	w0, #0                          ; =0x0
	ldr	x9, [x2]
	ldr	x10, [x8, #16]
	str	x10, [x2]
	str	x9, [x8, #16]
	b	LBB232_5
LBB232_4:
	mov	w0, #1                          ; =0x1
LBB232_5:                               ; %"wf_std.collections.slab.slab_edit$instance$77325daaae41e62d.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_len$instance$8d53fd32336043f5 ; -- Begin function wf_collections.priority_queue.priority_queue_len$instance$8d53fd32336043f5
	.p2align	2
_wf_collections.priority_queue.priority_queue_len$instance$8d53fd32336043f5: ; @"wf_collections.priority_queue.priority_queue_len$instance$8d53fd32336043f5"
; %bb.0:                                ; %entry
	ldr	x0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_visit$instance$cb0114172b9e3820 ; -- Begin function wf_std.collections.slab.slab_visit$instance$cb0114172b9e3820
	.p2align	2
_wf_std.collections.slab.slab_visit$instance$cb0114172b9e3820: ; @"wf_std.collections.slab.slab_visit$instance$cb0114172b9e3820"
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	ldr	x9, [x1]
	cmp	x8, x9
	b.hs	LBB234_4
; %bb.1:                                ; %bb2
	ldr	x9, [x2, #8]
	ldr	x10, [x1, #16]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB234_4
; %bb.2:                                ; %bb5
	ldr	x9, [x8]
	cbz	x9, LBB234_4
; %bb.3:                                ; %bb8
	sub	sp, sp, #16
	ldr	x9, [x8, #8]
	ldrb	w10, [x8, #24]
	ldr	x8, [x8, #32]
	and	w10, w10, #0x1
	strb	w10, [sp, #8]
	stp	x9, xzr, [x0, #8]
	str	xzr, [x0]
	strb	w10, [x0, #16]
	str	x8, [x0, #24]
	add	sp, sp, #16
	ret
LBB234_4:                               ; %bb1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	ret
                                        ; -- End function
	.globl	_wf_record_set_position$instance$4a70da04567deb49 ; -- Begin function wf_record_set_position$instance$4a70da04567deb49
	.p2align	2
_wf_record_set_position$instance$4a70da04567deb49: ; @"wf_record_set_position$instance$4a70da04567deb49"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	str	x8, [x1, #24]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_record_store_expire$instance$e67a16f596c8720d ; -- Begin function wf_record_store_expire$instance$e67a16f596c8720d
	.p2align	2
_wf_record_store_expire$instance$e67a16f596c8720d: ; @"wf_record_store_expire$instance$e67a16f596c8720d"
; %bb.0:                                ; %entry
	sub	sp, sp, #496
	stp	x28, x27, [sp, #400]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #416]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #432]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #448]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #464]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #480]            ; 16-byte Folded Spill
	mov	x23, x0
	ldr	x8, [x23, #88]!
	cbz	x8, LBB236_42
; %bb.1:                                ; %bb5.lr.ph
	mov	x20, x2
	mov	x21, x1
	mov	x22, x0
	mov	x19, #0                         ; =0x0
	add	x24, sp, #32
	add	x10, x2, #512
	add	x9, x2, #1024
	stp	x9, x10, [sp, #16]              ; 16-byte Folded Spill
	mov	w27, #8                         ; =0x8
	mov	w28, #56                        ; =0x38
	mov	w26, #1                         ; =0x1
LBB236_2:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x22, #104]
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp, #32]
	ldr	x10, [sp, #32]
	cmp	x10, x21
	b.hi	LBB236_43
; %bb.3:                                ; %bb8
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldur	x25, [x22, #16]
	subs	x2, x8, #1
	add	x8, x9, x2, lsl #5
	str	x2, [x23]
	ldp	q0, q1, [x8]
	stp	q0, q1, [sp, #368]
	b.eq	LBB236_9
; %bb.4:                                ; %bb2.i
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp, #368]
	ldp	q0, q1, [x8]
	stp	q0, q1, [x9]
	ldr	x8, [x9, #16]
	cmp	x8, x25
	b.hs	LBB236_8
; %bb.5:                                ; %bb2.i.i.i.i
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldr	x9, [x9, #24]
	ldr	x10, [x22, #32]
	madd	x8, x8, x28, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB236_8
; %bb.6:                                ; %bb5.i.i.i.i
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldr	x9, [x8]
	cbz	x9, LBB236_8
; %bb.7:                                ; %bb8.i.i.i.i
                                        ;   in Loop: Header=BB236_2 Depth=1
	str	xzr, [x8, #32]
LBB236_8:                               ; %"wf_record_report_position$instance$3ad8b32886f5e3ce.exit.i"
                                        ;   in Loop: Header=BB236_2 Depth=1
	add	x4, x22, #16
	mov	x0, x23
	mov	x1, #0                          ; =0x0
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$f0ce656cb92d5494
LBB236_9:                               ; %"wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$f0ce656cb92d5494.exit"
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldp	q0, q1, [sp, #368]
	stp	q0, q1, [x24, #32]
	str	x27, [sp, #352]
	ldur	q0, [x24, #48]
	stur	q0, [x24, #64]
	ldr	x8, [sp, #96]
	cmp	x8, x25
	b.hs	LBB236_13
; %bb.10:                               ; %bb2.i.i
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldr	x10, [sp, #104]
	ldr	x9, [x22, #32]
	madd	x9, x8, x28, x9
	ldr	x8, [x9, #40]
	cmp	x8, x10
	b.ne	LBB236_13
; %bb.11:                               ; %bb5.i.i
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldr	x8, [x9]
	cbz	x8, LBB236_13
; %bb.12:                               ; %bb8.i.i
                                        ;   in Loop: Header=BB236_2 Depth=1
	mov	w8, #0                          ; =0x0
	str	x27, [x9, #32]
	b	LBB236_14
LBB236_13:                              ;   in Loop: Header=BB236_2 Depth=1
	mov	w8, #1                          ; =0x1
LBB236_14:                              ; %"wf_std.collections.slab.slab_edit$instance$f11a17af73d113d5.exit"
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldp	q0, q1, [x22, #64]
	stur	q0, [x24, #152]
	stur	q1, [x24, #168]
	ldr	q0, [x22, #96]
	stur	q0, [x24, #184]
	ldp	q0, q1, [x22]
	stur	q0, [x24, #88]
	stur	q1, [x24, #104]
	ldp	q0, q1, [x22, #32]
	stur	q0, [x24, #120]
	str	w8, [sp, #112]
	strh	wzr, [sp, #116]
	ldr	x8, [x22, #112]
	stur	x8, [x24, #200]
	stur	q1, [x24, #136]
	ldur	q0, [x24, #48]
	stur	q0, [x24, #208]
	ldr	x25, [sp, #120]
	ldr	x1, [sp, #72]
	str	x25, [sp, #256]
	ldur	q0, [x24, #48]
	stur	q0, [x24, #232]
	add	x2, x24, #224
	mov	x0, x22
	bl	_wf_record_store_detach$instance$3ad8b32886f5e3ce
	ldr	x8, [x22]
	cmp	x25, x8
	b.ne	LBB236_21
; %bb.15:                               ; %bb3.i.i
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldr	x8, [sp, #264]
	ldur	x9, [x22, #16]
	cmp	x8, x9
	b.hs	LBB236_22
; %bb.16:                               ; %bb2.i.i.i
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldr	x10, [sp, #272]
	ldr	x9, [x22, #32]
	madd	x11, x8, x28, x9
	ldr	x12, [x11, #40]
	cmp	x12, x10
	b.ne	LBB236_22
; %bb.17:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldr	x12, [x11]
	cbz	x12, LBB236_22
; %bb.18:                               ; %bb2.i7
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldrb	w13, [x11, #24]
	ldr	x14, [x11, #32]
	and	w13, w13, #0x1
	strb	w13, [sp, #360]
	ldrb	w15, [x22, #8]
	cmp	x14, #8
	csinc	w13, w13, wzr, eq
	tbz	w15, #0, LBB236_25
; %bb.19:                               ; %bb2.i7
                                        ;   in Loop: Header=BB236_2 Depth=1
	tbz	w13, #0, LBB236_25
; %bb.20:                               ;   in Loop: Header=BB236_2 Depth=1
	mov	w8, #9                          ; =0x9
	b	LBB236_23
LBB236_21:                              ;   in Loop: Header=BB236_2 Depth=1
	mov	w8, #4                          ; =0x4
	b	LBB236_23
LBB236_22:                              ; %bb5.i.i6
                                        ;   in Loop: Header=BB236_2 Depth=1
	mov	w8, #3                          ; =0x3
LBB236_23:                              ; %"wf_record_store_delete$instance$3ad8b32886f5e3ce.exit.thread"
                                        ;   in Loop: Header=BB236_2 Depth=1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x24, #256]
	str	w26, [sp, #280]
	str	w8, [sp, #284]
LBB236_24:                              ; %bb9
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldr	x8, [x23]
	cbnz	x8, LBB236_2
	b	LBB236_43
LBB236_25:                              ; %bb8.i.i8
                                        ;   in Loop: Header=BB236_2 Depth=1
	sub	x12, x12, #1
	add	x13, x11, x12, lsl #5
	str	x12, [x11]
	ldur	q0, [x13, #8]
	ldur	q1, [x13, #24]
	stp	q0, q1, [sp, #368]
	cmp	x10, #1
	b.hi	LBB236_27
; %bb.26:                               ; %bb11.i.i
                                        ;   in Loop: Header=BB236_2 Depth=1
	add	x10, x10, #1
	ldr	x11, [x22, #40]
	madd	x9, x8, x28, x9
	stp	x10, x11, [x9, #40]
	str	x8, [x22, #40]
LBB236_27:                              ; %bb10
                                        ;   in Loop: Header=BB236_2 Depth=1
	str	xzr, [sp, #280]
	ldp	q0, q1, [sp, #368]
	stp	q0, q1, [x24, #256]
	ldp	q1, q0, [x24, #256]
	stp	q1, q0, [x24, #288]
	ldr	x0, [sp, #328]
	ldp	x8, x9, [x0]
	add	x10, x8, #101
	cmp	x9, x10
	csinv	x8, x8, xzr, eq
	cmp	x8, #64
	b.hs	LBB236_31
; %bb.28:                               ; %bb2.i18
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldr	x9, [sp, #320]
	ldr	x10, [x20, x8, lsl #3]
	cmp	x10, x9
	b.eq	LBB236_30
; %bb.29:                               ; %bb5.i20
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldr	x9, [x20, #1304]
	add	x9, x9, #1
	str	x9, [x20, #1304]
LBB236_30:                              ; %bb4.i
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldr	x10, [sp, #24]                  ; 8-byte Folded Reload
	ldr	x9, [x10, x8, lsl #3]
	add	x9, x9, #1
	str	x9, [x10, x8, lsl #3]
	ldrb	w9, [x20, #1296]
	tbnz	w9, #0, LBB236_32
	b	LBB236_41
LBB236_31:                              ; %bb3.i11
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldr	x9, [x20, #1304]
	add	x9, x9, #1
	str	x9, [x20, #1304]
	ldrb	w9, [x20, #1296]
	tbz	w9, #0, LBB236_41
LBB236_32:                              ; %bb8.i14
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldrb	w9, [sp, #336]
	tbz	w9, #0, LBB236_34
; %bb.33:                               ; %bb11.i17
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldr	x9, [x20, #1304]
	add	x9, x9, #1
	str	x9, [x20, #1304]
LBB236_34:                              ; %bb10.i
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldr	x9, [sp, #344]
	cmp	x9, #8
	b.eq	LBB236_36
; %bb.35:                               ; %bb14.i
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldr	x9, [x20, #1304]
	add	x9, x9, #1
	str	x9, [x20, #1304]
LBB236_36:                              ; %bb13.i15
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldr	x9, [x20, #1288]
	cmp	x9, #31
	b.hi	LBB236_39
; %bb.37:                               ; %bb13.i15
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldr	x10, [x20, #1280]
	cmp	x9, x10
	b.hs	LBB236_39
; %bb.38:                               ; %bb20.i
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldr	x10, [sp, #16]                  ; 8-byte Folded Reload
	ldr	x10, [x10, x9, lsl #3]
	cmp	x10, x8
	b.eq	LBB236_40
LBB236_39:                              ; %bb16.sink.split.i
                                        ;   in Loop: Header=BB236_2 Depth=1
	ldr	x8, [x20, #1304]
	add	x8, x8, #1
	str	x8, [x20, #1304]
LBB236_40:                              ; %bb16.i
                                        ;   in Loop: Header=BB236_2 Depth=1
	add	x8, x9, #1
	str	x8, [x20, #1288]
LBB236_41:                              ; %"wf_indexed_release$instance$cfa19887953541da.exit"
                                        ;   in Loop: Header=BB236_2 Depth=1
	bl	_free
	add	x19, x19, #1
	b	LBB236_24
LBB236_42:
	mov	x19, #0                         ; =0x0
LBB236_43:                              ; %bb2
	mov	x0, x19
	ldp	x29, x30, [sp, #480]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #464]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #448]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #432]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #416]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #400]            ; 16-byte Folded Reload
	add	sp, sp, #496
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_free$instance$062aa17160873f66 ; -- Begin function wf_std.collections.hash_map.hash_map_free$instance$062aa17160873f66
	.p2align	2
_wf_std.collections.hash_map.hash_map_free$instance$062aa17160873f66: ; @"wf_std.collections.hash_map.hash_map_free$instance$062aa17160873f66"
; %bb.0:                                ; %entry
	ldr	x8, [x0, #8]
	cbz	x8, LBB237_2
; %bb.1:                                ; %slots.release.drop.6.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #16]
	bl	_free
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB237_2:                               ; %"wf_free_empty$instance$16f094be4fd843b6.exit"
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_free$instance$45ff9783f97b77eb ; -- Begin function wf_collections.priority_queue.priority_queue_free$instance$45ff9783f97b77eb
	.p2align	2
_wf_collections.priority_queue.priority_queue_free$instance$45ff9783f97b77eb: ; @"wf_collections.priority_queue.priority_queue_free$instance$45ff9783f97b77eb"
; %bb.0:                                ; %entry
	ldr	x8, [x0, #8]
	cbz	x8, LBB238_2
; %bb.1:                                ; %slots.release.drop.6.i
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #16]
	bl	_free
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB238_2:                               ; %"wf_free_empty$instance$401ab120abe5d512.exit"
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_free$instance$7c376bc3f4ad4ade ; -- Begin function wf_std.collections.slab.slab_free$instance$7c376bc3f4ad4ade
	.p2align	2
_wf_std.collections.slab.slab_free$instance$7c376bc3f4ad4ade: ; @"wf_std.collections.slab.slab_free$instance$7c376bc3f4ad4ade"
; %bb.0:                                ; %entry
	sub	sp, sp, #128
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	ldp	x22, x21, [x0]
	ldr	x19, [x0, #16]
	cbz	x22, LBB239_19
; %bb.1:                                ; %bb5.lr.ph
	mov	x20, x1
	add	x23, x1, #512
	add	x24, x1, #1024
	mov	w8, #56                         ; =0x38
	madd	x8, x22, x8, x19
	sub	x25, x8, #56
	mov	x26, sp
	b	LBB239_6
LBB239_2:                               ; %bb16.sink.split.i
                                        ;   in Loop: Header=BB239_6 Depth=1
	ldr	x8, [x20, #1304]
	add	x8, x8, #1
	str	x8, [x20, #1304]
LBB239_3:                               ; %bb16.i
                                        ;   in Loop: Header=BB239_6 Depth=1
	add	x8, x9, #1
	str	x8, [x20, #1288]
LBB239_4:                               ; %"wf_indexed_release$instance$cfa19887953541da.exit"
                                        ;   in Loop: Header=BB239_6 Depth=1
	bl	_free
LBB239_5:                               ; %bb6
                                        ;   in Loop: Header=BB239_6 Depth=1
	sub	x25, x25, #56
	sub	x22, x22, #1
	cbz	x22, LBB239_19
LBB239_6:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q0, q1, [x25]
	stp	q0, q1, [sp]
	ldr	x8, [x25, #32]
	str	x8, [sp, #32]
	ldr	x8, [sp]
	cbz	x8, LBB239_5
; %bb.7:                                ; %bb7
                                        ;   in Loop: Header=BB239_6 Depth=1
	sub	x8, x8, #1
	add	x9, x26, x8, lsl #5
	str	x8, [sp]
	ldr	x0, [x9, #16]
	ldp	x8, x10, [x0]
	add	x11, x8, #101
	cmp	x10, x11
	csinv	x8, x8, xzr, eq
	cmp	x8, #64
	b.hs	LBB239_11
; %bb.8:                                ; %bb2.i
                                        ;   in Loop: Header=BB239_6 Depth=1
	ldr	x10, [x9, #8]
	ldr	x11, [x20, x8, lsl #3]
	cmp	x11, x10
	b.eq	LBB239_10
; %bb.9:                                ; %bb5.i
                                        ;   in Loop: Header=BB239_6 Depth=1
	ldr	x10, [x20, #1304]
	add	x10, x10, #1
	str	x10, [x20, #1304]
LBB239_10:                              ; %bb4.i
                                        ;   in Loop: Header=BB239_6 Depth=1
	ldr	x10, [x23, x8, lsl #3]
	add	x10, x10, #1
	str	x10, [x23, x8, lsl #3]
	ldrb	w10, [x20, #1296]
	tbz	w10, #0, LBB239_4
	b	LBB239_12
LBB239_11:                              ; %bb3.i
                                        ;   in Loop: Header=BB239_6 Depth=1
	ldr	x10, [x20, #1304]
	add	x10, x10, #1
	str	x10, [x20, #1304]
	ldrb	w10, [x20, #1296]
	tbz	w10, #0, LBB239_4
LBB239_12:                              ; %bb8.i
                                        ;   in Loop: Header=BB239_6 Depth=1
	ldrb	w10, [x9, #24]
	tbz	w10, #0, LBB239_14
; %bb.13:                               ; %bb11.i
                                        ;   in Loop: Header=BB239_6 Depth=1
	ldr	x10, [x20, #1304]
	add	x10, x10, #1
	str	x10, [x20, #1304]
LBB239_14:                              ; %bb10.i
                                        ;   in Loop: Header=BB239_6 Depth=1
	ldr	x9, [x9, #32]
	cmp	x9, #8
	b.eq	LBB239_16
; %bb.15:                               ; %bb14.i
                                        ;   in Loop: Header=BB239_6 Depth=1
	ldr	x9, [x20, #1304]
	add	x9, x9, #1
	str	x9, [x20, #1304]
LBB239_16:                              ; %bb13.i
                                        ;   in Loop: Header=BB239_6 Depth=1
	ldr	x9, [x20, #1288]
	cmp	x9, #31
	b.hi	LBB239_2
; %bb.17:                               ; %bb13.i
                                        ;   in Loop: Header=BB239_6 Depth=1
	ldr	x10, [x20, #1280]
	cmp	x9, x10
	b.hs	LBB239_2
; %bb.18:                               ; %bb20.i
                                        ;   in Loop: Header=BB239_6 Depth=1
	ldr	x10, [x24, x9, lsl #3]
	cmp	x10, x8
	b.ne	LBB239_2
	b	LBB239_3
LBB239_19:                              ; %bb4
	cbz	x21, LBB239_21
; %bb.20:                               ; %slots.release.drop.6.i
	mov	x0, x19
	bl	_free
LBB239_21:                              ; %"wf_free_empty$instance$5d2b3ddf4f1338b1.exit"
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_new$instance$b7e941dde1ad180f ; -- Begin function wf_std.collections.slab.slab_new$instance$b7e941dde1ad180f
	.p2align	2
_wf_std.collections.slab.slab_new$instance$b7e941dde1ad180f: ; @"wf_std.collections.slab.slab_new$instance$b7e941dde1ad180f"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x1
	mov	x20, x0
	cbz	x1, LBB240_3
; %bb.1:                                ; %window.payload.allocate.v1.i.i
	lsl	x8, x19, #7
	sub	x0, x8, x19, lsl #4
	bl	_malloc
	cbnz	x0, LBB240_4
; %bb.2:                                ; %window.block.oom.v1.i.i
	bl	l_wf_resource_abort
LBB240_3:
Lloh386:
	adrp	x0, l_.wf.empty.slots.payload@PAGE
Lloh387:
	add	x0, x0, l_.wf.empty.slots.payload@PAGEOFF
LBB240_4:                               ; %"wf_box_slots_new$instance$6f7c24dd1572f258.exit"
	stp	xzr, x19, [x20]
	stp	x0, x19, [x20, #16]
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh386, Lloh387
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_find_index$instance$b7e941dde1ad180f ; -- Begin function wf_std.collections.slab.slab_find_index$instance$b7e941dde1ad180f
	.p2align	2
_wf_std.collections.slab.slab_find_index$instance$b7e941dde1ad180f: ; @"wf_std.collections.slab.slab_find_index$instance$b7e941dde1ad180f"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.hs	LBB241_3
; %bb.1:                                ; %bb2.i
	ldr	x10, [x1, #8]
	ldr	x9, [x0, #16]
	mov	w11, #112                       ; =0x70
	madd	x9, x8, x11, x9
	ldr	x11, [x9, #96]
	cmp	x11, x10
	b.ne	LBB241_3
; %bb.2:                                ; %bb5.i
	ldr	x9, [x9]
	cmp	x9, #0
	csel	x1, xzr, x8, eq
	cset	w0, eq
	mov	w2, #0                          ; =0x0
	ret
LBB241_3:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_edit$instance$a7a5f5ad004788a5 ; -- Begin function wf_std.collections.slab.slab_edit$instance$a7a5f5ad004788a5
	.p2align	2
_wf_std.collections.slab.slab_edit$instance$a7a5f5ad004788a5: ; @"wf_std.collections.slab.slab_edit$instance$a7a5f5ad004788a5"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.hs	LBB242_4
; %bb.1:                                ; %bb2.i
	ldr	x9, [x1, #8]
	ldr	x10, [x0, #16]
	mov	w11, #112                       ; =0x70
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #96]
	cmp	x10, x9
	b.ne	LBB242_4
; %bb.2:                                ; %bb5.i
	ldr	x9, [x8]
	cbz	x9, LBB242_4
; %bb.3:                                ; %bb8.i
	mov	w0, #0                          ; =0x0
	ldrb	w9, [x2]
	strb	w9, [x8, #80]
	b	LBB242_5
LBB242_4:
	mov	w0, #1                          ; =0x1
LBB242_5:                               ; %"wf_std.collections.slab.slab_edit$instance$a7a5f5ad004788a5.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_push_indexed$instance$d383295a38079908 ; -- Begin function wf_collections.priority_queue.priority_queue_push_indexed$instance$d383295a38079908
	.p2align	2
_wf_collections.priority_queue.priority_queue_push_indexed$instance$d383295a38079908: ; @"wf_collections.priority_queue.priority_queue_push_indexed$instance$d383295a38079908"
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #80
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 80
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	mov	x19, x0
	ldp	q0, q1, [x2]
	stp	q0, q1, [sp]
	ldr	x21, [x1]
	cmp	x21, #8
	b.lo	LBB243_2
; %bb.1:                                ; %bb2
	str	xzr, [x19]
	mov	w8, #1                          ; =0x1
	str	w8, [x19]
	ldp	q0, q1, [sp]
	stur	q0, [x19, #8]
	stur	q1, [x19, #24]
	b	LBB243_7
LBB243_2:                               ; %bb3
	mov	x20, x1
	mov	x0, x1
	mov	x22, x4
	bl	_wf_collections.priority_queue.priority_queue_make_room$instance$8d53fd32336043f5
	mov	x4, x22
	ldr	x8, [x20]
	ldr	x9, [x20, #16]
	add	x10, x9, x8, lsl #5
	ldp	q1, q0, [sp]
	stp	q1, q0, [x10]
	add	x8, x8, #1
	str	x8, [x20]
	add	x9, x9, x21, lsl #5
	ldr	x8, [x9, #16]
	ldr	x10, [x22]
	cmp	x8, x10
	b.hs	LBB243_6
; %bb.3:                                ; %bb2.i.i.i
	ldr	x9, [x9, #24]
	ldr	x10, [x4, #16]
	mov	w11, #112                       ; =0x70
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #96]
	cmp	x10, x9
	b.ne	LBB243_6
; %bb.4:                                ; %bb5.i.i.i
	ldr	x9, [x8]
	cbz	x9, LBB243_6
; %bb.5:                                ; %bb8.i.i.i
	str	x21, [x8, #88]
LBB243_6:                               ; %"wf_record_report_position$instance$f8195bc386aec277.exit"
	mov	x0, x20
	mov	x1, x21
	bl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$d383295a38079908
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x19]
	str	xzr, [x19, #32]
LBB243_7:                               ; %bb2
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #80
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_insert$instance$b7e941dde1ad180f ; -- Begin function wf_std.collections.slab.slab_insert$instance$b7e941dde1ad180f
	.p2align	2
_wf_std.collections.slab.slab_insert$instance$b7e941dde1ad180f: ; @"wf_std.collections.slab.slab_insert$instance$b7e941dde1ad180f"
; %bb.0:                                ; %entry
	sub	sp, sp, #16
	ldp	x13, x4, [x2]
	ldp	x3, x17, [x2, #16]
	ldp	x16, x14, [x2, #32]
	ldp	x12, x11, [x2, #48]
	ldr	x10, [x2, #64]
	ldrb	w9, [x2, #72]
	ldr	w15, [x2, #76]
	mov	x5, x2
	ldr	w6, [x5, #73]!
	ldr	x8, [x2, #80]
	str	w6, [sp, #8]
	stur	w15, [sp, #11]
	ldr	x15, [x1, #24]
	ldr	x2, [x1]
	cmp	x15, x2
	b.hs	LBB244_4
; %bb.1:                                ; %bb2
	ldr	x2, [x1, #16]
	mov	w5, #112                        ; =0x70
	madd	x5, x15, x5, x2
	ldr	x2, [x5]
	cbnz	x2, LBB244_6
; %bb.2:                                ; %bb5
	ldr	x2, [x5, #96]
	cmp	x2, #2
	b.hi	LBB244_6
; %bb.3:                                ; %bb8
	ldr	x6, [x5, #104]
	stp	x4, x3, [x5, #16]
	stp	x17, x16, [x5, #32]
	stp	x14, x12, [x5, #48]
	stp	x11, x10, [x5, #64]
	strb	w9, [x5, #80]
	ldr	w9, [sp, #8]
	stur	w9, [x5, #81]
	ldur	w9, [sp, #11]
	str	w9, [x5, #84]
	str	x8, [x5, #88]
	mov	w8, #1                          ; =0x1
	stp	x8, x13, [x5]
	str	x6, [x1, #24]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	stp	q0, q0, [x0, #32]
	stp	q0, q0, [x0, #64]
	stp	x15, x2, [x0, #8]
	add	sp, sp, #16
	ret
LBB244_4:                               ; %bb3
	ldr	x6, [x1, #8]
	cmp	x2, x6
	b.hs	LBB244_6
; %bb.5:                                ; %bb11
	ldr	w6, [x5]
	str	w6, [sp]
	ldur	w5, [x5, #3]
	stur	w5, [sp, #3]
	ldr	x5, [x1, #16]
	mov	w6, #112                        ; =0x70
	madd	x5, x2, x6, x5
	mov	w6, #1                          ; =0x1
	stp	x6, x13, [x5]
	stp	x4, x3, [x5, #16]
	stp	x17, x16, [x5, #32]
	stp	x14, x12, [x5, #48]
	stp	x11, x10, [x5, #64]
	strb	w9, [x5, #80]
	ldr	w9, [sp]
	stur	w9, [x5, #81]
	ldur	w9, [sp, #3]
	str	w9, [x5, #84]
	stp	x8, xzr, [x5, #88]
	str	x15, [x5, #104]
	add	x8, x2, #1
	str	x8, [x1]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	stp	q0, q0, [x0, #32]
	stp	q0, q0, [x0, #64]
	str	x2, [x0, #8]
	add	sp, sp, #16
	ret
LBB244_6:                               ; %bb4
	stp	xzr, x13, [x0]
	mov	w15, #1                         ; =0x1
	str	w15, [x0]
	stp	x4, x3, [x0, #16]
	stp	x17, x16, [x0, #32]
	stp	x14, x12, [x0, #48]
	stp	x11, x10, [x0, #64]
	strb	w9, [x0, #80]
	ldr	w9, [sp, #8]
	stur	w9, [x0, #81]
	ldur	w9, [sp, #11]
	str	w9, [x0, #84]
	str	x8, [x0, #88]
	add	sp, sp, #16
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$d383295a38079908 ; -- Begin function wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$d383295a38079908
	.p2align	2
_wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$d383295a38079908: ; @"wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$d383295a38079908"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	mov	x19, x0
	ldr	x8, [x1]
	sub	x8, x8, #1
	ldr	x10, [x1, #16]
	add	x11, x10, x8, lsl #5
	str	x8, [x1]
	ldp	q0, q1, [x11]
	stp	q0, q1, [sp]
	cmp	x2, x8
	b.hs	LBB245_10
; %bb.1:                                ; %bb2
	add	x9, x10, x2, lsl #5
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp]
	ldp	q0, q1, [x11]
	stp	q0, q1, [x9]
	ldr	x11, [x9, #16]
	ldr	x12, [x4]
	cmp	x11, x12
	b.hs	LBB245_5
; %bb.2:                                ; %bb2.i.i.i
	ldr	x12, [x9, #24]
	ldr	x13, [x4, #16]
	mov	w14, #112                       ; =0x70
	madd	x11, x11, x14, x13
	ldr	x13, [x11, #96]
	cmp	x13, x12
	b.ne	LBB245_5
; %bb.3:                                ; %bb5.i.i.i
	ldr	x12, [x11]
	cbz	x12, LBB245_5
; %bb.4:                                ; %bb8.i.i.i
	str	x2, [x11, #88]
LBB245_5:                               ; %"wf_record_report_position$instance$f8195bc386aec277.exit"
	cbz	x2, LBB245_7
; %bb.6:                                ; %bb2.i
	lsl	x11, x2, #4
	sub	x11, x11, #16
	and	x11, x11, #0xffffffffffffffe0
	add	x10, x10, x11
	ldr	x11, [x10]
	ldr	x12, [x9]
	cmp	x11, x12
	b.hs	LBB245_8
LBB245_7:                               ; %bb1.i
	mov	x0, x1
	mov	x1, x2
	mov	x2, x8
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$d383295a38079908
	b	LBB245_10
LBB245_8:                               ; %bb3.i.i
	b.ls	LBB245_11
LBB245_9:                               ; %bb5.i
	mov	x0, x1
	mov	x1, x2
	bl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$d383295a38079908
LBB245_10:                              ; %bb1
	ldp	q0, q1, [sp]
	stp	q0, q1, [x19]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB245_11:                              ; %bb6.i.i
	ldr	x11, [x10, #8]
	ldr	x12, [x9, #8]
	cmp	x11, x12
	b.lo	LBB245_7
; %bb.12:                               ; %bb9.i.i
	b.hi	LBB245_9
; %bb.13:                               ; %bb12.i.i
	ldr	x11, [x10, #16]
	ldr	x12, [x9, #16]
	cmp	x11, x12
	b.lo	LBB245_7
; %bb.14:                               ; %bb15.i.i
	b.hi	LBB245_9
; %bb.15:                               ; %bb18.i.i
	ldr	x10, [x10, #24]
	ldr	x9, [x9, #24]
	cmp	x10, x9
	b.ls	LBB245_7
	b	LBB245_9
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_replace_at_indexed$instance$d383295a38079908 ; -- Begin function wf_collections.priority_queue.priority_queue_replace_at_indexed$instance$d383295a38079908
	.p2align	2
_wf_collections.priority_queue.priority_queue_replace_at_indexed$instance$d383295a38079908: ; @"wf_collections.priority_queue.priority_queue_replace_at_indexed$instance$d383295a38079908"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	mov	x4, x5
	mov	x8, x2
	mov	x19, x0
	ldr	x2, [x1]
	ldr	x10, [x1, #16]
	add	x9, x10, x8, lsl #5
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp]
	ldp	q0, q1, [x3]
	stp	q0, q1, [x9]
	ldr	x11, [x9, #16]
	ldr	x12, [x5]
	cmp	x11, x12
	b.hs	LBB246_4
; %bb.1:                                ; %bb2.i.i.i
	ldr	x12, [x9, #24]
	ldr	x13, [x4, #16]
	mov	w14, #112                       ; =0x70
	madd	x11, x11, x14, x13
	ldr	x13, [x11, #96]
	cmp	x13, x12
	b.ne	LBB246_4
; %bb.2:                                ; %bb5.i.i.i
	ldr	x12, [x11]
	cbz	x12, LBB246_4
; %bb.3:                                ; %bb8.i.i.i
	str	x8, [x11, #88]
LBB246_4:                               ; %"wf_record_report_position$instance$f8195bc386aec277.exit"
	cbz	x8, LBB246_6
; %bb.5:                                ; %bb2.i
	lsl	x11, x8, #4
	sub	x11, x11, #16
	and	x11, x11, #0xffffffffffffffe0
	add	x10, x10, x11
	ldr	x11, [x10]
	ldr	x12, [x9]
	cmp	x11, x12
	b.hs	LBB246_7
LBB246_6:                               ; %bb1.i
	mov	x0, x1
	mov	x1, x8
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$d383295a38079908
	b	LBB246_9
LBB246_7:                               ; %bb3.i.i
	b.ls	LBB246_10
LBB246_8:                               ; %bb5.i
	mov	x0, x1
	mov	x1, x8
	bl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$d383295a38079908
LBB246_9:                               ; %"wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$d383295a38079908.exit"
	ldp	q0, q1, [sp]
	stp	q0, q1, [x19]
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB246_10:                              ; %bb6.i.i
	ldr	x11, [x10, #8]
	ldr	x12, [x9, #8]
	cmp	x11, x12
	b.lo	LBB246_6
; %bb.11:                               ; %bb9.i.i
	b.hi	LBB246_8
; %bb.12:                               ; %bb12.i.i
	ldr	x11, [x10, #16]
	ldr	x12, [x9, #16]
	cmp	x11, x12
	b.lo	LBB246_6
; %bb.13:                               ; %bb15.i.i
	b.hi	LBB246_8
; %bb.14:                               ; %bb18.i.i
	ldr	x10, [x10, #24]
	ldr	x9, [x9, #24]
	cmp	x10, x9
	b.ls	LBB246_6
	b	LBB246_8
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_remove$instance$b7e941dde1ad180f ; -- Begin function wf_std.collections.slab.slab_remove$instance$b7e941dde1ad180f
	.p2align	2
_wf_std.collections.slab.slab_remove$instance$b7e941dde1ad180f: ; @"wf_std.collections.slab.slab_remove$instance$b7e941dde1ad180f"
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	ldr	x9, [x1]
	cmp	x8, x9
	b.hs	LBB247_6
; %bb.1:                                ; %bb2
	ldr	x10, [x2, #8]
	ldr	x9, [x1, #16]
	mov	w11, #112                       ; =0x70
	madd	x11, x8, x11, x9
	ldr	x12, [x11, #96]
	cmp	x12, x10
	b.ne	LBB247_6
; %bb.2:                                ; %bb5
	ldr	x12, [x11]
	cbz	x12, LBB247_6
; %bb.3:                                ; %bb8
	sub	sp, sp, #96
	sub	x13, x12, #1
	str	x13, [x11]
	mov	w13, #88                        ; =0x58
	madd	x11, x12, x13, x11
	ldp	q0, q1, [x11, #-48]
	stp	q0, q1, [sp, #32]
	ldur	q0, [x11, #-16]
	str	q0, [sp, #64]
	ldr	x12, [x11]
	str	x12, [sp, #80]
	ldp	q0, q1, [x11, #-80]
	stp	q0, q1, [sp]
	cmp	x10, #2
	b.hs	LBB247_5
; %bb.4:                                ; %bb11
	add	x10, x10, #1
	mov	w11, #112                       ; =0x70
	ldr	x12, [x1, #24]
	madd	x9, x8, x11, x9
	stp	x10, x12, [x9, #96]
	str	x8, [x1, #24]
LBB247_5:                               ; %bb10
	ldp	q0, q1, [sp, #32]
	stur	q0, [x0, #40]
	stur	q1, [x0, #56]
	ldr	q0, [sp, #64]
	stur	q0, [x0, #72]
	ldp	q0, q1, [sp]
	stur	q0, [x0, #8]
	str	xzr, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	ldr	x8, [sp, #80]
	str	x8, [x0, #88]
	stur	q1, [x0, #24]
	add	sp, sp, #96
	ret
LBB247_6:                               ; %bb1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0, #64]
	stp	q0, q0, [x0, #32]
	stp	q0, q0, [x0]
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_indexed_read$instance$21d963e604dff184
lCPI248_0:
	.quad	22                              ; 0x16
	.quad	33                              ; 0x21
lCPI248_1:
	.quad	44                              ; 0x2c
	.quad	55                              ; 0x37
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_indexed_read$instance$21d963e604dff184
	.p2align	2
_wf_indexed_read$instance$21d963e604dff184: ; @"wf_indexed_read$instance$21d963e604dff184"
; %bb.0:                                ; %entry
	ldp	x8, x9, [x1, #8]
	ldp	x10, x8, [x8]
	add	x11, x10, #101
	cmp	x8, x11
	csinv	x8, x10, xzr, eq
	add	x10, x8, #11
	cmp	x9, x10
	b.ne	LBB248_5
; %bb.1:                                ; %bb3.i
	dup.2d	v0, x8
Lloh388:
	adrp	x9, lCPI248_0@PAGE
Lloh389:
	ldr	q1, [x9, lCPI248_0@PAGEOFF]
	add.2d	v1, v0, v1
Lloh390:
	adrp	x9, lCPI248_1@PAGE
Lloh391:
	ldr	q2, [x9, lCPI248_1@PAGEOFF]
	add.2d	v0, v0, v2
	ldur	q2, [x1, #24]
	ldur	q3, [x1, #40]
	cmeq.2d	v0, v3, v0
	cmeq.2d	v1, v2, v1
	uzp1.4s	v0, v1, v0
	xtn.4h	v0, v0
	uminv.4h	h0, v0
	fmov	w9, s0
	mov	x0, #-1                         ; =0xffffffffffffffff
	tbz	w9, #0, LBB248_4
; %bb.2:                                ; %bb3.i
	add	x9, x8, #66
	ldr	x10, [x1, #56]
	cmp	x10, x9
	b.ne	LBB248_4
; %bb.3:                                ; %bb18.i
	add	x9, x8, #77
	ldr	x10, [x1, #64]
	cmp	x10, x9
	csinv	x0, x8, xzr, eq
LBB248_4:                               ; %wf_indexed_wide_read.exit
	ret
LBB248_5:
	mov	x0, #-1                         ; =0xffffffffffffffff
	ret
	.loh AdrpLdr	Lloh390, Lloh391
	.loh AdrpAdrp	Lloh388, Lloh390
	.loh AdrpLdr	Lloh388, Lloh389
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function wf_std.collections.slab.slab_visit$instance$ed57a410aad1618e
lCPI249_0:
	.quad	22                              ; 0x16
	.quad	33                              ; 0x21
lCPI249_1:
	.quad	44                              ; 0x2c
	.quad	55                              ; 0x37
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_wf_std.collections.slab.slab_visit$instance$ed57a410aad1618e
	.p2align	2
_wf_std.collections.slab.slab_visit$instance$ed57a410aad1618e: ; @"wf_std.collections.slab.slab_visit$instance$ed57a410aad1618e"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.hs	LBB249_7
; %bb.1:                                ; %bb2.i
	ldr	x9, [x1, #8]
	ldr	x10, [x0, #16]
	mov	w11, #112                       ; =0x70
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #96]
	cmp	x10, x9
	b.ne	LBB249_7
; %bb.2:                                ; %bb5.i
	ldr	x9, [x8]
	cbz	x9, LBB249_7
; %bb.3:                                ; %bb8.i
	ldp	x9, x10, [x8, #16]
	ldp	x11, x9, [x9]
	add	x12, x11, #101
	cmp	x9, x12
	csinv	x9, x11, xzr, eq
	add	x11, x9, #11
	cmp	x10, x11
	b.ne	LBB249_9
; %bb.4:                                ; %bb3.i.i.i
	mov	w0, #0                          ; =0x0
	dup.2d	v0, x9
Lloh392:
	adrp	x10, lCPI249_0@PAGE
Lloh393:
	ldr	q1, [x10, lCPI249_0@PAGEOFF]
	add.2d	v1, v0, v1
Lloh394:
	adrp	x10, lCPI249_1@PAGE
Lloh395:
	ldr	q2, [x10, lCPI249_1@PAGEOFF]
	add.2d	v0, v0, v2
	ldp	q2, q3, [x8, #32]
	cmeq.2d	v0, v3, v0
	cmeq.2d	v1, v2, v1
	uzp1.4s	v0, v1, v0
	xtn.4h	v0, v0
	uminv.4h	h0, v0
	fmov	w10, s0
	mov	x1, #-1                         ; =0xffffffffffffffff
	tbz	w10, #0, LBB249_8
; %bb.5:                                ; %bb3.i.i.i
	add	x10, x9, #66
	ldr	x11, [x8, #64]
	cmp	x11, x10
	b.ne	LBB249_8
; %bb.6:                                ; %bb18.i.i.i
	mov	w0, #0                          ; =0x0
	add	x10, x9, #77
	ldr	x8, [x8, #72]
	cmp	x8, x10
	csinv	x1, x9, xzr, eq
	mov	w2, #0                          ; =0x0
	ret
LBB249_7:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
LBB249_8:                               ; %"wf_std.collections.slab.slab_visit$instance$ed57a410aad1618e.body.exit"
	mov	w2, #0                          ; =0x0
	ret
LBB249_9:
	mov	w0, #0                          ; =0x0
	mov	x1, #-1                         ; =0xffffffffffffffff
	mov	w2, #0                          ; =0x0
	ret
	.loh AdrpLdr	Lloh394, Lloh395
	.loh AdrpAdrp	Lloh392, Lloh394
	.loh AdrpLdr	Lloh392, Lloh393
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_edit$instance$968c1d6754370774 ; -- Begin function wf_std.collections.slab.slab_edit$instance$968c1d6754370774
	.p2align	2
_wf_std.collections.slab.slab_edit$instance$968c1d6754370774: ; @"wf_std.collections.slab.slab_edit$instance$968c1d6754370774"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.hs	LBB250_4
; %bb.1:                                ; %bb2.i
	sub	sp, sp, #64
	ldr	x9, [x1, #8]
	ldr	x10, [x0, #16]
	mov	w11, #112                       ; =0x70
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #96]
	cmp	x10, x9
	b.ne	LBB250_5
; %bb.2:                                ; %bb5.i
	ldr	x9, [x8]
	cbz	x9, LBB250_5
; %bb.3:                                ; %bb8.i
	mov	w0, #0                          ; =0x0
	ldp	q1, q0, [x2, #32]
	ldp	q3, q2, [x2]
	ldp	q4, q5, [x8, #16]
	stp	q4, q5, [x2]
	ldp	q4, q5, [x8, #48]
	stp	q4, q5, [x2, #32]
	stp	q3, q2, [x8, #16]
	stp	q1, q0, [x8, #48]
	b	LBB250_6
LBB250_4:
	mov	w0, #1                          ; =0x1
	b	LBB250_7
LBB250_5:
	mov	w0, #1                          ; =0x1
LBB250_6:                               ; %"wf_std.collections.slab.slab_edit$instance$968c1d6754370774.body.exit"
	add	sp, sp, #64
LBB250_7:                               ; %"wf_std.collections.slab.slab_edit$instance$968c1d6754370774.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_visit$instance$fa687743152d433f ; -- Begin function wf_std.collections.slab.slab_visit$instance$fa687743152d433f
	.p2align	2
_wf_std.collections.slab.slab_visit$instance$fa687743152d433f: ; @"wf_std.collections.slab.slab_visit$instance$fa687743152d433f"
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	ldr	x9, [x1]
	cmp	x8, x9
	b.hs	LBB251_4
; %bb.1:                                ; %bb2
	ldr	x9, [x2, #8]
	ldr	x10, [x1, #16]
	mov	w11, #112                       ; =0x70
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #96]
	cmp	x10, x9
	b.ne	LBB251_4
; %bb.2:                                ; %bb5
	ldr	x9, [x8]
	cbz	x9, LBB251_4
; %bb.3:                                ; %bb8
	sub	sp, sp, #16
	ldr	x9, [x8, #8]
	ldrb	w10, [x8, #80]
	ldr	x8, [x8, #88]
	and	w10, w10, #0x1
	strb	w10, [sp, #8]
	stp	x9, xzr, [x0, #8]
	str	xzr, [x0]
	strb	w10, [x0, #16]
	str	x8, [x0, #24]
	add	sp, sp, #16
	ret
LBB251_4:                               ; %bb1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	ret
                                        ; -- End function
	.globl	_wf_record_set_position$instance$e1380248266a9ad2 ; -- Begin function wf_record_set_position$instance$e1380248266a9ad2
	.p2align	2
_wf_record_set_position$instance$e1380248266a9ad2: ; @"wf_record_set_position$instance$e1380248266a9ad2"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	str	x8, [x1, #80]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_record_store_expire$instance$dbfa3e54f7dd514a ; -- Begin function wf_record_store_expire$instance$dbfa3e54f7dd514a
	.p2align	2
_wf_record_store_expire$instance$dbfa3e54f7dd514a: ; @"wf_record_store_expire$instance$dbfa3e54f7dd514a"
; %bb.0:                                ; %entry
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #560
	str	x2, [sp, #8]                    ; 8-byte Folded Spill
	mov	x23, x0
	ldr	x8, [x23, #88]!
	cbz	x8, LBB253_28
; %bb.1:                                ; %bb5.lr.ph
	mov	x21, x1
	mov	x22, x0
	mov	x19, #0                         ; =0x0
	add	x25, sp, #16
	add	x24, x25, #344
	mov	w26, #8                         ; =0x8
	mov	w27, #112                       ; =0x70
	mov	w28, #1                         ; =0x1
LBB253_2:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	ldr	x9, [x22, #104]
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp, #16]
	ldr	x10, [sp, #16]
	cmp	x10, x21
	b.hi	LBB253_29
; %bb.3:                                ; %bb8
                                        ;   in Loop: Header=BB253_2 Depth=1
	ldur	x20, [x22, #16]
	subs	x2, x8, #1
	add	x8, x9, x2, lsl #5
	str	x2, [x23]
	ldp	q0, q1, [x8]
	stp	q0, q1, [sp, #464]
	b.eq	LBB253_9
; %bb.4:                                ; %bb2.i
                                        ;   in Loop: Header=BB253_2 Depth=1
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp, #464]
	ldp	q0, q1, [x8]
	stp	q0, q1, [x9]
	ldr	x8, [x9, #16]
	cmp	x8, x20
	b.hs	LBB253_8
; %bb.5:                                ; %bb2.i.i.i.i
                                        ;   in Loop: Header=BB253_2 Depth=1
	ldr	x9, [x9, #24]
	ldr	x10, [x22, #32]
	madd	x8, x8, x27, x10
	ldr	x10, [x8, #96]
	cmp	x10, x9
	b.ne	LBB253_8
; %bb.6:                                ; %bb5.i.i.i.i
                                        ;   in Loop: Header=BB253_2 Depth=1
	ldr	x9, [x8]
	cbz	x9, LBB253_8
; %bb.7:                                ; %bb8.i.i.i.i
                                        ;   in Loop: Header=BB253_2 Depth=1
	str	xzr, [x8, #88]
LBB253_8:                               ; %"wf_record_report_position$instance$f8195bc386aec277.exit.i"
                                        ;   in Loop: Header=BB253_2 Depth=1
	add	x4, x22, #16
	mov	x0, x23
	mov	x1, #0                          ; =0x0
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$d383295a38079908
LBB253_9:                               ; %"wf_collections.priority_queue.priority_queue_remove_at_indexed$instance$d383295a38079908.exit"
                                        ;   in Loop: Header=BB253_2 Depth=1
	ldp	q0, q1, [sp, #464]
	stp	q0, q1, [x25, #32]
	str	x26, [sp, #448]
	ldur	q0, [x25, #48]
	stur	q0, [x25, #64]
	ldr	x8, [sp, #80]
	cmp	x8, x20
	b.hs	LBB253_13
; %bb.10:                               ; %bb2.i.i
                                        ;   in Loop: Header=BB253_2 Depth=1
	ldr	x10, [sp, #88]
	ldr	x9, [x22, #32]
	madd	x9, x8, x27, x9
	ldr	x8, [x9, #96]
	cmp	x8, x10
	b.ne	LBB253_13
; %bb.11:                               ; %bb5.i.i
                                        ;   in Loop: Header=BB253_2 Depth=1
	ldr	x8, [x9]
	cbz	x8, LBB253_13
; %bb.12:                               ; %bb8.i.i
                                        ;   in Loop: Header=BB253_2 Depth=1
	mov	w8, #0                          ; =0x0
	str	x26, [x9, #88]
	b	LBB253_14
LBB253_13:                              ;   in Loop: Header=BB253_2 Depth=1
	mov	w8, #1                          ; =0x1
LBB253_14:                              ; %"wf_std.collections.slab.slab_edit$instance$6a5da7aad053cce4.exit"
                                        ;   in Loop: Header=BB253_2 Depth=1
	ldp	q0, q1, [x22, #64]
	stur	q0, [x25, #152]
	stur	q1, [x25, #168]
	ldr	q0, [x22, #96]
	stur	q0, [x25, #184]
	ldp	q0, q1, [x22]
	stur	q0, [x25, #88]
	stur	q1, [x25, #104]
	ldp	q0, q1, [x22, #32]
	stur	q0, [x25, #120]
	str	w8, [sp, #96]
	strh	wzr, [sp, #100]
	ldr	x8, [x22, #112]
	stur	x8, [x25, #200]
	stur	q1, [x25, #136]
	ldur	q0, [x25, #48]
	stur	q0, [x25, #208]
	ldr	x20, [sp, #104]
	ldr	x1, [sp, #56]
	str	x20, [sp, #240]
	ldur	q0, [x25, #48]
	stur	q0, [x25, #232]
	add	x2, x25, #224
	mov	x0, x22
	bl	_wf_record_store_detach$instance$f8195bc386aec277
	ldr	x8, [x22]
	cmp	x20, x8
	b.ne	LBB253_21
; %bb.15:                               ; %bb3.i.i
                                        ;   in Loop: Header=BB253_2 Depth=1
	ldr	x8, [sp, #248]
	ldur	x9, [x22, #16]
	cmp	x8, x9
	b.hs	LBB253_22
; %bb.16:                               ; %bb2.i.i.i
                                        ;   in Loop: Header=BB253_2 Depth=1
	ldr	x10, [sp, #256]
	ldr	x9, [x22, #32]
	madd	x11, x8, x27, x9
	ldr	x12, [x11, #96]
	cmp	x12, x10
	b.ne	LBB253_22
; %bb.17:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB253_2 Depth=1
	ldr	x12, [x11]
	cbz	x12, LBB253_22
; %bb.18:                               ; %bb2.i7
                                        ;   in Loop: Header=BB253_2 Depth=1
	ldrb	w13, [x11, #80]
	ldr	x14, [x11, #88]
	and	w13, w13, #0x1
	strb	w13, [sp, #456]
	ldrb	w15, [x22, #8]
	cmp	x14, #8
	csinc	w13, w13, wzr, eq
	tbz	w15, #0, LBB253_25
; %bb.19:                               ; %bb2.i7
                                        ;   in Loop: Header=BB253_2 Depth=1
	tbz	w13, #0, LBB253_25
; %bb.20:                               ;   in Loop: Header=BB253_2 Depth=1
	mov	w8, #9                          ; =0x9
	b	LBB253_23
LBB253_21:                              ;   in Loop: Header=BB253_2 Depth=1
	mov	w8, #4                          ; =0x4
	b	LBB253_23
LBB253_22:                              ; %bb5.i.i6
                                        ;   in Loop: Header=BB253_2 Depth=1
	mov	w8, #3                          ; =0x3
LBB253_23:                              ; %"wf_record_store_delete$instance$f8195bc386aec277.exit.thread"
                                        ;   in Loop: Header=BB253_2 Depth=1
	str	xzr, [x25, #336]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x25, #304]
	stp	q0, q0, [x25, #272]
	str	q0, [x25, #256]
	str	w28, [sp, #264]
	str	w8, [sp, #268]
LBB253_24:                              ; %bb9
                                        ;   in Loop: Header=BB253_2 Depth=1
	ldr	x8, [x23]
	cbnz	x8, LBB253_2
	b	LBB253_29
LBB253_25:                              ; %bb8.i.i8
                                        ;   in Loop: Header=BB253_2 Depth=1
	sub	x13, x12, #1
	str	x13, [x11]
	mov	w13, #88                        ; =0x58
	madd	x11, x12, x13, x11
	ldp	q0, q1, [x11, #-48]
	stp	q0, q1, [sp, #496]
	ldur	q0, [x11, #-16]
	str	q0, [sp, #528]
	ldr	x12, [x11]
	str	x12, [sp, #544]
	ldp	q0, q1, [x11, #-80]
	stp	q0, q1, [sp, #464]
	cmp	x10, #1
	b.hi	LBB253_27
; %bb.26:                               ; %bb11.i.i
                                        ;   in Loop: Header=BB253_2 Depth=1
	add	x10, x10, #1
	ldr	x11, [x22, #40]
	madd	x9, x8, x27, x9
	stp	x10, x11, [x9, #96]
	str	x8, [x22, #40]
LBB253_27:                              ; %bb10
                                        ;   in Loop: Header=BB253_2 Depth=1
	str	xzr, [sp, #264]
	ldp	q0, q1, [sp, #496]
	stp	q0, q1, [x25, #288]
	ldr	q0, [sp, #528]
	str	q0, [x25, #320]
	ldr	x8, [sp, #544]
	str	x8, [x25, #336]
	ldp	q0, q1, [sp, #464]
	stp	q0, q1, [x25, #256]
	ldp	q0, q1, [x25, #288]
	stp	q0, q1, [x24, #32]
	ldr	q0, [x25, #320]
	str	q0, [x24, #64]
	str	x8, [x24, #80]
	ldp	q0, q1, [x25, #256]
	stp	q0, q1, [x24]
	ldr	x0, [sp, #8]                    ; 8-byte Folded Reload
	mov	x1, x24
	bl	_wf_indexed_release$instance$68c9432c50ad41ad
	add	x19, x19, #1
	b	LBB253_24
LBB253_28:
	mov	x19, #0                         ; =0x0
LBB253_29:                              ; %bb2
	mov	x0, x19
	add	sp, sp, #560
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_free$instance$35920b2025f188fb ; -- Begin function wf_std.collections.slab.slab_free$instance$35920b2025f188fb
	.p2align	2
_wf_std.collections.slab.slab_free$instance$35920b2025f188fb: ; @"wf_std.collections.slab.slab_free$instance$35920b2025f188fb"
; %bb.0:                                ; %entry
	sub	sp, sp, #176
	stp	x26, x25, [sp, #96]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #112]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #160]            ; 16-byte Folded Spill
	ldp	x22, x21, [x0]
	ldr	x19, [x0, #16]
	cbz	x22, LBB254_5
; %bb.1:                                ; %bb5.preheader
	mov	x20, x1
	mov	w8, #112                        ; =0x70
	madd	x8, x22, x8, x19
	sub	x23, x8, #112
	mov	w24, #88                        ; =0x58
	mov	x25, sp
	b	LBB254_3
LBB254_2:                               ; %bb6
                                        ;   in Loop: Header=BB254_3 Depth=1
	sub	x23, x23, #112
	sub	x22, x22, #1
	cbz	x22, LBB254_5
LBB254_3:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q0, q1, [x23, #32]
	stp	q0, q1, [sp, #32]
	ldp	q0, q1, [x23, #64]
	stp	q0, q1, [sp, #64]
	ldp	q0, q1, [x23]
	stp	q0, q1, [sp]
	ldr	x8, [sp]
	cbz	x8, LBB254_2
; %bb.4:                                ; %bb7
                                        ;   in Loop: Header=BB254_3 Depth=1
	sub	x9, x8, #1
	madd	x8, x8, x24, x25
	sub	x1, x8, #80
	str	x9, [sp]
	mov	x0, x20
	bl	_wf_indexed_release$instance$68c9432c50ad41ad
	b	LBB254_2
LBB254_5:                               ; %bb4
	cbz	x21, LBB254_7
; %bb.6:                                ; %slots.release.drop.6.i
	mov	x0, x19
	bl	_free
LBB254_7:                               ; %"wf_free_empty$instance$2b0e6782a5453966.exit"
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #160]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #144]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #96]             ; 16-byte Folded Reload
	add	sp, sp, #176
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$6843c1d81191f67a ; -- Begin function wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$6843c1d81191f67a
	.p2align	2
_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$6843c1d81191f67a: ; @"wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$6843c1d81191f67a"
; %bb.0:                                ; %entry
	lsr	x8, x2, #1
	cmp	x1, x8
	b.hs	LBB255_21
; %bb.1:                                ; %bb5.lr.ph
	sub	sp, sp, #32
	ldr	x9, [x0]
	ldr	x10, [x0, #16]
	b	LBB255_3
LBB255_2:                               ; %bb8
                                        ;   in Loop: Header=BB255_3 Depth=1
	ldp	q1, q0, [x12]
	ldp	q3, q2, [x11]
	stp	q3, q2, [x12]
	stp	q1, q0, [x11]
	cmp	x1, x8
	b.hs	LBB255_20
LBB255_3:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	mov	x11, x1
	lsl	x13, x1, #1
	mov	w12, #1                         ; =0x1
	bfi	x12, x1, #1, #63
	add	x13, x13, #2
	cmp	x13, x9
	b.hs	LBB255_7
; %bb.4:                                ; %bb2.i
                                        ;   in Loop: Header=BB255_3 Depth=1
	add	x14, x10, x13, lsl #5
	add	x15, x10, x12, lsl #5
	ldr	x16, [x14]
	ldr	x17, [x15]
	cmp	x16, x17
	b.hs	LBB255_6
LBB255_5:                               ;   in Loop: Header=BB255_3 Depth=1
	mov	x1, x13
	b	LBB255_8
LBB255_6:                               ; %bb3.i.i
                                        ;   in Loop: Header=BB255_3 Depth=1
	b.ls	LBB255_15
LBB255_7:                               ;   in Loop: Header=BB255_3 Depth=1
	mov	x1, x12
LBB255_8:                               ; %"wf_collections.priority_queue.priority_queue_child$instance$97f85d10896f0873.exit"
                                        ;   in Loop: Header=BB255_3 Depth=1
	add	x12, x10, x11, lsl #5
	add	x11, x10, x1, lsl #5
	ldr	x13, [x12]
	ldr	x14, [x11]
	cmp	x13, x14
	b.lo	LBB255_20
; %bb.9:                                ; %bb3.i
                                        ;   in Loop: Header=BB255_3 Depth=1
	b.hi	LBB255_2
; %bb.10:                               ; %bb6.i
                                        ;   in Loop: Header=BB255_3 Depth=1
	ldr	x13, [x12, #8]
	ldr	x14, [x11, #8]
	cmp	x13, x14
	b.lo	LBB255_20
; %bb.11:                               ; %bb9.i
                                        ;   in Loop: Header=BB255_3 Depth=1
	b.hi	LBB255_2
; %bb.12:                               ; %bb12.i
                                        ;   in Loop: Header=BB255_3 Depth=1
	ldr	x13, [x12, #16]
	ldr	x14, [x11, #16]
	cmp	x13, x14
	b.lo	LBB255_20
; %bb.13:                               ; %bb15.i
                                        ;   in Loop: Header=BB255_3 Depth=1
	b.hi	LBB255_2
; %bb.14:                               ; %bb18.i
                                        ;   in Loop: Header=BB255_3 Depth=1
	ldr	x13, [x12, #24]
	ldr	x14, [x11, #24]
	cmp	x13, x14
	b.hi	LBB255_2
	b	LBB255_20
LBB255_15:                              ; %bb6.i.i
                                        ;   in Loop: Header=BB255_3 Depth=1
	ldr	x16, [x14, #8]
	ldr	x17, [x15, #8]
	cmp	x16, x17
	b.lo	LBB255_5
; %bb.16:                               ; %bb9.i.i
                                        ;   in Loop: Header=BB255_3 Depth=1
	b.hi	LBB255_7
; %bb.17:                               ; %bb12.i.i
                                        ;   in Loop: Header=BB255_3 Depth=1
	ldr	x16, [x14, #16]
	ldr	x17, [x15, #16]
	mov	x1, x13
	cmp	x16, x17
	b.lo	LBB255_8
; %bb.18:                               ; %bb15.i.i
                                        ;   in Loop: Header=BB255_3 Depth=1
	mov	x1, x12
	b.hi	LBB255_8
; %bb.19:                               ; %bb18.i.i
                                        ;   in Loop: Header=BB255_3 Depth=1
	ldr	x14, [x14, #24]
	ldr	x15, [x15, #24]
	cmp	x14, x15
	csel	x1, x13, x12, lo
	b	LBB255_8
LBB255_20:
	add	sp, sp, #32
LBB255_21:                              ; %common.ret
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_migrate_owner$instance$603c8258fd999e20 ; -- Begin function wf_std.collections.hash_map.hash_map_migrate_owner$instance$603c8258fd999e20
	.p2align	2
_wf_std.collections.hash_map.hash_map_migrate_owner$instance$603c8258fd999e20: ; @"wf_std.collections.hash_map.hash_map_migrate_owner$instance$603c8258fd999e20"
; %bb.0:                                ; %entry
	ldr	q0, [x2]
	ldr	x8, [x3]
	ldr	x9, [x0]
	ldr	x10, [x0, #16]
	udiv	x11, x1, x8
	msub	x11, x11, x8, x1
LBB256_1:                               ; %bb1
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB256_5 Depth 2
	cbz	x8, LBB256_3
; %bb.2:                                ; %bb3.i
                                        ;   in Loop: Header=BB256_1 Depth=1
	mov	x13, x11
	cbnz	x9, LBB256_4
	b	LBB256_1
LBB256_3:                               ;   in Loop: Header=BB256_1 Depth=1
	mov	x13, #0                         ; =0x0
	cbz	x9, LBB256_1
LBB256_4:                               ; %bb3.lr.ph
                                        ;   in Loop: Header=BB256_1 Depth=1
	mov	x12, #0                         ; =0x0
	udiv	x14, x13, x9
	msub	x13, x14, x9, x13
	sub	x14, x9, x13
	neg	x15, x14
LBB256_5:                               ; %bb3
                                        ;   Parent Loop BB256_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x12, x14
	csel	x16, x13, x15, lo
	add	x16, x16, x12
	lsl	x17, x16, #5
	ldr	w17, [x10, x17]
	cmp	w17, #1
	b.ls	LBB256_7
; %bb.6:                                ; %bb2
                                        ;   in Loop: Header=BB256_5 Depth=2
	add	x12, x12, #1
	cmp	x9, x12
	b.ne	LBB256_5
	b	LBB256_1
LBB256_7:                               ; %common.ret
	add	x8, x10, x16, lsl #5
	mov	w9, #2                          ; =0x2
	str	w9, [x8]
	str	x1, [x8, #8]
	str	q0, [x8, #16]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_action$instance$925b6cce71945287 ; -- Begin function wf_std.collections.hash_map.hash_map_action$instance$925b6cce71945287
	.p2align	2
_wf_std.collections.hash_map.hash_map_action$instance$925b6cce71945287: ; @"wf_std.collections.hash_map.hash_map_action$instance$925b6cce71945287"
; %bb.0:                                ; %entry
	mov	x8, x0
	ldr	w0, [x0]
	cmp	w0, #1
	b.ls	LBB257_2
; %bb.1:                                ; %bb3
	ldr	x8, [x8, #8]
	ldr	x9, [x1]
	cmp	x8, x9
	mov	w8, #2                          ; =0x2
	cinc	w0, w8, eq
LBB257_2:                               ; %common.ret
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_exchange$instance$44a98dc5bf86badc ; -- Begin function wf_std.collections.hash_map.hash_map_exchange$instance$44a98dc5bf86badc
	.p2align	2
_wf_std.collections.hash_map.hash_map_exchange$instance$44a98dc5bf86badc: ; @"wf_std.collections.hash_map.hash_map_exchange$instance$44a98dc5bf86badc"
; %bb.0:                                ; %entry
	ldr	x8, [x1, #16]
	add	x10, x8, x2, lsl #5
	ldr	w9, [x10]
	ldur	q0, [x10, #8]
	ldr	x8, [x10, #24]
	ldr	q1, [x4]
	mov	w11, #2                         ; =0x2
	str	w11, [x10]
	str	x3, [x10, #8]
	str	q1, [x10, #16]
	cbz	w9, LBB258_2
; %bb.1:                                ; %entry
	cmp	w9, #1
	b.ne	LBB258_3
LBB258_2:                               ; %bb2
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	ret
LBB258_3:                               ; %bb3
	str	xzr, [x0]
	mov	w9, #1                          ; =0x1
	str	w9, [x0]
	stur	q0, [x0, #8]
	str	x8, [x0, #24]
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_is_deleted$instance$44a98dc5bf86badc ; -- Begin function wf_std.collections.hash_map.hash_map_is_deleted$instance$44a98dc5bf86badc
	.p2align	2
_wf_std.collections.hash_map.hash_map_is_deleted$instance$44a98dc5bf86badc: ; @"wf_std.collections.hash_map.hash_map_is_deleted$instance$44a98dc5bf86badc"
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cmp	w8, #1
	cset	w0, eq
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_reserve$instance$a762b7cb0800ff6e ; -- Begin function wf_collections.priority_queue.priority_queue_reserve$instance$a762b7cb0800ff6e
	.p2align	2
_wf_collections.priority_queue.priority_queue_reserve$instance$a762b7cb0800ff6e: ; @"wf_collections.priority_queue.priority_queue_reserve$instance$a762b7cb0800ff6e"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	ldr	x22, [x0, #8]
	cmp	x22, x1
	b.hs	LBB260_5
; %bb.1:                                ; %bb3
	mov	x19, x1
	mov	x20, x0
	ldr	x23, [x0]
	ldr	x21, [x0, #16]
	lsl	x1, x1, #5
	cmp	x22, #0
	ccmp	x23, x22, #0, ne
	b.eq	LBB260_6
; %bb.2:                                ; %window.grow.copy.v2.i
	mov	x0, x1
	bl	_malloc
	cbz	x0, LBB260_9
; %bb.3:                                ; %window.grow.copy.ready.v2.i
	cbz	x22, LBB260_7
; %bb.4:                                ; %window.grow.copy.old.v2.i
	lsl	x2, x23, #5
	mov	x22, x0
	mov	x1, x21
	bl	_memcpy
	mov	x0, x21
	bl	_free
	mov	x0, x22
	b	LBB260_7
LBB260_5:
	mov	x19, x22
	b	LBB260_8
LBB260_6:                               ; %window.grow.reallocate.v2.i
	mov	x0, x21
	bl	_realloc
	cbz	x0, LBB260_9
LBB260_7:                               ; %"wf_grow$instance$57d99a800120d980.exit"
	stp	x19, x0, [x20, #8]
LBB260_8:                               ; %common.ret
	mov	x0, x19
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB260_9:                               ; %window.block.oom.v2.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$2a15825f0f6e194e ; -- Begin function wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$2a15825f0f6e194e
	.p2align	2
_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$2a15825f0f6e194e: ; @"wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$2a15825f0f6e194e"
; %bb.0:                                ; %entry
	lsr	x8, x2, #1
	cmp	x1, x8
	b.hs	LBB261_29
; %bb.1:                                ; %bb5.lr.ph
	sub	sp, sp, #32
	ldr	x9, [x0]
	ldr	x10, [x0, #16]
	mov	w11, #56                        ; =0x38
	b	LBB261_3
LBB261_2:                               ; %"wf_record_report_position$instance$50c6da9371c13a22.exit24"
                                        ;   in Loop: Header=BB261_3 Depth=1
	cmp	x1, x8
	b.hs	LBB261_28
LBB261_3:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	mov	x12, x1
	lsl	x14, x1, #1
	mov	w13, #1                         ; =0x1
	bfi	x13, x1, #1, #63
	add	x14, x14, #2
	cmp	x14, x9
	b.hs	LBB261_7
; %bb.4:                                ; %bb2.i
                                        ;   in Loop: Header=BB261_3 Depth=1
	add	x15, x10, x14, lsl #5
	add	x16, x10, x13, lsl #5
	ldr	x17, [x15]
	ldr	x0, [x16]
	cmp	x17, x0
	b.hs	LBB261_6
LBB261_5:                               ;   in Loop: Header=BB261_3 Depth=1
	mov	x1, x14
	b	LBB261_8
LBB261_6:                               ; %bb3.i.i
                                        ;   in Loop: Header=BB261_3 Depth=1
	b.ls	LBB261_23
LBB261_7:                               ;   in Loop: Header=BB261_3 Depth=1
	mov	x1, x13
LBB261_8:                               ; %"wf_collections.priority_queue.priority_queue_child$instance$97f85d10896f0873.exit"
                                        ;   in Loop: Header=BB261_3 Depth=1
	add	x14, x10, x12, lsl #5
	add	x13, x10, x1, lsl #5
	ldr	x15, [x14]
	ldr	x16, [x13]
	cmp	x15, x16
	b.lo	LBB261_28
; %bb.9:                                ; %bb3.i
                                        ;   in Loop: Header=BB261_3 Depth=1
	b.hi	LBB261_15
; %bb.10:                               ; %bb6.i
                                        ;   in Loop: Header=BB261_3 Depth=1
	ldr	x15, [x14, #8]
	ldr	x16, [x13, #8]
	cmp	x15, x16
	b.lo	LBB261_28
; %bb.11:                               ; %bb9.i
                                        ;   in Loop: Header=BB261_3 Depth=1
	b.hi	LBB261_15
; %bb.12:                               ; %bb12.i
                                        ;   in Loop: Header=BB261_3 Depth=1
	ldr	x15, [x14, #16]
	ldr	x16, [x13, #16]
	cmp	x15, x16
	b.lo	LBB261_28
; %bb.13:                               ; %bb15.i
                                        ;   in Loop: Header=BB261_3 Depth=1
	b.hi	LBB261_15
; %bb.14:                               ; %bb18.i
                                        ;   in Loop: Header=BB261_3 Depth=1
	ldr	x15, [x14, #24]
	ldr	x16, [x13, #24]
	cmp	x15, x16
	b.ls	LBB261_28
LBB261_15:                              ; %bb8
                                        ;   in Loop: Header=BB261_3 Depth=1
	ldp	q1, q0, [x14]
	ldp	q3, q2, [x13]
	stp	q3, q2, [x14]
	stp	q1, q0, [x13]
	ldr	x16, [x14, #16]
	ldr	x15, [x4]
	cmp	x16, x15
	b.hs	LBB261_19
; %bb.16:                               ; %bb2.i.i.i
                                        ;   in Loop: Header=BB261_3 Depth=1
	ldr	x17, [x14, #24]
	ldr	x14, [x4, #16]
	madd	x14, x16, x11, x14
	ldr	x16, [x14, #40]
	cmp	x16, x17
	b.ne	LBB261_19
; %bb.17:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB261_3 Depth=1
	ldr	x16, [x14]
	cbz	x16, LBB261_19
; %bb.18:                               ; %bb8.i.i.i
                                        ;   in Loop: Header=BB261_3 Depth=1
	str	x12, [x14, #32]
LBB261_19:                              ; %"wf_record_report_position$instance$50c6da9371c13a22.exit"
                                        ;   in Loop: Header=BB261_3 Depth=1
	ldr	x12, [x13, #16]
	cmp	x12, x15
	b.hs	LBB261_2
; %bb.20:                               ; %bb2.i.i.i11
                                        ;   in Loop: Header=BB261_3 Depth=1
	ldr	x13, [x13, #24]
	ldr	x14, [x4, #16]
	madd	x12, x12, x11, x14
	ldr	x14, [x12, #40]
	cmp	x14, x13
	b.ne	LBB261_2
; %bb.21:                               ; %bb5.i.i.i19
                                        ;   in Loop: Header=BB261_3 Depth=1
	ldr	x13, [x12]
	cbz	x13, LBB261_2
; %bb.22:                               ; %bb8.i.i.i22
                                        ;   in Loop: Header=BB261_3 Depth=1
	str	x1, [x12, #32]
	b	LBB261_2
LBB261_23:                              ; %bb6.i.i
                                        ;   in Loop: Header=BB261_3 Depth=1
	ldr	x17, [x15, #8]
	ldr	x0, [x16, #8]
	cmp	x17, x0
	b.lo	LBB261_5
; %bb.24:                               ; %bb9.i.i
                                        ;   in Loop: Header=BB261_3 Depth=1
	b.hi	LBB261_7
; %bb.25:                               ; %bb12.i.i
                                        ;   in Loop: Header=BB261_3 Depth=1
	ldr	x17, [x15, #16]
	ldr	x0, [x16, #16]
	mov	x1, x14
	cmp	x17, x0
	b.lo	LBB261_8
; %bb.26:                               ; %bb15.i.i
                                        ;   in Loop: Header=BB261_3 Depth=1
	mov	x1, x13
	b.hi	LBB261_8
; %bb.27:                               ; %bb18.i.i
                                        ;   in Loop: Header=BB261_3 Depth=1
	ldr	x15, [x15, #24]
	ldr	x16, [x16, #24]
	cmp	x15, x16
	csel	x1, x14, x13, lo
	b	LBB261_8
LBB261_28:
	add	sp, sp, #32
LBB261_29:                              ; %common.ret
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$45e23263d9dc5d6a ; -- Begin function wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$45e23263d9dc5d6a
	.p2align	2
_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$45e23263d9dc5d6a: ; @"wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$45e23263d9dc5d6a"
; %bb.0:                                ; %entry
	lsr	x8, x2, #1
	cmp	x1, x8
	b.hs	LBB262_21
; %bb.1:                                ; %bb5.lr.ph
	sub	sp, sp, #32
	ldr	x9, [x0]
	ldr	x10, [x0, #16]
	b	LBB262_3
LBB262_2:                               ; %bb8
                                        ;   in Loop: Header=BB262_3 Depth=1
	ldp	q1, q0, [x12]
	ldp	q3, q2, [x11]
	stp	q3, q2, [x12]
	stp	q1, q0, [x11]
	cmp	x1, x8
	b.hs	LBB262_20
LBB262_3:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	mov	x11, x1
	lsl	x13, x1, #1
	mov	w12, #1                         ; =0x1
	bfi	x12, x1, #1, #63
	add	x13, x13, #2
	cmp	x13, x9
	b.hs	LBB262_7
; %bb.4:                                ; %bb2.i
                                        ;   in Loop: Header=BB262_3 Depth=1
	add	x14, x10, x13, lsl #5
	add	x15, x10, x12, lsl #5
	ldr	x16, [x14]
	ldr	x17, [x15]
	cmp	x16, x17
	b.hs	LBB262_6
LBB262_5:                               ;   in Loop: Header=BB262_3 Depth=1
	mov	x1, x13
	b	LBB262_8
LBB262_6:                               ; %bb3.i.i
                                        ;   in Loop: Header=BB262_3 Depth=1
	b.ls	LBB262_15
LBB262_7:                               ;   in Loop: Header=BB262_3 Depth=1
	mov	x1, x12
LBB262_8:                               ; %"wf_collections.priority_queue.priority_queue_child$instance$b1f8c2aa150dd109.exit"
                                        ;   in Loop: Header=BB262_3 Depth=1
	add	x12, x10, x11, lsl #5
	add	x11, x10, x1, lsl #5
	ldr	x13, [x12]
	ldr	x14, [x11]
	cmp	x13, x14
	b.lo	LBB262_20
; %bb.9:                                ; %bb3.i
                                        ;   in Loop: Header=BB262_3 Depth=1
	b.hi	LBB262_2
; %bb.10:                               ; %bb6.i
                                        ;   in Loop: Header=BB262_3 Depth=1
	ldr	x13, [x12, #8]
	ldr	x14, [x11, #8]
	cmp	x13, x14
	b.lo	LBB262_20
; %bb.11:                               ; %bb9.i
                                        ;   in Loop: Header=BB262_3 Depth=1
	b.hi	LBB262_2
; %bb.12:                               ; %bb12.i
                                        ;   in Loop: Header=BB262_3 Depth=1
	ldr	x13, [x12, #16]
	ldr	x14, [x11, #16]
	cmp	x13, x14
	b.lo	LBB262_20
; %bb.13:                               ; %bb15.i
                                        ;   in Loop: Header=BB262_3 Depth=1
	b.hi	LBB262_2
; %bb.14:                               ; %bb18.i
                                        ;   in Loop: Header=BB262_3 Depth=1
	ldr	x13, [x12, #24]
	ldr	x14, [x11, #24]
	cmp	x13, x14
	b.hi	LBB262_2
	b	LBB262_20
LBB262_15:                              ; %bb6.i.i
                                        ;   in Loop: Header=BB262_3 Depth=1
	ldr	x16, [x14, #8]
	ldr	x17, [x15, #8]
	cmp	x16, x17
	b.lo	LBB262_5
; %bb.16:                               ; %bb9.i.i
                                        ;   in Loop: Header=BB262_3 Depth=1
	b.hi	LBB262_7
; %bb.17:                               ; %bb12.i.i
                                        ;   in Loop: Header=BB262_3 Depth=1
	ldr	x16, [x14, #16]
	ldr	x17, [x15, #16]
	mov	x1, x13
	cmp	x16, x17
	b.lo	LBB262_8
; %bb.18:                               ; %bb15.i.i
                                        ;   in Loop: Header=BB262_3 Depth=1
	mov	x1, x12
	b.hi	LBB262_8
; %bb.19:                               ; %bb18.i.i
                                        ;   in Loop: Header=BB262_3 Depth=1
	ldr	x14, [x14, #24]
	ldr	x15, [x15, #24]
	cmp	x14, x15
	csel	x1, x13, x12, lo
	b	LBB262_8
LBB262_20:
	add	sp, sp, #32
LBB262_21:                              ; %common.ret
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_edit$instance$8849ff7cbb1262dd ; -- Begin function wf_std.collections.slab.slab_edit$instance$8849ff7cbb1262dd
	.p2align	2
_wf_std.collections.slab.slab_edit$instance$8849ff7cbb1262dd: ; @"wf_std.collections.slab.slab_edit$instance$8849ff7cbb1262dd"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	ldr	x9, [x0]
	cmp	x8, x9
	b.hs	LBB263_4
; %bb.1:                                ; %bb2.i
	ldr	x9, [x1, #8]
	ldr	x10, [x0, #16]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB263_4
; %bb.2:                                ; %bb5.i
	ldr	x9, [x8]
	cbz	x9, LBB263_4
; %bb.3:                                ; %bb8.i
	mov	w0, #0                          ; =0x0
	ldr	x9, [x2]
	str	x9, [x8, #32]
	b	LBB263_5
LBB263_4:
	mov	w0, #1                          ; =0x1
LBB263_5:                               ; %"wf_std.collections.slab.slab_edit$instance$8849ff7cbb1262dd.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_reserve$instance$6fdaba65c7a2e99d ; -- Begin function wf_collections.priority_queue.priority_queue_reserve$instance$6fdaba65c7a2e99d
	.p2align	2
_wf_collections.priority_queue.priority_queue_reserve$instance$6fdaba65c7a2e99d: ; @"wf_collections.priority_queue.priority_queue_reserve$instance$6fdaba65c7a2e99d"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	ldr	x22, [x0, #8]
	cmp	x22, x1
	b.hs	LBB264_5
; %bb.1:                                ; %bb3
	mov	x19, x1
	mov	x20, x0
	ldr	x23, [x0]
	ldr	x21, [x0, #16]
	lsl	x1, x1, #5
	cmp	x22, #0
	ccmp	x23, x22, #0, ne
	b.eq	LBB264_6
; %bb.2:                                ; %window.grow.copy.v2.i
	mov	x0, x1
	bl	_malloc
	cbz	x0, LBB264_9
; %bb.3:                                ; %window.grow.copy.ready.v2.i
	cbz	x22, LBB264_7
; %bb.4:                                ; %window.grow.copy.old.v2.i
	lsl	x2, x23, #5
	mov	x22, x0
	mov	x1, x21
	bl	_memcpy
	mov	x0, x21
	bl	_free
	mov	x0, x22
	b	LBB264_7
LBB264_5:
	mov	x19, x22
	b	LBB264_8
LBB264_6:                               ; %window.grow.reallocate.v2.i
	mov	x0, x21
	bl	_realloc
	cbz	x0, LBB264_9
LBB264_7:                               ; %"wf_grow$instance$57d99a800120d980.exit"
	stp	x19, x0, [x20, #8]
LBB264_8:                               ; %common.ret
	mov	x0, x19
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB264_9:                               ; %window.block.oom.v2.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$ab518dd14902c4dc ; -- Begin function wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$ab518dd14902c4dc
	.p2align	2
_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$ab518dd14902c4dc: ; @"wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$ab518dd14902c4dc"
; %bb.0:                                ; %entry
	lsr	x8, x2, #1
	cmp	x1, x8
	b.hs	LBB265_21
; %bb.1:                                ; %bb5.lr.ph
	sub	sp, sp, #32
	ldr	x9, [x0]
	ldr	x10, [x0, #16]
	b	LBB265_3
LBB265_2:                               ; %bb8
                                        ;   in Loop: Header=BB265_3 Depth=1
	ldp	q1, q0, [x12]
	ldp	q3, q2, [x11]
	stp	q3, q2, [x12]
	stp	q1, q0, [x11]
	cmp	x1, x8
	b.hs	LBB265_20
LBB265_3:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	mov	x11, x1
	lsl	x13, x1, #1
	mov	w12, #1                         ; =0x1
	bfi	x12, x1, #1, #63
	add	x13, x13, #2
	cmp	x13, x9
	b.hs	LBB265_7
; %bb.4:                                ; %bb2.i
                                        ;   in Loop: Header=BB265_3 Depth=1
	add	x14, x10, x13, lsl #5
	add	x15, x10, x12, lsl #5
	ldr	x16, [x14]
	ldr	x17, [x15]
	cmp	x16, x17
	b.hs	LBB265_6
LBB265_5:                               ;   in Loop: Header=BB265_3 Depth=1
	mov	x1, x13
	b	LBB265_8
LBB265_6:                               ; %bb3.i.i
                                        ;   in Loop: Header=BB265_3 Depth=1
	b.ls	LBB265_15
LBB265_7:                               ;   in Loop: Header=BB265_3 Depth=1
	mov	x1, x12
LBB265_8:                               ; %"wf_collections.priority_queue.priority_queue_child$instance$e332b3dde67982e1.exit"
                                        ;   in Loop: Header=BB265_3 Depth=1
	add	x12, x10, x11, lsl #5
	add	x11, x10, x1, lsl #5
	ldr	x13, [x12]
	ldr	x14, [x11]
	cmp	x13, x14
	b.lo	LBB265_20
; %bb.9:                                ; %bb3.i
                                        ;   in Loop: Header=BB265_3 Depth=1
	b.hi	LBB265_2
; %bb.10:                               ; %bb6.i
                                        ;   in Loop: Header=BB265_3 Depth=1
	ldr	x13, [x12, #8]
	ldr	x14, [x11, #8]
	cmp	x13, x14
	b.lo	LBB265_20
; %bb.11:                               ; %bb9.i
                                        ;   in Loop: Header=BB265_3 Depth=1
	b.hi	LBB265_2
; %bb.12:                               ; %bb12.i
                                        ;   in Loop: Header=BB265_3 Depth=1
	ldr	x13, [x12, #16]
	ldr	x14, [x11, #16]
	cmp	x13, x14
	b.lo	LBB265_20
; %bb.13:                               ; %bb15.i
                                        ;   in Loop: Header=BB265_3 Depth=1
	b.hi	LBB265_2
; %bb.14:                               ; %bb18.i
                                        ;   in Loop: Header=BB265_3 Depth=1
	ldr	x13, [x12, #24]
	ldr	x14, [x11, #24]
	cmp	x13, x14
	b.hi	LBB265_2
	b	LBB265_20
LBB265_15:                              ; %bb6.i.i
                                        ;   in Loop: Header=BB265_3 Depth=1
	ldr	x16, [x14, #8]
	ldr	x17, [x15, #8]
	cmp	x16, x17
	b.lo	LBB265_5
; %bb.16:                               ; %bb9.i.i
                                        ;   in Loop: Header=BB265_3 Depth=1
	b.hi	LBB265_7
; %bb.17:                               ; %bb12.i.i
                                        ;   in Loop: Header=BB265_3 Depth=1
	ldr	x16, [x14, #16]
	ldr	x17, [x15, #16]
	mov	x1, x13
	cmp	x16, x17
	b.lo	LBB265_8
; %bb.18:                               ; %bb15.i.i
                                        ;   in Loop: Header=BB265_3 Depth=1
	mov	x1, x12
	b.hi	LBB265_8
; %bb.19:                               ; %bb18.i.i
                                        ;   in Loop: Header=BB265_3 Depth=1
	ldr	x14, [x14, #24]
	ldr	x15, [x15, #24]
	cmp	x14, x15
	csel	x1, x13, x12, lo
	b	LBB265_8
LBB265_20:
	add	sp, sp, #32
LBB265_21:                              ; %common.ret
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$4a1731430e1da28f ; -- Begin function wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$4a1731430e1da28f
	.p2align	2
_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$4a1731430e1da28f: ; @"wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$4a1731430e1da28f"
; %bb.0:                                ; %entry
	cbz	x1, LBB266_19
; %bb.1:                                ; %bb5.lr.ph
	sub	sp, sp, #32
	ldr	x8, [x0, #16]
	mov	w9, #56                         ; =0x38
	b	LBB266_3
LBB266_2:                               ; %"wf_record_report_position$instance$aa2364d9cd38ac5f.exit23"
                                        ;   in Loop: Header=BB266_3 Depth=1
	cmp	x10, #2
	b.lo	LBB266_18
LBB266_3:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	mov	x11, x1
	sub	x10, x1, #1
	lsr	x1, x10, #1
	add	x13, x8, x1, lsl #5
	add	x12, x8, x11, lsl #5
	ldr	x14, [x13]
	ldr	x15, [x12]
	cmp	x14, x15
	b.lo	LBB266_18
; %bb.4:                                ; %bb3.i
                                        ;   in Loop: Header=BB266_3 Depth=1
	b.hi	LBB266_10
; %bb.5:                                ; %bb6.i
                                        ;   in Loop: Header=BB266_3 Depth=1
	ldr	x14, [x13, #8]
	ldr	x15, [x12, #8]
	cmp	x14, x15
	b.lo	LBB266_18
; %bb.6:                                ; %bb9.i
                                        ;   in Loop: Header=BB266_3 Depth=1
	b.hi	LBB266_10
; %bb.7:                                ; %bb12.i
                                        ;   in Loop: Header=BB266_3 Depth=1
	ldr	x14, [x13, #16]
	ldr	x15, [x12, #16]
	cmp	x14, x15
	b.lo	LBB266_18
; %bb.8:                                ; %bb15.i
                                        ;   in Loop: Header=BB266_3 Depth=1
	b.hi	LBB266_10
; %bb.9:                                ; %bb18.i
                                        ;   in Loop: Header=BB266_3 Depth=1
	ldr	x14, [x13, #24]
	ldr	x15, [x12, #24]
	cmp	x14, x15
	b.ls	LBB266_18
LBB266_10:                              ; %bb8
                                        ;   in Loop: Header=BB266_3 Depth=1
	ldp	q1, q0, [x13]
	ldp	q3, q2, [x12]
	stp	q3, q2, [x13]
	stp	q1, q0, [x12]
	ldr	x15, [x13, #16]
	ldr	x14, [x4]
	cmp	x15, x14
	b.hs	LBB266_14
; %bb.11:                               ; %bb2.i.i.i
                                        ;   in Loop: Header=BB266_3 Depth=1
	ldr	x16, [x13, #24]
	ldr	x13, [x4, #16]
	madd	x13, x15, x9, x13
	ldr	x15, [x13, #40]
	cmp	x15, x16
	b.ne	LBB266_14
; %bb.12:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB266_3 Depth=1
	ldr	x15, [x13]
	cbz	x15, LBB266_14
; %bb.13:                               ; %bb8.i.i.i
                                        ;   in Loop: Header=BB266_3 Depth=1
	str	x1, [x13, #32]
LBB266_14:                              ; %"wf_record_report_position$instance$aa2364d9cd38ac5f.exit"
                                        ;   in Loop: Header=BB266_3 Depth=1
	ldr	x13, [x12, #16]
	cmp	x13, x14
	b.hs	LBB266_2
; %bb.15:                               ; %bb2.i.i.i10
                                        ;   in Loop: Header=BB266_3 Depth=1
	ldr	x14, [x12, #24]
	ldr	x12, [x4, #16]
	madd	x12, x13, x9, x12
	ldr	x13, [x12, #40]
	cmp	x13, x14
	b.ne	LBB266_2
; %bb.16:                               ; %bb5.i.i.i18
                                        ;   in Loop: Header=BB266_3 Depth=1
	ldr	x13, [x12]
	cbz	x13, LBB266_2
; %bb.17:                               ; %bb8.i.i.i21
                                        ;   in Loop: Header=BB266_3 Depth=1
	str	x11, [x12, #32]
	b	LBB266_2
LBB266_18:
	add	sp, sp, #32
LBB266_19:                              ; %common.ret
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$4a1731430e1da28f ; -- Begin function wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$4a1731430e1da28f
	.p2align	2
_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$4a1731430e1da28f: ; @"wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$4a1731430e1da28f"
; %bb.0:                                ; %entry
	lsr	x8, x2, #1
	cmp	x1, x8
	b.hs	LBB267_29
; %bb.1:                                ; %bb5.lr.ph
	sub	sp, sp, #32
	ldr	x9, [x0]
	ldr	x10, [x0, #16]
	mov	w11, #56                        ; =0x38
	b	LBB267_3
LBB267_2:                               ; %"wf_record_report_position$instance$aa2364d9cd38ac5f.exit24"
                                        ;   in Loop: Header=BB267_3 Depth=1
	cmp	x1, x8
	b.hs	LBB267_28
LBB267_3:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	mov	x12, x1
	lsl	x14, x1, #1
	mov	w13, #1                         ; =0x1
	bfi	x13, x1, #1, #63
	add	x14, x14, #2
	cmp	x14, x9
	b.hs	LBB267_7
; %bb.4:                                ; %bb2.i
                                        ;   in Loop: Header=BB267_3 Depth=1
	add	x15, x10, x14, lsl #5
	add	x16, x10, x13, lsl #5
	ldr	x17, [x15]
	ldr	x0, [x16]
	cmp	x17, x0
	b.hs	LBB267_6
LBB267_5:                               ;   in Loop: Header=BB267_3 Depth=1
	mov	x1, x14
	b	LBB267_8
LBB267_6:                               ; %bb3.i.i
                                        ;   in Loop: Header=BB267_3 Depth=1
	b.ls	LBB267_23
LBB267_7:                               ;   in Loop: Header=BB267_3 Depth=1
	mov	x1, x13
LBB267_8:                               ; %"wf_collections.priority_queue.priority_queue_child$instance$e332b3dde67982e1.exit"
                                        ;   in Loop: Header=BB267_3 Depth=1
	add	x14, x10, x12, lsl #5
	add	x13, x10, x1, lsl #5
	ldr	x15, [x14]
	ldr	x16, [x13]
	cmp	x15, x16
	b.lo	LBB267_28
; %bb.9:                                ; %bb3.i
                                        ;   in Loop: Header=BB267_3 Depth=1
	b.hi	LBB267_15
; %bb.10:                               ; %bb6.i
                                        ;   in Loop: Header=BB267_3 Depth=1
	ldr	x15, [x14, #8]
	ldr	x16, [x13, #8]
	cmp	x15, x16
	b.lo	LBB267_28
; %bb.11:                               ; %bb9.i
                                        ;   in Loop: Header=BB267_3 Depth=1
	b.hi	LBB267_15
; %bb.12:                               ; %bb12.i
                                        ;   in Loop: Header=BB267_3 Depth=1
	ldr	x15, [x14, #16]
	ldr	x16, [x13, #16]
	cmp	x15, x16
	b.lo	LBB267_28
; %bb.13:                               ; %bb15.i
                                        ;   in Loop: Header=BB267_3 Depth=1
	b.hi	LBB267_15
; %bb.14:                               ; %bb18.i
                                        ;   in Loop: Header=BB267_3 Depth=1
	ldr	x15, [x14, #24]
	ldr	x16, [x13, #24]
	cmp	x15, x16
	b.ls	LBB267_28
LBB267_15:                              ; %bb8
                                        ;   in Loop: Header=BB267_3 Depth=1
	ldp	q1, q0, [x14]
	ldp	q3, q2, [x13]
	stp	q3, q2, [x14]
	stp	q1, q0, [x13]
	ldr	x16, [x14, #16]
	ldr	x15, [x4]
	cmp	x16, x15
	b.hs	LBB267_19
; %bb.16:                               ; %bb2.i.i.i
                                        ;   in Loop: Header=BB267_3 Depth=1
	ldr	x17, [x14, #24]
	ldr	x14, [x4, #16]
	madd	x14, x16, x11, x14
	ldr	x16, [x14, #40]
	cmp	x16, x17
	b.ne	LBB267_19
; %bb.17:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB267_3 Depth=1
	ldr	x16, [x14]
	cbz	x16, LBB267_19
; %bb.18:                               ; %bb8.i.i.i
                                        ;   in Loop: Header=BB267_3 Depth=1
	str	x12, [x14, #32]
LBB267_19:                              ; %"wf_record_report_position$instance$aa2364d9cd38ac5f.exit"
                                        ;   in Loop: Header=BB267_3 Depth=1
	ldr	x12, [x13, #16]
	cmp	x12, x15
	b.hs	LBB267_2
; %bb.20:                               ; %bb2.i.i.i11
                                        ;   in Loop: Header=BB267_3 Depth=1
	ldr	x13, [x13, #24]
	ldr	x14, [x4, #16]
	madd	x12, x12, x11, x14
	ldr	x14, [x12, #40]
	cmp	x14, x13
	b.ne	LBB267_2
; %bb.21:                               ; %bb5.i.i.i19
                                        ;   in Loop: Header=BB267_3 Depth=1
	ldr	x13, [x12]
	cbz	x13, LBB267_2
; %bb.22:                               ; %bb8.i.i.i22
                                        ;   in Loop: Header=BB267_3 Depth=1
	str	x1, [x12, #32]
	b	LBB267_2
LBB267_23:                              ; %bb6.i.i
                                        ;   in Loop: Header=BB267_3 Depth=1
	ldr	x17, [x15, #8]
	ldr	x0, [x16, #8]
	cmp	x17, x0
	b.lo	LBB267_5
; %bb.24:                               ; %bb9.i.i
                                        ;   in Loop: Header=BB267_3 Depth=1
	b.hi	LBB267_7
; %bb.25:                               ; %bb12.i.i
                                        ;   in Loop: Header=BB267_3 Depth=1
	ldr	x17, [x15, #16]
	ldr	x0, [x16, #16]
	mov	x1, x14
	cmp	x17, x0
	b.lo	LBB267_8
; %bb.26:                               ; %bb15.i.i
                                        ;   in Loop: Header=BB267_3 Depth=1
	mov	x1, x13
	b.hi	LBB267_8
; %bb.27:                               ; %bb18.i.i
                                        ;   in Loop: Header=BB267_3 Depth=1
	ldr	x15, [x15, #24]
	ldr	x16, [x16, #24]
	cmp	x15, x16
	csel	x1, x14, x13, lo
	b	LBB267_8
LBB267_28:
	add	sp, sp, #32
LBB267_29:                              ; %common.ret
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_find$instance$2c23e55f2c711739 ; -- Begin function wf_std.collections.hash_map.hash_map_find$instance$2c23e55f2c711739
	.p2align	2
_wf_std.collections.hash_map.hash_map_find$instance$2c23e55f2c711739: ; @"wf_std.collections.hash_map.hash_map_find$instance$2c23e55f2c711739"
; %bb.0:                                ; %entry
	mov	x8, x1
	ldr	x9, [x2]
	cbz	x9, LBB268_2
; %bb.1:                                ; %bb3.i.i
	ldr	x10, [x8]
	udiv	x11, x10, x9
	msub	x10, x11, x9, x10
	ldr	x9, [x0]
	cbnz	x9, LBB268_3
	b	LBB268_9
LBB268_2:
	mov	x10, #0                         ; =0x0
	ldr	x9, [x0]
	cbz	x9, LBB268_9
LBB268_3:                               ; %bb3.i
	udiv	x11, x10, x9
	msub	x1, x11, x9, x10
	ldr	x10, [x0, #16]
	mov	x11, x9
	b	LBB268_5
LBB268_4:                               ; %bb8.i
                                        ;   in Loop: Header=BB268_5 Depth=1
	add	x12, x1, #1
	cmp	x12, x9
	csinc	x1, xzr, x1, hs
	subs	x11, x11, #1
	b.eq	LBB268_9
LBB268_5:                               ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x13, x10, x1, lsl #5
	ldr	w12, [x13]
	cmp	w12, #1
	b.eq	LBB268_4
; %bb.6:                                ; %bb5.i
                                        ;   in Loop: Header=BB268_5 Depth=1
	cmp	w12, #2
	b.ne	LBB268_10
; %bb.7:                                ; %bb3.i3.i
                                        ;   in Loop: Header=BB268_5 Depth=1
	ldr	x12, [x13, #8]
	ldr	x13, [x8]
	cmp	x12, x13
	b.ne	LBB268_4
; %bb.8:
	mov	w0, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ret
LBB268_9:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	ret
LBB268_10:
	mov	w0, #1                          ; =0x1
	mov	x1, x12
	mov	w2, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.slab.slab_visit$instance$676778b0f6b68ba1 ; -- Begin function wf_std.collections.slab.slab_visit$instance$676778b0f6b68ba1
	.p2align	2
_wf_std.collections.slab.slab_visit$instance$676778b0f6b68ba1: ; @"wf_std.collections.slab.slab_visit$instance$676778b0f6b68ba1"
; %bb.0:                                ; %entry
	ldr	x8, [x2]
	ldr	x9, [x1]
	cmp	x8, x9
	b.hs	LBB269_4
; %bb.1:                                ; %bb2
	ldr	x9, [x2, #8]
	ldr	x10, [x1, #16]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB269_4
; %bb.2:                                ; %bb5
	ldr	x9, [x8]
	cbz	x9, LBB269_4
; %bb.3:                                ; %bb8
	sub	sp, sp, #16
	ldr	x9, [x8, #8]
	ldrb	w10, [x8, #24]
	ldr	x8, [x8, #32]
	and	w10, w10, #0x1
	strb	w10, [sp, #8]
	stp	x9, xzr, [x0, #8]
	str	xzr, [x0]
	strb	w10, [x0, #16]
	str	x8, [x0, #24]
	add	sp, sp, #16
	ret
LBB269_4:                               ; %bb1
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_child$instance$a0febd4c3af9d108 ; -- Begin function wf_collections.priority_queue.priority_queue_child$instance$a0febd4c3af9d108
	.p2align	2
_wf_collections.priority_queue.priority_queue_child$instance$a0febd4c3af9d108: ; @"wf_collections.priority_queue.priority_queue_child$instance$a0febd4c3af9d108"
; %bb.0:                                ; %entry
	mov	x0, x1
	ret
                                        ; -- End function
	.globl	_wf_box_slots_new$instance$9ec8bbf9e58caef6 ; -- Begin function wf_box_slots_new$instance$9ec8bbf9e58caef6
	.p2align	2
_wf_box_slots_new$instance$9ec8bbf9e58caef6: ; @"wf_box_slots_new$instance$9ec8bbf9e58caef6"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	cbz	x0, LBB271_3
; %bb.1:                                ; %window.payload.allocate.v1.i
	lsl	x8, x19, #6
	sub	x0, x8, x19, lsl #3
	bl	_malloc
	mov	x2, x0
	cbnz	x0, LBB271_4
; %bb.2:                                ; %window.block.oom.v1.i
	bl	l_wf_resource_abort
LBB271_3:
Lloh396:
	adrp	x2, l_.wf.empty.slots.payload@PAGE
Lloh397:
	add	x2, x2, l_.wf.empty.slots.payload@PAGEOFF
LBB271_4:                               ; %"wf_box_slots_new$instance$9ec8bbf9e58caef6.body.exit"
	mov	x0, #0                          ; =0x0
	mov	x1, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh396, Lloh397
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_extend$instance$615fa5221ee98b49 ; -- Begin function wf_std.collections.hash_map.hash_map_extend$instance$615fa5221ee98b49
	.p2align	2
_wf_std.collections.hash_map.hash_map_extend$instance$615fa5221ee98b49: ; @"wf_std.collections.hash_map.hash_map_extend$instance$615fa5221ee98b49"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x20, x1
	mov	x19, x0
	ldp	x23, x22, [x0]
	cmp	x22, x1
	b.hs	LBB272_7
; %bb.1:                                ; %bb2
	ldr	x21, [x19, #16]
	lsl	x1, x20, #5
	cmp	x22, #0
	ccmp	x23, x22, #0, ne
	b.eq	LBB272_5
; %bb.2:                                ; %window.grow.copy.v2.i
	mov	x0, x1
	bl	_malloc
	cbz	x0, LBB272_12
; %bb.3:                                ; %window.grow.copy.ready.v2.i
	cbz	x22, LBB272_6
; %bb.4:                                ; %window.grow.copy.old.v2.i
	lsl	x2, x23, #5
	mov	x22, x0
	mov	x1, x21
	bl	_memcpy
	mov	x0, x21
	bl	_free
	mov	x0, x22
	b	LBB272_6
LBB272_5:                               ; %window.grow.reallocate.v2.i
	mov	x0, x21
	bl	_realloc
	cbz	x0, LBB272_12
LBB272_6:                               ; %"wf_grow$instance$29b61f0cf25c44c5.exit"
	stp	x20, x0, [x19, #8]
LBB272_7:                               ; %bb1
	cmp	x23, x20
	b.hs	LBB272_11
; %bb.8:                                ; %bb5.lr.ph
	ldr	x8, [x19, #16]
	add	x8, x8, x23, lsl #5
	add	x8, x8, #8
LBB272_9:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x8, #-8]
	add	x23, x23, #1
	stp	xzr, xzr, [x8, #8]
	str	xzr, [x8], #32
	cmp	x20, x23
	b.ne	LBB272_9
; %bb.10:                               ; %bb4.bb7_crit_edge
	str	x23, [x19]
LBB272_11:                              ; %bb7
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB272_12:                              ; %window.block.oom.v2.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_sift_sink$instance$64bc39c2fec80944 ; -- Begin function wf_collections.priority_queue.priority_queue_sift_sink$instance$64bc39c2fec80944
	.p2align	2
_wf_collections.priority_queue.priority_queue_sift_sink$instance$64bc39c2fec80944: ; @"wf_collections.priority_queue.priority_queue_sift_sink$instance$64bc39c2fec80944"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$e011e8cc7b7461b9
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_rebuild$instance$cb1167c8d0732e77 ; -- Begin function wf_std.collections.hash_map.hash_map_rebuild$instance$cb1167c8d0732e77
	.p2align	2
_wf_std.collections.hash_map.hash_map_rebuild$instance$cb1167c8d0732e77: ; @"wf_std.collections.hash_map.hash_map_rebuild$instance$cb1167c8d0732e77"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x22, x21, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x20, x19, [sp, #16]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	cmp	x1, #8
	b.hi	LBB274_2
; %bb.1:                                ; %bb3.i
	ldr	x20, [x0]
	cmp	x1, x20
	b.hs	LBB274_4
LBB274_2:
	mov	w0, #1                          ; =0x1
LBB274_3:                               ; %"wf_std.collections.hash_map.hash_map_rebuild$instance$cb1167c8d0732e77.body.exit"
	mov	w1, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #16]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp], #48             ; 16-byte Folded Reload
	ret
LBB274_4:                               ; %bb6.i
	cbz	x1, LBB274_23
; %bb.5:                                ; %window.payload.allocate.v1.i.i.i
	mov	x21, x2
	mov	x19, x0
	mov	x22, x1
	lsl	x0, x1, #5
	bl	_malloc
	cbz	x0, LBB274_24
; %bb.6:                                ; %bb5.i.i.preheader
	mov	x9, #0                          ; =0x0
	add	x8, x0, #8
	mov	x10, x19
	mov	x11, x22
	mov	x13, x21
LBB274_7:                               ; %bb5.i.i
                                        ; =>This Inner Loop Header: Depth=1
	stur	wzr, [x8, #-8]
	add	x9, x9, #1
	stp	xzr, xzr, [x8, #8]
	str	xzr, [x8], #32
	cmp	x11, x9
	b.ne	LBB274_7
; %bb.8:                                ; %"wf_std.collections.hash_map.hash_map_extend$instance$615fa5221ee98b49.exit.i"
	ldp	x12, x8, [x10, #8]
	stp	x11, x11, [x10]
	str	x0, [x10, #16]
	cbz	x20, LBB274_20
; %bb.9:                                ; %bb14.lr.ph.i
	ldr	x13, [x13]
	mov	w14, #2                         ; =0x2
	b	LBB274_12
LBB274_10:                              ; %"wf_std.collections.hash_map.hash_map_migrate_owner$instance$cb1167c8d0732e77.exit.i"
                                        ;   in Loop: Header=BB274_12 Depth=1
	add	x16, x0, x4, lsl #5
	str	w14, [x16]
	stur	q0, [x16, #8]
	str	x15, [x16, #24]
LBB274_11:                              ; %bb15.i
                                        ;   in Loop: Header=BB274_12 Depth=1
	cbz	x20, LBB274_20
LBB274_12:                              ; %bb14.i
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB274_14 Depth 2
                                        ;       Child Loop BB274_18 Depth 3
	sub	x20, x20, #1
	add	x15, x8, x20, lsl #5
	ldr	w16, [x15]
	cmp	w16, #2
	b.lo	LBB274_11
; %bb.13:                               ;   in Loop: Header=BB274_12 Depth=1
	ldur	q0, [x15, #8]
	ldr	x16, [x15, #8]
	ldr	x15, [x15, #24]
LBB274_14:                              ; %bb1.i9.i
                                        ;   Parent Loop BB274_12 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB274_18 Depth 3
	cbz	x13, LBB274_16
; %bb.15:                               ; %bb3.i.i.i
                                        ;   in Loop: Header=BB274_14 Depth=2
	udiv	x17, x16, x13
	msub	x1, x17, x13, x16
	b	LBB274_17
LBB274_16:                              ;   in Loop: Header=BB274_14 Depth=2
	mov	x1, #0                          ; =0x0
LBB274_17:                              ; %wf_record_id_hash.exit.i.i
                                        ;   in Loop: Header=BB274_14 Depth=2
	mov	x17, #0                         ; =0x0
	udiv	x2, x1, x11
	msub	x1, x2, x11, x1
	sub	x2, x11, x1
	neg	x3, x2
LBB274_18:                              ; %bb3.i.i
                                        ;   Parent Loop BB274_12 Depth=1
                                        ;     Parent Loop BB274_14 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	cmp	x17, x2
	csel	x4, x1, x3, lo
	add	x4, x4, x17
	lsl	x5, x4, #5
	ldr	w5, [x0, x5]
	cmp	w5, #1
	b.ls	LBB274_10
; %bb.19:                               ; %bb2.i12.i
                                        ;   in Loop: Header=BB274_18 Depth=3
	add	x17, x17, #1
	cmp	x9, x17
	b.ne	LBB274_18
	b	LBB274_14
LBB274_20:                              ; %bb13.i
	cbz	x12, LBB274_22
; %bb.21:                               ; %slots.release.drop.6.i.i
	mov	x0, x8
	bl	_free
	mov	x10, x19
LBB274_22:                              ; %"wf_free_empty$instance$16f094be4fd843b6.exit.i"
	mov	w0, #0                          ; =0x0
	str	xzr, [x10, #32]
	b	LBB274_3
LBB274_23:
	mov	w0, #0                          ; =0x0
	b	LBB274_3
LBB274_24:                              ; %window.block.oom.v1.i.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_try_put$instance$cb1167c8d0732e77 ; -- Begin function wf_std.collections.hash_map.hash_map_try_put$instance$cb1167c8d0732e77
	.p2align	2
_wf_std.collections.hash_map.hash_map_try_put$instance$cb1167c8d0732e77: ; @"wf_std.collections.hash_map.hash_map_try_put$instance$cb1167c8d0732e77"
; %bb.0:                                ; %entry
	ldr	x8, [x4]
	cbz	x8, LBB275_9
; %bb.1:                                ; %bb3.i
	udiv	x9, x2, x8
	msub	x9, x9, x8, x2
	ldr	x8, [x1]
	cbz	x8, LBB275_10
LBB275_2:                               ; %bb2
	udiv	x10, x9, x8
	msub	x10, x10, x8, x9
	ldr	x11, [x1, #16]
	mov	x12, x8
	mov	x9, x8
	b	LBB275_5
LBB275_3:                               ; %bb11
                                        ;   in Loop: Header=BB275_5 Depth=1
	cmp	x9, x8
	csel	x9, x10, x9, eq
LBB275_4:                               ; %bb8
                                        ;   in Loop: Header=BB275_5 Depth=1
	add	x13, x10, #1
	cmp	x13, x8
	csinc	x10, xzr, x10, hs
	subs	x12, x12, #1
	b.eq	LBB275_11
LBB275_5:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	add	x13, x11, x10, lsl #5
	ldr	w14, [x13]
	cmp	w14, #1
	b.eq	LBB275_3
; %bb.6:                                ; %bb5
                                        ;   in Loop: Header=BB275_5 Depth=1
	cmp	w14, #2
	b.ne	LBB275_15
; %bb.7:                                ; %bb3.i11
                                        ;   in Loop: Header=BB275_5 Depth=1
	ldr	x14, [x13, #8]
	cmp	x14, x2
	b.ne	LBB275_4
; %bb.8:                                ; %"wf_std.collections.hash_map.hash_map_exchange$instance$44a98dc5bf86badc.exit"
	ldr	q0, [x3]
	mov	w8, #2                          ; =0x2
	str	w8, [x13]
	ldr	q1, [x13, #16]
	str	q0, [x13, #16]
	mov	w8, #1                          ; =0x1
	stp	x8, x2, [x0]
	str	q1, [x0, #16]
	ret
LBB275_9:
	mov	x9, #0                          ; =0x0
	ldr	x8, [x1]
	cbnz	x8, LBB275_2
LBB275_10:
	mov	x9, #0                          ; =0x0
LBB275_11:                              ; %bb1
	cmp	x9, x8
	b.hs	LBB275_16
LBB275_12:                              ; %bb24
	ldr	x8, [x1, #24]
	cmp	x8, #7
	b.hi	LBB275_16
; %bb.13:                               ; %bb27
	add	x8, x8, #1
	str	x8, [x1, #24]
	ldr	x8, [x1, #16]
	add	x8, x8, x9, lsl #5
	ldr	w9, [x8]
	cmp	w9, #1
	b.ne	LBB275_17
; %bb.14:                               ; %bb29.thread
	ldr	x9, [x1, #32]
	subs	x9, x9, #1
	csel	x9, xzr, x9, lo
	str	x9, [x1, #32]
	ldr	q0, [x3]
	mov	w9, #2                          ; =0x2
	str	w9, [x8]
	str	x2, [x8, #8]
	str	q0, [x8, #16]
	b	LBB275_19
LBB275_15:                              ; %bb10
	cmp	x9, x8
	csel	x9, x10, x9, eq
	cmp	x9, x8
	b.lo	LBB275_12
LBB275_16:                              ; %bb23
	ldr	q0, [x3]
	stp	xzr, x2, [x0]
	mov	w8, #1                          ; =0x1
	str	w8, [x0]
	strb	w8, [x0, #4]
	str	q0, [x0, #16]
	ret
LBB275_17:                              ; %bb29
	ldur	q0, [x8, #8]
	ldr	x10, [x8, #24]
	ldr	q1, [x3]
	mov	w11, #2                         ; =0x2
	str	w11, [x8]
	str	x2, [x8, #8]
	str	q1, [x8, #16]
	cbz	w9, LBB275_19
; %bb.18:                               ; %bb3.i32
	mov	w8, #1                          ; =0x1
	str	x8, [x0]
	stur	q0, [x0, #8]
	str	x10, [x0, #24]
	ret
LBB275_19:                              ; %bb1.i37
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_record_set_id_member$instance$4a70da04567deb49 ; -- Begin function wf_record_set_id_member$instance$4a70da04567deb49
	.p2align	2
_wf_record_set_id_member$instance$4a70da04567deb49: ; @"wf_record_set_id_member$instance$4a70da04567deb49"
; %bb.0:                                ; %entry
	ldrb	w8, [x0]
	strb	w8, [x1, #16]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_record_report_position$instance$3ad8b32886f5e3ce ; -- Begin function wf_record_report_position$instance$3ad8b32886f5e3ce
	.p2align	2
_wf_record_report_position$instance$3ad8b32886f5e3ce: ; @"wf_record_report_position$instance$3ad8b32886f5e3ce"
; %bb.0:                                ; %entry
	ldr	x8, [x1, #16]
	ldr	x9, [x0]
	cmp	x8, x9
	b.hs	LBB277_4
; %bb.1:                                ; %bb2.i.i
	ldr	x9, [x1, #24]
	ldr	x10, [x0, #16]
	mov	w11, #56                        ; =0x38
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #40]
	cmp	x10, x9
	b.ne	LBB277_4
; %bb.2:                                ; %bb5.i.i
	ldr	x9, [x8]
	cbz	x9, LBB277_4
; %bb.3:                                ; %bb8.i.i
	str	x2, [x8, #32]
LBB277_4:                               ; %"wf_std.collections.slab.slab_edit$instance$f11a17af73d113d5.exit"
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_make_room$instance$8d53fd32336043f5 ; -- Begin function wf_collections.priority_queue.priority_queue_make_room$instance$8d53fd32336043f5
	.p2align	2
_wf_collections.priority_queue.priority_queue_make_room$instance$8d53fd32336043f5: ; @"wf_collections.priority_queue.priority_queue_make_room$instance$8d53fd32336043f5"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	ldp	x8, x20, [x0]
	cmp	x20, x8
	b.ne	LBB278_11
; %bb.1:                                ; %bb3
	mov	x19, x0
	cbz	x20, LBB278_5
; %bb.2:                                ; %bb6
	cmp	x20, #5
	b.hs	LBB278_7
; %bb.3:                                ; %bb11
	ldr	x0, [x19, #16]
	lsl	x1, x20, #6
	bl	_realloc
	cbz	x0, LBB278_12
; %bb.4:                                ; %"wf_grow$instance$57d99a800120d980.exit.i33"
	lsl	x8, x20, #1
	str	x0, [x19, #16]
	b	LBB278_10
LBB278_5:                               ; %bb5
	mov	w0, #32                         ; =0x20
	bl	_malloc
	cbz	x0, LBB278_12
; %bb.6:                                ; %window.grow.copy.ready.v2.i.i
	str	x0, [x19, #16]
	mov	w8, #1                          ; =0x1
	b	LBB278_10
LBB278_7:                               ; %bb7
	cmp	x20, #7
	b.hi	LBB278_11
; %bb.8:                                ; %bb3.i8
	ldr	x0, [x19, #16]
	mov	w1, #256                        ; =0x100
	bl	_realloc
	cbz	x0, LBB278_12
; %bb.9:                                ; %"wf_grow$instance$57d99a800120d980.exit.i"
	str	x0, [x19, #16]
	mov	w8, #8                          ; =0x8
LBB278_10:                              ; %common.ret.sink.split
	str	x8, [x19, #8]
LBB278_11:                              ; %common.ret
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
LBB278_12:                              ; %window.block.oom.v2.i.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$f0ce656cb92d5494 ; -- Begin function wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$f0ce656cb92d5494
	.p2align	2
_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$f0ce656cb92d5494: ; @"wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$f0ce656cb92d5494"
; %bb.0:                                ; %entry
	cbz	x1, LBB279_19
; %bb.1:                                ; %bb5.lr.ph
	sub	sp, sp, #32
	ldr	x8, [x0, #16]
	mov	w9, #56                         ; =0x38
	b	LBB279_3
LBB279_2:                               ; %"wf_record_report_position$instance$3ad8b32886f5e3ce.exit23"
                                        ;   in Loop: Header=BB279_3 Depth=1
	cmp	x10, #2
	b.lo	LBB279_18
LBB279_3:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	mov	x11, x1
	sub	x10, x1, #1
	lsr	x1, x10, #1
	add	x13, x8, x1, lsl #5
	add	x12, x8, x11, lsl #5
	ldr	x14, [x13]
	ldr	x15, [x12]
	cmp	x14, x15
	b.lo	LBB279_18
; %bb.4:                                ; %bb3.i
                                        ;   in Loop: Header=BB279_3 Depth=1
	b.hi	LBB279_10
; %bb.5:                                ; %bb6.i
                                        ;   in Loop: Header=BB279_3 Depth=1
	ldr	x14, [x13, #8]
	ldr	x15, [x12, #8]
	cmp	x14, x15
	b.lo	LBB279_18
; %bb.6:                                ; %bb9.i
                                        ;   in Loop: Header=BB279_3 Depth=1
	b.hi	LBB279_10
; %bb.7:                                ; %bb12.i
                                        ;   in Loop: Header=BB279_3 Depth=1
	ldr	x14, [x13, #16]
	ldr	x15, [x12, #16]
	cmp	x14, x15
	b.lo	LBB279_18
; %bb.8:                                ; %bb15.i
                                        ;   in Loop: Header=BB279_3 Depth=1
	b.hi	LBB279_10
; %bb.9:                                ; %bb18.i
                                        ;   in Loop: Header=BB279_3 Depth=1
	ldr	x14, [x13, #24]
	ldr	x15, [x12, #24]
	cmp	x14, x15
	b.ls	LBB279_18
LBB279_10:                              ; %bb8
                                        ;   in Loop: Header=BB279_3 Depth=1
	ldp	q1, q0, [x13]
	ldp	q3, q2, [x12]
	stp	q3, q2, [x13]
	stp	q1, q0, [x12]
	ldr	x15, [x13, #16]
	ldr	x14, [x4]
	cmp	x15, x14
	b.hs	LBB279_14
; %bb.11:                               ; %bb2.i.i.i
                                        ;   in Loop: Header=BB279_3 Depth=1
	ldr	x16, [x13, #24]
	ldr	x13, [x4, #16]
	madd	x13, x15, x9, x13
	ldr	x15, [x13, #40]
	cmp	x15, x16
	b.ne	LBB279_14
; %bb.12:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB279_3 Depth=1
	ldr	x15, [x13]
	cbz	x15, LBB279_14
; %bb.13:                               ; %bb8.i.i.i
                                        ;   in Loop: Header=BB279_3 Depth=1
	str	x1, [x13, #32]
LBB279_14:                              ; %"wf_record_report_position$instance$3ad8b32886f5e3ce.exit"
                                        ;   in Loop: Header=BB279_3 Depth=1
	ldr	x13, [x12, #16]
	cmp	x13, x14
	b.hs	LBB279_2
; %bb.15:                               ; %bb2.i.i.i10
                                        ;   in Loop: Header=BB279_3 Depth=1
	ldr	x14, [x12, #24]
	ldr	x12, [x4, #16]
	madd	x12, x13, x9, x12
	ldr	x13, [x12, #40]
	cmp	x13, x14
	b.ne	LBB279_2
; %bb.16:                               ; %bb5.i.i.i18
                                        ;   in Loop: Header=BB279_3 Depth=1
	ldr	x13, [x12]
	cbz	x13, LBB279_2
; %bb.17:                               ; %bb8.i.i.i21
                                        ;   in Loop: Header=BB279_3 Depth=1
	str	x11, [x12, #32]
	b	LBB279_2
LBB279_18:
	add	sp, sp, #32
LBB279_19:                              ; %common.ret
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_slots_new$instance$870c417897b1f10d ; -- Begin function wf_slots_new$instance$870c417897b1f10d
	.p2align	2
_wf_slots_new$instance$870c417897b1f10d: ; @"wf_slots_new$instance$870c417897b1f10d"
; %bb.0:                                ; %entry
	str	xzr, [x0, #32]
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$f0ce656cb92d5494 ; -- Begin function wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$f0ce656cb92d5494
	.p2align	2
_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$f0ce656cb92d5494: ; @"wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$f0ce656cb92d5494"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	cbz	x1, LBB281_2
; %bb.1:                                ; %bb2
	lsl	x8, x1, #4
	ldr	x9, [x0, #16]
	sub	x8, x8, #16
	and	x8, x8, #0xffffffffffffffe0
	add	x8, x9, x8
	add	x9, x9, x1, lsl #5
	ldr	x10, [x8]
	ldr	x11, [x9]
	cmp	x10, x11
	b.hs	LBB281_3
LBB281_2:                               ; %bb1
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$f0ce656cb92d5494
	b	LBB281_5
LBB281_3:                               ; %bb3.i
	b.ls	LBB281_6
LBB281_4:                               ; %bb5
	bl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$f0ce656cb92d5494
LBB281_5:                               ; %common.ret
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB281_6:                               ; %bb6.i
	ldr	x10, [x8, #8]
	ldr	x11, [x9, #8]
	cmp	x10, x11
	b.lo	LBB281_2
; %bb.7:                                ; %bb9.i
	b.hi	LBB281_4
; %bb.8:                                ; %bb12.i
	ldr	x10, [x8, #16]
	ldr	x11, [x9, #16]
	cmp	x10, x11
	b.lo	LBB281_2
; %bb.9:                                ; %bb15.i
	b.hi	LBB281_4
; %bb.10:                               ; %bb18.i
	ldr	x8, [x8, #24]
	ldr	x9, [x9, #24]
	cmp	x8, x9
	b.ls	LBB281_2
	b	LBB281_4
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_find$instance$cb1167c8d0732e77 ; -- Begin function wf_std.collections.hash_map.hash_map_find$instance$cb1167c8d0732e77
	.p2align	2
_wf_std.collections.hash_map.hash_map_find$instance$cb1167c8d0732e77: ; @"wf_std.collections.hash_map.hash_map_find$instance$cb1167c8d0732e77"
; %bb.0:                                ; %entry
	mov	x8, x1
	ldr	x9, [x2]
	cbz	x9, LBB282_2
; %bb.1:                                ; %bb3.i.i
	ldr	x10, [x8]
	udiv	x11, x10, x9
	msub	x10, x11, x9, x10
	ldr	x9, [x0]
	cbnz	x9, LBB282_3
	b	LBB282_9
LBB282_2:
	mov	x10, #0                         ; =0x0
	ldr	x9, [x0]
	cbz	x9, LBB282_9
LBB282_3:                               ; %bb3.i
	udiv	x11, x10, x9
	msub	x1, x11, x9, x10
	ldr	x10, [x0, #16]
	mov	x11, x9
	b	LBB282_5
LBB282_4:                               ; %bb8.i
                                        ;   in Loop: Header=BB282_5 Depth=1
	add	x12, x1, #1
	cmp	x12, x9
	csinc	x1, xzr, x1, hs
	subs	x11, x11, #1
	b.eq	LBB282_9
LBB282_5:                               ; %bb5.i
                                        ; =>This Inner Loop Header: Depth=1
	add	x13, x10, x1, lsl #5
	ldr	w12, [x13]
	cmp	w12, #1
	b.eq	LBB282_4
; %bb.6:                                ; %bb5.i
                                        ;   in Loop: Header=BB282_5 Depth=1
	cmp	w12, #2
	b.ne	LBB282_10
; %bb.7:                                ; %bb3.i3.i
                                        ;   in Loop: Header=BB282_5 Depth=1
	ldr	x12, [x13, #8]
	ldr	x13, [x8]
	cmp	x12, x13
	b.ne	LBB282_4
; %bb.8:
	mov	w0, #0                          ; =0x0
	mov	w2, #0                          ; =0x0
	ret
LBB282_9:
	mov	x1, #0                          ; =0x0
	mov	w0, #1                          ; =0x1
	mov	w2, #0                          ; =0x0
	ret
LBB282_10:
	mov	w0, #1                          ; =0x1
	mov	x1, x12
	mov	w2, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_record_swap_payload$instance$4a70da04567deb49 ; -- Begin function wf_record_swap_payload$instance$4a70da04567deb49
	.p2align	2
_wf_record_swap_payload$instance$4a70da04567deb49: ; @"wf_record_swap_payload$instance$4a70da04567deb49"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x9, [x1, #8]
	str	x9, [x0]
	str	x8, [x1, #8]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_record_read_info$instance$4a70da04567deb49 ; -- Begin function wf_record_read_info$instance$4a70da04567deb49
	.p2align	2
_wf_record_read_info$instance$4a70da04567deb49: ; @"wf_record_read_info$instance$4a70da04567deb49"
; %bb.0:                                ; %entry
	ldr	x0, [x1]
	ldr	x2, [x1, #24]
	ldrb	w8, [x1, #16]
	and	w1, w8, #0x1
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_peek$instance$89e474f4c5bc47c4 ; -- Begin function wf_collections.priority_queue.priority_queue_peek$instance$89e474f4c5bc47c4
	.p2align	2
_wf_collections.priority_queue.priority_queue_peek$instance$89e474f4c5bc47c4: ; @"wf_collections.priority_queue.priority_queue_peek$instance$89e474f4c5bc47c4"
; %bb.0:                                ; %entry
	ldr	x8, [x1, #16]
	ldp	q1, q0, [x8]
	stp	q1, q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_box_slots_new$instance$6f7c24dd1572f258 ; -- Begin function wf_box_slots_new$instance$6f7c24dd1572f258
	.p2align	2
_wf_box_slots_new$instance$6f7c24dd1572f258: ; @"wf_box_slots_new$instance$6f7c24dd1572f258"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x20, x19, [sp, #-32]!           ; 16-byte Folded Spill
	stp	x29, x30, [sp, #16]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	mov	x19, x0
	cbz	x0, LBB286_3
; %bb.1:                                ; %window.payload.allocate.v1.i
	lsl	x8, x19, #7
	sub	x0, x8, x19, lsl #4
	bl	_malloc
	mov	x2, x0
	cbnz	x0, LBB286_4
; %bb.2:                                ; %window.block.oom.v1.i
	bl	l_wf_resource_abort
LBB286_3:
Lloh398:
	adrp	x2, l_.wf.empty.slots.payload@PAGE
Lloh399:
	add	x2, x2, l_.wf.empty.slots.payload@PAGEOFF
LBB286_4:                               ; %"wf_box_slots_new$instance$6f7c24dd1572f258.body.exit"
	mov	x0, #0                          ; =0x0
	mov	x1, x19
	ldp	x29, x30, [sp, #16]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp], #32             ; 16-byte Folded Reload
	ret
	.loh AdrpAdd	Lloh398, Lloh399
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_record_set_id_member$instance$e1380248266a9ad2 ; -- Begin function wf_record_set_id_member$instance$e1380248266a9ad2
	.p2align	2
_wf_record_set_id_member$instance$e1380248266a9ad2: ; @"wf_record_set_id_member$instance$e1380248266a9ad2"
; %bb.0:                                ; %entry
	ldrb	w8, [x0]
	strb	w8, [x1, #72]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_record_report_position$instance$f8195bc386aec277 ; -- Begin function wf_record_report_position$instance$f8195bc386aec277
	.p2align	2
_wf_record_report_position$instance$f8195bc386aec277: ; @"wf_record_report_position$instance$f8195bc386aec277"
; %bb.0:                                ; %entry
	ldr	x8, [x1, #16]
	ldr	x9, [x0]
	cmp	x8, x9
	b.hs	LBB288_4
; %bb.1:                                ; %bb2.i.i
	ldr	x9, [x1, #24]
	ldr	x10, [x0, #16]
	mov	w11, #112                       ; =0x70
	madd	x8, x8, x11, x10
	ldr	x10, [x8, #96]
	cmp	x10, x9
	b.ne	LBB288_4
; %bb.2:                                ; %bb5.i.i
	ldr	x9, [x8]
	cbz	x9, LBB288_4
; %bb.3:                                ; %bb8.i.i
	str	x2, [x8, #88]
LBB288_4:                               ; %"wf_std.collections.slab.slab_edit$instance$6a5da7aad053cce4.exit"
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$d383295a38079908 ; -- Begin function wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$d383295a38079908
	.p2align	2
_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$d383295a38079908: ; @"wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$d383295a38079908"
; %bb.0:                                ; %entry
	cbz	x1, LBB289_19
; %bb.1:                                ; %bb5.lr.ph
	sub	sp, sp, #32
	ldr	x8, [x0, #16]
	mov	w9, #112                        ; =0x70
	b	LBB289_3
LBB289_2:                               ; %"wf_record_report_position$instance$f8195bc386aec277.exit23"
                                        ;   in Loop: Header=BB289_3 Depth=1
	cmp	x10, #2
	b.lo	LBB289_18
LBB289_3:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	mov	x11, x1
	sub	x10, x1, #1
	lsr	x1, x10, #1
	add	x13, x8, x1, lsl #5
	add	x12, x8, x11, lsl #5
	ldr	x14, [x13]
	ldr	x15, [x12]
	cmp	x14, x15
	b.lo	LBB289_18
; %bb.4:                                ; %bb3.i
                                        ;   in Loop: Header=BB289_3 Depth=1
	b.hi	LBB289_10
; %bb.5:                                ; %bb6.i
                                        ;   in Loop: Header=BB289_3 Depth=1
	ldr	x14, [x13, #8]
	ldr	x15, [x12, #8]
	cmp	x14, x15
	b.lo	LBB289_18
; %bb.6:                                ; %bb9.i
                                        ;   in Loop: Header=BB289_3 Depth=1
	b.hi	LBB289_10
; %bb.7:                                ; %bb12.i
                                        ;   in Loop: Header=BB289_3 Depth=1
	ldr	x14, [x13, #16]
	ldr	x15, [x12, #16]
	cmp	x14, x15
	b.lo	LBB289_18
; %bb.8:                                ; %bb15.i
                                        ;   in Loop: Header=BB289_3 Depth=1
	b.hi	LBB289_10
; %bb.9:                                ; %bb18.i
                                        ;   in Loop: Header=BB289_3 Depth=1
	ldr	x14, [x13, #24]
	ldr	x15, [x12, #24]
	cmp	x14, x15
	b.ls	LBB289_18
LBB289_10:                              ; %bb8
                                        ;   in Loop: Header=BB289_3 Depth=1
	ldp	q1, q0, [x13]
	ldp	q3, q2, [x12]
	stp	q3, q2, [x13]
	stp	q1, q0, [x12]
	ldr	x15, [x13, #16]
	ldr	x14, [x4]
	cmp	x15, x14
	b.hs	LBB289_14
; %bb.11:                               ; %bb2.i.i.i
                                        ;   in Loop: Header=BB289_3 Depth=1
	ldr	x16, [x13, #24]
	ldr	x13, [x4, #16]
	madd	x13, x15, x9, x13
	ldr	x15, [x13, #96]
	cmp	x15, x16
	b.ne	LBB289_14
; %bb.12:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB289_3 Depth=1
	ldr	x15, [x13]
	cbz	x15, LBB289_14
; %bb.13:                               ; %bb8.i.i.i
                                        ;   in Loop: Header=BB289_3 Depth=1
	str	x1, [x13, #88]
LBB289_14:                              ; %"wf_record_report_position$instance$f8195bc386aec277.exit"
                                        ;   in Loop: Header=BB289_3 Depth=1
	ldr	x13, [x12, #16]
	cmp	x13, x14
	b.hs	LBB289_2
; %bb.15:                               ; %bb2.i.i.i10
                                        ;   in Loop: Header=BB289_3 Depth=1
	ldr	x14, [x12, #24]
	ldr	x12, [x4, #16]
	madd	x12, x13, x9, x12
	ldr	x13, [x12, #96]
	cmp	x13, x14
	b.ne	LBB289_2
; %bb.16:                               ; %bb5.i.i.i18
                                        ;   in Loop: Header=BB289_3 Depth=1
	ldr	x13, [x12]
	cbz	x13, LBB289_2
; %bb.17:                               ; %bb8.i.i.i21
                                        ;   in Loop: Header=BB289_3 Depth=1
	str	x11, [x12, #88]
	b	LBB289_2
LBB289_18:
	add	sp, sp, #32
LBB289_19:                              ; %common.ret
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_slots_new$instance$4c3be85ec06dc167 ; -- Begin function wf_slots_new$instance$4c3be85ec06dc167
	.p2align	2
_wf_slots_new$instance$4c3be85ec06dc167: ; @"wf_slots_new$instance$4c3be85ec06dc167"
; %bb.0:                                ; %entry
	movi.2d	v0, #0000000000000000
	stp	q0, q0, [x0, #64]
	stp	q0, q0, [x0, #32]
	stp	q0, q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$d383295a38079908 ; -- Begin function wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$d383295a38079908
	.p2align	2
_wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$d383295a38079908: ; @"wf_collections.priority_queue.priority_queue_repair_at_indexed$instance$d383295a38079908"
; %bb.0:                                ; %entry
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	cbz	x1, LBB291_2
; %bb.1:                                ; %bb2
	lsl	x8, x1, #4
	ldr	x9, [x0, #16]
	sub	x8, x8, #16
	and	x8, x8, #0xffffffffffffffe0
	add	x8, x9, x8
	add	x9, x9, x1, lsl #5
	ldr	x10, [x8]
	ldr	x11, [x9]
	cmp	x10, x11
	b.hs	LBB291_3
LBB291_2:                               ; %bb1
	bl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$d383295a38079908
	b	LBB291_5
LBB291_3:                               ; %bb3.i
	b.ls	LBB291_6
LBB291_4:                               ; %bb5
	bl	_wf_collections.priority_queue.priority_queue_sift_rise_indexed$instance$d383295a38079908
LBB291_5:                               ; %common.ret
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
LBB291_6:                               ; %bb6.i
	ldr	x10, [x8, #8]
	ldr	x11, [x9, #8]
	cmp	x10, x11
	b.lo	LBB291_2
; %bb.7:                                ; %bb9.i
	b.hi	LBB291_4
; %bb.8:                                ; %bb12.i
	ldr	x10, [x8, #16]
	ldr	x11, [x9, #16]
	cmp	x10, x11
	b.lo	LBB291_2
; %bb.9:                                ; %bb15.i
	b.hi	LBB291_4
; %bb.10:                               ; %bb18.i
	ldr	x8, [x8, #24]
	ldr	x9, [x9, #24]
	cmp	x8, x9
	b.ls	LBB291_2
	b	LBB291_4
                                        ; -- End function
	.globl	_wf_record_swap_payload$instance$e1380248266a9ad2 ; -- Begin function wf_record_swap_payload$instance$e1380248266a9ad2
	.p2align	2
_wf_record_swap_payload$instance$e1380248266a9ad2: ; @"wf_record_swap_payload$instance$e1380248266a9ad2"
; %bb.0:                                ; %entry
	sub	sp, sp, #64
	ldp	q1, q0, [x0, #32]
	ldp	q3, q2, [x0]
	ldur	q4, [x1, #8]
	ldur	q5, [x1, #24]
	stp	q4, q5, [x0]
	ldur	q4, [x1, #40]
	ldur	q5, [x1, #56]
	stp	q4, q5, [x0, #32]
	stur	q3, [x1, #8]
	stur	q2, [x1, #24]
	stur	q1, [x1, #40]
	stur	q0, [x1, #56]
	mov	w0, #0                          ; =0x0
	add	sp, sp, #64
	ret
                                        ; -- End function
	.globl	_wf_record_read_info$instance$e1380248266a9ad2 ; -- Begin function wf_record_read_info$instance$e1380248266a9ad2
	.p2align	2
_wf_record_read_info$instance$e1380248266a9ad2: ; @"wf_record_read_info$instance$e1380248266a9ad2"
; %bb.0:                                ; %entry
	ldr	x0, [x1]
	ldr	x2, [x1, #80]
	ldrb	w8, [x1, #72]
	and	w1, w8, #0x1
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_ignore_position$instance$57d99a800120d980 ; -- Begin function wf_collections.priority_queue.priority_queue_ignore_position$instance$57d99a800120d980
	.p2align	2
_wf_collections.priority_queue.priority_queue_ignore_position$instance$57d99a800120d980: ; @"wf_collections.priority_queue.priority_queue_ignore_position$instance$57d99a800120d980"
; %bb.0:                                ; %entry
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_child$instance$97f85d10896f0873 ; -- Begin function wf_collections.priority_queue.priority_queue_child$instance$97f85d10896f0873
	.p2align	2
_wf_collections.priority_queue.priority_queue_child$instance$97f85d10896f0873: ; @"wf_collections.priority_queue.priority_queue_child$instance$97f85d10896f0873"
; %bb.0:                                ; %entry
	mov	x8, x0
	add	x0, x1, #1
	ldr	x9, [x8]
	cmp	x0, x9
	b.hs	LBB295_3
; %bb.1:                                ; %bb2
	ldr	x9, [x8, #16]
	add	x8, x9, x0, lsl #5
	add	x9, x9, x1, lsl #5
	ldr	x10, [x8]
	ldr	x11, [x9]
	cmp	x10, x11
	b.lo	LBB295_4
; %bb.2:                                ; %bb3.i
	b.ls	LBB295_5
LBB295_3:
	mov	x0, x1
LBB295_4:                               ; %common.ret
	ret
LBB295_5:                               ; %bb6.i
	ldr	x10, [x8, #8]
	ldr	x11, [x9, #8]
	cmp	x10, x11
	b.lo	LBB295_4
; %bb.6:                                ; %bb9.i
	b.hi	LBB295_3
; %bb.7:                                ; %bb12.i
	ldr	x10, [x8, #16]
	ldr	x11, [x9, #16]
	cmp	x10, x11
	b.lo	LBB295_4
; %bb.8:                                ; %bb15.i
	b.hi	LBB295_3
; %bb.9:                                ; %bb18.i
	ldr	x8, [x8, #24]
	ldr	x9, [x9, #24]
	cmp	x8, x9
	csel	x0, x0, x1, lo
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_is_available$instance$44a98dc5bf86badc ; -- Begin function wf_std.collections.hash_map.hash_map_is_available$instance$44a98dc5bf86badc
	.p2align	2
_wf_std.collections.hash_map.hash_map_is_available$instance$44a98dc5bf86badc: ; @"wf_std.collections.hash_map.hash_map_is_available$instance$44a98dc5bf86badc"
; %bb.0:                                ; %entry
	ldr	w8, [x0]
	cmp	w8, #2
	cset	w0, lo
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_child$instance$b1f8c2aa150dd109 ; -- Begin function wf_collections.priority_queue.priority_queue_child$instance$b1f8c2aa150dd109
	.p2align	2
_wf_collections.priority_queue.priority_queue_child$instance$b1f8c2aa150dd109: ; @"wf_collections.priority_queue.priority_queue_child$instance$b1f8c2aa150dd109"
; %bb.0:                                ; %entry
	mov	x8, x0
	add	x0, x1, #1
	ldr	x9, [x8]
	cmp	x0, x9
	b.hs	LBB297_3
; %bb.1:                                ; %bb2
	ldr	x9, [x8, #16]
	add	x8, x9, x0, lsl #5
	add	x9, x9, x1, lsl #5
	ldr	x10, [x8]
	ldr	x11, [x9]
	cmp	x10, x11
	b.lo	LBB297_4
; %bb.2:                                ; %bb3.i
	b.ls	LBB297_5
LBB297_3:
	mov	x0, x1
LBB297_4:                               ; %common.ret
	ret
LBB297_5:                               ; %bb6.i
	ldr	x10, [x8, #8]
	ldr	x11, [x9, #8]
	cmp	x10, x11
	b.lo	LBB297_4
; %bb.6:                                ; %bb9.i
	b.hi	LBB297_3
; %bb.7:                                ; %bb12.i
	ldr	x10, [x8, #16]
	ldr	x11, [x9, #16]
	cmp	x10, x11
	b.lo	LBB297_4
; %bb.8:                                ; %bb15.i
	b.hi	LBB297_3
; %bb.9:                                ; %bb18.i
	ldr	x8, [x8, #24]
	ldr	x9, [x9, #24]
	cmp	x8, x9
	csel	x0, x0, x1, lo
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_child$instance$e332b3dde67982e1 ; -- Begin function wf_collections.priority_queue.priority_queue_child$instance$e332b3dde67982e1
	.p2align	2
_wf_collections.priority_queue.priority_queue_child$instance$e332b3dde67982e1: ; @"wf_collections.priority_queue.priority_queue_child$instance$e332b3dde67982e1"
; %bb.0:                                ; %entry
	mov	x8, x0
	add	x0, x1, #1
	ldr	x9, [x8]
	cmp	x0, x9
	b.hs	LBB298_3
; %bb.1:                                ; %bb2
	ldr	x9, [x8, #16]
	add	x8, x9, x0, lsl #5
	add	x9, x9, x1, lsl #5
	ldr	x10, [x8]
	ldr	x11, [x9]
	cmp	x10, x11
	b.lo	LBB298_4
; %bb.2:                                ; %bb3.i
	b.ls	LBB298_5
LBB298_3:
	mov	x0, x1
LBB298_4:                               ; %common.ret
	ret
LBB298_5:                               ; %bb6.i
	ldr	x10, [x8, #8]
	ldr	x11, [x9, #8]
	cmp	x10, x11
	b.lo	LBB298_4
; %bb.6:                                ; %bb9.i
	b.hi	LBB298_3
; %bb.7:                                ; %bb12.i
	ldr	x10, [x8, #16]
	ldr	x11, [x9, #16]
	cmp	x10, x11
	b.lo	LBB298_4
; %bb.8:                                ; %bb15.i
	b.hi	LBB298_3
; %bb.9:                                ; %bb18.i
	ldr	x8, [x8, #24]
	ldr	x9, [x9, #24]
	cmp	x8, x9
	csel	x0, x0, x1, lo
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$e011e8cc7b7461b9 ; -- Begin function wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$e011e8cc7b7461b9
	.p2align	2
_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$e011e8cc7b7461b9: ; @"wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$e011e8cc7b7461b9"
; %bb.0:                                ; %entry
	lsr	x8, x2, #1
	cmp	x1, x8
	b.hs	LBB299_21
; %bb.1:                                ; %bb5.lr.ph
	sub	sp, sp, #32
	ldr	x9, [x0]
	ldr	x10, [x0, #16]
	b	LBB299_3
LBB299_2:                               ; %bb8
                                        ;   in Loop: Header=BB299_3 Depth=1
	ldp	q1, q0, [x12]
	ldp	q3, q2, [x11]
	stp	q3, q2, [x12]
	stp	q1, q0, [x11]
	cmp	x1, x8
	b.hs	LBB299_20
LBB299_3:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	mov	x11, x1
	lsl	x13, x1, #1
	mov	w12, #1                         ; =0x1
	bfi	x12, x1, #1, #63
	add	x13, x13, #2
	cmp	x13, x9
	b.hs	LBB299_7
; %bb.4:                                ; %bb2.i
                                        ;   in Loop: Header=BB299_3 Depth=1
	add	x14, x10, x13, lsl #5
	add	x15, x10, x12, lsl #5
	ldr	x16, [x14]
	ldr	x17, [x15]
	cmp	x16, x17
	b.hs	LBB299_6
LBB299_5:                               ;   in Loop: Header=BB299_3 Depth=1
	mov	x1, x13
	b	LBB299_8
LBB299_6:                               ; %bb3.i.i
                                        ;   in Loop: Header=BB299_3 Depth=1
	b.ls	LBB299_15
LBB299_7:                               ;   in Loop: Header=BB299_3 Depth=1
	mov	x1, x12
LBB299_8:                               ; %"wf_collections.priority_queue.priority_queue_child$instance$64bc39c2fec80944.exit"
                                        ;   in Loop: Header=BB299_3 Depth=1
	add	x12, x10, x11, lsl #5
	add	x11, x10, x1, lsl #5
	ldr	x13, [x12]
	ldr	x14, [x11]
	cmp	x13, x14
	b.lo	LBB299_20
; %bb.9:                                ; %bb3.i
                                        ;   in Loop: Header=BB299_3 Depth=1
	b.hi	LBB299_2
; %bb.10:                               ; %bb6.i
                                        ;   in Loop: Header=BB299_3 Depth=1
	ldr	x13, [x12, #8]
	ldr	x14, [x11, #8]
	cmp	x13, x14
	b.lo	LBB299_20
; %bb.11:                               ; %bb9.i
                                        ;   in Loop: Header=BB299_3 Depth=1
	b.hi	LBB299_2
; %bb.12:                               ; %bb12.i
                                        ;   in Loop: Header=BB299_3 Depth=1
	ldr	x13, [x12, #16]
	ldr	x14, [x11, #16]
	cmp	x13, x14
	b.lo	LBB299_20
; %bb.13:                               ; %bb15.i
                                        ;   in Loop: Header=BB299_3 Depth=1
	b.hi	LBB299_2
; %bb.14:                               ; %bb18.i
                                        ;   in Loop: Header=BB299_3 Depth=1
	ldr	x13, [x12, #24]
	ldr	x14, [x11, #24]
	cmp	x13, x14
	b.hi	LBB299_2
	b	LBB299_20
LBB299_15:                              ; %bb6.i.i
                                        ;   in Loop: Header=BB299_3 Depth=1
	ldr	x16, [x14, #8]
	ldr	x17, [x15, #8]
	cmp	x16, x17
	b.lo	LBB299_5
; %bb.16:                               ; %bb9.i.i
                                        ;   in Loop: Header=BB299_3 Depth=1
	b.hi	LBB299_7
; %bb.17:                               ; %bb12.i.i
                                        ;   in Loop: Header=BB299_3 Depth=1
	ldr	x16, [x14, #16]
	ldr	x17, [x15, #16]
	mov	x1, x13
	cmp	x16, x17
	b.lo	LBB299_8
; %bb.18:                               ; %bb15.i.i
                                        ;   in Loop: Header=BB299_3 Depth=1
	mov	x1, x12
	b.hi	LBB299_8
; %bb.19:                               ; %bb18.i.i
                                        ;   in Loop: Header=BB299_3 Depth=1
	ldr	x14, [x14, #24]
	ldr	x15, [x15, #24]
	cmp	x14, x15
	csel	x1, x13, x12, lo
	b	LBB299_8
LBB299_20:
	add	sp, sp, #32
LBB299_21:                              ; %common.ret
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_std.collections.hash_map.hash_map_migrate_owner$instance$cb1167c8d0732e77 ; -- Begin function wf_std.collections.hash_map.hash_map_migrate_owner$instance$cb1167c8d0732e77
	.p2align	2
_wf_std.collections.hash_map.hash_map_migrate_owner$instance$cb1167c8d0732e77: ; @"wf_std.collections.hash_map.hash_map_migrate_owner$instance$cb1167c8d0732e77"
; %bb.0:                                ; %entry
	ldr	q0, [x2]
	ldr	x8, [x3]
	ldr	x9, [x0]
	ldr	x10, [x0, #16]
	udiv	x11, x1, x8
	msub	x11, x11, x8, x1
LBB300_1:                               ; %bb1
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB300_5 Depth 2
	cbz	x8, LBB300_3
; %bb.2:                                ; %bb3.i
                                        ;   in Loop: Header=BB300_1 Depth=1
	mov	x13, x11
	cbnz	x9, LBB300_4
	b	LBB300_1
LBB300_3:                               ;   in Loop: Header=BB300_1 Depth=1
	mov	x13, #0                         ; =0x0
	cbz	x9, LBB300_1
LBB300_4:                               ; %bb3.lr.ph
                                        ;   in Loop: Header=BB300_1 Depth=1
	mov	x12, #0                         ; =0x0
	udiv	x14, x13, x9
	msub	x13, x14, x9, x13
	sub	x14, x9, x13
	neg	x15, x14
LBB300_5:                               ; %bb3
                                        ;   Parent Loop BB300_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x12, x14
	csel	x16, x13, x15, lo
	add	x16, x16, x12
	lsl	x17, x16, #5
	ldr	w17, [x10, x17]
	cmp	w17, #1
	b.ls	LBB300_7
; %bb.6:                                ; %bb2
                                        ;   in Loop: Header=BB300_5 Depth=2
	add	x12, x12, #1
	cmp	x9, x12
	b.ne	LBB300_5
	b	LBB300_1
LBB300_7:                               ; %common.ret
	add	x8, x10, x16, lsl #5
	mov	w9, #2                          ; =0x2
	str	w9, [x8]
	str	x1, [x8, #8]
	str	q0, [x8, #16]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_reserve$instance$8d53fd32336043f5 ; -- Begin function wf_collections.priority_queue.priority_queue_reserve$instance$8d53fd32336043f5
	.p2align	2
_wf_collections.priority_queue.priority_queue_reserve$instance$8d53fd32336043f5: ; @"wf_collections.priority_queue.priority_queue_reserve$instance$8d53fd32336043f5"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	ldr	x22, [x0, #8]
	cmp	x22, x1
	b.hs	LBB301_5
; %bb.1:                                ; %bb3
	mov	x19, x1
	mov	x20, x0
	ldr	x23, [x0]
	ldr	x21, [x0, #16]
	lsl	x1, x1, #5
	cmp	x22, #0
	ccmp	x23, x22, #0, ne
	b.eq	LBB301_6
; %bb.2:                                ; %window.grow.copy.v2.i
	mov	x0, x1
	bl	_malloc
	cbz	x0, LBB301_9
; %bb.3:                                ; %window.grow.copy.ready.v2.i
	cbz	x22, LBB301_7
; %bb.4:                                ; %window.grow.copy.old.v2.i
	lsl	x2, x23, #5
	mov	x22, x0
	mov	x1, x21
	bl	_memcpy
	mov	x0, x21
	bl	_free
	mov	x0, x22
	b	LBB301_7
LBB301_5:
	mov	x19, x22
	b	LBB301_8
LBB301_6:                               ; %window.grow.reallocate.v2.i
	mov	x0, x21
	bl	_realloc
	cbz	x0, LBB301_9
LBB301_7:                               ; %"wf_grow$instance$57d99a800120d980.exit"
	stp	x19, x0, [x20, #8]
LBB301_8:                               ; %common.ret
	mov	x0, x19
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB301_9:                               ; %window.block.oom.v2.i
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$f0ce656cb92d5494 ; -- Begin function wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$f0ce656cb92d5494
	.p2align	2
_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$f0ce656cb92d5494: ; @"wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$f0ce656cb92d5494"
; %bb.0:                                ; %entry
	lsr	x8, x2, #1
	cmp	x1, x8
	b.hs	LBB302_29
; %bb.1:                                ; %bb5.lr.ph
	sub	sp, sp, #32
	ldr	x9, [x0]
	ldr	x10, [x0, #16]
	mov	w11, #56                        ; =0x38
	b	LBB302_3
LBB302_2:                               ; %"wf_record_report_position$instance$3ad8b32886f5e3ce.exit24"
                                        ;   in Loop: Header=BB302_3 Depth=1
	cmp	x1, x8
	b.hs	LBB302_28
LBB302_3:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	mov	x12, x1
	lsl	x14, x1, #1
	mov	w13, #1                         ; =0x1
	bfi	x13, x1, #1, #63
	add	x14, x14, #2
	cmp	x14, x9
	b.hs	LBB302_7
; %bb.4:                                ; %bb2.i
                                        ;   in Loop: Header=BB302_3 Depth=1
	add	x15, x10, x14, lsl #5
	add	x16, x10, x13, lsl #5
	ldr	x17, [x15]
	ldr	x0, [x16]
	cmp	x17, x0
	b.hs	LBB302_6
LBB302_5:                               ;   in Loop: Header=BB302_3 Depth=1
	mov	x1, x14
	b	LBB302_8
LBB302_6:                               ; %bb3.i.i
                                        ;   in Loop: Header=BB302_3 Depth=1
	b.ls	LBB302_23
LBB302_7:                               ;   in Loop: Header=BB302_3 Depth=1
	mov	x1, x13
LBB302_8:                               ; %"wf_collections.priority_queue.priority_queue_child$instance$64bc39c2fec80944.exit"
                                        ;   in Loop: Header=BB302_3 Depth=1
	add	x14, x10, x12, lsl #5
	add	x13, x10, x1, lsl #5
	ldr	x15, [x14]
	ldr	x16, [x13]
	cmp	x15, x16
	b.lo	LBB302_28
; %bb.9:                                ; %bb3.i
                                        ;   in Loop: Header=BB302_3 Depth=1
	b.hi	LBB302_15
; %bb.10:                               ; %bb6.i
                                        ;   in Loop: Header=BB302_3 Depth=1
	ldr	x15, [x14, #8]
	ldr	x16, [x13, #8]
	cmp	x15, x16
	b.lo	LBB302_28
; %bb.11:                               ; %bb9.i
                                        ;   in Loop: Header=BB302_3 Depth=1
	b.hi	LBB302_15
; %bb.12:                               ; %bb12.i
                                        ;   in Loop: Header=BB302_3 Depth=1
	ldr	x15, [x14, #16]
	ldr	x16, [x13, #16]
	cmp	x15, x16
	b.lo	LBB302_28
; %bb.13:                               ; %bb15.i
                                        ;   in Loop: Header=BB302_3 Depth=1
	b.hi	LBB302_15
; %bb.14:                               ; %bb18.i
                                        ;   in Loop: Header=BB302_3 Depth=1
	ldr	x15, [x14, #24]
	ldr	x16, [x13, #24]
	cmp	x15, x16
	b.ls	LBB302_28
LBB302_15:                              ; %bb8
                                        ;   in Loop: Header=BB302_3 Depth=1
	ldp	q1, q0, [x14]
	ldp	q3, q2, [x13]
	stp	q3, q2, [x14]
	stp	q1, q0, [x13]
	ldr	x16, [x14, #16]
	ldr	x15, [x4]
	cmp	x16, x15
	b.hs	LBB302_19
; %bb.16:                               ; %bb2.i.i.i
                                        ;   in Loop: Header=BB302_3 Depth=1
	ldr	x17, [x14, #24]
	ldr	x14, [x4, #16]
	madd	x14, x16, x11, x14
	ldr	x16, [x14, #40]
	cmp	x16, x17
	b.ne	LBB302_19
; %bb.17:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB302_3 Depth=1
	ldr	x16, [x14]
	cbz	x16, LBB302_19
; %bb.18:                               ; %bb8.i.i.i
                                        ;   in Loop: Header=BB302_3 Depth=1
	str	x12, [x14, #32]
LBB302_19:                              ; %"wf_record_report_position$instance$3ad8b32886f5e3ce.exit"
                                        ;   in Loop: Header=BB302_3 Depth=1
	ldr	x12, [x13, #16]
	cmp	x12, x15
	b.hs	LBB302_2
; %bb.20:                               ; %bb2.i.i.i11
                                        ;   in Loop: Header=BB302_3 Depth=1
	ldr	x13, [x13, #24]
	ldr	x14, [x4, #16]
	madd	x12, x12, x11, x14
	ldr	x14, [x12, #40]
	cmp	x14, x13
	b.ne	LBB302_2
; %bb.21:                               ; %bb5.i.i.i19
                                        ;   in Loop: Header=BB302_3 Depth=1
	ldr	x13, [x12]
	cbz	x13, LBB302_2
; %bb.22:                               ; %bb8.i.i.i22
                                        ;   in Loop: Header=BB302_3 Depth=1
	str	x1, [x12, #32]
	b	LBB302_2
LBB302_23:                              ; %bb6.i.i
                                        ;   in Loop: Header=BB302_3 Depth=1
	ldr	x17, [x15, #8]
	ldr	x0, [x16, #8]
	cmp	x17, x0
	b.lo	LBB302_5
; %bb.24:                               ; %bb9.i.i
                                        ;   in Loop: Header=BB302_3 Depth=1
	b.hi	LBB302_7
; %bb.25:                               ; %bb12.i.i
                                        ;   in Loop: Header=BB302_3 Depth=1
	ldr	x17, [x15, #16]
	ldr	x0, [x16, #16]
	mov	x1, x14
	cmp	x17, x0
	b.lo	LBB302_8
; %bb.26:                               ; %bb15.i.i
                                        ;   in Loop: Header=BB302_3 Depth=1
	mov	x1, x13
	b.hi	LBB302_8
; %bb.27:                               ; %bb18.i.i
                                        ;   in Loop: Header=BB302_3 Depth=1
	ldr	x15, [x15, #24]
	ldr	x16, [x16, #24]
	cmp	x15, x16
	csel	x1, x14, x13, lo
	b	LBB302_8
LBB302_28:
	add	sp, sp, #32
LBB302_29:                              ; %common.ret
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$d383295a38079908 ; -- Begin function wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$d383295a38079908
	.p2align	2
_wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$d383295a38079908: ; @"wf_collections.priority_queue.priority_queue_sift_sink_indexed$instance$d383295a38079908"
; %bb.0:                                ; %entry
	lsr	x8, x2, #1
	cmp	x1, x8
	b.hs	LBB303_29
; %bb.1:                                ; %bb5.lr.ph
	sub	sp, sp, #32
	ldr	x9, [x0]
	ldr	x10, [x0, #16]
	mov	w11, #112                       ; =0x70
	b	LBB303_3
LBB303_2:                               ; %"wf_record_report_position$instance$f8195bc386aec277.exit24"
                                        ;   in Loop: Header=BB303_3 Depth=1
	cmp	x1, x8
	b.hs	LBB303_28
LBB303_3:                               ; %bb5
                                        ; =>This Inner Loop Header: Depth=1
	mov	x12, x1
	lsl	x14, x1, #1
	mov	w13, #1                         ; =0x1
	bfi	x13, x1, #1, #63
	add	x14, x14, #2
	cmp	x14, x9
	b.hs	LBB303_7
; %bb.4:                                ; %bb2.i
                                        ;   in Loop: Header=BB303_3 Depth=1
	add	x15, x10, x14, lsl #5
	add	x16, x10, x13, lsl #5
	ldr	x17, [x15]
	ldr	x0, [x16]
	cmp	x17, x0
	b.hs	LBB303_6
LBB303_5:                               ;   in Loop: Header=BB303_3 Depth=1
	mov	x1, x14
	b	LBB303_8
LBB303_6:                               ; %bb3.i.i
                                        ;   in Loop: Header=BB303_3 Depth=1
	b.ls	LBB303_23
LBB303_7:                               ;   in Loop: Header=BB303_3 Depth=1
	mov	x1, x13
LBB303_8:                               ; %"wf_collections.priority_queue.priority_queue_child$instance$64bc39c2fec80944.exit"
                                        ;   in Loop: Header=BB303_3 Depth=1
	add	x14, x10, x12, lsl #5
	add	x13, x10, x1, lsl #5
	ldr	x15, [x14]
	ldr	x16, [x13]
	cmp	x15, x16
	b.lo	LBB303_28
; %bb.9:                                ; %bb3.i
                                        ;   in Loop: Header=BB303_3 Depth=1
	b.hi	LBB303_15
; %bb.10:                               ; %bb6.i
                                        ;   in Loop: Header=BB303_3 Depth=1
	ldr	x15, [x14, #8]
	ldr	x16, [x13, #8]
	cmp	x15, x16
	b.lo	LBB303_28
; %bb.11:                               ; %bb9.i
                                        ;   in Loop: Header=BB303_3 Depth=1
	b.hi	LBB303_15
; %bb.12:                               ; %bb12.i
                                        ;   in Loop: Header=BB303_3 Depth=1
	ldr	x15, [x14, #16]
	ldr	x16, [x13, #16]
	cmp	x15, x16
	b.lo	LBB303_28
; %bb.13:                               ; %bb15.i
                                        ;   in Loop: Header=BB303_3 Depth=1
	b.hi	LBB303_15
; %bb.14:                               ; %bb18.i
                                        ;   in Loop: Header=BB303_3 Depth=1
	ldr	x15, [x14, #24]
	ldr	x16, [x13, #24]
	cmp	x15, x16
	b.ls	LBB303_28
LBB303_15:                              ; %bb8
                                        ;   in Loop: Header=BB303_3 Depth=1
	ldp	q1, q0, [x14]
	ldp	q3, q2, [x13]
	stp	q3, q2, [x14]
	stp	q1, q0, [x13]
	ldr	x16, [x14, #16]
	ldr	x15, [x4]
	cmp	x16, x15
	b.hs	LBB303_19
; %bb.16:                               ; %bb2.i.i.i
                                        ;   in Loop: Header=BB303_3 Depth=1
	ldr	x17, [x14, #24]
	ldr	x14, [x4, #16]
	madd	x14, x16, x11, x14
	ldr	x16, [x14, #96]
	cmp	x16, x17
	b.ne	LBB303_19
; %bb.17:                               ; %bb5.i.i.i
                                        ;   in Loop: Header=BB303_3 Depth=1
	ldr	x16, [x14]
	cbz	x16, LBB303_19
; %bb.18:                               ; %bb8.i.i.i
                                        ;   in Loop: Header=BB303_3 Depth=1
	str	x12, [x14, #88]
LBB303_19:                              ; %"wf_record_report_position$instance$f8195bc386aec277.exit"
                                        ;   in Loop: Header=BB303_3 Depth=1
	ldr	x12, [x13, #16]
	cmp	x12, x15
	b.hs	LBB303_2
; %bb.20:                               ; %bb2.i.i.i11
                                        ;   in Loop: Header=BB303_3 Depth=1
	ldr	x13, [x13, #24]
	ldr	x14, [x4, #16]
	madd	x12, x12, x11, x14
	ldr	x14, [x12, #96]
	cmp	x14, x13
	b.ne	LBB303_2
; %bb.21:                               ; %bb5.i.i.i19
                                        ;   in Loop: Header=BB303_3 Depth=1
	ldr	x13, [x12]
	cbz	x13, LBB303_2
; %bb.22:                               ; %bb8.i.i.i22
                                        ;   in Loop: Header=BB303_3 Depth=1
	str	x1, [x12, #88]
	b	LBB303_2
LBB303_23:                              ; %bb6.i.i
                                        ;   in Loop: Header=BB303_3 Depth=1
	ldr	x17, [x15, #8]
	ldr	x0, [x16, #8]
	cmp	x17, x0
	b.lo	LBB303_5
; %bb.24:                               ; %bb9.i.i
                                        ;   in Loop: Header=BB303_3 Depth=1
	b.hi	LBB303_7
; %bb.25:                               ; %bb12.i.i
                                        ;   in Loop: Header=BB303_3 Depth=1
	ldr	x17, [x15, #16]
	ldr	x0, [x16, #16]
	mov	x1, x14
	cmp	x17, x0
	b.lo	LBB303_8
; %bb.26:                               ; %bb15.i.i
                                        ;   in Loop: Header=BB303_3 Depth=1
	mov	x1, x13
	b.hi	LBB303_8
; %bb.27:                               ; %bb18.i.i
                                        ;   in Loop: Header=BB303_3 Depth=1
	ldr	x15, [x15, #24]
	ldr	x16, [x16, #24]
	cmp	x15, x16
	csel	x1, x14, x13, lo
	b	LBB303_8
LBB303_28:
	add	sp, sp, #32
LBB303_29:                              ; %common.ret
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_collections.priority_queue.priority_queue_child$instance$64bc39c2fec80944 ; -- Begin function wf_collections.priority_queue.priority_queue_child$instance$64bc39c2fec80944
	.p2align	2
_wf_collections.priority_queue.priority_queue_child$instance$64bc39c2fec80944: ; @"wf_collections.priority_queue.priority_queue_child$instance$64bc39c2fec80944"
; %bb.0:                                ; %entry
	mov	x8, x0
	add	x0, x1, #1
	ldr	x9, [x8]
	cmp	x0, x9
	b.hs	LBB304_3
; %bb.1:                                ; %bb2
	ldr	x9, [x8, #16]
	add	x8, x9, x0, lsl #5
	add	x9, x9, x1, lsl #5
	ldr	x10, [x8]
	ldr	x11, [x9]
	cmp	x10, x11
	b.lo	LBB304_4
; %bb.2:                                ; %bb3.i
	b.ls	LBB304_5
LBB304_3:
	mov	x0, x1
LBB304_4:                               ; %common.ret
	ret
LBB304_5:                               ; %bb6.i
	ldr	x10, [x8, #8]
	ldr	x11, [x9, #8]
	cmp	x10, x11
	b.lo	LBB304_4
; %bb.6:                                ; %bb9.i
	b.hi	LBB304_3
; %bb.7:                                ; %bb12.i
	ldr	x10, [x8, #16]
	ldr	x11, [x9, #16]
	cmp	x10, x11
	b.lo	LBB304_4
; %bb.8:                                ; %bb15.i
	b.hi	LBB304_3
; %bb.9:                                ; %bb18.i
	ldr	x8, [x8, #24]
	ldr	x9, [x9, #24]
	cmp	x8, x9
	csel	x0, x0, x1, lo
	ret
                                        ; -- End function
	.globl	_wf_place_back$instance$bf04aef0a4b06aa4 ; -- Begin function wf_place_back$instance$bf04aef0a4b06aa4
	.p2align	2
_wf_place_back$instance$bf04aef0a4b06aa4: ; @"wf_place_back$instance$bf04aef0a4b06aa4"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x9, [x0, #16]
	add	x9, x9, x8, lsl #5
	ldp	q1, q0, [x1]
	stp	q1, q0, [x9]
	add	x8, x8, #1
	str	x8, [x0]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_swap$instance$e1380248266a9ad2 ; -- Begin function wf_swap$instance$e1380248266a9ad2
	.p2align	2
_wf_swap$instance$e1380248266a9ad2:     ; @"wf_swap$instance$e1380248266a9ad2"
; %bb.0:                                ; %entry
	ldp	q0, q1, [x0]
	stp	q0, q1, [sp, #-64]!
	ldp	q0, q1, [x0, #32]
	stp	q0, q1, [sp, #32]
	ldp	q0, q1, [x1, #32]
	ldp	q3, q2, [x1]
	stp	q0, q1, [x0, #32]
	stp	q3, q2, [x0]
	ldp	q0, q1, [sp]
	stp	q0, q1, [x1]
	ldp	q0, q1, [sp, #32]
	stp	q0, q1, [x1, #32]
	mov	w0, #0                          ; =0x0
	add	sp, sp, #64
	ret
                                        ; -- End function
	.globl	_wf_take_back$instance$bf04aef0a4b06aa4 ; -- Begin function wf_take_back$instance$bf04aef0a4b06aa4
	.p2align	2
_wf_take_back$instance$bf04aef0a4b06aa4: ; @"wf_take_back$instance$bf04aef0a4b06aa4"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	sub	x8, x8, #1
	ldr	x9, [x1, #16]
	add	x9, x9, x8, lsl #5
	str	x8, [x1]
	ldp	q1, q0, [x9]
	stp	q1, q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_swap$instance$57d99a800120d980 ; -- Begin function wf_swap$instance$57d99a800120d980
	.p2align	2
_wf_swap$instance$57d99a800120d980:     ; @"wf_swap$instance$57d99a800120d980"
; %bb.0:                                ; %entry
	ldp	q0, q1, [x0]
	stp	q0, q1, [sp, #-32]!
	ldp	q3, q2, [x1]
	stp	q3, q2, [x0]
	stp	q0, q1, [x1]
	mov	w0, #0                          ; =0x0
	add	sp, sp, #32
	ret
                                        ; -- End function
	.globl	_wf_free_empty$instance$401ab120abe5d512 ; -- Begin function wf_free_empty$instance$401ab120abe5d512
	.p2align	2
_wf_free_empty$instance$401ab120abe5d512: ; @"wf_free_empty$instance$401ab120abe5d512"
; %bb.0:                                ; %entry
	ldr	x8, [x0, #8]
	cbz	x8, LBB309_2
; %bb.1:                                ; %slots.release.drop.6
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #16]
	bl	_free
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB309_2:                               ; %slots.release.done.drop.6
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_place_back$instance$2e729d0eeec27dcf ; -- Begin function wf_place_back$instance$2e729d0eeec27dcf
	.p2align	2
_wf_place_back$instance$2e729d0eeec27dcf: ; @"wf_place_back$instance$2e729d0eeec27dcf"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	add	x9, x0, x8, lsl #6
	ldp	q0, q1, [x1]
	stur	q0, [x9, #8]
	stur	q1, [x9, #24]
	ldp	q0, q1, [x1, #32]
	stur	q0, [x9, #40]
	stur	q1, [x9, #56]
	add	x8, x8, #1
	str	x8, [x0]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_place_back$instance$8d1e2a12c64c8b0b ; -- Begin function wf_place_back$instance$8d1e2a12c64c8b0b
	.p2align	2
_wf_place_back$instance$8d1e2a12c64c8b0b: ; @"wf_place_back$instance$8d1e2a12c64c8b0b"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x9, [x0, #16]
	mov	w10, #88                        ; =0x58
	madd	x9, x8, x10, x9
	ldp	q0, q1, [x1, #32]
	ldr	q2, [x1, #64]
	ldr	x10, [x1, #80]
	ldp	q4, q3, [x1]
	str	x10, [x9, #80]
	stp	q1, q2, [x9, #48]
	stp	q3, q0, [x9, #16]
	str	q4, [x9]
	add	x8, x8, #1
	str	x8, [x0]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_take_back$instance$2e729d0eeec27dcf ; -- Begin function wf_take_back$instance$2e729d0eeec27dcf
	.p2align	2
_wf_take_back$instance$2e729d0eeec27dcf: ; @"wf_take_back$instance$2e729d0eeec27dcf"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	sub	x8, x8, #1
	add	x9, x1, x8, lsl #6
	str	x8, [x1]
	ldur	q0, [x9, #8]
	ldur	q1, [x9, #24]
	stp	q0, q1, [x0]
	ldur	q0, [x9, #40]
	ldur	q1, [x9, #56]
	stp	q0, q1, [x0, #32]
	ret
                                        ; -- End function
	.globl	_wf_take_back$instance$8d1e2a12c64c8b0b ; -- Begin function wf_take_back$instance$8d1e2a12c64c8b0b
	.p2align	2
_wf_take_back$instance$8d1e2a12c64c8b0b: ; @"wf_take_back$instance$8d1e2a12c64c8b0b"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	sub	x8, x8, #1
	ldr	x9, [x1, #16]
	mov	w10, #88                        ; =0x58
	madd	x9, x8, x10, x9
	str	x8, [x1]
	ldp	q0, q1, [x9, #32]
	ldr	q2, [x9, #64]
	ldr	x8, [x9, #80]
	ldp	q4, q3, [x9]
	str	x8, [x0, #80]
	stp	q1, q2, [x0, #48]
	stp	q3, q0, [x0, #16]
	str	q4, [x0]
	ret
                                        ; -- End function
	.globl	_wf_free_empty$instance$6305538b6068bf92 ; -- Begin function wf_free_empty$instance$6305538b6068bf92
	.p2align	2
_wf_free_empty$instance$6305538b6068bf92: ; @"wf_free_empty$instance$6305538b6068bf92"
; %bb.0:                                ; %entry
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_free_empty$instance$81a0b1ff5783c983 ; -- Begin function wf_free_empty$instance$81a0b1ff5783c983
	.p2align	2
_wf_free_empty$instance$81a0b1ff5783c983: ; @"wf_free_empty$instance$81a0b1ff5783c983"
; %bb.0:                                ; %entry
	ldr	x8, [x0, #8]
	cbz	x8, LBB315_2
; %bb.1:                                ; %slots.release.drop.6
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #16]
	bl	_free
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB315_2:                               ; %slots.release.done.drop.6
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_take_back$instance$256a4690cb6caad8 ; -- Begin function wf_take_back$instance$256a4690cb6caad8
	.p2align	2
_wf_take_back$instance$256a4690cb6caad8: ; @"wf_take_back$instance$256a4690cb6caad8"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	sub	x8, x8, #1
	add	x9, x1, x8, lsl #5
	str	x8, [x1]
	ldur	q0, [x9, #8]
	ldur	q1, [x9, #24]
	stp	q0, q1, [x0]
	ret
                                        ; -- End function
	.globl	_wf_swap$instance$29b61f0cf25c44c5 ; -- Begin function wf_swap$instance$29b61f0cf25c44c5
	.p2align	2
_wf_swap$instance$29b61f0cf25c44c5:     ; @"wf_swap$instance$29b61f0cf25c44c5"
; %bb.0:                                ; %entry
	ldp	q0, q1, [x0]
	stp	q0, q1, [sp, #-32]!
	ldp	q3, q2, [x1]
	stp	q3, q2, [x0]
	stp	q0, q1, [x1]
	mov	w0, #0                          ; =0x0
	add	sp, sp, #32
	ret
                                        ; -- End function
	.globl	_wf_take_back$instance$2ebb51ac7e7440ad ; -- Begin function wf_take_back$instance$2ebb51ac7e7440ad
	.p2align	2
_wf_take_back$instance$2ebb51ac7e7440ad: ; @"wf_take_back$instance$2ebb51ac7e7440ad"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	sub	x8, x8, #1
	ldr	x9, [x1, #16]
	add	x9, x9, x8, lsl #5
	str	x8, [x1]
	ldp	q1, q0, [x9]
	stp	q1, q0, [x0]
	ret
                                        ; -- End function
	.globl	_wf_free_empty$instance$16f094be4fd843b6 ; -- Begin function wf_free_empty$instance$16f094be4fd843b6
	.p2align	2
_wf_free_empty$instance$16f094be4fd843b6: ; @"wf_free_empty$instance$16f094be4fd843b6"
; %bb.0:                                ; %entry
	ldr	x8, [x0, #8]
	cbz	x8, LBB319_2
; %bb.1:                                ; %slots.release.drop.6
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #16]
	bl	_free
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB319_2:                               ; %slots.release.done.drop.6
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_take_back$instance$26ef77557da29f1f ; -- Begin function wf_take_back$instance$26ef77557da29f1f
	.p2align	2
_wf_take_back$instance$26ef77557da29f1f: ; @"wf_take_back$instance$26ef77557da29f1f"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	sub	x8, x8, #1
	ldr	x9, [x1, #16]
	mov	w10, #56                        ; =0x38
	madd	x9, x8, x10, x9
	str	x8, [x1]
	ldp	q1, q0, [x9, #16]
	ldr	x8, [x9, #48]
	ldr	q2, [x9]
	str	x8, [x0, #48]
	stp	q1, q0, [x0, #16]
	str	q2, [x0]
	ret
                                        ; -- End function
	.globl	_wf_free_empty$instance$961b6cafed4929d8 ; -- Begin function wf_free_empty$instance$961b6cafed4929d8
	.p2align	2
_wf_free_empty$instance$961b6cafed4929d8: ; @"wf_free_empty$instance$961b6cafed4929d8"
; %bb.0:                                ; %entry
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_free_empty$instance$e22bd0c72870f88b ; -- Begin function wf_free_empty$instance$e22bd0c72870f88b
	.p2align	2
_wf_free_empty$instance$e22bd0c72870f88b: ; @"wf_free_empty$instance$e22bd0c72870f88b"
; %bb.0:                                ; %entry
	ldr	x8, [x0, #8]
	cbz	x8, LBB322_2
; %bb.1:                                ; %slots.release.drop.6
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #16]
	bl	_free
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB322_2:                               ; %slots.release.done.drop.6
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_place_back$instance$256a4690cb6caad8 ; -- Begin function wf_place_back$instance$256a4690cb6caad8
	.p2align	2
_wf_place_back$instance$256a4690cb6caad8: ; @"wf_place_back$instance$256a4690cb6caad8"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	add	x9, x0, x8, lsl #5
	ldp	q0, q1, [x1]
	stur	q0, [x9, #8]
	stur	q1, [x9, #24]
	add	x8, x8, #1
	str	x8, [x0]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_place_back$instance$26ef77557da29f1f ; -- Begin function wf_place_back$instance$26ef77557da29f1f
	.p2align	2
_wf_place_back$instance$26ef77557da29f1f: ; @"wf_place_back$instance$26ef77557da29f1f"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x9, [x0, #16]
	mov	w10, #56                        ; =0x38
	madd	x9, x8, x10, x9
	ldp	q1, q0, [x1, #16]
	ldr	x10, [x1, #48]
	ldr	q2, [x1]
	str	x10, [x9, #48]
	stp	q1, q0, [x9, #16]
	str	q2, [x9]
	add	x8, x8, #1
	str	x8, [x0]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_grow$instance$29b61f0cf25c44c5 ; -- Begin function wf_grow$instance$29b61f0cf25c44c5
	.p2align	2
_wf_grow$instance$29b61f0cf25c44c5:     ; @"wf_grow$instance$29b61f0cf25c44c5"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x1
	mov	x20, x0
	ldr	x21, [x0, #16]
	cbz	x1, LBB325_5
; %bb.1:                                ; %window.grow.positive.v2
	lsl	x1, x19, #5
	ldp	x22, x23, [x20]
	cmp	x22, x23
	ccmp	x23, #0, #4, eq
	b.ne	LBB325_6
; %bb.2:                                ; %window.grow.copy.v2
	mov	x0, x1
	bl	_malloc
	cbz	x0, LBB325_8
; %bb.3:                                ; %window.grow.copy.ready.v2
	cbz	x23, LBB325_7
; %bb.4:                                ; %window.grow.copy.old.v2
	lsl	x2, x22, #5
	mov	x22, x0
	mov	x1, x21
	bl	_memcpy
	mov	x0, x21
	bl	_free
	mov	x0, x22
	b	LBB325_7
LBB325_5:
	mov	x0, x21
	b	LBB325_7
LBB325_6:                               ; %window.grow.reallocate.v2
	mov	x0, x21
	bl	_realloc
	cbz	x0, LBB325_8
LBB325_7:                               ; %window.block.ready.v2
	stp	x19, x0, [x20, #8]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB325_8:                               ; %window.block.oom.v2
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_place_back$instance$2ebb51ac7e7440ad ; -- Begin function wf_place_back$instance$2ebb51ac7e7440ad
	.p2align	2
_wf_place_back$instance$2ebb51ac7e7440ad: ; @"wf_place_back$instance$2ebb51ac7e7440ad"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x9, [x0, #16]
	add	x9, x9, x8, lsl #5
	ldp	q1, q0, [x1]
	stp	q1, q0, [x9]
	add	x8, x8, #1
	str	x8, [x0]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_swap$instance$16f094be4fd843b6 ; -- Begin function wf_swap$instance$16f094be4fd843b6
	.p2align	2
_wf_swap$instance$16f094be4fd843b6:     ; @"wf_swap$instance$16f094be4fd843b6"
; %bb.0:                                ; %entry
	ldr	q0, [x0]
	str	q0, [sp, #-32]!
	ldr	x8, [x0, #16]
	str	x8, [sp, #16]
	ldr	x9, [x1, #16]
	ldr	q1, [x1]
	str	q1, [x0]
	str	x9, [x0, #16]
	str	q0, [x1]
	str	x8, [x1, #16]
	mov	w0, #0                          ; =0x0
	add	sp, sp, #32
	ret
                                        ; -- End function
	.globl	_wf_place_back$instance$3bdccace7b2f8cd6 ; -- Begin function wf_place_back$instance$3bdccace7b2f8cd6
	.p2align	2
_wf_place_back$instance$3bdccace7b2f8cd6: ; @"wf_place_back$instance$3bdccace7b2f8cd6"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	add	x9, x0, x8, lsl #5
	ldp	q0, q1, [x1]
	stur	q0, [x9, #8]
	stur	q1, [x9, #24]
	add	x8, x8, #1
	str	x8, [x0]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_place_back$instance$dfab5d0bd37dbcad ; -- Begin function wf_place_back$instance$dfab5d0bd37dbcad
	.p2align	2
_wf_place_back$instance$dfab5d0bd37dbcad: ; @"wf_place_back$instance$dfab5d0bd37dbcad"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x9, [x0, #16]
	mov	w10, #56                        ; =0x38
	madd	x9, x8, x10, x9
	ldp	q1, q0, [x1, #16]
	ldr	x10, [x1, #48]
	ldr	q2, [x1]
	str	x10, [x9, #48]
	stp	q1, q0, [x9, #16]
	str	q2, [x9]
	add	x8, x8, #1
	str	x8, [x0]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_take_back$instance$3bdccace7b2f8cd6 ; -- Begin function wf_take_back$instance$3bdccace7b2f8cd6
	.p2align	2
_wf_take_back$instance$3bdccace7b2f8cd6: ; @"wf_take_back$instance$3bdccace7b2f8cd6"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	sub	x8, x8, #1
	add	x9, x1, x8, lsl #5
	str	x8, [x1]
	ldur	q0, [x9, #8]
	ldur	q1, [x9, #24]
	stp	q0, q1, [x0]
	ret
                                        ; -- End function
	.globl	_wf_take_back$instance$dfab5d0bd37dbcad ; -- Begin function wf_take_back$instance$dfab5d0bd37dbcad
	.p2align	2
_wf_take_back$instance$dfab5d0bd37dbcad: ; @"wf_take_back$instance$dfab5d0bd37dbcad"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	sub	x8, x8, #1
	ldr	x9, [x1, #16]
	mov	w10, #56                        ; =0x38
	madd	x9, x8, x10, x9
	str	x8, [x1]
	ldp	q1, q0, [x9, #16]
	ldr	x8, [x9, #48]
	ldr	q2, [x9]
	str	x8, [x0, #48]
	stp	q1, q0, [x0, #16]
	str	q2, [x0]
	ret
                                        ; -- End function
	.globl	_wf_free_empty$instance$d1936424d55979a1 ; -- Begin function wf_free_empty$instance$d1936424d55979a1
	.p2align	2
_wf_free_empty$instance$d1936424d55979a1: ; @"wf_free_empty$instance$d1936424d55979a1"
; %bb.0:                                ; %entry
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_free_empty$instance$5d2b3ddf4f1338b1 ; -- Begin function wf_free_empty$instance$5d2b3ddf4f1338b1
	.p2align	2
_wf_free_empty$instance$5d2b3ddf4f1338b1: ; @"wf_free_empty$instance$5d2b3ddf4f1338b1"
; %bb.0:                                ; %entry
	ldr	x8, [x0, #8]
	cbz	x8, LBB333_2
; %bb.1:                                ; %slots.release.drop.6
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #16]
	bl	_free
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB333_2:                               ; %slots.release.done.drop.6
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_place_back$instance$90ab86c4509859d9 ; -- Begin function wf_place_back$instance$90ab86c4509859d9
	.p2align	2
_wf_place_back$instance$90ab86c4509859d9: ; @"wf_place_back$instance$90ab86c4509859d9"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	mov	w9, #88                         ; =0x58
	madd	x9, x8, x9, x0
	ldp	q0, q1, [x1, #32]
	stur	q0, [x9, #40]
	stur	q1, [x9, #56]
	ldr	q0, [x1, #64]
	stur	q0, [x9, #72]
	ldp	q0, q1, [x1]
	stur	q0, [x9, #8]
	ldr	x10, [x1, #80]
	str	x10, [x9, #88]
	stur	q1, [x9, #24]
	add	x8, x8, #1
	str	x8, [x0]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_place_back$instance$e90f5d30d57d8951 ; -- Begin function wf_place_back$instance$e90f5d30d57d8951
	.p2align	2
_wf_place_back$instance$e90f5d30d57d8951: ; @"wf_place_back$instance$e90f5d30d57d8951"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x9, [x0, #16]
	mov	w10, #112                       ; =0x70
	madd	x9, x8, x10, x9
	ldp	q1, q0, [x1, #80]
	ldp	q3, q2, [x1, #48]
	ldp	q5, q4, [x1, #16]
	ldr	q6, [x1]
	stp	q6, q5, [x9]
	stp	q4, q3, [x9, #32]
	stp	q2, q1, [x9, #64]
	str	q0, [x9, #96]
	add	x8, x8, #1
	str	x8, [x0]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_take_back$instance$90ab86c4509859d9 ; -- Begin function wf_take_back$instance$90ab86c4509859d9
	.p2align	2
_wf_take_back$instance$90ab86c4509859d9: ; @"wf_take_back$instance$90ab86c4509859d9"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	sub	x9, x8, #1
	str	x9, [x1]
	mov	w9, #88                         ; =0x58
	madd	x8, x8, x9, x1
	ldp	q0, q1, [x8, #-48]
	stp	q0, q1, [x0, #32]
	ldur	q0, [x8, #-16]
	str	q0, [x0, #64]
	ldr	x9, [x8]
	str	x9, [x0, #80]
	ldp	q0, q1, [x8, #-80]
	stp	q0, q1, [x0]
	ret
                                        ; -- End function
	.globl	_wf_take_back$instance$e90f5d30d57d8951 ; -- Begin function wf_take_back$instance$e90f5d30d57d8951
	.p2align	2
_wf_take_back$instance$e90f5d30d57d8951: ; @"wf_take_back$instance$e90f5d30d57d8951"
; %bb.0:                                ; %entry
	ldr	x8, [x1]
	sub	x8, x8, #1
	ldr	x9, [x1, #16]
	mov	w10, #112                       ; =0x70
	madd	x9, x8, x10, x9
	str	x8, [x1]
	ldp	q1, q0, [x9, #80]
	ldp	q3, q2, [x9, #48]
	ldp	q5, q4, [x9, #16]
	ldr	q6, [x9]
	stp	q6, q5, [x0]
	stp	q4, q3, [x0, #32]
	stp	q2, q1, [x0, #64]
	str	q0, [x0, #96]
	ret
                                        ; -- End function
	.globl	_wf_free_empty$instance$bc7c27c9116e7ad8 ; -- Begin function wf_free_empty$instance$bc7c27c9116e7ad8
	.p2align	2
_wf_free_empty$instance$bc7c27c9116e7ad8: ; @"wf_free_empty$instance$bc7c27c9116e7ad8"
; %bb.0:                                ; %entry
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_free_empty$instance$2b0e6782a5453966 ; -- Begin function wf_free_empty$instance$2b0e6782a5453966
	.p2align	2
_wf_free_empty$instance$2b0e6782a5453966: ; @"wf_free_empty$instance$2b0e6782a5453966"
; %bb.0:                                ; %entry
	ldr	x8, [x0, #8]
	cbz	x8, LBB339_2
; %bb.1:                                ; %slots.release.drop.6
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	ldr	x0, [x0, #16]
	bl	_free
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
LBB339_2:                               ; %slots.release.done.drop.6
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf_grow$instance$57d99a800120d980 ; -- Begin function wf_grow$instance$57d99a800120d980
	.p2align	2
_wf_grow$instance$57d99a800120d980:     ; @"wf_grow$instance$57d99a800120d980"
	.cfi_startproc
; %bb.0:                                ; %entry
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	mov	x19, x1
	mov	x20, x0
	ldr	x21, [x0, #16]
	cbz	x1, LBB340_5
; %bb.1:                                ; %window.grow.positive.v2
	lsl	x1, x19, #5
	ldp	x22, x23, [x20]
	cmp	x22, x23
	ccmp	x23, #0, #4, eq
	b.ne	LBB340_6
; %bb.2:                                ; %window.grow.copy.v2
	mov	x0, x1
	bl	_malloc
	cbz	x0, LBB340_8
; %bb.3:                                ; %window.grow.copy.ready.v2
	cbz	x23, LBB340_7
; %bb.4:                                ; %window.grow.copy.old.v2
	lsl	x2, x22, #5
	mov	x22, x0
	mov	x1, x21
	bl	_memcpy
	mov	x0, x21
	bl	_free
	mov	x0, x22
	b	LBB340_7
LBB340_5:
	mov	x0, x21
	b	LBB340_7
LBB340_6:                               ; %window.grow.reallocate.v2
	mov	x0, x21
	bl	_realloc
	cbz	x0, LBB340_8
LBB340_7:                               ; %window.block.ready.v2
	stp	x19, x0, [x20, #8]
	mov	w0, #0                          ; =0x0
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
LBB340_8:                               ; %window.block.oom.v2
	bl	l_wf_resource_abort
	.cfi_endproc
                                        ; -- End function
	.globl	_wf_swap$instance$4a70da04567deb49 ; -- Begin function wf_swap$instance$4a70da04567deb49
	.p2align	2
_wf_swap$instance$4a70da04567deb49:     ; @"wf_swap$instance$4a70da04567deb49"
; %bb.0:                                ; %entry
	ldr	x8, [x0]
	ldr	x9, [x1]
	str	x9, [x0]
	str	x8, [x1]
	mov	w0, #0                          ; =0x0
	ret
                                        ; -- End function
	.globl	_wf__floor_run                  ; -- Begin function wf__floor_run
	.weak_definition	_wf__floor_run
	.p2align	2
_wf__floor_run:                         ; @wf__floor_run
	.cfi_startproc
; %bb.0:                                ; %entry
	b	_wf__main_body
	.cfi_endproc
                                        ; -- End function
	.globl	_wf__main_body                  ; -- Begin function wf__main_body
	.p2align	2
_wf__main_body:                         ; @wf__main_body
	.cfi_startproc
; %bb.0:                                ; %entry
	sub	sp, sp, #48
	stp	x29, x30, [sp, #32]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x0, sp
	bl	_wf_main
	mov	x0, sp
	bl	_wf__ordinary_exit_code
	and	w0, w0, #0xff
	ldp	x29, x30, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
	.cfi_endproc
                                        ; -- End function
	.globl	_main                           ; -- Begin function main
	.p2align	2
_main:                                  ; @main
	.cfi_startproc
; %bb.0:                                ; %entry
	b	_wf__floor_run
	.cfi_endproc
                                        ; -- End function
.zerofill __DATA,__bss,l_.wf.empty.slots.payload,8,3 ; @.wf.empty.slots.payload
	.section	__TEXT,__const
l_.wf_resource.heap:                    ; @.wf_resource.heap
	.ascii	"{\"resource\":\"heap\"}\n"

.subsections_via_symbols
